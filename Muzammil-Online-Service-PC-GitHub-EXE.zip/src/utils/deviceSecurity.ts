const STORAGE_KEYS = {
	DEVICE_ID: "mos_hardware_device_id",
	DEVICE_NAME: "mos_hardware_device_name",
	OPERATORS: "mos_registered_operators",
	AUDIT_LOGS: "mos_security_audit_logs"
};
// Detect if current runtime is a mobile phone / tablet
export function isMobileDevice() {
	if (typeof navigator === "undefined") return false;
	return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
}
// Persistent hardware device ID (Generated once per machine/browser)
export function getHardwareDeviceId() {
	try {
		let deviceId = localStorage.getItem(STORAGE_KEYS.DEVICE_ID);
		if (!deviceId) {
			const randStr = Math.random().toString(36).substring(2, 6).toUpperCase() + "-" + Math.random().toString(36).substring(2, 6).toUpperCase();
			const mobile = isMobileDevice();
			deviceId = `DEV-MOS-${mobile ? "MOB" : "PC"}-${randStr}`;
			localStorage.setItem(STORAGE_KEYS.DEVICE_ID, deviceId);
		}
		return deviceId;
	} catch {
		return "DEV-MOS-DEFAULT-001";
	}
}
// Friendly device name based on platform/browser
export function getHardwareDeviceName() {
	try {
		let name = localStorage.getItem(STORAGE_KEYS.DEVICE_NAME);
		if (!name) {
			const ua = navigator.userAgent;
			let os = "Windows PC";
			if (/Android/i.test(ua)) os = "Android Mobile";
			else if (/iPhone/i.test(ua)) os = "iPhone";
			else if (/iPad/i.test(ua)) os = "iPad";
			else if (/Mac/i.test(ua)) os = "Mac Workstation";
			else if (/Linux/i.test(ua)) os = "Linux Workstation";
			let browser = "Chrome";
			if (/Firefox/i.test(ua)) browser = "Firefox";
			else if (/Edg/i.test(ua)) browser = "Edge";
			else if (/Safari/i.test(ua) && !/Chrome/i.test(ua)) browser = "Safari";
			name = `${os} • ${browser}`;
			localStorage.setItem(STORAGE_KEYS.DEVICE_NAME, name);
		}
		return name;
	} catch {
		return isMobileDevice() ? "Authorized Mobile" : "Authorized Workstation";
	}
}
// Default pre-configured operators (Dual Device: 1 PC + 1 Mobile)
const DEFAULT_OPERATORS = [
	{
		id: "op-admin",
		username: "admin",
		password: "muzammil786",
		displayName: "Imran Khan (Master Admin)",
		role: "admin",
		phone: "9561460313",
		boundPcDeviceId: null,
		boundPcDeviceName: null,
		boundPcAt: null,
		boundMobileDeviceId: null,
		boundMobileDeviceName: null,
		boundMobileAt: null,
		lastLogin: null,
		isLocked: false
	},
	{
		id: "op-1",
		username: "operator1",
		password: "sameer123",
		displayName: "Shaikh Sameer",
		role: "operator",
		phone: "9876543210",
		boundPcDeviceId: null,
		boundPcDeviceName: null,
		boundPcAt: null,
		boundMobileDeviceId: null,
		boundMobileDeviceName: null,
		boundMobileAt: null,
		lastLogin: null,
		isLocked: false
	},
	{
		id: "op-2",
		username: "operator2",
		password: "adil123",
		displayName: "Adil Khan",
		role: "operator",
		phone: "9123456780",
		boundPcDeviceId: null,
		boundPcDeviceName: null,
		boundPcAt: null,
		boundMobileDeviceId: null,
		boundMobileDeviceName: null,
		boundMobileAt: null,
		lastLogin: null,
		isLocked: false
	}
];
// Load registered operators
export function getRegisteredOperators() {
	try {
		const raw = localStorage.getItem(STORAGE_KEYS.OPERATORS);
		if (!raw) {
			localStorage.setItem(STORAGE_KEYS.OPERATORS, JSON.stringify(DEFAULT_OPERATORS));
			return DEFAULT_OPERATORS;
		}
		const parsed = JSON.parse(raw);
		// Ensure dual device fields are present if loaded from legacy format
		return parsed.map((op) => ({
			...op,
			boundPcDeviceId: op.boundPcDeviceId ?? (op.boundDeviceId?.includes("-PC-") ? op.boundDeviceId : null),
			boundPcDeviceName: op.boundPcDeviceName ?? (op.boundDeviceId?.includes("-PC-") ? op.boundDeviceName : null),
			boundPcAt: op.boundPcAt ?? (op.boundDeviceId?.includes("-PC-") ? op.boundAt : null),
			boundMobileDeviceId: op.boundMobileDeviceId ?? (op.boundDeviceId?.includes("-MOB-") ? op.boundDeviceId : null),
			boundMobileDeviceName: op.boundMobileDeviceName ?? (op.boundDeviceId?.includes("-MOB-") ? op.boundDeviceName : null),
			boundMobileAt: op.boundMobileAt ?? (op.boundDeviceId?.includes("-MOB-") ? op.boundAt : null)
		}));
	} catch {
		return DEFAULT_OPERATORS;
	}
}
// Save operators
export function saveRegisteredOperators(operators) {
	try {
		localStorage.setItem(STORAGE_KEYS.OPERATORS, JSON.stringify(operators));
	} catch (e) {
		console.error("Failed to save operators", e);
	}
}
// Add security audit log
export function addSecurityAuditLog(action, username, details) {
	try {
		const deviceId = getHardwareDeviceId();
		const deviceName = getHardwareDeviceName();
		const deviceType = isMobileDevice() ? "mobile" : "pc";
		const raw = localStorage.getItem(STORAGE_KEYS.AUDIT_LOGS);
		const logs = raw ? JSON.parse(raw) : [];
		const newLog = {
			id: `log-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
			timestamp: new Date().toLocaleString("en-IN", {
				day: "2-digit",
				month: "short",
				year: "numeric",
				hour: "2-digit",
				minute: "2-digit",
				second: "2-digit"
			}),
			username,
			action,
			deviceId,
			deviceName,
			deviceType,
			details
		};
		logs.unshift(newLog);
		if (logs.length > 60) logs.pop();
		localStorage.setItem(STORAGE_KEYS.AUDIT_LOGS, JSON.stringify(logs));
	} catch (e) {
		console.error("Failed to record audit log", e);
	}
}
export function getSecurityAuditLogs() {
	try {
		const raw = localStorage.getItem(STORAGE_KEYS.AUDIT_LOGS);
		return raw ? JSON.parse(raw) : [];
	} catch {
		return [];
	}
}
export function authenticateOperator(usernameInput, passwordInput) {
	const username = usernameInput.trim().toLowerCase();
	const password = passwordInput.trim();
	const currentDeviceId = getHardwareDeviceId();
	const currentDeviceName = getHardwareDeviceName();
	const currentType = isMobileDevice() ? "mobile" : "pc";
	const operators = getRegisteredOperators();
	const operator = operators.find((o) => o.username.toLowerCase() === username);
	if (!operator) {
		addSecurityAuditLog("LOGIN_FAILED", username, "Invalid operator username");
		return {
			success: false,
			error: "Invalid Operator ID. Please verify your username."
		};
	}
	// Check password
	if (operator.password && operator.password !== password) {
		addSecurityAuditLog("LOGIN_FAILED", username, "Incorrect password entered");
		return {
			success: false,
			error: "Incorrect Password. Please try again."
		};
	}
	// Check if account is suspended / locked
	if (operator.isLocked) {
		addSecurityAuditLog("OPERATOR_LOCKED", username, "Attempt to login to suspended account");
		return {
			success: false,
			error: "⛔ ACCOUNT SUSPENDED: This operator ID has been locked by Master Admin. Please contact shop owner."
		};
	}
	// -------------------------------------------------------------
	// DUAL-DEVICE ENFORCEMENT: PC SLOT vs MOBILE SLOT
	// -------------------------------------------------------------
	const now = new Date().toLocaleString("en-IN");
	if (currentType === "pc") {
		// Logging in from PC
		if (!operator.boundPcDeviceId) {
			// First PC login: Bind this PC!
			operator.boundPcDeviceId = currentDeviceId;
			operator.boundPcDeviceName = currentDeviceName;
			operator.boundPcAt = now;
			operator.lastLogin = now;
			saveRegisteredOperators(operators);
			addSecurityAuditLog("DEVICE_BOUND", username, `PC bound: ${currentDeviceName} (${currentDeviceId})`);
		} else if (operator.boundPcDeviceId !== currentDeviceId) {
			// Different PC tried to access!
			addSecurityAuditLog("DEVICE_BLOCKED", username, `Unauthorized PC login attempt. ID is already bound to PC (${operator.boundPcDeviceName} / ${operator.boundPcDeviceId})`);
			return {
				success: false,
				deviceLockedToOther: true,
				deviceType: "pc",
				boundDeviceName: operator.boundPcDeviceName || operator.boundPcDeviceId,
				error: `🚨 PC DEVICE MISMATCH:\nThis Operator ID is already paired with your shop PC (${operator.boundPcDeviceName || operator.boundPcDeviceId}).\n\n1 ID is permitted on 1 PC + 1 Mobile only. To use on this new computer, ask Master Admin to reset your PC binding.`
			};
		} else {
			// Authorized PC match!
			operator.lastLogin = now;
			saveRegisteredOperators(operators);
			addSecurityAuditLog("LOGIN_SUCCESS", username, `Successful login on authorized PC (${currentDeviceId})`);
		}
	} else {
		// Logging in from Mobile Phone / Tablet
		if (!operator.boundMobileDeviceId) {
			// First Mobile login: Bind this Mobile!
			operator.boundMobileDeviceId = currentDeviceId;
			operator.boundMobileDeviceName = currentDeviceName;
			operator.boundMobileAt = now;
			operator.lastLogin = now;
			saveRegisteredOperators(operators);
			addSecurityAuditLog("DEVICE_BOUND", username, `Mobile bound: ${currentDeviceName} (${currentDeviceId})`);
		} else if (operator.boundMobileDeviceId !== currentDeviceId) {
			// Different Mobile tried to access!
			addSecurityAuditLog("DEVICE_BLOCKED", username, `Unauthorized Mobile login attempt. ID is already bound to Mobile (${operator.boundMobileDeviceName} / ${operator.boundMobileDeviceId})`);
			return {
				success: false,
				deviceLockedToOther: true,
				deviceType: "mobile",
				boundDeviceName: operator.boundMobileDeviceName || operator.boundMobileDeviceId,
				error: `🚨 MOBILE DEVICE MISMATCH:\nThis Operator ID is already paired with your registered Mobile (${operator.boundMobileDeviceName || operator.boundMobileDeviceId}).\n\n1 ID is permitted on 1 PC + 1 Mobile only. To use on this new phone, ask Master Admin to reset your Mobile binding.`
			};
		} else {
			// Authorized Mobile match!
			operator.lastLogin = now;
			saveRegisteredOperators(operators);
			addSecurityAuditLog("LOGIN_SUCCESS", username, `Successful login on authorized Mobile (${currentDeviceId})`);
		}
	}
	const activeUser = {
		username: operator.username,
		displayName: operator.displayName,
		role: operator.role,
		phone: operator.phone,
		shopName: "Muzammil Online Service",
		isLoggedIn: true,
		currentDeviceType: currentType,
		currentDeviceId,
		currentDeviceName,
		boundPcDeviceId: operator.boundPcDeviceId || undefined,
		boundMobileDeviceId: operator.boundMobileDeviceId || undefined
	};
	return {
		success: true,
		user: activeUser
	};
}
// Master Admin: Reset PC Device Binding
export function resetOperatorPcBinding(operatorId) {
	const operators = getRegisteredOperators();
	const op = operators.find((o) => o.id === operatorId || o.username === operatorId);
	if (!op) return false;
	const prev = op.boundPcDeviceName || op.boundPcDeviceId || "PC";
	op.boundPcDeviceId = null;
	op.boundPcDeviceName = null;
	op.boundPcAt = null;
	saveRegisteredOperators(operators);
	addSecurityAuditLog("DEVICE_RESET", op.username, `Master Admin cleared PC device binding (was: ${prev})`);
	return true;
}
// Master Admin: Reset Mobile Device Binding
export function resetOperatorMobileBinding(operatorId) {
	const operators = getRegisteredOperators();
	const op = operators.find((o) => o.id === operatorId || o.username === operatorId);
	if (!op) return false;
	const prev = op.boundMobileDeviceName || op.boundMobileDeviceId || "Mobile";
	op.boundMobileDeviceId = null;
	op.boundMobileDeviceName = null;
	op.boundMobileAt = null;
	saveRegisteredOperators(operators);
	addSecurityAuditLog("DEVICE_RESET", op.username, `Master Admin cleared Mobile device binding (was: ${prev})`);
	return true;
}
// Master Admin: Reset Both Device Bindings (Full Reset)
export function resetOperatorAllBindings(operatorId) {
	const operators = getRegisteredOperators();
	const op = operators.find((o) => o.id === operatorId || o.username === operatorId);
	if (!op) return false;
	op.boundPcDeviceId = null;
	op.boundPcDeviceName = null;
	op.boundPcAt = null;
	op.boundMobileDeviceId = null;
	op.boundMobileDeviceName = null;
	op.boundMobileAt = null;
	saveRegisteredOperators(operators);
	addSecurityAuditLog("DEVICE_RESET", op.username, `Master Admin cleared all device bindings (PC & Mobile)`);
	return true;
}
// Master Admin: Toggle Lock Account
export function toggleOperatorLock(operatorId) {
	const operators = getRegisteredOperators();
	const op = operators.find((o) => o.id === operatorId || o.username === operatorId);
	if (!op) return false;
	op.isLocked = !op.isLocked;
	saveRegisteredOperators(operators);
	addSecurityAuditLog("OPERATOR_LOCKED", op.username, `Master Admin set lock status to: ${op.isLocked ? "LOCKED" : "ACTIVE"}`);
	return true;
}
// Master Admin: Add Operator
export function addNewOperator(op) {
	const operators = getRegisteredOperators();
	if (operators.some((o) => o.username.toLowerCase() === op.username.toLowerCase())) {
		return false;
	}
	const newOp = {
		...op,
		id: `op-${Date.now()}`,
		boundPcDeviceId: null,
		boundPcDeviceName: null,
		boundPcAt: null,
		boundMobileDeviceId: null,
		boundMobileDeviceName: null,
		boundMobileAt: null,
		lastLogin: null,
		isLocked: false
	};
	operators.push(newOp);
	saveRegisteredOperators(operators);
	addSecurityAuditLog("LOGIN_SUCCESS", "admin", `Master Admin registered new operator: ${op.username}`);
	return true;
}
// Master Admin: Delete Operator
export function deleteOperator(operatorId) {
	let operators = getRegisteredOperators();
	const op = operators.find((o) => o.id === operatorId);
	if (!op || op.role === "admin") return false;
	operators = operators.filter((o) => o.id !== operatorId);
	saveRegisteredOperators(operators);
	addSecurityAuditLog("LOGIN_SUCCESS", "admin", `Master Admin deleted operator: ${op.username}`);
	return true;
}
// Calculate Days Left until validity expiry
export function calculateRemainingDays(dateStr) {
	if (!dateStr) return 90;
	const expiry = new Date(dateStr).getTime();
	const now = Date.now();
	const diff = expiry - now;
	return Math.max(0, Math.ceil(diff / (1e3 * 60 * 60 * 24)));
}
// Master Admin: Renew Operator License / Access
export function renewOperatorLicense(operatorId, daysToAdd) {
	const operators = getRegisteredOperators();
	const op = operators.find((o) => o.id === operatorId || o.username === operatorId);
	if (!op) return {
		success: false,
		newExpiry: "",
		daysLeft: 0
	};
	let currentExpiry = op.validityExpiresAt ? new Date(op.validityExpiresAt).getTime() : Date.now();
	if (currentExpiry < Date.now()) {
		currentExpiry = Date.now();
	}
	const newExpiryTime = currentExpiry + daysToAdd * 24 * 60 * 60 * 1e3;
	const newExpiryStr = new Date(newExpiryTime).toISOString().split("T")[0];
	const daysLeft = Math.ceil((newExpiryTime - Date.now()) / (1e3 * 60 * 60 * 24));
	op.validityExpiresAt = newExpiryStr;
	op.validityDaysLeft = daysLeft;
	saveRegisteredOperators(operators);
	addSecurityAuditLog("LOGIN_SUCCESS", op.username, `License renewed for +${daysToAdd} days. Valid until ${newExpiryStr} (${daysLeft} days left)`);
	return {
		success: true,
		newExpiry: newExpiryStr,
		daysLeft
	};
}
// Client Live Heartbeat Reporter
export async function sendOperatorHeartbeat(data) {
	const deviceId = getHardwareDeviceId();
	const deviceName = getHardwareDeviceName();
	const deviceType = isMobileDevice() ? "mobile" : "pc";
	try {
		const res = await fetch("/api/live/heartbeat", {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify({
				...data,
				deviceId,
				deviceName,
				deviceType
			})
		});
		if (res.ok) {
			return await res.json();
		}
	} catch {
		// Offline mode: store in local storage heartbeat registry
		try {
			const localKey = "mos_local_live_pulse";
			const existing = JSON.parse(localStorage.getItem(localKey) || "{}");
			existing[data.username] = {
				...data,
				deviceId,
				deviceName,
				deviceType,
				lastHeartbeat: new Date().toISOString()
			};
			localStorage.setItem(localKey, JSON.stringify(existing));
		} catch {}
	}
	return {
		success: true,
		activeCount: 1,
		broadcastMessage: null
	};
}
// Master Admin: Fetch Live Operator Sessions
export async function getLiveOperatorSessions() {
	try {
		const res = await fetch("/api/live/sessions");
		if (res.ok) {
			const data = await res.json();
			return data.sessions || [];
		}
	} catch {}
	// Local fallback if server unreachable
	const operators = getRegisteredOperators();
	const currentDevId = getHardwareDeviceId();
	const currentDevName = getHardwareDeviceName();
	return operators.map((op) => ({
		sessionId: `local-${op.id}`,
		username: op.username,
		displayName: op.displayName,
		role: op.role,
		phone: op.phone,
		deviceType: isMobileDevice() ? "mobile" : "pc",
		deviceId: currentDevId,
		deviceName: currentDevName,
		currentTab: "Workstation Active",
		currentTask: "Online Hub",
		loginTime: op.lastLogin || new Date().toISOString(),
		lastHeartbeat: new Date().toISOString(),
		validityExpiresAt: op.validityExpiresAt || "2026-12-31",
		isOnline: true,
		lastActiveSecondsAgo: 2,
		ipAddress: "127.0.0.1 (Local)"
	}));
}
// Master Admin: Force Disconnect an Operator
export async function forceDisconnectOperator(username, deviceId) {
	try {
		const res = await fetch("/api/live/terminate", {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify({
				username,
				deviceId
			})
		});
		return res.ok;
	} catch {
		return false;
	}
}
// Master Admin: Broadcast message to operator
export async function sendOperatorBroadcastMessage(username, message) {
	try {
		const res = await fetch("/api/live/broadcast", {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify({
				username,
				message
			})
		});
		return res.ok;
	} catch {
		return false;
	}
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBRUEsTUFBTSxlQUFlO0NBQ25CLFdBQVc7Q0FDWCxhQUFhO0NBQ2IsV0FBVztDQUNYLFlBQVk7QUFDZDs7QUFjQSxPQUFPLFNBQVMsaUJBQTBCO0NBQ3hDLElBQUksT0FBTyxjQUFjLGFBQWEsT0FBTztDQUM3QyxPQUFPLGlFQUFpRSxLQUFLLFVBQVUsU0FBUztBQUNsRzs7QUFHQSxPQUFPLFNBQVMsc0JBQThCO0NBQzVDLElBQUk7RUFDRixJQUFJLFdBQVcsYUFBYSxRQUFRLGFBQWEsU0FBUztFQUMxRCxJQUFJLENBQUMsVUFBVTtHQUNiLE1BQU0sVUFBVSxLQUFLLE9BQU8sQ0FBQyxDQUFDLFNBQVMsRUFBRSxDQUFDLENBQUMsVUFBVSxHQUFHLENBQUMsQ0FBQyxDQUFDLFlBQVksSUFBSSxNQUFNLEtBQUssT0FBTyxDQUFDLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQyxVQUFVLEdBQUcsQ0FBQyxDQUFDLENBQUMsWUFBWTtHQUN4SSxNQUFNLFNBQVMsZUFBZTtHQUM5QixXQUFXLFdBQVcsU0FBUyxRQUFRLEtBQUssR0FBRztHQUMvQyxhQUFhLFFBQVEsYUFBYSxXQUFXLFFBQVE7RUFDdkQ7RUFDQSxPQUFPO0NBQ1QsUUFBUTtFQUNOLE9BQU87Q0FDVDtBQUNGOztBQUdBLE9BQU8sU0FBUyx3QkFBZ0M7Q0FDOUMsSUFBSTtFQUNGLElBQUksT0FBTyxhQUFhLFFBQVEsYUFBYSxXQUFXO0VBQ3hELElBQUksQ0FBQyxNQUFNO0dBQ1QsTUFBTSxLQUFLLFVBQVU7R0FDckIsSUFBSSxLQUFLO0dBQ1QsSUFBSSxXQUFXLEtBQUssRUFBRSxHQUFHLEtBQUs7UUFDekIsSUFBSSxVQUFVLEtBQUssRUFBRSxHQUFHLEtBQUs7UUFDN0IsSUFBSSxRQUFRLEtBQUssRUFBRSxHQUFHLEtBQUs7UUFDM0IsSUFBSSxPQUFPLEtBQUssRUFBRSxHQUFHLEtBQUs7UUFDMUIsSUFBSSxTQUFTLEtBQUssRUFBRSxHQUFHLEtBQUs7R0FFakMsSUFBSSxVQUFVO0dBQ2QsSUFBSSxXQUFXLEtBQUssRUFBRSxHQUFHLFVBQVU7UUFDOUIsSUFBSSxPQUFPLEtBQUssRUFBRSxHQUFHLFVBQVU7UUFDL0IsSUFBSSxVQUFVLEtBQUssRUFBRSxLQUFLLENBQUMsVUFBVSxLQUFLLEVBQUUsR0FBRyxVQUFVO0dBRTlELE9BQU8sR0FBRyxHQUFHLEtBQUs7R0FDbEIsYUFBYSxRQUFRLGFBQWEsYUFBYSxJQUFJO0VBQ3JEO0VBQ0EsT0FBTztDQUNULFFBQVE7RUFDTixPQUFPLGVBQWUsSUFBSSxzQkFBc0I7Q0FDbEQ7QUFDRjs7QUFHQSxNQUFNLG9CQUF1QztDQUMzQztFQUNFLElBQUk7RUFDSixVQUFVO0VBQ1YsVUFBVTtFQUNWLGFBQWE7RUFDYixNQUFNO0VBQ04sT0FBTztFQUNQLGlCQUFpQjtFQUNqQixtQkFBbUI7RUFDbkIsV0FBVztFQUNYLHFCQUFxQjtFQUNyQix1QkFBdUI7RUFDdkIsZUFBZTtFQUNmLFdBQVc7RUFDWCxVQUFVO0NBQ1o7Q0FDQTtFQUNFLElBQUk7RUFDSixVQUFVO0VBQ1YsVUFBVTtFQUNWLGFBQWE7RUFDYixNQUFNO0VBQ04sT0FBTztFQUNQLGlCQUFpQjtFQUNqQixtQkFBbUI7RUFDbkIsV0FBVztFQUNYLHFCQUFxQjtFQUNyQix1QkFBdUI7RUFDdkIsZUFBZTtFQUNmLFdBQVc7RUFDWCxVQUFVO0NBQ1o7Q0FDQTtFQUNFLElBQUk7RUFDSixVQUFVO0VBQ1YsVUFBVTtFQUNWLGFBQWE7RUFDYixNQUFNO0VBQ04sT0FBTztFQUNQLGlCQUFpQjtFQUNqQixtQkFBbUI7RUFDbkIsV0FBVztFQUNYLHFCQUFxQjtFQUNyQix1QkFBdUI7RUFDdkIsZUFBZTtFQUNmLFdBQVc7RUFDWCxVQUFVO0NBQ1o7QUFDRjs7QUFHQSxPQUFPLFNBQVMseUJBQTRDO0NBQzFELElBQUk7RUFDRixNQUFNLE1BQU0sYUFBYSxRQUFRLGFBQWEsU0FBUztFQUN2RCxJQUFJLENBQUMsS0FBSztHQUNSLGFBQWEsUUFBUSxhQUFhLFdBQVcsS0FBSyxVQUFVLGlCQUFpQixDQUFDO0dBQzlFLE9BQU87RUFDVDtFQUNBLE1BQU0sU0FBUyxLQUFLLE1BQU0sR0FBRzs7RUFFN0IsT0FBTyxPQUFPLEtBQUssUUFBYTtHQUM5QixHQUFHO0dBQ0gsaUJBQWlCLEdBQUcsb0JBQW9CLEdBQUcsZUFBZSxTQUFTLE1BQU0sSUFBSSxHQUFHLGdCQUFnQjtHQUNoRyxtQkFBbUIsR0FBRyxzQkFBc0IsR0FBRyxlQUFlLFNBQVMsTUFBTSxJQUFJLEdBQUcsa0JBQWtCO0dBQ3RHLFdBQVcsR0FBRyxjQUFjLEdBQUcsZUFBZSxTQUFTLE1BQU0sSUFBSSxHQUFHLFVBQVU7R0FDOUUscUJBQXFCLEdBQUcsd0JBQXdCLEdBQUcsZUFBZSxTQUFTLE9BQU8sSUFBSSxHQUFHLGdCQUFnQjtHQUN6Ryx1QkFBdUIsR0FBRywwQkFBMEIsR0FBRyxlQUFlLFNBQVMsT0FBTyxJQUFJLEdBQUcsa0JBQWtCO0dBQy9HLGVBQWUsR0FBRyxrQkFBa0IsR0FBRyxlQUFlLFNBQVMsT0FBTyxJQUFJLEdBQUcsVUFBVTtFQUN6RixFQUFFO0NBQ0osUUFBUTtFQUNOLE9BQU87Q0FDVDtBQUNGOztBQUdBLE9BQU8sU0FBUyx3QkFBd0IsV0FBb0M7Q0FDMUUsSUFBSTtFQUNGLGFBQWEsUUFBUSxhQUFhLFdBQVcsS0FBSyxVQUFVLFNBQVMsQ0FBQztDQUN4RSxTQUFTLEdBQUc7RUFDVixRQUFRLE1BQU0sNEJBQTRCLENBQUM7Q0FDN0M7QUFDRjs7QUFHQSxPQUFPLFNBQVMsb0JBQ2QsUUFDQSxVQUNBLFNBQ007Q0FDTixJQUFJO0VBQ0YsTUFBTSxXQUFXLG9CQUFvQjtFQUNyQyxNQUFNLGFBQWEsc0JBQXNCO0VBQ3pDLE1BQU0sYUFBOEIsZUFBZSxJQUFJLFdBQVc7RUFFbEUsTUFBTSxNQUFNLGFBQWEsUUFBUSxhQUFhLFVBQVU7RUFDeEQsTUFBTSxPQUEyQixNQUFNLEtBQUssTUFBTSxHQUFHLElBQUksQ0FBQztFQUUxRCxNQUFNLFNBQTJCO0dBQy9CLElBQUksT0FBTyxLQUFLLElBQUksRUFBRSxHQUFHLEtBQUssT0FBTyxDQUFDLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQyxPQUFPLEdBQUcsQ0FBQztHQUMvRCxXQUFXLElBQUksS0FBSyxDQUFDLENBQUMsZUFBZSxTQUFTO0lBQzVDLEtBQUs7SUFDTCxPQUFPO0lBQ1AsTUFBTTtJQUNOLE1BQU07SUFDTixRQUFRO0lBQ1IsUUFBUTtHQUNWLENBQUM7R0FDRDtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7RUFDRjtFQUVBLEtBQUssUUFBUSxNQUFNO0VBQ25CLElBQUksS0FBSyxTQUFTLElBQUksS0FBSyxJQUFJO0VBQy9CLGFBQWEsUUFBUSxhQUFhLFlBQVksS0FBSyxVQUFVLElBQUksQ0FBQztDQUNwRSxTQUFTLEdBQUc7RUFDVixRQUFRLE1BQU0sOEJBQThCLENBQUM7Q0FDL0M7QUFDRjtBQUVBLE9BQU8sU0FBUyx1QkFBMkM7Q0FDekQsSUFBSTtFQUNGLE1BQU0sTUFBTSxhQUFhLFFBQVEsYUFBYSxVQUFVO0VBQ3hELE9BQU8sTUFBTSxLQUFLLE1BQU0sR0FBRyxJQUFJLENBQUM7Q0FDbEMsUUFBUTtFQUNOLE9BQU8sQ0FBQztDQUNWO0FBQ0Y7QUFjQSxPQUFPLFNBQVMscUJBQXFCLGVBQXVCLGVBQW1DO0NBQzdGLE1BQU0sV0FBVyxjQUFjLEtBQUssQ0FBQyxDQUFDLFlBQVk7Q0FDbEQsTUFBTSxXQUFXLGNBQWMsS0FBSztDQUNwQyxNQUFNLGtCQUFrQixvQkFBb0I7Q0FDNUMsTUFBTSxvQkFBb0Isc0JBQXNCO0NBQ2hELE1BQU0sY0FBK0IsZUFBZSxJQUFJLFdBQVc7Q0FFbkUsTUFBTSxZQUFZLHVCQUF1QjtDQUN6QyxNQUFNLFdBQVcsVUFBVSxNQUFLLE1BQUssRUFBRSxTQUFTLFlBQVksTUFBTSxRQUFRO0NBRTFFLElBQUksQ0FBQyxVQUFVO0VBQ2Isb0JBQW9CLGdCQUFnQixVQUFVLDJCQUEyQjtFQUN6RSxPQUFPO0dBQ0wsU0FBUztHQUNULE9BQU87RUFDVDtDQUNGOztDQUdBLElBQUksU0FBUyxZQUFZLFNBQVMsYUFBYSxVQUFVO0VBQ3ZELG9CQUFvQixnQkFBZ0IsVUFBVSw0QkFBNEI7RUFDMUUsT0FBTztHQUNMLFNBQVM7R0FDVCxPQUFPO0VBQ1Q7Q0FDRjs7Q0FHQSxJQUFJLFNBQVMsVUFBVTtFQUNyQixvQkFBb0IsbUJBQW1CLFVBQVUsdUNBQXVDO0VBQ3hGLE9BQU87R0FDTCxTQUFTO0dBQ1QsT0FBTztFQUNUO0NBQ0Y7Ozs7Q0FLQSxNQUFNLE1BQU0sSUFBSSxLQUFLLENBQUMsQ0FBQyxlQUFlLE9BQU87Q0FFN0MsSUFBSSxnQkFBZ0IsTUFBTTs7RUFFeEIsSUFBSSxDQUFDLFNBQVMsaUJBQWlCOztHQUU3QixTQUFTLGtCQUFrQjtHQUMzQixTQUFTLG9CQUFvQjtHQUM3QixTQUFTLFlBQVk7R0FDckIsU0FBUyxZQUFZO0dBQ3JCLHdCQUF3QixTQUFTO0dBQ2pDLG9CQUFvQixnQkFBZ0IsVUFBVSxhQUFhLGtCQUFrQixJQUFJLGdCQUFnQixFQUFFO0VBQ3JHLE9BQU8sSUFBSSxTQUFTLG9CQUFvQixpQkFBaUI7O0dBRXZELG9CQUNFLGtCQUNBLFVBQ0EsNkRBQTZELFNBQVMsa0JBQWtCLEtBQUssU0FBUyxnQkFBZ0IsRUFDeEg7R0FFQSxPQUFPO0lBQ0wsU0FBUztJQUNULHFCQUFxQjtJQUNyQixZQUFZO0lBQ1osaUJBQWlCLFNBQVMscUJBQXFCLFNBQVM7SUFDeEQsT0FBTyxpRkFBaUYsU0FBUyxxQkFBcUIsU0FBUyxnQkFBZ0I7R0FDako7RUFDRixPQUFPOztHQUVMLFNBQVMsWUFBWTtHQUNyQix3QkFBd0IsU0FBUztHQUNqQyxvQkFBb0IsaUJBQWlCLFVBQVUsc0NBQXNDLGdCQUFnQixFQUFFO0VBQ3pHO0NBQ0YsT0FBTzs7RUFFTCxJQUFJLENBQUMsU0FBUyxxQkFBcUI7O0dBRWpDLFNBQVMsc0JBQXNCO0dBQy9CLFNBQVMsd0JBQXdCO0dBQ2pDLFNBQVMsZ0JBQWdCO0dBQ3pCLFNBQVMsWUFBWTtHQUNyQix3QkFBd0IsU0FBUztHQUNqQyxvQkFBb0IsZ0JBQWdCLFVBQVUsaUJBQWlCLGtCQUFrQixJQUFJLGdCQUFnQixFQUFFO0VBQ3pHLE9BQU8sSUFBSSxTQUFTLHdCQUF3QixpQkFBaUI7O0dBRTNELG9CQUNFLGtCQUNBLFVBQ0EscUVBQXFFLFNBQVMsc0JBQXNCLEtBQUssU0FBUyxvQkFBb0IsRUFDeEk7R0FFQSxPQUFPO0lBQ0wsU0FBUztJQUNULHFCQUFxQjtJQUNyQixZQUFZO0lBQ1osaUJBQWlCLFNBQVMseUJBQXlCLFNBQVM7SUFDNUQsT0FBTywrRkFBK0YsU0FBUyx5QkFBeUIsU0FBUyxvQkFBb0I7R0FDdks7RUFDRixPQUFPOztHQUVMLFNBQVMsWUFBWTtHQUNyQix3QkFBd0IsU0FBUztHQUNqQyxvQkFBb0IsaUJBQWlCLFVBQVUsMENBQTBDLGdCQUFnQixFQUFFO0VBQzdHO0NBQ0Y7Q0FFQSxNQUFNLGFBQTBCO0VBQzlCLFVBQVUsU0FBUztFQUNuQixhQUFhLFNBQVM7RUFDdEIsTUFBTSxTQUFTO0VBQ2YsT0FBTyxTQUFTO0VBQ2hCLFVBQVU7RUFDVixZQUFZO0VBQ1osbUJBQW1CO0VBQ25CO0VBQ0E7RUFDQSxpQkFBaUIsU0FBUyxtQkFBbUI7RUFDN0MscUJBQXFCLFNBQVMsdUJBQXVCO0NBQ3ZEO0NBRUEsT0FBTztFQUNMLFNBQVM7RUFDVCxNQUFNO0NBQ1I7QUFDRjs7QUFHQSxPQUFPLFNBQVMsdUJBQXVCLFlBQTZCO0NBQ2xFLE1BQU0sWUFBWSx1QkFBdUI7Q0FDekMsTUFBTSxLQUFLLFVBQVUsTUFBSyxNQUFLLEVBQUUsT0FBTyxjQUFjLEVBQUUsYUFBYSxVQUFVO0NBQy9FLElBQUksQ0FBQyxJQUFJLE9BQU87Q0FFaEIsTUFBTSxPQUFPLEdBQUcscUJBQXFCLEdBQUcsbUJBQW1CO0NBQzNELEdBQUcsa0JBQWtCO0NBQ3JCLEdBQUcsb0JBQW9CO0NBQ3ZCLEdBQUcsWUFBWTtDQUVmLHdCQUF3QixTQUFTO0NBQ2pDLG9CQUFvQixnQkFBZ0IsR0FBRyxVQUFVLGdEQUFnRCxLQUFLLEVBQUU7Q0FDeEcsT0FBTztBQUNUOztBQUdBLE9BQU8sU0FBUywyQkFBMkIsWUFBNkI7Q0FDdEUsTUFBTSxZQUFZLHVCQUF1QjtDQUN6QyxNQUFNLEtBQUssVUFBVSxNQUFLLE1BQUssRUFBRSxPQUFPLGNBQWMsRUFBRSxhQUFhLFVBQVU7Q0FDL0UsSUFBSSxDQUFDLElBQUksT0FBTztDQUVoQixNQUFNLE9BQU8sR0FBRyx5QkFBeUIsR0FBRyx1QkFBdUI7Q0FDbkUsR0FBRyxzQkFBc0I7Q0FDekIsR0FBRyx3QkFBd0I7Q0FDM0IsR0FBRyxnQkFBZ0I7Q0FFbkIsd0JBQXdCLFNBQVM7Q0FDakMsb0JBQW9CLGdCQUFnQixHQUFHLFVBQVUsb0RBQW9ELEtBQUssRUFBRTtDQUM1RyxPQUFPO0FBQ1Q7O0FBR0EsT0FBTyxTQUFTLHlCQUF5QixZQUE2QjtDQUNwRSxNQUFNLFlBQVksdUJBQXVCO0NBQ3pDLE1BQU0sS0FBSyxVQUFVLE1BQUssTUFBSyxFQUFFLE9BQU8sY0FBYyxFQUFFLGFBQWEsVUFBVTtDQUMvRSxJQUFJLENBQUMsSUFBSSxPQUFPO0NBRWhCLEdBQUcsa0JBQWtCO0NBQ3JCLEdBQUcsb0JBQW9CO0NBQ3ZCLEdBQUcsWUFBWTtDQUNmLEdBQUcsc0JBQXNCO0NBQ3pCLEdBQUcsd0JBQXdCO0NBQzNCLEdBQUcsZ0JBQWdCO0NBRW5CLHdCQUF3QixTQUFTO0NBQ2pDLG9CQUFvQixnQkFBZ0IsR0FBRyxVQUFVLHdEQUF3RDtDQUN6RyxPQUFPO0FBQ1Q7O0FBR0EsT0FBTyxTQUFTLG1CQUFtQixZQUE2QjtDQUM5RCxNQUFNLFlBQVksdUJBQXVCO0NBQ3pDLE1BQU0sS0FBSyxVQUFVLE1BQUssTUFBSyxFQUFFLE9BQU8sY0FBYyxFQUFFLGFBQWEsVUFBVTtDQUMvRSxJQUFJLENBQUMsSUFBSSxPQUFPO0NBRWhCLEdBQUcsV0FBVyxDQUFDLEdBQUc7Q0FDbEIsd0JBQXdCLFNBQVM7Q0FDakMsb0JBQW9CLG1CQUFtQixHQUFHLFVBQVUsb0NBQW9DLEdBQUcsV0FBVyxXQUFXLFVBQVU7Q0FDM0gsT0FBTztBQUNUOztBQUdBLE9BQU8sU0FBUyxlQUFlLElBQWlNO0NBQzlOLE1BQU0sWUFBWSx1QkFBdUI7Q0FDekMsSUFBSSxVQUFVLE1BQUssTUFBSyxFQUFFLFNBQVMsWUFBWSxNQUFNLEdBQUcsU0FBUyxZQUFZLENBQUMsR0FBRztFQUMvRSxPQUFPO0NBQ1Q7Q0FFQSxNQUFNLFFBQXlCO0VBQzdCLEdBQUc7RUFDSCxJQUFJLE1BQU0sS0FBSyxJQUFJO0VBQ25CLGlCQUFpQjtFQUNqQixtQkFBbUI7RUFDbkIsV0FBVztFQUNYLHFCQUFxQjtFQUNyQix1QkFBdUI7RUFDdkIsZUFBZTtFQUNmLFdBQVc7RUFDWCxVQUFVO0NBQ1o7Q0FFQSxVQUFVLEtBQUssS0FBSztDQUNwQix3QkFBd0IsU0FBUztDQUNqQyxvQkFBb0IsaUJBQWlCLFNBQVMseUNBQXlDLEdBQUcsVUFBVTtDQUNwRyxPQUFPO0FBQ1Q7O0FBR0EsT0FBTyxTQUFTLGVBQWUsWUFBNkI7Q0FDMUQsSUFBSSxZQUFZLHVCQUF1QjtDQUN2QyxNQUFNLEtBQUssVUFBVSxNQUFLLE1BQUssRUFBRSxPQUFPLFVBQVU7Q0FDbEQsSUFBSSxDQUFDLE1BQU0sR0FBRyxTQUFTLFNBQVMsT0FBTztDQUV2QyxZQUFZLFVBQVUsUUFBTyxNQUFLLEVBQUUsT0FBTyxVQUFVO0NBQ3JELHdCQUF3QixTQUFTO0NBQ2pDLG9CQUFvQixpQkFBaUIsU0FBUyxrQ0FBa0MsR0FBRyxVQUFVO0NBQzdGLE9BQU87QUFDVDs7QUFHQSxPQUFPLFNBQVMsdUJBQXVCLFNBQWlDO0NBQ3RFLElBQUksQ0FBQyxTQUFTLE9BQU87Q0FDckIsTUFBTSxTQUFTLElBQUksS0FBSyxPQUFPLENBQUMsQ0FBQyxRQUFRO0NBQ3pDLE1BQU0sTUFBTSxLQUFLLElBQUk7Q0FDckIsTUFBTSxPQUFPLFNBQVM7Q0FDdEIsT0FBTyxLQUFLLElBQUksR0FBRyxLQUFLLEtBQUssUUFBUSxNQUFPLEtBQUssS0FBSyxHQUFHLENBQUM7QUFDNUQ7O0FBR0EsT0FBTyxTQUFTLHFCQUFxQixZQUFvQixXQUE4RTtDQUNySSxNQUFNLFlBQVksdUJBQXVCO0NBQ3pDLE1BQU0sS0FBSyxVQUFVLE1BQUssTUFBSyxFQUFFLE9BQU8sY0FBYyxFQUFFLGFBQWEsVUFBVTtDQUMvRSxJQUFJLENBQUMsSUFBSSxPQUFPO0VBQUUsU0FBUztFQUFPLFdBQVc7RUFBSSxVQUFVO0NBQUU7Q0FFN0QsSUFBSSxnQkFBZ0IsR0FBRyxvQkFBb0IsSUFBSSxLQUFLLEdBQUcsaUJBQWlCLENBQUMsQ0FBQyxRQUFRLElBQUksS0FBSyxJQUFJO0NBQy9GLElBQUksZ0JBQWdCLEtBQUssSUFBSSxHQUFHO0VBQzlCLGdCQUFnQixLQUFLLElBQUk7Q0FDM0I7Q0FFQSxNQUFNLGdCQUFnQixnQkFBaUIsWUFBWSxLQUFLLEtBQUssS0FBSztDQUNsRSxNQUFNLGVBQWUsSUFBSSxLQUFLLGFBQWEsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7Q0FDdEUsTUFBTSxXQUFXLEtBQUssTUFBTSxnQkFBZ0IsS0FBSyxJQUFJLE1BQU0sTUFBTyxLQUFLLEtBQUssR0FBRztDQUUvRSxHQUFHLG9CQUFvQjtDQUN2QixHQUFHLG1CQUFtQjtDQUV0Qix3QkFBd0IsU0FBUztDQUNqQyxvQkFBb0IsaUJBQWlCLEdBQUcsVUFBVSx3QkFBd0IsVUFBVSxxQkFBcUIsYUFBYSxJQUFJLFNBQVMsWUFBWTtDQUUvSSxPQUFPO0VBQ0wsU0FBUztFQUNULFdBQVc7RUFDWDtDQUNGO0FBQ0Y7O0FBR0EsT0FBTyxlQUFlLHNCQUFzQixNQU82QztDQUN2RixNQUFNLFdBQVcsb0JBQW9CO0NBQ3JDLE1BQU0sYUFBYSxzQkFBc0I7Q0FDekMsTUFBTSxhQUFhLGVBQWUsSUFBSSxXQUFXO0NBRWpELElBQUk7RUFDRixNQUFNLE1BQU0sTUFBTSxNQUFNLHVCQUF1QjtHQUM3QyxRQUFRO0dBQ1IsU0FBUyxFQUFFLGdCQUFnQixtQkFBbUI7R0FDOUMsTUFBTSxLQUFLLFVBQVU7SUFDbkIsR0FBRztJQUNIO0lBQ0E7SUFDQTtHQUNGLENBQUM7RUFDSCxDQUFDO0VBQ0QsSUFBSSxJQUFJLElBQUk7R0FDVixPQUFPLE1BQU0sSUFBSSxLQUFLO0VBQ3hCO0NBQ0YsUUFBUTs7RUFFTixJQUFJO0dBQ0YsTUFBTSxXQUFXO0dBQ2pCLE1BQU0sV0FBVyxLQUFLLE1BQU0sYUFBYSxRQUFRLFFBQVEsS0FBSyxJQUFJO0dBQ2xFLFNBQVMsS0FBSyxZQUFZO0lBQ3hCLEdBQUc7SUFDSDtJQUNBO0lBQ0E7SUFDQSxlQUFlLElBQUksS0FBSyxDQUFDLENBQUMsWUFBWTtHQUN4QztHQUNBLGFBQWEsUUFBUSxVQUFVLEtBQUssVUFBVSxRQUFRLENBQUM7RUFDekQsUUFBUSxDQUFDO0NBQ1g7Q0FDQSxPQUFPO0VBQUUsU0FBUztFQUFNLGFBQWE7RUFBRyxrQkFBa0I7Q0FBSztBQUNqRTs7QUFHQSxPQUFPLGVBQWUsMEJBQTBDO0NBQzlELElBQUk7RUFDRixNQUFNLE1BQU0sTUFBTSxNQUFNLG9CQUFvQjtFQUM1QyxJQUFJLElBQUksSUFBSTtHQUNWLE1BQU0sT0FBTyxNQUFNLElBQUksS0FBSztHQUM1QixPQUFPLEtBQUssWUFBWSxDQUFDO0VBQzNCO0NBQ0YsUUFBUSxDQUFDOztDQUdULE1BQU0sWUFBWSx1QkFBdUI7Q0FDekMsTUFBTSxlQUFlLG9CQUFvQjtDQUN6QyxNQUFNLGlCQUFpQixzQkFBc0I7Q0FFN0MsT0FBTyxVQUFVLEtBQUksUUFBTztFQUMxQixXQUFXLFNBQVMsR0FBRztFQUN2QixVQUFVLEdBQUc7RUFDYixhQUFhLEdBQUc7RUFDaEIsTUFBTSxHQUFHO0VBQ1QsT0FBTyxHQUFHO0VBQ1YsWUFBWSxlQUFlLElBQUksV0FBVztFQUMxQyxVQUFVO0VBQ1YsWUFBWTtFQUNaLFlBQVk7RUFDWixhQUFhO0VBQ2IsV0FBVyxHQUFHLGFBQWEsSUFBSSxLQUFLLENBQUMsQ0FBQyxZQUFZO0VBQ2xELGVBQWUsSUFBSSxLQUFLLENBQUMsQ0FBQyxZQUFZO0VBQ3RDLG1CQUFtQixHQUFHLHFCQUFxQjtFQUMzQyxVQUFVO0VBQ1Ysc0JBQXNCO0VBQ3RCLFdBQVc7Q0FDYixFQUFFO0FBQ0o7O0FBR0EsT0FBTyxlQUFlLHdCQUF3QixVQUFrQixVQUFxQztDQUNuRyxJQUFJO0VBQ0YsTUFBTSxNQUFNLE1BQU0sTUFBTSx1QkFBdUI7R0FDN0MsUUFBUTtHQUNSLFNBQVMsRUFBRSxnQkFBZ0IsbUJBQW1CO0dBQzlDLE1BQU0sS0FBSyxVQUFVO0lBQUU7SUFBVTtHQUFTLENBQUM7RUFDN0MsQ0FBQztFQUNELE9BQU8sSUFBSTtDQUNiLFFBQVE7RUFDTixPQUFPO0NBQ1Q7QUFDRjs7QUFHQSxPQUFPLGVBQWUsNkJBQTZCLFVBQWtCLFNBQW1DO0NBQ3RHLElBQUk7RUFDRixNQUFNLE1BQU0sTUFBTSxNQUFNLHVCQUF1QjtHQUM3QyxRQUFRO0dBQ1IsU0FBUyxFQUFFLGdCQUFnQixtQkFBbUI7R0FDOUMsTUFBTSxLQUFLLFVBQVU7SUFBRTtJQUFVO0dBQVEsQ0FBQztFQUM1QyxDQUFDO0VBQ0QsT0FBTyxJQUFJO0NBQ2IsUUFBUTtFQUNOLE9BQU87Q0FDVDtBQUNGIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbImRldmljZVNlY3VyaXR5LnRzIl0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IE9wZXJhdG9yQWNjb3VudCwgVXNlckFjY291bnQgfSBmcm9tICcuLi90eXBlcyc7XG5cbmNvbnN0IFNUT1JBR0VfS0VZUyA9IHtcbiAgREVWSUNFX0lEOiAnbW9zX2hhcmR3YXJlX2RldmljZV9pZCcsXG4gIERFVklDRV9OQU1FOiAnbW9zX2hhcmR3YXJlX2RldmljZV9uYW1lJyxcbiAgT1BFUkFUT1JTOiAnbW9zX3JlZ2lzdGVyZWRfb3BlcmF0b3JzJyxcbiAgQVVESVRfTE9HUzogJ21vc19zZWN1cml0eV9hdWRpdF9sb2dzJ1xufTtcblxuZXhwb3J0IGludGVyZmFjZSBTZWN1cml0eUF1ZGl0TG9nIHtcbiAgaWQ6IHN0cmluZztcbiAgdGltZXN0YW1wOiBzdHJpbmc7XG4gIHVzZXJuYW1lOiBzdHJpbmc7XG4gIGFjdGlvbjogJ0xPR0lOX1NVQ0NFU1MnIHwgJ0xPR0lOX0ZBSUxFRCcgfCAnREVWSUNFX0JMT0NLRUQnIHwgJ0RFVklDRV9CT1VORCcgfCAnREVWSUNFX1JFU0VUJyB8ICdPUEVSQVRPUl9MT0NLRUQnO1xuICBkZXZpY2VJZDogc3RyaW5nO1xuICBkZXZpY2VOYW1lOiBzdHJpbmc7XG4gIGRldmljZVR5cGU6ICdwYycgfCAnbW9iaWxlJztcbiAgZGV0YWlsczogc3RyaW5nO1xufVxuXG4vLyBEZXRlY3QgaWYgY3VycmVudCBydW50aW1lIGlzIGEgbW9iaWxlIHBob25lIC8gdGFibGV0XG5leHBvcnQgZnVuY3Rpb24gaXNNb2JpbGVEZXZpY2UoKTogYm9vbGVhbiB7XG4gIGlmICh0eXBlb2YgbmF2aWdhdG9yID09PSAndW5kZWZpbmVkJykgcmV0dXJuIGZhbHNlO1xuICByZXR1cm4gL0FuZHJvaWR8d2ViT1N8aVBob25lfGlQYWR8aVBvZHxCbGFja0JlcnJ5fElFTW9iaWxlfE9wZXJhIE1pbmkvaS50ZXN0KG5hdmlnYXRvci51c2VyQWdlbnQpO1xufVxuXG4vLyBQZXJzaXN0ZW50IGhhcmR3YXJlIGRldmljZSBJRCAoR2VuZXJhdGVkIG9uY2UgcGVyIG1hY2hpbmUvYnJvd3NlcilcbmV4cG9ydCBmdW5jdGlvbiBnZXRIYXJkd2FyZURldmljZUlkKCk6IHN0cmluZyB7XG4gIHRyeSB7XG4gICAgbGV0IGRldmljZUlkID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oU1RPUkFHRV9LRVlTLkRFVklDRV9JRCk7XG4gICAgaWYgKCFkZXZpY2VJZCkge1xuICAgICAgY29uc3QgcmFuZFN0ciA9IE1hdGgucmFuZG9tKCkudG9TdHJpbmcoMzYpLnN1YnN0cmluZygyLCA2KS50b1VwcGVyQ2FzZSgpICsgJy0nICsgTWF0aC5yYW5kb20oKS50b1N0cmluZygzNikuc3Vic3RyaW5nKDIsIDYpLnRvVXBwZXJDYXNlKCk7XG4gICAgICBjb25zdCBtb2JpbGUgPSBpc01vYmlsZURldmljZSgpO1xuICAgICAgZGV2aWNlSWQgPSBgREVWLU1PUy0ke21vYmlsZSA/ICdNT0InIDogJ1BDJ30tJHtyYW5kU3RyfWA7XG4gICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShTVE9SQUdFX0tFWVMuREVWSUNFX0lELCBkZXZpY2VJZCk7XG4gICAgfVxuICAgIHJldHVybiBkZXZpY2VJZDtcbiAgfSBjYXRjaCB7XG4gICAgcmV0dXJuICdERVYtTU9TLURFRkFVTFQtMDAxJztcbiAgfVxufVxuXG4vLyBGcmllbmRseSBkZXZpY2UgbmFtZSBiYXNlZCBvbiBwbGF0Zm9ybS9icm93c2VyXG5leHBvcnQgZnVuY3Rpb24gZ2V0SGFyZHdhcmVEZXZpY2VOYW1lKCk6IHN0cmluZyB7XG4gIHRyeSB7XG4gICAgbGV0IG5hbWUgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShTVE9SQUdFX0tFWVMuREVWSUNFX05BTUUpO1xuICAgIGlmICghbmFtZSkge1xuICAgICAgY29uc3QgdWEgPSBuYXZpZ2F0b3IudXNlckFnZW50O1xuICAgICAgbGV0IG9zID0gJ1dpbmRvd3MgUEMnO1xuICAgICAgaWYgKC9BbmRyb2lkL2kudGVzdCh1YSkpIG9zID0gJ0FuZHJvaWQgTW9iaWxlJztcbiAgICAgIGVsc2UgaWYgKC9pUGhvbmUvaS50ZXN0KHVhKSkgb3MgPSAnaVBob25lJztcbiAgICAgIGVsc2UgaWYgKC9pUGFkL2kudGVzdCh1YSkpIG9zID0gJ2lQYWQnO1xuICAgICAgZWxzZSBpZiAoL01hYy9pLnRlc3QodWEpKSBvcyA9ICdNYWMgV29ya3N0YXRpb24nO1xuICAgICAgZWxzZSBpZiAoL0xpbnV4L2kudGVzdCh1YSkpIG9zID0gJ0xpbnV4IFdvcmtzdGF0aW9uJztcblxuICAgICAgbGV0IGJyb3dzZXIgPSAnQ2hyb21lJztcbiAgICAgIGlmICgvRmlyZWZveC9pLnRlc3QodWEpKSBicm93c2VyID0gJ0ZpcmVmb3gnO1xuICAgICAgZWxzZSBpZiAoL0VkZy9pLnRlc3QodWEpKSBicm93c2VyID0gJ0VkZ2UnO1xuICAgICAgZWxzZSBpZiAoL1NhZmFyaS9pLnRlc3QodWEpICYmICEvQ2hyb21lL2kudGVzdCh1YSkpIGJyb3dzZXIgPSAnU2FmYXJpJztcblxuICAgICAgbmFtZSA9IGAke29zfSDigKIgJHticm93c2VyfWA7XG4gICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShTVE9SQUdFX0tFWVMuREVWSUNFX05BTUUsIG5hbWUpO1xuICAgIH1cbiAgICByZXR1cm4gbmFtZTtcbiAgfSBjYXRjaCB7XG4gICAgcmV0dXJuIGlzTW9iaWxlRGV2aWNlKCkgPyAnQXV0aG9yaXplZCBNb2JpbGUnIDogJ0F1dGhvcml6ZWQgV29ya3N0YXRpb24nO1xuICB9XG59XG5cbi8vIERlZmF1bHQgcHJlLWNvbmZpZ3VyZWQgb3BlcmF0b3JzIChEdWFsIERldmljZTogMSBQQyArIDEgTW9iaWxlKVxuY29uc3QgREVGQVVMVF9PUEVSQVRPUlM6IE9wZXJhdG9yQWNjb3VudFtdID0gW1xuICB7XG4gICAgaWQ6ICdvcC1hZG1pbicsXG4gICAgdXNlcm5hbWU6ICdhZG1pbicsXG4gICAgcGFzc3dvcmQ6ICdtdXphbW1pbDc4NicsXG4gICAgZGlzcGxheU5hbWU6ICdJbXJhbiBLaGFuIChNYXN0ZXIgQWRtaW4pJyxcbiAgICByb2xlOiAnYWRtaW4nLFxuICAgIHBob25lOiAnOTU2MTQ2MDMxMycsXG4gICAgYm91bmRQY0RldmljZUlkOiBudWxsLFxuICAgIGJvdW5kUGNEZXZpY2VOYW1lOiBudWxsLFxuICAgIGJvdW5kUGNBdDogbnVsbCxcbiAgICBib3VuZE1vYmlsZURldmljZUlkOiBudWxsLFxuICAgIGJvdW5kTW9iaWxlRGV2aWNlTmFtZTogbnVsbCxcbiAgICBib3VuZE1vYmlsZUF0OiBudWxsLFxuICAgIGxhc3RMb2dpbjogbnVsbCxcbiAgICBpc0xvY2tlZDogZmFsc2VcbiAgfSxcbiAge1xuICAgIGlkOiAnb3AtMScsXG4gICAgdXNlcm5hbWU6ICdvcGVyYXRvcjEnLFxuICAgIHBhc3N3b3JkOiAnc2FtZWVyMTIzJyxcbiAgICBkaXNwbGF5TmFtZTogJ1NoYWlraCBTYW1lZXInLFxuICAgIHJvbGU6ICdvcGVyYXRvcicsXG4gICAgcGhvbmU6ICc5ODc2NTQzMjEwJyxcbiAgICBib3VuZFBjRGV2aWNlSWQ6IG51bGwsXG4gICAgYm91bmRQY0RldmljZU5hbWU6IG51bGwsXG4gICAgYm91bmRQY0F0OiBudWxsLFxuICAgIGJvdW5kTW9iaWxlRGV2aWNlSWQ6IG51bGwsXG4gICAgYm91bmRNb2JpbGVEZXZpY2VOYW1lOiBudWxsLFxuICAgIGJvdW5kTW9iaWxlQXQ6IG51bGwsXG4gICAgbGFzdExvZ2luOiBudWxsLFxuICAgIGlzTG9ja2VkOiBmYWxzZVxuICB9LFxuICB7XG4gICAgaWQ6ICdvcC0yJyxcbiAgICB1c2VybmFtZTogJ29wZXJhdG9yMicsXG4gICAgcGFzc3dvcmQ6ICdhZGlsMTIzJyxcbiAgICBkaXNwbGF5TmFtZTogJ0FkaWwgS2hhbicsXG4gICAgcm9sZTogJ29wZXJhdG9yJyxcbiAgICBwaG9uZTogJzkxMjM0NTY3ODAnLFxuICAgIGJvdW5kUGNEZXZpY2VJZDogbnVsbCxcbiAgICBib3VuZFBjRGV2aWNlTmFtZTogbnVsbCxcbiAgICBib3VuZFBjQXQ6IG51bGwsXG4gICAgYm91bmRNb2JpbGVEZXZpY2VJZDogbnVsbCxcbiAgICBib3VuZE1vYmlsZURldmljZU5hbWU6IG51bGwsXG4gICAgYm91bmRNb2JpbGVBdDogbnVsbCxcbiAgICBsYXN0TG9naW46IG51bGwsXG4gICAgaXNMb2NrZWQ6IGZhbHNlXG4gIH1cbl07XG5cbi8vIExvYWQgcmVnaXN0ZXJlZCBvcGVyYXRvcnNcbmV4cG9ydCBmdW5jdGlvbiBnZXRSZWdpc3RlcmVkT3BlcmF0b3JzKCk6IE9wZXJhdG9yQWNjb3VudFtdIHtcbiAgdHJ5IHtcbiAgICBjb25zdCByYXcgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShTVE9SQUdFX0tFWVMuT1BFUkFUT1JTKTtcbiAgICBpZiAoIXJhdykge1xuICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oU1RPUkFHRV9LRVlTLk9QRVJBVE9SUywgSlNPTi5zdHJpbmdpZnkoREVGQVVMVF9PUEVSQVRPUlMpKTtcbiAgICAgIHJldHVybiBERUZBVUxUX09QRVJBVE9SUztcbiAgICB9XG4gICAgY29uc3QgcGFyc2VkID0gSlNPTi5wYXJzZShyYXcpO1xuICAgIC8vIEVuc3VyZSBkdWFsIGRldmljZSBmaWVsZHMgYXJlIHByZXNlbnQgaWYgbG9hZGVkIGZyb20gbGVnYWN5IGZvcm1hdFxuICAgIHJldHVybiBwYXJzZWQubWFwKChvcDogYW55KSA9PiAoe1xuICAgICAgLi4ub3AsXG4gICAgICBib3VuZFBjRGV2aWNlSWQ6IG9wLmJvdW5kUGNEZXZpY2VJZCA/PyAob3AuYm91bmREZXZpY2VJZD8uaW5jbHVkZXMoJy1QQy0nKSA/IG9wLmJvdW5kRGV2aWNlSWQgOiBudWxsKSxcbiAgICAgIGJvdW5kUGNEZXZpY2VOYW1lOiBvcC5ib3VuZFBjRGV2aWNlTmFtZSA/PyAob3AuYm91bmREZXZpY2VJZD8uaW5jbHVkZXMoJy1QQy0nKSA/IG9wLmJvdW5kRGV2aWNlTmFtZSA6IG51bGwpLFxuICAgICAgYm91bmRQY0F0OiBvcC5ib3VuZFBjQXQgPz8gKG9wLmJvdW5kRGV2aWNlSWQ/LmluY2x1ZGVzKCctUEMtJykgPyBvcC5ib3VuZEF0IDogbnVsbCksXG4gICAgICBib3VuZE1vYmlsZURldmljZUlkOiBvcC5ib3VuZE1vYmlsZURldmljZUlkID8/IChvcC5ib3VuZERldmljZUlkPy5pbmNsdWRlcygnLU1PQi0nKSA/IG9wLmJvdW5kRGV2aWNlSWQgOiBudWxsKSxcbiAgICAgIGJvdW5kTW9iaWxlRGV2aWNlTmFtZTogb3AuYm91bmRNb2JpbGVEZXZpY2VOYW1lID8/IChvcC5ib3VuZERldmljZUlkPy5pbmNsdWRlcygnLU1PQi0nKSA/IG9wLmJvdW5kRGV2aWNlTmFtZSA6IG51bGwpLFxuICAgICAgYm91bmRNb2JpbGVBdDogb3AuYm91bmRNb2JpbGVBdCA/PyAob3AuYm91bmREZXZpY2VJZD8uaW5jbHVkZXMoJy1NT0ItJykgPyBvcC5ib3VuZEF0IDogbnVsbCksXG4gICAgfSkpO1xuICB9IGNhdGNoIHtcbiAgICByZXR1cm4gREVGQVVMVF9PUEVSQVRPUlM7XG4gIH1cbn1cblxuLy8gU2F2ZSBvcGVyYXRvcnNcbmV4cG9ydCBmdW5jdGlvbiBzYXZlUmVnaXN0ZXJlZE9wZXJhdG9ycyhvcGVyYXRvcnM6IE9wZXJhdG9yQWNjb3VudFtdKTogdm9pZCB7XG4gIHRyeSB7XG4gICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oU1RPUkFHRV9LRVlTLk9QRVJBVE9SUywgSlNPTi5zdHJpbmdpZnkob3BlcmF0b3JzKSk7XG4gIH0gY2F0Y2ggKGUpIHtcbiAgICBjb25zb2xlLmVycm9yKCdGYWlsZWQgdG8gc2F2ZSBvcGVyYXRvcnMnLCBlKTtcbiAgfVxufVxuXG4vLyBBZGQgc2VjdXJpdHkgYXVkaXQgbG9nXG5leHBvcnQgZnVuY3Rpb24gYWRkU2VjdXJpdHlBdWRpdExvZyhcbiAgYWN0aW9uOiBTZWN1cml0eUF1ZGl0TG9nWydhY3Rpb24nXSxcbiAgdXNlcm5hbWU6IHN0cmluZyxcbiAgZGV0YWlsczogc3RyaW5nXG4pOiB2b2lkIHtcbiAgdHJ5IHtcbiAgICBjb25zdCBkZXZpY2VJZCA9IGdldEhhcmR3YXJlRGV2aWNlSWQoKTtcbiAgICBjb25zdCBkZXZpY2VOYW1lID0gZ2V0SGFyZHdhcmVEZXZpY2VOYW1lKCk7XG4gICAgY29uc3QgZGV2aWNlVHlwZTogJ3BjJyB8ICdtb2JpbGUnID0gaXNNb2JpbGVEZXZpY2UoKSA/ICdtb2JpbGUnIDogJ3BjJztcblxuICAgIGNvbnN0IHJhdyA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFNUT1JBR0VfS0VZUy5BVURJVF9MT0dTKTtcbiAgICBjb25zdCBsb2dzOiBTZWN1cml0eUF1ZGl0TG9nW10gPSByYXcgPyBKU09OLnBhcnNlKHJhdykgOiBbXTtcblxuICAgIGNvbnN0IG5ld0xvZzogU2VjdXJpdHlBdWRpdExvZyA9IHtcbiAgICAgIGlkOiBgbG9nLSR7RGF0ZS5ub3coKX0tJHtNYXRoLnJhbmRvbSgpLnRvU3RyaW5nKDM2KS5zdWJzdHIoMiwgNCl9YCxcbiAgICAgIHRpbWVzdGFtcDogbmV3IERhdGUoKS50b0xvY2FsZVN0cmluZygnZW4tSU4nLCB7XG4gICAgICAgIGRheTogJzItZGlnaXQnLFxuICAgICAgICBtb250aDogJ3Nob3J0JyxcbiAgICAgICAgeWVhcjogJ251bWVyaWMnLFxuICAgICAgICBob3VyOiAnMi1kaWdpdCcsXG4gICAgICAgIG1pbnV0ZTogJzItZGlnaXQnLFxuICAgICAgICBzZWNvbmQ6ICcyLWRpZ2l0J1xuICAgICAgfSksXG4gICAgICB1c2VybmFtZSxcbiAgICAgIGFjdGlvbixcbiAgICAgIGRldmljZUlkLFxuICAgICAgZGV2aWNlTmFtZSxcbiAgICAgIGRldmljZVR5cGUsXG4gICAgICBkZXRhaWxzXG4gICAgfTtcblxuICAgIGxvZ3MudW5zaGlmdChuZXdMb2cpO1xuICAgIGlmIChsb2dzLmxlbmd0aCA+IDYwKSBsb2dzLnBvcCgpO1xuICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKFNUT1JBR0VfS0VZUy5BVURJVF9MT0dTLCBKU09OLnN0cmluZ2lmeShsb2dzKSk7XG4gIH0gY2F0Y2ggKGUpIHtcbiAgICBjb25zb2xlLmVycm9yKCdGYWlsZWQgdG8gcmVjb3JkIGF1ZGl0IGxvZycsIGUpO1xuICB9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBnZXRTZWN1cml0eUF1ZGl0TG9ncygpOiBTZWN1cml0eUF1ZGl0TG9nW10ge1xuICB0cnkge1xuICAgIGNvbnN0IHJhdyA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFNUT1JBR0VfS0VZUy5BVURJVF9MT0dTKTtcbiAgICByZXR1cm4gcmF3ID8gSlNPTi5wYXJzZShyYXcpIDogW107XG4gIH0gY2F0Y2gge1xuICAgIHJldHVybiBbXTtcbiAgfVxufVxuXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4vLyBEVUFMLURFVklDRSBBVVRIRU5USUNBVElPTiAoMSBJRCA9IDEgQXV0aG9yaXplZCBQQyArIDEgQXV0aG9yaXplZCBNb2JpbGUpXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5leHBvcnQgaW50ZXJmYWNlIEF1dGhSZXN1bHQge1xuICBzdWNjZXNzOiBib29sZWFuO1xuICB1c2VyPzogVXNlckFjY291bnQ7XG4gIGVycm9yPzogc3RyaW5nO1xuICBkZXZpY2VMb2NrZWRUb090aGVyPzogYm9vbGVhbjtcbiAgZGV2aWNlVHlwZT86ICdwYycgfCAnbW9iaWxlJztcbiAgYm91bmREZXZpY2VOYW1lPzogc3RyaW5nO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gYXV0aGVudGljYXRlT3BlcmF0b3IodXNlcm5hbWVJbnB1dDogc3RyaW5nLCBwYXNzd29yZElucHV0OiBzdHJpbmcpOiBBdXRoUmVzdWx0IHtcbiAgY29uc3QgdXNlcm5hbWUgPSB1c2VybmFtZUlucHV0LnRyaW0oKS50b0xvd2VyQ2FzZSgpO1xuICBjb25zdCBwYXNzd29yZCA9IHBhc3N3b3JkSW5wdXQudHJpbSgpO1xuICBjb25zdCBjdXJyZW50RGV2aWNlSWQgPSBnZXRIYXJkd2FyZURldmljZUlkKCk7XG4gIGNvbnN0IGN1cnJlbnREZXZpY2VOYW1lID0gZ2V0SGFyZHdhcmVEZXZpY2VOYW1lKCk7XG4gIGNvbnN0IGN1cnJlbnRUeXBlOiAncGMnIHwgJ21vYmlsZScgPSBpc01vYmlsZURldmljZSgpID8gJ21vYmlsZScgOiAncGMnO1xuXG4gIGNvbnN0IG9wZXJhdG9ycyA9IGdldFJlZ2lzdGVyZWRPcGVyYXRvcnMoKTtcbiAgY29uc3Qgb3BlcmF0b3IgPSBvcGVyYXRvcnMuZmluZChvID0+IG8udXNlcm5hbWUudG9Mb3dlckNhc2UoKSA9PT0gdXNlcm5hbWUpO1xuXG4gIGlmICghb3BlcmF0b3IpIHtcbiAgICBhZGRTZWN1cml0eUF1ZGl0TG9nKCdMT0dJTl9GQUlMRUQnLCB1c2VybmFtZSwgJ0ludmFsaWQgb3BlcmF0b3IgdXNlcm5hbWUnKTtcbiAgICByZXR1cm4ge1xuICAgICAgc3VjY2VzczogZmFsc2UsXG4gICAgICBlcnJvcjogJ0ludmFsaWQgT3BlcmF0b3IgSUQuIFBsZWFzZSB2ZXJpZnkgeW91ciB1c2VybmFtZS4nXG4gICAgfTtcbiAgfVxuXG4gIC8vIENoZWNrIHBhc3N3b3JkXG4gIGlmIChvcGVyYXRvci5wYXNzd29yZCAmJiBvcGVyYXRvci5wYXNzd29yZCAhPT0gcGFzc3dvcmQpIHtcbiAgICBhZGRTZWN1cml0eUF1ZGl0TG9nKCdMT0dJTl9GQUlMRUQnLCB1c2VybmFtZSwgJ0luY29ycmVjdCBwYXNzd29yZCBlbnRlcmVkJyk7XG4gICAgcmV0dXJuIHtcbiAgICAgIHN1Y2Nlc3M6IGZhbHNlLFxuICAgICAgZXJyb3I6ICdJbmNvcnJlY3QgUGFzc3dvcmQuIFBsZWFzZSB0cnkgYWdhaW4uJ1xuICAgIH07XG4gIH1cblxuICAvLyBDaGVjayBpZiBhY2NvdW50IGlzIHN1c3BlbmRlZCAvIGxvY2tlZFxuICBpZiAob3BlcmF0b3IuaXNMb2NrZWQpIHtcbiAgICBhZGRTZWN1cml0eUF1ZGl0TG9nKCdPUEVSQVRPUl9MT0NLRUQnLCB1c2VybmFtZSwgJ0F0dGVtcHQgdG8gbG9naW4gdG8gc3VzcGVuZGVkIGFjY291bnQnKTtcbiAgICByZXR1cm4ge1xuICAgICAgc3VjY2VzczogZmFsc2UsXG4gICAgICBlcnJvcjogJ+KblCBBQ0NPVU5UIFNVU1BFTkRFRDogVGhpcyBvcGVyYXRvciBJRCBoYXMgYmVlbiBsb2NrZWQgYnkgTWFzdGVyIEFkbWluLiBQbGVhc2UgY29udGFjdCBzaG9wIG93bmVyLidcbiAgICB9O1xuICB9XG5cbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvLyBEVUFMLURFVklDRSBFTkZPUkNFTUVOVDogUEMgU0xPVCB2cyBNT0JJTEUgU0xPVFxuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIGNvbnN0IG5vdyA9IG5ldyBEYXRlKCkudG9Mb2NhbGVTdHJpbmcoJ2VuLUlOJyk7XG5cbiAgaWYgKGN1cnJlbnRUeXBlID09PSAncGMnKSB7XG4gICAgLy8gTG9nZ2luZyBpbiBmcm9tIFBDXG4gICAgaWYgKCFvcGVyYXRvci5ib3VuZFBjRGV2aWNlSWQpIHtcbiAgICAgIC8vIEZpcnN0IFBDIGxvZ2luOiBCaW5kIHRoaXMgUEMhXG4gICAgICBvcGVyYXRvci5ib3VuZFBjRGV2aWNlSWQgPSBjdXJyZW50RGV2aWNlSWQ7XG4gICAgICBvcGVyYXRvci5ib3VuZFBjRGV2aWNlTmFtZSA9IGN1cnJlbnREZXZpY2VOYW1lO1xuICAgICAgb3BlcmF0b3IuYm91bmRQY0F0ID0gbm93O1xuICAgICAgb3BlcmF0b3IubGFzdExvZ2luID0gbm93O1xuICAgICAgc2F2ZVJlZ2lzdGVyZWRPcGVyYXRvcnMob3BlcmF0b3JzKTtcbiAgICAgIGFkZFNlY3VyaXR5QXVkaXRMb2coJ0RFVklDRV9CT1VORCcsIHVzZXJuYW1lLCBgUEMgYm91bmQ6ICR7Y3VycmVudERldmljZU5hbWV9ICgke2N1cnJlbnREZXZpY2VJZH0pYCk7XG4gICAgfSBlbHNlIGlmIChvcGVyYXRvci5ib3VuZFBjRGV2aWNlSWQgIT09IGN1cnJlbnREZXZpY2VJZCkge1xuICAgICAgLy8gRGlmZmVyZW50IFBDIHRyaWVkIHRvIGFjY2VzcyFcbiAgICAgIGFkZFNlY3VyaXR5QXVkaXRMb2coXG4gICAgICAgICdERVZJQ0VfQkxPQ0tFRCcsXG4gICAgICAgIHVzZXJuYW1lLFxuICAgICAgICBgVW5hdXRob3JpemVkIFBDIGxvZ2luIGF0dGVtcHQuIElEIGlzIGFscmVhZHkgYm91bmQgdG8gUEMgKCR7b3BlcmF0b3IuYm91bmRQY0RldmljZU5hbWV9IC8gJHtvcGVyYXRvci5ib3VuZFBjRGV2aWNlSWR9KWBcbiAgICAgICk7XG5cbiAgICAgIHJldHVybiB7XG4gICAgICAgIHN1Y2Nlc3M6IGZhbHNlLFxuICAgICAgICBkZXZpY2VMb2NrZWRUb090aGVyOiB0cnVlLFxuICAgICAgICBkZXZpY2VUeXBlOiAncGMnLFxuICAgICAgICBib3VuZERldmljZU5hbWU6IG9wZXJhdG9yLmJvdW5kUGNEZXZpY2VOYW1lIHx8IG9wZXJhdG9yLmJvdW5kUGNEZXZpY2VJZCxcbiAgICAgICAgZXJyb3I6IGDwn5qoIFBDIERFVklDRSBNSVNNQVRDSDpcXG5UaGlzIE9wZXJhdG9yIElEIGlzIGFscmVhZHkgcGFpcmVkIHdpdGggeW91ciBzaG9wIFBDICgke29wZXJhdG9yLmJvdW5kUGNEZXZpY2VOYW1lIHx8IG9wZXJhdG9yLmJvdW5kUGNEZXZpY2VJZH0pLlxcblxcbjEgSUQgaXMgcGVybWl0dGVkIG9uIDEgUEMgKyAxIE1vYmlsZSBvbmx5LiBUbyB1c2Ugb24gdGhpcyBuZXcgY29tcHV0ZXIsIGFzayBNYXN0ZXIgQWRtaW4gdG8gcmVzZXQgeW91ciBQQyBiaW5kaW5nLmBcbiAgICAgIH07XG4gICAgfSBlbHNlIHtcbiAgICAgIC8vIEF1dGhvcml6ZWQgUEMgbWF0Y2ghXG4gICAgICBvcGVyYXRvci5sYXN0TG9naW4gPSBub3c7XG4gICAgICBzYXZlUmVnaXN0ZXJlZE9wZXJhdG9ycyhvcGVyYXRvcnMpO1xuICAgICAgYWRkU2VjdXJpdHlBdWRpdExvZygnTE9HSU5fU1VDQ0VTUycsIHVzZXJuYW1lLCBgU3VjY2Vzc2Z1bCBsb2dpbiBvbiBhdXRob3JpemVkIFBDICgke2N1cnJlbnREZXZpY2VJZH0pYCk7XG4gICAgfVxuICB9IGVsc2Uge1xuICAgIC8vIExvZ2dpbmcgaW4gZnJvbSBNb2JpbGUgUGhvbmUgLyBUYWJsZXRcbiAgICBpZiAoIW9wZXJhdG9yLmJvdW5kTW9iaWxlRGV2aWNlSWQpIHtcbiAgICAgIC8vIEZpcnN0IE1vYmlsZSBsb2dpbjogQmluZCB0aGlzIE1vYmlsZSFcbiAgICAgIG9wZXJhdG9yLmJvdW5kTW9iaWxlRGV2aWNlSWQgPSBjdXJyZW50RGV2aWNlSWQ7XG4gICAgICBvcGVyYXRvci5ib3VuZE1vYmlsZURldmljZU5hbWUgPSBjdXJyZW50RGV2aWNlTmFtZTtcbiAgICAgIG9wZXJhdG9yLmJvdW5kTW9iaWxlQXQgPSBub3c7XG4gICAgICBvcGVyYXRvci5sYXN0TG9naW4gPSBub3c7XG4gICAgICBzYXZlUmVnaXN0ZXJlZE9wZXJhdG9ycyhvcGVyYXRvcnMpO1xuICAgICAgYWRkU2VjdXJpdHlBdWRpdExvZygnREVWSUNFX0JPVU5EJywgdXNlcm5hbWUsIGBNb2JpbGUgYm91bmQ6ICR7Y3VycmVudERldmljZU5hbWV9ICgke2N1cnJlbnREZXZpY2VJZH0pYCk7XG4gICAgfSBlbHNlIGlmIChvcGVyYXRvci5ib3VuZE1vYmlsZURldmljZUlkICE9PSBjdXJyZW50RGV2aWNlSWQpIHtcbiAgICAgIC8vIERpZmZlcmVudCBNb2JpbGUgdHJpZWQgdG8gYWNjZXNzIVxuICAgICAgYWRkU2VjdXJpdHlBdWRpdExvZyhcbiAgICAgICAgJ0RFVklDRV9CTE9DS0VEJyxcbiAgICAgICAgdXNlcm5hbWUsXG4gICAgICAgIGBVbmF1dGhvcml6ZWQgTW9iaWxlIGxvZ2luIGF0dGVtcHQuIElEIGlzIGFscmVhZHkgYm91bmQgdG8gTW9iaWxlICgke29wZXJhdG9yLmJvdW5kTW9iaWxlRGV2aWNlTmFtZX0gLyAke29wZXJhdG9yLmJvdW5kTW9iaWxlRGV2aWNlSWR9KWBcbiAgICAgICk7XG5cbiAgICAgIHJldHVybiB7XG4gICAgICAgIHN1Y2Nlc3M6IGZhbHNlLFxuICAgICAgICBkZXZpY2VMb2NrZWRUb090aGVyOiB0cnVlLFxuICAgICAgICBkZXZpY2VUeXBlOiAnbW9iaWxlJyxcbiAgICAgICAgYm91bmREZXZpY2VOYW1lOiBvcGVyYXRvci5ib3VuZE1vYmlsZURldmljZU5hbWUgfHwgb3BlcmF0b3IuYm91bmRNb2JpbGVEZXZpY2VJZCxcbiAgICAgICAgZXJyb3I6IGDwn5qoIE1PQklMRSBERVZJQ0UgTUlTTUFUQ0g6XFxuVGhpcyBPcGVyYXRvciBJRCBpcyBhbHJlYWR5IHBhaXJlZCB3aXRoIHlvdXIgcmVnaXN0ZXJlZCBNb2JpbGUgKCR7b3BlcmF0b3IuYm91bmRNb2JpbGVEZXZpY2VOYW1lIHx8IG9wZXJhdG9yLmJvdW5kTW9iaWxlRGV2aWNlSWR9KS5cXG5cXG4xIElEIGlzIHBlcm1pdHRlZCBvbiAxIFBDICsgMSBNb2JpbGUgb25seS4gVG8gdXNlIG9uIHRoaXMgbmV3IHBob25lLCBhc2sgTWFzdGVyIEFkbWluIHRvIHJlc2V0IHlvdXIgTW9iaWxlIGJpbmRpbmcuYFxuICAgICAgfTtcbiAgICB9IGVsc2Uge1xuICAgICAgLy8gQXV0aG9yaXplZCBNb2JpbGUgbWF0Y2ghXG4gICAgICBvcGVyYXRvci5sYXN0TG9naW4gPSBub3c7XG4gICAgICBzYXZlUmVnaXN0ZXJlZE9wZXJhdG9ycyhvcGVyYXRvcnMpO1xuICAgICAgYWRkU2VjdXJpdHlBdWRpdExvZygnTE9HSU5fU1VDQ0VTUycsIHVzZXJuYW1lLCBgU3VjY2Vzc2Z1bCBsb2dpbiBvbiBhdXRob3JpemVkIE1vYmlsZSAoJHtjdXJyZW50RGV2aWNlSWR9KWApO1xuICAgIH1cbiAgfVxuXG4gIGNvbnN0IGFjdGl2ZVVzZXI6IFVzZXJBY2NvdW50ID0ge1xuICAgIHVzZXJuYW1lOiBvcGVyYXRvci51c2VybmFtZSxcbiAgICBkaXNwbGF5TmFtZTogb3BlcmF0b3IuZGlzcGxheU5hbWUsXG4gICAgcm9sZTogb3BlcmF0b3Iucm9sZSxcbiAgICBwaG9uZTogb3BlcmF0b3IucGhvbmUsXG4gICAgc2hvcE5hbWU6ICdNdXphbW1pbCBPbmxpbmUgU2VydmljZScsXG4gICAgaXNMb2dnZWRJbjogdHJ1ZSxcbiAgICBjdXJyZW50RGV2aWNlVHlwZTogY3VycmVudFR5cGUsXG4gICAgY3VycmVudERldmljZUlkLFxuICAgIGN1cnJlbnREZXZpY2VOYW1lLFxuICAgIGJvdW5kUGNEZXZpY2VJZDogb3BlcmF0b3IuYm91bmRQY0RldmljZUlkIHx8IHVuZGVmaW5lZCxcbiAgICBib3VuZE1vYmlsZURldmljZUlkOiBvcGVyYXRvci5ib3VuZE1vYmlsZURldmljZUlkIHx8IHVuZGVmaW5lZFxuICB9O1xuXG4gIHJldHVybiB7XG4gICAgc3VjY2VzczogdHJ1ZSxcbiAgICB1c2VyOiBhY3RpdmVVc2VyXG4gIH07XG59XG5cbi8vIE1hc3RlciBBZG1pbjogUmVzZXQgUEMgRGV2aWNlIEJpbmRpbmdcbmV4cG9ydCBmdW5jdGlvbiByZXNldE9wZXJhdG9yUGNCaW5kaW5nKG9wZXJhdG9ySWQ6IHN0cmluZyk6IGJvb2xlYW4ge1xuICBjb25zdCBvcGVyYXRvcnMgPSBnZXRSZWdpc3RlcmVkT3BlcmF0b3JzKCk7XG4gIGNvbnN0IG9wID0gb3BlcmF0b3JzLmZpbmQobyA9PiBvLmlkID09PSBvcGVyYXRvcklkIHx8IG8udXNlcm5hbWUgPT09IG9wZXJhdG9ySWQpO1xuICBpZiAoIW9wKSByZXR1cm4gZmFsc2U7XG5cbiAgY29uc3QgcHJldiA9IG9wLmJvdW5kUGNEZXZpY2VOYW1lIHx8IG9wLmJvdW5kUGNEZXZpY2VJZCB8fCAnUEMnO1xuICBvcC5ib3VuZFBjRGV2aWNlSWQgPSBudWxsO1xuICBvcC5ib3VuZFBjRGV2aWNlTmFtZSA9IG51bGw7XG4gIG9wLmJvdW5kUGNBdCA9IG51bGw7XG5cbiAgc2F2ZVJlZ2lzdGVyZWRPcGVyYXRvcnMob3BlcmF0b3JzKTtcbiAgYWRkU2VjdXJpdHlBdWRpdExvZygnREVWSUNFX1JFU0VUJywgb3AudXNlcm5hbWUsIGBNYXN0ZXIgQWRtaW4gY2xlYXJlZCBQQyBkZXZpY2UgYmluZGluZyAod2FzOiAke3ByZXZ9KWApO1xuICByZXR1cm4gdHJ1ZTtcbn1cblxuLy8gTWFzdGVyIEFkbWluOiBSZXNldCBNb2JpbGUgRGV2aWNlIEJpbmRpbmdcbmV4cG9ydCBmdW5jdGlvbiByZXNldE9wZXJhdG9yTW9iaWxlQmluZGluZyhvcGVyYXRvcklkOiBzdHJpbmcpOiBib29sZWFuIHtcbiAgY29uc3Qgb3BlcmF0b3JzID0gZ2V0UmVnaXN0ZXJlZE9wZXJhdG9ycygpO1xuICBjb25zdCBvcCA9IG9wZXJhdG9ycy5maW5kKG8gPT4gby5pZCA9PT0gb3BlcmF0b3JJZCB8fCBvLnVzZXJuYW1lID09PSBvcGVyYXRvcklkKTtcbiAgaWYgKCFvcCkgcmV0dXJuIGZhbHNlO1xuXG4gIGNvbnN0IHByZXYgPSBvcC5ib3VuZE1vYmlsZURldmljZU5hbWUgfHwgb3AuYm91bmRNb2JpbGVEZXZpY2VJZCB8fCAnTW9iaWxlJztcbiAgb3AuYm91bmRNb2JpbGVEZXZpY2VJZCA9IG51bGw7XG4gIG9wLmJvdW5kTW9iaWxlRGV2aWNlTmFtZSA9IG51bGw7XG4gIG9wLmJvdW5kTW9iaWxlQXQgPSBudWxsO1xuXG4gIHNhdmVSZWdpc3RlcmVkT3BlcmF0b3JzKG9wZXJhdG9ycyk7XG4gIGFkZFNlY3VyaXR5QXVkaXRMb2coJ0RFVklDRV9SRVNFVCcsIG9wLnVzZXJuYW1lLCBgTWFzdGVyIEFkbWluIGNsZWFyZWQgTW9iaWxlIGRldmljZSBiaW5kaW5nICh3YXM6ICR7cHJldn0pYCk7XG4gIHJldHVybiB0cnVlO1xufVxuXG4vLyBNYXN0ZXIgQWRtaW46IFJlc2V0IEJvdGggRGV2aWNlIEJpbmRpbmdzIChGdWxsIFJlc2V0KVxuZXhwb3J0IGZ1bmN0aW9uIHJlc2V0T3BlcmF0b3JBbGxCaW5kaW5ncyhvcGVyYXRvcklkOiBzdHJpbmcpOiBib29sZWFuIHtcbiAgY29uc3Qgb3BlcmF0b3JzID0gZ2V0UmVnaXN0ZXJlZE9wZXJhdG9ycygpO1xuICBjb25zdCBvcCA9IG9wZXJhdG9ycy5maW5kKG8gPT4gby5pZCA9PT0gb3BlcmF0b3JJZCB8fCBvLnVzZXJuYW1lID09PSBvcGVyYXRvcklkKTtcbiAgaWYgKCFvcCkgcmV0dXJuIGZhbHNlO1xuXG4gIG9wLmJvdW5kUGNEZXZpY2VJZCA9IG51bGw7XG4gIG9wLmJvdW5kUGNEZXZpY2VOYW1lID0gbnVsbDtcbiAgb3AuYm91bmRQY0F0ID0gbnVsbDtcbiAgb3AuYm91bmRNb2JpbGVEZXZpY2VJZCA9IG51bGw7XG4gIG9wLmJvdW5kTW9iaWxlRGV2aWNlTmFtZSA9IG51bGw7XG4gIG9wLmJvdW5kTW9iaWxlQXQgPSBudWxsO1xuXG4gIHNhdmVSZWdpc3RlcmVkT3BlcmF0b3JzKG9wZXJhdG9ycyk7XG4gIGFkZFNlY3VyaXR5QXVkaXRMb2coJ0RFVklDRV9SRVNFVCcsIG9wLnVzZXJuYW1lLCBgTWFzdGVyIEFkbWluIGNsZWFyZWQgYWxsIGRldmljZSBiaW5kaW5ncyAoUEMgJiBNb2JpbGUpYCk7XG4gIHJldHVybiB0cnVlO1xufVxuXG4vLyBNYXN0ZXIgQWRtaW46IFRvZ2dsZSBMb2NrIEFjY291bnRcbmV4cG9ydCBmdW5jdGlvbiB0b2dnbGVPcGVyYXRvckxvY2sob3BlcmF0b3JJZDogc3RyaW5nKTogYm9vbGVhbiB7XG4gIGNvbnN0IG9wZXJhdG9ycyA9IGdldFJlZ2lzdGVyZWRPcGVyYXRvcnMoKTtcbiAgY29uc3Qgb3AgPSBvcGVyYXRvcnMuZmluZChvID0+IG8uaWQgPT09IG9wZXJhdG9ySWQgfHwgby51c2VybmFtZSA9PT0gb3BlcmF0b3JJZCk7XG4gIGlmICghb3ApIHJldHVybiBmYWxzZTtcblxuICBvcC5pc0xvY2tlZCA9ICFvcC5pc0xvY2tlZDtcbiAgc2F2ZVJlZ2lzdGVyZWRPcGVyYXRvcnMob3BlcmF0b3JzKTtcbiAgYWRkU2VjdXJpdHlBdWRpdExvZygnT1BFUkFUT1JfTE9DS0VEJywgb3AudXNlcm5hbWUsIGBNYXN0ZXIgQWRtaW4gc2V0IGxvY2sgc3RhdHVzIHRvOiAke29wLmlzTG9ja2VkID8gJ0xPQ0tFRCcgOiAnQUNUSVZFJ31gKTtcbiAgcmV0dXJuIHRydWU7XG59XG5cbi8vIE1hc3RlciBBZG1pbjogQWRkIE9wZXJhdG9yXG5leHBvcnQgZnVuY3Rpb24gYWRkTmV3T3BlcmF0b3Iob3A6IE9taXQ8T3BlcmF0b3JBY2NvdW50LCAnaWQnIHwgJ2JvdW5kUGNEZXZpY2VJZCcgfCAnYm91bmRQY0RldmljZU5hbWUnIHwgJ2JvdW5kUGNBdCcgfCAnYm91bmRNb2JpbGVEZXZpY2VJZCcgfCAnYm91bmRNb2JpbGVEZXZpY2VOYW1lJyB8ICdib3VuZE1vYmlsZUF0JyB8ICdsYXN0TG9naW4nIHwgJ2lzTG9ja2VkJz4pOiBib29sZWFuIHtcbiAgY29uc3Qgb3BlcmF0b3JzID0gZ2V0UmVnaXN0ZXJlZE9wZXJhdG9ycygpO1xuICBpZiAob3BlcmF0b3JzLnNvbWUobyA9PiBvLnVzZXJuYW1lLnRvTG93ZXJDYXNlKCkgPT09IG9wLnVzZXJuYW1lLnRvTG93ZXJDYXNlKCkpKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG5cbiAgY29uc3QgbmV3T3A6IE9wZXJhdG9yQWNjb3VudCA9IHtcbiAgICAuLi5vcCxcbiAgICBpZDogYG9wLSR7RGF0ZS5ub3coKX1gLFxuICAgIGJvdW5kUGNEZXZpY2VJZDogbnVsbCxcbiAgICBib3VuZFBjRGV2aWNlTmFtZTogbnVsbCxcbiAgICBib3VuZFBjQXQ6IG51bGwsXG4gICAgYm91bmRNb2JpbGVEZXZpY2VJZDogbnVsbCxcbiAgICBib3VuZE1vYmlsZURldmljZU5hbWU6IG51bGwsXG4gICAgYm91bmRNb2JpbGVBdDogbnVsbCxcbiAgICBsYXN0TG9naW46IG51bGwsXG4gICAgaXNMb2NrZWQ6IGZhbHNlXG4gIH07XG5cbiAgb3BlcmF0b3JzLnB1c2gobmV3T3ApO1xuICBzYXZlUmVnaXN0ZXJlZE9wZXJhdG9ycyhvcGVyYXRvcnMpO1xuICBhZGRTZWN1cml0eUF1ZGl0TG9nKCdMT0dJTl9TVUNDRVNTJywgJ2FkbWluJywgYE1hc3RlciBBZG1pbiByZWdpc3RlcmVkIG5ldyBvcGVyYXRvcjogJHtvcC51c2VybmFtZX1gKTtcbiAgcmV0dXJuIHRydWU7XG59XG5cbi8vIE1hc3RlciBBZG1pbjogRGVsZXRlIE9wZXJhdG9yXG5leHBvcnQgZnVuY3Rpb24gZGVsZXRlT3BlcmF0b3Iob3BlcmF0b3JJZDogc3RyaW5nKTogYm9vbGVhbiB7XG4gIGxldCBvcGVyYXRvcnMgPSBnZXRSZWdpc3RlcmVkT3BlcmF0b3JzKCk7XG4gIGNvbnN0IG9wID0gb3BlcmF0b3JzLmZpbmQobyA9PiBvLmlkID09PSBvcGVyYXRvcklkKTtcbiAgaWYgKCFvcCB8fCBvcC5yb2xlID09PSAnYWRtaW4nKSByZXR1cm4gZmFsc2U7XG5cbiAgb3BlcmF0b3JzID0gb3BlcmF0b3JzLmZpbHRlcihvID0+IG8uaWQgIT09IG9wZXJhdG9ySWQpO1xuICBzYXZlUmVnaXN0ZXJlZE9wZXJhdG9ycyhvcGVyYXRvcnMpO1xuICBhZGRTZWN1cml0eUF1ZGl0TG9nKCdMT0dJTl9TVUNDRVNTJywgJ2FkbWluJywgYE1hc3RlciBBZG1pbiBkZWxldGVkIG9wZXJhdG9yOiAke29wLnVzZXJuYW1lfWApO1xuICByZXR1cm4gdHJ1ZTtcbn1cblxuLy8gQ2FsY3VsYXRlIERheXMgTGVmdCB1bnRpbCB2YWxpZGl0eSBleHBpcnlcbmV4cG9ydCBmdW5jdGlvbiBjYWxjdWxhdGVSZW1haW5pbmdEYXlzKGRhdGVTdHI/OiBzdHJpbmcgfCBudWxsKTogbnVtYmVyIHtcbiAgaWYgKCFkYXRlU3RyKSByZXR1cm4gOTA7IC8vIGRlZmF1bHQgOTAgZGF5c1xuICBjb25zdCBleHBpcnkgPSBuZXcgRGF0ZShkYXRlU3RyKS5nZXRUaW1lKCk7XG4gIGNvbnN0IG5vdyA9IERhdGUubm93KCk7XG4gIGNvbnN0IGRpZmYgPSBleHBpcnkgLSBub3c7XG4gIHJldHVybiBNYXRoLm1heCgwLCBNYXRoLmNlaWwoZGlmZiAvICgxMDAwICogNjAgKiA2MCAqIDI0KSkpO1xufVxuXG4vLyBNYXN0ZXIgQWRtaW46IFJlbmV3IE9wZXJhdG9yIExpY2Vuc2UgLyBBY2Nlc3NcbmV4cG9ydCBmdW5jdGlvbiByZW5ld09wZXJhdG9yTGljZW5zZShvcGVyYXRvcklkOiBzdHJpbmcsIGRheXNUb0FkZDogbnVtYmVyKTogeyBzdWNjZXNzOiBib29sZWFuOyBuZXdFeHBpcnk6IHN0cmluZzsgZGF5c0xlZnQ6IG51bWJlciB9IHtcbiAgY29uc3Qgb3BlcmF0b3JzID0gZ2V0UmVnaXN0ZXJlZE9wZXJhdG9ycygpO1xuICBjb25zdCBvcCA9IG9wZXJhdG9ycy5maW5kKG8gPT4gby5pZCA9PT0gb3BlcmF0b3JJZCB8fCBvLnVzZXJuYW1lID09PSBvcGVyYXRvcklkKTtcbiAgaWYgKCFvcCkgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIG5ld0V4cGlyeTogJycsIGRheXNMZWZ0OiAwIH07XG5cbiAgbGV0IGN1cnJlbnRFeHBpcnkgPSBvcC52YWxpZGl0eUV4cGlyZXNBdCA/IG5ldyBEYXRlKG9wLnZhbGlkaXR5RXhwaXJlc0F0KS5nZXRUaW1lKCkgOiBEYXRlLm5vdygpO1xuICBpZiAoY3VycmVudEV4cGlyeSA8IERhdGUubm93KCkpIHtcbiAgICBjdXJyZW50RXhwaXJ5ID0gRGF0ZS5ub3coKTtcbiAgfVxuXG4gIGNvbnN0IG5ld0V4cGlyeVRpbWUgPSBjdXJyZW50RXhwaXJ5ICsgKGRheXNUb0FkZCAqIDI0ICogNjAgKiA2MCAqIDEwMDApO1xuICBjb25zdCBuZXdFeHBpcnlTdHIgPSBuZXcgRGF0ZShuZXdFeHBpcnlUaW1lKS50b0lTT1N0cmluZygpLnNwbGl0KCdUJylbMF07XG4gIGNvbnN0IGRheXNMZWZ0ID0gTWF0aC5jZWlsKChuZXdFeHBpcnlUaW1lIC0gRGF0ZS5ub3coKSkgLyAoMTAwMCAqIDYwICogNjAgKiAyNCkpO1xuXG4gIG9wLnZhbGlkaXR5RXhwaXJlc0F0ID0gbmV3RXhwaXJ5U3RyO1xuICBvcC52YWxpZGl0eURheXNMZWZ0ID0gZGF5c0xlZnQ7XG5cbiAgc2F2ZVJlZ2lzdGVyZWRPcGVyYXRvcnMob3BlcmF0b3JzKTtcbiAgYWRkU2VjdXJpdHlBdWRpdExvZygnTE9HSU5fU1VDQ0VTUycsIG9wLnVzZXJuYW1lLCBgTGljZW5zZSByZW5ld2VkIGZvciArJHtkYXlzVG9BZGR9IGRheXMuIFZhbGlkIHVudGlsICR7bmV3RXhwaXJ5U3RyfSAoJHtkYXlzTGVmdH0gZGF5cyBsZWZ0KWApO1xuXG4gIHJldHVybiB7XG4gICAgc3VjY2VzczogdHJ1ZSxcbiAgICBuZXdFeHBpcnk6IG5ld0V4cGlyeVN0cixcbiAgICBkYXlzTGVmdFxuICB9O1xufVxuXG4vLyBDbGllbnQgTGl2ZSBIZWFydGJlYXQgUmVwb3J0ZXJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZW5kT3BlcmF0b3JIZWFydGJlYXQoZGF0YToge1xuICB1c2VybmFtZTogc3RyaW5nO1xuICBkaXNwbGF5TmFtZTogc3RyaW5nO1xuICByb2xlOiAnYWRtaW4nIHwgJ29wZXJhdG9yJztcbiAgcGhvbmU/OiBzdHJpbmc7XG4gIGN1cnJlbnRUYWI6IHN0cmluZztcbiAgY3VycmVudFRhc2s/OiBzdHJpbmc7XG59KTogUHJvbWlzZTx7IHN1Y2Nlc3M6IGJvb2xlYW47IGFjdGl2ZUNvdW50OiBudW1iZXI7IGJyb2FkY2FzdE1lc3NhZ2U/OiBzdHJpbmcgfCBudWxsIH0+IHtcbiAgY29uc3QgZGV2aWNlSWQgPSBnZXRIYXJkd2FyZURldmljZUlkKCk7XG4gIGNvbnN0IGRldmljZU5hbWUgPSBnZXRIYXJkd2FyZURldmljZU5hbWUoKTtcbiAgY29uc3QgZGV2aWNlVHlwZSA9IGlzTW9iaWxlRGV2aWNlKCkgPyAnbW9iaWxlJyA6ICdwYyc7XG5cbiAgdHJ5IHtcbiAgICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaCgnL2FwaS9saXZlL2hlYXJ0YmVhdCcsIHtcbiAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgaGVhZGVyczogeyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0sXG4gICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIC4uLmRhdGEsXG4gICAgICAgIGRldmljZUlkLFxuICAgICAgICBkZXZpY2VOYW1lLFxuICAgICAgICBkZXZpY2VUeXBlXG4gICAgICB9KVxuICAgIH0pO1xuICAgIGlmIChyZXMub2spIHtcbiAgICAgIHJldHVybiBhd2FpdCByZXMuanNvbigpO1xuICAgIH1cbiAgfSBjYXRjaCB7XG4gICAgLy8gT2ZmbGluZSBtb2RlOiBzdG9yZSBpbiBsb2NhbCBzdG9yYWdlIGhlYXJ0YmVhdCByZWdpc3RyeVxuICAgIHRyeSB7XG4gICAgICBjb25zdCBsb2NhbEtleSA9ICdtb3NfbG9jYWxfbGl2ZV9wdWxzZSc7XG4gICAgICBjb25zdCBleGlzdGluZyA9IEpTT04ucGFyc2UobG9jYWxTdG9yYWdlLmdldEl0ZW0obG9jYWxLZXkpIHx8ICd7fScpO1xuICAgICAgZXhpc3RpbmdbZGF0YS51c2VybmFtZV0gPSB7XG4gICAgICAgIC4uLmRhdGEsXG4gICAgICAgIGRldmljZUlkLFxuICAgICAgICBkZXZpY2VOYW1lLFxuICAgICAgICBkZXZpY2VUeXBlLFxuICAgICAgICBsYXN0SGVhcnRiZWF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKClcbiAgICAgIH07XG4gICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShsb2NhbEtleSwgSlNPTi5zdHJpbmdpZnkoZXhpc3RpbmcpKTtcbiAgICB9IGNhdGNoIHt9XG4gIH1cbiAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSwgYWN0aXZlQ291bnQ6IDEsIGJyb2FkY2FzdE1lc3NhZ2U6IG51bGwgfTtcbn1cblxuLy8gTWFzdGVyIEFkbWluOiBGZXRjaCBMaXZlIE9wZXJhdG9yIFNlc3Npb25zXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TGl2ZU9wZXJhdG9yU2Vzc2lvbnMoKTogUHJvbWlzZTxhbnlbXT4ge1xuICB0cnkge1xuICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKCcvYXBpL2xpdmUvc2Vzc2lvbnMnKTtcbiAgICBpZiAocmVzLm9rKSB7XG4gICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzLmpzb24oKTtcbiAgICAgIHJldHVybiBkYXRhLnNlc3Npb25zIHx8IFtdO1xuICAgIH1cbiAgfSBjYXRjaCB7fVxuXG4gIC8vIExvY2FsIGZhbGxiYWNrIGlmIHNlcnZlciB1bnJlYWNoYWJsZVxuICBjb25zdCBvcGVyYXRvcnMgPSBnZXRSZWdpc3RlcmVkT3BlcmF0b3JzKCk7XG4gIGNvbnN0IGN1cnJlbnREZXZJZCA9IGdldEhhcmR3YXJlRGV2aWNlSWQoKTtcbiAgY29uc3QgY3VycmVudERldk5hbWUgPSBnZXRIYXJkd2FyZURldmljZU5hbWUoKTtcblxuICByZXR1cm4gb3BlcmF0b3JzLm1hcChvcCA9PiAoe1xuICAgIHNlc3Npb25JZDogYGxvY2FsLSR7b3AuaWR9YCxcbiAgICB1c2VybmFtZTogb3AudXNlcm5hbWUsXG4gICAgZGlzcGxheU5hbWU6IG9wLmRpc3BsYXlOYW1lLFxuICAgIHJvbGU6IG9wLnJvbGUsXG4gICAgcGhvbmU6IG9wLnBob25lLFxuICAgIGRldmljZVR5cGU6IGlzTW9iaWxlRGV2aWNlKCkgPyAnbW9iaWxlJyA6ICdwYycsXG4gICAgZGV2aWNlSWQ6IGN1cnJlbnREZXZJZCxcbiAgICBkZXZpY2VOYW1lOiBjdXJyZW50RGV2TmFtZSxcbiAgICBjdXJyZW50VGFiOiAnV29ya3N0YXRpb24gQWN0aXZlJyxcbiAgICBjdXJyZW50VGFzazogJ09ubGluZSBIdWInLFxuICAgIGxvZ2luVGltZTogb3AubGFzdExvZ2luIHx8IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICBsYXN0SGVhcnRiZWF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgdmFsaWRpdHlFeHBpcmVzQXQ6IG9wLnZhbGlkaXR5RXhwaXJlc0F0IHx8ICcyMDI2LTEyLTMxJyxcbiAgICBpc09ubGluZTogdHJ1ZSxcbiAgICBsYXN0QWN0aXZlU2Vjb25kc0FnbzogMixcbiAgICBpcEFkZHJlc3M6ICcxMjcuMC4wLjEgKExvY2FsKSdcbiAgfSkpO1xufVxuXG4vLyBNYXN0ZXIgQWRtaW46IEZvcmNlIERpc2Nvbm5lY3QgYW4gT3BlcmF0b3JcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBmb3JjZURpc2Nvbm5lY3RPcGVyYXRvcih1c2VybmFtZTogc3RyaW5nLCBkZXZpY2VJZD86IHN0cmluZyk6IFByb21pc2U8Ym9vbGVhbj4ge1xuICB0cnkge1xuICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKCcvYXBpL2xpdmUvdGVybWluYXRlJywge1xuICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICBoZWFkZXJzOiB7ICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSxcbiAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHsgdXNlcm5hbWUsIGRldmljZUlkIH0pXG4gICAgfSk7XG4gICAgcmV0dXJuIHJlcy5vaztcbiAgfSBjYXRjaCB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG59XG5cbi8vIE1hc3RlciBBZG1pbjogQnJvYWRjYXN0IG1lc3NhZ2UgdG8gb3BlcmF0b3JcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZW5kT3BlcmF0b3JCcm9hZGNhc3RNZXNzYWdlKHVzZXJuYW1lOiBzdHJpbmcsIG1lc3NhZ2U6IHN0cmluZyk6IFByb21pc2U8Ym9vbGVhbj4ge1xuICB0cnkge1xuICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKCcvYXBpL2xpdmUvYnJvYWRjYXN0Jywge1xuICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICBoZWFkZXJzOiB7ICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSxcbiAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHsgdXNlcm5hbWUsIG1lc3NhZ2UgfSlcbiAgICB9KTtcbiAgICByZXR1cm4gcmVzLm9rO1xuICB9IGNhdGNoIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbn1cblxuIl19