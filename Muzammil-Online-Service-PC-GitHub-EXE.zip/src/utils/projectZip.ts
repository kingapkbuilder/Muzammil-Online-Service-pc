const JSZip = __vite__cjsImport0_jszip;import __vite__cjsImport0_jszip from "/node_modules/.vite/deps/jszip.js?v=1d04f0f2";
export async function generateProjectZip(onProgress) {
	const zip = new JSZip();
	// Project information
	const readmeContent = `# Muzammil Online Service - CSC & Cyber Cafe Workstation Suite
## Version: v98.0 PC Suite (Standalone Standalone Edition)
**Owner:** Imran Khan | **Contact:** 9561460313
**Address:** Naya Munshi Shaban Nagar, Main Road, Maharashtra, India

---

### Features & Workstation Modules:
1. **Strict 1-Device Security Locking**: Each Operator ID is permanently bound to a single computer/phone.
2. **PVC Smart Card Studio**: CR-80 85.6x54mm instant dual card 300 DPI layout for 4x6 photo paper with center cut line.
3. **Passport Photo Studio Pro**:
   - 4x6 Landscape (8 Copies @ 300 DPI) & A4 Landscape sheet layout.
   - Connected Flood-Fill Magic Wand Background Cutout.
   - Vector Pen Tool with Anchor Points & Live Dual Preview.
   - AI Auto Beauty Face Effect with Skin Smoothing & Facial Radiance.
   - Official Exam Stamp (Candidate Name & Date for SSC/Police Bharti).
4. **PDF to HD JPG High-Resolution Rasterizer**: Convert PDF Aadhaar/PAN/Voter slips to 300 DPI images.
5. **Fast Thermal Billing Desk & POS**: 58mm & 80mm thermal receipt generator with QR code payment.
6. **Customer CRM & Delivery Tracker**: Token tracking, pending work alerts, WhatsApp notifications.
7. **BioData & CV Maker**: Hindi, English, and Islamic wedding biodata templates.
8. **50+ Government Portals Directory**: Direct links to all Central & Maharashtra State Citizen Portals.
9. **Cyber Cafe Daily SOP Workflow Engine**: Interactive checklist for day-to-day cyber operations.
10. **Master Admin Panel**: Device lock resets, operator management, and security audit logs.

---

### How to Run Locally:
\`\`\`bash
# 1. Install dependencies
npm install

# 2. Run development server (Port 3000)
npm run dev

# 3. Build for production
npm run build
\`\`\`
`;
	zip.file("README.md", readmeContent);
	// We can fetch files or bundle the source files that make up the client app
	const sourceFiles = [
		"/package.json",
		"/server.ts",
		"/vite.config.ts",
		"/tsconfig.json",
		"/index.html",
		"/src/main.tsx",
		"/src/App.tsx",
		"/src/index.css",
		"/src/types.ts",
		"/src/data/portalData.ts",
		"/src/utils/storage.ts",
		"/src/utils/printer.ts",
		"/src/utils/deviceSecurity.ts",
		"/src/utils/projectZip.ts",
		"/src/components/Header.tsx",
		"/src/components/Sidebar.tsx",
		"/src/components/DashboardView.tsx",
		"/src/components/LoginScreen.tsx",
		"/src/components/PvcStudioView.tsx",
		"/src/components/PassportStudioView.tsx",
		"/src/components/BillingDeskView.tsx",
		"/src/components/CustomerCrmView.tsx",
		"/src/components/PdfToJpgView.tsx",
		"/src/components/BioDataMakerView.tsx",
		"/src/components/GovernmentPortalsView.tsx",
		"/src/components/AiAssistantView.tsx",
		"/src/components/DownloadsView.tsx",
		"/src/components/SettingsView.tsx",
		"/src/components/ShortcutsModal.tsx",
		"/src/components/AuthModal.tsx",
		"/src/components/MasterAdminView.tsx",
		"/src/components/WorkflowGuideView.tsx",
		"/START-WORKSTATION.bat",
		"/CREATE-EXE-SETUP.bat",
		"/HOW-TO-BUILD-EXE.md",
		"/installer/setup.iss",
		"/electron/main.cjs",
		"/electron/preload.cjs"
	];
	let completed = 0;
	for (const filePath of sourceFiles) {
		try {
			const cleanPath = filePath.startsWith("/") ? filePath.slice(1) : filePath;
			if (onProgress) {
				onProgress(Math.round(completed / sourceFiles.length * 100), cleanPath);
			}
			const res = await fetch(filePath);
			if (res.ok) {
				const text = await res.text();
				zip.file(cleanPath, text);
			}
		} catch {}
		completed++;
	}
	if (onProgress) {
		onProgress(100, "Compressing archive...");
	}
	const content = await zip.generateAsync({
		type: "blob",
		compression: "DEFLATE",
		compressionOptions: { level: 9 }
	});
	return content;
}
export function triggerDownloadZip(blob, filename = "Muzammil-Online-Service-Complete-Source.zip") {
	const url = URL.createObjectURL(blob);
	const a = document.createElement("a");
	a.href = url;
	a.download = filename;
	document.body.appendChild(a);
	a.click();
	document.body.removeChild(a);
	setTimeout(() => URL.revokeObjectURL(url), 5e3);
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBRWxCLE9BQU8sZUFBZSxtQkFBbUIsWUFBcUU7Q0FDNUcsTUFBTSxNQUFNLElBQUksTUFBTTs7Q0FHdEIsTUFBTSxnQkFBZ0I7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBdUN0QixJQUFJLEtBQUssYUFBYSxhQUFhOztDQUduQyxNQUFNLGNBQWM7RUFDbEI7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtDQUNGO0NBRUEsSUFBSSxZQUFZO0NBQ2hCLEtBQUssTUFBTSxZQUFZLGFBQWE7RUFDbEMsSUFBSTtHQUNGLE1BQU0sWUFBWSxTQUFTLFdBQVcsR0FBRyxJQUFJLFNBQVMsTUFBTSxDQUFDLElBQUk7R0FDakUsSUFBSSxZQUFZO0lBQ2QsV0FBVyxLQUFLLE1BQU8sWUFBWSxZQUFZLFNBQVUsR0FBRyxHQUFHLFNBQVM7R0FDMUU7R0FFQSxNQUFNLE1BQU0sTUFBTSxNQUFNLFFBQVE7R0FDaEMsSUFBSSxJQUFJLElBQUk7SUFDVixNQUFNLE9BQU8sTUFBTSxJQUFJLEtBQUs7SUFDNUIsSUFBSSxLQUFLLFdBQVcsSUFBSTtHQUMxQjtFQUNGLFFBQVEsQ0FFUjtFQUNBO0NBQ0Y7Q0FFQSxJQUFJLFlBQVk7RUFDZCxXQUFXLEtBQUssd0JBQXdCO0NBQzFDO0NBRUEsTUFBTSxVQUFVLE1BQU0sSUFBSSxjQUFjO0VBQ3RDLE1BQU07RUFDTixhQUFhO0VBQ2Isb0JBQW9CLEVBQUUsT0FBTyxFQUFFO0NBQ2pDLENBQUM7Q0FFRCxPQUFPO0FBQ1Q7QUFFQSxPQUFPLFNBQVMsbUJBQW1CLE1BQVksV0FBVywrQ0FBK0M7Q0FDdkcsTUFBTSxNQUFNLElBQUksZ0JBQWdCLElBQUk7Q0FDcEMsTUFBTSxJQUFJLFNBQVMsY0FBYyxHQUFHO0NBQ3BDLEVBQUUsT0FBTztDQUNULEVBQUUsV0FBVztDQUNiLFNBQVMsS0FBSyxZQUFZLENBQUM7Q0FDM0IsRUFBRSxNQUFNO0NBQ1IsU0FBUyxLQUFLLFlBQVksQ0FBQztDQUMzQixpQkFBaUIsSUFBSSxnQkFBZ0IsR0FBRyxHQUFHLEdBQUk7QUFDakQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsicHJvamVjdFppcC50cyJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgSlNaaXAgZnJvbSAnanN6aXAnO1xuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2VuZXJhdGVQcm9qZWN0WmlwKG9uUHJvZ3Jlc3M/OiAocGVyY2VudDogbnVtYmVyLCBmaWxlOiBzdHJpbmcpID0+IHZvaWQpOiBQcm9taXNlPEJsb2I+IHtcbiAgY29uc3QgemlwID0gbmV3IEpTWmlwKCk7XG5cbiAgLy8gUHJvamVjdCBpbmZvcm1hdGlvblxuICBjb25zdCByZWFkbWVDb250ZW50ID0gYCMgTXV6YW1taWwgT25saW5lIFNlcnZpY2UgLSBDU0MgJiBDeWJlciBDYWZlIFdvcmtzdGF0aW9uIFN1aXRlXG4jIyBWZXJzaW9uOiB2OTguMCBQQyBTdWl0ZSAoU3RhbmRhbG9uZSBTdGFuZGFsb25lIEVkaXRpb24pXG4qKk93bmVyOioqIEltcmFuIEtoYW4gfCAqKkNvbnRhY3Q6KiogOTU2MTQ2MDMxM1xuKipBZGRyZXNzOioqIE5heWEgTXVuc2hpIFNoYWJhbiBOYWdhciwgTWFpbiBSb2FkLCBNYWhhcmFzaHRyYSwgSW5kaWFcblxuLS0tXG5cbiMjIyBGZWF0dXJlcyAmIFdvcmtzdGF0aW9uIE1vZHVsZXM6XG4xLiAqKlN0cmljdCAxLURldmljZSBTZWN1cml0eSBMb2NraW5nKio6IEVhY2ggT3BlcmF0b3IgSUQgaXMgcGVybWFuZW50bHkgYm91bmQgdG8gYSBzaW5nbGUgY29tcHV0ZXIvcGhvbmUuXG4yLiAqKlBWQyBTbWFydCBDYXJkIFN0dWRpbyoqOiBDUi04MCA4NS42eDU0bW0gaW5zdGFudCBkdWFsIGNhcmQgMzAwIERQSSBsYXlvdXQgZm9yIDR4NiBwaG90byBwYXBlciB3aXRoIGNlbnRlciBjdXQgbGluZS5cbjMuICoqUGFzc3BvcnQgUGhvdG8gU3R1ZGlvIFBybyoqOlxuICAgLSA0eDYgTGFuZHNjYXBlICg4IENvcGllcyBAIDMwMCBEUEkpICYgQTQgTGFuZHNjYXBlIHNoZWV0IGxheW91dC5cbiAgIC0gQ29ubmVjdGVkIEZsb29kLUZpbGwgTWFnaWMgV2FuZCBCYWNrZ3JvdW5kIEN1dG91dC5cbiAgIC0gVmVjdG9yIFBlbiBUb29sIHdpdGggQW5jaG9yIFBvaW50cyAmIExpdmUgRHVhbCBQcmV2aWV3LlxuICAgLSBBSSBBdXRvIEJlYXV0eSBGYWNlIEVmZmVjdCB3aXRoIFNraW4gU21vb3RoaW5nICYgRmFjaWFsIFJhZGlhbmNlLlxuICAgLSBPZmZpY2lhbCBFeGFtIFN0YW1wIChDYW5kaWRhdGUgTmFtZSAmIERhdGUgZm9yIFNTQy9Qb2xpY2UgQmhhcnRpKS5cbjQuICoqUERGIHRvIEhEIEpQRyBIaWdoLVJlc29sdXRpb24gUmFzdGVyaXplcioqOiBDb252ZXJ0IFBERiBBYWRoYWFyL1BBTi9Wb3RlciBzbGlwcyB0byAzMDAgRFBJIGltYWdlcy5cbjUuICoqRmFzdCBUaGVybWFsIEJpbGxpbmcgRGVzayAmIFBPUyoqOiA1OG1tICYgODBtbSB0aGVybWFsIHJlY2VpcHQgZ2VuZXJhdG9yIHdpdGggUVIgY29kZSBwYXltZW50LlxuNi4gKipDdXN0b21lciBDUk0gJiBEZWxpdmVyeSBUcmFja2VyKio6IFRva2VuIHRyYWNraW5nLCBwZW5kaW5nIHdvcmsgYWxlcnRzLCBXaGF0c0FwcCBub3RpZmljYXRpb25zLlxuNy4gKipCaW9EYXRhICYgQ1YgTWFrZXIqKjogSGluZGksIEVuZ2xpc2gsIGFuZCBJc2xhbWljIHdlZGRpbmcgYmlvZGF0YSB0ZW1wbGF0ZXMuXG44LiAqKjUwKyBHb3Zlcm5tZW50IFBvcnRhbHMgRGlyZWN0b3J5Kio6IERpcmVjdCBsaW5rcyB0byBhbGwgQ2VudHJhbCAmIE1haGFyYXNodHJhIFN0YXRlIENpdGl6ZW4gUG9ydGFscy5cbjkuICoqQ3liZXIgQ2FmZSBEYWlseSBTT1AgV29ya2Zsb3cgRW5naW5lKio6IEludGVyYWN0aXZlIGNoZWNrbGlzdCBmb3IgZGF5LXRvLWRheSBjeWJlciBvcGVyYXRpb25zLlxuMTAuICoqTWFzdGVyIEFkbWluIFBhbmVsKio6IERldmljZSBsb2NrIHJlc2V0cywgb3BlcmF0b3IgbWFuYWdlbWVudCwgYW5kIHNlY3VyaXR5IGF1ZGl0IGxvZ3MuXG5cbi0tLVxuXG4jIyMgSG93IHRvIFJ1biBMb2NhbGx5OlxuXFxgXFxgXFxgYmFzaFxuIyAxLiBJbnN0YWxsIGRlcGVuZGVuY2llc1xubnBtIGluc3RhbGxcblxuIyAyLiBSdW4gZGV2ZWxvcG1lbnQgc2VydmVyIChQb3J0IDMwMDApXG5ucG0gcnVuIGRldlxuXG4jIDMuIEJ1aWxkIGZvciBwcm9kdWN0aW9uXG5ucG0gcnVuIGJ1aWxkXG5cXGBcXGBcXGBcbmA7XG5cbiAgemlwLmZpbGUoJ1JFQURNRS5tZCcsIHJlYWRtZUNvbnRlbnQpO1xuXG4gIC8vIFdlIGNhbiBmZXRjaCBmaWxlcyBvciBidW5kbGUgdGhlIHNvdXJjZSBmaWxlcyB0aGF0IG1ha2UgdXAgdGhlIGNsaWVudCBhcHBcbiAgY29uc3Qgc291cmNlRmlsZXMgPSBbXG4gICAgJy9wYWNrYWdlLmpzb24nLFxuICAgICcvc2VydmVyLnRzJyxcbiAgICAnL3ZpdGUuY29uZmlnLnRzJyxcbiAgICAnL3RzY29uZmlnLmpzb24nLFxuICAgICcvaW5kZXguaHRtbCcsXG4gICAgJy9zcmMvbWFpbi50c3gnLFxuICAgICcvc3JjL0FwcC50c3gnLFxuICAgICcvc3JjL2luZGV4LmNzcycsXG4gICAgJy9zcmMvdHlwZXMudHMnLFxuICAgICcvc3JjL2RhdGEvcG9ydGFsRGF0YS50cycsXG4gICAgJy9zcmMvdXRpbHMvc3RvcmFnZS50cycsXG4gICAgJy9zcmMvdXRpbHMvcHJpbnRlci50cycsXG4gICAgJy9zcmMvdXRpbHMvZGV2aWNlU2VjdXJpdHkudHMnLFxuICAgICcvc3JjL3V0aWxzL3Byb2plY3RaaXAudHMnLFxuICAgICcvc3JjL2NvbXBvbmVudHMvSGVhZGVyLnRzeCcsXG4gICAgJy9zcmMvY29tcG9uZW50cy9TaWRlYmFyLnRzeCcsXG4gICAgJy9zcmMvY29tcG9uZW50cy9EYXNoYm9hcmRWaWV3LnRzeCcsXG4gICAgJy9zcmMvY29tcG9uZW50cy9Mb2dpblNjcmVlbi50c3gnLFxuICAgICcvc3JjL2NvbXBvbmVudHMvUHZjU3R1ZGlvVmlldy50c3gnLFxuICAgICcvc3JjL2NvbXBvbmVudHMvUGFzc3BvcnRTdHVkaW9WaWV3LnRzeCcsXG4gICAgJy9zcmMvY29tcG9uZW50cy9CaWxsaW5nRGVza1ZpZXcudHN4JyxcbiAgICAnL3NyYy9jb21wb25lbnRzL0N1c3RvbWVyQ3JtVmlldy50c3gnLFxuICAgICcvc3JjL2NvbXBvbmVudHMvUGRmVG9KcGdWaWV3LnRzeCcsXG4gICAgJy9zcmMvY29tcG9uZW50cy9CaW9EYXRhTWFrZXJWaWV3LnRzeCcsXG4gICAgJy9zcmMvY29tcG9uZW50cy9Hb3Zlcm5tZW50UG9ydGFsc1ZpZXcudHN4JyxcbiAgICAnL3NyYy9jb21wb25lbnRzL0FpQXNzaXN0YW50Vmlldy50c3gnLFxuICAgICcvc3JjL2NvbXBvbmVudHMvRG93bmxvYWRzVmlldy50c3gnLFxuICAgICcvc3JjL2NvbXBvbmVudHMvU2V0dGluZ3NWaWV3LnRzeCcsXG4gICAgJy9zcmMvY29tcG9uZW50cy9TaG9ydGN1dHNNb2RhbC50c3gnLFxuICAgICcvc3JjL2NvbXBvbmVudHMvQXV0aE1vZGFsLnRzeCcsXG4gICAgJy9zcmMvY29tcG9uZW50cy9NYXN0ZXJBZG1pblZpZXcudHN4JyxcbiAgICAnL3NyYy9jb21wb25lbnRzL1dvcmtmbG93R3VpZGVWaWV3LnRzeCcsXG4gICAgJy9TVEFSVC1XT1JLU1RBVElPTi5iYXQnLFxuICAgICcvQ1JFQVRFLUVYRS1TRVRVUC5iYXQnLFxuICAgICcvSE9XLVRPLUJVSUxELUVYRS5tZCcsXG4gICAgJy9pbnN0YWxsZXIvc2V0dXAuaXNzJyxcbiAgICAnL2VsZWN0cm9uL21haW4uY2pzJyxcbiAgICAnL2VsZWN0cm9uL3ByZWxvYWQuY2pzJ1xuICBdO1xuXG4gIGxldCBjb21wbGV0ZWQgPSAwO1xuICBmb3IgKGNvbnN0IGZpbGVQYXRoIG9mIHNvdXJjZUZpbGVzKSB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGNsZWFuUGF0aCA9IGZpbGVQYXRoLnN0YXJ0c1dpdGgoJy8nKSA/IGZpbGVQYXRoLnNsaWNlKDEpIDogZmlsZVBhdGg7XG4gICAgICBpZiAob25Qcm9ncmVzcykge1xuICAgICAgICBvblByb2dyZXNzKE1hdGgucm91bmQoKGNvbXBsZXRlZCAvIHNvdXJjZUZpbGVzLmxlbmd0aCkgKiAxMDApLCBjbGVhblBhdGgpO1xuICAgICAgfVxuICAgICAgXG4gICAgICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaChmaWxlUGF0aCk7XG4gICAgICBpZiAocmVzLm9rKSB7XG4gICAgICAgIGNvbnN0IHRleHQgPSBhd2FpdCByZXMudGV4dCgpO1xuICAgICAgICB6aXAuZmlsZShjbGVhblBhdGgsIHRleHQpO1xuICAgICAgfVxuICAgIH0gY2F0Y2gge1xuICAgICAgLy8gQ29udGludWUgYnVuZGxpbmdcbiAgICB9XG4gICAgY29tcGxldGVkKys7XG4gIH1cblxuICBpZiAob25Qcm9ncmVzcykge1xuICAgIG9uUHJvZ3Jlc3MoMTAwLCAnQ29tcHJlc3NpbmcgYXJjaGl2ZS4uLicpO1xuICB9XG5cbiAgY29uc3QgY29udGVudCA9IGF3YWl0IHppcC5nZW5lcmF0ZUFzeW5jKHtcbiAgICB0eXBlOiAnYmxvYicsXG4gICAgY29tcHJlc3Npb246ICdERUZMQVRFJyxcbiAgICBjb21wcmVzc2lvbk9wdGlvbnM6IHsgbGV2ZWw6IDkgfVxuICB9KTtcblxuICByZXR1cm4gY29udGVudDtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHRyaWdnZXJEb3dubG9hZFppcChibG9iOiBCbG9iLCBmaWxlbmFtZSA9ICdNdXphbW1pbC1PbmxpbmUtU2VydmljZS1Db21wbGV0ZS1Tb3VyY2UuemlwJykge1xuICBjb25zdCB1cmwgPSBVUkwuY3JlYXRlT2JqZWN0VVJMKGJsb2IpO1xuICBjb25zdCBhID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnYScpO1xuICBhLmhyZWYgPSB1cmw7XG4gIGEuZG93bmxvYWQgPSBmaWxlbmFtZTtcbiAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChhKTtcbiAgYS5jbGljaygpO1xuICBkb2N1bWVudC5ib2R5LnJlbW92ZUNoaWxkKGEpO1xuICBzZXRUaW1lb3V0KCgpID0+IFVSTC5yZXZva2VPYmplY3RVUkwodXJsKSwgNTAwMCk7XG59XG4iXX0=