const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport21_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=1d04f0f2";
import { Header } from "/src/components/Header.tsx";
import { Sidebar } from "/src/components/Sidebar.tsx";
import { DashboardView } from "/src/components/DashboardView.tsx";
import { PvcStudioView } from "/src/components/PvcStudioView.tsx";
import { PassportStudioView } from "/src/components/PassportStudioView.tsx";
import { PdfToJpgView } from "/src/components/PdfToJpgView.tsx";
import { BillingDeskView } from "/src/components/BillingDeskView.tsx";
import { CustomerCrmView } from "/src/components/CustomerCrmView.tsx";
import { BioDataMakerView } from "/src/components/BioDataMakerView.tsx";
import { GovernmentPortalsView } from "/src/components/GovernmentPortalsView.tsx";
import { AiAssistantView } from "/src/components/AiAssistantView.tsx";
import { DownloadsView } from "/src/components/DownloadsView.tsx";
import { SettingsView } from "/src/components/SettingsView.tsx";
import { MasterAdminView } from "/src/components/MasterAdminView.tsx";
import { WorkflowGuideView } from "/src/components/WorkflowGuideView.tsx";
import { AuthModal } from "/src/components/AuthModal.tsx";
import { ShortcutsModal } from "/src/components/ShortcutsModal.tsx";
import { loadSettings, saveSettings, loadUser, saveUser, logoutUser, loadBills, saveBills, loadCustomers, saveCustomers, loadDownloads, deleteDownloadRecord, exportAllData, saveDownloads } from "/src/utils/storage.ts";
import { sendOperatorHeartbeat } from "/src/utils/deviceSecurity.ts";
import { LoginScreen } from "/src/components/LoginScreen.tsx";
var _jsxFileName = "/app/applet/src/App.tsx";
import __vite__cjsImport21_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=1d04f0f2";
export default function App() {
	const [activeTab, setActiveTab] = useState("dashboard");
	const [settings, setSettings] = useState(loadSettings);
	const [user, setUser] = useState(loadUser);
	const [bills, setBills] = useState(loadBills);
	const [customers, setCustomers] = useState(loadCustomers);
	const [downloads, setDownloads] = useState(loadDownloads);
	const [adminBroadcastToast, setAdminBroadcastToast] = useState(null);
	const [searchQuery, setSearchQuery] = useState("");
	const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
	const [showAuthModal, setShowAuthModal] = useState(false);
	const [showShortcutsModal, setShowShortcutsModal] = useState(false);
	// Live Operator Heartbeat loop
	useEffect(() => {
		if (!user.isLoggedIn || !user.username) return;
		const reportHeartbeat = async () => {
			try {
				const res = await sendOperatorHeartbeat({
					username: user.username,
					displayName: user.displayName,
					role: user.role,
					phone: user.phone,
					currentTab: activeTab,
					currentTask: `Active on ${activeTab}`
				});
				if (res && res.broadcastMessage) {
					if (res.broadcastMessage === "FORCE_DISCONNECTED_BY_ADMIN") {
						alert("🚨 Your workstation session was disconnected by Master Admin.");
						handleLogout();
					} else {
						setAdminBroadcastToast(res.broadcastMessage);
						setTimeout(() => setAdminBroadcastToast(null), 8e3);
					}
				}
			} catch {}
		};
		reportHeartbeat();
		const interval = setInterval(reportHeartbeat, 5e3);
		return () => clearInterval(interval);
	}, [
		user.isLoggedIn,
		user.username,
		activeTab
	]);
	const handleAddDownload = (newDl) => {
		const updated = [newDl, ...downloads];
		setDownloads(updated);
		saveDownloads(updated);
	};
	// Sync to storage
	const handleSaveSettings = (newSettings) => {
		setSettings(newSettings);
		saveSettings(newSettings);
	};
	const handleSelectUser = (newUser) => {
		setUser(newUser);
		saveUser(newUser);
	};
	const handleLogout = () => {
		logoutUser();
		setUser({
			username: "",
			displayName: "",
			role: "operator",
			phone: "",
			shopName: settings.shopName,
			isLoggedIn: false
		});
	};
	const handleAddBill = (newBill) => {
		const updated = [newBill, ...bills];
		setBills(updated);
		saveBills(updated);
	};
	const handleDeleteBill = (id) => {
		const updated = bills.filter((b) => b.id !== id);
		setBills(updated);
		saveBills(updated);
	};
	const handleAddCustomer = (newCustomer) => {
		const updated = [newCustomer, ...customers];
		setCustomers(updated);
		saveCustomers(updated);
	};
	const handleUpdateCustomerStatus = (id, newStatus) => {
		const updated = customers.map((c) => c.id === id ? {
			...c,
			status: newStatus
		} : c);
		setCustomers(updated);
		saveCustomers(updated);
	};
	const handleDeleteCustomer = (id) => {
		const updated = customers.filter((c) => c.id !== id);
		setCustomers(updated);
		saveCustomers(updated);
	};
	const handleDeleteDownload = (id) => {
		deleteDownloadRecord(id);
		setDownloads(loadDownloads());
	};
	const handleClearDownloads = () => {
		localStorage.removeItem("mos_pc_downloads");
		setDownloads([]);
	};
	// Keyboard Shortcuts for PC
	useEffect(() => {
		const handleKeyDown = (e) => {
			// Focus search: Ctrl + K or '/'
			if (e.ctrlKey && e.key === "k" || e.key === "/" && e.target.tagName !== "INPUT" && e.target.tagName !== "TEXTAREA") {
				e.preventDefault();
				const searchInput = document.getElementById("pc-global-search");
				searchInput?.focus();
			}
			// Fast Bill: Ctrl + B
			if (e.ctrlKey && e.key === "b") {
				e.preventDefault();
				setActiveTab("billing");
			}
			// Direct In-App Studio Print: Ctrl + P
			if (e.ctrlKey && e.key === "p") {
				e.preventDefault();
				window.dispatchEvent(new CustomEvent("app-direct-print"));
			}
			// Direct In-App PDF Download: Ctrl + S
			if (e.ctrlKey && e.key === "s") {
				e.preventDefault();
				window.dispatchEvent(new CustomEvent("app-direct-pdf"));
			}
			// Direct In-App HD JPG Download: Ctrl + J
			if (e.ctrlKey && e.key === "j") {
				e.preventDefault();
				window.dispatchEvent(new CustomEvent("app-direct-jpg"));
			}
			// Tab switcher: Alt + 1 to 9
			if (e.altKey) {
				const tabMap = {
					"1": "dashboard",
					"2": "pvc_studio",
					"3": "passport_studio",
					"4": "pdf_to_jpg",
					"5": "billing",
					"6": "customers",
					"7": "biodata_maker",
					"8": "portals",
					"9": "ai_assistant"
				};
				if (tabMap[e.key]) {
					e.preventDefault();
					setActiveTab(tabMap[e.key]);
				}
			}
			// Shortcuts Modal: '?'
			if (e.key === "?" && e.target.tagName !== "INPUT" && e.target.tagName !== "TEXTAREA") {
				setShowShortcutsModal(true);
			}
			// Escape to close modals
			if (e.key === "Escape") {
				setShowAuthModal(false);
				setShowShortcutsModal(false);
			}
		};
		window.addEventListener("keydown", handleKeyDown);
		return () => window.removeEventListener("keydown", handleKeyDown);
	}, []);
	// When global search is typed, automatically switch to portals or show matches if not empty
	useEffect(() => {
		if (searchQuery.trim().length > 1 && activeTab !== "portals" && activeTab !== "dashboard") {
			setActiveTab("portals");
		}
	}, [searchQuery]);
	const pendingJobsCount = customers.filter((c) => c.status === "Pending" || c.status === "Processing").length;
	// STRICT LOGIN WALL: Nothing works or displays without authentication!
	if (!user.isLoggedIn) {
		return /* @__PURE__ */ _jsxDEV(LoginScreen, {
			settings,
			onLoginSuccess: handleSelectUser
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 241,
			columnNumber: 7
		}, this);
	}
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "flex flex-col h-screen w-screen bg-slate-950 text-slate-100 overflow-hidden font-sans selection:bg-blue-600 selection:text-white",
		children: [
			/* @__PURE__ */ _jsxDEV(Header, {
				settings,
				user,
				activeTab,
				onNavigate: (tab) => {
					setActiveTab(tab);
					setSearchQuery("");
				},
				onOpenLogin: () => setShowAuthModal(true),
				onOpenShortcuts: () => setShowShortcutsModal(true),
				onLogout: handleLogout,
				searchQuery,
				onSearchChange: setSearchQuery,
				isSidebarCollapsed,
				onToggleSidebar: () => setIsSidebarCollapsed((prev) => !prev)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 251,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-1 overflow-hidden relative",
				children: [/* @__PURE__ */ _jsxDEV(Sidebar, {
					activeTab,
					onNavigate: (tab) => {
						setActiveTab(tab);
						setSearchQuery("");
					},
					isCollapsed: isSidebarCollapsed,
					onToggleCollapse: () => setIsSidebarCollapsed((prev) => !prev),
					user,
					pendingJobsCount,
					onLogout: handleLogout
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 271,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("main", {
					className: "flex-1 overflow-y-auto p-4 lg:p-6 bg-slate-950 relative",
					children: [
						adminBroadcastToast && /* @__PURE__ */ _jsxDEV("div", {
							className: "mb-4 p-4 rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-xl flex items-center justify-between gap-3 animate-in fade-in slide-in-from-top-4 z-30",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-3",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-xl",
									children: "📢"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 290,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "font-extrabold text-xs block uppercase tracking-wider text-blue-200",
									children: "Broadcast from Master Admin:"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 292,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs font-semibold",
									children: adminBroadcastToast
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 293,
									columnNumber: 19
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 291,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 289,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setAdminBroadcastToast(null),
								className: "text-white/80 hover:text-white px-2 py-1 bg-white/10 rounded-lg text-xs font-bold",
								children: "Dismiss"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 296,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 288,
							columnNumber: 13
						}, this),
						activeTab === "dashboard" && /* @__PURE__ */ _jsxDEV(DashboardView, {
							bills,
							customers,
							settings,
							onNavigate: setActiveTab,
							onOpenQuickBill: () => setActiveTab("billing"),
							onPrintBill: () => setActiveTab("billing")
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 306,
							columnNumber: 13
						}, this),
						activeTab === "pvc_studio" && /* @__PURE__ */ _jsxDEV(PvcStudioView, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 317,
							columnNumber: 13
						}, this),
						activeTab === "passport_studio" && /* @__PURE__ */ _jsxDEV(PassportStudioView, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 321,
							columnNumber: 13
						}, this),
						activeTab === "pdf_to_jpg" && /* @__PURE__ */ _jsxDEV(PdfToJpgView, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 325,
							columnNumber: 13
						}, this),
						activeTab === "billing" && /* @__PURE__ */ _jsxDEV(BillingDeskView, {
							bills,
							settings,
							onAddBill: handleAddBill,
							onDeleteBill: handleDeleteBill
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 329,
							columnNumber: 13
						}, this),
						activeTab === "customers" && /* @__PURE__ */ _jsxDEV(CustomerCrmView, {
							customers,
							settings,
							onAddCustomer: handleAddCustomer,
							onUpdateStatus: handleUpdateCustomerStatus,
							onDeleteCustomer: handleDeleteCustomer
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 338,
							columnNumber: 13
						}, this),
						activeTab === "biodata_maker" && /* @__PURE__ */ _jsxDEV(BioDataMakerView, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 348,
							columnNumber: 13
						}, this),
						activeTab === "workflow" && /* @__PURE__ */ _jsxDEV(WorkflowGuideView, { onNavigate: setActiveTab }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 352,
							columnNumber: 13
						}, this),
						activeTab === "master_admin" && (user.role === "admin" ? /* @__PURE__ */ _jsxDEV(MasterAdminView, {
							settings,
							onUpdateSettings: handleSaveSettings,
							onNavigateToWorkflow: () => setActiveTab("workflow")
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 357,
							columnNumber: 15
						}, this) : /* @__PURE__ */ _jsxDEV("div", {
							className: "max-w-md mx-auto text-center p-8 bg-slate-900 border border-slate-800 rounded-3xl mt-12 space-y-3 shadow-2xl",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "w-12 h-12 bg-rose-500/20 text-rose-400 rounded-2xl flex items-center justify-center mx-auto text-2xl font-bold border border-rose-500/30",
									children: "🔒"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 364,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("h3", {
									className: "text-base font-extrabold text-white",
									children: "Master Admin Restricted Access"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 367,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-slate-400 leading-relaxed",
									children: "Access Denied. The project source .ZIP archive, executable setup builder, and central security controls are strictly reserved for Master Admin (Imran Khan). Staff operators or customers cannot view or download this data."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 368,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 363,
							columnNumber: 15
						}, this)),
						activeTab === "portals" && /* @__PURE__ */ _jsxDEV(GovernmentPortalsView, {
							onAddDownload: handleAddDownload,
							onNavigate: setActiveTab
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 376,
							columnNumber: 13
						}, this),
						activeTab === "ai_assistant" && /* @__PURE__ */ _jsxDEV(AiAssistantView, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 383,
							columnNumber: 13
						}, this),
						activeTab === "downloads" && /* @__PURE__ */ _jsxDEV(DownloadsView, {
							downloads,
							onDeleteDownload: handleDeleteDownload,
							onClearAll: handleClearDownloads
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 387,
							columnNumber: 13
						}, this),
						activeTab === "settings" && /* @__PURE__ */ _jsxDEV(SettingsView, {
							settings,
							onSaveSettings: handleSaveSettings
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 395,
							columnNumber: 13
						}, this),
						activeTab === "backup" && /* @__PURE__ */ _jsxDEV("div", {
							className: "max-w-2xl mx-auto space-y-4 pt-6",
							children: /* @__PURE__ */ _jsxDEV("div", {
								className: "bg-slate-900 border border-slate-800 p-6 rounded-3xl shadow-xl text-center space-y-4",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "w-16 h-16 rounded-2xl bg-purple-600/20 border border-purple-500/30 flex items-center justify-center text-purple-400 mx-auto",
										children: /* @__PURE__ */ _jsxDEV("span", {
											className: "text-3xl",
											children: "💾"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 405,
											columnNumber: 19
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 404,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("h2", {
										className: "text-xl font-bold text-white",
										children: "Full Station Data Backup"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 407,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "text-xs text-slate-300 leading-relaxed max-w-md mx-auto",
										children: [
											"Export all your bills (",
											bills.length,
											"), customer records (",
											customers.length,
											"), settings, and recent download logs into a single secure file."
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 408,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex justify-center gap-3 pt-2",
										children: /* @__PURE__ */ _jsxDEV("button", {
											onClick: exportAllData,
											className: "bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs px-5 py-2.5 rounded-xl shadow-lg shadow-purple-600/30 transition-all hover:scale-105",
											children: "Download Complete Backup JSON"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 412,
											columnNumber: 19
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 411,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 403,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 402,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 285,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 269,
				columnNumber: 7
			}, this),
			showAuthModal && /* @__PURE__ */ _jsxDEV(AuthModal, {
				currentUser: user,
				onSelectUser: handleSelectUser,
				onClose: () => setShowAuthModal(false)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 427,
				columnNumber: 9
			}, this),
			showShortcutsModal && /* @__PURE__ */ _jsxDEV(ShortcutsModal, { onClose: () => setShowShortcutsModal(false) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 436,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 249,
		columnNumber: 5
	}, this);
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsaUJBQWlCO0FBQzNDLFNBQVMsY0FBYztBQUN2QixTQUFTLGVBQWU7QUFDeEIsU0FBUyxxQkFBcUI7QUFDOUIsU0FBUyxxQkFBcUI7QUFDOUIsU0FBUywwQkFBMEI7QUFDbkMsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyx1QkFBdUI7QUFDaEMsU0FBUyx1QkFBdUI7QUFDaEMsU0FBUyx3QkFBd0I7QUFDakMsU0FBUyw2QkFBNkI7QUFDdEMsU0FBUyx1QkFBdUI7QUFDaEMsU0FBUyxxQkFBcUI7QUFDOUIsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyx1QkFBdUI7QUFDaEMsU0FBUyx5QkFBeUI7QUFDbEMsU0FBUyxpQkFBaUI7QUFDMUIsU0FBUyxzQkFBc0I7QUFTL0IsU0FDRSxjQUNBLGNBQ0EsVUFDQSxVQUNBLFlBQ0EsV0FDQSxXQUNBLGVBQ0EsZUFDQSxlQUNBLHNCQUNBLGVBQ0EscUJBQ0s7QUFDUCxTQUFTLDZCQUE2QjtBQUN0QyxTQUFTLG1CQUFtQjs7O0FBRTVCLGVBQWUsU0FBUyxNQUFNO0NBQzVCLE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFpQixXQUFXO0NBQzlELE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBdUIsWUFBWTtDQUNuRSxNQUFNLENBQUMsTUFBTSxXQUFXLFNBQXNCLFFBQVE7Q0FDdEQsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFxQixTQUFTO0NBQ3hELE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUEyQixhQUFhO0NBQzFFLE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUF5QixhQUFhO0NBQ3hFLE1BQU0sQ0FBQyxxQkFBcUIsMEJBQTBCLFNBQXdCLElBQUk7Q0FFbEYsTUFBTSxDQUFDLGFBQWEsa0JBQWtCLFNBQWlCLEVBQUU7Q0FDekQsTUFBTSxDQUFDLG9CQUFvQix5QkFBeUIsU0FBa0IsS0FBSztDQUMzRSxNQUFNLENBQUMsZUFBZSxvQkFBb0IsU0FBa0IsS0FBSztDQUNqRSxNQUFNLENBQUMsb0JBQW9CLHlCQUF5QixTQUFrQixLQUFLOztDQUczRSxnQkFBZ0I7RUFDZCxJQUFJLENBQUMsS0FBSyxjQUFjLENBQUMsS0FBSyxVQUFVO0VBRXhDLE1BQU0sa0JBQWtCLFlBQVk7R0FDbEMsSUFBSTtJQUNGLE1BQU0sTUFBTSxNQUFNLHNCQUFzQjtLQUN0QyxVQUFVLEtBQUs7S0FDZixhQUFhLEtBQUs7S0FDbEIsTUFBTSxLQUFLO0tBQ1gsT0FBTyxLQUFLO0tBQ1osWUFBWTtLQUNaLGFBQWEsYUFBYTtJQUM1QixDQUFDO0lBRUQsSUFBSSxPQUFPLElBQUksa0JBQWtCO0tBQy9CLElBQUksSUFBSSxxQkFBcUIsK0JBQStCO01BQzFELE1BQU0sK0RBQStEO01BQ3JFLGFBQWE7S0FDZixPQUFPO01BQ0wsdUJBQXVCLElBQUksZ0JBQWdCO01BQzNDLGlCQUFpQix1QkFBdUIsSUFBSSxHQUFHLEdBQUk7S0FDckQ7SUFDRjtHQUNGLFFBQVEsQ0FBQztFQUNYO0VBRUEsZ0JBQWdCO0VBQ2hCLE1BQU0sV0FBVyxZQUFZLGlCQUFpQixHQUFJO0VBQ2xELGFBQWEsY0FBYyxRQUFRO0NBQ3JDLEdBQUc7RUFBQyxLQUFLO0VBQVksS0FBSztFQUFVO0NBQVMsQ0FBQztDQUU5QyxNQUFNLHFCQUFxQixVQUF3QjtFQUNqRCxNQUFNLFVBQVUsQ0FBQyxPQUFPLEdBQUcsU0FBUztFQUNwQyxhQUFhLE9BQU87RUFDcEIsY0FBYyxPQUFPO0NBQ3ZCOztDQUdBLE1BQU0sc0JBQXNCLGdCQUE4QjtFQUN4RCxZQUFZLFdBQVc7RUFDdkIsYUFBYSxXQUFXO0NBQzFCO0NBRUEsTUFBTSxvQkFBb0IsWUFBeUI7RUFDakQsUUFBUSxPQUFPO0VBQ2YsU0FBUyxPQUFPO0NBQ2xCO0NBRUEsTUFBTSxxQkFBcUI7RUFDekIsV0FBVztFQUNYLFFBQVE7R0FDTixVQUFVO0dBQ1YsYUFBYTtHQUNiLE1BQU07R0FDTixPQUFPO0dBQ1AsVUFBVSxTQUFTO0dBQ25CLFlBQVk7RUFDZCxDQUFDO0NBQ0g7Q0FFQSxNQUFNLGlCQUFpQixZQUFzQjtFQUMzQyxNQUFNLFVBQVUsQ0FBQyxTQUFTLEdBQUcsS0FBSztFQUNsQyxTQUFTLE9BQU87RUFDaEIsVUFBVSxPQUFPO0NBQ25CO0NBRUEsTUFBTSxvQkFBb0IsT0FBZTtFQUN2QyxNQUFNLFVBQVUsTUFBTSxRQUFPLE1BQUssRUFBRSxPQUFPLEVBQUU7RUFDN0MsU0FBUyxPQUFPO0VBQ2hCLFVBQVUsT0FBTztDQUNuQjtDQUVBLE1BQU0scUJBQXFCLGdCQUFnQztFQUN6RCxNQUFNLFVBQVUsQ0FBQyxhQUFhLEdBQUcsU0FBUztFQUMxQyxhQUFhLE9BQU87RUFDcEIsY0FBYyxPQUFPO0NBQ3ZCO0NBRUEsTUFBTSw4QkFBOEIsSUFBWSxjQUF3QztFQUN0RixNQUFNLFVBQVUsVUFBVSxLQUFJLE1BQUssRUFBRSxPQUFPLEtBQUs7R0FBRSxHQUFHO0dBQUcsUUFBUTtFQUFVLElBQUksQ0FBQztFQUNoRixhQUFhLE9BQU87RUFDcEIsY0FBYyxPQUFPO0NBQ3ZCO0NBRUEsTUFBTSx3QkFBd0IsT0FBZTtFQUMzQyxNQUFNLFVBQVUsVUFBVSxRQUFPLE1BQUssRUFBRSxPQUFPLEVBQUU7RUFDakQsYUFBYSxPQUFPO0VBQ3BCLGNBQWMsT0FBTztDQUN2QjtDQUVBLE1BQU0sd0JBQXdCLE9BQWU7RUFDM0MscUJBQXFCLEVBQUU7RUFDdkIsYUFBYSxjQUFjLENBQUM7Q0FDOUI7Q0FFQSxNQUFNLDZCQUE2QjtFQUNqQyxhQUFhLFdBQVcsa0JBQWtCO0VBQzFDLGFBQWEsQ0FBQyxDQUFDO0NBQ2pCOztDQUdBLGdCQUFnQjtFQUNkLE1BQU0saUJBQWlCLE1BQXFCOztHQUUxQyxJQUFLLEVBQUUsV0FBVyxFQUFFLFFBQVEsT0FBUyxFQUFFLFFBQVEsT0FBUSxFQUFFLE9BQXVCLFlBQVksV0FBWSxFQUFFLE9BQXVCLFlBQVksWUFBYTtJQUN4SixFQUFFLGVBQWU7SUFDakIsTUFBTSxjQUFjLFNBQVMsZUFBZSxrQkFBa0I7SUFDOUQsYUFBYSxNQUFNO0dBQ3JCOztHQUdBLElBQUksRUFBRSxXQUFXLEVBQUUsUUFBUSxLQUFLO0lBQzlCLEVBQUUsZUFBZTtJQUNqQixhQUFhLFNBQVM7R0FDeEI7O0dBR0EsSUFBSSxFQUFFLFdBQVcsRUFBRSxRQUFRLEtBQUs7SUFDOUIsRUFBRSxlQUFlO0lBQ2pCLE9BQU8sY0FBYyxJQUFJLFlBQVksa0JBQWtCLENBQUM7R0FDMUQ7O0dBR0EsSUFBSSxFQUFFLFdBQVcsRUFBRSxRQUFRLEtBQUs7SUFDOUIsRUFBRSxlQUFlO0lBQ2pCLE9BQU8sY0FBYyxJQUFJLFlBQVksZ0JBQWdCLENBQUM7R0FDeEQ7O0dBR0EsSUFBSSxFQUFFLFdBQVcsRUFBRSxRQUFRLEtBQUs7SUFDOUIsRUFBRSxlQUFlO0lBQ2pCLE9BQU8sY0FBYyxJQUFJLFlBQVksZ0JBQWdCLENBQUM7R0FDeEQ7O0dBR0EsSUFBSSxFQUFFLFFBQVE7SUFDWixNQUFNLFNBQWlDO0tBQ3JDLEtBQUs7S0FDTCxLQUFLO0tBQ0wsS0FBSztLQUNMLEtBQUs7S0FDTCxLQUFLO0tBQ0wsS0FBSztLQUNMLEtBQUs7S0FDTCxLQUFLO0tBQ0wsS0FBSztJQUNQO0lBQ0EsSUFBSSxPQUFPLEVBQUUsTUFBTTtLQUNqQixFQUFFLGVBQWU7S0FDakIsYUFBYSxPQUFPLEVBQUUsSUFBSTtJQUM1QjtHQUNGOztHQUdBLElBQUksRUFBRSxRQUFRLE9BQVEsRUFBRSxPQUF1QixZQUFZLFdBQVksRUFBRSxPQUF1QixZQUFZLFlBQVk7SUFDdEgsc0JBQXNCLElBQUk7R0FDNUI7O0dBR0EsSUFBSSxFQUFFLFFBQVEsVUFBVTtJQUN0QixpQkFBaUIsS0FBSztJQUN0QixzQkFBc0IsS0FBSztHQUM3QjtFQUNGO0VBRUEsT0FBTyxpQkFBaUIsV0FBVyxhQUFhO0VBQ2hELGFBQWEsT0FBTyxvQkFBb0IsV0FBVyxhQUFhO0NBQ2xFLEdBQUcsQ0FBQyxDQUFDOztDQUdMLGdCQUFnQjtFQUNkLElBQUksWUFBWSxLQUFLLENBQUMsQ0FBQyxTQUFTLEtBQUssY0FBYyxhQUFhLGNBQWMsYUFBYTtHQUN6RixhQUFhLFNBQVM7RUFDeEI7Q0FDRixHQUFHLENBQUMsV0FBVyxDQUFDO0NBRWhCLE1BQU0sbUJBQW1CLFVBQVUsUUFBTyxNQUFLLEVBQUUsV0FBVyxhQUFhLEVBQUUsV0FBVyxZQUFZLENBQUMsQ0FBQzs7Q0FHcEcsSUFBSSxDQUFDLEtBQUssWUFBWTtFQUNwQixPQUNFLHdCQUFDLGFBQUQ7R0FDWTtHQUNWLGdCQUFnQjtFQUNqQjs7Ozs7Q0FFTDtDQUVBLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUVFLHdCQUFDLFFBQUQ7SUFDWTtJQUNKO0lBQ0s7SUFDWCxhQUFhLFFBQVE7S0FDbkIsYUFBYSxHQUFHO0tBQ2hCLGVBQWUsRUFBRTtJQUNuQjtJQUNBLG1CQUFtQixpQkFBaUIsSUFBSTtJQUN4Qyx1QkFBdUIsc0JBQXNCLElBQUk7SUFDakQsVUFBVTtJQUNHO0lBQ2IsZ0JBQWdCO0lBQ0k7SUFDcEIsdUJBQXVCLHVCQUFzQixTQUFRLENBQUMsSUFBSTtHQUMzRDs7Ozs7R0FHRCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBRUUsd0JBQUMsU0FBRDtLQUNhO0tBQ1gsYUFBYSxRQUFRO01BQ25CLGFBQWEsR0FBRztNQUNoQixlQUFlLEVBQUU7S0FDbkI7S0FDQSxhQUFhO0tBQ2Isd0JBQXdCLHVCQUFzQixTQUFRLENBQUMsSUFBSTtLQUNyRDtLQUNZO0tBQ2xCLFVBQVU7SUFDWDs7OztjQUdELHdCQUFDLFFBQUQ7S0FBTSxXQUFVO2VBQWhCO01BRUcsdUJBQ0Msd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFVO1FBQVE7Ozs7a0JBQ2xDLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBc0U7UUFBa0M7Ozs7a0JBQ3hILHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUF5QjtRQUF1Qjs7OztnQkFDMUQ7Ozs7Z0JBQ0Y7Ozs7O2lCQUNMLHdCQUFDLFVBQUQ7UUFDRSxlQUFlLHVCQUF1QixJQUFJO1FBQzFDLFdBQVU7a0JBQ1g7T0FFTzs7OztlQUNMOzs7Ozs7TUFHTixjQUFjLGVBQ2Isd0JBQUMsZUFBRDtPQUNTO09BQ0k7T0FDRDtPQUNWLFlBQVk7T0FDWix1QkFBdUIsYUFBYSxTQUFTO09BQzdDLG1CQUFtQixhQUFhLFNBQVM7TUFDMUM7Ozs7O01BR0YsY0FBYyxnQkFDYix3QkFBQyxlQUFELENBQWdCOzs7OztNQUdqQixjQUFjLHFCQUNiLHdCQUFDLG9CQUFELENBQXFCOzs7OztNQUd0QixjQUFjLGdCQUNiLHdCQUFDLGNBQUQsQ0FBZTs7Ozs7TUFHaEIsY0FBYyxhQUNiLHdCQUFDLGlCQUFEO09BQ1M7T0FDRztPQUNWLFdBQVc7T0FDWCxjQUFjO01BQ2Y7Ozs7O01BR0YsY0FBYyxlQUNiLHdCQUFDLGlCQUFEO09BQ2E7T0FDRDtPQUNWLGVBQWU7T0FDZixnQkFBZ0I7T0FDaEIsa0JBQWtCO01BQ25COzs7OztNQUdGLGNBQWMsbUJBQ2Isd0JBQUMsa0JBQUQsQ0FBbUI7Ozs7O01BR3BCLGNBQWMsY0FDYix3QkFBQyxtQkFBRCxFQUFtQixZQUFZLGFBQWU7Ozs7O01BRy9DLGNBQWMsbUJBQ2IsS0FBSyxTQUFTLFVBQ1osd0JBQUMsaUJBQUQ7T0FDWTtPQUNWLGtCQUFrQjtPQUNsQiw0QkFBNEIsYUFBYSxVQUFVO01BQ3BEOzs7O2lCQUVELHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQTJJO1FBRXJKOzs7OztRQUNMLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUFzQztRQUFrQzs7Ozs7UUFDdEYsd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQXlDO1FBRW5EOzs7OztPQUNBOzs7Ozs7TUFJUixjQUFjLGFBQ2Isd0JBQUMsdUJBQUQ7T0FDRSxlQUFlO09BQ2YsWUFBWTtNQUNiOzs7OztNQUdGLGNBQWMsa0JBQ2Isd0JBQUMsaUJBQUQsQ0FBa0I7Ozs7O01BR25CLGNBQWMsZUFDYix3QkFBQyxlQUFEO09BQ2E7T0FDWCxrQkFBa0I7T0FDbEIsWUFBWTtNQUNiOzs7OztNQUdGLGNBQWMsY0FDYix3QkFBQyxjQUFEO09BQ1k7T0FDVixnQkFBZ0I7TUFDakI7Ozs7O01BR0YsY0FBYyxZQUNiLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNiLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQ0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQ2Isd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQVc7VUFBUTs7Ozs7U0FDaEM7Ozs7O1NBQ0wsd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQStCO1NBQTRCOzs7OztTQUN6RSx3QkFBQyxLQUFEO1VBQUcsV0FBVTtvQkFBYjtXQUF1RTtXQUM3QyxNQUFNO1dBQU87V0FBc0IsVUFBVTtXQUFPO1VBQzNFOzs7Ozs7U0FDSCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFDYix3QkFBQyxVQUFEO1dBQ0UsU0FBUztXQUNULFdBQVU7cUJBQ1g7VUFFTzs7Ozs7U0FDTDs7Ozs7UUFDRjs7Ozs7O01BQ0Y7Ozs7O0tBRUg7Ozs7O1lBQ0g7Ozs7OztHQUdKLGlCQUNDLHdCQUFDLFdBQUQ7SUFDRSxhQUFhO0lBQ2IsY0FBYztJQUNkLGVBQWUsaUJBQWlCLEtBQUs7R0FDdEM7Ozs7O0dBSUYsc0JBQ0Msd0JBQUMsZ0JBQUQsRUFDRSxlQUFlLHNCQUFzQixLQUFLLEVBQzNDOzs7OztFQUVBOzs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJBcHAudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgSGVhZGVyIH0gZnJvbSAnLi9jb21wb25lbnRzL0hlYWRlcic7XG5pbXBvcnQgeyBTaWRlYmFyIH0gZnJvbSAnLi9jb21wb25lbnRzL1NpZGViYXInO1xuaW1wb3J0IHsgRGFzaGJvYXJkVmlldyB9IGZyb20gJy4vY29tcG9uZW50cy9EYXNoYm9hcmRWaWV3JztcbmltcG9ydCB7IFB2Y1N0dWRpb1ZpZXcgfSBmcm9tICcuL2NvbXBvbmVudHMvUHZjU3R1ZGlvVmlldyc7XG5pbXBvcnQgeyBQYXNzcG9ydFN0dWRpb1ZpZXcgfSBmcm9tICcuL2NvbXBvbmVudHMvUGFzc3BvcnRTdHVkaW9WaWV3JztcbmltcG9ydCB7IFBkZlRvSnBnVmlldyB9IGZyb20gJy4vY29tcG9uZW50cy9QZGZUb0pwZ1ZpZXcnO1xuaW1wb3J0IHsgQmlsbGluZ0Rlc2tWaWV3IH0gZnJvbSAnLi9jb21wb25lbnRzL0JpbGxpbmdEZXNrVmlldyc7XG5pbXBvcnQgeyBDdXN0b21lckNybVZpZXcgfSBmcm9tICcuL2NvbXBvbmVudHMvQ3VzdG9tZXJDcm1WaWV3JztcbmltcG9ydCB7IEJpb0RhdGFNYWtlclZpZXcgfSBmcm9tICcuL2NvbXBvbmVudHMvQmlvRGF0YU1ha2VyVmlldyc7XG5pbXBvcnQgeyBHb3Zlcm5tZW50UG9ydGFsc1ZpZXcgfSBmcm9tICcuL2NvbXBvbmVudHMvR292ZXJubWVudFBvcnRhbHNWaWV3JztcbmltcG9ydCB7IEFpQXNzaXN0YW50VmlldyB9IGZyb20gJy4vY29tcG9uZW50cy9BaUFzc2lzdGFudFZpZXcnO1xuaW1wb3J0IHsgRG93bmxvYWRzVmlldyB9IGZyb20gJy4vY29tcG9uZW50cy9Eb3dubG9hZHNWaWV3JztcbmltcG9ydCB7IFNldHRpbmdzVmlldyB9IGZyb20gJy4vY29tcG9uZW50cy9TZXR0aW5nc1ZpZXcnO1xuaW1wb3J0IHsgTWFzdGVyQWRtaW5WaWV3IH0gZnJvbSAnLi9jb21wb25lbnRzL01hc3RlckFkbWluVmlldyc7XG5pbXBvcnQgeyBXb3JrZmxvd0d1aWRlVmlldyB9IGZyb20gJy4vY29tcG9uZW50cy9Xb3JrZmxvd0d1aWRlVmlldyc7XG5pbXBvcnQgeyBBdXRoTW9kYWwgfSBmcm9tICcuL2NvbXBvbmVudHMvQXV0aE1vZGFsJztcbmltcG9ydCB7IFNob3J0Y3V0c01vZGFsIH0gZnJvbSAnLi9jb21wb25lbnRzL1Nob3J0Y3V0c01vZGFsJztcblxuaW1wb3J0IHsgXG4gIEJpbGxJdGVtLCBcbiAgQ3VzdG9tZXJSZWNvcmQsIFxuICBEb3dubG9hZEl0ZW0sIFxuICBTaG9wU2V0dGluZ3MsIFxuICBVc2VyQWNjb3VudCBcbn0gZnJvbSAnLi90eXBlcyc7XG5pbXBvcnQgeyBcbiAgbG9hZFNldHRpbmdzLCBcbiAgc2F2ZVNldHRpbmdzLCBcbiAgbG9hZFVzZXIsIFxuICBzYXZlVXNlciwgXG4gIGxvZ291dFVzZXIsXG4gIGxvYWRCaWxscywgXG4gIHNhdmVCaWxscywgXG4gIGxvYWRDdXN0b21lcnMsIFxuICBzYXZlQ3VzdG9tZXJzLCBcbiAgbG9hZERvd25sb2FkcywgXG4gIGRlbGV0ZURvd25sb2FkUmVjb3JkLCBcbiAgZXhwb3J0QWxsRGF0YSxcbiAgc2F2ZURvd25sb2FkcyBcbn0gZnJvbSAnLi91dGlscy9zdG9yYWdlJztcbmltcG9ydCB7IHNlbmRPcGVyYXRvckhlYXJ0YmVhdCB9IGZyb20gJy4vdXRpbHMvZGV2aWNlU2VjdXJpdHknO1xuaW1wb3J0IHsgTG9naW5TY3JlZW4gfSBmcm9tICcuL2NvbXBvbmVudHMvTG9naW5TY3JlZW4nO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBBcHAoKSB7XG4gIGNvbnN0IFthY3RpdmVUYWIsIHNldEFjdGl2ZVRhYl0gPSB1c2VTdGF0ZTxzdHJpbmc+KCdkYXNoYm9hcmQnKTtcbiAgY29uc3QgW3NldHRpbmdzLCBzZXRTZXR0aW5nc10gPSB1c2VTdGF0ZTxTaG9wU2V0dGluZ3M+KGxvYWRTZXR0aW5ncyk7XG4gIGNvbnN0IFt1c2VyLCBzZXRVc2VyXSA9IHVzZVN0YXRlPFVzZXJBY2NvdW50Pihsb2FkVXNlcik7XG4gIGNvbnN0IFtiaWxscywgc2V0QmlsbHNdID0gdXNlU3RhdGU8QmlsbEl0ZW1bXT4obG9hZEJpbGxzKTtcbiAgY29uc3QgW2N1c3RvbWVycywgc2V0Q3VzdG9tZXJzXSA9IHVzZVN0YXRlPEN1c3RvbWVyUmVjb3JkW10+KGxvYWRDdXN0b21lcnMpO1xuICBjb25zdCBbZG93bmxvYWRzLCBzZXREb3dubG9hZHNdID0gdXNlU3RhdGU8RG93bmxvYWRJdGVtW10+KGxvYWREb3dubG9hZHMpO1xuICBjb25zdCBbYWRtaW5Ccm9hZGNhc3RUb2FzdCwgc2V0QWRtaW5Ccm9hZGNhc3RUb2FzdF0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcblxuICBjb25zdCBbc2VhcmNoUXVlcnksIHNldFNlYXJjaFF1ZXJ5XSA9IHVzZVN0YXRlPHN0cmluZz4oJycpO1xuICBjb25zdCBbaXNTaWRlYmFyQ29sbGFwc2VkLCBzZXRJc1NpZGViYXJDb2xsYXBzZWRdID0gdXNlU3RhdGU8Ym9vbGVhbj4oZmFsc2UpO1xuICBjb25zdCBbc2hvd0F1dGhNb2RhbCwgc2V0U2hvd0F1dGhNb2RhbF0gPSB1c2VTdGF0ZTxib29sZWFuPihmYWxzZSk7XG4gIGNvbnN0IFtzaG93U2hvcnRjdXRzTW9kYWwsIHNldFNob3dTaG9ydGN1dHNNb2RhbF0gPSB1c2VTdGF0ZTxib29sZWFuPihmYWxzZSk7XG5cbiAgLy8gTGl2ZSBPcGVyYXRvciBIZWFydGJlYXQgbG9vcFxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmICghdXNlci5pc0xvZ2dlZEluIHx8ICF1c2VyLnVzZXJuYW1lKSByZXR1cm47XG5cbiAgICBjb25zdCByZXBvcnRIZWFydGJlYXQgPSBhc3luYyAoKSA9PiB7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBzZW5kT3BlcmF0b3JIZWFydGJlYXQoe1xuICAgICAgICAgIHVzZXJuYW1lOiB1c2VyLnVzZXJuYW1lLFxuICAgICAgICAgIGRpc3BsYXlOYW1lOiB1c2VyLmRpc3BsYXlOYW1lLFxuICAgICAgICAgIHJvbGU6IHVzZXIucm9sZSxcbiAgICAgICAgICBwaG9uZTogdXNlci5waG9uZSxcbiAgICAgICAgICBjdXJyZW50VGFiOiBhY3RpdmVUYWIsXG4gICAgICAgICAgY3VycmVudFRhc2s6IGBBY3RpdmUgb24gJHthY3RpdmVUYWJ9YFxuICAgICAgICB9KTtcblxuICAgICAgICBpZiAocmVzICYmIHJlcy5icm9hZGNhc3RNZXNzYWdlKSB7XG4gICAgICAgICAgaWYgKHJlcy5icm9hZGNhc3RNZXNzYWdlID09PSAnRk9SQ0VfRElTQ09OTkVDVEVEX0JZX0FETUlOJykge1xuICAgICAgICAgICAgYWxlcnQoJ/CfmqggWW91ciB3b3Jrc3RhdGlvbiBzZXNzaW9uIHdhcyBkaXNjb25uZWN0ZWQgYnkgTWFzdGVyIEFkbWluLicpO1xuICAgICAgICAgICAgaGFuZGxlTG9nb3V0KCk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHNldEFkbWluQnJvYWRjYXN0VG9hc3QocmVzLmJyb2FkY2FzdE1lc3NhZ2UpO1xuICAgICAgICAgICAgc2V0VGltZW91dCgoKSA9PiBzZXRBZG1pbkJyb2FkY2FzdFRvYXN0KG51bGwpLCA4MDAwKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH0gY2F0Y2gge31cbiAgICB9O1xuXG4gICAgcmVwb3J0SGVhcnRiZWF0KCk7XG4gICAgY29uc3QgaW50ZXJ2YWwgPSBzZXRJbnRlcnZhbChyZXBvcnRIZWFydGJlYXQsIDUwMDApO1xuICAgIHJldHVybiAoKSA9PiBjbGVhckludGVydmFsKGludGVydmFsKTtcbiAgfSwgW3VzZXIuaXNMb2dnZWRJbiwgdXNlci51c2VybmFtZSwgYWN0aXZlVGFiXSk7XG5cbiAgY29uc3QgaGFuZGxlQWRkRG93bmxvYWQgPSAobmV3RGw6IERvd25sb2FkSXRlbSkgPT4ge1xuICAgIGNvbnN0IHVwZGF0ZWQgPSBbbmV3RGwsIC4uLmRvd25sb2Fkc107XG4gICAgc2V0RG93bmxvYWRzKHVwZGF0ZWQpO1xuICAgIHNhdmVEb3dubG9hZHModXBkYXRlZCk7XG4gIH07XG5cbiAgLy8gU3luYyB0byBzdG9yYWdlXG4gIGNvbnN0IGhhbmRsZVNhdmVTZXR0aW5ncyA9IChuZXdTZXR0aW5nczogU2hvcFNldHRpbmdzKSA9PiB7XG4gICAgc2V0U2V0dGluZ3MobmV3U2V0dGluZ3MpO1xuICAgIHNhdmVTZXR0aW5ncyhuZXdTZXR0aW5ncyk7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlU2VsZWN0VXNlciA9IChuZXdVc2VyOiBVc2VyQWNjb3VudCkgPT4ge1xuICAgIHNldFVzZXIobmV3VXNlcik7XG4gICAgc2F2ZVVzZXIobmV3VXNlcik7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlTG9nb3V0ID0gKCkgPT4ge1xuICAgIGxvZ291dFVzZXIoKTtcbiAgICBzZXRVc2VyKHtcbiAgICAgIHVzZXJuYW1lOiAnJyxcbiAgICAgIGRpc3BsYXlOYW1lOiAnJyxcbiAgICAgIHJvbGU6ICdvcGVyYXRvcicsXG4gICAgICBwaG9uZTogJycsXG4gICAgICBzaG9wTmFtZTogc2V0dGluZ3Muc2hvcE5hbWUsXG4gICAgICBpc0xvZ2dlZEluOiBmYWxzZVxuICAgIH0pO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZUFkZEJpbGwgPSAobmV3QmlsbDogQmlsbEl0ZW0pID0+IHtcbiAgICBjb25zdCB1cGRhdGVkID0gW25ld0JpbGwsIC4uLmJpbGxzXTtcbiAgICBzZXRCaWxscyh1cGRhdGVkKTtcbiAgICBzYXZlQmlsbHModXBkYXRlZCk7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlRGVsZXRlQmlsbCA9IChpZDogc3RyaW5nKSA9PiB7XG4gICAgY29uc3QgdXBkYXRlZCA9IGJpbGxzLmZpbHRlcihiID0+IGIuaWQgIT09IGlkKTtcbiAgICBzZXRCaWxscyh1cGRhdGVkKTtcbiAgICBzYXZlQmlsbHModXBkYXRlZCk7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlQWRkQ3VzdG9tZXIgPSAobmV3Q3VzdG9tZXI6IEN1c3RvbWVyUmVjb3JkKSA9PiB7XG4gICAgY29uc3QgdXBkYXRlZCA9IFtuZXdDdXN0b21lciwgLi4uY3VzdG9tZXJzXTtcbiAgICBzZXRDdXN0b21lcnModXBkYXRlZCk7XG4gICAgc2F2ZUN1c3RvbWVycyh1cGRhdGVkKTtcbiAgfTtcblxuICBjb25zdCBoYW5kbGVVcGRhdGVDdXN0b21lclN0YXR1cyA9IChpZDogc3RyaW5nLCBuZXdTdGF0dXM6IEN1c3RvbWVyUmVjb3JkWydzdGF0dXMnXSkgPT4ge1xuICAgIGNvbnN0IHVwZGF0ZWQgPSBjdXN0b21lcnMubWFwKGMgPT4gYy5pZCA9PT0gaWQgPyB7IC4uLmMsIHN0YXR1czogbmV3U3RhdHVzIH0gOiBjKTtcbiAgICBzZXRDdXN0b21lcnModXBkYXRlZCk7XG4gICAgc2F2ZUN1c3RvbWVycyh1cGRhdGVkKTtcbiAgfTtcblxuICBjb25zdCBoYW5kbGVEZWxldGVDdXN0b21lciA9IChpZDogc3RyaW5nKSA9PiB7XG4gICAgY29uc3QgdXBkYXRlZCA9IGN1c3RvbWVycy5maWx0ZXIoYyA9PiBjLmlkICE9PSBpZCk7XG4gICAgc2V0Q3VzdG9tZXJzKHVwZGF0ZWQpO1xuICAgIHNhdmVDdXN0b21lcnModXBkYXRlZCk7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlRGVsZXRlRG93bmxvYWQgPSAoaWQ6IHN0cmluZykgPT4ge1xuICAgIGRlbGV0ZURvd25sb2FkUmVjb3JkKGlkKTtcbiAgICBzZXREb3dubG9hZHMobG9hZERvd25sb2FkcygpKTtcbiAgfTtcblxuICBjb25zdCBoYW5kbGVDbGVhckRvd25sb2FkcyA9ICgpID0+IHtcbiAgICBsb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbSgnbW9zX3BjX2Rvd25sb2FkcycpO1xuICAgIHNldERvd25sb2FkcyhbXSk7XG4gIH07XG5cbiAgLy8gS2V5Ym9hcmQgU2hvcnRjdXRzIGZvciBQQ1xuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IGhhbmRsZUtleURvd24gPSAoZTogS2V5Ym9hcmRFdmVudCkgPT4ge1xuICAgICAgLy8gRm9jdXMgc2VhcmNoOiBDdHJsICsgSyBvciAnLydcbiAgICAgIGlmICgoZS5jdHJsS2V5ICYmIGUua2V5ID09PSAnaycpIHx8IChlLmtleSA9PT0gJy8nICYmIChlLnRhcmdldCBhcyBIVE1MRWxlbWVudCkudGFnTmFtZSAhPT0gJ0lOUFVUJyAmJiAoZS50YXJnZXQgYXMgSFRNTEVsZW1lbnQpLnRhZ05hbWUgIT09ICdURVhUQVJFQScpKSB7XG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgY29uc3Qgc2VhcmNoSW5wdXQgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgncGMtZ2xvYmFsLXNlYXJjaCcpO1xuICAgICAgICBzZWFyY2hJbnB1dD8uZm9jdXMoKTtcbiAgICAgIH1cblxuICAgICAgLy8gRmFzdCBCaWxsOiBDdHJsICsgQlxuICAgICAgaWYgKGUuY3RybEtleSAmJiBlLmtleSA9PT0gJ2InKSB7XG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgc2V0QWN0aXZlVGFiKCdiaWxsaW5nJyk7XG4gICAgICB9XG5cbiAgICAgIC8vIERpcmVjdCBJbi1BcHAgU3R1ZGlvIFByaW50OiBDdHJsICsgUFxuICAgICAgaWYgKGUuY3RybEtleSAmJiBlLmtleSA9PT0gJ3AnKSB7XG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgd2luZG93LmRpc3BhdGNoRXZlbnQobmV3IEN1c3RvbUV2ZW50KCdhcHAtZGlyZWN0LXByaW50JykpO1xuICAgICAgfVxuXG4gICAgICAvLyBEaXJlY3QgSW4tQXBwIFBERiBEb3dubG9hZDogQ3RybCArIFNcbiAgICAgIGlmIChlLmN0cmxLZXkgJiYgZS5rZXkgPT09ICdzJykge1xuICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgIHdpbmRvdy5kaXNwYXRjaEV2ZW50KG5ldyBDdXN0b21FdmVudCgnYXBwLWRpcmVjdC1wZGYnKSk7XG4gICAgICB9XG5cbiAgICAgIC8vIERpcmVjdCBJbi1BcHAgSEQgSlBHIERvd25sb2FkOiBDdHJsICsgSlxuICAgICAgaWYgKGUuY3RybEtleSAmJiBlLmtleSA9PT0gJ2onKSB7XG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgd2luZG93LmRpc3BhdGNoRXZlbnQobmV3IEN1c3RvbUV2ZW50KCdhcHAtZGlyZWN0LWpwZycpKTtcbiAgICAgIH1cblxuICAgICAgLy8gVGFiIHN3aXRjaGVyOiBBbHQgKyAxIHRvIDlcbiAgICAgIGlmIChlLmFsdEtleSkge1xuICAgICAgICBjb25zdCB0YWJNYXA6IFJlY29yZDxzdHJpbmcsIHN0cmluZz4gPSB7XG4gICAgICAgICAgJzEnOiAnZGFzaGJvYXJkJyxcbiAgICAgICAgICAnMic6ICdwdmNfc3R1ZGlvJyxcbiAgICAgICAgICAnMyc6ICdwYXNzcG9ydF9zdHVkaW8nLFxuICAgICAgICAgICc0JzogJ3BkZl90b19qcGcnLFxuICAgICAgICAgICc1JzogJ2JpbGxpbmcnLFxuICAgICAgICAgICc2JzogJ2N1c3RvbWVycycsXG4gICAgICAgICAgJzcnOiAnYmlvZGF0YV9tYWtlcicsXG4gICAgICAgICAgJzgnOiAncG9ydGFscycsXG4gICAgICAgICAgJzknOiAnYWlfYXNzaXN0YW50J1xuICAgICAgICB9O1xuICAgICAgICBpZiAodGFiTWFwW2Uua2V5XSkge1xuICAgICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgICBzZXRBY3RpdmVUYWIodGFiTWFwW2Uua2V5XSk7XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgLy8gU2hvcnRjdXRzIE1vZGFsOiAnPydcbiAgICAgIGlmIChlLmtleSA9PT0gJz8nICYmIChlLnRhcmdldCBhcyBIVE1MRWxlbWVudCkudGFnTmFtZSAhPT0gJ0lOUFVUJyAmJiAoZS50YXJnZXQgYXMgSFRNTEVsZW1lbnQpLnRhZ05hbWUgIT09ICdURVhUQVJFQScpIHtcbiAgICAgICAgc2V0U2hvd1Nob3J0Y3V0c01vZGFsKHRydWUpO1xuICAgICAgfVxuXG4gICAgICAvLyBFc2NhcGUgdG8gY2xvc2UgbW9kYWxzXG4gICAgICBpZiAoZS5rZXkgPT09ICdFc2NhcGUnKSB7XG4gICAgICAgIHNldFNob3dBdXRoTW9kYWwoZmFsc2UpO1xuICAgICAgICBzZXRTaG93U2hvcnRjdXRzTW9kYWwoZmFsc2UpO1xuICAgICAgfVxuICAgIH07XG5cbiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcigna2V5ZG93bicsIGhhbmRsZUtleURvd24pO1xuICAgIHJldHVybiAoKSA9PiB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcigna2V5ZG93bicsIGhhbmRsZUtleURvd24pO1xuICB9LCBbXSk7XG5cbiAgLy8gV2hlbiBnbG9iYWwgc2VhcmNoIGlzIHR5cGVkLCBhdXRvbWF0aWNhbGx5IHN3aXRjaCB0byBwb3J0YWxzIG9yIHNob3cgbWF0Y2hlcyBpZiBub3QgZW1wdHlcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoc2VhcmNoUXVlcnkudHJpbSgpLmxlbmd0aCA+IDEgJiYgYWN0aXZlVGFiICE9PSAncG9ydGFscycgJiYgYWN0aXZlVGFiICE9PSAnZGFzaGJvYXJkJykge1xuICAgICAgc2V0QWN0aXZlVGFiKCdwb3J0YWxzJyk7XG4gICAgfVxuICB9LCBbc2VhcmNoUXVlcnldKTtcblxuICBjb25zdCBwZW5kaW5nSm9ic0NvdW50ID0gY3VzdG9tZXJzLmZpbHRlcihjID0+IGMuc3RhdHVzID09PSAnUGVuZGluZycgfHwgYy5zdGF0dXMgPT09ICdQcm9jZXNzaW5nJykubGVuZ3RoO1xuXG4gIC8vIFNUUklDVCBMT0dJTiBXQUxMOiBOb3RoaW5nIHdvcmtzIG9yIGRpc3BsYXlzIHdpdGhvdXQgYXV0aGVudGljYXRpb24hXG4gIGlmICghdXNlci5pc0xvZ2dlZEluKSB7XG4gICAgcmV0dXJuIChcbiAgICAgIDxMb2dpblNjcmVlblxuICAgICAgICBzZXR0aW5ncz17c2V0dGluZ3N9XG4gICAgICAgIG9uTG9naW5TdWNjZXNzPXtoYW5kbGVTZWxlY3RVc2VyfVxuICAgICAgLz5cbiAgICApO1xuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgaC1zY3JlZW4gdy1zY3JlZW4gYmctc2xhdGUtOTUwIHRleHQtc2xhdGUtMTAwIG92ZXJmbG93LWhpZGRlbiBmb250LXNhbnMgc2VsZWN0aW9uOmJnLWJsdWUtNjAwIHNlbGVjdGlvbjp0ZXh0LXdoaXRlXCI+XG4gICAgICB7LyogUEMgVG9wIE5hdmlnYXRpb24gSGVhZGVyICovfVxuICAgICAgPEhlYWRlclxuICAgICAgICBzZXR0aW5ncz17c2V0dGluZ3N9XG4gICAgICAgIHVzZXI9e3VzZXJ9XG4gICAgICAgIGFjdGl2ZVRhYj17YWN0aXZlVGFifVxuICAgICAgICBvbk5hdmlnYXRlPXsodGFiKSA9PiB7XG4gICAgICAgICAgc2V0QWN0aXZlVGFiKHRhYik7XG4gICAgICAgICAgc2V0U2VhcmNoUXVlcnkoJycpO1xuICAgICAgICB9fVxuICAgICAgICBvbk9wZW5Mb2dpbj17KCkgPT4gc2V0U2hvd0F1dGhNb2RhbCh0cnVlKX1cbiAgICAgICAgb25PcGVuU2hvcnRjdXRzPXsoKSA9PiBzZXRTaG93U2hvcnRjdXRzTW9kYWwodHJ1ZSl9XG4gICAgICAgIG9uTG9nb3V0PXtoYW5kbGVMb2dvdXR9XG4gICAgICAgIHNlYXJjaFF1ZXJ5PXtzZWFyY2hRdWVyeX1cbiAgICAgICAgb25TZWFyY2hDaGFuZ2U9e3NldFNlYXJjaFF1ZXJ5fVxuICAgICAgICBpc1NpZGViYXJDb2xsYXBzZWQ9e2lzU2lkZWJhckNvbGxhcHNlZH1cbiAgICAgICAgb25Ub2dnbGVTaWRlYmFyPXsoKSA9PiBzZXRJc1NpZGViYXJDb2xsYXBzZWQocHJldiA9PiAhcHJldil9XG4gICAgICAvPlxuXG4gICAgICB7LyogTWFpbiBDb250YWluZXI6IFNpZGViYXIgKyBXb3Jrc3BhY2UgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC0xIG92ZXJmbG93LWhpZGRlbiByZWxhdGl2ZVwiPlxuICAgICAgICB7LyogUEMgU2lkZWJhciBOYXZpZ2F0aW9uICovfVxuICAgICAgICA8U2lkZWJhclxuICAgICAgICAgIGFjdGl2ZVRhYj17YWN0aXZlVGFifVxuICAgICAgICAgIG9uTmF2aWdhdGU9eyh0YWIpID0+IHtcbiAgICAgICAgICAgIHNldEFjdGl2ZVRhYih0YWIpO1xuICAgICAgICAgICAgc2V0U2VhcmNoUXVlcnkoJycpO1xuICAgICAgICAgIH19XG4gICAgICAgICAgaXNDb2xsYXBzZWQ9e2lzU2lkZWJhckNvbGxhcHNlZH1cbiAgICAgICAgICBvblRvZ2dsZUNvbGxhcHNlPXsoKSA9PiBzZXRJc1NpZGViYXJDb2xsYXBzZWQocHJldiA9PiAhcHJldil9XG4gICAgICAgICAgdXNlcj17dXNlcn1cbiAgICAgICAgICBwZW5kaW5nSm9ic0NvdW50PXtwZW5kaW5nSm9ic0NvdW50fVxuICAgICAgICAgIG9uTG9nb3V0PXtoYW5kbGVMb2dvdXR9XG4gICAgICAgIC8+XG5cbiAgICAgICAgey8qIE1haW4gV29ya3N0YXRpb24gVmlldyBBcmVhICovfVxuICAgICAgICA8bWFpbiBjbGFzc05hbWU9XCJmbGV4LTEgb3ZlcmZsb3cteS1hdXRvIHAtNCBsZzpwLTYgYmctc2xhdGUtOTUwIHJlbGF0aXZlXCI+XG4gICAgICAgICAgey8qIEFkbWluIExpdmUgQnJvYWRjYXN0IFRvYXN0ICovfVxuICAgICAgICAgIHthZG1pbkJyb2FkY2FzdFRvYXN0ICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNCBwLTQgcm91bmRlZC0yeGwgYmctZ3JhZGllbnQtdG8tciBmcm9tLWJsdWUtNjAwIHRvLWluZGlnby02MDAgdGV4dC13aGl0ZSBzaGFkb3cteGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zIGFuaW1hdGUtaW4gZmFkZS1pbiBzbGlkZS1pbi1mcm9tLXRvcC00IHotMzBcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteGxcIj7wn5OiPC9zcGFuPlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWV4dHJhYm9sZCB0ZXh0LXhzIGJsb2NrIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LWJsdWUtMjAwXCI+QnJvYWRjYXN0IGZyb20gTWFzdGVyIEFkbWluOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZFwiPnthZG1pbkJyb2FkY2FzdFRvYXN0fTwvcD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxidXR0b24gXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QWRtaW5Ccm9hZGNhc3RUb2FzdChudWxsKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXdoaXRlLzgwIGhvdmVyOnRleHQtd2hpdGUgcHgtMiBweS0xIGJnLXdoaXRlLzEwIHJvdW5kZWQtbGcgdGV4dC14cyBmb250LWJvbGRcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgRGlzbWlzc1xuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICB7YWN0aXZlVGFiID09PSAnZGFzaGJvYXJkJyAmJiAoXG4gICAgICAgICAgICA8RGFzaGJvYXJkVmlld1xuICAgICAgICAgICAgICBiaWxscz17YmlsbHN9XG4gICAgICAgICAgICAgIGN1c3RvbWVycz17Y3VzdG9tZXJzfVxuICAgICAgICAgICAgICBzZXR0aW5ncz17c2V0dGluZ3N9XG4gICAgICAgICAgICAgIG9uTmF2aWdhdGU9e3NldEFjdGl2ZVRhYn1cbiAgICAgICAgICAgICAgb25PcGVuUXVpY2tCaWxsPXsoKSA9PiBzZXRBY3RpdmVUYWIoJ2JpbGxpbmcnKX1cbiAgICAgICAgICAgICAgb25QcmludEJpbGw9eygpID0+IHNldEFjdGl2ZVRhYignYmlsbGluZycpfVxuICAgICAgICAgICAgLz5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAge2FjdGl2ZVRhYiA9PT0gJ3B2Y19zdHVkaW8nICYmIChcbiAgICAgICAgICAgIDxQdmNTdHVkaW9WaWV3IC8+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIHthY3RpdmVUYWIgPT09ICdwYXNzcG9ydF9zdHVkaW8nICYmIChcbiAgICAgICAgICAgIDxQYXNzcG9ydFN0dWRpb1ZpZXcgLz5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAge2FjdGl2ZVRhYiA9PT0gJ3BkZl90b19qcGcnICYmIChcbiAgICAgICAgICAgIDxQZGZUb0pwZ1ZpZXcgLz5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAge2FjdGl2ZVRhYiA9PT0gJ2JpbGxpbmcnICYmIChcbiAgICAgICAgICAgIDxCaWxsaW5nRGVza1ZpZXdcbiAgICAgICAgICAgICAgYmlsbHM9e2JpbGxzfVxuICAgICAgICAgICAgICBzZXR0aW5ncz17c2V0dGluZ3N9XG4gICAgICAgICAgICAgIG9uQWRkQmlsbD17aGFuZGxlQWRkQmlsbH1cbiAgICAgICAgICAgICAgb25EZWxldGVCaWxsPXtoYW5kbGVEZWxldGVCaWxsfVxuICAgICAgICAgICAgLz5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAge2FjdGl2ZVRhYiA9PT0gJ2N1c3RvbWVycycgJiYgKFxuICAgICAgICAgICAgPEN1c3RvbWVyQ3JtVmlld1xuICAgICAgICAgICAgICBjdXN0b21lcnM9e2N1c3RvbWVyc31cbiAgICAgICAgICAgICAgc2V0dGluZ3M9e3NldHRpbmdzfVxuICAgICAgICAgICAgICBvbkFkZEN1c3RvbWVyPXtoYW5kbGVBZGRDdXN0b21lcn1cbiAgICAgICAgICAgICAgb25VcGRhdGVTdGF0dXM9e2hhbmRsZVVwZGF0ZUN1c3RvbWVyU3RhdHVzfVxuICAgICAgICAgICAgICBvbkRlbGV0ZUN1c3RvbWVyPXtoYW5kbGVEZWxldGVDdXN0b21lcn1cbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIHthY3RpdmVUYWIgPT09ICdiaW9kYXRhX21ha2VyJyAmJiAoXG4gICAgICAgICAgICA8QmlvRGF0YU1ha2VyVmlldyAvPlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICB7YWN0aXZlVGFiID09PSAnd29ya2Zsb3cnICYmIChcbiAgICAgICAgICAgIDxXb3JrZmxvd0d1aWRlVmlldyBvbk5hdmlnYXRlPXtzZXRBY3RpdmVUYWJ9IC8+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIHthY3RpdmVUYWIgPT09ICdtYXN0ZXJfYWRtaW4nICYmIChcbiAgICAgICAgICAgIHVzZXIucm9sZSA9PT0gJ2FkbWluJyA/IChcbiAgICAgICAgICAgICAgPE1hc3RlckFkbWluVmlld1xuICAgICAgICAgICAgICAgIHNldHRpbmdzPXtzZXR0aW5nc31cbiAgICAgICAgICAgICAgICBvblVwZGF0ZVNldHRpbmdzPXtoYW5kbGVTYXZlU2V0dGluZ3N9XG4gICAgICAgICAgICAgICAgb25OYXZpZ2F0ZVRvV29ya2Zsb3c9eygpID0+IHNldEFjdGl2ZVRhYignd29ya2Zsb3cnKX1cbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWF4LXctbWQgbXgtYXV0byB0ZXh0LWNlbnRlciBwLTggYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtM3hsIG10LTEyIHNwYWNlLXktMyBzaGFkb3ctMnhsXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEyIGgtMTIgYmctcm9zZS01MDAvMjAgdGV4dC1yb3NlLTQwMCByb3VuZGVkLTJ4bCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBteC1hdXRvIHRleHQtMnhsIGZvbnQtYm9sZCBib3JkZXIgYm9yZGVyLXJvc2UtNTAwLzMwXCI+XG4gICAgICAgICAgICAgICAgICDwn5SSXG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LWV4dHJhYm9sZCB0ZXh0LXdoaXRlXCI+TWFzdGVyIEFkbWluIFJlc3RyaWN0ZWQgQWNjZXNzPC9oMz5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwIGxlYWRpbmctcmVsYXhlZFwiPlxuICAgICAgICAgICAgICAgICAgQWNjZXNzIERlbmllZC4gVGhlIHByb2plY3Qgc291cmNlIC5aSVAgYXJjaGl2ZSwgZXhlY3V0YWJsZSBzZXR1cCBidWlsZGVyLCBhbmQgY2VudHJhbCBzZWN1cml0eSBjb250cm9scyBhcmUgc3RyaWN0bHkgcmVzZXJ2ZWQgZm9yIE1hc3RlciBBZG1pbiAoSW1yYW4gS2hhbikuIFN0YWZmIG9wZXJhdG9ycyBvciBjdXN0b21lcnMgY2Fubm90IHZpZXcgb3IgZG93bmxvYWQgdGhpcyBkYXRhLlxuICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApXG4gICAgICAgICAgKX1cblxuICAgICAgICAgIHthY3RpdmVUYWIgPT09ICdwb3J0YWxzJyAmJiAoXG4gICAgICAgICAgICA8R292ZXJubWVudFBvcnRhbHNWaWV3IFxuICAgICAgICAgICAgICBvbkFkZERvd25sb2FkPXtoYW5kbGVBZGREb3dubG9hZH1cbiAgICAgICAgICAgICAgb25OYXZpZ2F0ZT17c2V0QWN0aXZlVGFifVxuICAgICAgICAgICAgLz5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAge2FjdGl2ZVRhYiA9PT0gJ2FpX2Fzc2lzdGFudCcgJiYgKFxuICAgICAgICAgICAgPEFpQXNzaXN0YW50VmlldyAvPlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICB7YWN0aXZlVGFiID09PSAnZG93bmxvYWRzJyAmJiAoXG4gICAgICAgICAgICA8RG93bmxvYWRzVmlld1xuICAgICAgICAgICAgICBkb3dubG9hZHM9e2Rvd25sb2Fkc31cbiAgICAgICAgICAgICAgb25EZWxldGVEb3dubG9hZD17aGFuZGxlRGVsZXRlRG93bmxvYWR9XG4gICAgICAgICAgICAgIG9uQ2xlYXJBbGw9e2hhbmRsZUNsZWFyRG93bmxvYWRzfVxuICAgICAgICAgICAgLz5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAge2FjdGl2ZVRhYiA9PT0gJ3NldHRpbmdzJyAmJiAoXG4gICAgICAgICAgICA8U2V0dGluZ3NWaWV3XG4gICAgICAgICAgICAgIHNldHRpbmdzPXtzZXR0aW5nc31cbiAgICAgICAgICAgICAgb25TYXZlU2V0dGluZ3M9e2hhbmRsZVNhdmVTZXR0aW5nc31cbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIHthY3RpdmVUYWIgPT09ICdiYWNrdXAnICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWF4LXctMnhsIG14LWF1dG8gc3BhY2UteS00IHB0LTZcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcC02IHJvdW5kZWQtM3hsIHNoYWRvdy14bCB0ZXh0LWNlbnRlciBzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTYgaC0xNiByb3VuZGVkLTJ4bCBiZy1wdXJwbGUtNjAwLzIwIGJvcmRlciBib3JkZXItcHVycGxlLTUwMC8zMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0ZXh0LXB1cnBsZS00MDAgbXgtYXV0b1wiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC0zeGxcIj7wn5K+PC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LXdoaXRlXCI+RnVsbCBTdGF0aW9uIERhdGEgQmFja3VwPC9oMj5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtMzAwIGxlYWRpbmctcmVsYXhlZCBtYXgtdy1tZCBteC1hdXRvXCI+XG4gICAgICAgICAgICAgICAgICBFeHBvcnQgYWxsIHlvdXIgYmlsbHMgKHtiaWxscy5sZW5ndGh9KSwgY3VzdG9tZXIgcmVjb3JkcyAoe2N1c3RvbWVycy5sZW5ndGh9KSwgc2V0dGluZ3MsIGFuZCByZWNlbnQgZG93bmxvYWQgbG9ncyBpbnRvIGEgc2luZ2xlIHNlY3VyZSBmaWxlLlxuICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgZ2FwLTMgcHQtMlwiPlxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtleHBvcnRBbGxEYXRhfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1wdXJwbGUtNjAwIGhvdmVyOmJnLXB1cnBsZS01MDAgdGV4dC13aGl0ZSBmb250LWJvbGQgdGV4dC14cyBweC01IHB5LTIuNSByb3VuZGVkLXhsIHNoYWRvdy1sZyBzaGFkb3ctcHVycGxlLTYwMC8zMCB0cmFuc2l0aW9uLWFsbCBob3ZlcjpzY2FsZS0xMDVcIlxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICBEb3dubG9hZCBDb21wbGV0ZSBCYWNrdXAgSlNPTlxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9tYWluPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBBdXRoIE1vZGFsICovfVxuICAgICAge3Nob3dBdXRoTW9kYWwgJiYgKFxuICAgICAgICA8QXV0aE1vZGFsXG4gICAgICAgICAgY3VycmVudFVzZXI9e3VzZXJ9XG4gICAgICAgICAgb25TZWxlY3RVc2VyPXtoYW5kbGVTZWxlY3RVc2VyfVxuICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldFNob3dBdXRoTW9kYWwoZmFsc2UpfVxuICAgICAgICAvPlxuICAgICAgKX1cblxuICAgICAgey8qIFNob3J0Y3V0cyBNb2RhbCAqL31cbiAgICAgIHtzaG93U2hvcnRjdXRzTW9kYWwgJiYgKFxuICAgICAgICA8U2hvcnRjdXRzTW9kYWxcbiAgICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRTaG93U2hvcnRjdXRzTW9kYWwoZmFsc2UpfVxuICAgICAgICAvPlxuICAgICAgKX1cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdfQ==