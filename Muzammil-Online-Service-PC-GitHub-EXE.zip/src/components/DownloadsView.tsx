const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=1d04f0f2";
import { Download, Trash2, FileText, CreditCard, Camera, FileImage, Receipt, Clock } from "/node_modules/.vite/deps/lucide-react.js?v=1d04f0f2";
var _jsxFileName = "/app/applet/src/components/DownloadsView.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=1d04f0f2";
export const DownloadsView = ({ downloads, onDeleteDownload, onClearAll }) => {
	const getIcon = (type) => {
		switch (type) {
			case "PVC Card PDF":
			case "PVC Card JPG": return /* @__PURE__ */ _jsxDEV(CreditCard, { className: "w-5 h-5 text-blue-400" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 29,
				columnNumber: 16
			}, this);
			case "Passport Sheet PDF":
			case "Passport Sheet JPG": return /* @__PURE__ */ _jsxDEV(Camera, { className: "w-5 h-5 text-purple-400" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 32,
				columnNumber: 16
			}, this);
			case "BioData PDF": return /* @__PURE__ */ _jsxDEV(FileText, { className: "w-5 h-5 text-indigo-400" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 34,
				columnNumber: 16
			}, this);
			case "Converted JPG": return /* @__PURE__ */ _jsxDEV(FileImage, { className: "w-5 h-5 text-amber-400" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 36,
				columnNumber: 16
			}, this);
			default: return /* @__PURE__ */ _jsxDEV(Receipt, { className: "w-5 h-5 text-emerald-400" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 38,
				columnNumber: 16
			}, this);
		}
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "space-y-4 max-w-5xl mx-auto",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900 border border-slate-800 p-4 rounded-2xl shadow-md",
			children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center gap-2",
				children: [/* @__PURE__ */ _jsxDEV("h1", {
					className: "text-xl font-extrabold text-white",
					children: "Generated Downloads & Print History"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 48,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("span", {
					className: "bg-blue-500/20 text-blue-400 border border-blue-500/30 text-xs px-2 py-0.5 rounded-full font-mono font-bold",
					children: [downloads.length, " Files"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 49,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 47,
				columnNumber: 11
			}, this), /* @__PURE__ */ _jsxDEV("p", {
				className: "text-xs text-slate-400 mt-0.5",
				children: "Log of all generated PVC cards, passport sheets, converted PDFs, and receipts created on this PC"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 53,
				columnNumber: 11
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 46,
				columnNumber: 9
			}, this), downloads.length > 0 && /* @__PURE__ */ _jsxDEV("button", {
				onClick: onClearAll,
				className: "flex items-center gap-1.5 bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/30 text-xs font-bold px-3 py-2 rounded-xl transition-colors",
				children: [/* @__PURE__ */ _jsxDEV(Trash2, { className: "w-4 h-4" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 63,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Clear History" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 64,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 59,
				columnNumber: 11
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 45,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-md",
			children: downloads.length === 0 ? /* @__PURE__ */ _jsxDEV("div", {
				className: "p-12 text-center text-slate-500 text-xs space-y-2",
				children: [
					/* @__PURE__ */ _jsxDEV(Download, { className: "w-10 h-10 mx-auto text-slate-600" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 73,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "font-bold text-slate-400 text-sm",
						children: "No Downloads Logged Yet"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 74,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("p", { children: "Generated PVC cards, passport photo sheets, and converted PDFs will be listed here." }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 75,
						columnNumber: 13
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 72,
				columnNumber: 11
			}, this) : /* @__PURE__ */ _jsxDEV("div", {
				className: "divide-y divide-slate-800",
				children: downloads.map((item) => /* @__PURE__ */ _jsxDEV("div", {
					className: "p-4 flex items-center justify-between gap-4 hover:bg-slate-800/40 transition-colors",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-3 min-w-0",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "w-10 h-10 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-center flex-shrink-0 shadow-inner",
							children: getIcon(item.type)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 85,
							columnNumber: 19
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ _jsxDEV("h4", {
								className: "text-xs font-bold text-white truncate",
								children: item.title
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 89,
								columnNumber: 21
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2 text-[11px] text-slate-400 font-mono mt-0.5",
								children: [
									/* @__PURE__ */ _jsxDEV("span", { children: item.type }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 91,
										columnNumber: 23
									}, this),
									/* @__PURE__ */ _jsxDEV("span", { children: "•" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 92,
										columnNumber: 23
									}, this),
									/* @__PURE__ */ _jsxDEV("span", { children: item.size }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 93,
										columnNumber: 23
									}, this),
									/* @__PURE__ */ _jsxDEV("span", { children: "•" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 94,
										columnNumber: 23
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "flex items-center gap-1",
										children: [/* @__PURE__ */ _jsxDEV(Clock, { className: "w-3 h-3 text-slate-500" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 96,
											columnNumber: 25
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: item.timestamp }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 97,
											columnNumber: 25
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 95,
										columnNumber: 23
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 90,
								columnNumber: 21
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 88,
							columnNumber: 19
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 84,
						columnNumber: 17
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-2",
						children: /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => onDeleteDownload(item.id),
							title: "Remove record",
							className: "p-2 text-slate-500 hover:text-rose-400 rounded-lg hover:bg-slate-800 transition-colors",
							children: /* @__PURE__ */ _jsxDEV(Trash2, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 109,
								columnNumber: 21
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 104,
							columnNumber: 19
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 103,
						columnNumber: 17
					}, this)]
				}, item.id, true, {
					fileName: _jsxFileName,
					lineNumber: 80,
					columnNumber: 15
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 78,
				columnNumber: 11
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 70,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 43,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLFNBQ0UsVUFDQSxRQUNBLFVBQ0EsWUFDQSxRQUNBLFdBQ0EsU0FDQSxhQUNLOzs7QUFTUCxPQUFPLE1BQU0saUJBQStDLEVBQzFELFdBQ0Esa0JBQ0EsaUJBQ0k7Q0FDSixNQUFNLFdBQVcsU0FBK0I7RUFDOUMsUUFBUSxNQUFSO0dBQ0UsS0FBSztHQUNMLEtBQUssZ0JBQ0gsT0FBTyx3QkFBQyxZQUFELEVBQVksV0FBVSx3QkFBeUI7Ozs7O0dBQ3hELEtBQUs7R0FDTCxLQUFLLHNCQUNILE9BQU8sd0JBQUMsUUFBRCxFQUFRLFdBQVUsMEJBQTJCOzs7OztHQUN0RCxLQUFLLGVBQ0gsT0FBTyx3QkFBQyxVQUFELEVBQVUsV0FBVSwwQkFBMkI7Ozs7O0dBQ3hELEtBQUssaUJBQ0gsT0FBTyx3QkFBQyxXQUFELEVBQVcsV0FBVSx5QkFBMEI7Ozs7O0dBQ3hELFNBQ0UsT0FBTyx3QkFBQyxTQUFELEVBQVMsV0FBVSwyQkFBNEI7Ozs7O0VBQzFEO0NBQ0Y7Q0FFQSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWYsQ0FFRSx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxNQUFEO0tBQUksV0FBVTtlQUFvQztJQUF1Qzs7OztjQUN6Rix3QkFBQyxRQUFEO0tBQU0sV0FBVTtlQUFoQixDQUNHLFVBQVUsUUFBTyxRQUNkOzs7OztZQUNIOzs7OzthQUNMLHdCQUFDLEtBQUQ7SUFBRyxXQUFVO2NBQWdDO0dBRTFDOzs7O1dBQ0E7Ozs7YUFFSixVQUFVLFNBQVMsS0FDbEIsd0JBQUMsVUFBRDtJQUNFLFNBQVM7SUFDVCxXQUFVO2NBRlosQ0FJRSx3QkFBQyxRQUFELEVBQVEsV0FBVSxVQUFXOzs7O2NBQzdCLHdCQUFDLFFBQUQsWUFBTSxnQkFBbUI7Ozs7WUFDbkI7Ozs7O1dBRVA7Ozs7O1lBR0wsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFDWixVQUFVLFdBQVcsSUFDcEIsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUNFLHdCQUFDLFVBQUQsRUFBVSxXQUFVLG1DQUFvQzs7Ozs7S0FDeEQsd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQW1DO0tBQTBCOzs7OztLQUMxRSx3QkFBQyxLQUFELFlBQUcsc0ZBQXNGOzs7OztJQUN0Rjs7Ozs7Y0FFTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNaLFVBQVUsS0FBSyxTQUNkLHdCQUFDLE9BQUQ7S0FFRSxXQUFVO2VBRlosQ0FJRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNaLFFBQVEsS0FBSyxJQUFJO01BQ2Y7Ozs7Z0JBQ0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBeUMsS0FBSztPQUFVOzs7O2lCQUN0RSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUNFLHdCQUFDLFFBQUQsWUFBTyxLQUFLLEtBQVc7Ozs7O1NBQ3ZCLHdCQUFDLFFBQUQsWUFBTSxJQUFPOzs7OztTQUNiLHdCQUFDLFFBQUQsWUFBTyxLQUFLLEtBQVc7Ozs7O1NBQ3ZCLHdCQUFDLFFBQUQsWUFBTSxJQUFPOzs7OztTQUNiLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFoQixDQUNFLHdCQUFDLE9BQUQsRUFBTyxXQUFVLHlCQUEwQjs7OztvQkFDM0Msd0JBQUMsUUFBRCxZQUFPLEtBQUssVUFBZ0I7Ozs7a0JBQ3hCOzs7Ozs7UUFDSDs7Ozs7ZUFDRjs7Ozs7Y0FDRjs7Ozs7ZUFFTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFDYix3QkFBQyxVQUFEO09BQ0UsZUFBZSxpQkFBaUIsS0FBSyxFQUFFO09BQ3ZDLE9BQU07T0FDTixXQUFVO2lCQUVWLHdCQUFDLFFBQUQsRUFBUSxXQUFVLFVBQVc7Ozs7O01BQ3ZCOzs7OztLQUNMOzs7O2FBQ0Y7T0EvQkUsS0FBSzs7OztXQStCUCxDQUNOO0dBQ0U7Ozs7O0VBRUo7Ozs7VUFDRjs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiRG93bmxvYWRzVmlldy50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IFxuICBEb3dubG9hZCwgXG4gIFRyYXNoMiwgXG4gIEZpbGVUZXh0LCBcbiAgQ3JlZGl0Q2FyZCwgXG4gIENhbWVyYSwgXG4gIEZpbGVJbWFnZSwgXG4gIFJlY2VpcHQsIFxuICBDbG9jayBcbn0gZnJvbSAnbHVjaWRlLXJlYWN0JztcbmltcG9ydCB7IERvd25sb2FkSXRlbSB9IGZyb20gJy4uL3R5cGVzJztcblxuaW50ZXJmYWNlIERvd25sb2Fkc1ZpZXdQcm9wcyB7XG4gIGRvd25sb2FkczogRG93bmxvYWRJdGVtW107XG4gIG9uRGVsZXRlRG93bmxvYWQ6IChpZDogc3RyaW5nKSA9PiB2b2lkO1xuICBvbkNsZWFyQWxsOiAoKSA9PiB2b2lkO1xufVxuXG5leHBvcnQgY29uc3QgRG93bmxvYWRzVmlldzogUmVhY3QuRkM8RG93bmxvYWRzVmlld1Byb3BzPiA9ICh7XG4gIGRvd25sb2FkcyxcbiAgb25EZWxldGVEb3dubG9hZCxcbiAgb25DbGVhckFsbFxufSkgPT4ge1xuICBjb25zdCBnZXRJY29uID0gKHR5cGU6IERvd25sb2FkSXRlbVsndHlwZSddKSA9PiB7XG4gICAgc3dpdGNoICh0eXBlKSB7XG4gICAgICBjYXNlICdQVkMgQ2FyZCBQREYnOlxuICAgICAgY2FzZSAnUFZDIENhcmQgSlBHJzpcbiAgICAgICAgcmV0dXJuIDxDcmVkaXRDYXJkIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1ibHVlLTQwMFwiIC8+O1xuICAgICAgY2FzZSAnUGFzc3BvcnQgU2hlZXQgUERGJzpcbiAgICAgIGNhc2UgJ1Bhc3Nwb3J0IFNoZWV0IEpQRyc6XG4gICAgICAgIHJldHVybiA8Q2FtZXJhIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1wdXJwbGUtNDAwXCIgLz47XG4gICAgICBjYXNlICdCaW9EYXRhIFBERic6XG4gICAgICAgIHJldHVybiA8RmlsZVRleHQgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LWluZGlnby00MDBcIiAvPjtcbiAgICAgIGNhc2UgJ0NvbnZlcnRlZCBKUEcnOlxuICAgICAgICByZXR1cm4gPEZpbGVJbWFnZSBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtYW1iZXItNDAwXCIgLz47XG4gICAgICBkZWZhdWx0OlxuICAgICAgICByZXR1cm4gPFJlY2VpcHQgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LWVtZXJhbGQtNDAwXCIgLz47XG4gICAgfVxuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTQgbWF4LXctNXhsIG14LWF1dG9cIj5cbiAgICAgIHsvKiBIZWFkZXIgYmFyICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IHNtOml0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTMgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHAtNCByb3VuZGVkLTJ4bCBzaGFkb3ctbWRcIj5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWV4dHJhYm9sZCB0ZXh0LXdoaXRlXCI+R2VuZXJhdGVkIERvd25sb2FkcyAmIFByaW50IEhpc3Rvcnk8L2gxPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYmctYmx1ZS01MDAvMjAgdGV4dC1ibHVlLTQwMCBib3JkZXIgYm9yZGVyLWJsdWUtNTAwLzMwIHRleHQteHMgcHgtMiBweS0wLjUgcm91bmRlZC1mdWxsIGZvbnQtbW9ubyBmb250LWJvbGRcIj5cbiAgICAgICAgICAgICAge2Rvd25sb2Fkcy5sZW5ndGh9IEZpbGVzXG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMCBtdC0wLjVcIj5cbiAgICAgICAgICAgIExvZyBvZiBhbGwgZ2VuZXJhdGVkIFBWQyBjYXJkcywgcGFzc3BvcnQgc2hlZXRzLCBjb252ZXJ0ZWQgUERGcywgYW5kIHJlY2VpcHRzIGNyZWF0ZWQgb24gdGhpcyBQQ1xuICAgICAgICAgIDwvcD5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAge2Rvd25sb2Fkcy5sZW5ndGggPiAwICYmIChcbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXtvbkNsZWFyQWxsfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBiZy1yb3NlLTUwMC8xMCBob3ZlcjpiZy1yb3NlLTUwMC8yMCB0ZXh0LXJvc2UtNDAwIGJvcmRlciBib3JkZXItcm9zZS01MDAvMzAgdGV4dC14cyBmb250LWJvbGQgcHgtMyBweS0yIHJvdW5kZWQteGwgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxUcmFzaDIgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICA8c3Bhbj5DbGVhciBIaXN0b3J5PC9zcGFuPlxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICApfVxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBEb3dubG9hZHMgTGlzdCAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtMnhsIG92ZXJmbG93LWhpZGRlbiBzaGFkb3ctbWRcIj5cbiAgICAgICAge2Rvd25sb2Fkcy5sZW5ndGggPT09IDAgPyAoXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTEyIHRleHQtY2VudGVyIHRleHQtc2xhdGUtNTAwIHRleHQteHMgc3BhY2UteS0yXCI+XG4gICAgICAgICAgICA8RG93bmxvYWQgY2xhc3NOYW1lPVwidy0xMCBoLTEwIG14LWF1dG8gdGV4dC1zbGF0ZS02MDBcIiAvPlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIHRleHQtc21cIj5ObyBEb3dubG9hZHMgTG9nZ2VkIFlldDwvcD5cbiAgICAgICAgICAgIDxwPkdlbmVyYXRlZCBQVkMgY2FyZHMsIHBhc3Nwb3J0IHBob3RvIHNoZWV0cywgYW5kIGNvbnZlcnRlZCBQREZzIHdpbGwgYmUgbGlzdGVkIGhlcmUuPC9wPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApIDogKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZGl2aWRlLXkgZGl2aWRlLXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAge2Rvd25sb2Fkcy5tYXAoKGl0ZW0pID0+IChcbiAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgIGtleT17aXRlbS5pZH1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTQgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC00IGhvdmVyOmJnLXNsYXRlLTgwMC80MCB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIG1pbi13LTBcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMCBoLTEwIHJvdW5kZWQteGwgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGZsZXgtc2hyaW5rLTAgc2hhZG93LWlubmVyXCI+XG4gICAgICAgICAgICAgICAgICAgIHtnZXRJY29uKGl0ZW0udHlwZSl9XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLXctMFwiPlxuICAgICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC13aGl0ZSB0cnVuY2F0ZVwiPntpdGVtLnRpdGxlfTwvaDQ+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC1bMTFweF0gdGV4dC1zbGF0ZS00MDAgZm9udC1tb25vIG10LTAuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPntpdGVtLnR5cGV9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPuKAojwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57aXRlbS5zaXplfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj7igKI8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxDbG9jayBjbGFzc05hbWU9XCJ3LTMgaC0zIHRleHQtc2xhdGUtNTAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPntpdGVtLnRpbWVzdGFtcH08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvbkRlbGV0ZURvd25sb2FkKGl0ZW0uaWQpfVxuICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIlJlbW92ZSByZWNvcmRcIlxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTIgdGV4dC1zbGF0ZS01MDAgaG92ZXI6dGV4dC1yb3NlLTQwMCByb3VuZGVkLWxnIGhvdmVyOmJnLXNsYXRlLTgwMCB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIDxUcmFzaDIgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKX1cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufTtcbiJdfQ==