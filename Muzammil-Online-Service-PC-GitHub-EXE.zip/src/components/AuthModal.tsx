const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=1d04f0f2";
import { Lock, X, LogIn, KeyRound, User, AlertCircle } from "/node_modules/.vite/deps/lucide-react.js?v=1d04f0f2";
var _jsxFileName = "/app/applet/src/components/AuthModal.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=1d04f0f2";
export const AuthModal = ({ currentUser, onSelectUser, onClose }) => {
	const [username, setUsername] = useState("");
	const [password, setPassword] = useState("");
	const [errorMsg, setErrorMsg] = useState("");
	const handleManualLogin = (e) => {
		e.preventDefault();
		setErrorMsg("");
		const cleanUser = username.trim().toLowerCase();
		const cleanPass = password.trim();
		if (!cleanUser) {
			setErrorMsg("Kripya username enter karein.");
			return;
		}
		if (!cleanPass) {
			setErrorMsg("Kripya password enter karein.");
			return;
		}
		if ((cleanUser === "admin" || cleanUser === "imran") && cleanPass === "muzammil786") {
			const adminAccount = {
				username: cleanUser,
				displayName: "Imran Khan",
				role: "admin",
				phone: currentUser.phone,
				shopName: currentUser.shopName,
				isLoggedIn: true
			};
			onSelectUser(adminAccount);
			onClose();
			return;
		}
		if (cleanPass === "muzammil786") {
			const opAccount = {
				username: cleanUser,
				displayName: cleanUser.toUpperCase(),
				role: "operator",
				phone: currentUser.phone,
				shopName: currentUser.shopName,
				isLoggedIn: true
			};
			onSelectUser(opAccount);
			onClose();
			return;
		}
		setErrorMsg("Galat username ya password. Kripya check karein.");
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "bg-slate-900 border border-slate-800 rounded-3xl max-w-sm w-full p-6 shadow-2xl space-y-5 animate-in fade-in zoom-in-95",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center justify-between border-b border-slate-800 pb-3",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2.5",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "w-10 h-10 rounded-xl bg-blue-600/20 border border-blue-500/30 flex items-center justify-center text-blue-400",
						children: /* @__PURE__ */ _jsxDEV(Lock, { className: "w-5 h-5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 79,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 78,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
						className: "font-extrabold text-white text-base",
						children: "Operator Login"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 82,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "text-xs text-slate-400",
						children: "Switch operator session"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 83,
						columnNumber: 15
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 81,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 77,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					onClick: onClose,
					className: "p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800",
					children: /* @__PURE__ */ _jsxDEV(X, { className: "w-5 h-5" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 87,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 86,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 76,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("form", {
				onSubmit: handleManualLogin,
				className: "space-y-3.5 text-xs",
				children: [
					errorMsg && /* @__PURE__ */ _jsxDEV("div", {
						className: "p-2.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2",
						children: [/* @__PURE__ */ _jsxDEV(AlertCircle, { className: "w-4 h-4 text-rose-400 flex-shrink-0" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 95,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: errorMsg }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 96,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 94,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
						className: "text-slate-300 font-semibold block mb-1",
						children: "Username"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 101,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "relative",
						children: [/* @__PURE__ */ _jsxDEV(User, { className: "w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 103,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("input", {
							type: "text",
							required: true,
							placeholder: "Username enter karein",
							value: username,
							onChange: (e) => setUsername(e.target.value),
							className: "w-full bg-slate-950 border border-slate-700 rounded-xl pl-9 pr-3 py-2.5 text-white text-xs focus:outline-none focus:border-blue-500"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 104,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 102,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 100,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
						className: "text-slate-300 font-semibold block mb-1",
						children: "Password"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 116,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "relative",
						children: [/* @__PURE__ */ _jsxDEV(KeyRound, { className: "w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 118,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("input", {
							type: "password",
							required: true,
							placeholder: "Password enter karein",
							value: password,
							onChange: (e) => setPassword(e.target.value),
							className: "w-full bg-slate-950 border border-slate-700 rounded-xl pl-9 pr-3 py-2.5 text-white text-xs focus:outline-none focus:border-blue-500"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 119,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 117,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 115,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						type: "submit",
						className: "w-full flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-500 text-white font-bold py-2.5 rounded-xl transition-all shadow-md shadow-blue-600/30",
						children: [/* @__PURE__ */ _jsxDEV(LogIn, { className: "w-4 h-4" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 134,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Login to Station" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 135,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 130,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 92,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 75,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 74,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxTQUNFLE1BQ0EsR0FDQSxPQUNBLFVBQ0EsTUFDQSxtQkFDSzs7O0FBU1AsT0FBTyxNQUFNLGFBQXVDLEVBQ2xELGFBQ0EsY0FDQSxjQUNJO0NBQ0osTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFTLEVBQUU7Q0FDM0MsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFTLEVBQUU7Q0FDM0MsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFTLEVBQUU7Q0FFM0MsTUFBTSxxQkFBcUIsTUFBdUI7RUFDaEQsRUFBRSxlQUFlO0VBQ2pCLFlBQVksRUFBRTtFQUNkLE1BQU0sWUFBWSxTQUFTLEtBQUssQ0FBQyxDQUFDLFlBQVk7RUFDOUMsTUFBTSxZQUFZLFNBQVMsS0FBSztFQUVoQyxJQUFJLENBQUMsV0FBVztHQUNkLFlBQVksK0JBQStCO0dBQzNDO0VBQ0Y7RUFDQSxJQUFJLENBQUMsV0FBVztHQUNkLFlBQVksK0JBQStCO0dBQzNDO0VBQ0Y7RUFFQSxLQUFLLGNBQWMsV0FBVyxjQUFjLFlBQVksY0FBYyxlQUFlO0dBQ25GLE1BQU0sZUFBNEI7SUFDaEMsVUFBVTtJQUNWLGFBQWE7SUFDYixNQUFNO0lBQ04sT0FBTyxZQUFZO0lBQ25CLFVBQVUsWUFBWTtJQUN0QixZQUFZO0dBQ2Q7R0FDQSxhQUFhLFlBQVk7R0FDekIsUUFBUTtHQUNSO0VBQ0Y7RUFFQSxJQUFJLGNBQWMsZUFBZTtHQUMvQixNQUFNLFlBQXlCO0lBQzdCLFVBQVU7SUFDVixhQUFhLFVBQVUsWUFBWTtJQUNuQyxNQUFNO0lBQ04sT0FBTyxZQUFZO0lBQ25CLFVBQVUsWUFBWTtJQUN0QixZQUFZO0dBQ2Q7R0FDQSxhQUFhLFNBQVM7R0FDdEIsUUFBUTtHQUNSO0VBQ0Y7RUFFQSxZQUFZLGtEQUFrRDtDQUNoRTtDQUVBLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFDYix3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBQ0Usd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFDYix3QkFBQyxNQUFELEVBQU0sV0FBVSxVQUFXOzs7OztLQUN4Qjs7OztlQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBc0M7S0FBa0I7Ozs7ZUFDdEUsd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQXlCO0tBQTBCOzs7O2FBQzdEOzs7O2FBQ0Y7Ozs7O2NBQ0wsd0JBQUMsVUFBRDtLQUFRLFNBQVM7S0FBUyxXQUFVO2VBQ2xDLHdCQUFDLEdBQUQsRUFBRyxXQUFVLFVBQVc7Ozs7O0lBQ2xCOzs7O1lBQ0w7Ozs7O2FBR0wsd0JBQUMsUUFBRDtJQUFNLFVBQVU7SUFBbUIsV0FBVTtjQUE3QztLQUNHLFlBQ0Msd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxhQUFELEVBQWEsV0FBVSxzQ0FBdUM7Ozs7Z0JBQzlELHdCQUFDLFFBQUQsWUFBTyxTQUFlOzs7O2NBQ25COzs7Ozs7S0FHUCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtNQUFPLFdBQVU7Z0JBQTBDO0tBQWU7Ozs7ZUFDMUUsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxNQUFELEVBQU0sV0FBVSxrRUFBbUU7Ozs7Z0JBQ25GLHdCQUFDLFNBQUQ7T0FDRSxNQUFLO09BQ0w7T0FDQSxhQUFZO09BQ1osT0FBTztPQUNQLFdBQVcsTUFBTSxZQUFZLEVBQUUsT0FBTyxLQUFLO09BQzNDLFdBQVU7TUFDWDs7OztjQUNFOzs7OzthQUNGOzs7OztLQUVMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO01BQU8sV0FBVTtnQkFBMEM7S0FBZTs7OztlQUMxRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLFVBQUQsRUFBVSxXQUFVLGtFQUFtRTs7OztnQkFDdkYsd0JBQUMsU0FBRDtPQUNFLE1BQUs7T0FDTDtPQUNBLGFBQVk7T0FDWixPQUFPO09BQ1AsV0FBVyxNQUFNLFlBQVksRUFBRSxPQUFPLEtBQUs7T0FDM0MsV0FBVTtNQUNYOzs7O2NBQ0U7Ozs7O2FBQ0Y7Ozs7O0tBRUwsd0JBQUMsVUFBRDtNQUNFLE1BQUs7TUFDTCxXQUFVO2dCQUZaLENBSUUsd0JBQUMsT0FBRCxFQUFPLFdBQVUsVUFBVzs7OztnQkFDNUIsd0JBQUMsUUFBRCxZQUFNLG1CQUFzQjs7OztjQUN0Qjs7Ozs7O0lBQ0o7Ozs7O1dBQ0g7Ozs7OztDQUNGOzs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkF1dGhNb2RhbC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgXG4gIExvY2ssIFxuICBYLCBcbiAgTG9nSW4sIFxuICBLZXlSb3VuZCxcbiAgVXNlcixcbiAgQWxlcnRDaXJjbGVcbn0gZnJvbSAnbHVjaWRlLXJlYWN0JztcbmltcG9ydCB7IFVzZXJBY2NvdW50IH0gZnJvbSAnLi4vdHlwZXMnO1xuXG5pbnRlcmZhY2UgQXV0aE1vZGFsUHJvcHMge1xuICBjdXJyZW50VXNlcjogVXNlckFjY291bnQ7XG4gIG9uU2VsZWN0VXNlcjogKHVzZXI6IFVzZXJBY2NvdW50KSA9PiB2b2lkO1xuICBvbkNsb3NlOiAoKSA9PiB2b2lkO1xufVxuXG5leHBvcnQgY29uc3QgQXV0aE1vZGFsOiBSZWFjdC5GQzxBdXRoTW9kYWxQcm9wcz4gPSAoe1xuICBjdXJyZW50VXNlcixcbiAgb25TZWxlY3RVc2VyLFxuICBvbkNsb3NlXG59KSA9PiB7XG4gIGNvbnN0IFt1c2VybmFtZSwgc2V0VXNlcm5hbWVdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbcGFzc3dvcmQsIHNldFBhc3N3b3JkXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW2Vycm9yTXNnLCBzZXRFcnJvck1zZ10gPSB1c2VTdGF0ZSgnJyk7XG5cbiAgY29uc3QgaGFuZGxlTWFudWFsTG9naW4gPSAoZTogUmVhY3QuRm9ybUV2ZW50KSA9PiB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgIHNldEVycm9yTXNnKCcnKTtcbiAgICBjb25zdCBjbGVhblVzZXIgPSB1c2VybmFtZS50cmltKCkudG9Mb3dlckNhc2UoKTtcbiAgICBjb25zdCBjbGVhblBhc3MgPSBwYXNzd29yZC50cmltKCk7XG5cbiAgICBpZiAoIWNsZWFuVXNlcikge1xuICAgICAgc2V0RXJyb3JNc2coJ0tyaXB5YSB1c2VybmFtZSBlbnRlciBrYXJlaW4uJyk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGlmICghY2xlYW5QYXNzKSB7XG4gICAgICBzZXRFcnJvck1zZygnS3JpcHlhIHBhc3N3b3JkIGVudGVyIGthcmVpbi4nKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBpZiAoKGNsZWFuVXNlciA9PT0gJ2FkbWluJyB8fCBjbGVhblVzZXIgPT09ICdpbXJhbicpICYmIGNsZWFuUGFzcyA9PT0gJ211emFtbWlsNzg2Jykge1xuICAgICAgY29uc3QgYWRtaW5BY2NvdW50OiBVc2VyQWNjb3VudCA9IHtcbiAgICAgICAgdXNlcm5hbWU6IGNsZWFuVXNlcixcbiAgICAgICAgZGlzcGxheU5hbWU6ICdJbXJhbiBLaGFuJyxcbiAgICAgICAgcm9sZTogJ2FkbWluJyxcbiAgICAgICAgcGhvbmU6IGN1cnJlbnRVc2VyLnBob25lLFxuICAgICAgICBzaG9wTmFtZTogY3VycmVudFVzZXIuc2hvcE5hbWUsXG4gICAgICAgIGlzTG9nZ2VkSW46IHRydWVcbiAgICAgIH07XG4gICAgICBvblNlbGVjdFVzZXIoYWRtaW5BY2NvdW50KTtcbiAgICAgIG9uQ2xvc2UoKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBpZiAoY2xlYW5QYXNzID09PSAnbXV6YW1taWw3ODYnKSB7XG4gICAgICBjb25zdCBvcEFjY291bnQ6IFVzZXJBY2NvdW50ID0ge1xuICAgICAgICB1c2VybmFtZTogY2xlYW5Vc2VyLFxuICAgICAgICBkaXNwbGF5TmFtZTogY2xlYW5Vc2VyLnRvVXBwZXJDYXNlKCksXG4gICAgICAgIHJvbGU6ICdvcGVyYXRvcicsXG4gICAgICAgIHBob25lOiBjdXJyZW50VXNlci5waG9uZSxcbiAgICAgICAgc2hvcE5hbWU6IGN1cnJlbnRVc2VyLnNob3BOYW1lLFxuICAgICAgICBpc0xvZ2dlZEluOiB0cnVlXG4gICAgICB9O1xuICAgICAgb25TZWxlY3RVc2VyKG9wQWNjb3VudCk7XG4gICAgICBvbkNsb3NlKCk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgc2V0RXJyb3JNc2coJ0dhbGF0IHVzZXJuYW1lIHlhIHBhc3N3b3JkLiBLcmlweWEgY2hlY2sga2FyZWluLicpO1xuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIGJnLWJsYWNrLzgwIGJhY2tkcm9wLWJsdXItc20gei01MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTRcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtM3hsIG1heC13LXNtIHctZnVsbCBwLTYgc2hhZG93LTJ4bCBzcGFjZS15LTUgYW5pbWF0ZS1pbiBmYWRlLWluIHpvb20taW4tOTVcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMCBwYi0zXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMi41XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTAgaC0xMCByb3VuZGVkLXhsIGJnLWJsdWUtNjAwLzIwIGJvcmRlciBib3JkZXItYmx1ZS01MDAvMzAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC1ibHVlLTQwMFwiPlxuICAgICAgICAgICAgICA8TG9jayBjbGFzc05hbWU9XCJ3LTUgaC01XCIgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtZXh0cmFib2xkIHRleHQtd2hpdGUgdGV4dC1iYXNlXCI+T3BlcmF0b3IgTG9naW48L2gzPlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwXCI+U3dpdGNoIG9wZXJhdG9yIHNlc3Npb248L3A+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9e29uQ2xvc2V9IGNsYXNzTmFtZT1cInAtMS41IHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtd2hpdGUgcm91bmRlZC1sZyBob3ZlcjpiZy1zbGF0ZS04MDBcIj5cbiAgICAgICAgICAgIDxYIGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPlxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogQ2xlYW4gTG9naW4gRm9ybSAqL31cbiAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZU1hbnVhbExvZ2lufSBjbGFzc05hbWU9XCJzcGFjZS15LTMuNSB0ZXh0LXhzXCI+XG4gICAgICAgICAge2Vycm9yTXNnICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0yLjUgcm91bmRlZC14bCBiZy1yb3NlLTUwMC8xMCBib3JkZXIgYm9yZGVyLXJvc2UtNTAwLzMwIHRleHQtcm9zZS0zMDAgdGV4dC14cyBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICA8QWxlcnRDaXJjbGUgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LXJvc2UtNDAwIGZsZXgtc2hyaW5rLTBcIiAvPlxuICAgICAgICAgICAgICA8c3Bhbj57ZXJyb3JNc2d9PC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS0zMDAgZm9udC1zZW1pYm9sZCBibG9jayBtYi0xXCI+VXNlcm5hbWU8L2xhYmVsPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZVwiPlxuICAgICAgICAgICAgICA8VXNlciBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtc2xhdGUtNTAwIGFic29sdXRlIGxlZnQtMyB0b3AtMS8yIC10cmFuc2xhdGUteS0xLzJcIiAvPlxuICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlVzZXJuYW1lIGVudGVyIGthcmVpblwiXG4gICAgICAgICAgICAgICAgdmFsdWU9e3VzZXJuYW1lfVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0VXNlcm5hbWUoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCBwbC05IHByLTMgcHktMi41IHRleHQtd2hpdGUgdGV4dC14cyBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwXCJcbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTMwMCBmb250LXNlbWlib2xkIGJsb2NrIG1iLTFcIj5QYXNzd29yZDwvbGFiZWw+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlXCI+XG4gICAgICAgICAgICAgIDxLZXlSb3VuZCBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtc2xhdGUtNTAwIGFic29sdXRlIGxlZnQtMyB0b3AtMS8yIC10cmFuc2xhdGUteS0xLzJcIiAvPlxuICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICB0eXBlPVwicGFzc3dvcmRcIlxuICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJQYXNzd29yZCBlbnRlciBrYXJlaW5cIlxuICAgICAgICAgICAgICAgIHZhbHVlPXtwYXNzd29yZH1cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFBhc3N3b3JkKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQteGwgcGwtOSBwci0zIHB5LTIuNSB0ZXh0LXdoaXRlIHRleHQteHMgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1ibHVlLTUwMFwiXG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIGJnLWJsdWUtNjAwIGhvdmVyOmJnLWJsdWUtNTAwIHRleHQtd2hpdGUgZm9udC1ib2xkIHB5LTIuNSByb3VuZGVkLXhsIHRyYW5zaXRpb24tYWxsIHNoYWRvdy1tZCBzaGFkb3ctYmx1ZS02MDAvMzBcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxMb2dJbiBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgIDxzcGFuPkxvZ2luIHRvIFN0YXRpb248L3NwYW4+XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZm9ybT5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufTtcbiJdfQ==