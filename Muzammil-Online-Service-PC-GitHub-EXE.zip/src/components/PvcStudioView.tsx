const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useRef = __vite__cjsImport0_react["useRef"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=1d04f0f2";
import { Upload, Printer, Download, RotateCw, Check, ArrowUpDown, Sun, Contrast, HelpCircle } from "/node_modules/.vite/deps/lucide-react.js?v=1d04f0f2";
import { jsPDF } from "/node_modules/.vite/deps/jspdf.js?v=1d04f0f2";
import { addDownloadRecord } from "/src/utils/storage.ts";
import { printImageSheet } from "/src/utils/printer.ts";
var _jsxFileName = "/app/applet/src/components/PvcStudioView.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=1d04f0f2";
export const PvcStudioView = () => {
	// Canvas references
	const canvasRef = useRef(null);
	// Card images (Data URLs or Image objects)
	const [card1Src, setCard1Src] = useState(null);
	const [card2Src, setCard2Src] = useState(null);
	// Active editing card: 'card1' | 'card2'
	const [activeCard, setActiveCard] = useState("card1");
	// Adjustments per card
	const [card1Config, setCard1Config] = useState({
		x: 0,
		y: 0,
		scale: 1,
		rotation: 0
	});
	const [card2Config, setCard2Config] = useState({
		x: 0,
		y: 0,
		scale: 1,
		rotation: 0
	});
	// Global card adjustments
	const [brightness, setBrightness] = useState(0);
	const [contrast, setContrast] = useState(0);
	const [showCutMarks, setShowCutMarks] = useState(true);
	const [roundedCorners, setRoundedCorners] = useState(true);
	const [borderStroke, setBorderStroke] = useState(true);
	const [isProcessing, setIsProcessing] = useState(false);
	const [printAlert, setPrintAlert] = useState(null);
	// Dragging state on canvas
	const [isDragging, setIsDragging] = useState(false);
	const [dragCard, setDragCard] = useState(null);
	const [dragStart, setDragStart] = useState({
		x: 0,
		y: 0
	});
	// 300 DPI constants for 4x6 inch paper:
	// 4 inches = 1200 px, 6 inches = 1800 px
	const CANVAS_WIDTH = 1200;
	const CANVAS_HEIGHT = 1800;
	// Exact 5.5 cm × 8.5 cm (85 mm × 55 mm) dimensions at 300 DPI:
	// 1 inch = 2.54 cm -> 300 px / 2.54 cm = 118.1102 px per cm
	// Width: 8.5 cm * 118.1102 ≈ 1004 px
	// Height: 5.5 cm * 118.1102 ≈ 650 px
	const CARD_WIDTH = 1004;
	const CARD_HEIGHT = 650;
	// Position on 4x6 inch Portrait Sheet (1200 x 1800 px):
	// X Center: 1200 / 2 = 600 px (98 px margin on left and right = ~8.3 mm)
	// Top Card Center (Front): Y = 465 px
	// Center Cut Guideline: Y = 900 px
	// Bottom Card Center (Back): Y = 1335 px
	const CARD_CENTER_X = 600;
	const CARD1_DEFAULT_Y = 465;
	const CARD2_DEFAULT_Y = 1335;
	// Pre-load images for canvas drawing
	const card1ImgRef = useRef(null);
	const card2ImgRef = useRef(null);
	// Load card 1 image
	useEffect(() => {
		if (card1Src) {
			const img = new Image();
			img.crossOrigin = "anonymous";
			img.onload = () => {
				card1ImgRef.current = img;
				renderCanvas();
			};
			img.src = card1Src;
		} else {
			card1ImgRef.current = null;
			renderCanvas();
		}
	}, [card1Src]);
	// Load card 2 image
	useEffect(() => {
		if (card2Src) {
			const img = new Image();
			img.crossOrigin = "anonymous";
			img.onload = () => {
				card2ImgRef.current = img;
				renderCanvas();
			};
			img.src = card2Src;
		} else {
			card2ImgRef.current = null;
			renderCanvas();
		}
	}, [card2Src]);
	// Global Keyboard shortcuts listener (Ctrl+P, Ctrl+S, Ctrl+J)
	useEffect(() => {
		const handleGlobalPrint = () => handleDirectPrint();
		const handleGlobalPdf = () => handleDownloadPDF();
		const handleGlobalJpg = () => handleDownloadJPG();
		window.addEventListener("app-direct-print", handleGlobalPrint);
		window.addEventListener("app-direct-pdf", handleGlobalPdf);
		window.addEventListener("app-direct-jpg", handleGlobalJpg);
		return () => {
			window.removeEventListener("app-direct-print", handleGlobalPrint);
			window.removeEventListener("app-direct-pdf", handleGlobalPdf);
			window.removeEventListener("app-direct-jpg", handleGlobalJpg);
		};
	});
	// Re-render canvas whenever configs change
	useEffect(() => {
		renderCanvas();
	}, [
		card1Config,
		card2Config,
		brightness,
		contrast,
		showCutMarks,
		roundedCorners,
		borderStroke
	]);
	// Main Render Function to Canvas @ 300 DPI
	const renderCanvas = () => {
		const canvas = canvasRef.current;
		if (!canvas) return;
		const ctx = canvas.getContext("2d");
		if (!ctx) return;
		// Clear background to pure white (for photo paper print)
		ctx.fillStyle = "#ffffff";
		ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
		// Filter string
		const filterStr = `brightness(${100 + brightness}%) contrast(${100 + contrast}%)`;
		// 1. Draw Card 1 (Top / Front)
		drawSingleCard(ctx, card1ImgRef.current, CARD_CENTER_X + card1Config.x, CARD1_DEFAULT_Y + card1Config.y, card1Config.scale, card1Config.rotation, "Card 1 (Front)", filterStr);
		// 2. Draw Card 2 (Bottom / Back)
		drawSingleCard(ctx, card2ImgRef.current, CARD_CENTER_X + card2Config.x, CARD2_DEFAULT_Y + card2Config.y, card2Config.scale, card2Config.rotation, "Card 2 (Back)", filterStr);
		// 3. Draw Cut Guide Line between cards
		if (showCutMarks) {
			ctx.save();
			ctx.strokeStyle = "#94a3b8";
			ctx.lineWidth = 2;
			ctx.setLineDash([8, 8]);
			// Horizontal center cut mark (exact center of 4x6 inch sheet)
			const midY = 900;
			ctx.beginPath();
			ctx.moveTo(40, midY);
			ctx.lineTo(CANVAS_WIDTH - 40, midY);
			ctx.stroke();
			// Scissor indicator text
			ctx.setLineDash([]);
			ctx.fillStyle = "#64748b";
			ctx.font = "bold 20px sans-serif";
			ctx.textAlign = "center";
			ctx.fillText("✂ Cut Here (Fold / Separate • 5.5 cm × 8.5 cm Each)", CANVAS_WIDTH / 2, midY - 12);
			// Sheet boundary crop corners
			drawCropMarks(ctx, 40, 40);
			drawCropMarks(ctx, CANVAS_WIDTH - 40, 40);
			drawCropMarks(ctx, 40, CANVAS_HEIGHT - 40);
			drawCropMarks(ctx, CANVAS_WIDTH - 40, CANVAS_HEIGHT - 40);
			ctx.restore();
		}
	};
	const drawCropMarks = (ctx, x, y) => {
		ctx.strokeStyle = "#cbd5e1";
		ctx.lineWidth = 2;
		ctx.beginPath();
		ctx.moveTo(x - 20, y);
		ctx.lineTo(x + 20, y);
		ctx.moveTo(x, y - 20);
		ctx.lineTo(x, y + 20);
		ctx.stroke();
	};
	const drawSingleCard = (ctx, img, centerX, centerY, scale, rotation, placeholderLabel, filter) => {
		const w = CARD_WIDTH;
		const h = CARD_HEIGHT;
		const left = centerX - w / 2;
		const top = centerY - h / 2;
		ctx.save();
		// Rounded rectangle path for CR-80 card (standard ~3mm / 36px radius @ 300DPI)
		const radius = roundedCorners ? 36 : 0;
		ctx.beginPath();
		ctx.roundRect(left, top, w, h, radius);
		if (img) {
			ctx.save();
			// Clip image to card boundary
			ctx.clip();
			// Apply brightness & contrast filters
			ctx.filter = filter;
			// Transform for position, scale & rotation
			ctx.translate(centerX, centerY);
			ctx.rotate(rotation * Math.PI / 180);
			ctx.scale(scale, scale);
			// Draw image centered
			ctx.drawImage(img, -w / 2, -h / 2, w, h);
			ctx.restore();
		} else {
			// Empty placeholder slot
			ctx.fillStyle = "#f8fafc";
			ctx.fill();
			ctx.strokeStyle = "#cbd5e1";
			ctx.lineWidth = 4;
			ctx.setLineDash([12, 8]);
			ctx.stroke();
			// Placeholder text
			ctx.fillStyle = "#64748b";
			ctx.font = "bold 36px sans-serif";
			ctx.textAlign = "center";
			ctx.fillText(placeholderLabel, centerX, centerY - 20);
			ctx.font = "24px sans-serif";
			ctx.fillStyle = "#94a3b8";
			ctx.fillText("Drop image or PDF to place here", centerX, centerY + 30);
			ctx.fillText("Official Size: 5.5 cm × 8.5 cm (85 mm × 55 mm)", centerX, centerY + 70);
		}
		// Border line around card
		if (borderStroke) {
			ctx.beginPath();
			ctx.roundRect(left, top, w, h, radius);
			ctx.strokeStyle = "#1e293b";
			ctx.lineWidth = 2;
			ctx.setLineDash([]);
			ctx.stroke();
		}
		ctx.restore();
	};
	// Upload handler for Card 1 or Card 2
	const handleFileUpload = (e, target) => {
		const file = e.target.files?.[0];
		if (!file) return;
		const reader = new FileReader();
		reader.onload = (event) => {
			const result = event.target?.result;
			if (target === "card1") {
				setCard1Src(result);
				setActiveCard("card1");
			} else {
				setCard2Src(result);
				setActiveCard("card2");
			}
		};
		reader.readAsDataURL(file);
		e.target.value = "";
	};
	// Swap Front & Back cards
	const handleSwapCards = () => {
		const tempSrc = card1Src;
		setCard1Src(card2Src);
		setCard2Src(tempSrc);
		const tempCfg = { ...card1Config };
		setCard1Config({ ...card2Config });
		setCard2Config(tempCfg);
	};
	// Scale adjustment
	const handleScaleChange = (val) => {
		if (activeCard === "card1") {
			setCard1Config((prev) => ({
				...prev,
				scale: val
			}));
		} else {
			setCard2Config((prev) => ({
				...prev,
				scale: val
			}));
		}
	};
	// Nudge adjustment
	const handleNudge = (dx, dy) => {
		if (activeCard === "card1") {
			setCard1Config((prev) => ({
				...prev,
				x: prev.x + dx,
				y: prev.y + dy
			}));
		} else {
			setCard2Config((prev) => ({
				...prev,
				x: prev.x + dx,
				y: prev.y + dy
			}));
		}
	};
	// Rotate 90 degrees
	const handleRotate = () => {
		if (activeCard === "card1") {
			setCard1Config((prev) => ({
				...prev,
				rotation: (prev.rotation + 90) % 360
			}));
		} else {
			setCard2Config((prev) => ({
				...prev,
				rotation: (prev.rotation + 90) % 360
			}));
		}
	};
	// Reset controls
	const handleReset = () => {
		setCard1Config({
			x: 0,
			y: 0,
			scale: 1,
			rotation: 0
		});
		setCard2Config({
			x: 0,
			y: 0,
			scale: 1,
			rotation: 0
		});
		setBrightness(0);
		setContrast(0);
	};
	// Download High-Res 300 DPI JPG
	const handleDownloadJPG = () => {
		const canvas = canvasRef.current;
		if (!canvas) return;
		setIsProcessing(true);
		try {
			const dataUrl = canvas.toDataURL("image/jpeg", .98);
			const a = document.createElement("a");
			a.href = dataUrl;
			const fileName = `PVC_Card_4x6_300DPI_${Date.now()}.jpg`;
			a.download = fileName;
			a.click();
			addDownloadRecord({
				id: `pvc-jpg-${Date.now()}`,
				title: fileName,
				type: "PVC Card JPG",
				size: "1200×1800 px (300 DPI)",
				timestamp: new Date().toLocaleTimeString("en-IN")
			});
		} catch (e) {
			console.error(e);
		} finally {
			setIsProcessing(false);
		}
	};
	// Download 300 DPI PDF (Exact 4x6 inch paper size)
	const handleDownloadPDF = () => {
		const canvas = canvasRef.current;
		if (!canvas) return;
		setIsProcessing(true);
		try {
			const dataUrl = canvas.toDataURL("image/jpeg", .98);
			// 4x6 inches in PDF points: 4 * 72 = 288, 6 * 72 = 432
			const pdf = new jsPDF({
				orientation: "portrait",
				unit: "in",
				format: [4, 6]
			});
			pdf.addImage(dataUrl, "JPEG", 0, 0, 4, 6);
			const fileName = `PVC_Card_Printable_4x6_${Date.now()}.pdf`;
			pdf.save(fileName);
			addDownloadRecord({
				id: `pvc-pdf-${Date.now()}`,
				title: fileName,
				type: "PVC Card PDF",
				size: "4×6 inch (300 DPI)",
				timestamp: new Date().toLocaleTimeString("en-IN")
			});
		} catch (e) {
			console.error(e);
		} finally {
			setIsProcessing(false);
		}
	};
	// Direct Browser Print (Formatted for 4x6 photo paper)
	const handleDirectPrint = () => {
		const canvas = canvasRef.current;
		if (!canvas) return;
		try {
			const dataUrl = canvas.toDataURL("image/jpeg", 1);
			printImageSheet(dataUrl, {
				paperFormat: "4x6_portrait",
				title: "PVC_Card_4x6_Print"
			});
			setPrintAlert("🖨️ PVC Card print command sent to printer! (4×6 Photo Paper Portrait • Exact 5.5 cm × 8.5 cm)");
			setTimeout(() => setPrintAlert(null), 4e3);
		} catch (e) {
			console.error(e);
			window.print();
		}
	};
	// Interactive Drag on Canvas
	const handleMouseDown = (e) => {
		const canvas = canvasRef.current;
		if (!canvas) return;
		const rect = canvas.getBoundingClientRect();
		const scaleX = CANVAS_WIDTH / rect.width;
		const scaleY = CANVAS_HEIGHT / rect.height;
		const mouseX = (e.clientX - rect.left) * scaleX;
		const mouseY = (e.clientY - rect.top) * scaleY;
		// Check if clicked in top card (Card 1)
		if (mouseY < CANVAS_HEIGHT / 2) {
			setDragCard("card1");
			setActiveCard("card1");
			setIsDragging(true);
			setDragStart({
				x: mouseX - card1Config.x,
				y: mouseY - card1Config.y
			});
		} else {
			setDragCard("card2");
			setActiveCard("card2");
			setIsDragging(true);
			setDragStart({
				x: mouseX - card2Config.x,
				y: mouseY - card2Config.y
			});
		}
	};
	const handleMouseMove = (e) => {
		if (!isDragging || !dragCard) return;
		const canvas = canvasRef.current;
		if (!canvas) return;
		const rect = canvas.getBoundingClientRect();
		const scaleX = CANVAS_WIDTH / rect.width;
		const scaleY = CANVAS_HEIGHT / rect.height;
		const mouseX = (e.clientX - rect.left) * scaleX;
		const mouseY = (e.clientY - rect.top) * scaleY;
		if (dragCard === "card1") {
			setCard1Config((prev) => ({
				...prev,
				x: Math.round(mouseX - dragStart.x),
				y: Math.round(mouseY - dragStart.y)
			}));
		} else {
			setCard2Config((prev) => ({
				...prev,
				x: Math.round(mouseX - dragStart.x),
				y: Math.round(mouseY - dragStart.y)
			}));
		}
	};
	const handleMouseUp = () => {
		setIsDragging(false);
		setDragCard(null);
	};
	const currentConfig = activeCard === "card1" ? card1Config : card2Config;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900 border border-slate-800 p-4 rounded-2xl shadow-md",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2",
					children: [
						/* @__PURE__ */ _jsxDEV("h1", {
							className: "text-xl font-extrabold text-white",
							children: "PVC Smart Card Studio (5.5 cm × 8.5 cm)"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 505,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("span", {
							className: "bg-blue-500/20 text-blue-400 border border-blue-500/30 text-xs px-2 py-0.5 rounded-full font-mono font-bold",
							children: "300 DPI High-Definition"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 506,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("span", {
							className: "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-xs px-2 py-0.5 rounded-full font-bold",
							children: "4×6 inch Portrait Layout"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 509,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 504,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "text-xs text-slate-400 mt-0.5",
					children: ["4×6 inch Portrait Glossy Photo Paper with 2 Pre-Aligned Cards (Front & Back) • Exact Size: ", /* @__PURE__ */ _jsxDEV("b", { children: "5.5 cm × 8.5 cm" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 514,
						columnNumber: 104
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 513,
					columnNumber: 11
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 503,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2 flex-wrap",
					children: [
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: handleDirectPrint,
							className: "flex items-center gap-2 bg-gradient-to-r from-blue-600 via-indigo-600 to-blue-500 hover:from-blue-500 hover:to-indigo-500 text-white font-extrabold text-xs px-4 py-2.5 rounded-xl shadow-lg shadow-blue-600/30 transition-all hover:scale-105 active:scale-95 border border-blue-400/30",
							title: "Direct Print to Epson / Canon (Ctrl + P)",
							children: [/* @__PURE__ */ _jsxDEV(Printer, { className: "w-4 h-4 text-white" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 525,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "🖨️ Direct Print PVC Card" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 526,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 520,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: handleDownloadPDF,
							disabled: isProcessing,
							className: "flex items-center gap-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs px-3.5 py-2.5 rounded-xl shadow-lg shadow-indigo-600/30 transition-all hover:scale-105 disabled:opacity-50",
							title: "Download Printable 300 DPI PDF",
							children: [/* @__PURE__ */ _jsxDEV(Download, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 535,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "📄 PDF (4×6)" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 536,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 529,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: handleDownloadJPG,
							disabled: isProcessing,
							className: "flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white font-bold text-xs px-3 py-2.5 rounded-xl border border-slate-700 transition-all",
							title: "Download High-Res 1200x1800 JPG",
							children: [/* @__PURE__ */ _jsxDEV(Download, { className: "w-3.5 h-3.5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 545,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "🖼️ HD JPG" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 546,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 539,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 519,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 502,
				columnNumber: 7
			}, this),
			printAlert && /* @__PURE__ */ _jsxDEV("div", {
				className: "p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs flex items-center gap-2 animate-in fade-in",
				children: [/* @__PURE__ */ _jsxDEV(Check, { className: "w-4 h-4 text-emerald-400 flex-shrink-0" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 554,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("span", { children: printAlert }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 555,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 553,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "grid grid-cols-1 lg:grid-cols-12 gap-5 items-start",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "lg:col-span-5 space-y-4",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-md space-y-3",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs font-bold text-slate-300 uppercase tracking-wider",
									children: "Card Slots & Images"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 566,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									onClick: handleSwapCards,
									className: "text-xs font-semibold text-blue-400 hover:text-blue-300 flex items-center gap-1",
									title: "Swap Front and Back Cards",
									children: [/* @__PURE__ */ _jsxDEV(ArrowUpDown, { className: "w-3.5 h-3.5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 572,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Swap Front/Back" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 573,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 567,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 565,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: `p-3 rounded-xl border transition-all ${activeCard === "card1" ? "bg-blue-950/30 border-blue-500/50 shadow-sm" : "bg-slate-950/40 border-slate-800 hover:border-slate-700"}`,
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center justify-between mb-2",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ _jsxDEV("span", { className: "w-2 h-2 rounded-full bg-blue-500" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 585,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "text-xs font-bold text-white",
											children: "Card 1 (Front Side)"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 586,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 584,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-1.5",
										children: [/* @__PURE__ */ _jsxDEV("button", {
											onClick: () => setCard1Config((prev) => ({
												...prev,
												rotation: (prev.rotation + 90) % 360
											})),
											className: "text-[11px] px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 flex items-center gap-1",
											title: "Rotate Card 1",
											children: [/* @__PURE__ */ _jsxDEV(RotateCw, { className: "w-3 h-3 text-amber-400" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 594,
												columnNumber: 21
											}, this), /* @__PURE__ */ _jsxDEV("span", { children: [card1Config.rotation, "°"] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 595,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 589,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("button", {
											onClick: () => setCard1Config({
												x: 0,
												y: 0,
												scale: 1,
												rotation: 0
											}),
											className: "text-[11px] px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white",
											title: "Reset Position",
											children: "Reset"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 597,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 588,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 583,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "flex-1 flex items-center justify-center gap-2 py-2 px-3 bg-slate-800 hover:bg-slate-750 text-slate-200 text-xs font-semibold rounded-lg cursor-pointer border border-slate-700 transition-colors",
										children: [
											/* @__PURE__ */ _jsxDEV(Upload, { className: "w-3.5 h-3.5 text-blue-400" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 609,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("span", { children: card1Src ? "Change Front Photo/PDF" : "Upload Card 1 (Front)" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 610,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("input", {
												type: "file",
												accept: "image/*,.pdf",
												onChange: (e) => handleFileUpload(e, "card1"),
												className: "hidden"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 611,
												columnNumber: 19
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 608,
										columnNumber: 17
									}, this), card1Src && /* @__PURE__ */ _jsxDEV("button", {
										onClick: () => setCard1Src(null),
										className: "p-2 text-rose-400 hover:bg-rose-500/10 rounded-lg text-xs",
										title: "Remove Card 1",
										children: "✕"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 614,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 607,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 578,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: `p-3 rounded-xl border transition-all ${activeCard === "card2" ? "bg-blue-950/30 border-blue-500/50 shadow-sm" : "bg-slate-950/40 border-slate-800 hover:border-slate-700"}`,
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center justify-between mb-2",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ _jsxDEV("span", { className: "w-2 h-2 rounded-full bg-purple-500" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 633,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "text-xs font-bold text-white",
											children: "Card 2 (Back Side)"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 634,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 632,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-1.5",
										children: [/* @__PURE__ */ _jsxDEV("button", {
											onClick: () => setCard2Config((prev) => ({
												...prev,
												rotation: (prev.rotation + 90) % 360
											})),
											className: "text-[11px] px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 flex items-center gap-1",
											title: "Rotate Card 2",
											children: [/* @__PURE__ */ _jsxDEV(RotateCw, { className: "w-3 h-3 text-amber-400" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 642,
												columnNumber: 21
											}, this), /* @__PURE__ */ _jsxDEV("span", { children: [card2Config.rotation, "°"] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 643,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 637,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("button", {
											onClick: () => setCard2Config({
												x: 0,
												y: 0,
												scale: 1,
												rotation: 0
											}),
											className: "text-[11px] px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white",
											title: "Reset Position",
											children: "Reset"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 645,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 636,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 631,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "flex-1 flex items-center justify-center gap-2 py-2 px-3 bg-slate-800 hover:bg-slate-750 text-slate-200 text-xs font-semibold rounded-lg cursor-pointer border border-slate-700 transition-colors",
										children: [
											/* @__PURE__ */ _jsxDEV(Upload, { className: "w-3.5 h-3.5 text-purple-400" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 657,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("span", { children: card2Src ? "Change Back Photo/PDF" : "Upload Card 2 (Back)" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 658,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("input", {
												type: "file",
												accept: "image/*,.pdf",
												onChange: (e) => handleFileUpload(e, "card2"),
												className: "hidden"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 659,
												columnNumber: 19
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 656,
										columnNumber: 17
									}, this), card2Src && /* @__PURE__ */ _jsxDEV("button", {
										onClick: () => setCard2Src(null),
										className: "p-2 text-rose-400 hover:bg-rose-500/10 rounded-lg text-xs",
										title: "Remove Card 2",
										children: "✕"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 662,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 655,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 626,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 564,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-md space-y-3",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "text-xs font-bold text-slate-300 uppercase tracking-wider block",
							children: "Image Enhancement & Layout Guides"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 676,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-3 text-xs",
							children: [
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex justify-between text-slate-400 mb-1",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "flex items-center gap-1.5",
										children: [/* @__PURE__ */ _jsxDEV(Sun, { className: "w-3.5 h-3.5 text-amber-400" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 683,
											columnNumber: 63
										}, this), " Brightness"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 683,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "font-mono text-slate-200",
										children: brightness > 0 ? `+${brightness}` : brightness
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 684,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 682,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "range",
									min: "-30",
									max: "30",
									value: brightness,
									onChange: (e) => setBrightness(parseInt(e.target.value)),
									className: "w-full accent-amber-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 686,
									columnNumber: 17
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 681,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex justify-between text-slate-400 mb-1",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "flex items-center gap-1.5",
										children: [/* @__PURE__ */ _jsxDEV(Contrast, { className: "w-3.5 h-3.5 text-sky-400" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 698,
											columnNumber: 63
										}, this), " Contrast"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 698,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "font-mono text-slate-200",
										children: contrast > 0 ? `+${contrast}` : contrast
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 699,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 697,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "range",
									min: "-30",
									max: "30",
									value: contrast,
									onChange: (e) => setContrast(parseInt(e.target.value)),
									className: "w-full accent-sky-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 701,
									columnNumber: 17
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 696,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "pt-2 border-t border-slate-800 grid grid-cols-2 gap-2",
									children: [
										/* @__PURE__ */ _jsxDEV("label", {
											className: "flex items-center gap-2 cursor-pointer text-slate-300",
											children: [/* @__PURE__ */ _jsxDEV("input", {
												type: "checkbox",
												checked: showCutMarks,
												onChange: (e) => setShowCutMarks(e.target.checked),
												className: "rounded accent-blue-600"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 713,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("span", { children: "✂ Center Cut Line" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 719,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 712,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("label", {
											className: "flex items-center gap-2 cursor-pointer text-slate-300",
											children: [/* @__PURE__ */ _jsxDEV("input", {
												type: "checkbox",
												checked: roundedCorners,
												onChange: (e) => setRoundedCorners(e.target.checked),
												className: "rounded accent-blue-600"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 723,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Rounded CR80 Corner" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 729,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 722,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("label", {
											className: "flex items-center gap-2 cursor-pointer text-slate-300",
											children: [/* @__PURE__ */ _jsxDEV("input", {
												type: "checkbox",
												checked: borderStroke,
												onChange: (e) => setBorderStroke(e.target.checked),
												className: "rounded accent-blue-600"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 733,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Card Outline Border" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 739,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 732,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 711,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 680,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 675,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 562,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "lg:col-span-7 space-y-3",
					children: /* @__PURE__ */ _jsxDEV("div", {
						className: "bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-xl",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center justify-between mb-3 text-xs flex-wrap gap-2",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "font-bold text-white",
										children: "Interactive 4×6 Live Sheet"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 751,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-[11px] text-slate-400 font-mono",
										children: "(1200 × 1800 px @ 300 DPI)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 752,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 750,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									onClick: handleDirectPrint,
									className: "flex items-center gap-1.5 bg-blue-600 hover:bg-blue-500 text-white font-extrabold text-xs px-3.5 py-1.5 rounded-lg shadow-md transition-all hover:scale-105 active:scale-95",
									title: "Print PVC Card Sheet directly to connected printer",
									children: [/* @__PURE__ */ _jsxDEV(Printer, { className: "w-3.5 h-3.5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 761,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "🖨️ Print PVC Card Now" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 762,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 756,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 749,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "relative flex justify-center bg-slate-950 p-4 rounded-xl border border-slate-800/80 overflow-hidden shadow-inner",
								children: [/* @__PURE__ */ _jsxDEV("canvas", {
									ref: canvasRef,
									width: CANVAS_WIDTH,
									height: CANVAS_HEIGHT,
									onMouseDown: handleMouseDown,
									onMouseMove: handleMouseMove,
									onMouseUp: handleMouseUp,
									onMouseLeave: handleMouseUp,
									className: "w-full max-w-[460px] h-auto bg-white rounded-lg shadow-2xl cursor-move border border-slate-700",
									style: { aspectRatio: "4/6" }
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 768,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "absolute top-6 left-6 bg-slate-900/90 text-blue-400 border border-blue-500/30 px-2 py-1 rounded text-[10px] font-mono font-bold pointer-events-none",
									children: "CR-80: 85.6 mm × 54 mm"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 781,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 767,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center justify-between pt-2 border-t border-slate-800 text-xs flex-wrap gap-2",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-slate-400",
									children: "✂️ 300 DPI Pre-Aligned Center Cut Mark"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 788,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ _jsxDEV("button", {
										onClick: handleDirectPrint,
										className: "flex items-center gap-1 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs px-3 py-1.5 rounded-lg transition-colors",
										children: [/* @__PURE__ */ _jsxDEV(Printer, { className: "w-3.5 h-3.5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 794,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Print Sheet (Ctrl + P)" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 795,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 790,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("button", {
										onClick: handleDownloadPDF,
										className: "flex items-center gap-1 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs px-3 py-1.5 rounded-lg border border-slate-700 transition-colors",
										children: [/* @__PURE__ */ _jsxDEV(Download, { className: "w-3.5 h-3.5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 801,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: "PDF" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 802,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 797,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 789,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 787,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "mt-3 p-3 rounded-xl bg-slate-950 border border-slate-800/80 text-xs text-slate-300 leading-relaxed flex items-start gap-2.5",
								children: [/* @__PURE__ */ _jsxDEV(HelpCircle, { className: "w-4 h-4 text-blue-400 flex-shrink-0 mt-0.5" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 809,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", { children: [
									/* @__PURE__ */ _jsxDEV("b", {
										className: "text-white",
										children: "Printer Setup Tip:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 811,
										columnNumber: 17
									}, this),
									" Set your printer paper to ",
									/* @__PURE__ */ _jsxDEV("b", { children: "4×6 in (10×15 cm) Photo Paper Glossy" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 811,
										columnNumber: 92
									}, this),
									". In printer properties, select ",
									/* @__PURE__ */ _jsxDEV("b", { children: "High Quality" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 811,
										columnNumber: 167
									}, this),
									" and ",
									/* @__PURE__ */ _jsxDEV("b", { children: "Fit to Printable Area / 100%" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 811,
										columnNumber: 191
									}, this),
									" for exact card dimensions!"
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 810,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 808,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 748,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 747,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 560,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 500,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsUUFBUSxpQkFBaUI7QUFDbkQsU0FDRSxRQUNBLFNBQ0EsVUFDQSxVQU1BLE9BR0EsYUFDQSxLQUNBLFVBQ0Esa0JBRUs7QUFDUCxTQUFTLGFBQWE7QUFDdEIsU0FBUyx5QkFBeUI7QUFDbEMsU0FBUyx1QkFBdUI7OztBQUVoQyxPQUFPLE1BQU0sc0JBQWdDOztDQUUzQyxNQUFNLFlBQVksT0FBaUMsSUFBSTs7Q0FHdkQsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUF3QixJQUFJO0NBQzVELE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBd0IsSUFBSTs7Q0FHNUQsTUFBTSxDQUFDLFlBQVksaUJBQWlCLFNBQTRCLE9BQU87O0NBR3ZFLE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFTO0VBQzdDLEdBQUc7RUFDSCxHQUFHO0VBQ0gsT0FBTztFQUNQLFVBQVU7Q0FDWixDQUFDO0NBRUQsTUFBTSxDQUFDLGFBQWEsa0JBQWtCLFNBQVM7RUFDN0MsR0FBRztFQUNILEdBQUc7RUFDSCxPQUFPO0VBQ1AsVUFBVTtDQUNaLENBQUM7O0NBR0QsTUFBTSxDQUFDLFlBQVksaUJBQWlCLFNBQWlCLENBQUM7Q0FDdEQsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFpQixDQUFDO0NBQ2xELE1BQU0sQ0FBQyxjQUFjLG1CQUFtQixTQUFrQixJQUFJO0NBQzlELE1BQU0sQ0FBQyxnQkFBZ0IscUJBQXFCLFNBQWtCLElBQUk7Q0FDbEUsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQWtCLElBQUk7Q0FDOUQsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQWtCLEtBQUs7Q0FDL0QsTUFBTSxDQUFDLFlBQVksaUJBQWlCLFNBQXdCLElBQUk7O0NBR2hFLE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUFrQixLQUFLO0NBQzNELE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBbUMsSUFBSTtDQUN2RSxNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBbUM7RUFBRSxHQUFHO0VBQUcsR0FBRztDQUFFLENBQUM7OztDQUluRixNQUFNLGVBQWU7Q0FDckIsTUFBTSxnQkFBZ0I7Ozs7O0NBTXRCLE1BQU0sYUFBYTtDQUNuQixNQUFNLGNBQWM7Ozs7OztDQU9wQixNQUFNLGdCQUFnQjtDQUN0QixNQUFNLGtCQUFrQjtDQUN4QixNQUFNLGtCQUFrQjs7Q0FHeEIsTUFBTSxjQUFjLE9BQWdDLElBQUk7Q0FDeEQsTUFBTSxjQUFjLE9BQWdDLElBQUk7O0NBR3hELGdCQUFnQjtFQUNkLElBQUksVUFBVTtHQUNaLE1BQU0sTUFBTSxJQUFJLE1BQU07R0FDdEIsSUFBSSxjQUFjO0dBQ2xCLElBQUksZUFBZTtJQUNqQixZQUFZLFVBQVU7SUFDdEIsYUFBYTtHQUNmO0dBQ0EsSUFBSSxNQUFNO0VBQ1osT0FBTztHQUNMLFlBQVksVUFBVTtHQUN0QixhQUFhO0VBQ2Y7Q0FDRixHQUFHLENBQUMsUUFBUSxDQUFDOztDQUdiLGdCQUFnQjtFQUNkLElBQUksVUFBVTtHQUNaLE1BQU0sTUFBTSxJQUFJLE1BQU07R0FDdEIsSUFBSSxjQUFjO0dBQ2xCLElBQUksZUFBZTtJQUNqQixZQUFZLFVBQVU7SUFDdEIsYUFBYTtHQUNmO0dBQ0EsSUFBSSxNQUFNO0VBQ1osT0FBTztHQUNMLFlBQVksVUFBVTtHQUN0QixhQUFhO0VBQ2Y7Q0FDRixHQUFHLENBQUMsUUFBUSxDQUFDOztDQUdiLGdCQUFnQjtFQUNkLE1BQU0sMEJBQTBCLGtCQUFrQjtFQUNsRCxNQUFNLHdCQUF3QixrQkFBa0I7RUFDaEQsTUFBTSx3QkFBd0Isa0JBQWtCO0VBRWhELE9BQU8saUJBQWlCLG9CQUFvQixpQkFBaUI7RUFDN0QsT0FBTyxpQkFBaUIsa0JBQWtCLGVBQWU7RUFDekQsT0FBTyxpQkFBaUIsa0JBQWtCLGVBQWU7RUFFekQsYUFBYTtHQUNYLE9BQU8sb0JBQW9CLG9CQUFvQixpQkFBaUI7R0FDaEUsT0FBTyxvQkFBb0Isa0JBQWtCLGVBQWU7R0FDNUQsT0FBTyxvQkFBb0Isa0JBQWtCLGVBQWU7RUFDOUQ7Q0FDRixDQUFDOztDQUdELGdCQUFnQjtFQUNkLGFBQWE7Q0FDZixHQUFHO0VBQUM7RUFBYTtFQUFhO0VBQVk7RUFBVTtFQUFjO0VBQWdCO0NBQVksQ0FBQzs7Q0FHL0YsTUFBTSxxQkFBcUI7RUFDekIsTUFBTSxTQUFTLFVBQVU7RUFDekIsSUFBSSxDQUFDLFFBQVE7RUFDYixNQUFNLE1BQU0sT0FBTyxXQUFXLElBQUk7RUFDbEMsSUFBSSxDQUFDLEtBQUs7O0VBR1YsSUFBSSxZQUFZO0VBQ2hCLElBQUksU0FBUyxHQUFHLEdBQUcsY0FBYyxhQUFhOztFQUc5QyxNQUFNLFlBQVksY0FBYyxNQUFNLFdBQVcsY0FBYyxNQUFNLFNBQVM7O0VBRzlFLGVBQ0UsS0FDQSxZQUFZLFNBQ1osZ0JBQWdCLFlBQVksR0FDNUIsa0JBQWtCLFlBQVksR0FDOUIsWUFBWSxPQUNaLFlBQVksVUFDWixrQkFDQSxTQUNGOztFQUdBLGVBQ0UsS0FDQSxZQUFZLFNBQ1osZ0JBQWdCLFlBQVksR0FDNUIsa0JBQWtCLFlBQVksR0FDOUIsWUFBWSxPQUNaLFlBQVksVUFDWixpQkFDQSxTQUNGOztFQUdBLElBQUksY0FBYztHQUNoQixJQUFJLEtBQUs7R0FDVCxJQUFJLGNBQWM7R0FDbEIsSUFBSSxZQUFZO0dBQ2hCLElBQUksWUFBWSxDQUFDLEdBQUcsQ0FBQyxDQUFDOztHQUd0QixNQUFNLE9BQU87R0FDYixJQUFJLFVBQVU7R0FDZCxJQUFJLE9BQU8sSUFBSSxJQUFJO0dBQ25CLElBQUksT0FBTyxlQUFlLElBQUksSUFBSTtHQUNsQyxJQUFJLE9BQU87O0dBR1gsSUFBSSxZQUFZLENBQUMsQ0FBQztHQUNsQixJQUFJLFlBQVk7R0FDaEIsSUFBSSxPQUFPO0dBQ1gsSUFBSSxZQUFZO0dBQ2hCLElBQUksU0FBUyx1REFBdUQsZUFBZSxHQUFHLE9BQU8sRUFBRTs7R0FHL0YsY0FBYyxLQUFLLElBQUksRUFBRTtHQUN6QixjQUFjLEtBQUssZUFBZSxJQUFJLEVBQUU7R0FDeEMsY0FBYyxLQUFLLElBQUksZ0JBQWdCLEVBQUU7R0FDekMsY0FBYyxLQUFLLGVBQWUsSUFBSSxnQkFBZ0IsRUFBRTtHQUV4RCxJQUFJLFFBQVE7RUFDZDtDQUNGO0NBRUEsTUFBTSxpQkFBaUIsS0FBK0IsR0FBVyxNQUFjO0VBQzdFLElBQUksY0FBYztFQUNsQixJQUFJLFlBQVk7RUFDaEIsSUFBSSxVQUFVO0VBQ2QsSUFBSSxPQUFPLElBQUksSUFBSSxDQUFDO0VBQ3BCLElBQUksT0FBTyxJQUFJLElBQUksQ0FBQztFQUNwQixJQUFJLE9BQU8sR0FBRyxJQUFJLEVBQUU7RUFDcEIsSUFBSSxPQUFPLEdBQUcsSUFBSSxFQUFFO0VBQ3BCLElBQUksT0FBTztDQUNiO0NBRUEsTUFBTSxrQkFDSixLQUNBLEtBQ0EsU0FDQSxTQUNBLE9BQ0EsVUFDQSxrQkFDQSxXQUNHO0VBQ0gsTUFBTSxJQUFJO0VBQ1YsTUFBTSxJQUFJO0VBQ1YsTUFBTSxPQUFPLFVBQVUsSUFBSTtFQUMzQixNQUFNLE1BQU0sVUFBVSxJQUFJO0VBRTFCLElBQUksS0FBSzs7RUFHVCxNQUFNLFNBQVMsaUJBQWlCLEtBQUs7RUFDckMsSUFBSSxVQUFVO0VBQ2QsSUFBSSxVQUFVLE1BQU0sS0FBSyxHQUFHLEdBQUcsTUFBTTtFQUVyQyxJQUFJLEtBQUs7R0FDUCxJQUFJLEtBQUs7O0dBRVQsSUFBSSxLQUFLOztHQUdULElBQUksU0FBUzs7R0FHYixJQUFJLFVBQVUsU0FBUyxPQUFPO0dBQzlCLElBQUksT0FBUSxXQUFXLEtBQUssS0FBTSxHQUFHO0dBQ3JDLElBQUksTUFBTSxPQUFPLEtBQUs7O0dBR3RCLElBQUksVUFBVSxLQUFLLENBQUMsSUFBSSxHQUFHLENBQUMsSUFBSSxHQUFHLEdBQUcsQ0FBQztHQUN2QyxJQUFJLFFBQVE7RUFDZCxPQUFPOztHQUVMLElBQUksWUFBWTtHQUNoQixJQUFJLEtBQUs7R0FFVCxJQUFJLGNBQWM7R0FDbEIsSUFBSSxZQUFZO0dBQ2hCLElBQUksWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDO0dBQ3ZCLElBQUksT0FBTzs7R0FHWCxJQUFJLFlBQVk7R0FDaEIsSUFBSSxPQUFPO0dBQ1gsSUFBSSxZQUFZO0dBQ2hCLElBQUksU0FBUyxrQkFBa0IsU0FBUyxVQUFVLEVBQUU7R0FDcEQsSUFBSSxPQUFPO0dBQ1gsSUFBSSxZQUFZO0dBQ2hCLElBQUksU0FBUyxtQ0FBbUMsU0FBUyxVQUFVLEVBQUU7R0FDckUsSUFBSSxTQUFTLGtEQUFrRCxTQUFTLFVBQVUsRUFBRTtFQUN0Rjs7RUFHQSxJQUFJLGNBQWM7R0FDaEIsSUFBSSxVQUFVO0dBQ2QsSUFBSSxVQUFVLE1BQU0sS0FBSyxHQUFHLEdBQUcsTUFBTTtHQUNyQyxJQUFJLGNBQWM7R0FDbEIsSUFBSSxZQUFZO0dBQ2hCLElBQUksWUFBWSxDQUFDLENBQUM7R0FDbEIsSUFBSSxPQUFPO0VBQ2I7RUFFQSxJQUFJLFFBQVE7Q0FDZDs7Q0FHQSxNQUFNLG9CQUFvQixHQUF3QyxXQUE4QjtFQUM5RixNQUFNLE9BQU8sRUFBRSxPQUFPLFFBQVE7RUFDOUIsSUFBSSxDQUFDLE1BQU07RUFFWCxNQUFNLFNBQVMsSUFBSSxXQUFXO0VBQzlCLE9BQU8sVUFBVSxVQUFVO0dBQ3pCLE1BQU0sU0FBUyxNQUFNLFFBQVE7R0FDN0IsSUFBSSxXQUFXLFNBQVM7SUFDdEIsWUFBWSxNQUFNO0lBQ2xCLGNBQWMsT0FBTztHQUN2QixPQUFPO0lBQ0wsWUFBWSxNQUFNO0lBQ2xCLGNBQWMsT0FBTztHQUN2QjtFQUNGO0VBQ0EsT0FBTyxjQUFjLElBQUk7RUFDekIsRUFBRSxPQUFPLFFBQVE7Q0FDbkI7O0NBR0EsTUFBTSx3QkFBd0I7RUFDNUIsTUFBTSxVQUFVO0VBQ2hCLFlBQVksUUFBUTtFQUNwQixZQUFZLE9BQU87RUFFbkIsTUFBTSxVQUFVLEVBQUUsR0FBRyxZQUFZO0VBQ2pDLGVBQWUsRUFBRSxHQUFHLFlBQVksQ0FBQztFQUNqQyxlQUFlLE9BQU87Q0FDeEI7O0NBR0EsTUFBTSxxQkFBcUIsUUFBZ0I7RUFDekMsSUFBSSxlQUFlLFNBQVM7R0FDMUIsZ0JBQWUsVUFBUztJQUFFLEdBQUc7SUFBTSxPQUFPO0dBQUksRUFBRTtFQUNsRCxPQUFPO0dBQ0wsZ0JBQWUsVUFBUztJQUFFLEdBQUc7SUFBTSxPQUFPO0dBQUksRUFBRTtFQUNsRDtDQUNGOztDQUdBLE1BQU0sZUFBZSxJQUFZLE9BQWU7RUFDOUMsSUFBSSxlQUFlLFNBQVM7R0FDMUIsZ0JBQWUsVUFBUztJQUFFLEdBQUc7SUFBTSxHQUFHLEtBQUssSUFBSTtJQUFJLEdBQUcsS0FBSyxJQUFJO0dBQUcsRUFBRTtFQUN0RSxPQUFPO0dBQ0wsZ0JBQWUsVUFBUztJQUFFLEdBQUc7SUFBTSxHQUFHLEtBQUssSUFBSTtJQUFJLEdBQUcsS0FBSyxJQUFJO0dBQUcsRUFBRTtFQUN0RTtDQUNGOztDQUdBLE1BQU0scUJBQXFCO0VBQ3pCLElBQUksZUFBZSxTQUFTO0dBQzFCLGdCQUFlLFVBQVM7SUFBRSxHQUFHO0lBQU0sV0FBVyxLQUFLLFdBQVcsTUFBTTtHQUFJLEVBQUU7RUFDNUUsT0FBTztHQUNMLGdCQUFlLFVBQVM7SUFBRSxHQUFHO0lBQU0sV0FBVyxLQUFLLFdBQVcsTUFBTTtHQUFJLEVBQUU7RUFDNUU7Q0FDRjs7Q0FHQSxNQUFNLG9CQUFvQjtFQUN4QixlQUFlO0dBQUUsR0FBRztHQUFHLEdBQUc7R0FBRyxPQUFPO0dBQUssVUFBVTtFQUFFLENBQUM7RUFDdEQsZUFBZTtHQUFFLEdBQUc7R0FBRyxHQUFHO0dBQUcsT0FBTztHQUFLLFVBQVU7RUFBRSxDQUFDO0VBQ3RELGNBQWMsQ0FBQztFQUNmLFlBQVksQ0FBQztDQUNmOztDQUdBLE1BQU0sMEJBQTBCO0VBQzlCLE1BQU0sU0FBUyxVQUFVO0VBQ3pCLElBQUksQ0FBQyxRQUFRO0VBQ2IsZ0JBQWdCLElBQUk7RUFFcEIsSUFBSTtHQUNGLE1BQU0sVUFBVSxPQUFPLFVBQVUsY0FBYyxHQUFJO0dBQ25ELE1BQU0sSUFBSSxTQUFTLGNBQWMsR0FBRztHQUNwQyxFQUFFLE9BQU87R0FDVCxNQUFNLFdBQVcsdUJBQXVCLEtBQUssSUFBSSxFQUFFO0dBQ25ELEVBQUUsV0FBVztHQUNiLEVBQUUsTUFBTTtHQUVSLGtCQUFrQjtJQUNoQixJQUFJLFdBQVcsS0FBSyxJQUFJO0lBQ3hCLE9BQU87SUFDUCxNQUFNO0lBQ04sTUFBTTtJQUNOLFdBQVcsSUFBSSxLQUFLLENBQUMsQ0FBQyxtQkFBbUIsT0FBTztHQUNsRCxDQUFDO0VBQ0gsU0FBUyxHQUFHO0dBQ1YsUUFBUSxNQUFNLENBQUM7RUFDakIsVUFBVTtHQUNSLGdCQUFnQixLQUFLO0VBQ3ZCO0NBQ0Y7O0NBR0EsTUFBTSwwQkFBMEI7RUFDOUIsTUFBTSxTQUFTLFVBQVU7RUFDekIsSUFBSSxDQUFDLFFBQVE7RUFDYixnQkFBZ0IsSUFBSTtFQUVwQixJQUFJO0dBQ0YsTUFBTSxVQUFVLE9BQU8sVUFBVSxjQUFjLEdBQUk7O0dBRW5ELE1BQU0sTUFBTSxJQUFJLE1BQU07SUFDcEIsYUFBYTtJQUNiLE1BQU07SUFDTixRQUFRLENBQUMsR0FBRyxDQUFDO0dBQ2YsQ0FBQztHQUVELElBQUksU0FBUyxTQUFTLFFBQVEsR0FBRyxHQUFHLEdBQUcsQ0FBQztHQUN4QyxNQUFNLFdBQVcsMEJBQTBCLEtBQUssSUFBSSxFQUFFO0dBQ3RELElBQUksS0FBSyxRQUFRO0dBRWpCLGtCQUFrQjtJQUNoQixJQUFJLFdBQVcsS0FBSyxJQUFJO0lBQ3hCLE9BQU87SUFDUCxNQUFNO0lBQ04sTUFBTTtJQUNOLFdBQVcsSUFBSSxLQUFLLENBQUMsQ0FBQyxtQkFBbUIsT0FBTztHQUNsRCxDQUFDO0VBQ0gsU0FBUyxHQUFHO0dBQ1YsUUFBUSxNQUFNLENBQUM7RUFDakIsVUFBVTtHQUNSLGdCQUFnQixLQUFLO0VBQ3ZCO0NBQ0Y7O0NBR0EsTUFBTSwwQkFBMEI7RUFDOUIsTUFBTSxTQUFTLFVBQVU7RUFDekIsSUFBSSxDQUFDLFFBQVE7RUFDYixJQUFJO0dBQ0YsTUFBTSxVQUFVLE9BQU8sVUFBVSxjQUFjLENBQUc7R0FDbEQsZ0JBQWdCLFNBQVM7SUFDdkIsYUFBYTtJQUNiLE9BQU87R0FDVCxDQUFDO0dBQ0QsY0FBYyxnR0FBZ0c7R0FDOUcsaUJBQWlCLGNBQWMsSUFBSSxHQUFHLEdBQUk7RUFDNUMsU0FBUyxHQUFHO0dBQ1YsUUFBUSxNQUFNLENBQUM7R0FDZixPQUFPLE1BQU07RUFDZjtDQUNGOztDQUdBLE1BQU0sbUJBQW1CLE1BQTJDO0VBQ2xFLE1BQU0sU0FBUyxVQUFVO0VBQ3pCLElBQUksQ0FBQyxRQUFRO0VBQ2IsTUFBTSxPQUFPLE9BQU8sc0JBQXNCO0VBQzFDLE1BQU0sU0FBUyxlQUFlLEtBQUs7RUFDbkMsTUFBTSxTQUFTLGdCQUFnQixLQUFLO0VBRXBDLE1BQU0sVUFBVSxFQUFFLFVBQVUsS0FBSyxRQUFRO0VBQ3pDLE1BQU0sVUFBVSxFQUFFLFVBQVUsS0FBSyxPQUFPOztFQUd4QyxJQUFJLFNBQVMsZ0JBQWdCLEdBQUc7R0FDOUIsWUFBWSxPQUFPO0dBQ25CLGNBQWMsT0FBTztHQUNyQixjQUFjLElBQUk7R0FDbEIsYUFBYTtJQUFFLEdBQUcsU0FBUyxZQUFZO0lBQUcsR0FBRyxTQUFTLFlBQVk7R0FBRSxDQUFDO0VBQ3ZFLE9BQU87R0FDTCxZQUFZLE9BQU87R0FDbkIsY0FBYyxPQUFPO0dBQ3JCLGNBQWMsSUFBSTtHQUNsQixhQUFhO0lBQUUsR0FBRyxTQUFTLFlBQVk7SUFBRyxHQUFHLFNBQVMsWUFBWTtHQUFFLENBQUM7RUFDdkU7Q0FDRjtDQUVBLE1BQU0sbUJBQW1CLE1BQTJDO0VBQ2xFLElBQUksQ0FBQyxjQUFjLENBQUMsVUFBVTtFQUM5QixNQUFNLFNBQVMsVUFBVTtFQUN6QixJQUFJLENBQUMsUUFBUTtFQUNiLE1BQU0sT0FBTyxPQUFPLHNCQUFzQjtFQUMxQyxNQUFNLFNBQVMsZUFBZSxLQUFLO0VBQ25DLE1BQU0sU0FBUyxnQkFBZ0IsS0FBSztFQUVwQyxNQUFNLFVBQVUsRUFBRSxVQUFVLEtBQUssUUFBUTtFQUN6QyxNQUFNLFVBQVUsRUFBRSxVQUFVLEtBQUssT0FBTztFQUV4QyxJQUFJLGFBQWEsU0FBUztHQUN4QixnQkFBZSxVQUFTO0lBQ3RCLEdBQUc7SUFDSCxHQUFHLEtBQUssTUFBTSxTQUFTLFVBQVUsQ0FBQztJQUNsQyxHQUFHLEtBQUssTUFBTSxTQUFTLFVBQVUsQ0FBQztHQUNwQyxFQUFFO0VBQ0osT0FBTztHQUNMLGdCQUFlLFVBQVM7SUFDdEIsR0FBRztJQUNILEdBQUcsS0FBSyxNQUFNLFNBQVMsVUFBVSxDQUFDO0lBQ2xDLEdBQUcsS0FBSyxNQUFNLFNBQVMsVUFBVSxDQUFDO0dBQ3BDLEVBQUU7RUFDSjtDQUNGO0NBRUEsTUFBTSxzQkFBc0I7RUFDMUIsY0FBYyxLQUFLO0VBQ25CLFlBQVksSUFBSTtDQUNsQjtDQUVBLE1BQU0sZ0JBQWdCLGVBQWUsVUFBVSxjQUFjO0NBRTdELE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUVFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNFLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUFvQztNQUEyQzs7Ozs7TUFDN0Ysd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQThHO01BRXhIOzs7OztNQUNOLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUE2RztNQUV2SDs7Ozs7S0FDSDs7Ozs7Y0FDTCx3QkFBQyxLQUFEO0tBQUcsV0FBVTtlQUFiLENBQTZDLCtGQUNnRCx3QkFBQyxLQUFELFlBQUcsa0JBQWtCOzs7O2FBQy9HOzs7OztZQUNBOzs7O2NBR0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNFLHdCQUFDLFVBQUQ7T0FDRSxTQUFTO09BQ1QsV0FBVTtPQUNWLE9BQU07aUJBSFIsQ0FLRSx3QkFBQyxTQUFELEVBQVMsV0FBVSxxQkFBc0I7Ozs7aUJBQ3pDLHdCQUFDLFFBQUQsWUFBTSw0QkFBK0I7Ozs7ZUFDL0I7Ozs7OztNQUVSLHdCQUFDLFVBQUQ7T0FDRSxTQUFTO09BQ1QsVUFBVTtPQUNWLFdBQVU7T0FDVixPQUFNO2lCQUpSLENBTUUsd0JBQUMsVUFBRCxFQUFVLFdBQVUsVUFBVzs7OztpQkFDL0Isd0JBQUMsUUFBRCxZQUFNLGVBQWtCOzs7O2VBQ2xCOzs7Ozs7TUFFUix3QkFBQyxVQUFEO09BQ0UsU0FBUztPQUNULFVBQVU7T0FDVixXQUFVO09BQ1YsT0FBTTtpQkFKUixDQU1FLHdCQUFDLFVBQUQsRUFBVSxXQUFVLGNBQWU7Ozs7aUJBQ25DLHdCQUFDLFFBQUQsWUFBTSxhQUFnQjs7OztlQUNoQjs7Ozs7O0tBQ0w7Ozs7O1lBQ0Y7Ozs7OztHQUdKLGNBQ0Msd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQsRUFBTyxXQUFVLHlDQUEwQzs7OztjQUMzRCx3QkFBQyxRQUFELFlBQU8sV0FBaUI7Ozs7WUFDckI7Ozs7OztHQUlQLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FFRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBRUUsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUE0RDtRQUF5Qjs7OztrQkFDckcsd0JBQUMsVUFBRDtTQUNFLFNBQVM7U0FDVCxXQUFVO1NBQ1YsT0FBTTttQkFIUixDQUtFLHdCQUFDLGFBQUQsRUFBYSxXQUFVLGNBQWU7Ozs7bUJBQ3RDLHdCQUFDLFFBQUQsWUFBTSxrQkFBcUI7Ozs7aUJBQ3JCOzs7OztnQkFDTDs7Ozs7O09BR0wsd0JBQUMsT0FBRDtRQUFLLFdBQVcsd0NBQ2QsZUFBZSxVQUNYLGdEQUNBO2tCQUhOLENBS0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLFFBQUQsRUFBTSxXQUFVLG1DQUF5Qzs7OztvQkFDekQsd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQStCO1VBQXlCOzs7O2tCQUNyRTs7Ozs7bUJBQ0wsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxVQUFEO1dBQ0UsZUFBZSxnQkFBZSxVQUFTO1lBQUUsR0FBRztZQUFNLFdBQVcsS0FBSyxXQUFXLE1BQU07V0FBSSxFQUFFO1dBQ3pGLFdBQVU7V0FDVixPQUFNO3FCQUhSLENBS0Usd0JBQUMsVUFBRCxFQUFVLFdBQVUseUJBQTBCOzs7O3FCQUM5Qyx3QkFBQyxRQUFELGFBQU8sWUFBWSxVQUFTLEdBQU87Ozs7bUJBQzdCOzs7OztvQkFDUix3QkFBQyxVQUFEO1dBQ0UsZUFBZSxlQUFlO1lBQUUsR0FBRztZQUFHLEdBQUc7WUFBRyxPQUFPO1lBQUssVUFBVTtXQUFFLENBQUM7V0FDckUsV0FBVTtXQUNWLE9BQU07cUJBQ1A7VUFFTzs7OztrQkFDTDs7Ozs7aUJBQ0Y7Ozs7O2tCQUVMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsU0FBRDtVQUFPLFdBQVU7b0JBQWpCO1dBQ0Usd0JBQUMsUUFBRCxFQUFRLFdBQVUsNEJBQTZCOzs7OztXQUMvQyx3QkFBQyxRQUFELFlBQU8sV0FBVywyQkFBMkIsd0JBQThCOzs7OztXQUMzRSx3QkFBQyxTQUFEO1lBQU8sTUFBSztZQUFPLFFBQU87WUFBZSxXQUFXLE1BQU0saUJBQWlCLEdBQUcsT0FBTztZQUFHLFdBQVU7V0FBVTs7Ozs7VUFDdkc7Ozs7O21CQUNOLFlBQ0Msd0JBQUMsVUFBRDtVQUNFLGVBQWUsWUFBWSxJQUFJO1VBQy9CLFdBQVU7VUFDVixPQUFNO29CQUNQO1NBRU87Ozs7aUJBRVA7Ozs7O2dCQUNGOzs7Ozs7T0FHTCx3QkFBQyxPQUFEO1FBQUssV0FBVyx3Q0FDZCxlQUFlLFVBQ1gsZ0RBQ0E7a0JBSE4sQ0FLRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsUUFBRCxFQUFNLFdBQVUscUNBQTJDOzs7O29CQUMzRCx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBK0I7VUFBd0I7Ozs7a0JBQ3BFOzs7OzttQkFDTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLFVBQUQ7V0FDRSxlQUFlLGdCQUFlLFVBQVM7WUFBRSxHQUFHO1lBQU0sV0FBVyxLQUFLLFdBQVcsTUFBTTtXQUFJLEVBQUU7V0FDekYsV0FBVTtXQUNWLE9BQU07cUJBSFIsQ0FLRSx3QkFBQyxVQUFELEVBQVUsV0FBVSx5QkFBMEI7Ozs7cUJBQzlDLHdCQUFDLFFBQUQsYUFBTyxZQUFZLFVBQVMsR0FBTzs7OzttQkFDN0I7Ozs7O29CQUNSLHdCQUFDLFVBQUQ7V0FDRSxlQUFlLGVBQWU7WUFBRSxHQUFHO1lBQUcsR0FBRztZQUFHLE9BQU87WUFBSyxVQUFVO1dBQUUsQ0FBQztXQUNyRSxXQUFVO1dBQ1YsT0FBTTtxQkFDUDtVQUVPOzs7O2tCQUNMOzs7OztpQkFDRjs7Ozs7a0JBRUwsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxTQUFEO1VBQU8sV0FBVTtvQkFBakI7V0FDRSx3QkFBQyxRQUFELEVBQVEsV0FBVSw4QkFBK0I7Ozs7O1dBQ2pELHdCQUFDLFFBQUQsWUFBTyxXQUFXLDBCQUEwQix1QkFBNkI7Ozs7O1dBQ3pFLHdCQUFDLFNBQUQ7WUFBTyxNQUFLO1lBQU8sUUFBTztZQUFlLFdBQVcsTUFBTSxpQkFBaUIsR0FBRyxPQUFPO1lBQUcsV0FBVTtXQUFVOzs7OztVQUN2Rzs7Ozs7bUJBQ04sWUFDQyx3QkFBQyxVQUFEO1VBQ0UsZUFBZSxZQUFZLElBQUk7VUFDL0IsV0FBVTtVQUNWLE9BQU07b0JBQ1A7U0FFTzs7OztpQkFFUDs7Ozs7Z0JBQ0Y7Ozs7OztNQUNGOzs7OztlQUdMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQWtFO01BRTVFOzs7O2dCQUVOLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQWhCLENBQTRDLHdCQUFDLEtBQUQsRUFBSyxXQUFVLDZCQUE4Qjs7OztvQkFBQyxhQUFpQjs7Ozs7bUJBQzNHLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUE0QixhQUFhLElBQUksSUFBSSxlQUFlO1NBQWlCOzs7O2lCQUM5Rjs7Ozs7a0JBQ0wsd0JBQUMsU0FBRDtTQUNFLE1BQUs7U0FDTCxLQUFJO1NBQ0osS0FBSTtTQUNKLE9BQU87U0FDUCxXQUFXLE1BQU0sY0FBYyxTQUFTLEVBQUUsT0FBTyxLQUFLLENBQUM7U0FDdkQsV0FBVTtRQUNYOzs7O2dCQUNFOzs7OztRQUVMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFoQixDQUE0Qyx3QkFBQyxVQUFELEVBQVUsV0FBVSwyQkFBNEI7Ozs7b0JBQUMsV0FBZTs7Ozs7bUJBQzVHLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUE0QixXQUFXLElBQUksSUFBSSxhQUFhO1NBQWU7Ozs7aUJBQ3hGOzs7OztrQkFDTCx3QkFBQyxTQUFEO1NBQ0UsTUFBSztTQUNMLEtBQUk7U0FDSixLQUFJO1NBQ0osT0FBTztTQUNQLFdBQVcsTUFBTSxZQUFZLFNBQVMsRUFBRSxPQUFPLEtBQUssQ0FBQztTQUNyRCxXQUFVO1FBQ1g7Ozs7Z0JBQ0U7Ozs7O1FBRUwsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWY7VUFDRSx3QkFBQyxTQUFEO1dBQU8sV0FBVTtxQkFBakIsQ0FDRSx3QkFBQyxTQUFEO1lBQ0UsTUFBSztZQUNMLFNBQVM7WUFDVCxXQUFXLE1BQU0sZ0JBQWdCLEVBQUUsT0FBTyxPQUFPO1lBQ2pELFdBQVU7V0FDWDs7OztxQkFDRCx3QkFBQyxRQUFELFlBQU0sb0JBQXVCOzs7O21CQUN4Qjs7Ozs7O1VBRVAsd0JBQUMsU0FBRDtXQUFPLFdBQVU7cUJBQWpCLENBQ0Usd0JBQUMsU0FBRDtZQUNFLE1BQUs7WUFDTCxTQUFTO1lBQ1QsV0FBVyxNQUFNLGtCQUFrQixFQUFFLE9BQU8sT0FBTztZQUNuRCxXQUFVO1dBQ1g7Ozs7cUJBQ0Qsd0JBQUMsUUFBRCxZQUFNLHNCQUF5Qjs7OzttQkFDMUI7Ozs7OztVQUVQLHdCQUFDLFNBQUQ7V0FBTyxXQUFVO3FCQUFqQixDQUNFLHdCQUFDLFNBQUQ7WUFDRSxNQUFLO1lBQ0wsU0FBUztZQUNULFdBQVcsTUFBTSxnQkFBZ0IsRUFBRSxPQUFPLE9BQU87WUFDakQsV0FBVTtXQUNYOzs7O3FCQUNELHdCQUFDLFFBQUQsWUFBTSxzQkFBeUI7Ozs7bUJBQzFCOzs7Ozs7U0FDSjs7Ozs7O09BQ0Y7Ozs7O2NBQ0Y7Ozs7O2FBQ0Y7Ozs7O2NBR0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFDYix3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBdUI7U0FBZ0M7Ozs7bUJBQ3ZFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUF1QztTQUFnQzs7OztpQkFDcEY7Ozs7O2tCQUdMLHdCQUFDLFVBQUQ7U0FDRSxTQUFTO1NBQ1QsV0FBVTtTQUNWLE9BQU07bUJBSFIsQ0FLRSx3QkFBQyxTQUFELEVBQVMsV0FBVSxjQUFlOzs7O21CQUNsQyx3QkFBQyxRQUFELFlBQU0seUJBQTRCOzs7O2lCQUM1Qjs7Ozs7Z0JBQ0w7Ozs7OztPQUdMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsVUFBRDtTQUNFLEtBQUs7U0FDTCxPQUFPO1NBQ1AsUUFBUTtTQUNSLGFBQWE7U0FDYixhQUFhO1NBQ2IsV0FBVztTQUNYLGNBQWM7U0FDZCxXQUFVO1NBQ1YsT0FBTyxFQUFFLGFBQWEsTUFBTTtRQUM3Qjs7OztrQkFHRCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBc0o7UUFFaEs7Ozs7Z0JBQ0Y7Ozs7OztPQUdMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQWlCO1FBQTRDOzs7O2tCQUM3RSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLFVBQUQ7VUFDRSxTQUFTO1VBQ1QsV0FBVTtvQkFGWixDQUlFLHdCQUFDLFNBQUQsRUFBUyxXQUFVLGNBQWU7Ozs7b0JBQ2xDLHdCQUFDLFFBQUQsWUFBTSx5QkFBNEI7Ozs7a0JBQzVCOzs7OzttQkFDUix3QkFBQyxVQUFEO1VBQ0UsU0FBUztVQUNULFdBQVU7b0JBRlosQ0FJRSx3QkFBQyxVQUFELEVBQVUsV0FBVSxjQUFlOzs7O29CQUNuQyx3QkFBQyxRQUFELFlBQU0sTUFBUzs7OztrQkFDVDs7Ozs7aUJBQ0w7Ozs7O2dCQUNGOzs7Ozs7T0FHTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLFlBQUQsRUFBWSxXQUFVLDZDQUE4Qzs7OztrQkFDcEUsd0JBQUMsT0FBRDtTQUNFLHdCQUFDLEtBQUQ7VUFBRyxXQUFVO29CQUFhO1NBQXFCOzs7OztTQUFDO1NBQTJCLHdCQUFDLEtBQUQsWUFBRyx1Q0FBdUM7Ozs7O1NBQUM7U0FBZ0Msd0JBQUMsS0FBRCxZQUFHLGVBQWU7Ozs7O1NBQUM7U0FBSyx3QkFBQyxLQUFELFlBQUcsK0JBQStCOzs7OztTQUFDO1FBQzlNOzs7O2dCQUNGOzs7Ozs7TUFDRjs7Ozs7O0lBQ0Y7Ozs7WUFDRjs7Ozs7O0VBQ0Y7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlB2Y1N0dWRpb1ZpZXcudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlUmVmLCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBcbiAgVXBsb2FkLCBcbiAgUHJpbnRlciwgXG4gIERvd25sb2FkLCBcbiAgUm90YXRlQ3csIFxuICBab29tSW4sIFxuICBab29tT3V0LCBcbiAgTW92ZSwgXG4gIFNwYXJrbGVzLCBcbiAgUmVmcmVzaEN3LCBcbiAgQ2hlY2ssIFxuICBTY2lzc29ycywgXG4gIExheWVycywgXG4gIEFycm93VXBEb3duLCBcbiAgU3VuLCBcbiAgQ29udHJhc3QsIFxuICBIZWxwQ2lyY2xlLFxuICBGaWxlVGV4dFxufSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuaW1wb3J0IHsganNQREYgfSBmcm9tICdqc3BkZic7XG5pbXBvcnQgeyBhZGREb3dubG9hZFJlY29yZCB9IGZyb20gJy4uL3V0aWxzL3N0b3JhZ2UnO1xuaW1wb3J0IHsgcHJpbnRJbWFnZVNoZWV0IH0gZnJvbSAnLi4vdXRpbHMvcHJpbnRlcic7XG5cbmV4cG9ydCBjb25zdCBQdmNTdHVkaW9WaWV3OiBSZWFjdC5GQyA9ICgpID0+IHtcbiAgLy8gQ2FudmFzIHJlZmVyZW5jZXNcbiAgY29uc3QgY2FudmFzUmVmID0gdXNlUmVmPEhUTUxDYW52YXNFbGVtZW50IHwgbnVsbD4obnVsbCk7XG5cbiAgLy8gQ2FyZCBpbWFnZXMgKERhdGEgVVJMcyBvciBJbWFnZSBvYmplY3RzKVxuICBjb25zdCBbY2FyZDFTcmMsIHNldENhcmQxU3JjXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbY2FyZDJTcmMsIHNldENhcmQyU3JjXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuXG4gIC8vIEFjdGl2ZSBlZGl0aW5nIGNhcmQ6ICdjYXJkMScgfCAnY2FyZDInXG4gIGNvbnN0IFthY3RpdmVDYXJkLCBzZXRBY3RpdmVDYXJkXSA9IHVzZVN0YXRlPCdjYXJkMScgfCAnY2FyZDInPignY2FyZDEnKTtcblxuICAvLyBBZGp1c3RtZW50cyBwZXIgY2FyZFxuICBjb25zdCBbY2FyZDFDb25maWcsIHNldENhcmQxQ29uZmlnXSA9IHVzZVN0YXRlKHtcbiAgICB4OiAwLFxuICAgIHk6IDAsXG4gICAgc2NhbGU6IDEuMCxcbiAgICByb3RhdGlvbjogMFxuICB9KTtcblxuICBjb25zdCBbY2FyZDJDb25maWcsIHNldENhcmQyQ29uZmlnXSA9IHVzZVN0YXRlKHtcbiAgICB4OiAwLFxuICAgIHk6IDAsXG4gICAgc2NhbGU6IDEuMCxcbiAgICByb3RhdGlvbjogMFxuICB9KTtcblxuICAvLyBHbG9iYWwgY2FyZCBhZGp1c3RtZW50c1xuICBjb25zdCBbYnJpZ2h0bmVzcywgc2V0QnJpZ2h0bmVzc10gPSB1c2VTdGF0ZTxudW1iZXI+KDApO1xuICBjb25zdCBbY29udHJhc3QsIHNldENvbnRyYXN0XSA9IHVzZVN0YXRlPG51bWJlcj4oMCk7XG4gIGNvbnN0IFtzaG93Q3V0TWFya3MsIHNldFNob3dDdXRNYXJrc10gPSB1c2VTdGF0ZTxib29sZWFuPih0cnVlKTtcbiAgY29uc3QgW3JvdW5kZWRDb3JuZXJzLCBzZXRSb3VuZGVkQ29ybmVyc10gPSB1c2VTdGF0ZTxib29sZWFuPih0cnVlKTtcbiAgY29uc3QgW2JvcmRlclN0cm9rZSwgc2V0Qm9yZGVyU3Ryb2tlXSA9IHVzZVN0YXRlPGJvb2xlYW4+KHRydWUpO1xuICBjb25zdCBbaXNQcm9jZXNzaW5nLCBzZXRJc1Byb2Nlc3NpbmddID0gdXNlU3RhdGU8Ym9vbGVhbj4oZmFsc2UpO1xuICBjb25zdCBbcHJpbnRBbGVydCwgc2V0UHJpbnRBbGVydF0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcblxuICAvLyBEcmFnZ2luZyBzdGF0ZSBvbiBjYW52YXNcbiAgY29uc3QgW2lzRHJhZ2dpbmcsIHNldElzRHJhZ2dpbmddID0gdXNlU3RhdGU8Ym9vbGVhbj4oZmFsc2UpO1xuICBjb25zdCBbZHJhZ0NhcmQsIHNldERyYWdDYXJkXSA9IHVzZVN0YXRlPCdjYXJkMScgfCAnY2FyZDInIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IFtkcmFnU3RhcnQsIHNldERyYWdTdGFydF0gPSB1c2VTdGF0ZTx7IHg6IG51bWJlcjsgeTogbnVtYmVyIH0+KHsgeDogMCwgeTogMCB9KTtcblxuICAvLyAzMDAgRFBJIGNvbnN0YW50cyBmb3IgNHg2IGluY2ggcGFwZXI6XG4gIC8vIDQgaW5jaGVzID0gMTIwMCBweCwgNiBpbmNoZXMgPSAxODAwIHB4XG4gIGNvbnN0IENBTlZBU19XSURUSCA9IDEyMDA7XG4gIGNvbnN0IENBTlZBU19IRUlHSFQgPSAxODAwO1xuXG4gIC8vIEV4YWN0IDUuNSBjbSDDlyA4LjUgY20gKDg1IG1tIMOXIDU1IG1tKSBkaW1lbnNpb25zIGF0IDMwMCBEUEk6XG4gIC8vIDEgaW5jaCA9IDIuNTQgY20gLT4gMzAwIHB4IC8gMi41NCBjbSA9IDExOC4xMTAyIHB4IHBlciBjbVxuICAvLyBXaWR0aDogOC41IGNtICogMTE4LjExMDIg4omIIDEwMDQgcHhcbiAgLy8gSGVpZ2h0OiA1LjUgY20gKiAxMTguMTEwMiDiiYggNjUwIHB4XG4gIGNvbnN0IENBUkRfV0lEVEggPSAxMDA0O1xuICBjb25zdCBDQVJEX0hFSUdIVCA9IDY1MDtcblxuICAvLyBQb3NpdGlvbiBvbiA0eDYgaW5jaCBQb3J0cmFpdCBTaGVldCAoMTIwMCB4IDE4MDAgcHgpOlxuICAvLyBYIENlbnRlcjogMTIwMCAvIDIgPSA2MDAgcHggKDk4IHB4IG1hcmdpbiBvbiBsZWZ0IGFuZCByaWdodCA9IH44LjMgbW0pXG4gIC8vIFRvcCBDYXJkIENlbnRlciAoRnJvbnQpOiBZID0gNDY1IHB4XG4gIC8vIENlbnRlciBDdXQgR3VpZGVsaW5lOiBZID0gOTAwIHB4XG4gIC8vIEJvdHRvbSBDYXJkIENlbnRlciAoQmFjayk6IFkgPSAxMzM1IHB4XG4gIGNvbnN0IENBUkRfQ0VOVEVSX1ggPSA2MDA7XG4gIGNvbnN0IENBUkQxX0RFRkFVTFRfWSA9IDQ2NTtcbiAgY29uc3QgQ0FSRDJfREVGQVVMVF9ZID0gMTMzNTtcblxuICAvLyBQcmUtbG9hZCBpbWFnZXMgZm9yIGNhbnZhcyBkcmF3aW5nXG4gIGNvbnN0IGNhcmQxSW1nUmVmID0gdXNlUmVmPEhUTUxJbWFnZUVsZW1lbnQgfCBudWxsPihudWxsKTtcbiAgY29uc3QgY2FyZDJJbWdSZWYgPSB1c2VSZWY8SFRNTEltYWdlRWxlbWVudCB8IG51bGw+KG51bGwpO1xuXG4gIC8vIExvYWQgY2FyZCAxIGltYWdlXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKGNhcmQxU3JjKSB7XG4gICAgICBjb25zdCBpbWcgPSBuZXcgSW1hZ2UoKTtcbiAgICAgIGltZy5jcm9zc09yaWdpbiA9ICdhbm9ueW1vdXMnO1xuICAgICAgaW1nLm9ubG9hZCA9ICgpID0+IHtcbiAgICAgICAgY2FyZDFJbWdSZWYuY3VycmVudCA9IGltZztcbiAgICAgICAgcmVuZGVyQ2FudmFzKCk7XG4gICAgICB9O1xuICAgICAgaW1nLnNyYyA9IGNhcmQxU3JjO1xuICAgIH0gZWxzZSB7XG4gICAgICBjYXJkMUltZ1JlZi5jdXJyZW50ID0gbnVsbDtcbiAgICAgIHJlbmRlckNhbnZhcygpO1xuICAgIH1cbiAgfSwgW2NhcmQxU3JjXSk7XG5cbiAgLy8gTG9hZCBjYXJkIDIgaW1hZ2VcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoY2FyZDJTcmMpIHtcbiAgICAgIGNvbnN0IGltZyA9IG5ldyBJbWFnZSgpO1xuICAgICAgaW1nLmNyb3NzT3JpZ2luID0gJ2Fub255bW91cyc7XG4gICAgICBpbWcub25sb2FkID0gKCkgPT4ge1xuICAgICAgICBjYXJkMkltZ1JlZi5jdXJyZW50ID0gaW1nO1xuICAgICAgICByZW5kZXJDYW52YXMoKTtcbiAgICAgIH07XG4gICAgICBpbWcuc3JjID0gY2FyZDJTcmM7XG4gICAgfSBlbHNlIHtcbiAgICAgIGNhcmQySW1nUmVmLmN1cnJlbnQgPSBudWxsO1xuICAgICAgcmVuZGVyQ2FudmFzKCk7XG4gICAgfVxuICB9LCBbY2FyZDJTcmNdKTtcblxuICAvLyBHbG9iYWwgS2V5Ym9hcmQgc2hvcnRjdXRzIGxpc3RlbmVyIChDdHJsK1AsIEN0cmwrUywgQ3RybCtKKVxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IGhhbmRsZUdsb2JhbFByaW50ID0gKCkgPT4gaGFuZGxlRGlyZWN0UHJpbnQoKTtcbiAgICBjb25zdCBoYW5kbGVHbG9iYWxQZGYgPSAoKSA9PiBoYW5kbGVEb3dubG9hZFBERigpO1xuICAgIGNvbnN0IGhhbmRsZUdsb2JhbEpwZyA9ICgpID0+IGhhbmRsZURvd25sb2FkSlBHKCk7XG5cbiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcignYXBwLWRpcmVjdC1wcmludCcsIGhhbmRsZUdsb2JhbFByaW50KTtcbiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcignYXBwLWRpcmVjdC1wZGYnLCBoYW5kbGVHbG9iYWxQZGYpO1xuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdhcHAtZGlyZWN0LWpwZycsIGhhbmRsZUdsb2JhbEpwZyk7XG5cbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ2FwcC1kaXJlY3QtcHJpbnQnLCBoYW5kbGVHbG9iYWxQcmludCk7XG4gICAgICB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcignYXBwLWRpcmVjdC1wZGYnLCBoYW5kbGVHbG9iYWxQZGYpO1xuICAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ2FwcC1kaXJlY3QtanBnJywgaGFuZGxlR2xvYmFsSnBnKTtcbiAgICB9O1xuICB9KTtcblxuICAvLyBSZS1yZW5kZXIgY2FudmFzIHdoZW5ldmVyIGNvbmZpZ3MgY2hhbmdlXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgcmVuZGVyQ2FudmFzKCk7XG4gIH0sIFtjYXJkMUNvbmZpZywgY2FyZDJDb25maWcsIGJyaWdodG5lc3MsIGNvbnRyYXN0LCBzaG93Q3V0TWFya3MsIHJvdW5kZWRDb3JuZXJzLCBib3JkZXJTdHJva2VdKTtcblxuICAvLyBNYWluIFJlbmRlciBGdW5jdGlvbiB0byBDYW52YXMgQCAzMDAgRFBJXG4gIGNvbnN0IHJlbmRlckNhbnZhcyA9ICgpID0+IHtcbiAgICBjb25zdCBjYW52YXMgPSBjYW52YXNSZWYuY3VycmVudDtcbiAgICBpZiAoIWNhbnZhcykgcmV0dXJuO1xuICAgIGNvbnN0IGN0eCA9IGNhbnZhcy5nZXRDb250ZXh0KCcyZCcpO1xuICAgIGlmICghY3R4KSByZXR1cm47XG5cbiAgICAvLyBDbGVhciBiYWNrZ3JvdW5kIHRvIHB1cmUgd2hpdGUgKGZvciBwaG90byBwYXBlciBwcmludClcbiAgICBjdHguZmlsbFN0eWxlID0gJyNmZmZmZmYnO1xuICAgIGN0eC5maWxsUmVjdCgwLCAwLCBDQU5WQVNfV0lEVEgsIENBTlZBU19IRUlHSFQpO1xuXG4gICAgLy8gRmlsdGVyIHN0cmluZ1xuICAgIGNvbnN0IGZpbHRlclN0ciA9IGBicmlnaHRuZXNzKCR7MTAwICsgYnJpZ2h0bmVzc30lKSBjb250cmFzdCgkezEwMCArIGNvbnRyYXN0fSUpYDtcblxuICAgIC8vIDEuIERyYXcgQ2FyZCAxIChUb3AgLyBGcm9udClcbiAgICBkcmF3U2luZ2xlQ2FyZChcbiAgICAgIGN0eCxcbiAgICAgIGNhcmQxSW1nUmVmLmN1cnJlbnQsXG4gICAgICBDQVJEX0NFTlRFUl9YICsgY2FyZDFDb25maWcueCxcbiAgICAgIENBUkQxX0RFRkFVTFRfWSArIGNhcmQxQ29uZmlnLnksXG4gICAgICBjYXJkMUNvbmZpZy5zY2FsZSxcbiAgICAgIGNhcmQxQ29uZmlnLnJvdGF0aW9uLFxuICAgICAgJ0NhcmQgMSAoRnJvbnQpJyxcbiAgICAgIGZpbHRlclN0clxuICAgICk7XG5cbiAgICAvLyAyLiBEcmF3IENhcmQgMiAoQm90dG9tIC8gQmFjaylcbiAgICBkcmF3U2luZ2xlQ2FyZChcbiAgICAgIGN0eCxcbiAgICAgIGNhcmQySW1nUmVmLmN1cnJlbnQsXG4gICAgICBDQVJEX0NFTlRFUl9YICsgY2FyZDJDb25maWcueCxcbiAgICAgIENBUkQyX0RFRkFVTFRfWSArIGNhcmQyQ29uZmlnLnksXG4gICAgICBjYXJkMkNvbmZpZy5zY2FsZSxcbiAgICAgIGNhcmQyQ29uZmlnLnJvdGF0aW9uLFxuICAgICAgJ0NhcmQgMiAoQmFjayknLFxuICAgICAgZmlsdGVyU3RyXG4gICAgKTtcblxuICAgIC8vIDMuIERyYXcgQ3V0IEd1aWRlIExpbmUgYmV0d2VlbiBjYXJkc1xuICAgIGlmIChzaG93Q3V0TWFya3MpIHtcbiAgICAgIGN0eC5zYXZlKCk7XG4gICAgICBjdHguc3Ryb2tlU3R5bGUgPSAnIzk0YTNiOCc7XG4gICAgICBjdHgubGluZVdpZHRoID0gMjtcbiAgICAgIGN0eC5zZXRMaW5lRGFzaChbOCwgOF0pO1xuXG4gICAgICAvLyBIb3Jpem9udGFsIGNlbnRlciBjdXQgbWFyayAoZXhhY3QgY2VudGVyIG9mIDR4NiBpbmNoIHNoZWV0KVxuICAgICAgY29uc3QgbWlkWSA9IDkwMDtcbiAgICAgIGN0eC5iZWdpblBhdGgoKTtcbiAgICAgIGN0eC5tb3ZlVG8oNDAsIG1pZFkpO1xuICAgICAgY3R4LmxpbmVUbyhDQU5WQVNfV0lEVEggLSA0MCwgbWlkWSk7XG4gICAgICBjdHguc3Ryb2tlKCk7XG5cbiAgICAgIC8vIFNjaXNzb3IgaW5kaWNhdG9yIHRleHRcbiAgICAgIGN0eC5zZXRMaW5lRGFzaChbXSk7XG4gICAgICBjdHguZmlsbFN0eWxlID0gJyM2NDc0OGInO1xuICAgICAgY3R4LmZvbnQgPSAnYm9sZCAyMHB4IHNhbnMtc2VyaWYnO1xuICAgICAgY3R4LnRleHRBbGlnbiA9ICdjZW50ZXInO1xuICAgICAgY3R4LmZpbGxUZXh0KCfinIIgQ3V0IEhlcmUgKEZvbGQgLyBTZXBhcmF0ZSDigKIgNS41IGNtIMOXIDguNSBjbSBFYWNoKScsIENBTlZBU19XSURUSCAvIDIsIG1pZFkgLSAxMik7XG5cbiAgICAgIC8vIFNoZWV0IGJvdW5kYXJ5IGNyb3AgY29ybmVyc1xuICAgICAgZHJhd0Nyb3BNYXJrcyhjdHgsIDQwLCA0MCk7XG4gICAgICBkcmF3Q3JvcE1hcmtzKGN0eCwgQ0FOVkFTX1dJRFRIIC0gNDAsIDQwKTtcbiAgICAgIGRyYXdDcm9wTWFya3MoY3R4LCA0MCwgQ0FOVkFTX0hFSUdIVCAtIDQwKTtcbiAgICAgIGRyYXdDcm9wTWFya3MoY3R4LCBDQU5WQVNfV0lEVEggLSA0MCwgQ0FOVkFTX0hFSUdIVCAtIDQwKTtcblxuICAgICAgY3R4LnJlc3RvcmUoKTtcbiAgICB9XG4gIH07XG5cbiAgY29uc3QgZHJhd0Nyb3BNYXJrcyA9IChjdHg6IENhbnZhc1JlbmRlcmluZ0NvbnRleHQyRCwgeDogbnVtYmVyLCB5OiBudW1iZXIpID0+IHtcbiAgICBjdHguc3Ryb2tlU3R5bGUgPSAnI2NiZDVlMSc7XG4gICAgY3R4LmxpbmVXaWR0aCA9IDI7XG4gICAgY3R4LmJlZ2luUGF0aCgpO1xuICAgIGN0eC5tb3ZlVG8oeCAtIDIwLCB5KTtcbiAgICBjdHgubGluZVRvKHggKyAyMCwgeSk7XG4gICAgY3R4Lm1vdmVUbyh4LCB5IC0gMjApO1xuICAgIGN0eC5saW5lVG8oeCwgeSArIDIwKTtcbiAgICBjdHguc3Ryb2tlKCk7XG4gIH07XG5cbiAgY29uc3QgZHJhd1NpbmdsZUNhcmQgPSAoXG4gICAgY3R4OiBDYW52YXNSZW5kZXJpbmdDb250ZXh0MkQsXG4gICAgaW1nOiBIVE1MSW1hZ2VFbGVtZW50IHwgbnVsbCxcbiAgICBjZW50ZXJYOiBudW1iZXIsXG4gICAgY2VudGVyWTogbnVtYmVyLFxuICAgIHNjYWxlOiBudW1iZXIsXG4gICAgcm90YXRpb246IG51bWJlcixcbiAgICBwbGFjZWhvbGRlckxhYmVsOiBzdHJpbmcsXG4gICAgZmlsdGVyOiBzdHJpbmdcbiAgKSA9PiB7XG4gICAgY29uc3QgdyA9IENBUkRfV0lEVEg7XG4gICAgY29uc3QgaCA9IENBUkRfSEVJR0hUO1xuICAgIGNvbnN0IGxlZnQgPSBjZW50ZXJYIC0gdyAvIDI7XG4gICAgY29uc3QgdG9wID0gY2VudGVyWSAtIGggLyAyO1xuXG4gICAgY3R4LnNhdmUoKTtcblxuICAgIC8vIFJvdW5kZWQgcmVjdGFuZ2xlIHBhdGggZm9yIENSLTgwIGNhcmQgKHN0YW5kYXJkIH4zbW0gLyAzNnB4IHJhZGl1cyBAIDMwMERQSSlcbiAgICBjb25zdCByYWRpdXMgPSByb3VuZGVkQ29ybmVycyA/IDM2IDogMDtcbiAgICBjdHguYmVnaW5QYXRoKCk7XG4gICAgY3R4LnJvdW5kUmVjdChsZWZ0LCB0b3AsIHcsIGgsIHJhZGl1cyk7XG5cbiAgICBpZiAoaW1nKSB7XG4gICAgICBjdHguc2F2ZSgpO1xuICAgICAgLy8gQ2xpcCBpbWFnZSB0byBjYXJkIGJvdW5kYXJ5XG4gICAgICBjdHguY2xpcCgpO1xuXG4gICAgICAvLyBBcHBseSBicmlnaHRuZXNzICYgY29udHJhc3QgZmlsdGVyc1xuICAgICAgY3R4LmZpbHRlciA9IGZpbHRlcjtcblxuICAgICAgLy8gVHJhbnNmb3JtIGZvciBwb3NpdGlvbiwgc2NhbGUgJiByb3RhdGlvblxuICAgICAgY3R4LnRyYW5zbGF0ZShjZW50ZXJYLCBjZW50ZXJZKTtcbiAgICAgIGN0eC5yb3RhdGUoKHJvdGF0aW9uICogTWF0aC5QSSkgLyAxODApO1xuICAgICAgY3R4LnNjYWxlKHNjYWxlLCBzY2FsZSk7XG5cbiAgICAgIC8vIERyYXcgaW1hZ2UgY2VudGVyZWRcbiAgICAgIGN0eC5kcmF3SW1hZ2UoaW1nLCAtdyAvIDIsIC1oIC8gMiwgdywgaCk7XG4gICAgICBjdHgucmVzdG9yZSgpO1xuICAgIH0gZWxzZSB7XG4gICAgICAvLyBFbXB0eSBwbGFjZWhvbGRlciBzbG90XG4gICAgICBjdHguZmlsbFN0eWxlID0gJyNmOGZhZmMnO1xuICAgICAgY3R4LmZpbGwoKTtcblxuICAgICAgY3R4LnN0cm9rZVN0eWxlID0gJyNjYmQ1ZTEnO1xuICAgICAgY3R4LmxpbmVXaWR0aCA9IDQ7XG4gICAgICBjdHguc2V0TGluZURhc2goWzEyLCA4XSk7XG4gICAgICBjdHguc3Ryb2tlKCk7XG5cbiAgICAgIC8vIFBsYWNlaG9sZGVyIHRleHRcbiAgICAgIGN0eC5maWxsU3R5bGUgPSAnIzY0NzQ4Yic7XG4gICAgICBjdHguZm9udCA9ICdib2xkIDM2cHggc2Fucy1zZXJpZic7XG4gICAgICBjdHgudGV4dEFsaWduID0gJ2NlbnRlcic7XG4gICAgICBjdHguZmlsbFRleHQocGxhY2Vob2xkZXJMYWJlbCwgY2VudGVyWCwgY2VudGVyWSAtIDIwKTtcbiAgICAgIGN0eC5mb250ID0gJzI0cHggc2Fucy1zZXJpZic7XG4gICAgICBjdHguZmlsbFN0eWxlID0gJyM5NGEzYjgnO1xuICAgICAgY3R4LmZpbGxUZXh0KCdEcm9wIGltYWdlIG9yIFBERiB0byBwbGFjZSBoZXJlJywgY2VudGVyWCwgY2VudGVyWSArIDMwKTtcbiAgICAgIGN0eC5maWxsVGV4dCgnT2ZmaWNpYWwgU2l6ZTogNS41IGNtIMOXIDguNSBjbSAoODUgbW0gw5cgNTUgbW0pJywgY2VudGVyWCwgY2VudGVyWSArIDcwKTtcbiAgICB9XG5cbiAgICAvLyBCb3JkZXIgbGluZSBhcm91bmQgY2FyZFxuICAgIGlmIChib3JkZXJTdHJva2UpIHtcbiAgICAgIGN0eC5iZWdpblBhdGgoKTtcbiAgICAgIGN0eC5yb3VuZFJlY3QobGVmdCwgdG9wLCB3LCBoLCByYWRpdXMpO1xuICAgICAgY3R4LnN0cm9rZVN0eWxlID0gJyMxZTI5M2InO1xuICAgICAgY3R4LmxpbmVXaWR0aCA9IDI7XG4gICAgICBjdHguc2V0TGluZURhc2goW10pO1xuICAgICAgY3R4LnN0cm9rZSgpO1xuICAgIH1cblxuICAgIGN0eC5yZXN0b3JlKCk7XG4gIH07XG5cbiAgLy8gVXBsb2FkIGhhbmRsZXIgZm9yIENhcmQgMSBvciBDYXJkIDJcbiAgY29uc3QgaGFuZGxlRmlsZVVwbG9hZCA9IChlOiBSZWFjdC5DaGFuZ2VFdmVudDxIVE1MSW5wdXRFbGVtZW50PiwgdGFyZ2V0OiAnY2FyZDEnIHwgJ2NhcmQyJykgPT4ge1xuICAgIGNvbnN0IGZpbGUgPSBlLnRhcmdldC5maWxlcz8uWzBdO1xuICAgIGlmICghZmlsZSkgcmV0dXJuO1xuXG4gICAgY29uc3QgcmVhZGVyID0gbmV3IEZpbGVSZWFkZXIoKTtcbiAgICByZWFkZXIub25sb2FkID0gKGV2ZW50KSA9PiB7XG4gICAgICBjb25zdCByZXN1bHQgPSBldmVudC50YXJnZXQ/LnJlc3VsdCBhcyBzdHJpbmc7XG4gICAgICBpZiAodGFyZ2V0ID09PSAnY2FyZDEnKSB7XG4gICAgICAgIHNldENhcmQxU3JjKHJlc3VsdCk7XG4gICAgICAgIHNldEFjdGl2ZUNhcmQoJ2NhcmQxJyk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBzZXRDYXJkMlNyYyhyZXN1bHQpO1xuICAgICAgICBzZXRBY3RpdmVDYXJkKCdjYXJkMicpO1xuICAgICAgfVxuICAgIH07XG4gICAgcmVhZGVyLnJlYWRBc0RhdGFVUkwoZmlsZSk7XG4gICAgZS50YXJnZXQudmFsdWUgPSAnJztcbiAgfTtcblxuICAvLyBTd2FwIEZyb250ICYgQmFjayBjYXJkc1xuICBjb25zdCBoYW5kbGVTd2FwQ2FyZHMgPSAoKSA9PiB7XG4gICAgY29uc3QgdGVtcFNyYyA9IGNhcmQxU3JjO1xuICAgIHNldENhcmQxU3JjKGNhcmQyU3JjKTtcbiAgICBzZXRDYXJkMlNyYyh0ZW1wU3JjKTtcblxuICAgIGNvbnN0IHRlbXBDZmcgPSB7IC4uLmNhcmQxQ29uZmlnIH07XG4gICAgc2V0Q2FyZDFDb25maWcoeyAuLi5jYXJkMkNvbmZpZyB9KTtcbiAgICBzZXRDYXJkMkNvbmZpZyh0ZW1wQ2ZnKTtcbiAgfTtcblxuICAvLyBTY2FsZSBhZGp1c3RtZW50XG4gIGNvbnN0IGhhbmRsZVNjYWxlQ2hhbmdlID0gKHZhbDogbnVtYmVyKSA9PiB7XG4gICAgaWYgKGFjdGl2ZUNhcmQgPT09ICdjYXJkMScpIHtcbiAgICAgIHNldENhcmQxQ29uZmlnKHByZXYgPT4gKHsgLi4ucHJldiwgc2NhbGU6IHZhbCB9KSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHNldENhcmQyQ29uZmlnKHByZXYgPT4gKHsgLi4ucHJldiwgc2NhbGU6IHZhbCB9KSk7XG4gICAgfVxuICB9O1xuXG4gIC8vIE51ZGdlIGFkanVzdG1lbnRcbiAgY29uc3QgaGFuZGxlTnVkZ2UgPSAoZHg6IG51bWJlciwgZHk6IG51bWJlcikgPT4ge1xuICAgIGlmIChhY3RpdmVDYXJkID09PSAnY2FyZDEnKSB7XG4gICAgICBzZXRDYXJkMUNvbmZpZyhwcmV2ID0+ICh7IC4uLnByZXYsIHg6IHByZXYueCArIGR4LCB5OiBwcmV2LnkgKyBkeSB9KSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHNldENhcmQyQ29uZmlnKHByZXYgPT4gKHsgLi4ucHJldiwgeDogcHJldi54ICsgZHgsIHk6IHByZXYueSArIGR5IH0pKTtcbiAgICB9XG4gIH07XG5cbiAgLy8gUm90YXRlIDkwIGRlZ3JlZXNcbiAgY29uc3QgaGFuZGxlUm90YXRlID0gKCkgPT4ge1xuICAgIGlmIChhY3RpdmVDYXJkID09PSAnY2FyZDEnKSB7XG4gICAgICBzZXRDYXJkMUNvbmZpZyhwcmV2ID0+ICh7IC4uLnByZXYsIHJvdGF0aW9uOiAocHJldi5yb3RhdGlvbiArIDkwKSAlIDM2MCB9KSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHNldENhcmQyQ29uZmlnKHByZXYgPT4gKHsgLi4ucHJldiwgcm90YXRpb246IChwcmV2LnJvdGF0aW9uICsgOTApICUgMzYwIH0pKTtcbiAgICB9XG4gIH07XG5cbiAgLy8gUmVzZXQgY29udHJvbHNcbiAgY29uc3QgaGFuZGxlUmVzZXQgPSAoKSA9PiB7XG4gICAgc2V0Q2FyZDFDb25maWcoeyB4OiAwLCB5OiAwLCBzY2FsZTogMS4wLCByb3RhdGlvbjogMCB9KTtcbiAgICBzZXRDYXJkMkNvbmZpZyh7IHg6IDAsIHk6IDAsIHNjYWxlOiAxLjAsIHJvdGF0aW9uOiAwIH0pO1xuICAgIHNldEJyaWdodG5lc3MoMCk7XG4gICAgc2V0Q29udHJhc3QoMCk7XG4gIH07XG5cbiAgLy8gRG93bmxvYWQgSGlnaC1SZXMgMzAwIERQSSBKUEdcbiAgY29uc3QgaGFuZGxlRG93bmxvYWRKUEcgPSAoKSA9PiB7XG4gICAgY29uc3QgY2FudmFzID0gY2FudmFzUmVmLmN1cnJlbnQ7XG4gICAgaWYgKCFjYW52YXMpIHJldHVybjtcbiAgICBzZXRJc1Byb2Nlc3NpbmcodHJ1ZSk7XG5cbiAgICB0cnkge1xuICAgICAgY29uc3QgZGF0YVVybCA9IGNhbnZhcy50b0RhdGFVUkwoJ2ltYWdlL2pwZWcnLCAwLjk4KTtcbiAgICAgIGNvbnN0IGEgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdhJyk7XG4gICAgICBhLmhyZWYgPSBkYXRhVXJsO1xuICAgICAgY29uc3QgZmlsZU5hbWUgPSBgUFZDX0NhcmRfNHg2XzMwMERQSV8ke0RhdGUubm93KCl9LmpwZ2A7XG4gICAgICBhLmRvd25sb2FkID0gZmlsZU5hbWU7XG4gICAgICBhLmNsaWNrKCk7XG5cbiAgICAgIGFkZERvd25sb2FkUmVjb3JkKHtcbiAgICAgICAgaWQ6IGBwdmMtanBnLSR7RGF0ZS5ub3coKX1gLFxuICAgICAgICB0aXRsZTogZmlsZU5hbWUsXG4gICAgICAgIHR5cGU6ICdQVkMgQ2FyZCBKUEcnLFxuICAgICAgICBzaXplOiAnMTIwMMOXMTgwMCBweCAoMzAwIERQSSknLFxuICAgICAgICB0aW1lc3RhbXA6IG5ldyBEYXRlKCkudG9Mb2NhbGVUaW1lU3RyaW5nKCdlbi1JTicpXG4gICAgICB9KTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBjb25zb2xlLmVycm9yKGUpO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRJc1Byb2Nlc3NpbmcoZmFsc2UpO1xuICAgIH1cbiAgfTtcblxuICAvLyBEb3dubG9hZCAzMDAgRFBJIFBERiAoRXhhY3QgNHg2IGluY2ggcGFwZXIgc2l6ZSlcbiAgY29uc3QgaGFuZGxlRG93bmxvYWRQREYgPSAoKSA9PiB7XG4gICAgY29uc3QgY2FudmFzID0gY2FudmFzUmVmLmN1cnJlbnQ7XG4gICAgaWYgKCFjYW52YXMpIHJldHVybjtcbiAgICBzZXRJc1Byb2Nlc3NpbmcodHJ1ZSk7XG5cbiAgICB0cnkge1xuICAgICAgY29uc3QgZGF0YVVybCA9IGNhbnZhcy50b0RhdGFVUkwoJ2ltYWdlL2pwZWcnLCAwLjk4KTtcbiAgICAgIC8vIDR4NiBpbmNoZXMgaW4gUERGIHBvaW50czogNCAqIDcyID0gMjg4LCA2ICogNzIgPSA0MzJcbiAgICAgIGNvbnN0IHBkZiA9IG5ldyBqc1BERih7XG4gICAgICAgIG9yaWVudGF0aW9uOiAncG9ydHJhaXQnLFxuICAgICAgICB1bml0OiAnaW4nLFxuICAgICAgICBmb3JtYXQ6IFs0LCA2XVxuICAgICAgfSk7XG5cbiAgICAgIHBkZi5hZGRJbWFnZShkYXRhVXJsLCAnSlBFRycsIDAsIDAsIDQsIDYpO1xuICAgICAgY29uc3QgZmlsZU5hbWUgPSBgUFZDX0NhcmRfUHJpbnRhYmxlXzR4Nl8ke0RhdGUubm93KCl9LnBkZmA7XG4gICAgICBwZGYuc2F2ZShmaWxlTmFtZSk7XG5cbiAgICAgIGFkZERvd25sb2FkUmVjb3JkKHtcbiAgICAgICAgaWQ6IGBwdmMtcGRmLSR7RGF0ZS5ub3coKX1gLFxuICAgICAgICB0aXRsZTogZmlsZU5hbWUsXG4gICAgICAgIHR5cGU6ICdQVkMgQ2FyZCBQREYnLFxuICAgICAgICBzaXplOiAnNMOXNiBpbmNoICgzMDAgRFBJKScsXG4gICAgICAgIHRpbWVzdGFtcDogbmV3IERhdGUoKS50b0xvY2FsZVRpbWVTdHJpbmcoJ2VuLUlOJylcbiAgICAgIH0pO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoZSk7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldElzUHJvY2Vzc2luZyhmYWxzZSk7XG4gICAgfVxuICB9O1xuXG4gIC8vIERpcmVjdCBCcm93c2VyIFByaW50IChGb3JtYXR0ZWQgZm9yIDR4NiBwaG90byBwYXBlcilcbiAgY29uc3QgaGFuZGxlRGlyZWN0UHJpbnQgPSAoKSA9PiB7XG4gICAgY29uc3QgY2FudmFzID0gY2FudmFzUmVmLmN1cnJlbnQ7XG4gICAgaWYgKCFjYW52YXMpIHJldHVybjtcbiAgICB0cnkge1xuICAgICAgY29uc3QgZGF0YVVybCA9IGNhbnZhcy50b0RhdGFVUkwoJ2ltYWdlL2pwZWcnLCAxLjApO1xuICAgICAgcHJpbnRJbWFnZVNoZWV0KGRhdGFVcmwsIHtcbiAgICAgICAgcGFwZXJGb3JtYXQ6ICc0eDZfcG9ydHJhaXQnLFxuICAgICAgICB0aXRsZTogJ1BWQ19DYXJkXzR4Nl9QcmludCdcbiAgICAgIH0pO1xuICAgICAgc2V0UHJpbnRBbGVydCgn8J+WqO+4jyBQVkMgQ2FyZCBwcmludCBjb21tYW5kIHNlbnQgdG8gcHJpbnRlciEgKDTDlzYgUGhvdG8gUGFwZXIgUG9ydHJhaXQg4oCiIEV4YWN0IDUuNSBjbSDDlyA4LjUgY20pJyk7XG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHNldFByaW50QWxlcnQobnVsbCksIDQwMDApO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoZSk7XG4gICAgICB3aW5kb3cucHJpbnQoKTtcbiAgICB9XG4gIH07XG5cbiAgLy8gSW50ZXJhY3RpdmUgRHJhZyBvbiBDYW52YXNcbiAgY29uc3QgaGFuZGxlTW91c2VEb3duID0gKGU6IFJlYWN0Lk1vdXNlRXZlbnQ8SFRNTENhbnZhc0VsZW1lbnQ+KSA9PiB7XG4gICAgY29uc3QgY2FudmFzID0gY2FudmFzUmVmLmN1cnJlbnQ7XG4gICAgaWYgKCFjYW52YXMpIHJldHVybjtcbiAgICBjb25zdCByZWN0ID0gY2FudmFzLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuICAgIGNvbnN0IHNjYWxlWCA9IENBTlZBU19XSURUSCAvIHJlY3Qud2lkdGg7XG4gICAgY29uc3Qgc2NhbGVZID0gQ0FOVkFTX0hFSUdIVCAvIHJlY3QuaGVpZ2h0O1xuXG4gICAgY29uc3QgbW91c2VYID0gKGUuY2xpZW50WCAtIHJlY3QubGVmdCkgKiBzY2FsZVg7XG4gICAgY29uc3QgbW91c2VZID0gKGUuY2xpZW50WSAtIHJlY3QudG9wKSAqIHNjYWxlWTtcblxuICAgIC8vIENoZWNrIGlmIGNsaWNrZWQgaW4gdG9wIGNhcmQgKENhcmQgMSlcbiAgICBpZiAobW91c2VZIDwgQ0FOVkFTX0hFSUdIVCAvIDIpIHtcbiAgICAgIHNldERyYWdDYXJkKCdjYXJkMScpO1xuICAgICAgc2V0QWN0aXZlQ2FyZCgnY2FyZDEnKTtcbiAgICAgIHNldElzRHJhZ2dpbmcodHJ1ZSk7XG4gICAgICBzZXREcmFnU3RhcnQoeyB4OiBtb3VzZVggLSBjYXJkMUNvbmZpZy54LCB5OiBtb3VzZVkgLSBjYXJkMUNvbmZpZy55IH0pO1xuICAgIH0gZWxzZSB7XG4gICAgICBzZXREcmFnQ2FyZCgnY2FyZDInKTtcbiAgICAgIHNldEFjdGl2ZUNhcmQoJ2NhcmQyJyk7XG4gICAgICBzZXRJc0RyYWdnaW5nKHRydWUpO1xuICAgICAgc2V0RHJhZ1N0YXJ0KHsgeDogbW91c2VYIC0gY2FyZDJDb25maWcueCwgeTogbW91c2VZIC0gY2FyZDJDb25maWcueSB9KTtcbiAgICB9XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlTW91c2VNb3ZlID0gKGU6IFJlYWN0Lk1vdXNlRXZlbnQ8SFRNTENhbnZhc0VsZW1lbnQ+KSA9PiB7XG4gICAgaWYgKCFpc0RyYWdnaW5nIHx8ICFkcmFnQ2FyZCkgcmV0dXJuO1xuICAgIGNvbnN0IGNhbnZhcyA9IGNhbnZhc1JlZi5jdXJyZW50O1xuICAgIGlmICghY2FudmFzKSByZXR1cm47XG4gICAgY29uc3QgcmVjdCA9IGNhbnZhcy5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgICBjb25zdCBzY2FsZVggPSBDQU5WQVNfV0lEVEggLyByZWN0LndpZHRoO1xuICAgIGNvbnN0IHNjYWxlWSA9IENBTlZBU19IRUlHSFQgLyByZWN0LmhlaWdodDtcblxuICAgIGNvbnN0IG1vdXNlWCA9IChlLmNsaWVudFggLSByZWN0LmxlZnQpICogc2NhbGVYO1xuICAgIGNvbnN0IG1vdXNlWSA9IChlLmNsaWVudFkgLSByZWN0LnRvcCkgKiBzY2FsZVk7XG5cbiAgICBpZiAoZHJhZ0NhcmQgPT09ICdjYXJkMScpIHtcbiAgICAgIHNldENhcmQxQ29uZmlnKHByZXYgPT4gKHtcbiAgICAgICAgLi4ucHJldixcbiAgICAgICAgeDogTWF0aC5yb3VuZChtb3VzZVggLSBkcmFnU3RhcnQueCksXG4gICAgICAgIHk6IE1hdGgucm91bmQobW91c2VZIC0gZHJhZ1N0YXJ0LnkpXG4gICAgICB9KSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHNldENhcmQyQ29uZmlnKHByZXYgPT4gKHtcbiAgICAgICAgLi4ucHJldixcbiAgICAgICAgeDogTWF0aC5yb3VuZChtb3VzZVggLSBkcmFnU3RhcnQueCksXG4gICAgICAgIHk6IE1hdGgucm91bmQobW91c2VZIC0gZHJhZ1N0YXJ0LnkpXG4gICAgICB9KSk7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IGhhbmRsZU1vdXNlVXAgPSAoKSA9PiB7XG4gICAgc2V0SXNEcmFnZ2luZyhmYWxzZSk7XG4gICAgc2V0RHJhZ0NhcmQobnVsbCk7XG4gIH07XG5cbiAgY29uc3QgY3VycmVudENvbmZpZyA9IGFjdGl2ZUNhcmQgPT09ICdjYXJkMScgPyBjYXJkMUNvbmZpZyA6IGNhcmQyQ29uZmlnO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cbiAgICAgIHsvKiBIZWFkZXIgYmFyICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IHNtOml0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTMgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHAtNCByb3VuZGVkLTJ4bCBzaGFkb3ctbWRcIj5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWV4dHJhYm9sZCB0ZXh0LXdoaXRlXCI+UFZDIFNtYXJ0IENhcmQgU3R1ZGlvICg1LjUgY20gw5cgOC41IGNtKTwvaDE+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJiZy1ibHVlLTUwMC8yMCB0ZXh0LWJsdWUtNDAwIGJvcmRlciBib3JkZXItYmx1ZS01MDAvMzAgdGV4dC14cyBweC0yIHB5LTAuNSByb3VuZGVkLWZ1bGwgZm9udC1tb25vIGZvbnQtYm9sZFwiPlxuICAgICAgICAgICAgICAzMDAgRFBJIEhpZ2gtRGVmaW5pdGlvblxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYmctZW1lcmFsZC01MDAvMjAgdGV4dC1lbWVyYWxkLTQwMCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtNTAwLzMwIHRleHQteHMgcHgtMiBweS0wLjUgcm91bmRlZC1mdWxsIGZvbnQtYm9sZFwiPlxuICAgICAgICAgICAgICA0w5c2IGluY2ggUG9ydHJhaXQgTGF5b3V0XG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMCBtdC0wLjVcIj5cbiAgICAgICAgICAgIDTDlzYgaW5jaCBQb3J0cmFpdCBHbG9zc3kgUGhvdG8gUGFwZXIgd2l0aCAyIFByZS1BbGlnbmVkIENhcmRzIChGcm9udCAmIEJhY2spIOKAoiBFeGFjdCBTaXplOiA8Yj41LjUgY20gw5cgOC41IGNtPC9iPlxuICAgICAgICAgIDwvcD5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIFByaW1hcnkgRXhwb3J0IEFjdGlvbnMgZm9yIFBDICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGZsZXgtd3JhcFwiPlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZURpcmVjdFByaW50fVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgYmctZ3JhZGllbnQtdG8tciBmcm9tLWJsdWUtNjAwIHZpYS1pbmRpZ28tNjAwIHRvLWJsdWUtNTAwIGhvdmVyOmZyb20tYmx1ZS01MDAgaG92ZXI6dG8taW5kaWdvLTUwMCB0ZXh0LXdoaXRlIGZvbnQtZXh0cmFib2xkIHRleHQteHMgcHgtNCBweS0yLjUgcm91bmRlZC14bCBzaGFkb3ctbGcgc2hhZG93LWJsdWUtNjAwLzMwIHRyYW5zaXRpb24tYWxsIGhvdmVyOnNjYWxlLTEwNSBhY3RpdmU6c2NhbGUtOTUgYm9yZGVyIGJvcmRlci1ibHVlLTQwMC8zMFwiXG4gICAgICAgICAgICB0aXRsZT1cIkRpcmVjdCBQcmludCB0byBFcHNvbiAvIENhbm9uIChDdHJsICsgUClcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxQcmludGVyIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC13aGl0ZVwiIC8+XG4gICAgICAgICAgICA8c3Bhbj7wn5ao77iPIERpcmVjdCBQcmludCBQVkMgQ2FyZDwvc3Bhbj5cbiAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZURvd25sb2FkUERGfVxuICAgICAgICAgICAgZGlzYWJsZWQ9e2lzUHJvY2Vzc2luZ31cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgYmctaW5kaWdvLTYwMCBob3ZlcjpiZy1pbmRpZ28tNTAwIHRleHQtd2hpdGUgZm9udC1ib2xkIHRleHQteHMgcHgtMy41IHB5LTIuNSByb3VuZGVkLXhsIHNoYWRvdy1sZyBzaGFkb3ctaW5kaWdvLTYwMC8zMCB0cmFuc2l0aW9uLWFsbCBob3ZlcjpzY2FsZS0xMDUgZGlzYWJsZWQ6b3BhY2l0eS01MFwiXG4gICAgICAgICAgICB0aXRsZT1cIkRvd25sb2FkIFByaW50YWJsZSAzMDAgRFBJIFBERlwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPERvd25sb2FkIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICAgICAgPHNwYW4+8J+ThCBQREYgKDTDlzYpPC9zcGFuPlxuICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17aGFuZGxlRG93bmxvYWRKUEd9XG4gICAgICAgICAgICBkaXNhYmxlZD17aXNQcm9jZXNzaW5nfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBiZy1zbGF0ZS04MDAgaG92ZXI6Ymctc2xhdGUtNzAwIHRleHQtc2xhdGUtMjAwIGhvdmVyOnRleHQtd2hpdGUgZm9udC1ib2xkIHRleHQteHMgcHgtMyBweS0yLjUgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCB0cmFuc2l0aW9uLWFsbFwiXG4gICAgICAgICAgICB0aXRsZT1cIkRvd25sb2FkIEhpZ2gtUmVzIDEyMDB4MTgwMCBKUEdcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxEb3dubG9hZCBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XG4gICAgICAgICAgICA8c3Bhbj7wn5a877iPIEhEIEpQRzwvc3Bhbj5cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIFByaW50IE5vdGlmaWNhdGlvbiBCYW5uZXIgKi99XG4gICAgICB7cHJpbnRBbGVydCAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zIHJvdW5kZWQteGwgYmctZW1lcmFsZC01MDAvMTAgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTUwMC8zMCB0ZXh0LWVtZXJhbGQtNDAwIHRleHQteHMgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgYW5pbWF0ZS1pbiBmYWRlLWluXCI+XG4gICAgICAgICAgPENoZWNrIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1lbWVyYWxkLTQwMCBmbGV4LXNocmluay0wXCIgLz5cbiAgICAgICAgICA8c3Bhbj57cHJpbnRBbGVydH08L3NwYW4+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgey8qIE1haW4gRHVhbC1QYW5lIFBDIFdvcmtzcGFjZSAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBsZzpncmlkLWNvbHMtMTIgZ2FwLTUgaXRlbXMtc3RhcnRcIj5cbiAgICAgICAgey8qIExlZnQgU2lkZTogQ29udHJvbHMgJiBVcGxvYWRzICg1IGNvbHVtbnMpICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxnOmNvbC1zcGFuLTUgc3BhY2UteS00XCI+XG4gICAgICAgICAgey8qIENhcmQgU2xvdHMgKENhcmQgMSAmIENhcmQgMikgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAvOTAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0yeGwgcC00IHNoYWRvdy1tZCBzcGFjZS15LTNcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtMzAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPkNhcmQgU2xvdHMgJiBJbWFnZXM8L3NwYW4+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVTd2FwQ2FyZHN9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtYmx1ZS00MDAgaG92ZXI6dGV4dC1ibHVlLTMwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiXG4gICAgICAgICAgICAgICAgdGl0bGU9XCJTd2FwIEZyb250IGFuZCBCYWNrIENhcmRzXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxBcnJvd1VwRG93biBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XG4gICAgICAgICAgICAgICAgPHNwYW4+U3dhcCBGcm9udC9CYWNrPC9zcGFuPlxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogQ2FyZCAxIFNsb3QgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YHAtMyByb3VuZGVkLXhsIGJvcmRlciB0cmFuc2l0aW9uLWFsbCAke1xuICAgICAgICAgICAgICBhY3RpdmVDYXJkID09PSAnY2FyZDEnIFxuICAgICAgICAgICAgICAgID8gJ2JnLWJsdWUtOTUwLzMwIGJvcmRlci1ibHVlLTUwMC81MCBzaGFkb3ctc20nIFxuICAgICAgICAgICAgICAgIDogJ2JnLXNsYXRlLTk1MC80MCBib3JkZXItc2xhdGUtODAwIGhvdmVyOmJvcmRlci1zbGF0ZS03MDAnXG4gICAgICAgICAgICB9YH0+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTJcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3LTIgaC0yIHJvdW5kZWQtZnVsbCBiZy1ibHVlLTUwMFwiPjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtd2hpdGVcIj5DYXJkIDEgKEZyb250IFNpZGUpPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRDYXJkMUNvbmZpZyhwcmV2ID0+ICh7IC4uLnByZXYsIHJvdGF0aW9uOiAocHJldi5yb3RhdGlvbiArIDkwKSAlIDM2MCB9KSl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHB4LTIgcHktMC41IHJvdW5kZWQgYmctc2xhdGUtODAwIGhvdmVyOmJnLXNsYXRlLTcwMCB0ZXh0LXNsYXRlLTIwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiXG4gICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiUm90YXRlIENhcmQgMVwiXG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIDxSb3RhdGVDdyBjbGFzc05hbWU9XCJ3LTMgaC0zIHRleHQtYW1iZXItNDAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+e2NhcmQxQ29uZmlnLnJvdGF0aW9ufcKwPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldENhcmQxQ29uZmlnKHsgeDogMCwgeTogMCwgc2NhbGU6IDEuMCwgcm90YXRpb246IDAgfSl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHB4LTIgcHktMC41IHJvdW5kZWQgYmctc2xhdGUtODAwIGhvdmVyOmJnLXNsYXRlLTcwMCB0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXdoaXRlXCJcbiAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJSZXNldCBQb3NpdGlvblwiXG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIFJlc2V0XG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmbGV4LTEgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgcHktMiBweC0zIGJnLXNsYXRlLTgwMCBob3ZlcjpiZy1zbGF0ZS03NTAgdGV4dC1zbGF0ZS0yMDAgdGV4dC14cyBmb250LXNlbWlib2xkIHJvdW5kZWQtbGcgY3Vyc29yLXBvaW50ZXIgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgdHJhbnNpdGlvbi1jb2xvcnNcIj5cbiAgICAgICAgICAgICAgICAgIDxVcGxvYWQgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1ibHVlLTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgICA8c3Bhbj57Y2FyZDFTcmMgPyAnQ2hhbmdlIEZyb250IFBob3RvL1BERicgOiAnVXBsb2FkIENhcmQgMSAoRnJvbnQpJ308L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cImZpbGVcIiBhY2NlcHQ9XCJpbWFnZS8qLC5wZGZcIiBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUZpbGVVcGxvYWQoZSwgJ2NhcmQxJyl9IGNsYXNzTmFtZT1cImhpZGRlblwiIC8+XG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICB7Y2FyZDFTcmMgJiYgKFxuICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0Q2FyZDFTcmMobnVsbCl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMiB0ZXh0LXJvc2UtNDAwIGhvdmVyOmJnLXJvc2UtNTAwLzEwIHJvdW5kZWQtbGcgdGV4dC14c1wiXG4gICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiUmVtb3ZlIENhcmQgMVwiXG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIOKclVxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIENhcmQgMiBTbG90ICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2BwLTMgcm91bmRlZC14bCBib3JkZXIgdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgICAgICAgYWN0aXZlQ2FyZCA9PT0gJ2NhcmQyJyBcbiAgICAgICAgICAgICAgICA/ICdiZy1ibHVlLTk1MC8zMCBib3JkZXItYmx1ZS01MDAvNTAgc2hhZG93LXNtJyBcbiAgICAgICAgICAgICAgICA6ICdiZy1zbGF0ZS05NTAvNDAgYm9yZGVyLXNsYXRlLTgwMCBob3Zlcjpib3JkZXItc2xhdGUtNzAwJ1xuICAgICAgICAgICAgfWB9PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi0yXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy0yIGgtMiByb3VuZGVkLWZ1bGwgYmctcHVycGxlLTUwMFwiPjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtd2hpdGVcIj5DYXJkIDIgKEJhY2sgU2lkZSk8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCI+XG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldENhcmQyQ29uZmlnKHByZXYgPT4gKHsgLi4ucHJldiwgcm90YXRpb246IChwcmV2LnJvdGF0aW9uICsgOTApICUgMzYwIH0pKX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gcHgtMiBweS0wLjUgcm91bmRlZCBiZy1zbGF0ZS04MDAgaG92ZXI6Ymctc2xhdGUtNzAwIHRleHQtc2xhdGUtMjAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCJcbiAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJSb3RhdGUgQ2FyZCAyXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPFJvdGF0ZUN3IGNsYXNzTmFtZT1cInctMyBoLTMgdGV4dC1hbWJlci00MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj57Y2FyZDJDb25maWcucm90YXRpb259wrA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0Q2FyZDJDb25maWcoeyB4OiAwLCB5OiAwLCBzY2FsZTogMS4wLCByb3RhdGlvbjogMCB9KX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gcHgtMiBweS0wLjUgcm91bmRlZCBiZy1zbGF0ZS04MDAgaG92ZXI6Ymctc2xhdGUtNzAwIHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtd2hpdGVcIlxuICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIlJlc2V0IFBvc2l0aW9uXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgUmVzZXRcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZsZXgtMSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiBweS0yIHB4LTMgYmctc2xhdGUtODAwIGhvdmVyOmJnLXNsYXRlLTc1MCB0ZXh0LXNsYXRlLTIwMCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgcm91bmRlZC1sZyBjdXJzb3ItcG9pbnRlciBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCB0cmFuc2l0aW9uLWNvbG9yc1wiPlxuICAgICAgICAgICAgICAgICAgPFVwbG9hZCBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LXB1cnBsZS00MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgPHNwYW4+e2NhcmQyU3JjID8gJ0NoYW5nZSBCYWNrIFBob3RvL1BERicgOiAnVXBsb2FkIENhcmQgMiAoQmFjayknfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwiZmlsZVwiIGFjY2VwdD1cImltYWdlLyosLnBkZlwiIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlRmlsZVVwbG9hZChlLCAnY2FyZDInKX0gY2xhc3NOYW1lPVwiaGlkZGVuXCIgLz5cbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgIHtjYXJkMlNyYyAmJiAoXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uIFxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRDYXJkMlNyYyhudWxsKX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0yIHRleHQtcm9zZS00MDAgaG92ZXI6Ymctcm9zZS01MDAvMTAgcm91bmRlZC1sZyB0ZXh0LXhzXCJcbiAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJSZW1vdmUgQ2FyZCAyXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAg4pyVXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIENvbG9yICYgUHJpbnQgUXVhbGl0eSBFbmhhbmNlbWVudHMgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAvOTAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0yeGwgcC00IHNoYWRvdy1tZCBzcGFjZS15LTNcIj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtMzAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBibG9ja1wiPlxuICAgICAgICAgICAgICBJbWFnZSBFbmhhbmNlbWVudCAmIExheW91dCBHdWlkZXNcbiAgICAgICAgICAgIDwvc3Bhbj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTMgdGV4dC14c1wiPlxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gdGV4dC1zbGF0ZS00MDAgbWItMVwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPjxTdW4gY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1hbWJlci00MDBcIiAvPiBCcmlnaHRuZXNzPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vIHRleHQtc2xhdGUtMjAwXCI+e2JyaWdodG5lc3MgPiAwID8gYCske2JyaWdodG5lc3N9YCA6IGJyaWdodG5lc3N9PC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgdHlwZT1cInJhbmdlXCJcbiAgICAgICAgICAgICAgICAgIG1pbj1cIi0zMFwiXG4gICAgICAgICAgICAgICAgICBtYXg9XCIzMFwiXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17YnJpZ2h0bmVzc31cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0QnJpZ2h0bmVzcyhwYXJzZUludChlLnRhcmdldC52YWx1ZSkpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGFjY2VudC1hbWJlci01MDAgaC0xLjUgYmctc2xhdGUtODAwIHJvdW5kZWQtbGcgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiB0ZXh0LXNsYXRlLTQwMCBtYi0xXCI+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCI+PENvbnRyYXN0IGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtc2t5LTQwMFwiIC8+IENvbnRyYXN0PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vIHRleHQtc2xhdGUtMjAwXCI+e2NvbnRyYXN0ID4gMCA/IGArJHtjb250cmFzdH1gIDogY29udHJhc3R9PC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgdHlwZT1cInJhbmdlXCJcbiAgICAgICAgICAgICAgICAgIG1pbj1cIi0zMFwiXG4gICAgICAgICAgICAgICAgICBtYXg9XCIzMFwiXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17Y29udHJhc3R9XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldENvbnRyYXN0KHBhcnNlSW50KGUudGFyZ2V0LnZhbHVlKSl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYWNjZW50LXNreS01MDAgaC0xLjUgYmctc2xhdGUtODAwIHJvdW5kZWQtbGcgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHQtMiBib3JkZXItdCBib3JkZXItc2xhdGUtODAwIGdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgY3Vyc29yLXBvaW50ZXIgdGV4dC1zbGF0ZS0zMDBcIj5cbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxuICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXtzaG93Q3V0TWFya3N9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2hvd0N1dE1hcmtzKGUudGFyZ2V0LmNoZWNrZWQpfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkIGFjY2VudC1ibHVlLTYwMFwiXG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgPHNwYW4+4pyCIENlbnRlciBDdXQgTGluZTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxuXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGN1cnNvci1wb2ludGVyIHRleHQtc2xhdGUtMzAwXCI+XG4gICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17cm91bmRlZENvcm5lcnN9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Um91bmRlZENvcm5lcnMoZS50YXJnZXQuY2hlY2tlZCl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQgYWNjZW50LWJsdWUtNjAwXCJcbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICA8c3Bhbj5Sb3VuZGVkIENSODAgQ29ybmVyPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XG5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgY3Vyc29yLXBvaW50ZXIgdGV4dC1zbGF0ZS0zMDBcIj5cbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxuICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXtib3JkZXJTdHJva2V9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Qm9yZGVyU3Ryb2tlKGUudGFyZ2V0LmNoZWNrZWQpfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkIGFjY2VudC1ibHVlLTYwMFwiXG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgPHNwYW4+Q2FyZCBPdXRsaW5lIEJvcmRlcjwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogUmlnaHQgU2lkZTogTGl2ZSBJbnRlcmFjdGl2ZSAzMDAgRFBJIENhbnZhcyBQcmV2aWV3ICg3IGNvbHVtbnMpICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxnOmNvbC1zcGFuLTcgc3BhY2UteS0zXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0yeGwgcC00IHNoYWRvdy14bFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItMyB0ZXh0LXhzIGZsZXgtd3JhcCBnYXAtMlwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtd2hpdGVcIj5JbnRlcmFjdGl2ZSA0w5c2IExpdmUgU2hlZXQ8L3NwYW4+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS00MDAgZm9udC1tb25vXCI+KDEyMDAgw5cgMTgwMCBweCBAIDMwMCBEUEkpPC9zcGFuPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgIHsvKiBEaXJlY3QgUHJpbnQgQnV0dG9uIGFib3ZlIENhbnZhcyAqL31cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZURpcmVjdFByaW50fVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgYmctYmx1ZS02MDAgaG92ZXI6YmctYmx1ZS01MDAgdGV4dC13aGl0ZSBmb250LWV4dHJhYm9sZCB0ZXh0LXhzIHB4LTMuNSBweS0xLjUgcm91bmRlZC1sZyBzaGFkb3ctbWQgdHJhbnNpdGlvbi1hbGwgaG92ZXI6c2NhbGUtMTA1IGFjdGl2ZTpzY2FsZS05NVwiXG4gICAgICAgICAgICAgICAgdGl0bGU9XCJQcmludCBQVkMgQ2FyZCBTaGVldCBkaXJlY3RseSB0byBjb25uZWN0ZWQgcHJpbnRlclwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8UHJpbnRlciBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XG4gICAgICAgICAgICAgICAgPHNwYW4+8J+WqO+4jyBQcmludCBQVkMgQ2FyZCBOb3c8L3NwYW4+XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBDYW52YXMgQ29udGFpbmVyIHdpdGggUnVsZXJzICYgU2hhZG93ICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBmbGV4IGp1c3RpZnktY2VudGVyIGJnLXNsYXRlLTk1MCBwLTQgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMC84MCBvdmVyZmxvdy1oaWRkZW4gc2hhZG93LWlubmVyXCI+XG4gICAgICAgICAgICAgIDxjYW52YXNcbiAgICAgICAgICAgICAgICByZWY9e2NhbnZhc1JlZn1cbiAgICAgICAgICAgICAgICB3aWR0aD17Q0FOVkFTX1dJRFRIfVxuICAgICAgICAgICAgICAgIGhlaWdodD17Q0FOVkFTX0hFSUdIVH1cbiAgICAgICAgICAgICAgICBvbk1vdXNlRG93bj17aGFuZGxlTW91c2VEb3dufVxuICAgICAgICAgICAgICAgIG9uTW91c2VNb3ZlPXtoYW5kbGVNb3VzZU1vdmV9XG4gICAgICAgICAgICAgICAgb25Nb3VzZVVwPXtoYW5kbGVNb3VzZVVwfVxuICAgICAgICAgICAgICAgIG9uTW91c2VMZWF2ZT17aGFuZGxlTW91c2VVcH1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgbWF4LXctWzQ2MHB4XSBoLWF1dG8gYmctd2hpdGUgcm91bmRlZC1sZyBzaGFkb3ctMnhsIGN1cnNvci1tb3ZlIGJvcmRlciBib3JkZXItc2xhdGUtNzAwXCJcbiAgICAgICAgICAgICAgICBzdHlsZT17eyBhc3BlY3RSYXRpbzogJzQvNicgfX1cbiAgICAgICAgICAgICAgLz5cblxuICAgICAgICAgICAgICB7LyogUnVsZXJzIC8gRGltZW5zaW9uIGJhZGdlICovfVxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIHRvcC02IGxlZnQtNiBiZy1zbGF0ZS05MDAvOTAgdGV4dC1ibHVlLTQwMCBib3JkZXIgYm9yZGVyLWJsdWUtNTAwLzMwIHB4LTIgcHktMSByb3VuZGVkIHRleHQtWzEwcHhdIGZvbnQtbW9ubyBmb250LWJvbGQgcG9pbnRlci1ldmVudHMtbm9uZVwiPlxuICAgICAgICAgICAgICAgIENSLTgwOiA4NS42IG1tIMOXIDU0IG1tXG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBRdWljayBBY3Rpb24gRm9vdGVyIEJhciAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHB0LTIgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTgwMCB0ZXh0LXhzIGZsZXgtd3JhcCBnYXAtMlwiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMFwiPuKcgu+4jyAzMDAgRFBJIFByZS1BbGlnbmVkIENlbnRlciBDdXQgTWFyazwvc3Bhbj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZURpcmVjdFByaW50fVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgYmctYmx1ZS02MDAgaG92ZXI6YmctYmx1ZS01MDAgdGV4dC13aGl0ZSBmb250LWJvbGQgdGV4dC14cyBweC0zIHB5LTEuNSByb3VuZGVkLWxnIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8UHJpbnRlciBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XG4gICAgICAgICAgICAgICAgICA8c3Bhbj5QcmludCBTaGVldCAoQ3RybCArIFApPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZURvd25sb2FkUERGfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgYmctc2xhdGUtODAwIGhvdmVyOmJnLXNsYXRlLTcwMCB0ZXh0LXNsYXRlLTIwMCBmb250LWJvbGQgdGV4dC14cyBweC0zIHB5LTEuNSByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8RG93bmxvYWQgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICAgICAgICAgICAgPHNwYW4+UERGPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogQ3liZXIgQ2FmZSBPcGVyYXRvciBQcmludCBUaXBzICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0zIHAtMyByb3VuZGVkLXhsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMC84MCB0ZXh0LXhzIHRleHQtc2xhdGUtMzAwIGxlYWRpbmctcmVsYXhlZCBmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0yLjVcIj5cbiAgICAgICAgICAgICAgPEhlbHBDaXJjbGUgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWJsdWUtNDAwIGZsZXgtc2hyaW5rLTAgbXQtMC41XCIgLz5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8YiBjbGFzc05hbWU9XCJ0ZXh0LXdoaXRlXCI+UHJpbnRlciBTZXR1cCBUaXA6PC9iPiBTZXQgeW91ciBwcmludGVyIHBhcGVyIHRvIDxiPjTDlzYgaW4gKDEww5cxNSBjbSkgUGhvdG8gUGFwZXIgR2xvc3N5PC9iPi4gSW4gcHJpbnRlciBwcm9wZXJ0aWVzLCBzZWxlY3QgPGI+SGlnaCBRdWFsaXR5PC9iPiBhbmQgPGI+Rml0IHRvIFByaW50YWJsZSBBcmVhIC8gMTAwJTwvYj4gZm9yIGV4YWN0IGNhcmQgZGltZW5zaW9ucyFcbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG4iXX0=