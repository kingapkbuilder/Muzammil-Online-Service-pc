const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=1d04f0f2";
import { CheckCircle2, Circle, Sparkles, ShieldCheck, Clock, DollarSign, FileCheck, Zap, Play } from "/node_modules/.vite/deps/lucide-react.js?v=1d04f0f2";
var _jsxFileName = "/app/applet/src/components/WorkflowGuideView.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=1d04f0f2";
const SERVICE_BLUEPRINTS = [
	{
		id: "pvc_card",
		name: "PVC Smart Card (Aadhaar, PAN, Voter, Ayushman)",
		category: "Card Printing",
		icon: "💳",
		timeEstimate: "4-5 Minutes",
		suggestedRate: "₹60 - ₹80",
		targetStudio: "pvc_studio",
		steps: [
			{
				title: "Step 1: Download Original e-Card PDF",
				action: "Download original e-Aadhaar from UIDAI or PAN PDF from NSDL/UTIITSL.",
				studioAction: {
					label: "Open Govt Portals Hub",
					tab: "portals"
				}
			},
			{
				title: "Step 2: Auto-Crop Front & Back in PVC Studio",
				action: "Upload front and back images to CR-80 85.6×54mm template with 300 DPI high-resolution.",
				studioAction: {
					label: "Open PVC Card Studio",
					tab: "pvc_studio"
				}
			},
			{
				title: "Step 3: Direct Print on 4×6 Glossy Paper",
				action: "Load 4×6 photo paper in Epson/Canon printer, hit Ctrl+P to send borderless print with center cutting line."
			},
			{
				title: "Step 4: Thermal Lamination & POS Billing",
				action: "Pass through pouch laminator for waterproof finish and generate ₹70 thermal bill.",
				studioAction: {
					label: "Open Fast Billing Desk",
					tab: "billing"
				}
			}
		],
		docsRequired: [
			"Aadhaar No. & OTP",
			"Acknowledgement Slip",
			"PAN / Voter / Ayushman ID"
		],
		operatorTips: "Printer settings mein \"Glossy Photo Paper - High Quality\" select karein taaki PVC print fade na ho."
	},
	{
		id: "passport_photo",
		name: "Urgent 8-Copy Passport Photos (4×6 Glossy Sheet)",
		category: "Photo Studio",
		icon: "📸",
		timeEstimate: "3 Minutes",
		suggestedRate: "₹50 - ₹60",
		targetStudio: "passport_studio",
		steps: [
			{
				title: "Step 1: Capture or Upload Customer Photo",
				action: "Take photo on phone/webcam or upload customer JPEG into Passport Studio.",
				studioAction: {
					label: "Open Passport Studio",
					tab: "passport_studio"
				}
			},
			{
				title: "Step 2: Magic Wand / Pen Background Cutout",
				action: "Use 1-Click Magic Cut or Vector Pen Tool to replace background with Official White or Studio Blue."
			},
			{
				title: "Step 3: Auto Beauty Skin Smoothing & Face Radiance",
				action: "Click \"Auto Studio Beauty\" to brighten skin tones, soften blemishes, and enhance facial contrast."
			},
			{
				title: "Step 4: Direct Print Sheet (Ctrl + P)",
				action: "Direct print 4×6 Landscape sheet with exact 8 pre-aligned copies and guide lines."
			}
		],
		docsRequired: ["Customer Presence / Photo", "Exam Notification (if name & date stamp required)"],
		operatorTips: "SSC GD aur Police Bharti ke liye \"Exam Strip\" enable karke candidate ka naam aur date stamp karein."
	},
	{
		id: "ladki_bahin",
		name: "Majhi Ladki Bahin Yojana Online Application",
		category: "Govt Schemes",
		icon: "🌸",
		timeEstimate: "7-9 Minutes",
		suggestedRate: "₹100",
		targetStudio: "portals",
		steps: [
			{
				title: "Step 1: Aadhaar Mobile Linking & Bank Status Check",
				action: "Check if applicant mobile number is active for OTP and Aadhaar is NPCI-linked to bank account.",
				studioAction: {
					label: "Open Govt Portals",
					tab: "portals"
				}
			},
			{
				title: "Step 2: Document Verification & Upload",
				action: "Verify Domicile Certificate (or 15-year Ration card / Voter ID) and Income Certificate (under 2.5 Lakh).",
				studioAction: {
					label: "Ask AI Scheme Guide",
					tab: "ai_assistant"
				}
			},
			{
				title: "Step 3: Portal Form Submission",
				action: "Submit application on official portal, verify bank details (Hamipatra declaration), and download acknowledgement token."
			},
			{
				title: "Step 4: Issue Acknowledgement Print & CRM Entry",
				action: "Print token slip for applicant and add customer in CRM for application tracking.",
				studioAction: {
					label: "Open Customer CRM",
					tab: "customers"
				}
			}
		],
		docsRequired: [
			"Aadhaar Card",
			"Ration Card / Domicile",
			"Bank Passbook (NPCI linked)",
			"Hamipatra Undertaking"
		],
		operatorTips: "Bank account mein DBT/NPCI active hona zaroori hai tabhi monthly ₹1,500 direct aayega."
	},
	{
		id: "police_exam",
		name: "SSC GD / Police Bharti Online Application",
		category: "Recruitment Forms",
		icon: "👮",
		timeEstimate: "10-12 Minutes",
		suggestedRate: "₹120 - ₹150",
		targetStudio: "portals",
		steps: [
			{
				title: "Step 1: Check Age, Domicile & Education Criteria",
				action: "Verify 10th/12th marksheet, category caste certificate, and non-creamy layer certificate."
			},
			{
				title: "Step 2: Prepare Form-Specification Photo & Signature",
				action: "Generate passport photo with candidate name & photo date in Passport Studio; resize signature under 20KB.",
				studioAction: {
					label: "Open Passport Studio",
					tab: "passport_studio"
				}
			},
			{
				title: "Step 3: Online Form Entry & Fee Payment",
				action: "Fill registration, review preview with applicant, pay official exam fee via UPI/Netbanking.",
				studioAction: {
					label: "Open Recruitment Portals",
					tab: "portals"
				}
			},
			{
				title: "Step 4: Print Confirmation Page & Slip",
				action: "Print color confirmation slip, issue receipt with registration number, and save in CRM."
			}
		],
		docsRequired: [
			"10th Marksheet",
			"Caste & Non-Creamy Layer Certificate",
			"Passport Photo with Date",
			"Signature"
		],
		operatorTips: "Form submit karne se pehle candidate ke samne preview check karwayein taaki koi spelling mistake na ho."
	},
	{
		id: "biodata",
		name: "Marriage BioData & Professional CV Resume",
		category: "Document Creation",
		icon: "📄",
		timeEstimate: "6-8 Minutes",
		suggestedRate: "₹70 - ₹100",
		targetStudio: "biodata_maker",
		steps: [
			{
				title: "Step 1: Select Template",
				action: "Choose from Modern Professional CV, Hindi Traditional BioData, or Islamic Marriage BioData.",
				studioAction: {
					label: "Open BioData Maker",
					tab: "biodata_maker"
				}
			},
			{
				title: "Step 2: Enter Applicant Details",
				action: "Fill personal info, qualification, job designation, family background, and contact details."
			},
			{
				title: "Step 3: Upload Studio Portrait",
				action: "Attach high-resolution passport/portrait photo."
			},
			{
				title: "Step 4: Direct Print / PDF Export",
				action: "Download 300 DPI A4 PDF and print physical copy on heavy 100 GSM bond paper."
			}
		],
		docsRequired: [
			"Applicant Details & DOB",
			"Qualification & Experience Details",
			"Family Details",
			"Photo"
		],
		operatorTips: "BioData hamesha 100 GSM white bond paper par print karein taaki presentation professional lage."
	}
];
export const WorkflowGuideView = ({ onNavigate }) => {
	const [selectedBlueprint, setSelectedBlueprint] = useState("pvc_card");
	const [completedSteps, setCompletedSteps] = useState({});
	// Daily Counter State
	const [todayCards, setTodayCards] = useState(14);
	const [todayPhotos, setTodayPhotos] = useState(8);
	const [todayForms, setTodayForms] = useState(6);
	const activeBlueprint = SERVICE_BLUEPRINTS.find((b) => b.id === selectedBlueprint) || SERVICE_BLUEPRINTS[0];
	const toggleStep = (stepKey) => {
		setCompletedSteps((prev) => ({
			...prev,
			[stepKey]: !prev[stepKey]
		}));
	};
	const handleLaunchStudio = (tab) => {
		if (onNavigate) {
			onNavigate(tab);
		}
	};
	const estimatedTodayTurnover = todayCards * 70 + todayPhotos * 50 + todayForms * 100;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-md flex flex-col lg:flex-row lg:items-center justify-between gap-4",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2 flex-wrap",
					children: [/* @__PURE__ */ _jsxDEV("h1", {
						className: "text-xl font-extrabold text-white flex items-center gap-2",
						children: [/* @__PURE__ */ _jsxDEV(ShieldCheck, { className: "w-6 h-6 text-emerald-400" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 239,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Cyber Cafe SOP & Daily Workflow Engine" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 240,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 238,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs px-2.5 py-0.5 rounded-full font-mono font-bold",
						children: "v98.0 Operational Standard"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 242,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 237,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "text-xs text-slate-400 mt-1",
					children: "End-to-end service blueprints • Customer intake to 300 DPI printing • Rates, checklists & 1-click studio launchers"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 246,
					columnNumber: 11
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 236,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-3 bg-slate-950 border border-slate-800 p-2.5 rounded-xl text-xs flex-wrap",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-1.5 px-2 border-r border-slate-800",
							children: [
								/* @__PURE__ */ _jsxDEV("span", {
									className: "text-slate-400",
									children: "Cards:"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 254,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									className: "font-mono text-blue-400 font-bold",
									children: todayCards
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 255,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => setTodayCards((c) => c + 1),
									className: "text-[10px] bg-slate-800 hover:bg-slate-700 px-1 rounded text-white",
									children: "+"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 256,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 253,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-1.5 px-2 border-r border-slate-800",
							children: [
								/* @__PURE__ */ _jsxDEV("span", {
									className: "text-slate-400",
									children: "Photos:"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 259,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									className: "font-mono text-purple-400 font-bold",
									children: todayPhotos
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 260,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => setTodayPhotos((p) => p + 1),
									className: "text-[10px] bg-slate-800 hover:bg-slate-700 px-1 rounded text-white",
									children: "+"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 261,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 258,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-1.5 px-2 border-r border-slate-800",
							children: [
								/* @__PURE__ */ _jsxDEV("span", {
									className: "text-slate-400",
									children: "Forms:"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 264,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									className: "font-mono text-emerald-400 font-bold",
									children: todayForms
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 265,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => setTodayForms((f) => f + 1),
									className: "text-[10px] bg-slate-800 hover:bg-slate-700 px-1 rounded text-white",
									children: "+"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 266,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 263,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-1 text-amber-300 font-bold font-mono pl-1",
							children: /* @__PURE__ */ _jsxDEV("span", { children: ["Est: ₹", estimatedTodayTurnover.toLocaleString("en-IN")] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 269,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 268,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 252,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 235,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center gap-2 overflow-x-auto pb-1",
				children: SERVICE_BLUEPRINTS.map((bp) => {
					const isSelected = selectedBlueprint === bp.id;
					return /* @__PURE__ */ _jsxDEV("button", {
						onClick: () => setSelectedBlueprint(bp.id),
						className: `flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold border transition-all whitespace-nowrap flex-shrink-0 ${isSelected ? "bg-gradient-to-r from-blue-600 to-indigo-600 text-white border-blue-400 shadow-lg shadow-blue-600/30 scale-102" : "bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-800"}`,
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "text-base",
							children: bp.icon
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 288,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: bp.name }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 289,
							columnNumber: 15
						}, this)]
					}, bp.id, true, {
						fileName: _jsxFileName,
						lineNumber: 279,
						columnNumber: 13
					}, this);
				})
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 275,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "grid grid-cols-1 lg:grid-cols-12 gap-4 items-start",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "lg:col-span-8 bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-3xl",
								children: activeBlueprint.icon
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 301,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
								className: "text-base font-extrabold text-white",
								children: activeBlueprint.name
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 303,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-3 text-xs text-slate-400 mt-0.5",
								children: [
									/* @__PURE__ */ _jsxDEV("span", {
										className: "flex items-center gap-1 text-sky-400 font-medium",
										children: [/* @__PURE__ */ _jsxDEV(Clock, { className: "w-3.5 h-3.5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 306,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: ["Est. Time: ", activeBlueprint.timeEstimate] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 307,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 305,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("span", { children: "•" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 309,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "flex items-center gap-1 text-emerald-400 font-bold font-mono",
										children: [/* @__PURE__ */ _jsxDEV(DollarSign, { className: "w-3.5 h-3.5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 311,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: ["Standard Rate: ", activeBlueprint.suggestedRate] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 312,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 310,
										columnNumber: 19
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 304,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 302,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 300,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => handleLaunchStudio(activeBlueprint.targetStudio),
							className: "flex items-center gap-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-extrabold text-xs px-4 py-2 rounded-xl shadow-lg shadow-emerald-600/20 transition-all hover:scale-105 self-start sm:self-auto",
							children: [/* @__PURE__ */ _jsxDEV(Zap, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 323,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Launch Studio for this Service" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 324,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 319,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 299,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-3",
						children: activeBlueprint.steps.map((st, idx) => {
							const stepKey = `${activeBlueprint.id}-${idx}`;
							const isDone = !!completedSteps[stepKey];
							return /* @__PURE__ */ _jsxDEV("div", {
								className: `p-4 rounded-xl border transition-all space-y-2 ${isDone ? "bg-slate-950/40 border-emerald-500/40" : "bg-slate-950 border-slate-800/80 hover:border-slate-700"}`,
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-2.5",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: `w-6 h-6 rounded-lg flex items-center justify-center font-mono font-bold text-xs ${isDone ? "bg-emerald-500 text-slate-950" : "bg-blue-600 text-white"}`,
											children: idx + 1
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 345,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("h3", {
											className: "font-extrabold text-white text-xs",
											children: st.title
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 350,
											columnNumber: 23
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 344,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-2",
										children: [st.studioAction && /* @__PURE__ */ _jsxDEV("button", {
											onClick: () => handleLaunchStudio(st.studioAction.tab),
											className: "flex items-center gap-1 text-[11px] font-bold px-2.5 py-1 rounded-lg bg-blue-600/20 text-blue-300 border border-blue-500/30 hover:bg-blue-600/30 transition-colors",
											children: [/* @__PURE__ */ _jsxDEV(Play, { className: "w-3 h-3" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 359,
												columnNumber: 27
											}, this), /* @__PURE__ */ _jsxDEV("span", { children: st.studioAction.label }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 360,
												columnNumber: 27
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 355,
											columnNumber: 25
										}, this), /* @__PURE__ */ _jsxDEV("button", {
											onClick: () => toggleStep(stepKey),
											className: `flex items-center gap-1 text-[11px] font-bold px-2.5 py-1 rounded-lg border transition-all ${isDone ? "bg-emerald-500/20 text-emerald-300 border-emerald-500/30" : "bg-slate-900 text-slate-400 border-slate-700 hover:text-white"}`,
											children: [isDone ? /* @__PURE__ */ _jsxDEV(CheckCircle2, { className: "w-3.5 h-3.5 text-emerald-400" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 372,
												columnNumber: 35
											}, this) : /* @__PURE__ */ _jsxDEV(Circle, { className: "w-3.5 h-3.5" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 372,
												columnNumber: 95
											}, this), /* @__PURE__ */ _jsxDEV("span", { children: isDone ? "Completed" : "Mark Done" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 373,
												columnNumber: 25
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 364,
											columnNumber: 23
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 353,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 343,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-slate-300 leading-relaxed pl-8",
									children: st.action
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 378,
									columnNumber: 19
								}, this)]
							}, idx, true, {
								fileName: _jsxFileName,
								lineNumber: 335,
								columnNumber: 17
							}, this);
						})
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 329,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 298,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "lg:col-span-4 space-y-4",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-md space-y-3",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2 text-xs font-bold text-white uppercase tracking-wider",
								children: [/* @__PURE__ */ _jsxDEV(FileCheck, { className: "w-4 h-4 text-emerald-400" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 392,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Customer Documents Checklist" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 393,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 391,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-2 text-xs text-slate-300",
								children: activeBlueprint.docsRequired.map((doc, i) => /* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-start gap-2 bg-slate-950 p-2.5 rounded-xl border border-slate-800",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-emerald-400 font-bold",
										children: "✓"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 399,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: doc }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 400,
										columnNumber: 19
									}, this)]
								}, i, true, {
									fileName: _jsxFileName,
									lineNumber: 398,
									columnNumber: 17
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 396,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 390,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "bg-gradient-to-br from-amber-950/20 via-slate-900 to-slate-900 border border-amber-500/30 rounded-2xl p-4 shadow-md space-y-2 text-xs",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2 text-amber-300 font-bold uppercase tracking-wider",
								children: [/* @__PURE__ */ _jsxDEV(Sparkles, { className: "w-4 h-4 text-amber-400" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 409,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Operator Golden Rule" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 410,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 408,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "text-slate-300 leading-relaxed",
								children: activeBlueprint.operatorTips
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 412,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 407,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-md space-y-2.5",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs font-bold text-slate-300 uppercase tracking-wider block",
								children: "Quick Workstation Launchers"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 419,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-2 gap-2 text-xs",
								children: [
									/* @__PURE__ */ _jsxDEV("button", {
										onClick: () => handleLaunchStudio("pvc_studio"),
										className: "p-2.5 rounded-xl bg-slate-950 hover:bg-blue-950/30 border border-slate-800 hover:border-blue-500/40 text-left transition-all group",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "font-bold text-white group-hover:text-blue-400",
											children: "PVC Studio"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 428,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "text-[10px] text-slate-400",
											children: "300 DPI Cards"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 429,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 424,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										onClick: () => handleLaunchStudio("passport_studio"),
										className: "p-2.5 rounded-xl bg-slate-950 hover:bg-purple-950/30 border border-slate-800 hover:border-purple-500/40 text-left transition-all group",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "font-bold text-white group-hover:text-purple-400",
											children: "Passport Studio"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 436,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "text-[10px] text-slate-400",
											children: "4×6 & A4 Sheet"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 437,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 432,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										onClick: () => handleLaunchStudio("billing"),
										className: "p-2.5 rounded-xl bg-slate-950 hover:bg-emerald-950/30 border border-slate-800 hover:border-emerald-500/40 text-left transition-all group",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "font-bold text-white group-hover:text-emerald-400",
											children: "Fast POS Billing"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 444,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "text-[10px] text-slate-400",
											children: "Thermal Slips"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 445,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 440,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										onClick: () => handleLaunchStudio("portals"),
										className: "p-2.5 rounded-xl bg-slate-950 hover:bg-sky-950/30 border border-slate-800 hover:border-sky-500/40 text-left transition-all group",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "font-bold text-white group-hover:text-sky-400",
											children: "50+ Portals Hub"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 452,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "text-[10px] text-slate-400",
											children: "Govt Schemes"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 453,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 448,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 423,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 418,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 388,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 296,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 233,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxTQUNFLGNBQ0EsUUFPQSxVQUVBLGFBRUEsT0FFQSxZQUNBLFdBQ0EsS0FDQSxZQUtLOzs7QUF1QlAsTUFBTSxxQkFBeUM7Q0FDN0M7RUFDRSxJQUFJO0VBQ0osTUFBTTtFQUNOLFVBQVU7RUFDVixNQUFNO0VBQ04sY0FBYztFQUNkLGVBQWU7RUFDZixjQUFjO0VBQ2QsT0FBTztHQUNMO0lBQ0UsT0FBTztJQUNQLFFBQVE7SUFDUixjQUFjO0tBQUUsT0FBTztLQUF5QixLQUFLO0lBQVU7R0FDakU7R0FDQTtJQUNFLE9BQU87SUFDUCxRQUFRO0lBQ1IsY0FBYztLQUFFLE9BQU87S0FBd0IsS0FBSztJQUFhO0dBQ25FO0dBQ0E7SUFDRSxPQUFPO0lBQ1AsUUFBUTtHQUNWO0dBQ0E7SUFDRSxPQUFPO0lBQ1AsUUFBUTtJQUNSLGNBQWM7S0FBRSxPQUFPO0tBQTBCLEtBQUs7SUFBVTtHQUNsRTtFQUNGO0VBQ0EsY0FBYztHQUFDO0dBQXFCO0dBQXdCO0VBQTJCO0VBQ3ZGLGNBQWM7Q0FDaEI7Q0FDQTtFQUNFLElBQUk7RUFDSixNQUFNO0VBQ04sVUFBVTtFQUNWLE1BQU07RUFDTixjQUFjO0VBQ2QsZUFBZTtFQUNmLGNBQWM7RUFDZCxPQUFPO0dBQ0w7SUFDRSxPQUFPO0lBQ1AsUUFBUTtJQUNSLGNBQWM7S0FBRSxPQUFPO0tBQXdCLEtBQUs7SUFBa0I7R0FDeEU7R0FDQTtJQUNFLE9BQU87SUFDUCxRQUFRO0dBQ1Y7R0FDQTtJQUNFLE9BQU87SUFDUCxRQUFRO0dBQ1Y7R0FDQTtJQUNFLE9BQU87SUFDUCxRQUFRO0dBQ1Y7RUFDRjtFQUNBLGNBQWMsQ0FBQyw2QkFBNkIsbURBQW1EO0VBQy9GLGNBQWM7Q0FDaEI7Q0FDQTtFQUNFLElBQUk7RUFDSixNQUFNO0VBQ04sVUFBVTtFQUNWLE1BQU07RUFDTixjQUFjO0VBQ2QsZUFBZTtFQUNmLGNBQWM7RUFDZCxPQUFPO0dBQ0w7SUFDRSxPQUFPO0lBQ1AsUUFBUTtJQUNSLGNBQWM7S0FBRSxPQUFPO0tBQXFCLEtBQUs7SUFBVTtHQUM3RDtHQUNBO0lBQ0UsT0FBTztJQUNQLFFBQVE7SUFDUixjQUFjO0tBQUUsT0FBTztLQUF1QixLQUFLO0lBQWU7R0FDcEU7R0FDQTtJQUNFLE9BQU87SUFDUCxRQUFRO0dBQ1Y7R0FDQTtJQUNFLE9BQU87SUFDUCxRQUFRO0lBQ1IsY0FBYztLQUFFLE9BQU87S0FBcUIsS0FBSztJQUFZO0dBQy9EO0VBQ0Y7RUFDQSxjQUFjO0dBQUM7R0FBZ0I7R0FBMEI7R0FBK0I7RUFBdUI7RUFDL0csY0FBYztDQUNoQjtDQUNBO0VBQ0UsSUFBSTtFQUNKLE1BQU07RUFDTixVQUFVO0VBQ1YsTUFBTTtFQUNOLGNBQWM7RUFDZCxlQUFlO0VBQ2YsY0FBYztFQUNkLE9BQU87R0FDTDtJQUNFLE9BQU87SUFDUCxRQUFRO0dBQ1Y7R0FDQTtJQUNFLE9BQU87SUFDUCxRQUFRO0lBQ1IsY0FBYztLQUFFLE9BQU87S0FBd0IsS0FBSztJQUFrQjtHQUN4RTtHQUNBO0lBQ0UsT0FBTztJQUNQLFFBQVE7SUFDUixjQUFjO0tBQUUsT0FBTztLQUE0QixLQUFLO0lBQVU7R0FDcEU7R0FDQTtJQUNFLE9BQU87SUFDUCxRQUFRO0dBQ1Y7RUFDRjtFQUNBLGNBQWM7R0FBQztHQUFrQjtHQUF3QztHQUE0QjtFQUFXO0VBQ2hILGNBQWM7Q0FDaEI7Q0FDQTtFQUNFLElBQUk7RUFDSixNQUFNO0VBQ04sVUFBVTtFQUNWLE1BQU07RUFDTixjQUFjO0VBQ2QsZUFBZTtFQUNmLGNBQWM7RUFDZCxPQUFPO0dBQ0w7SUFDRSxPQUFPO0lBQ1AsUUFBUTtJQUNSLGNBQWM7S0FBRSxPQUFPO0tBQXNCLEtBQUs7SUFBZ0I7R0FDcEU7R0FDQTtJQUNFLE9BQU87SUFDUCxRQUFRO0dBQ1Y7R0FDQTtJQUNFLE9BQU87SUFDUCxRQUFRO0dBQ1Y7R0FDQTtJQUNFLE9BQU87SUFDUCxRQUFRO0dBQ1Y7RUFDRjtFQUNBLGNBQWM7R0FBQztHQUEyQjtHQUFzQztHQUFrQjtFQUFPO0VBQ3pHLGNBQWM7Q0FDaEI7QUFDRjtBQUVBLE9BQU8sTUFBTSxxQkFBdUQsRUFBRSxpQkFBaUI7Q0FDckYsTUFBTSxDQUFDLG1CQUFtQix3QkFBd0IsU0FBaUIsVUFBVTtDQUM3RSxNQUFNLENBQUMsZ0JBQWdCLHFCQUFxQixTQUFrQyxDQUFDLENBQUM7O0NBR2hGLE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUFpQixFQUFFO0NBQ3ZELE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFpQixDQUFDO0NBQ3hELE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUFpQixDQUFDO0NBRXRELE1BQU0sa0JBQWtCLG1CQUFtQixNQUFLLE1BQUssRUFBRSxPQUFPLGlCQUFpQixLQUFLLG1CQUFtQjtDQUV2RyxNQUFNLGNBQWMsWUFBb0I7RUFDdEMsbUJBQWtCLFVBQVM7R0FDekIsR0FBRztJQUNGLFVBQVUsQ0FBQyxLQUFLO0VBQ25CLEVBQUU7Q0FDSjtDQUVBLE1BQU0sc0JBQXNCLFFBQWdCO0VBQzFDLElBQUksWUFBWTtHQUNkLFdBQVcsR0FBRztFQUNoQjtDQUNGO0NBRUEsTUFBTSx5QkFBeUIsYUFBYSxLQUFLLGNBQWMsS0FBSyxhQUFhO0NBRWpGLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUVFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUFkLENBQ0Usd0JBQUMsYUFBRCxFQUFhLFdBQVUsMkJBQTRCOzs7O2dCQUNuRCx3QkFBQyxRQUFELFlBQU0seUNBQTRDOzs7O2NBQ2hEOzs7OztlQUNKLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUF5SDtLQUVuSTs7OzthQUNIOzs7OztjQUNMLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQThCO0lBRXhDOzs7O1lBQ0E7Ozs7Y0FHTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDRSx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBaUI7UUFBWTs7Ozs7UUFDN0Msd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQXFDO1FBQWlCOzs7OztRQUN0RSx3QkFBQyxVQUFEO1NBQVEsZUFBZSxlQUFjLE1BQUssSUFBSSxDQUFDO1NBQUcsV0FBVTttQkFBc0U7UUFBUzs7Ozs7T0FDeEk7Ozs7OztNQUNMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQWlCO1FBQWE7Ozs7O1FBQzlDLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUF1QztRQUFrQjs7Ozs7UUFDekUsd0JBQUMsVUFBRDtTQUFRLGVBQWUsZ0JBQWUsTUFBSyxJQUFJLENBQUM7U0FBRyxXQUFVO21CQUFzRTtRQUFTOzs7OztPQUN6STs7Ozs7O01BQ0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDRSx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBaUI7UUFBWTs7Ozs7UUFDN0Msd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQXdDO1FBQWlCOzs7OztRQUN6RSx3QkFBQyxVQUFEO1NBQVEsZUFBZSxlQUFjLE1BQUssSUFBSSxDQUFDO1NBQUcsV0FBVTttQkFBc0U7UUFBUzs7Ozs7T0FDeEk7Ozs7OztNQUNMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNiLHdCQUFDLFFBQUQsYUFBTSxVQUFPLHVCQUF1QixlQUFlLE9BQU8sQ0FBUTs7Ozs7TUFDL0Q7Ozs7O0tBQ0Y7Ozs7O1lBQ0Y7Ozs7OztHQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ1osbUJBQW1CLEtBQUssT0FBTztLQUM5QixNQUFNLGFBQWEsc0JBQXNCLEdBQUc7S0FDNUMsT0FDRSx3QkFBQyxVQUFEO01BRUUsZUFBZSxxQkFBcUIsR0FBRyxFQUFFO01BQ3pDLFdBQVcsMEhBQ1QsYUFDSSxtSEFDQTtnQkFOUixDQVNFLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFhLEdBQUc7TUFBVzs7OztnQkFDM0Msd0JBQUMsUUFBRCxZQUFPLEdBQUcsS0FBVzs7OztjQUNmO1FBVkQsR0FBRzs7OztZQVVGO0lBRVosQ0FBQztHQUNFOzs7OztHQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FFRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFZLGdCQUFnQjtPQUFXOzs7O2lCQUN2RCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQXVDLGdCQUFnQjtPQUFTOzs7O2lCQUM5RSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFoQixDQUNFLHdCQUFDLE9BQUQsRUFBTyxXQUFVLGNBQWU7Ozs7b0JBQ2hDLHdCQUFDLFFBQUQsYUFBTSxlQUFZLGdCQUFnQixZQUFtQjs7OztrQkFDakQ7Ozs7OztTQUNOLHdCQUFDLFFBQUQsWUFBTSxJQUFPOzs7OztTQUNiLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFoQixDQUNFLHdCQUFDLFlBQUQsRUFBWSxXQUFVLGNBQWU7Ozs7b0JBQ3JDLHdCQUFDLFFBQUQsYUFBTSxtQkFBZ0IsZ0JBQWdCLGFBQW9COzs7O2tCQUN0RDs7Ozs7O1FBQ0g7Ozs7O2VBQ0Y7Ozs7ZUFDRjs7Ozs7Z0JBR0wsd0JBQUMsVUFBRDtPQUNFLGVBQWUsbUJBQW1CLGdCQUFnQixZQUFZO09BQzlELFdBQVU7aUJBRlosQ0FJRSx3QkFBQyxLQUFELEVBQUssV0FBVSxVQUFXOzs7O2lCQUMxQix3QkFBQyxRQUFELFlBQU0saUNBQW9DOzs7O2VBQ3BDOzs7OztjQUNMOzs7OztlQUdMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNaLGdCQUFnQixNQUFNLEtBQUssSUFBSSxRQUFRO09BQ3RDLE1BQU0sVUFBVSxHQUFHLGdCQUFnQixHQUFHLEdBQUc7T0FDekMsTUFBTSxTQUFTLENBQUMsQ0FBQyxlQUFlO09BRWhDLE9BQ0Usd0JBQUMsT0FBRDtRQUVFLFdBQVcsa0RBQ1QsU0FDSSwwQ0FDQTtrQkFMUixDQVFFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxRQUFEO1dBQU0sV0FBVyxtRkFDZixTQUFTLGtDQUFrQztxQkFFMUMsTUFBTTtVQUNIOzs7O29CQUNOLHdCQUFDLE1BQUQ7V0FBSSxXQUFVO3FCQUFxQyxHQUFHO1VBQVU7Ozs7a0JBQzdEOzs7OzttQkFFTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNHLEdBQUcsZ0JBQ0Ysd0JBQUMsVUFBRDtXQUNFLGVBQWUsbUJBQW1CLEdBQUcsYUFBYyxHQUFHO1dBQ3RELFdBQVU7cUJBRlosQ0FJRSx3QkFBQyxNQUFELEVBQU0sV0FBVSxVQUFXOzs7O3FCQUMzQix3QkFBQyxRQUFELFlBQU8sR0FBRyxhQUFhLE1BQVk7Ozs7bUJBQzdCOzs7OztvQkFHVix3QkFBQyxVQUFEO1dBQ0UsZUFBZSxXQUFXLE9BQU87V0FDakMsV0FBVyw4RkFDVCxTQUNJLDZEQUNBO3FCQUxSLENBUUcsU0FBUyx3QkFBQyxjQUFELEVBQWMsV0FBVSwrQkFBZ0M7Ozs7c0JBQUksd0JBQUMsUUFBRCxFQUFRLFdBQVUsY0FBZTs7OztxQkFDdkcsd0JBQUMsUUFBRCxZQUFPLFNBQVMsY0FBYyxZQUFrQjs7OzttQkFDMUM7Ozs7O2tCQUNMOzs7OztpQkFDRjs7Ozs7a0JBRUwsd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQ1YsR0FBRztRQUNIOzs7O2dCQUNBO1VBN0NFOzs7O2NBNkNGO01BRVQsQ0FBQztLQUNFOzs7O2FBQ0Y7Ozs7O2NBR0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUVFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxXQUFELEVBQVcsV0FBVSwyQkFBNEI7Ozs7a0JBQ2pELHdCQUFDLFFBQUQsWUFBTSwrQkFBa0M7Ozs7Z0JBQ3JDOzs7OztpQkFFTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFDWixnQkFBZ0IsYUFBYSxLQUFLLEtBQUssTUFDdEMsd0JBQUMsT0FBRDtTQUFhLFdBQVU7bUJBQXZCLENBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQTZCO1NBQU87Ozs7bUJBQ3BELHdCQUFDLFFBQUQsWUFBTyxJQUFVOzs7O2lCQUNkO1dBSEs7Ozs7ZUFHTCxDQUNOO09BQ0U7Ozs7ZUFDRjs7Ozs7O01BR0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLFVBQUQsRUFBVSxXQUFVLHlCQUEwQjs7OztrQkFDOUMsd0JBQUMsUUFBRCxZQUFNLHVCQUEwQjs7OztnQkFDN0I7Ozs7O2lCQUNMLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUNWLGdCQUFnQjtPQUNoQjs7OztlQUNBOzs7Ozs7TUFHTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFrRTtPQUU1RTs7OztpQkFFTix3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUNFLHdCQUFDLFVBQUQ7VUFDRSxlQUFlLG1CQUFtQixZQUFZO1VBQzlDLFdBQVU7b0JBRlosQ0FJRSx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBaUQ7VUFBZTs7OztvQkFDL0Usd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQTZCO1VBQWtCOzs7O2tCQUN4RDs7Ozs7O1NBRVIsd0JBQUMsVUFBRDtVQUNFLGVBQWUsbUJBQW1CLGlCQUFpQjtVQUNuRCxXQUFVO29CQUZaLENBSUUsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQW1EO1VBQW9COzs7O29CQUN0Rix3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBNkI7VUFBbUI7Ozs7a0JBQ3pEOzs7Ozs7U0FFUix3QkFBQyxVQUFEO1VBQ0UsZUFBZSxtQkFBbUIsU0FBUztVQUMzQyxXQUFVO29CQUZaLENBSUUsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQW9EO1VBQXFCOzs7O29CQUN4Rix3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBNkI7VUFBa0I7Ozs7a0JBQ3hEOzs7Ozs7U0FFUix3QkFBQyxVQUFEO1VBQ0UsZUFBZSxtQkFBbUIsU0FBUztVQUMzQyxXQUFVO29CQUZaLENBSUUsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWdEO1VBQW9COzs7O29CQUNuRix3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBNkI7VUFBaUI7Ozs7a0JBQ3ZEOzs7Ozs7UUFDTDs7Ozs7ZUFDRjs7Ozs7O0tBQ0Y7Ozs7O1lBQ0Y7Ozs7OztFQUNGOzs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJXb3JrZmxvd0d1aWRlVmlldy50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgXG4gIENoZWNrQ2lyY2xlMiwgXG4gIENpcmNsZSwgXG4gIEFycm93UmlnaHQsIFxuICBQcmludGVyLCBcbiAgRmlsZVRleHQsIFxuICBDcmVkaXRDYXJkLCBcbiAgQ2FtZXJhLCBcbiAgVXNlcnMsIFxuICBTcGFya2xlcywgXG4gIExheWVycywgXG4gIFNoaWVsZENoZWNrLCBcbiAgSGVscENpcmNsZSxcbiAgQ2xvY2ssXG4gIFFyQ29kZSxcbiAgRG9sbGFyU2lnbixcbiAgRmlsZUNoZWNrLFxuICBaYXAsXG4gIFBsYXksXG4gIFJvdGF0ZUNjdyxcbiAgQ2hlY2ssXG4gIFRyZW5kaW5nVXAsXG4gIEF3YXJkXG59IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5cbmludGVyZmFjZSBXb3JrZmxvd0d1aWRlVmlld1Byb3BzIHtcbiAgb25OYXZpZ2F0ZT86ICh0YWI6IHN0cmluZykgPT4gdm9pZDtcbn1cblxuaW50ZXJmYWNlIFNlcnZpY2VCbHVlcHJpbnQge1xuICBpZDogc3RyaW5nO1xuICBuYW1lOiBzdHJpbmc7XG4gIGNhdGVnb3J5OiBzdHJpbmc7XG4gIGljb246IHN0cmluZztcbiAgdGltZUVzdGltYXRlOiBzdHJpbmc7XG4gIHN1Z2dlc3RlZFJhdGU6IHN0cmluZztcbiAgdGFyZ2V0U3R1ZGlvOiBzdHJpbmc7XG4gIHN0ZXBzOiB7XG4gICAgdGl0bGU6IHN0cmluZztcbiAgICBhY3Rpb246IHN0cmluZztcbiAgICBzdHVkaW9BY3Rpb24/OiB7IGxhYmVsOiBzdHJpbmc7IHRhYjogc3RyaW5nIH07XG4gIH1bXTtcbiAgZG9jc1JlcXVpcmVkOiBzdHJpbmdbXTtcbiAgb3BlcmF0b3JUaXBzOiBzdHJpbmc7XG59XG5cbmNvbnN0IFNFUlZJQ0VfQkxVRVBSSU5UUzogU2VydmljZUJsdWVwcmludFtdID0gW1xuICB7XG4gICAgaWQ6ICdwdmNfY2FyZCcsXG4gICAgbmFtZTogJ1BWQyBTbWFydCBDYXJkIChBYWRoYWFyLCBQQU4sIFZvdGVyLCBBeXVzaG1hbiknLFxuICAgIGNhdGVnb3J5OiAnQ2FyZCBQcmludGluZycsXG4gICAgaWNvbjogJ/CfkrMnLFxuICAgIHRpbWVFc3RpbWF0ZTogJzQtNSBNaW51dGVzJyxcbiAgICBzdWdnZXN0ZWRSYXRlOiAn4oK5NjAgLSDigrk4MCcsXG4gICAgdGFyZ2V0U3R1ZGlvOiAncHZjX3N0dWRpbycsXG4gICAgc3RlcHM6IFtcbiAgICAgIHtcbiAgICAgICAgdGl0bGU6ICdTdGVwIDE6IERvd25sb2FkIE9yaWdpbmFsIGUtQ2FyZCBQREYnLFxuICAgICAgICBhY3Rpb246ICdEb3dubG9hZCBvcmlnaW5hbCBlLUFhZGhhYXIgZnJvbSBVSURBSSBvciBQQU4gUERGIGZyb20gTlNETC9VVElJVFNMLicsXG4gICAgICAgIHN0dWRpb0FjdGlvbjogeyBsYWJlbDogJ09wZW4gR292dCBQb3J0YWxzIEh1YicsIHRhYjogJ3BvcnRhbHMnIH1cbiAgICAgIH0sXG4gICAgICB7XG4gICAgICAgIHRpdGxlOiAnU3RlcCAyOiBBdXRvLUNyb3AgRnJvbnQgJiBCYWNrIGluIFBWQyBTdHVkaW8nLFxuICAgICAgICBhY3Rpb246ICdVcGxvYWQgZnJvbnQgYW5kIGJhY2sgaW1hZ2VzIHRvIENSLTgwIDg1LjbDlzU0bW0gdGVtcGxhdGUgd2l0aCAzMDAgRFBJIGhpZ2gtcmVzb2x1dGlvbi4nLFxuICAgICAgICBzdHVkaW9BY3Rpb246IHsgbGFiZWw6ICdPcGVuIFBWQyBDYXJkIFN0dWRpbycsIHRhYjogJ3B2Y19zdHVkaW8nIH1cbiAgICAgIH0sXG4gICAgICB7XG4gICAgICAgIHRpdGxlOiAnU3RlcCAzOiBEaXJlY3QgUHJpbnQgb24gNMOXNiBHbG9zc3kgUGFwZXInLFxuICAgICAgICBhY3Rpb246ICdMb2FkIDTDlzYgcGhvdG8gcGFwZXIgaW4gRXBzb24vQ2Fub24gcHJpbnRlciwgaGl0IEN0cmwrUCB0byBzZW5kIGJvcmRlcmxlc3MgcHJpbnQgd2l0aCBjZW50ZXIgY3V0dGluZyBsaW5lLidcbiAgICAgIH0sXG4gICAgICB7XG4gICAgICAgIHRpdGxlOiAnU3RlcCA0OiBUaGVybWFsIExhbWluYXRpb24gJiBQT1MgQmlsbGluZycsXG4gICAgICAgIGFjdGlvbjogJ1Bhc3MgdGhyb3VnaCBwb3VjaCBsYW1pbmF0b3IgZm9yIHdhdGVycHJvb2YgZmluaXNoIGFuZCBnZW5lcmF0ZSDigrk3MCB0aGVybWFsIGJpbGwuJyxcbiAgICAgICAgc3R1ZGlvQWN0aW9uOiB7IGxhYmVsOiAnT3BlbiBGYXN0IEJpbGxpbmcgRGVzaycsIHRhYjogJ2JpbGxpbmcnIH1cbiAgICAgIH1cbiAgICBdLFxuICAgIGRvY3NSZXF1aXJlZDogWydBYWRoYWFyIE5vLiAmIE9UUCcsICdBY2tub3dsZWRnZW1lbnQgU2xpcCcsICdQQU4gLyBWb3RlciAvIEF5dXNobWFuIElEJ10sXG4gICAgb3BlcmF0b3JUaXBzOiAnUHJpbnRlciBzZXR0aW5ncyBtZWluIFwiR2xvc3N5IFBob3RvIFBhcGVyIC0gSGlnaCBRdWFsaXR5XCIgc2VsZWN0IGthcmVpbiB0YWFraSBQVkMgcHJpbnQgZmFkZSBuYSBoby4nXG4gIH0sXG4gIHtcbiAgICBpZDogJ3Bhc3Nwb3J0X3Bob3RvJyxcbiAgICBuYW1lOiAnVXJnZW50IDgtQ29weSBQYXNzcG9ydCBQaG90b3MgKDTDlzYgR2xvc3N5IFNoZWV0KScsXG4gICAgY2F0ZWdvcnk6ICdQaG90byBTdHVkaW8nLFxuICAgIGljb246ICfwn5O4JyxcbiAgICB0aW1lRXN0aW1hdGU6ICczIE1pbnV0ZXMnLFxuICAgIHN1Z2dlc3RlZFJhdGU6ICfigrk1MCAtIOKCuTYwJyxcbiAgICB0YXJnZXRTdHVkaW86ICdwYXNzcG9ydF9zdHVkaW8nLFxuICAgIHN0ZXBzOiBbXG4gICAgICB7XG4gICAgICAgIHRpdGxlOiAnU3RlcCAxOiBDYXB0dXJlIG9yIFVwbG9hZCBDdXN0b21lciBQaG90bycsXG4gICAgICAgIGFjdGlvbjogJ1Rha2UgcGhvdG8gb24gcGhvbmUvd2ViY2FtIG9yIHVwbG9hZCBjdXN0b21lciBKUEVHIGludG8gUGFzc3BvcnQgU3R1ZGlvLicsXG4gICAgICAgIHN0dWRpb0FjdGlvbjogeyBsYWJlbDogJ09wZW4gUGFzc3BvcnQgU3R1ZGlvJywgdGFiOiAncGFzc3BvcnRfc3R1ZGlvJyB9XG4gICAgICB9LFxuICAgICAge1xuICAgICAgICB0aXRsZTogJ1N0ZXAgMjogTWFnaWMgV2FuZCAvIFBlbiBCYWNrZ3JvdW5kIEN1dG91dCcsXG4gICAgICAgIGFjdGlvbjogJ1VzZSAxLUNsaWNrIE1hZ2ljIEN1dCBvciBWZWN0b3IgUGVuIFRvb2wgdG8gcmVwbGFjZSBiYWNrZ3JvdW5kIHdpdGggT2ZmaWNpYWwgV2hpdGUgb3IgU3R1ZGlvIEJsdWUuJ1xuICAgICAgfSxcbiAgICAgIHtcbiAgICAgICAgdGl0bGU6ICdTdGVwIDM6IEF1dG8gQmVhdXR5IFNraW4gU21vb3RoaW5nICYgRmFjZSBSYWRpYW5jZScsXG4gICAgICAgIGFjdGlvbjogJ0NsaWNrIFwiQXV0byBTdHVkaW8gQmVhdXR5XCIgdG8gYnJpZ2h0ZW4gc2tpbiB0b25lcywgc29mdGVuIGJsZW1pc2hlcywgYW5kIGVuaGFuY2UgZmFjaWFsIGNvbnRyYXN0LidcbiAgICAgIH0sXG4gICAgICB7XG4gICAgICAgIHRpdGxlOiAnU3RlcCA0OiBEaXJlY3QgUHJpbnQgU2hlZXQgKEN0cmwgKyBQKScsXG4gICAgICAgIGFjdGlvbjogJ0RpcmVjdCBwcmludCA0w5c2IExhbmRzY2FwZSBzaGVldCB3aXRoIGV4YWN0IDggcHJlLWFsaWduZWQgY29waWVzIGFuZCBndWlkZSBsaW5lcy4nXG4gICAgICB9XG4gICAgXSxcbiAgICBkb2NzUmVxdWlyZWQ6IFsnQ3VzdG9tZXIgUHJlc2VuY2UgLyBQaG90bycsICdFeGFtIE5vdGlmaWNhdGlvbiAoaWYgbmFtZSAmIGRhdGUgc3RhbXAgcmVxdWlyZWQpJ10sXG4gICAgb3BlcmF0b3JUaXBzOiAnU1NDIEdEIGF1ciBQb2xpY2UgQmhhcnRpIGtlIGxpeWUgXCJFeGFtIFN0cmlwXCIgZW5hYmxlIGthcmtlIGNhbmRpZGF0ZSBrYSBuYWFtIGF1ciBkYXRlIHN0YW1wIGthcmVpbi4nXG4gIH0sXG4gIHtcbiAgICBpZDogJ2xhZGtpX2JhaGluJyxcbiAgICBuYW1lOiAnTWFqaGkgTGFka2kgQmFoaW4gWW9qYW5hIE9ubGluZSBBcHBsaWNhdGlvbicsXG4gICAgY2F0ZWdvcnk6ICdHb3Z0IFNjaGVtZXMnLFxuICAgIGljb246ICfwn4y4JyxcbiAgICB0aW1lRXN0aW1hdGU6ICc3LTkgTWludXRlcycsXG4gICAgc3VnZ2VzdGVkUmF0ZTogJ+KCuTEwMCcsXG4gICAgdGFyZ2V0U3R1ZGlvOiAncG9ydGFscycsXG4gICAgc3RlcHM6IFtcbiAgICAgIHtcbiAgICAgICAgdGl0bGU6ICdTdGVwIDE6IEFhZGhhYXIgTW9iaWxlIExpbmtpbmcgJiBCYW5rIFN0YXR1cyBDaGVjaycsXG4gICAgICAgIGFjdGlvbjogJ0NoZWNrIGlmIGFwcGxpY2FudCBtb2JpbGUgbnVtYmVyIGlzIGFjdGl2ZSBmb3IgT1RQIGFuZCBBYWRoYWFyIGlzIE5QQ0ktbGlua2VkIHRvIGJhbmsgYWNjb3VudC4nLFxuICAgICAgICBzdHVkaW9BY3Rpb246IHsgbGFiZWw6ICdPcGVuIEdvdnQgUG9ydGFscycsIHRhYjogJ3BvcnRhbHMnIH1cbiAgICAgIH0sXG4gICAgICB7XG4gICAgICAgIHRpdGxlOiAnU3RlcCAyOiBEb2N1bWVudCBWZXJpZmljYXRpb24gJiBVcGxvYWQnLFxuICAgICAgICBhY3Rpb246ICdWZXJpZnkgRG9taWNpbGUgQ2VydGlmaWNhdGUgKG9yIDE1LXllYXIgUmF0aW9uIGNhcmQgLyBWb3RlciBJRCkgYW5kIEluY29tZSBDZXJ0aWZpY2F0ZSAodW5kZXIgMi41IExha2gpLicsXG4gICAgICAgIHN0dWRpb0FjdGlvbjogeyBsYWJlbDogJ0FzayBBSSBTY2hlbWUgR3VpZGUnLCB0YWI6ICdhaV9hc3Npc3RhbnQnIH1cbiAgICAgIH0sXG4gICAgICB7XG4gICAgICAgIHRpdGxlOiAnU3RlcCAzOiBQb3J0YWwgRm9ybSBTdWJtaXNzaW9uJyxcbiAgICAgICAgYWN0aW9uOiAnU3VibWl0IGFwcGxpY2F0aW9uIG9uIG9mZmljaWFsIHBvcnRhbCwgdmVyaWZ5IGJhbmsgZGV0YWlscyAoSGFtaXBhdHJhIGRlY2xhcmF0aW9uKSwgYW5kIGRvd25sb2FkIGFja25vd2xlZGdlbWVudCB0b2tlbi4nXG4gICAgICB9LFxuICAgICAge1xuICAgICAgICB0aXRsZTogJ1N0ZXAgNDogSXNzdWUgQWNrbm93bGVkZ2VtZW50IFByaW50ICYgQ1JNIEVudHJ5JyxcbiAgICAgICAgYWN0aW9uOiAnUHJpbnQgdG9rZW4gc2xpcCBmb3IgYXBwbGljYW50IGFuZCBhZGQgY3VzdG9tZXIgaW4gQ1JNIGZvciBhcHBsaWNhdGlvbiB0cmFja2luZy4nLFxuICAgICAgICBzdHVkaW9BY3Rpb246IHsgbGFiZWw6ICdPcGVuIEN1c3RvbWVyIENSTScsIHRhYjogJ2N1c3RvbWVycycgfVxuICAgICAgfVxuICAgIF0sXG4gICAgZG9jc1JlcXVpcmVkOiBbJ0FhZGhhYXIgQ2FyZCcsICdSYXRpb24gQ2FyZCAvIERvbWljaWxlJywgJ0JhbmsgUGFzc2Jvb2sgKE5QQ0kgbGlua2VkKScsICdIYW1pcGF0cmEgVW5kZXJ0YWtpbmcnXSxcbiAgICBvcGVyYXRvclRpcHM6ICdCYW5rIGFjY291bnQgbWVpbiBEQlQvTlBDSSBhY3RpdmUgaG9uYSB6YXJvb3JpIGhhaSB0YWJoaSBtb250aGx5IOKCuTEsNTAwIGRpcmVjdCBhYXllZ2EuJ1xuICB9LFxuICB7XG4gICAgaWQ6ICdwb2xpY2VfZXhhbScsXG4gICAgbmFtZTogJ1NTQyBHRCAvIFBvbGljZSBCaGFydGkgT25saW5lIEFwcGxpY2F0aW9uJyxcbiAgICBjYXRlZ29yeTogJ1JlY3J1aXRtZW50IEZvcm1zJyxcbiAgICBpY29uOiAn8J+RricsXG4gICAgdGltZUVzdGltYXRlOiAnMTAtMTIgTWludXRlcycsXG4gICAgc3VnZ2VzdGVkUmF0ZTogJ+KCuTEyMCAtIOKCuTE1MCcsXG4gICAgdGFyZ2V0U3R1ZGlvOiAncG9ydGFscycsXG4gICAgc3RlcHM6IFtcbiAgICAgIHtcbiAgICAgICAgdGl0bGU6ICdTdGVwIDE6IENoZWNrIEFnZSwgRG9taWNpbGUgJiBFZHVjYXRpb24gQ3JpdGVyaWEnLFxuICAgICAgICBhY3Rpb246ICdWZXJpZnkgMTB0aC8xMnRoIG1hcmtzaGVldCwgY2F0ZWdvcnkgY2FzdGUgY2VydGlmaWNhdGUsIGFuZCBub24tY3JlYW15IGxheWVyIGNlcnRpZmljYXRlLidcbiAgICAgIH0sXG4gICAgICB7XG4gICAgICAgIHRpdGxlOiAnU3RlcCAyOiBQcmVwYXJlIEZvcm0tU3BlY2lmaWNhdGlvbiBQaG90byAmIFNpZ25hdHVyZScsXG4gICAgICAgIGFjdGlvbjogJ0dlbmVyYXRlIHBhc3Nwb3J0IHBob3RvIHdpdGggY2FuZGlkYXRlIG5hbWUgJiBwaG90byBkYXRlIGluIFBhc3Nwb3J0IFN0dWRpbzsgcmVzaXplIHNpZ25hdHVyZSB1bmRlciAyMEtCLicsXG4gICAgICAgIHN0dWRpb0FjdGlvbjogeyBsYWJlbDogJ09wZW4gUGFzc3BvcnQgU3R1ZGlvJywgdGFiOiAncGFzc3BvcnRfc3R1ZGlvJyB9XG4gICAgICB9LFxuICAgICAge1xuICAgICAgICB0aXRsZTogJ1N0ZXAgMzogT25saW5lIEZvcm0gRW50cnkgJiBGZWUgUGF5bWVudCcsXG4gICAgICAgIGFjdGlvbjogJ0ZpbGwgcmVnaXN0cmF0aW9uLCByZXZpZXcgcHJldmlldyB3aXRoIGFwcGxpY2FudCwgcGF5IG9mZmljaWFsIGV4YW0gZmVlIHZpYSBVUEkvTmV0YmFua2luZy4nLFxuICAgICAgICBzdHVkaW9BY3Rpb246IHsgbGFiZWw6ICdPcGVuIFJlY3J1aXRtZW50IFBvcnRhbHMnLCB0YWI6ICdwb3J0YWxzJyB9XG4gICAgICB9LFxuICAgICAge1xuICAgICAgICB0aXRsZTogJ1N0ZXAgNDogUHJpbnQgQ29uZmlybWF0aW9uIFBhZ2UgJiBTbGlwJyxcbiAgICAgICAgYWN0aW9uOiAnUHJpbnQgY29sb3IgY29uZmlybWF0aW9uIHNsaXAsIGlzc3VlIHJlY2VpcHQgd2l0aCByZWdpc3RyYXRpb24gbnVtYmVyLCBhbmQgc2F2ZSBpbiBDUk0uJ1xuICAgICAgfVxuICAgIF0sXG4gICAgZG9jc1JlcXVpcmVkOiBbJzEwdGggTWFya3NoZWV0JywgJ0Nhc3RlICYgTm9uLUNyZWFteSBMYXllciBDZXJ0aWZpY2F0ZScsICdQYXNzcG9ydCBQaG90byB3aXRoIERhdGUnLCAnU2lnbmF0dXJlJ10sXG4gICAgb3BlcmF0b3JUaXBzOiAnRm9ybSBzdWJtaXQga2FybmUgc2UgcGVobGUgY2FuZGlkYXRlIGtlIHNhbW5lIHByZXZpZXcgY2hlY2sga2Fyd2F5ZWluIHRhYWtpIGtvaSBzcGVsbGluZyBtaXN0YWtlIG5hIGhvLidcbiAgfSxcbiAge1xuICAgIGlkOiAnYmlvZGF0YScsXG4gICAgbmFtZTogJ01hcnJpYWdlIEJpb0RhdGEgJiBQcm9mZXNzaW9uYWwgQ1YgUmVzdW1lJyxcbiAgICBjYXRlZ29yeTogJ0RvY3VtZW50IENyZWF0aW9uJyxcbiAgICBpY29uOiAn8J+ThCcsXG4gICAgdGltZUVzdGltYXRlOiAnNi04IE1pbnV0ZXMnLFxuICAgIHN1Z2dlc3RlZFJhdGU6ICfigrk3MCAtIOKCuTEwMCcsXG4gICAgdGFyZ2V0U3R1ZGlvOiAnYmlvZGF0YV9tYWtlcicsXG4gICAgc3RlcHM6IFtcbiAgICAgIHtcbiAgICAgICAgdGl0bGU6ICdTdGVwIDE6IFNlbGVjdCBUZW1wbGF0ZScsXG4gICAgICAgIGFjdGlvbjogJ0Nob29zZSBmcm9tIE1vZGVybiBQcm9mZXNzaW9uYWwgQ1YsIEhpbmRpIFRyYWRpdGlvbmFsIEJpb0RhdGEsIG9yIElzbGFtaWMgTWFycmlhZ2UgQmlvRGF0YS4nLFxuICAgICAgICBzdHVkaW9BY3Rpb246IHsgbGFiZWw6ICdPcGVuIEJpb0RhdGEgTWFrZXInLCB0YWI6ICdiaW9kYXRhX21ha2VyJyB9XG4gICAgICB9LFxuICAgICAge1xuICAgICAgICB0aXRsZTogJ1N0ZXAgMjogRW50ZXIgQXBwbGljYW50IERldGFpbHMnLFxuICAgICAgICBhY3Rpb246ICdGaWxsIHBlcnNvbmFsIGluZm8sIHF1YWxpZmljYXRpb24sIGpvYiBkZXNpZ25hdGlvbiwgZmFtaWx5IGJhY2tncm91bmQsIGFuZCBjb250YWN0IGRldGFpbHMuJ1xuICAgICAgfSxcbiAgICAgIHtcbiAgICAgICAgdGl0bGU6ICdTdGVwIDM6IFVwbG9hZCBTdHVkaW8gUG9ydHJhaXQnLFxuICAgICAgICBhY3Rpb246ICdBdHRhY2ggaGlnaC1yZXNvbHV0aW9uIHBhc3Nwb3J0L3BvcnRyYWl0IHBob3RvLidcbiAgICAgIH0sXG4gICAgICB7XG4gICAgICAgIHRpdGxlOiAnU3RlcCA0OiBEaXJlY3QgUHJpbnQgLyBQREYgRXhwb3J0JyxcbiAgICAgICAgYWN0aW9uOiAnRG93bmxvYWQgMzAwIERQSSBBNCBQREYgYW5kIHByaW50IHBoeXNpY2FsIGNvcHkgb24gaGVhdnkgMTAwIEdTTSBib25kIHBhcGVyLidcbiAgICAgIH1cbiAgICBdLFxuICAgIGRvY3NSZXF1aXJlZDogWydBcHBsaWNhbnQgRGV0YWlscyAmIERPQicsICdRdWFsaWZpY2F0aW9uICYgRXhwZXJpZW5jZSBEZXRhaWxzJywgJ0ZhbWlseSBEZXRhaWxzJywgJ1Bob3RvJ10sXG4gICAgb3BlcmF0b3JUaXBzOiAnQmlvRGF0YSBoYW1lc2hhIDEwMCBHU00gd2hpdGUgYm9uZCBwYXBlciBwYXIgcHJpbnQga2FyZWluIHRhYWtpIHByZXNlbnRhdGlvbiBwcm9mZXNzaW9uYWwgbGFnZS4nXG4gIH1cbl07XG5cbmV4cG9ydCBjb25zdCBXb3JrZmxvd0d1aWRlVmlldzogUmVhY3QuRkM8V29ya2Zsb3dHdWlkZVZpZXdQcm9wcz4gPSAoeyBvbk5hdmlnYXRlIH0pID0+IHtcbiAgY29uc3QgW3NlbGVjdGVkQmx1ZXByaW50LCBzZXRTZWxlY3RlZEJsdWVwcmludF0gPSB1c2VTdGF0ZTxzdHJpbmc+KCdwdmNfY2FyZCcpO1xuICBjb25zdCBbY29tcGxldGVkU3RlcHMsIHNldENvbXBsZXRlZFN0ZXBzXSA9IHVzZVN0YXRlPFJlY29yZDxzdHJpbmcsIGJvb2xlYW4+Pih7fSk7XG5cbiAgLy8gRGFpbHkgQ291bnRlciBTdGF0ZVxuICBjb25zdCBbdG9kYXlDYXJkcywgc2V0VG9kYXlDYXJkc10gPSB1c2VTdGF0ZTxudW1iZXI+KDE0KTtcbiAgY29uc3QgW3RvZGF5UGhvdG9zLCBzZXRUb2RheVBob3Rvc10gPSB1c2VTdGF0ZTxudW1iZXI+KDgpO1xuICBjb25zdCBbdG9kYXlGb3Jtcywgc2V0VG9kYXlGb3Jtc10gPSB1c2VTdGF0ZTxudW1iZXI+KDYpO1xuXG4gIGNvbnN0IGFjdGl2ZUJsdWVwcmludCA9IFNFUlZJQ0VfQkxVRVBSSU5UUy5maW5kKGIgPT4gYi5pZCA9PT0gc2VsZWN0ZWRCbHVlcHJpbnQpIHx8IFNFUlZJQ0VfQkxVRVBSSU5UU1swXTtcblxuICBjb25zdCB0b2dnbGVTdGVwID0gKHN0ZXBLZXk6IHN0cmluZykgPT4ge1xuICAgIHNldENvbXBsZXRlZFN0ZXBzKHByZXYgPT4gKHtcbiAgICAgIC4uLnByZXYsXG4gICAgICBbc3RlcEtleV06ICFwcmV2W3N0ZXBLZXldXG4gICAgfSkpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZUxhdW5jaFN0dWRpbyA9ICh0YWI6IHN0cmluZykgPT4ge1xuICAgIGlmIChvbk5hdmlnYXRlKSB7XG4gICAgICBvbk5hdmlnYXRlKHRhYik7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IGVzdGltYXRlZFRvZGF5VHVybm92ZXIgPSB0b2RheUNhcmRzICogNzAgKyB0b2RheVBob3RvcyAqIDUwICsgdG9kYXlGb3JtcyAqIDEwMDtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XG4gICAgICB7LyogVG9wIEJhbm5lciAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHAtNSByb3VuZGVkLTJ4bCBzaGFkb3ctbWQgZmxleCBmbGV4LWNvbCBsZzpmbGV4LXJvdyBsZzppdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC00XCI+XG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBmbGV4LXdyYXBcIj5cbiAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtZXh0cmFib2xkIHRleHQtd2hpdGUgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgPFNoaWVsZENoZWNrIGNsYXNzTmFtZT1cInctNiBoLTYgdGV4dC1lbWVyYWxkLTQwMFwiIC8+XG4gICAgICAgICAgICAgIDxzcGFuPkN5YmVyIENhZmUgU09QICYgRGFpbHkgV29ya2Zsb3cgRW5naW5lPC9zcGFuPlxuICAgICAgICAgICAgPC9oMT5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJnLWVtZXJhbGQtNTAwLzIwIHRleHQtZW1lcmFsZC0zMDAgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTUwMC8zMCB0ZXh0LXhzIHB4LTIuNSBweS0wLjUgcm91bmRlZC1mdWxsIGZvbnQtbW9ubyBmb250LWJvbGRcIj5cbiAgICAgICAgICAgICAgdjk4LjAgT3BlcmF0aW9uYWwgU3RhbmRhcmRcbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwIG10LTFcIj5cbiAgICAgICAgICAgIEVuZC10by1lbmQgc2VydmljZSBibHVlcHJpbnRzIOKAoiBDdXN0b21lciBpbnRha2UgdG8gMzAwIERQSSBwcmludGluZyDigKIgUmF0ZXMsIGNoZWNrbGlzdHMgJiAxLWNsaWNrIHN0dWRpbyBsYXVuY2hlcnNcbiAgICAgICAgICA8L3A+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBEYWlseSBQcm9kdWN0aW9uIFN1bW1hcnkgQmFyICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBwLTIuNSByb3VuZGVkLXhsIHRleHQteHMgZmxleC13cmFwXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTIgYm9yZGVyLXIgYm9yZGVyLXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDBcIj5DYXJkczo8L3NwYW4+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1vbm8gdGV4dC1ibHVlLTQwMCBmb250LWJvbGRcIj57dG9kYXlDYXJkc308L3NwYW4+XG4gICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IHNldFRvZGF5Q2FyZHMoYyA9PiBjICsgMSl9IGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGJnLXNsYXRlLTgwMCBob3ZlcjpiZy1zbGF0ZS03MDAgcHgtMSByb3VuZGVkIHRleHQtd2hpdGVcIj4rPC9idXR0b24+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTIgYm9yZGVyLXIgYm9yZGVyLXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDBcIj5QaG90b3M6PC9zcGFuPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vIHRleHQtcHVycGxlLTQwMCBmb250LWJvbGRcIj57dG9kYXlQaG90b3N9PC9zcGFuPlxuICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXRUb2RheVBob3RvcyhwID0+IHAgKyAxKX0gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gYmctc2xhdGUtODAwIGhvdmVyOmJnLXNsYXRlLTcwMCBweC0xIHJvdW5kZWQgdGV4dC13aGl0ZVwiPis8L2J1dHRvbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtMiBib3JkZXItciBib3JkZXItc2xhdGUtODAwXCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMFwiPkZvcm1zOjwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ubyB0ZXh0LWVtZXJhbGQtNDAwIGZvbnQtYm9sZFwiPnt0b2RheUZvcm1zfTwvc3Bhbj5cbiAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gc2V0VG9kYXlGb3JtcyhmID0+IGYgKyAxKX0gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gYmctc2xhdGUtODAwIGhvdmVyOmJnLXNsYXRlLTcwMCBweC0xIHJvdW5kZWQgdGV4dC13aGl0ZVwiPis8L2J1dHRvbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xIHRleHQtYW1iZXItMzAwIGZvbnQtYm9sZCBmb250LW1vbm8gcGwtMVwiPlxuICAgICAgICAgICAgPHNwYW4+RXN0OiDigrl7ZXN0aW1hdGVkVG9kYXlUdXJub3Zlci50b0xvY2FsZVN0cmluZygnZW4tSU4nKX08L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBTRVJWSUNFIEJMVUVQUklOVCBTRUxFQ1RPUiBUQUJTICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBvdmVyZmxvdy14LWF1dG8gcGItMVwiPlxuICAgICAgICB7U0VSVklDRV9CTFVFUFJJTlRTLm1hcCgoYnApID0+IHtcbiAgICAgICAgICBjb25zdCBpc1NlbGVjdGVkID0gc2VsZWN0ZWRCbHVlcHJpbnQgPT09IGJwLmlkO1xuICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIGtleT17YnAuaWR9XG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNlbGVjdGVkQmx1ZXByaW50KGJwLmlkKX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcHgtNCBweS0yLjUgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtYm9sZCBib3JkZXIgdHJhbnNpdGlvbi1hbGwgd2hpdGVzcGFjZS1ub3dyYXAgZmxleC1zaHJpbmstMCAke1xuICAgICAgICAgICAgICAgIGlzU2VsZWN0ZWRcbiAgICAgICAgICAgICAgICAgID8gJ2JnLWdyYWRpZW50LXRvLXIgZnJvbS1ibHVlLTYwMCB0by1pbmRpZ28tNjAwIHRleHQtd2hpdGUgYm9yZGVyLWJsdWUtNDAwIHNoYWRvdy1sZyBzaGFkb3ctYmx1ZS02MDAvMzAgc2NhbGUtMTAyJ1xuICAgICAgICAgICAgICAgICAgOiAnYmctc2xhdGUtOTAwIGJvcmRlci1zbGF0ZS04MDAgdGV4dC1zbGF0ZS0zMDAgaG92ZXI6Ymctc2xhdGUtODAwJ1xuICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1iYXNlXCI+e2JwLmljb259PC9zcGFuPlxuICAgICAgICAgICAgICA8c3Bhbj57YnAubmFtZX08L3NwYW4+XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICApO1xuICAgICAgICB9KX1cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogU0VMRUNURUQgQkxVRVBSSU5UIERFVEFJTCBWSUVXICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIGxnOmdyaWQtY29scy0xMiBnYXAtNCBpdGVtcy1zdGFydFwiPlxuICAgICAgICB7LyogTGVmdDogU3RlcC1ieS1TdGVwIEV4ZWN1dGlvbiBQbGFuICg4IGNvbHMpICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxnOmNvbC1zcGFuLTggYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtMnhsIHAtNSBzaGFkb3cteGwgc3BhY2UteS00XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IHNtOml0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTMgcGItMyBib3JkZXItYiBib3JkZXItc2xhdGUtODAwXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtM3hsXCI+e2FjdGl2ZUJsdWVwcmludC5pY29ufTwvc3Bhbj5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtZXh0cmFib2xkIHRleHQtd2hpdGVcIj57YWN0aXZlQmx1ZXByaW50Lm5hbWV9PC9oMj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIHRleHQteHMgdGV4dC1zbGF0ZS00MDAgbXQtMC41XCI+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSB0ZXh0LXNreS00MDAgZm9udC1tZWRpdW1cIj5cbiAgICAgICAgICAgICAgICAgICAgPENsb2NrIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+RXN0LiBUaW1lOiB7YWN0aXZlQmx1ZXByaW50LnRpbWVFc3RpbWF0ZX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8c3Bhbj7igKI8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSB0ZXh0LWVtZXJhbGQtNDAwIGZvbnQtYm9sZCBmb250LW1vbm9cIj5cbiAgICAgICAgICAgICAgICAgICAgPERvbGxhclNpZ24gY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj5TdGFuZGFyZCBSYXRlOiB7YWN0aXZlQmx1ZXByaW50LnN1Z2dlc3RlZFJhdGV9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogUXVpY2sgMS1DbGljayBMYXVuY2ggQnV0dG9uICovfVxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVMYXVuY2hTdHVkaW8oYWN0aXZlQmx1ZXByaW50LnRhcmdldFN0dWRpbyl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGJnLWdyYWRpZW50LXRvLXIgZnJvbS1lbWVyYWxkLTYwMCB0by10ZWFsLTYwMCBob3Zlcjpmcm9tLWVtZXJhbGQtNTAwIGhvdmVyOnRvLXRlYWwtNTAwIHRleHQtd2hpdGUgZm9udC1leHRyYWJvbGQgdGV4dC14cyBweC00IHB5LTIgcm91bmRlZC14bCBzaGFkb3ctbGcgc2hhZG93LWVtZXJhbGQtNjAwLzIwIHRyYW5zaXRpb24tYWxsIGhvdmVyOnNjYWxlLTEwNSBzZWxmLXN0YXJ0IHNtOnNlbGYtYXV0b1wiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxaYXAgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgIDxzcGFuPkxhdW5jaCBTdHVkaW8gZm9yIHRoaXMgU2VydmljZTwvc3Bhbj5cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIFN0ZXBzIExpc3QgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cbiAgICAgICAgICAgIHthY3RpdmVCbHVlcHJpbnQuc3RlcHMubWFwKChzdCwgaWR4KSA9PiB7XG4gICAgICAgICAgICAgIGNvbnN0IHN0ZXBLZXkgPSBgJHthY3RpdmVCbHVlcHJpbnQuaWR9LSR7aWR4fWA7XG4gICAgICAgICAgICAgIGNvbnN0IGlzRG9uZSA9ICEhY29tcGxldGVkU3RlcHNbc3RlcEtleV07XG5cbiAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICBrZXk9e2lkeH1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHAtNCByb3VuZGVkLXhsIGJvcmRlciB0cmFuc2l0aW9uLWFsbCBzcGFjZS15LTIgJHtcbiAgICAgICAgICAgICAgICAgICAgaXNEb25lIFxuICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLXNsYXRlLTk1MC80MCBib3JkZXItZW1lcmFsZC01MDAvNDAnIFxuICAgICAgICAgICAgICAgICAgICAgIDogJ2JnLXNsYXRlLTk1MCBib3JkZXItc2xhdGUtODAwLzgwIGhvdmVyOmJvcmRlci1zbGF0ZS03MDAnXG4gICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2B3LTYgaC02IHJvdW5kZWQtbGcgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZm9udC1tb25vIGZvbnQtYm9sZCB0ZXh0LXhzICR7XG4gICAgICAgICAgICAgICAgICAgICAgICBpc0RvbmUgPyAnYmctZW1lcmFsZC01MDAgdGV4dC1zbGF0ZS05NTAnIDogJ2JnLWJsdWUtNjAwIHRleHQtd2hpdGUnXG4gICAgICAgICAgICAgICAgICAgICAgfWB9PlxuICAgICAgICAgICAgICAgICAgICAgICAge2lkeCArIDF9XG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LWV4dHJhYm9sZCB0ZXh0LXdoaXRlIHRleHQteHNcIj57c3QudGl0bGV9PC9oMz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgIHtzdC5zdHVkaW9BY3Rpb24gJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVMYXVuY2hTdHVkaW8oc3Quc3R1ZGlvQWN0aW9uIS50YWIpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSB0ZXh0LVsxMXB4XSBmb250LWJvbGQgcHgtMi41IHB5LTEgcm91bmRlZC1sZyBiZy1ibHVlLTYwMC8yMCB0ZXh0LWJsdWUtMzAwIGJvcmRlciBib3JkZXItYmx1ZS01MDAvMzAgaG92ZXI6YmctYmx1ZS02MDAvMzAgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8UGxheSBjbGFzc05hbWU9XCJ3LTMgaC0zXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3N0LnN0dWRpb0FjdGlvbi5sYWJlbH08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdG9nZ2xlU3RlcChzdGVwS2V5KX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXggaXRlbXMtY2VudGVyIGdhcC0xIHRleHQtWzExcHhdIGZvbnQtYm9sZCBweC0yLjUgcHktMSByb3VuZGVkLWxnIGJvcmRlciB0cmFuc2l0aW9uLWFsbCAke1xuICAgICAgICAgICAgICAgICAgICAgICAgICBpc0RvbmUgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctZW1lcmFsZC01MDAvMjAgdGV4dC1lbWVyYWxkLTMwMCBib3JkZXItZW1lcmFsZC01MDAvMzAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnYmctc2xhdGUtOTAwIHRleHQtc2xhdGUtNDAwIGJvcmRlci1zbGF0ZS03MDAgaG92ZXI6dGV4dC13aGl0ZSdcbiAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtpc0RvbmUgPyA8Q2hlY2tDaXJjbGUyIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtZW1lcmFsZC00MDBcIiAvPiA6IDxDaXJjbGUgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPn1cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPntpc0RvbmUgPyAnQ29tcGxldGVkJyA6ICdNYXJrIERvbmUnfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTMwMCBsZWFkaW5nLXJlbGF4ZWQgcGwtOFwiPlxuICAgICAgICAgICAgICAgICAgICB7c3QuYWN0aW9ufVxuICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgfSl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBSaWdodDogUHJlcmVxdWlzaXRlIERvY3VtZW50cyAmIFBybyBPcGVyYXRvciBUaXBzICg0IGNvbHMpICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxnOmNvbC1zcGFuLTQgc3BhY2UteS00XCI+XG4gICAgICAgICAgey8qIFJlcXVpcmVkIERvY3VtZW50cyBDYXJkICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtMnhsIHAtNCBzaGFkb3ctbWQgc3BhY2UteS0zXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQteHMgZm9udC1ib2xkIHRleHQtd2hpdGUgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XG4gICAgICAgICAgICAgIDxGaWxlQ2hlY2sgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWVtZXJhbGQtNDAwXCIgLz5cbiAgICAgICAgICAgICAgPHNwYW4+Q3VzdG9tZXIgRG9jdW1lbnRzIENoZWNrbGlzdDwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMiB0ZXh0LXhzIHRleHQtc2xhdGUtMzAwXCI+XG4gICAgICAgICAgICAgIHthY3RpdmVCbHVlcHJpbnQuZG9jc1JlcXVpcmVkLm1hcCgoZG9jLCBpKSA9PiAoXG4gICAgICAgICAgICAgICAgPGRpdiBrZXk9e2l9IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQgZ2FwLTIgYmctc2xhdGUtOTUwIHAtMi41IHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDBcIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZW1lcmFsZC00MDAgZm9udC1ib2xkXCI+4pyTPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4+e2RvY308L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogUHJvIE9wZXJhdG9yIFRpcCBDYXJkICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JhZGllbnQtdG8tYnIgZnJvbS1hbWJlci05NTAvMjAgdmlhLXNsYXRlLTkwMCB0by1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1hbWJlci01MDAvMzAgcm91bmRlZC0yeGwgcC00IHNoYWRvdy1tZCBzcGFjZS15LTIgdGV4dC14c1wiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LWFtYmVyLTMwMCBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XG4gICAgICAgICAgICAgIDxTcGFya2xlcyBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtYW1iZXItNDAwXCIgLz5cbiAgICAgICAgICAgICAgPHNwYW4+T3BlcmF0b3IgR29sZGVuIFJ1bGU8L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtMzAwIGxlYWRpbmctcmVsYXhlZFwiPlxuICAgICAgICAgICAgICB7YWN0aXZlQmx1ZXByaW50Lm9wZXJhdG9yVGlwc31cbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBRdWljayBTdHVkaW8gSnVtcCBEZWNrICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtMnhsIHAtNCBzaGFkb3ctbWQgc3BhY2UteS0yLjVcIj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtMzAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBibG9ja1wiPlxuICAgICAgICAgICAgICBRdWljayBXb3Jrc3RhdGlvbiBMYXVuY2hlcnNcbiAgICAgICAgICAgIDwvc3Bhbj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC0yIHRleHQteHNcIj5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZUxhdW5jaFN0dWRpbygncHZjX3N0dWRpbycpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMi41IHJvdW5kZWQteGwgYmctc2xhdGUtOTUwIGhvdmVyOmJnLWJsdWUtOTUwLzMwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGhvdmVyOmJvcmRlci1ibHVlLTUwMC80MCB0ZXh0LWxlZnQgdHJhbnNpdGlvbi1hbGwgZ3JvdXBcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC13aGl0ZSBncm91cC1ob3Zlcjp0ZXh0LWJsdWUtNDAwXCI+UFZDIFN0dWRpbzwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS00MDBcIj4zMDAgRFBJIENhcmRzPC9kaXY+XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVMYXVuY2hTdHVkaW8oJ3Bhc3Nwb3J0X3N0dWRpbycpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMi41IHJvdW5kZWQteGwgYmctc2xhdGUtOTUwIGhvdmVyOmJnLXB1cnBsZS05NTAvMzAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgaG92ZXI6Ym9yZGVyLXB1cnBsZS01MDAvNDAgdGV4dC1sZWZ0IHRyYW5zaXRpb24tYWxsIGdyb3VwXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtd2hpdGUgZ3JvdXAtaG92ZXI6dGV4dC1wdXJwbGUtNDAwXCI+UGFzc3BvcnQgU3R1ZGlvPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTQwMFwiPjTDlzYgJiBBNCBTaGVldDwvZGl2PlxuICAgICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlTGF1bmNoU3R1ZGlvKCdiaWxsaW5nJyl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0yLjUgcm91bmRlZC14bCBiZy1zbGF0ZS05NTAgaG92ZXI6YmctZW1lcmFsZC05NTAvMzAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgaG92ZXI6Ym9yZGVyLWVtZXJhbGQtNTAwLzQwIHRleHQtbGVmdCB0cmFuc2l0aW9uLWFsbCBncm91cFwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXdoaXRlIGdyb3VwLWhvdmVyOnRleHQtZW1lcmFsZC00MDBcIj5GYXN0IFBPUyBCaWxsaW5nPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTQwMFwiPlRoZXJtYWwgU2xpcHM8L2Rpdj5cbiAgICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZUxhdW5jaFN0dWRpbygncG9ydGFscycpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMi41IHJvdW5kZWQteGwgYmctc2xhdGUtOTUwIGhvdmVyOmJnLXNreS05NTAvMzAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgaG92ZXI6Ym9yZGVyLXNreS01MDAvNDAgdGV4dC1sZWZ0IHRyYW5zaXRpb24tYWxsIGdyb3VwXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtd2hpdGUgZ3JvdXAtaG92ZXI6dGV4dC1za3ktNDAwXCI+NTArIFBvcnRhbHMgSHViPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTQwMFwiPkdvdnQgU2NoZW1lczwvZGl2PlxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufTtcbiJdfQ==