const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=1d04f0f2";
import { CreditCard, Camera, Receipt, Maximize2, Minimize2, Search, Command, User, Clock, Sparkles, HelpCircle, Sliders, Laptop, Lock } from "/node_modules/.vite/deps/lucide-react.js?v=1d04f0f2";
import { usePWAInstall } from "/src/hooks/usePWAInstall.ts";
var _jsxFileName = "/app/applet/src/components/Header.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=1d04f0f2";
export const Header = ({ settings, user, onNavigate, onOpenLogin, onOpenShortcuts, onLogout, searchQuery, onSearchChange, isSidebarCollapsed, onToggleSidebar }) => {
	const [timeStr, setTimeStr] = useState("");
	const [dateStr, setDateStr] = useState("");
	const [isFullscreen, setIsFullscreen] = useState(false);
	const { isInstallable, install } = usePWAInstall();
	useEffect(() => {
		const updateTime = () => {
			const now = new Date();
			setTimeStr(now.toLocaleTimeString("en-IN", {
				hour: "2-digit",
				minute: "2-digit",
				second: "2-digit",
				hour12: true
			}));
			setDateStr(now.toLocaleDateString("en-IN", {
				weekday: "short",
				day: "numeric",
				month: "short",
				year: "numeric"
			}));
		};
		updateTime();
		const interval = setInterval(updateTime, 1e3);
		return () => clearInterval(interval);
	}, []);
	const toggleFullscreen = () => {
		if (!document.fullscreenElement) {
			document.documentElement.requestFullscreen().catch(() => {});
			setIsFullscreen(true);
		} else {
			if (document.exitFullscreen) {
				document.exitFullscreen().catch(() => {});
				setIsFullscreen(false);
			}
		}
	};
	return /* @__PURE__ */ _jsxDEV("header", {
		className: "h-16 bg-slate-900 border-b border-slate-800 px-4 flex items-center justify-between gap-3 select-none flex-shrink-0 z-30 shadow-md no-print",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ _jsxDEV("button", {
					onClick: onToggleSidebar,
					title: isSidebarCollapsed ? "Expand Sidebar" : "Collapse Sidebar",
					className: "p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors",
					children: /* @__PURE__ */ _jsxDEV(Sliders, { className: "w-5 h-5 rotate-90" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 86,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 81,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2.5 cursor-pointer",
					onClick: () => onNavigate("dashboard"),
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-sky-400 flex items-center justify-center shadow-lg shadow-blue-500/20 overflow-hidden border border-blue-400/30",
						children: [/* @__PURE__ */ _jsxDEV("img", {
							src: "/muzammil_app_icon.png",
							alt: "Logo",
							className: "w-full h-full object-cover",
							onError: (e) => {
								// Fallback icon if image not available
								e.target.style.display = "none";
							}
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 91,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "text-white font-black text-lg",
							children: "M"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 100,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 90,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "hidden sm:block leading-tight",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-1.5",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "font-extrabold text-base tracking-tight text-white",
								children: settings.shopName
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 104,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "text-[10px] font-bold uppercase tracking-wider bg-blue-500/20 text-blue-400 px-1.5 py-0.5 rounded border border-blue-500/30",
								children: "PC Suite"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 105,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 103,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-slate-400 truncate max-w-[220px]",
							children: settings.tagline
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 109,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 102,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 89,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 80,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex-1 max-w-xl mx-2 hidden md:block",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "relative group",
					children: [
						/* @__PURE__ */ _jsxDEV(Search, { className: "w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 group-focus-within:text-blue-400 transition-colors" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 117,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("input", {
							id: "pc-global-search",
							type: "text",
							placeholder: "Search 50+ Govt Portals, PVC Card, Passport, Bills... (Press / or Ctrl+K)",
							value: searchQuery,
							onChange: (e) => onSearchChange(e.target.value),
							className: "w-full bg-slate-950/80 border border-slate-700/80 group-focus-within:border-blue-500 text-sm rounded-xl pl-9 pr-12 py-2 text-slate-200 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500/20 transition-all shadow-inner"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 118,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "absolute right-2.5 top-1/2 -translate-y-1/2 flex items-center gap-1 text-[11px] text-slate-400 bg-slate-800/80 px-1.5 py-0.5 rounded border border-slate-700/60 font-mono",
							children: [/* @__PURE__ */ _jsxDEV(Command, { className: "w-3 h-3" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 127,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "K" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 128,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 126,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 116,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 115,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center gap-2",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "hidden lg:flex items-center gap-1.5",
						children: [
							/* @__PURE__ */ _jsxDEV("button", {
								onClick: () => onNavigate("billing"),
								className: "flex items-center gap-1.5 bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-400 border border-emerald-500/30 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors",
								title: "Fast Billing Desk (Ctrl + B)",
								children: [/* @__PURE__ */ _jsxDEV(Receipt, { className: "w-3.5 h-3.5" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 142,
									columnNumber: 13
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "+ Bill" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 143,
									columnNumber: 13
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 137,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								onClick: () => onNavigate("pvc_studio"),
								className: "flex items-center gap-1.5 bg-blue-600/20 hover:bg-blue-600/30 text-blue-400 border border-blue-500/30 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors",
								title: "PVC 4x6 Card Creator",
								children: [/* @__PURE__ */ _jsxDEV(CreditCard, { className: "w-3.5 h-3.5" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 151,
									columnNumber: 13
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "PVC 4×6" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 152,
									columnNumber: 13
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 146,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								onClick: () => onNavigate("passport_studio"),
								className: "flex items-center gap-1.5 bg-purple-600/20 hover:bg-purple-600/30 text-purple-400 border border-purple-500/30 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors",
								title: "Passport Photo Studio",
								children: [/* @__PURE__ */ _jsxDEV(Camera, { className: "w-3.5 h-3.5" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 160,
									columnNumber: 13
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Passport 8" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 161,
									columnNumber: 13
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 155,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								onClick: () => onNavigate("ai_assistant"),
								className: "flex items-center gap-1.5 bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors",
								title: "AI Government Scheme Assistant",
								children: [/* @__PURE__ */ _jsxDEV(Sparkles, { className: "w-3.5 h-3.5 text-amber-400" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 169,
									columnNumber: 13
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "AI Guide" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 170,
									columnNumber: 13
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 164,
								columnNumber: 11
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 136,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "hidden xl:flex flex-col items-end px-3 py-1 bg-slate-950/60 rounded-lg border border-slate-800 font-mono",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-1 text-xs font-semibold text-slate-200",
							children: [/* @__PURE__ */ _jsxDEV(Clock, { className: "w-3 h-3 text-blue-400 animate-pulse" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 177,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: timeStr }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 178,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 176,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "text-[10px] text-slate-500",
							children: dateStr
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 180,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 175,
						columnNumber: 9
					}, this),
					isInstallable && /* @__PURE__ */ _jsxDEV("button", {
						onClick: install,
						className: "flex items-center gap-1.5 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-bold text-xs px-3 py-1.5 rounded-lg shadow-md transition-all hover:scale-105",
						title: "Install Muzammil PC Suite on your Computer",
						children: [/* @__PURE__ */ _jsxDEV(Laptop, { className: "w-3.5 h-3.5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 190,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "hidden sm:inline",
							children: "Install PC App"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 191,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 185,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						onClick: onOpenShortcuts,
						title: "Keyboard Shortcuts (?)",
						className: "p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors",
						children: /* @__PURE__ */ _jsxDEV(HelpCircle, { className: "w-4 h-4" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 201,
							columnNumber: 11
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 196,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						onClick: toggleFullscreen,
						title: isFullscreen ? "Exit Fullscreen (Esc)" : "Fullscreen PC Mode (F11)",
						className: "p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors",
						children: isFullscreen ? /* @__PURE__ */ _jsxDEV(Minimize2, { className: "w-4 h-4" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 210,
							columnNumber: 27
						}, this) : /* @__PURE__ */ _jsxDEV(Maximize2, { className: "w-4 h-4" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 210,
							columnNumber: 63
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 205,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-1.5 pl-2 border-l border-slate-800",
						children: [/* @__PURE__ */ _jsxDEV("button", {
							onClick: onOpenLogin,
							className: "flex items-center gap-2 hover:bg-slate-800 p-1.5 rounded-xl transition-colors text-left",
							title: "Switch Operator Profile",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500 to-indigo-700 flex items-center justify-center text-white font-bold text-xs shadow-md",
								children: /* @__PURE__ */ _jsxDEV(User, { className: "w-4 h-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 221,
									columnNumber: 15
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 220,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "hidden 2xl:block leading-none",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "text-xs font-bold text-white truncate max-w-[120px]",
									children: user.displayName || user.username
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 224,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "text-[10px] text-emerald-400 font-mono mt-0.5 flex items-center gap-1",
									children: [/* @__PURE__ */ _jsxDEV("span", { className: "w-1.5 h-1.5 rounded-full bg-emerald-500 inline-block animate-pulse" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 226,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: user.role.toUpperCase() }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 227,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 225,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 223,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 215,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							onClick: onLogout,
							title: "Lock PC Station & Logout",
							className: "p-2 text-rose-400 hover:text-rose-200 hover:bg-rose-500/10 rounded-lg transition-colors",
							children: /* @__PURE__ */ _jsxDEV(Lock, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 237,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 232,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 214,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 134,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 78,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsaUJBQWlCO0FBQzNDLFNBQ0UsWUFDQSxRQUNBLFNBQ0EsV0FDQSxXQUNBLFFBQ0EsU0FDQSxNQUNBLE9BQ0EsVUFDQSxZQUVBLFNBQ0EsUUFDQSxZQUNLO0FBRVAsU0FBUyxxQkFBcUI7OztBQWdCOUIsT0FBTyxNQUFNLFVBQWlDLEVBQzVDLFVBQ0EsTUFDQSxZQUNBLGFBQ0EsaUJBQ0EsVUFDQSxhQUNBLGdCQUNBLG9CQUNBLHNCQUNJO0NBQ0osTUFBTSxDQUFDLFNBQVMsY0FBYyxTQUFTLEVBQUU7Q0FDekMsTUFBTSxDQUFDLFNBQVMsY0FBYyxTQUFTLEVBQUU7Q0FDekMsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQVMsS0FBSztDQUV0RCxNQUFNLEVBQUUsZUFBZSxZQUFZLGNBQWM7Q0FFakQsZ0JBQWdCO0VBQ2QsTUFBTSxtQkFBbUI7R0FDdkIsTUFBTSxNQUFNLElBQUksS0FBSztHQUNyQixXQUFXLElBQUksbUJBQW1CLFNBQVM7SUFBRSxNQUFNO0lBQVcsUUFBUTtJQUFXLFFBQVE7SUFBVyxRQUFRO0dBQUssQ0FBQyxDQUFDO0dBQ25ILFdBQVcsSUFBSSxtQkFBbUIsU0FBUztJQUFFLFNBQVM7SUFBUyxLQUFLO0lBQVcsT0FBTztJQUFTLE1BQU07R0FBVSxDQUFDLENBQUM7RUFDbkg7RUFDQSxXQUFXO0VBQ1gsTUFBTSxXQUFXLFlBQVksWUFBWSxHQUFJO0VBQzdDLGFBQWEsY0FBYyxRQUFRO0NBQ3JDLEdBQUcsQ0FBQyxDQUFDO0NBRUwsTUFBTSx5QkFBeUI7RUFDN0IsSUFBSSxDQUFDLFNBQVMsbUJBQW1CO0dBQy9CLFNBQVMsZ0JBQWdCLGtCQUFrQixDQUFDLENBQUMsWUFBWSxDQUFDLENBQUM7R0FDM0QsZ0JBQWdCLElBQUk7RUFDdEIsT0FBTztHQUNMLElBQUksU0FBUyxnQkFBZ0I7SUFDM0IsU0FBUyxlQUFlLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQztJQUN4QyxnQkFBZ0IsS0FBSztHQUN2QjtFQUNGO0NBQ0Y7Q0FFQSxPQUNFLHdCQUFDLFVBQUQ7RUFBUSxXQUFVO1lBQWxCO0dBRUUsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLFVBQUQ7S0FDRSxTQUFTO0tBQ1QsT0FBTyxxQkFBcUIsbUJBQW1CO0tBQy9DLFdBQVU7ZUFFVix3QkFBQyxTQUFELEVBQVMsV0FBVSxvQkFBcUI7Ozs7O0lBQ2xDOzs7O2NBRVIsd0JBQUMsT0FBRDtLQUFLLFdBQVU7S0FBMkMsZUFBZSxXQUFXLFdBQVc7ZUFBL0YsQ0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQ7T0FDRSxLQUFJO09BQ0osS0FBSTtPQUNKLFdBQVU7T0FDVixVQUFVLE1BQU07O1FBRWQsQUFBQyxFQUFFLE9BQXVCLE1BQU0sVUFBVTtPQUM1QztNQUNEOzs7O2dCQUNELHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFnQztNQUFPOzs7O2NBQ3BEOzs7OztlQUNMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBc0QsU0FBUztPQUFlOzs7O2lCQUM5Rix3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBOEg7T0FFeEk7Ozs7ZUFDSDs7Ozs7Z0JBQ0wsd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQWlELFNBQVM7TUFBVzs7OztjQUMvRTs7Ozs7YUFDRjs7Ozs7WUFDRjs7Ozs7O0dBR0wsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FDYix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQ0Usd0JBQUMsUUFBRCxFQUFRLFdBQVUscUhBQXNIOzs7OztNQUN4SSx3QkFBQyxTQUFEO09BQ0UsSUFBRztPQUNILE1BQUs7T0FDTCxhQUFZO09BQ1osT0FBTztPQUNQLFdBQVcsTUFBTSxlQUFlLEVBQUUsT0FBTyxLQUFLO09BQzlDLFdBQVU7TUFDWDs7Ozs7TUFDRCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFNBQUQsRUFBUyxXQUFVLFVBQVc7Ozs7aUJBQzlCLHdCQUFDLFFBQUQsWUFBTSxJQUFPOzs7O2VBQ1Y7Ozs7OztLQUNGOzs7Ozs7R0FDRjs7Ozs7R0FHTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmO0tBRUUsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FDRSx3QkFBQyxVQUFEO1FBQ0UsZUFBZSxXQUFXLFNBQVM7UUFDbkMsV0FBVTtRQUNWLE9BQU07a0JBSFIsQ0FLRSx3QkFBQyxTQUFELEVBQVMsV0FBVSxjQUFlOzs7O2tCQUNsQyx3QkFBQyxRQUFELFlBQU0sU0FBWTs7OztnQkFDWjs7Ozs7O09BRVIsd0JBQUMsVUFBRDtRQUNFLGVBQWUsV0FBVyxZQUFZO1FBQ3RDLFdBQVU7UUFDVixPQUFNO2tCQUhSLENBS0Usd0JBQUMsWUFBRCxFQUFZLFdBQVUsY0FBZTs7OztrQkFDckMsd0JBQUMsUUFBRCxZQUFNLFVBQWE7Ozs7Z0JBQ2I7Ozs7OztPQUVSLHdCQUFDLFVBQUQ7UUFDRSxlQUFlLFdBQVcsaUJBQWlCO1FBQzNDLFdBQVU7UUFDVixPQUFNO2tCQUhSLENBS0Usd0JBQUMsUUFBRCxFQUFRLFdBQVUsY0FBZTs7OztrQkFDakMsd0JBQUMsUUFBRCxZQUFNLGFBQWdCOzs7O2dCQUNoQjs7Ozs7O09BRVIsd0JBQUMsVUFBRDtRQUNFLGVBQWUsV0FBVyxjQUFjO1FBQ3hDLFdBQVU7UUFDVixPQUFNO2tCQUhSLENBS0Usd0JBQUMsVUFBRCxFQUFVLFdBQVUsNkJBQThCOzs7O2tCQUNsRCx3QkFBQyxRQUFELFlBQU0sV0FBYzs7OztnQkFDZDs7Ozs7O01BQ0w7Ozs7OztLQUdMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxPQUFELEVBQU8sV0FBVSxzQ0FBdUM7Ozs7aUJBQ3hELHdCQUFDLFFBQUQsWUFBTyxRQUFjOzs7O2VBQ2xCOzs7OztnQkFDTCx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBOEI7TUFBYzs7OztjQUN6RDs7Ozs7O0tBR0osaUJBQ0Msd0JBQUMsVUFBRDtNQUNFLFNBQVM7TUFDVCxXQUFVO01BQ1YsT0FBTTtnQkFIUixDQUtFLHdCQUFDLFFBQUQsRUFBUSxXQUFVLGNBQWU7Ozs7Z0JBQ2pDLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFtQjtNQUFvQjs7OztjQUNqRDs7Ozs7O0tBSVYsd0JBQUMsVUFBRDtNQUNFLFNBQVM7TUFDVCxPQUFNO01BQ04sV0FBVTtnQkFFVix3QkFBQyxZQUFELEVBQVksV0FBVSxVQUFXOzs7OztLQUMzQjs7Ozs7S0FHUix3QkFBQyxVQUFEO01BQ0UsU0FBUztNQUNULE9BQU8sZUFBZSwwQkFBMEI7TUFDaEQsV0FBVTtnQkFFVCxlQUFlLHdCQUFDLFdBQUQsRUFBVyxXQUFVLFVBQVc7Ozs7aUJBQUksd0JBQUMsV0FBRCxFQUFXLFdBQVUsVUFBVzs7Ozs7S0FDOUU7Ozs7O0tBR1Isd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxVQUFEO09BQ0UsU0FBUztPQUNULFdBQVU7T0FDVixPQUFNO2lCQUhSLENBS0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQ2Isd0JBQUMsTUFBRCxFQUFNLFdBQVUsVUFBVzs7Ozs7T0FDeEI7Ozs7aUJBQ0wsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBdUQsS0FBSyxlQUFlLEtBQUs7UUFBYzs7OztrQkFDN0csd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxRQUFELEVBQU0sV0FBVSxxRUFBMkU7Ozs7bUJBQzNGLHdCQUFDLFFBQUQsWUFBTyxLQUFLLEtBQUssWUFBWSxFQUFROzs7O2lCQUNsQzs7Ozs7Z0JBQ0Y7Ozs7O2VBQ0M7Ozs7O2dCQUVSLHdCQUFDLFVBQUQ7T0FDRSxTQUFTO09BQ1QsT0FBTTtPQUNOLFdBQVU7aUJBRVYsd0JBQUMsTUFBRCxFQUFNLFdBQVUsVUFBVzs7Ozs7TUFDckI7Ozs7Y0FDTDs7Ozs7O0lBQ0Y7Ozs7OztFQUNDOzs7Ozs7QUFFWiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJIZWFkZXIudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgXG4gIENyZWRpdENhcmQsIFxuICBDYW1lcmEsIFxuICBSZWNlaXB0LCBcbiAgTWF4aW1pemUyLCBcbiAgTWluaW1pemUyLCBcbiAgU2VhcmNoLCBcbiAgQ29tbWFuZCwgXG4gIFVzZXIsIFxuICBDbG9jaywgXG4gIFNwYXJrbGVzLCBcbiAgSGVscENpcmNsZSwgXG4gIExvZ091dCwgXG4gIFNsaWRlcnMsXG4gIExhcHRvcCxcbiAgTG9ja1xufSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuaW1wb3J0IHsgU2hvcFNldHRpbmdzLCBVc2VyQWNjb3VudCB9IGZyb20gJy4uL3R5cGVzJztcbmltcG9ydCB7IHVzZVBXQUluc3RhbGwgfSBmcm9tICcuLi9ob29rcy91c2VQV0FJbnN0YWxsJztcblxuaW50ZXJmYWNlIEhlYWRlclByb3BzIHtcbiAgc2V0dGluZ3M6IFNob3BTZXR0aW5ncztcbiAgdXNlcjogVXNlckFjY291bnQ7XG4gIGFjdGl2ZVRhYjogc3RyaW5nO1xuICBvbk5hdmlnYXRlOiAodGFiOiBzdHJpbmcpID0+IHZvaWQ7XG4gIG9uT3BlbkxvZ2luOiAoKSA9PiB2b2lkO1xuICBvbk9wZW5TaG9ydGN1dHM6ICgpID0+IHZvaWQ7XG4gIG9uTG9nb3V0OiAoKSA9PiB2b2lkO1xuICBzZWFyY2hRdWVyeTogc3RyaW5nO1xuICBvblNlYXJjaENoYW5nZTogKHE6IHN0cmluZykgPT4gdm9pZDtcbiAgaXNTaWRlYmFyQ29sbGFwc2VkOiBib29sZWFuO1xuICBvblRvZ2dsZVNpZGViYXI6ICgpID0+IHZvaWQ7XG59XG5cbmV4cG9ydCBjb25zdCBIZWFkZXI6IFJlYWN0LkZDPEhlYWRlclByb3BzPiA9ICh7XG4gIHNldHRpbmdzLFxuICB1c2VyLFxuICBvbk5hdmlnYXRlLFxuICBvbk9wZW5Mb2dpbixcbiAgb25PcGVuU2hvcnRjdXRzLFxuICBvbkxvZ291dCxcbiAgc2VhcmNoUXVlcnksXG4gIG9uU2VhcmNoQ2hhbmdlLFxuICBpc1NpZGViYXJDb2xsYXBzZWQsXG4gIG9uVG9nZ2xlU2lkZWJhclxufSkgPT4ge1xuICBjb25zdCBbdGltZVN0ciwgc2V0VGltZVN0cl0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtkYXRlU3RyLCBzZXREYXRlU3RyXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW2lzRnVsbHNjcmVlbiwgc2V0SXNGdWxsc2NyZWVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICBjb25zdCB7IGlzSW5zdGFsbGFibGUsIGluc3RhbGwgfSA9IHVzZVBXQUluc3RhbGwoKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IHVwZGF0ZVRpbWUgPSAoKSA9PiB7XG4gICAgICBjb25zdCBub3cgPSBuZXcgRGF0ZSgpO1xuICAgICAgc2V0VGltZVN0cihub3cudG9Mb2NhbGVUaW1lU3RyaW5nKCdlbi1JTicsIHsgaG91cjogJzItZGlnaXQnLCBtaW51dGU6ICcyLWRpZ2l0Jywgc2Vjb25kOiAnMi1kaWdpdCcsIGhvdXIxMjogdHJ1ZSB9KSk7XG4gICAgICBzZXREYXRlU3RyKG5vdy50b0xvY2FsZURhdGVTdHJpbmcoJ2VuLUlOJywgeyB3ZWVrZGF5OiAnc2hvcnQnLCBkYXk6ICdudW1lcmljJywgbW9udGg6ICdzaG9ydCcsIHllYXI6ICdudW1lcmljJyB9KSk7XG4gICAgfTtcbiAgICB1cGRhdGVUaW1lKCk7XG4gICAgY29uc3QgaW50ZXJ2YWwgPSBzZXRJbnRlcnZhbCh1cGRhdGVUaW1lLCAxMDAwKTtcbiAgICByZXR1cm4gKCkgPT4gY2xlYXJJbnRlcnZhbChpbnRlcnZhbCk7XG4gIH0sIFtdKTtcblxuICBjb25zdCB0b2dnbGVGdWxsc2NyZWVuID0gKCkgPT4ge1xuICAgIGlmICghZG9jdW1lbnQuZnVsbHNjcmVlbkVsZW1lbnQpIHtcbiAgICAgIGRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5yZXF1ZXN0RnVsbHNjcmVlbigpLmNhdGNoKCgpID0+IHt9KTtcbiAgICAgIHNldElzRnVsbHNjcmVlbih0cnVlKTtcbiAgICB9IGVsc2Uge1xuICAgICAgaWYgKGRvY3VtZW50LmV4aXRGdWxsc2NyZWVuKSB7XG4gICAgICAgIGRvY3VtZW50LmV4aXRGdWxsc2NyZWVuKCkuY2F0Y2goKCkgPT4ge30pO1xuICAgICAgICBzZXRJc0Z1bGxzY3JlZW4oZmFsc2UpO1xuICAgICAgfVxuICAgIH1cbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxoZWFkZXIgY2xhc3NOYW1lPVwiaC0xNiBiZy1zbGF0ZS05MDAgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMCBweC00IGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMyBzZWxlY3Qtbm9uZSBmbGV4LXNocmluay0wIHotMzAgc2hhZG93LW1kIG5vLXByaW50XCI+XG4gICAgICB7LyogTGVmdDogQnJhbmRpbmcgJiBUb2dnbGUgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgIDxidXR0b24gXG4gICAgICAgICAgb25DbGljaz17b25Ub2dnbGVTaWRlYmFyfVxuICAgICAgICAgIHRpdGxlPXtpc1NpZGViYXJDb2xsYXBzZWQgPyBcIkV4cGFuZCBTaWRlYmFyXCIgOiBcIkNvbGxhcHNlIFNpZGViYXJcIn1cbiAgICAgICAgICBjbGFzc05hbWU9XCJwLTIgdGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC13aGl0ZSBob3ZlcjpiZy1zbGF0ZS04MDAgcm91bmRlZC1sZyB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgID5cbiAgICAgICAgICA8U2xpZGVycyBjbGFzc05hbWU9XCJ3LTUgaC01IHJvdGF0ZS05MFwiIC8+XG4gICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIuNSBjdXJzb3ItcG9pbnRlclwiIG9uQ2xpY2s9eygpID0+IG9uTmF2aWdhdGUoJ2Rhc2hib2FyZCcpfT5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTAgaC0xMCByb3VuZGVkLXhsIGJnLWdyYWRpZW50LXRvLXRyIGZyb20tYmx1ZS02MDAgdmlhLWluZGlnby02MDAgdG8tc2t5LTQwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBzaGFkb3ctbGcgc2hhZG93LWJsdWUtNTAwLzIwIG92ZXJmbG93LWhpZGRlbiBib3JkZXIgYm9yZGVyLWJsdWUtNDAwLzMwXCI+XG4gICAgICAgICAgICA8aW1nIFxuICAgICAgICAgICAgICBzcmM9XCIvbXV6YW1taWxfYXBwX2ljb24ucG5nXCIgXG4gICAgICAgICAgICAgIGFsdD1cIkxvZ29cIiBcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtZnVsbCBvYmplY3QtY292ZXJcIlxuICAgICAgICAgICAgICBvbkVycm9yPXsoZSkgPT4ge1xuICAgICAgICAgICAgICAgIC8vIEZhbGxiYWNrIGljb24gaWYgaW1hZ2Ugbm90IGF2YWlsYWJsZVxuICAgICAgICAgICAgICAgIChlLnRhcmdldCBhcyBIVE1MRWxlbWVudCkuc3R5bGUuZGlzcGxheSA9ICdub25lJztcbiAgICAgICAgICAgICAgfX0gXG4gICAgICAgICAgICAvPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC13aGl0ZSBmb250LWJsYWNrIHRleHQtbGdcIj5NPC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGlkZGVuIHNtOmJsb2NrIGxlYWRpbmctdGlnaHRcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWV4dHJhYm9sZCB0ZXh0LWJhc2UgdHJhY2tpbmctdGlnaHQgdGV4dC13aGl0ZVwiPntzZXR0aW5ncy5zaG9wTmFtZX08L3NwYW4+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgYmctYmx1ZS01MDAvMjAgdGV4dC1ibHVlLTQwMCBweC0xLjUgcHktMC41IHJvdW5kZWQgYm9yZGVyIGJvcmRlci1ibHVlLTUwMC8zMFwiPlxuICAgICAgICAgICAgICAgIFBDIFN1aXRlXG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMCB0cnVuY2F0ZSBtYXgtdy1bMjIwcHhdXCI+e3NldHRpbmdzLnRhZ2xpbmV9PC9wPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogQ2VudGVyOiBHbG9iYWwgU2VhcmNoIEJhciBmb3IgUEMgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBtYXgtdy14bCBteC0yIGhpZGRlbiBtZDpibG9ja1wiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGdyb3VwXCI+XG4gICAgICAgICAgPFNlYXJjaCBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtc2xhdGUtNDAwIGFic29sdXRlIGxlZnQtMyB0b3AtMS8yIC10cmFuc2xhdGUteS0xLzIgZ3JvdXAtZm9jdXMtd2l0aGluOnRleHQtYmx1ZS00MDAgdHJhbnNpdGlvbi1jb2xvcnNcIiAvPlxuICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgaWQ9XCJwYy1nbG9iYWwtc2VhcmNoXCJcbiAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VhcmNoIDUwKyBHb3Z0IFBvcnRhbHMsIFBWQyBDYXJkLCBQYXNzcG9ydCwgQmlsbHMuLi4gKFByZXNzIC8gb3IgQ3RybCtLKVwiXG4gICAgICAgICAgICB2YWx1ZT17c2VhcmNoUXVlcnl9XG4gICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IG9uU2VhcmNoQ2hhbmdlKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05NTAvODAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAvODAgZ3JvdXAtZm9jdXMtd2l0aGluOmJvcmRlci1ibHVlLTUwMCB0ZXh0LXNtIHJvdW5kZWQteGwgcGwtOSBwci0xMiBweS0yIHRleHQtc2xhdGUtMjAwIHBsYWNlaG9sZGVyLXNsYXRlLTUwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctYmx1ZS01MDAvMjAgdHJhbnNpdGlvbi1hbGwgc2hhZG93LWlubmVyXCJcbiAgICAgICAgICAvPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgcmlnaHQtMi41IHRvcC0xLzIgLXRyYW5zbGF0ZS15LTEvMiBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSB0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTQwMCBiZy1zbGF0ZS04MDAvODAgcHgtMS41IHB5LTAuNSByb3VuZGVkIGJvcmRlciBib3JkZXItc2xhdGUtNzAwLzYwIGZvbnQtbW9ub1wiPlxuICAgICAgICAgICAgPENvbW1hbmQgY2xhc3NOYW1lPVwidy0zIGgtM1wiIC8+XG4gICAgICAgICAgICA8c3Bhbj5LPC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogUmlnaHQ6IFF1aWNrIEFjdGlvbiBCdXR0b25zICYgT3BlcmF0b3IgUHJvZmlsZSAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgey8qIFF1aWNrIFRvb2xzIGJ1dHRvbnMgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGlkZGVuIGxnOmZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvbk5hdmlnYXRlKCdiaWxsaW5nJyl9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IGJnLWVtZXJhbGQtNjAwLzIwIGhvdmVyOmJnLWVtZXJhbGQtNjAwLzMwIHRleHQtZW1lcmFsZC00MDAgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTUwMC8zMCBweC0zIHB5LTEuNSByb3VuZGVkLWxnIHRleHQteHMgZm9udC1zZW1pYm9sZCB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICB0aXRsZT1cIkZhc3QgQmlsbGluZyBEZXNrIChDdHJsICsgQilcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxSZWNlaXB0IGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cbiAgICAgICAgICAgIDxzcGFuPisgQmlsbDwvc3Bhbj5cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICBcbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvbk5hdmlnYXRlKCdwdmNfc3R1ZGlvJyl9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IGJnLWJsdWUtNjAwLzIwIGhvdmVyOmJnLWJsdWUtNjAwLzMwIHRleHQtYmx1ZS00MDAgYm9yZGVyIGJvcmRlci1ibHVlLTUwMC8zMCBweC0zIHB5LTEuNSByb3VuZGVkLWxnIHRleHQteHMgZm9udC1zZW1pYm9sZCB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICB0aXRsZT1cIlBWQyA0eDYgQ2FyZCBDcmVhdG9yXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8Q3JlZGl0Q2FyZCBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XG4gICAgICAgICAgICA8c3Bhbj5QVkMgNMOXNjwvc3Bhbj5cbiAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uTmF2aWdhdGUoJ3Bhc3Nwb3J0X3N0dWRpbycpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBiZy1wdXJwbGUtNjAwLzIwIGhvdmVyOmJnLXB1cnBsZS02MDAvMzAgdGV4dC1wdXJwbGUtNDAwIGJvcmRlciBib3JkZXItcHVycGxlLTUwMC8zMCBweC0zIHB5LTEuNSByb3VuZGVkLWxnIHRleHQteHMgZm9udC1zZW1pYm9sZCB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICB0aXRsZT1cIlBhc3Nwb3J0IFBob3RvIFN0dWRpb1wiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPENhbWVyYSBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XG4gICAgICAgICAgICA8c3Bhbj5QYXNzcG9ydCA4PC9zcGFuPlxuICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb25OYXZpZ2F0ZSgnYWlfYXNzaXN0YW50Jyl9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IGJnLWFtYmVyLTUwMC8xMCBob3ZlcjpiZy1hbWJlci01MDAvMjAgdGV4dC1hbWJlci0zMDAgYm9yZGVyIGJvcmRlci1hbWJlci01MDAvMzAgcHgtMyBweS0xLjUgcm91bmRlZC1sZyB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgICAgdGl0bGU9XCJBSSBHb3Zlcm5tZW50IFNjaGVtZSBBc3Npc3RhbnRcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxTcGFya2xlcyBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LWFtYmVyLTQwMFwiIC8+XG4gICAgICAgICAgICA8c3Bhbj5BSSBHdWlkZTwvc3Bhbj5cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIExpdmUgRGlnaXRhbCBDbG9jayBmb3IgY3liZXIgY2FmZSAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoaWRkZW4geGw6ZmxleCBmbGV4LWNvbCBpdGVtcy1lbmQgcHgtMyBweS0xIGJnLXNsYXRlLTk1MC82MCByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGZvbnQtbW9ub1wiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtMjAwXCI+XG4gICAgICAgICAgICA8Q2xvY2sgY2xhc3NOYW1lPVwidy0zIGgtMyB0ZXh0LWJsdWUtNDAwIGFuaW1hdGUtcHVsc2VcIiAvPlxuICAgICAgICAgICAgPHNwYW4+e3RpbWVTdHJ9PC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNTAwXCI+e2RhdGVTdHJ9PC9zcGFuPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogUFdBIEluc3RhbGwgRGVza3RvcCBBcHAgQnV0dG9uICovfVxuICAgICAgICB7aXNJbnN0YWxsYWJsZSAmJiAoXG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17aW5zdGFsbH1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgYmctZ3JhZGllbnQtdG8tciBmcm9tLWJsdWUtNjAwIHRvLWluZGlnby02MDAgaG92ZXI6ZnJvbS1ibHVlLTUwMCBob3Zlcjp0by1pbmRpZ28tNTAwIHRleHQtd2hpdGUgZm9udC1ib2xkIHRleHQteHMgcHgtMyBweS0xLjUgcm91bmRlZC1sZyBzaGFkb3ctbWQgdHJhbnNpdGlvbi1hbGwgaG92ZXI6c2NhbGUtMTA1XCJcbiAgICAgICAgICAgIHRpdGxlPVwiSW5zdGFsbCBNdXphbW1pbCBQQyBTdWl0ZSBvbiB5b3VyIENvbXB1dGVyXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8TGFwdG9wIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImhpZGRlbiBzbTppbmxpbmVcIj5JbnN0YWxsIFBDIEFwcDwvc3Bhbj5cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgKX1cblxuICAgICAgICB7LyogS2V5Ym9hcmQgc2hvcnRjdXRzIGhlbHBlciAqL31cbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIG9uQ2xpY2s9e29uT3BlblNob3J0Y3V0c31cbiAgICAgICAgICB0aXRsZT1cIktleWJvYXJkIFNob3J0Y3V0cyAoPylcIlxuICAgICAgICAgIGNsYXNzTmFtZT1cInAtMiB0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXdoaXRlIGhvdmVyOmJnLXNsYXRlLTgwMCByb3VuZGVkLWxnIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgPlxuICAgICAgICAgIDxIZWxwQ2lyY2xlIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICB7LyogRnVsbHNjcmVlbiBUb2dnbGUgKi99XG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICBvbkNsaWNrPXt0b2dnbGVGdWxsc2NyZWVufVxuICAgICAgICAgIHRpdGxlPXtpc0Z1bGxzY3JlZW4gPyBcIkV4aXQgRnVsbHNjcmVlbiAoRXNjKVwiIDogXCJGdWxsc2NyZWVuIFBDIE1vZGUgKEYxMSlcIn1cbiAgICAgICAgICBjbGFzc05hbWU9XCJwLTIgdGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC13aGl0ZSBob3ZlcjpiZy1zbGF0ZS04MDAgcm91bmRlZC1sZyB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgID5cbiAgICAgICAgICB7aXNGdWxsc2NyZWVuID8gPE1pbmltaXplMiBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz4gOiA8TWF4aW1pemUyIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPn1cbiAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgey8qIE9wZXJhdG9yIFByb2ZpbGUgQ2FyZCAmIFN0YXRpb24gTG9jayAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHBsLTIgYm9yZGVyLWwgYm9yZGVyLXNsYXRlLTgwMFwiPlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9e29uT3BlbkxvZ2lufVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgaG92ZXI6Ymctc2xhdGUtODAwIHAtMS41IHJvdW5kZWQteGwgdHJhbnNpdGlvbi1jb2xvcnMgdGV4dC1sZWZ0XCJcbiAgICAgICAgICAgIHRpdGxlPVwiU3dpdGNoIE9wZXJhdG9yIFByb2ZpbGVcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy04IGgtOCByb3VuZGVkLWxnIGJnLWdyYWRpZW50LXRvLWJyIGZyb20tYmx1ZS01MDAgdG8taW5kaWdvLTcwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0ZXh0LXdoaXRlIGZvbnQtYm9sZCB0ZXh0LXhzIHNoYWRvdy1tZFwiPlxuICAgICAgICAgICAgICA8VXNlciBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoaWRkZW4gMnhsOmJsb2NrIGxlYWRpbmctbm9uZVwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtd2hpdGUgdHJ1bmNhdGUgbWF4LXctWzEyMHB4XVwiPnt1c2VyLmRpc3BsYXlOYW1lIHx8IHVzZXIudXNlcm5hbWV9PC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1lbWVyYWxkLTQwMCBmb250LW1vbm8gbXQtMC41IGZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy0xLjUgaC0xLjUgcm91bmRlZC1mdWxsIGJnLWVtZXJhbGQtNTAwIGlubGluZS1ibG9jayBhbmltYXRlLXB1bHNlXCI+PC9zcGFuPlxuICAgICAgICAgICAgICAgIDxzcGFuPnt1c2VyLnJvbGUudG9VcHBlckNhc2UoKX08L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXtvbkxvZ291dH1cbiAgICAgICAgICAgIHRpdGxlPVwiTG9jayBQQyBTdGF0aW9uICYgTG9nb3V0XCJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMiB0ZXh0LXJvc2UtNDAwIGhvdmVyOnRleHQtcm9zZS0yMDAgaG92ZXI6Ymctcm9zZS01MDAvMTAgcm91bmRlZC1sZyB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPExvY2sgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9oZWFkZXI+XG4gICk7XG59O1xuIl19