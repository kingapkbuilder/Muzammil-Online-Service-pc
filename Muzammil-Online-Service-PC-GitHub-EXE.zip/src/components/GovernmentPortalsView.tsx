const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useRef = __vite__cjsImport0_react["useRef"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=1d04f0f2";
import { ExternalLink, Search, FileCheck, CheckCircle, Copy, Check, X, RefreshCw, Globe, Download, FileText, Printer, CreditCard, FolderDown, Columns } from "/node_modules/.vite/deps/lucide-react.js?v=1d04f0f2";
import { ALL_GOV_PORTALS, SERVICE_CATEGORIES } from "/src/data/portalData.ts";
var _jsxFileName = "/app/applet/src/components/GovernmentPortalsView.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=1d04f0f2";
export const GovernmentPortalsView = ({ onAddDownload, onNavigate }) => {
	const [activeCategory, setActiveCategory] = useState("all");
	const [search, setSearch] = useState("");
	const [selectedPortalForDocs, setSelectedPortalForDocs] = useState(null);
	const [copiedId, setCopiedId] = useState(null);
	// In-App Browser State
	const [activePortal, setActivePortal] = useState(null);
	const [browserUrl, setBrowserUrl] = useState("");
	const [iframeKey, setIframeKey] = useState(0);
	const [zoomLevel, setZoomLevel] = useState(100);
	const [isSplitScreen, setIsSplitScreen] = useState(true);
	const [useProxy, setUseProxy] = useState(false);
	// Quick Notes & In-App Document Grabber
	const [notesCustomerName, setNotesCustomerName] = useState("");
	const [notesAckToken, setNotesAckToken] = useState("");
	const [notesAadhaar, setNotesAadhaar] = useState("");
	const [downloadSuccessMsg, setDownloadSuccessMsg] = useState(null);
	const fileInputRef = useRef(null);
	const filteredPortals = ALL_GOV_PORTALS.filter((p) => {
		const matchesCategory = activeCategory === "all" || p.category === activeCategory;
		const matchesSearch = p.title.toLowerCase().includes(search.toLowerCase()) || p.description.toLowerCase().includes(search.toLowerCase());
		return matchesCategory && matchesSearch;
	});
	const handleCopyLink = (portal) => {
		navigator.clipboard.writeText(portal.url);
		setCopiedId(portal.id);
		setTimeout(() => setCopiedId(null), 2e3);
	};
	// Open Portal Inside the App
	const handleOpenInsideApp = (portal) => {
		setActivePortal(portal);
		setBrowserUrl(portal.url);
		setIframeKey((prev) => prev + 1);
		setUseProxy(false);
	};
	// Close In-App Browser
	const handleCloseBrowser = () => {
		setActivePortal(null);
		setBrowserUrl("");
	};
	// Refresh current portal iframe
	const handleReload = () => {
		setIframeKey((prev) => prev + 1);
	};
	// Handle in-app document grab / upload
	const handleInAppDownloadFile = (e) => {
		const file = e.target.files?.[0];
		if (!file) return;
		const fileExt = file.name.split(".").pop()?.toUpperCase() || "PDF";
		const isImage = file.type.startsWith("image/");
		const isPdf = file.type === "application/pdf" || file.name.endsWith(".pdf");
		const downloadItem = {
			id: `dl-${Date.now()}`,
			title: `${notesCustomerName ? notesCustomerName + " - " : ""}${activePortal?.title || "Portal Document"} (${notesAckToken || "Slip"})`,
			type: isPdf ? "PVC Card PDF" : "Converted JPG",
			size: `${(file.size / 1024).toFixed(1)} KB`,
			timestamp: new Date().toLocaleTimeString([], {
				hour: "2-digit",
				minute: "2-digit"
			}),
			dataUrl: URL.createObjectURL(file)
		};
		if (onAddDownload) {
			onAddDownload(downloadItem);
		}
		setDownloadSuccessMsg(`✅ Document saved to In-App Downloads Vault!`);
		setTimeout(() => setDownloadSuccessMsg(null), 4e3);
	};
	const getEffectiveIframeSrc = () => {
		if (!browserUrl) return "";
		if (useProxy) {
			return `/api/portal-proxy?url=${encodeURIComponent(browserUrl)}`;
		}
		return browserUrl;
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900 border border-slate-800 p-4 rounded-2xl shadow-md",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2 flex-wrap",
					children: [
						/* @__PURE__ */ _jsxDEV("h1", {
							className: "text-xl font-extrabold text-white flex items-center gap-2",
							children: [/* @__PURE__ */ _jsxDEV(Globe, { className: "w-5 h-5 text-sky-400" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 138,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Official Government Portals & In-App Web Browser" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 139,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 137,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("span", {
							className: "bg-sky-500/20 text-sky-400 border border-sky-500/30 text-xs px-2.5 py-0.5 rounded-full font-mono font-bold",
							children: [ALL_GOV_PORTALS.length, " Central & State Portals"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 141,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("span", {
							className: "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-xs px-2.5 py-0.5 rounded-full font-bold",
							children: "In-App Embedded Mode"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 144,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 136,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "text-xs text-slate-400 mt-1",
					children: "All 50+ official government websites open directly inside this workstation with built-in document download vault"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 148,
					columnNumber: 11
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 135,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "relative",
					children: [/* @__PURE__ */ _jsxDEV(Search, { className: "w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 155,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("input", {
						type: "text",
						placeholder: "Search portals (Aadhaar, PAN, Ladki Bahin)...",
						value: search,
						onChange: (e) => setSearch(e.target.value),
						className: "bg-slate-950 border border-slate-700 rounded-xl pl-8 pr-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-sky-500 w-full sm:w-72"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 156,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 154,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 134,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center gap-2 overflow-x-auto pb-1",
				children: SERVICE_CATEGORIES.map((cat) => /* @__PURE__ */ _jsxDEV("button", {
					onClick: () => setActiveCategory(cat.id),
					className: `px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap flex items-center gap-1.5 transition-all ${activeCategory === cat.id ? "bg-blue-600 text-white shadow-md shadow-blue-600/30" : "bg-slate-900 text-slate-400 hover:text-white border border-slate-800 hover:bg-slate-800"}`,
					children: [/* @__PURE__ */ _jsxDEV("span", { children: cat.icon }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 178,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: cat.label }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 179,
						columnNumber: 13
					}, this)]
				}, cat.id, true, {
					fileName: _jsxFileName,
					lineNumber: 169,
					columnNumber: 11
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 167,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4",
				children: filteredPortals.map((portal) => /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-2xl p-4 shadow-md transition-all duration-200 hover:-translate-y-0.5 flex flex-col justify-between",
					children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-start justify-between gap-3 mb-2",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2.5",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "w-10 h-10 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-center text-xl shadow-inner",
								children: portal.icon
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 194,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
								className: "font-bold text-sm text-white",
								children: portal.title
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 198,
								columnNumber: 21
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "text-[10px] font-mono text-slate-400 capitalize",
								children: [
									portal.portalType,
									" Portal • ",
									portal.category.replace("_", " ")
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 199,
								columnNumber: 21
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 197,
								columnNumber: 19
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 193,
							columnNumber: 17
						}, this), portal.popular && /* @__PURE__ */ _jsxDEV("span", {
							className: "text-[9px] font-bold uppercase tracking-wider bg-emerald-500/20 text-emerald-400 px-1.5 py-0.5 rounded border border-emerald-500/30",
							children: "High Demand"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 206,
							columnNumber: 19
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 192,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "text-xs text-slate-300 mt-2 leading-relaxed line-clamp-3",
						children: portal.description
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 212,
						columnNumber: 15
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 191,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "mt-4 pt-3 border-t border-slate-800 flex items-center justify-between text-xs",
						children: [/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setSelectedPortalForDocs(portal),
							className: "text-slate-400 hover:text-blue-400 font-medium flex items-center gap-1 text-[11px]",
							children: [/* @__PURE__ */ _jsxDEV(FileCheck, { className: "w-3.5 h-3.5 text-blue-400" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 222,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: [
								"Docs Needed (",
								portal.requiredDocs.length,
								")"
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 223,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 218,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-1.5",
							children: [/* @__PURE__ */ _jsxDEV("button", {
								onClick: () => handleCopyLink(portal),
								title: "Copy Direct Official Link",
								className: "p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white",
								children: copiedId === portal.id ? /* @__PURE__ */ _jsxDEV(Check, { className: "w-3.5 h-3.5 text-emerald-400" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 232,
									columnNumber: 45
								}, this) : /* @__PURE__ */ _jsxDEV(Copy, { className: "w-3.5 h-3.5" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 232,
									columnNumber: 98
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 227,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => handleOpenInsideApp(portal),
								className: "flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-extrabold text-xs shadow-md transition-all hover:scale-105",
								title: "Open this government portal inside the app",
								children: [/* @__PURE__ */ _jsxDEV(Globe, { className: "w-3 h-3 text-sky-200" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 241,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Open Inside App" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 242,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 236,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 226,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 217,
						columnNumber: 13
					}, this)]
				}, portal.id, true, {
					fileName: _jsxFileName,
					lineNumber: 187,
					columnNumber: 11
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 185,
				columnNumber: 7
			}, this),
			activePortal && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed inset-0 bg-black/90 backdrop-blur-md z-50 flex flex-col p-2 sm:p-4",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-slate-900 border border-slate-800 rounded-3xl flex-1 flex flex-col overflow-hidden shadow-2xl",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-slate-950 border-b border-slate-800 px-4 py-3 flex items-center justify-between gap-3 flex-wrap",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-xl",
									children: activePortal.icon
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 257,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
									className: "font-extrabold text-white text-xs leading-none flex items-center gap-1.5",
									children: [/* @__PURE__ */ _jsxDEV("span", { children: activePortal.title }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 260,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-[10px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded font-mono font-bold",
										children: "In-App Browser"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 261,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 259,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "text-[10px] text-slate-400 font-mono",
									children: [
										activePortal.portalType,
										" • ",
										activePortal.category
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 265,
									columnNumber: 19
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 258,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 256,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex-1 max-w-xl flex items-center bg-slate-900 border border-slate-700 rounded-xl px-3 py-1.5 gap-2 text-xs",
								children: [
									/* @__PURE__ */ _jsxDEV(Globe, { className: "w-3.5 h-3.5 text-blue-400 flex-shrink-0" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 271,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: browserUrl,
										onChange: (e) => setBrowserUrl(e.target.value),
										onKeyDown: (e) => e.key === "Enter" && handleReload(),
										className: "bg-transparent text-white font-mono text-[11px] w-full focus:outline-none truncate"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 272,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										onClick: handleReload,
										title: "Reload Portal",
										className: "text-slate-400 hover:text-white",
										children: /* @__PURE__ */ _jsxDEV(RefreshCw, { className: "w-3.5 h-3.5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 284,
											columnNumber: 19
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 279,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 270,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2",
								children: [
									/* @__PURE__ */ _jsxDEV("button", {
										onClick: () => {
											setUseProxy(!useProxy);
											handleReload();
										},
										className: `px-2.5 py-1.5 rounded-xl text-[11px] font-bold border transition-colors ${useProxy ? "bg-purple-600 text-white border-purple-400 shadow" : "bg-slate-900 text-slate-400 border-slate-800 hover:text-white"}`,
										title: "Toggle In-App Bypass Proxy for restricted portals",
										children: /* @__PURE__ */ _jsxDEV("span", { children: ["Proxy: ", useProxy ? "ON" : "OFF"] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 300,
											columnNumber: 19
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 291,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										onClick: () => setIsSplitScreen(!isSplitScreen),
										className: `p-2 rounded-xl border text-xs ${isSplitScreen ? "bg-blue-600 text-white border-blue-400" : "bg-slate-900 text-slate-400 border-slate-800 hover:text-white"}`,
										title: "Toggle Operator Split-Screen Workstation Desk",
										children: /* @__PURE__ */ _jsxDEV(Columns, { className: "w-3.5 h-3.5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 313,
											columnNumber: 19
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 304,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										onClick: handleCloseBrowser,
										className: "p-2 rounded-xl bg-slate-800 hover:bg-rose-600 text-slate-300 hover:text-white transition-colors",
										title: "Close Portal",
										children: /* @__PURE__ */ _jsxDEV(X, { className: "w-4 h-4" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 322,
											columnNumber: 19
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 317,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 289,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 255,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex-1 flex overflow-hidden",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: `h-full flex flex-col bg-white relative transition-all duration-200 ${isSplitScreen ? "w-full lg:w-8/12" : "w-full"}`,
							children: [/* @__PURE__ */ _jsxDEV("iframe", {
								src: getEffectiveIframeSrc(),
								title: activePortal.title,
								className: "w-full h-full border-none",
								style: {
									transform: `scale(${zoomLevel / 100})`,
									transformOrigin: "0 0"
								},
								sandbox: "allow-same-origin allow-scripts allow-forms allow-popups allow-downloads"
							}, iframeKey, false, {
								fileName: _jsxFileName,
								lineNumber: 333,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "absolute bottom-2 left-3 right-3 bg-slate-950/90 backdrop-blur-md border border-slate-800 p-2 rounded-xl text-[11px] text-slate-300 flex items-center justify-between gap-2 shadow-lg",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-1.5 truncate",
									children: [/* @__PURE__ */ _jsxDEV("span", { className: "w-2 h-2 rounded-full bg-emerald-400" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 345,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: ["Live Portal: ", /* @__PURE__ */ _jsxDEV("b", { children: activePortal.title }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 346,
										columnNumber: 40
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 346,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 344,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-2 flex-shrink-0",
									children: [/* @__PURE__ */ _jsxDEV("button", {
										onClick: () => setUseProxy(!useProxy),
										className: "text-xs text-sky-400 hover:underline font-bold",
										children: useProxy ? "Switch Direct" : "Bypass Frame Restriction"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 349,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("a", {
										href: browserUrl,
										target: "_blank",
										rel: "noopener noreferrer",
										className: "text-xs text-slate-400 hover:text-white flex items-center gap-0.5 font-bold",
										children: [/* @__PURE__ */ _jsxDEV("span", { children: "New Window" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 361,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV(ExternalLink, { className: "w-3 h-3" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 362,
											columnNumber: 23
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 355,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 348,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 343,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 330,
							columnNumber: 15
						}, this), isSplitScreen && /* @__PURE__ */ _jsxDEV("div", {
							className: "hidden lg:flex lg:w-4/12 h-full bg-slate-900 border-l border-slate-800 flex-col p-4 space-y-4 overflow-y-auto",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-1",
									children: [/* @__PURE__ */ _jsxDEV("h3", {
										className: "font-extrabold text-white text-xs uppercase tracking-wider flex items-center gap-2 text-emerald-400",
										children: [/* @__PURE__ */ _jsxDEV(FolderDown, { className: "w-4 h-4" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 373,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: "In-App Document Grabber & Downloads" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 374,
											columnNumber: 23
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 372,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "text-[11px] text-slate-400 leading-snug",
										children: "When citizen acknowledgement slip, e-Aadhaar, or PAN PDF is ready, grab it directly into the in-app vault."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 376,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 371,
									columnNumber: 19
								}, this),
								downloadSuccessMsg && /* @__PURE__ */ _jsxDEV("div", {
									className: "p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-bold flex items-center gap-2 animate-in fade-in",
									children: [/* @__PURE__ */ _jsxDEV(CheckCircle, { className: "w-4 h-4 flex-shrink-0" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 383,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: downloadSuccessMsg }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 384,
										columnNumber: 23
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 382,
									columnNumber: 21
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-2 text-xs bg-slate-950 p-3 rounded-xl border border-slate-800",
									children: [
										/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "text-[11px] text-slate-400 block mb-0.5",
											children: "Citizen Name"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 391,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											placeholder: "e.g. Rahul Sharma",
											value: notesCustomerName,
											onChange: (e) => setNotesCustomerName(e.target.value),
											className: "w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white font-bold"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 392,
											columnNumber: 23
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 390,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "text-[11px] text-slate-400 block mb-0.5",
											children: "Application Token / Ack No."
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 402,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											placeholder: "e.g. MH-LBY-2026-98124",
											value: notesAckToken,
											onChange: (e) => setNotesAckToken(e.target.value),
											className: "w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white font-mono"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 403,
											columnNumber: 23
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 401,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "text-[11px] text-slate-400 block mb-0.5",
											children: "Aadhaar / Mobile (Reference)"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 413,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											placeholder: "XXXX-XXXX-XXXX",
											value: notesAadhaar,
											onChange: (e) => setNotesAadhaar(e.target.value),
											className: "w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white font-mono"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 414,
											columnNumber: 23
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 412,
											columnNumber: 21
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 389,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-2",
									children: [
										/* @__PURE__ */ _jsxDEV("span", {
											className: "text-[11px] font-bold text-slate-300 block",
											children: "Save Portal File to In-App Vault:"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 426,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("input", {
											type: "file",
											ref: fileInputRef,
											onChange: handleInAppDownloadFile,
											accept: ".pdf,.jpg,.jpeg,.png",
											className: "hidden"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 429,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("button", {
											onClick: () => fileInputRef.current?.click(),
											className: "w-full py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-extrabold text-xs rounded-xl shadow-lg shadow-emerald-600/20 flex items-center justify-center gap-2 transition-all hover:scale-102",
											children: [/* @__PURE__ */ _jsxDEV(Download, { className: "w-4 h-4" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 440,
												columnNumber: 23
											}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Grab Slip / e-Card (In-App)" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 441,
												columnNumber: 23
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 436,
											columnNumber: 21
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 425,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-2 pt-2 border-t border-slate-800 text-xs",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-[11px] font-bold text-slate-400 uppercase tracking-wider block",
										children: "Transfer to Studio:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 447,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "grid grid-cols-2 gap-2",
										children: [
											/* @__PURE__ */ _jsxDEV("button", {
												onClick: () => {
													handleCloseBrowser();
													onNavigate?.("pvc_studio");
												},
												className: "p-2 rounded-xl bg-slate-950 border border-slate-800 hover:border-blue-500 text-left transition-colors",
												children: [/* @__PURE__ */ _jsxDEV("div", {
													className: "font-bold text-white text-[11px] flex items-center gap-1",
													children: [/* @__PURE__ */ _jsxDEV(CreditCard, { className: "w-3 h-3 text-blue-400" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 457,
														columnNumber: 27
													}, this), /* @__PURE__ */ _jsxDEV("span", { children: "PVC Studio" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 458,
														columnNumber: 27
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 456,
													columnNumber: 25
												}, this), /* @__PURE__ */ _jsxDEV("div", {
													className: "text-[10px] text-slate-400",
													children: "Card Maker"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 460,
													columnNumber: 25
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 452,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("button", {
												onClick: () => {
													handleCloseBrowser();
													onNavigate?.("pdf_to_jpg");
												},
												className: "p-2 rounded-xl bg-slate-950 border border-slate-800 hover:border-amber-500 text-left transition-colors",
												children: [/* @__PURE__ */ _jsxDEV("div", {
													className: "font-bold text-white text-[11px] flex items-center gap-1",
													children: [/* @__PURE__ */ _jsxDEV(FileText, { className: "w-3 h-3 text-amber-400" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 468,
														columnNumber: 27
													}, this), /* @__PURE__ */ _jsxDEV("span", { children: "PDF to JPG" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 469,
														columnNumber: 27
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 467,
													columnNumber: 25
												}, this), /* @__PURE__ */ _jsxDEV("div", {
													className: "text-[10px] text-slate-400",
													children: "Compressor"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 471,
													columnNumber: 25
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 463,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("button", {
												onClick: () => {
													handleCloseBrowser();
													onNavigate?.("billing");
												},
												className: "p-2 rounded-xl bg-slate-950 border border-slate-800 hover:border-emerald-500 text-left transition-colors",
												children: [/* @__PURE__ */ _jsxDEV("div", {
													className: "font-bold text-white text-[11px] flex items-center gap-1",
													children: [/* @__PURE__ */ _jsxDEV(Printer, { className: "w-3 h-3 text-emerald-400" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 479,
														columnNumber: 27
													}, this), /* @__PURE__ */ _jsxDEV("span", { children: "POS Billing" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 480,
														columnNumber: 27
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 478,
													columnNumber: 25
												}, this), /* @__PURE__ */ _jsxDEV("div", {
													className: "text-[10px] text-slate-400",
													children: "Thermal Slip"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 482,
													columnNumber: 25
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 474,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("button", {
												onClick: () => {
													handleCloseBrowser();
													onNavigate?.("downloads");
												},
												className: "p-2 rounded-xl bg-slate-950 border border-slate-800 hover:border-purple-500 text-left transition-colors",
												children: [/* @__PURE__ */ _jsxDEV("div", {
													className: "font-bold text-white text-[11px] flex items-center gap-1",
													children: [/* @__PURE__ */ _jsxDEV(FolderDown, { className: "w-3 h-3 text-purple-400" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 490,
														columnNumber: 27
													}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Downloads" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 491,
														columnNumber: 27
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 489,
													columnNumber: 25
												}, this), /* @__PURE__ */ _jsxDEV("div", {
													className: "text-[10px] text-slate-400",
													children: "Vault History"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 493,
													columnNumber: 25
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 485,
												columnNumber: 23
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 451,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 446,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-2 text-xs",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "font-bold text-white text-[11px] flex items-center gap-1.5",
										children: [/* @__PURE__ */ _jsxDEV(FileCheck, { className: "w-3.5 h-3.5 text-blue-400" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 501,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: [activePortal.title, " Checklist:"] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 502,
											columnNumber: 23
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 500,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "space-y-1",
										children: activePortal.requiredDocs.map((doc, idx) => /* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-start gap-1.5 text-[11px] text-slate-300",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "text-emerald-400 font-bold",
												children: "✓"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 507,
												columnNumber: 27
											}, this), /* @__PURE__ */ _jsxDEV("span", { children: doc }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 508,
												columnNumber: 27
											}, this)]
										}, idx, true, {
											fileName: _jsxFileName,
											lineNumber: 506,
											columnNumber: 25
										}, this))
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 504,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 499,
									columnNumber: 19
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 370,
							columnNumber: 17
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 328,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 253,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 252,
				columnNumber: 9
			}, this),
			selectedPortalForDocs && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed inset-0 bg-black/75 z-50 flex items-center justify-center p-4",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-slate-900 border border-slate-800 rounded-2xl max-w-lg w-full p-5 shadow-2xl space-y-4",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between border-b border-slate-800 pb-3",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-2xl",
									children: selectedPortalForDocs.icon
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 526,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
									className: "font-bold text-white text-base",
									children: selectedPortalForDocs.title
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 528,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs text-blue-400 font-medium",
									children: "Customer Documents Checklist"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 529,
									columnNumber: 19
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 527,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 525,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setSelectedPortalForDocs(null),
								className: "p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800",
								children: /* @__PURE__ */ _jsxDEV(X, { className: "w-5 h-5" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 536,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 532,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 524,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-2 text-xs",
							children: [/* @__PURE__ */ _jsxDEV("p", {
								className: "text-slate-300 leading-relaxed",
								children: [
									"Before applying for ",
									/* @__PURE__ */ _jsxDEV("b", { children: selectedPortalForDocs.title }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 542,
										columnNumber: 37
									}, this),
									", collect the following original documents from the citizen:"
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 541,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2.5",
								children: selectedPortalForDocs.requiredDocs.map((doc, idx) => /* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-start gap-2.5 text-slate-200",
									children: [/* @__PURE__ */ _jsxDEV(CheckCircle, { className: "w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 548,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "leading-snug",
										children: doc
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 549,
										columnNumber: 21
									}, this)]
								}, idx, true, {
									fileName: _jsxFileName,
									lineNumber: 547,
									columnNumber: 19
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 545,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 540,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-end gap-2 pt-2 border-t border-slate-800",
							children: /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => {
									const p = selectedPortalForDocs;
									setSelectedPortalForDocs(null);
									handleOpenInsideApp(p);
								},
								className: "px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl text-xs flex items-center gap-1.5",
								children: [/* @__PURE__ */ _jsxDEV(Globe, { className: "w-3.5 h-3.5" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 564,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Open Inside App" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 565,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 556,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 555,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 523,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 522,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 132,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsY0FBYztBQUN4QyxTQUVFLGNBQ0EsUUFDQSxXQUNBLGFBQ0EsTUFDQSxPQUVBLEdBR0EsV0FHQSxPQUNBLFVBQ0EsVUFDQSxTQUNBLFlBRUEsWUFNQSxlQUNLO0FBQ1AsU0FBUyxpQkFBaUIsMEJBQTBCOzs7QUFRcEQsT0FBTyxNQUFNLHlCQUErRCxFQUMxRSxlQUNBLGlCQUNJO0NBQ0osTUFBTSxDQUFDLGdCQUFnQixxQkFBcUIsU0FBaUIsS0FBSztDQUNsRSxNQUFNLENBQUMsUUFBUSxhQUFhLFNBQWlCLEVBQUU7Q0FDL0MsTUFBTSxDQUFDLHVCQUF1Qiw0QkFBNEIsU0FBNEIsSUFBSTtDQUMxRixNQUFNLENBQUMsVUFBVSxlQUFlLFNBQXdCLElBQUk7O0NBRzVELE1BQU0sQ0FBQyxjQUFjLG1CQUFtQixTQUE0QixJQUFJO0NBQ3hFLE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUFpQixFQUFFO0NBQ3ZELE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFpQixDQUFDO0NBQ3BELE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFpQixHQUFHO0NBQ3RELE1BQU0sQ0FBQyxlQUFlLG9CQUFvQixTQUFrQixJQUFJO0NBQ2hFLE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBa0IsS0FBSzs7Q0FHdkQsTUFBTSxDQUFDLG1CQUFtQix3QkFBd0IsU0FBaUIsRUFBRTtDQUNyRSxNQUFNLENBQUMsZUFBZSxvQkFBb0IsU0FBaUIsRUFBRTtDQUM3RCxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBaUIsRUFBRTtDQUMzRCxNQUFNLENBQUMsb0JBQW9CLHlCQUF5QixTQUF3QixJQUFJO0NBRWhGLE1BQU0sZUFBZSxPQUF5QixJQUFJO0NBRWxELE1BQU0sa0JBQWtCLGdCQUFnQixRQUFRLE1BQU07RUFDcEQsTUFBTSxrQkFBa0IsbUJBQW1CLFNBQVMsRUFBRSxhQUFhO0VBQ25FLE1BQU0sZ0JBQ0osRUFBRSxNQUFNLFlBQVksQ0FBQyxDQUFDLFNBQVMsT0FBTyxZQUFZLENBQUMsS0FDbkQsRUFBRSxZQUFZLFlBQVksQ0FBQyxDQUFDLFNBQVMsT0FBTyxZQUFZLENBQUM7RUFDM0QsT0FBTyxtQkFBbUI7Q0FDNUIsQ0FBQztDQUVELE1BQU0sa0JBQWtCLFdBQXVCO0VBQzdDLFVBQVUsVUFBVSxVQUFVLE9BQU8sR0FBRztFQUN4QyxZQUFZLE9BQU8sRUFBRTtFQUNyQixpQkFBaUIsWUFBWSxJQUFJLEdBQUcsR0FBSTtDQUMxQzs7Q0FHQSxNQUFNLHVCQUF1QixXQUF1QjtFQUNsRCxnQkFBZ0IsTUFBTTtFQUN0QixjQUFjLE9BQU8sR0FBRztFQUN4QixjQUFhLFNBQVEsT0FBTyxDQUFDO0VBQzdCLFlBQVksS0FBSztDQUNuQjs7Q0FHQSxNQUFNLDJCQUEyQjtFQUMvQixnQkFBZ0IsSUFBSTtFQUNwQixjQUFjLEVBQUU7Q0FDbEI7O0NBR0EsTUFBTSxxQkFBcUI7RUFDekIsY0FBYSxTQUFRLE9BQU8sQ0FBQztDQUMvQjs7Q0FHQSxNQUFNLDJCQUEyQixNQUEyQztFQUMxRSxNQUFNLE9BQU8sRUFBRSxPQUFPLFFBQVE7RUFDOUIsSUFBSSxDQUFDLE1BQU07RUFFWCxNQUFNLFVBQVUsS0FBSyxLQUFLLE1BQU0sR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsWUFBWSxLQUFLO0VBQzdELE1BQU0sVUFBVSxLQUFLLEtBQUssV0FBVyxRQUFRO0VBQzdDLE1BQU0sUUFBUSxLQUFLLFNBQVMscUJBQXFCLEtBQUssS0FBSyxTQUFTLE1BQU07RUFFMUUsTUFBTSxlQUE2QjtHQUNqQyxJQUFJLE1BQU0sS0FBSyxJQUFJO0dBQ25CLE9BQU8sR0FBRyxvQkFBb0Isb0JBQW9CLFFBQVEsS0FBSyxjQUFjLFNBQVMsa0JBQWtCLElBQUksaUJBQWlCLE9BQU87R0FDcEksTUFBTSxRQUFRLGlCQUFpQjtHQUMvQixNQUFNLElBQUksS0FBSyxPQUFPLEtBQUksQ0FBRSxRQUFRLENBQUMsRUFBRTtHQUN2QyxXQUFXLElBQUksS0FBSyxDQUFDLENBQUMsbUJBQW1CLENBQUMsR0FBRztJQUFFLE1BQU07SUFBVyxRQUFRO0dBQVUsQ0FBQztHQUNuRixTQUFTLElBQUksZ0JBQWdCLElBQUk7RUFDbkM7RUFFQSxJQUFJLGVBQWU7R0FDakIsY0FBYyxZQUFZO0VBQzVCO0VBRUEsc0JBQXNCLDZDQUE2QztFQUNuRSxpQkFBaUIsc0JBQXNCLElBQUksR0FBRyxHQUFJO0NBQ3BEO0NBRUEsTUFBTSw4QkFBOEI7RUFDbEMsSUFBSSxDQUFDLFlBQVksT0FBTztFQUN4QixJQUFJLFVBQVU7R0FDWixPQUFPLHlCQUF5QixtQkFBbUIsVUFBVTtFQUMvRDtFQUNBLE9BQU87Q0FDVDtDQUVBLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUVFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNFLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUFkLENBQ0Usd0JBQUMsT0FBRCxFQUFPLFdBQVUsdUJBQXdCOzs7O2lCQUN6Qyx3QkFBQyxRQUFELFlBQU0sbURBQXNEOzs7O2VBQzFEOzs7Ozs7TUFDSix3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBaEIsQ0FDRyxnQkFBZ0IsUUFBTywwQkFDcEI7Ozs7OztNQUNOLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUErRztNQUV6SDs7Ozs7S0FDSDs7Ozs7Y0FDTCx3QkFBQyxLQUFEO0tBQUcsV0FBVTtlQUE4QjtJQUV4Qzs7OztZQUNBOzs7O2NBR0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLFFBQUQsRUFBUSxXQUFVLHNFQUF1RTs7OztlQUN6Rix3QkFBQyxTQUFEO01BQ0UsTUFBSztNQUNMLGFBQVk7TUFDWixPQUFPO01BQ1AsV0FBVyxNQUFNLFVBQVUsRUFBRSxPQUFPLEtBQUs7TUFDekMsV0FBVTtLQUNYOzs7O2FBQ0U7Ozs7O1lBQ0Y7Ozs7OztHQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ1osbUJBQW1CLEtBQUssUUFDdkIsd0JBQUMsVUFBRDtLQUVFLGVBQWUsa0JBQWtCLElBQUksRUFBRTtLQUN2QyxXQUFXLHVHQUNULG1CQUFtQixJQUFJLEtBQ25CLHdEQUNBO2VBTlIsQ0FTRSx3QkFBQyxRQUFELFlBQU8sSUFBSSxLQUFXOzs7O2VBQ3RCLHdCQUFDLFFBQUQsWUFBTyxJQUFJLE1BQVk7Ozs7YUFDakI7T0FWRCxJQUFJOzs7O1dBVUgsQ0FDVDtHQUNFOzs7OztHQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ1osZ0JBQWdCLEtBQUssV0FDcEIsd0JBQUMsT0FBRDtLQUVFLFdBQVU7ZUFGWixDQUlFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQ1osT0FBTztPQUNMOzs7O2lCQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBZ0MsT0FBTztPQUFVOzs7O2lCQUMvRCx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBaEI7U0FDRyxPQUFPO1NBQVc7U0FBVyxPQUFPLFNBQVMsUUFBUSxLQUFLLEdBQUc7UUFDMUQ7Ozs7O2VBQ0g7Ozs7ZUFDRjs7Ozs7Z0JBRUosT0FBTyxXQUNOLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFzSTtNQUVoSjs7OztjQUVMOzs7OztlQUVMLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUNWLE9BQU87S0FDUDs7OzthQUNBOzs7O2VBRUwsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxVQUFEO09BQ0UsZUFBZSx5QkFBeUIsTUFBTTtPQUM5QyxXQUFVO2lCQUZaLENBSUUsd0JBQUMsV0FBRCxFQUFXLFdBQVUsNEJBQTZCOzs7O2lCQUNsRCx3QkFBQyxRQUFEO1FBQU07UUFBYyxPQUFPLGFBQWE7UUFBTztPQUFPOzs7O2VBQ2hEOzs7OztnQkFFUix3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFVBQUQ7UUFDRSxlQUFlLGVBQWUsTUFBTTtRQUNwQyxPQUFNO1FBQ04sV0FBVTtrQkFFVCxhQUFhLE9BQU8sS0FBSyx3QkFBQyxPQUFELEVBQU8sV0FBVSwrQkFBZ0M7Ozs7bUJBQUksd0JBQUMsTUFBRCxFQUFNLFdBQVUsY0FBZTs7Ozs7T0FDeEc7Ozs7aUJBR1Isd0JBQUMsVUFBRDtRQUNFLGVBQWUsb0JBQW9CLE1BQU07UUFDekMsV0FBVTtRQUNWLE9BQU07a0JBSFIsQ0FLRSx3QkFBQyxPQUFELEVBQU8sV0FBVSx1QkFBd0I7Ozs7a0JBQ3pDLHdCQUFDLFFBQUQsWUFBTSxrQkFBcUI7Ozs7Z0JBQ3JCOzs7OztlQUNMOzs7OztjQUNGOzs7OzthQUNGO09BMURFLE9BQU87Ozs7V0EwRFQsQ0FDTjtHQUNFOzs7OztHQUdKLGdCQUNDLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ2Isd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUVFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBVyxhQUFhO1FBQVc7Ozs7a0JBQ25ELHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBZCxDQUNFLHdCQUFDLFFBQUQsWUFBTyxhQUFhLE1BQVk7Ozs7bUJBQ2hDLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUF5RjtTQUVuRzs7OztpQkFDSjs7Ozs7a0JBQ0osd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQWhCO1VBQXdELGFBQWE7VUFBVztVQUFJLGFBQWE7U0FBZTs7Ozs7Z0JBQzdHOzs7O2dCQUNGOzs7Ozs7T0FHTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUNFLHdCQUFDLE9BQUQsRUFBTyxXQUFVLDBDQUEyQzs7Ozs7U0FDNUQsd0JBQUMsU0FBRDtVQUNFLE1BQUs7VUFDTCxPQUFPO1VBQ1AsV0FBVyxNQUFNLGNBQWMsRUFBRSxPQUFPLEtBQUs7VUFDN0MsWUFBWSxNQUFNLEVBQUUsUUFBUSxXQUFXLGFBQWE7VUFDcEQsV0FBVTtTQUNYOzs7OztTQUNELHdCQUFDLFVBQUQ7VUFDRSxTQUFTO1VBQ1QsT0FBTTtVQUNOLFdBQVU7b0JBRVYsd0JBQUMsV0FBRCxFQUFXLFdBQVUsY0FBZTs7Ozs7U0FDOUI7Ozs7O1FBQ0w7Ozs7OztPQUdMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBRUUsd0JBQUMsVUFBRDtVQUNFLGVBQWU7V0FBRSxZQUFZLENBQUMsUUFBUTtXQUFHLGFBQWE7VUFBRztVQUN6RCxXQUFXLDJFQUNULFdBQ0ksc0RBQ0E7VUFFTixPQUFNO29CQUVOLHdCQUFDLFFBQUQsYUFBTSxXQUFRLFdBQVcsT0FBTyxLQUFZOzs7OztTQUN0Qzs7Ozs7U0FHUix3QkFBQyxVQUFEO1VBQ0UsZUFBZSxpQkFBaUIsQ0FBQyxhQUFhO1VBQzlDLFdBQVcsaUNBQ1QsZ0JBQ0ksMkNBQ0E7VUFFTixPQUFNO29CQUVOLHdCQUFDLFNBQUQsRUFBUyxXQUFVLGNBQWU7Ozs7O1NBQzVCOzs7OztTQUdSLHdCQUFDLFVBQUQ7VUFDRSxTQUFTO1VBQ1QsV0FBVTtVQUNWLE9BQU07b0JBRU4sd0JBQUMsR0FBRCxFQUFHLFdBQVUsVUFBVzs7Ozs7U0FDbEI7Ozs7O1FBQ0w7Ozs7OztNQUNGOzs7OztlQUdMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBRUUsd0JBQUMsT0FBRDtPQUFLLFdBQVcsc0VBQ2QsZ0JBQWdCLHFCQUFxQjtpQkFEdkMsQ0FHRSx3QkFBQyxVQUFEO1FBRUUsS0FBSyxzQkFBc0I7UUFDM0IsT0FBTyxhQUFhO1FBQ3BCLFdBQVU7UUFDVixPQUFPO1NBQUUsV0FBVyxTQUFTLFlBQVksSUFBSTtTQUFJLGlCQUFpQjtRQUFNO1FBQ3hFLFNBQVE7T0FDVCxHQU5NOzs7O2NBTU4sR0FHRCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsUUFBRCxFQUFNLFdBQVUsc0NBQTRDOzs7O21CQUM1RCx3QkFBQyxRQUFELGFBQU0saUJBQWEsd0JBQUMsS0FBRCxZQUFJLGFBQWEsTUFBUzs7OztpQkFBTzs7OztpQkFDakQ7Ozs7O2tCQUNMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsVUFBRDtVQUNFLGVBQWUsWUFBWSxDQUFDLFFBQVE7VUFDcEMsV0FBVTtvQkFFVCxXQUFXLGtCQUFrQjtTQUN4Qjs7OzttQkFDUix3QkFBQyxLQUFEO1VBQ0UsTUFBTTtVQUNOLFFBQU87VUFDUCxLQUFJO1VBQ0osV0FBVTtvQkFKWixDQU1FLHdCQUFDLFFBQUQsWUFBTSxhQUFnQjs7OztvQkFDdEIsd0JBQUMsY0FBRCxFQUFjLFdBQVUsVUFBVzs7OztrQkFDbEM7Ozs7O2lCQUNBOzs7OztnQkFDRjs7Ozs7ZUFDRjs7Ozs7Z0JBR0osaUJBQ0Msd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUFkLENBQ0Usd0JBQUMsWUFBRCxFQUFZLFdBQVUsVUFBVzs7OztvQkFDakMsd0JBQUMsUUFBRCxZQUFNLHNDQUF5Qzs7OztrQkFDN0M7Ozs7O21CQUNKLHdCQUFDLEtBQUQ7VUFBRyxXQUFVO29CQUEwQztTQUVwRDs7OztpQkFDQTs7Ozs7O1FBRUosc0JBQ0Msd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxhQUFELEVBQWEsV0FBVSx3QkFBeUI7Ozs7bUJBQ2hELHdCQUFDLFFBQUQsWUFBTyxtQkFBeUI7Ozs7aUJBQzdCOzs7Ozs7UUFJUCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZjtVQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1dBQU8sV0FBVTtxQkFBMEM7VUFBbUI7Ozs7b0JBQzlFLHdCQUFDLFNBQUQ7V0FDRSxNQUFLO1dBQ0wsYUFBWTtXQUNaLE9BQU87V0FDUCxXQUFXLE1BQU0scUJBQXFCLEVBQUUsT0FBTyxLQUFLO1dBQ3BELFdBQVU7VUFDWDs7OztrQkFDRTs7Ozs7VUFFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtXQUFPLFdBQVU7cUJBQTBDO1VBQWtDOzs7O29CQUM3Rix3QkFBQyxTQUFEO1dBQ0UsTUFBSztXQUNMLGFBQVk7V0FDWixPQUFPO1dBQ1AsV0FBVyxNQUFNLGlCQUFpQixFQUFFLE9BQU8sS0FBSztXQUNoRCxXQUFVO1VBQ1g7Ozs7a0JBQ0U7Ozs7O1VBRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7V0FBTyxXQUFVO3FCQUEwQztVQUFtQzs7OztvQkFDOUYsd0JBQUMsU0FBRDtXQUNFLE1BQUs7V0FDTCxhQUFZO1dBQ1osT0FBTztXQUNQLFdBQVcsTUFBTSxnQkFBZ0IsRUFBRSxPQUFPLEtBQUs7V0FDL0MsV0FBVTtVQUNYOzs7O2tCQUNFOzs7OztTQUNGOzs7Ozs7UUFHTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZjtVQUNFLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUE2QztVQUV2RDs7Ozs7VUFDTix3QkFBQyxTQUFEO1dBQ0UsTUFBSztXQUNMLEtBQUs7V0FDTCxVQUFVO1dBQ1YsUUFBTztXQUNQLFdBQVU7VUFDWDs7Ozs7VUFDRCx3QkFBQyxVQUFEO1dBQ0UsZUFBZSxhQUFhLFNBQVMsTUFBTTtXQUMzQyxXQUFVO3FCQUZaLENBSUUsd0JBQUMsVUFBRCxFQUFVLFdBQVUsVUFBVzs7OztxQkFDL0Isd0JBQUMsUUFBRCxZQUFNLDhCQUFpQzs7OzttQkFDakM7Ozs7OztTQUNMOzs7Ozs7UUFHTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFzRTtTQUVoRjs7OzttQkFFTix3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZjtXQUNFLHdCQUFDLFVBQUQ7WUFDRSxlQUFlO2FBQUUsbUJBQW1CO2FBQUcsYUFBYSxZQUFZO1lBQUc7WUFDbkUsV0FBVTtzQkFGWixDQUlFLHdCQUFDLE9BQUQ7YUFBSyxXQUFVO3VCQUFmLENBQ0Usd0JBQUMsWUFBRCxFQUFZLFdBQVUsd0JBQXlCOzs7O3VCQUMvQyx3QkFBQyxRQUFELFlBQU0sYUFBZ0I7Ozs7cUJBQ25COzs7OztzQkFDTCx3QkFBQyxPQUFEO2FBQUssV0FBVTt1QkFBNkI7WUFBZTs7OztvQkFDckQ7Ozs7OztXQUVSLHdCQUFDLFVBQUQ7WUFDRSxlQUFlO2FBQUUsbUJBQW1CO2FBQUcsYUFBYSxZQUFZO1lBQUc7WUFDbkUsV0FBVTtzQkFGWixDQUlFLHdCQUFDLE9BQUQ7YUFBSyxXQUFVO3VCQUFmLENBQ0Usd0JBQUMsVUFBRCxFQUFVLFdBQVUseUJBQTBCOzs7O3VCQUM5Qyx3QkFBQyxRQUFELFlBQU0sYUFBZ0I7Ozs7cUJBQ25COzs7OztzQkFDTCx3QkFBQyxPQUFEO2FBQUssV0FBVTt1QkFBNkI7WUFBZTs7OztvQkFDckQ7Ozs7OztXQUVSLHdCQUFDLFVBQUQ7WUFDRSxlQUFlO2FBQUUsbUJBQW1CO2FBQUcsYUFBYSxTQUFTO1lBQUc7WUFDaEUsV0FBVTtzQkFGWixDQUlFLHdCQUFDLE9BQUQ7YUFBSyxXQUFVO3VCQUFmLENBQ0Usd0JBQUMsU0FBRCxFQUFTLFdBQVUsMkJBQTRCOzs7O3VCQUMvQyx3QkFBQyxRQUFELFlBQU0sY0FBaUI7Ozs7cUJBQ3BCOzs7OztzQkFDTCx3QkFBQyxPQUFEO2FBQUssV0FBVTt1QkFBNkI7WUFBaUI7Ozs7b0JBQ3ZEOzs7Ozs7V0FFUix3QkFBQyxVQUFEO1lBQ0UsZUFBZTthQUFFLG1CQUFtQjthQUFHLGFBQWEsV0FBVztZQUFHO1lBQ2xFLFdBQVU7c0JBRlosQ0FJRSx3QkFBQyxPQUFEO2FBQUssV0FBVTt1QkFBZixDQUNFLHdCQUFDLFlBQUQsRUFBWSxXQUFVLDBCQUEyQjs7Ozt1QkFDakQsd0JBQUMsUUFBRCxZQUFNLFlBQWU7Ozs7cUJBQ2xCOzs7OztzQkFDTCx3QkFBQyxPQUFEO2FBQUssV0FBVTt1QkFBNkI7WUFBa0I7Ozs7b0JBQ3hEOzs7Ozs7VUFDTDs7Ozs7aUJBQ0Y7Ozs7OztRQUdMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQWhCLENBQ0Usd0JBQUMsV0FBRCxFQUFXLFdBQVUsNEJBQTZCOzs7O29CQUNsRCx3QkFBQyxRQUFELGFBQU8sYUFBYSxPQUFNLGFBQWlCOzs7O2tCQUN2Qzs7Ozs7bUJBQ04sd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQ1osYUFBYSxhQUFhLEtBQUssS0FBSyxRQUNuQyx3QkFBQyxPQUFEO1dBQWUsV0FBVTtxQkFBekIsQ0FDRSx3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBNkI7V0FBTzs7OztxQkFDcEQsd0JBQUMsUUFBRCxZQUFPLElBQVU7Ozs7bUJBQ2Q7YUFISzs7OztpQkFHTCxDQUNOO1NBQ0U7Ozs7aUJBQ0Y7Ozs7OztPQUNGOzs7OztjQUVKOzs7OzthQUNGOzs7Ozs7R0FDRjs7Ozs7R0FJTix5QkFDQyx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNiLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQVksc0JBQXNCO1FBQVc7Ozs7a0JBQzdELHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBa0Msc0JBQXNCO1FBQVU7Ozs7a0JBQ2hGLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFvQztRQUFrQzs7OztnQkFDbkY7Ozs7Z0JBQ0Y7Ozs7O2lCQUNMLHdCQUFDLFVBQUQ7UUFDRSxlQUFlLHlCQUF5QixJQUFJO1FBQzVDLFdBQVU7a0JBRVYsd0JBQUMsR0FBRCxFQUFHLFdBQVUsVUFBVzs7Ozs7T0FDbEI7Ozs7ZUFDTDs7Ozs7O01BRUwsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBYjtTQUE4QztTQUN4Qix3QkFBQyxLQUFELFlBQUksc0JBQXNCLE1BQVM7Ozs7O1NBQUM7UUFDdkQ7Ozs7O2lCQUVILHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUNaLHNCQUFzQixhQUFhLEtBQUssS0FBSyxRQUM1Qyx3QkFBQyxPQUFEO1NBQWUsV0FBVTttQkFBekIsQ0FDRSx3QkFBQyxhQUFELEVBQWEsV0FBVSxnREFBaUQ7Ozs7bUJBQ3hFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFnQjtTQUFVOzs7O2lCQUN2QztXQUhLOzs7O2VBR0wsQ0FDTjtPQUNFOzs7O2VBQ0Y7Ozs7OztNQUVMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNiLHdCQUFDLFVBQUQ7UUFDRSxlQUFlO1NBQ2IsTUFBTSxJQUFJO1NBQ1YseUJBQXlCLElBQUk7U0FDN0Isb0JBQW9CLENBQUM7UUFDdkI7UUFDQSxXQUFVO2tCQU5aLENBUUUsd0JBQUMsT0FBRCxFQUFPLFdBQVUsY0FBZTs7OztrQkFDaEMsd0JBQUMsUUFBRCxZQUFNLGtCQUFxQjs7OztnQkFDckI7Ozs7OztNQUNMOzs7OztLQUNGOzs7Ozs7R0FDRjs7Ozs7RUFFSjs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiR292ZXJubWVudFBvcnRhbHNWaWV3LnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUsIHVzZVJlZiB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IFxuICBMYW5kbWFyaywgXG4gIEV4dGVybmFsTGluaywgXG4gIFNlYXJjaCwgXG4gIEZpbGVDaGVjaywgXG4gIENoZWNrQ2lyY2xlLCBcbiAgQ29weSwgXG4gIENoZWNrLCBcbiAgSGVscENpcmNsZSxcbiAgWCxcbiAgTWF4aW1pemUyLFxuICBNaW5pbWl6ZTIsXG4gIFJlZnJlc2hDdyxcbiAgQXJyb3dMZWZ0LFxuICBBcnJvd1JpZ2h0LFxuICBHbG9iZSxcbiAgRG93bmxvYWQsXG4gIEZpbGVUZXh0LFxuICBQcmludGVyLFxuICBDcmVkaXRDYXJkLFxuICBDYW1lcmEsXG4gIEZvbGRlckRvd24sXG4gIExheWVycyxcbiAgU3BhcmtsZXMsXG4gIFphcCxcbiAgWm9vbUluLFxuICBab29tT3V0LFxuICBDb2x1bW5zXG59IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5pbXBvcnQgeyBBTExfR09WX1BPUlRBTFMsIFNFUlZJQ0VfQ0FURUdPUklFUyB9IGZyb20gJy4uL2RhdGEvcG9ydGFsRGF0YSc7XG5pbXBvcnQgeyBQb3J0YWxJdGVtLCBEb3dubG9hZEl0ZW0gfSBmcm9tICcuLi90eXBlcyc7XG5cbmludGVyZmFjZSBHb3Zlcm5tZW50UG9ydGFsc1ZpZXdQcm9wcyB7XG4gIG9uQWRkRG93bmxvYWQ/OiAoZG93bmxvYWQ6IERvd25sb2FkSXRlbSkgPT4gdm9pZDtcbiAgb25OYXZpZ2F0ZT86ICh0YWI6IHN0cmluZykgPT4gdm9pZDtcbn1cblxuZXhwb3J0IGNvbnN0IEdvdmVybm1lbnRQb3J0YWxzVmlldzogUmVhY3QuRkM8R292ZXJubWVudFBvcnRhbHNWaWV3UHJvcHM+ID0gKHtcbiAgb25BZGREb3dubG9hZCxcbiAgb25OYXZpZ2F0ZVxufSkgPT4ge1xuICBjb25zdCBbYWN0aXZlQ2F0ZWdvcnksIHNldEFjdGl2ZUNhdGVnb3J5XSA9IHVzZVN0YXRlPHN0cmluZz4oJ2FsbCcpO1xuICBjb25zdCBbc2VhcmNoLCBzZXRTZWFyY2hdID0gdXNlU3RhdGU8c3RyaW5nPignJyk7XG4gIGNvbnN0IFtzZWxlY3RlZFBvcnRhbEZvckRvY3MsIHNldFNlbGVjdGVkUG9ydGFsRm9yRG9jc10gPSB1c2VTdGF0ZTxQb3J0YWxJdGVtIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IFtjb3BpZWRJZCwgc2V0Q29waWVkSWRdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG5cbiAgLy8gSW4tQXBwIEJyb3dzZXIgU3RhdGVcbiAgY29uc3QgW2FjdGl2ZVBvcnRhbCwgc2V0QWN0aXZlUG9ydGFsXSA9IHVzZVN0YXRlPFBvcnRhbEl0ZW0gfCBudWxsPihudWxsKTtcbiAgY29uc3QgW2Jyb3dzZXJVcmwsIHNldEJyb3dzZXJVcmxdID0gdXNlU3RhdGU8c3RyaW5nPignJyk7XG4gIGNvbnN0IFtpZnJhbWVLZXksIHNldElmcmFtZUtleV0gPSB1c2VTdGF0ZTxudW1iZXI+KDApO1xuICBjb25zdCBbem9vbUxldmVsLCBzZXRab29tTGV2ZWxdID0gdXNlU3RhdGU8bnVtYmVyPigxMDApO1xuICBjb25zdCBbaXNTcGxpdFNjcmVlbiwgc2V0SXNTcGxpdFNjcmVlbl0gPSB1c2VTdGF0ZTxib29sZWFuPih0cnVlKTtcbiAgY29uc3QgW3VzZVByb3h5LCBzZXRVc2VQcm94eV0gPSB1c2VTdGF0ZTxib29sZWFuPihmYWxzZSk7XG5cbiAgLy8gUXVpY2sgTm90ZXMgJiBJbi1BcHAgRG9jdW1lbnQgR3JhYmJlclxuICBjb25zdCBbbm90ZXNDdXN0b21lck5hbWUsIHNldE5vdGVzQ3VzdG9tZXJOYW1lXSA9IHVzZVN0YXRlPHN0cmluZz4oJycpO1xuICBjb25zdCBbbm90ZXNBY2tUb2tlbiwgc2V0Tm90ZXNBY2tUb2tlbl0gPSB1c2VTdGF0ZTxzdHJpbmc+KCcnKTtcbiAgY29uc3QgW25vdGVzQWFkaGFhciwgc2V0Tm90ZXNBYWRoYWFyXSA9IHVzZVN0YXRlPHN0cmluZz4oJycpO1xuICBjb25zdCBbZG93bmxvYWRTdWNjZXNzTXNnLCBzZXREb3dubG9hZFN1Y2Nlc3NNc2ddID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG5cbiAgY29uc3QgZmlsZUlucHV0UmVmID0gdXNlUmVmPEhUTUxJbnB1dEVsZW1lbnQ+KG51bGwpO1xuXG4gIGNvbnN0IGZpbHRlcmVkUG9ydGFscyA9IEFMTF9HT1ZfUE9SVEFMUy5maWx0ZXIoKHApID0+IHtcbiAgICBjb25zdCBtYXRjaGVzQ2F0ZWdvcnkgPSBhY3RpdmVDYXRlZ29yeSA9PT0gJ2FsbCcgfHwgcC5jYXRlZ29yeSA9PT0gYWN0aXZlQ2F0ZWdvcnk7XG4gICAgY29uc3QgbWF0Y2hlc1NlYXJjaCA9IFxuICAgICAgcC50aXRsZS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHNlYXJjaC50b0xvd2VyQ2FzZSgpKSB8fFxuICAgICAgcC5kZXNjcmlwdGlvbi50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHNlYXJjaC50b0xvd2VyQ2FzZSgpKTtcbiAgICByZXR1cm4gbWF0Y2hlc0NhdGVnb3J5ICYmIG1hdGNoZXNTZWFyY2g7XG4gIH0pO1xuXG4gIGNvbnN0IGhhbmRsZUNvcHlMaW5rID0gKHBvcnRhbDogUG9ydGFsSXRlbSkgPT4ge1xuICAgIG5hdmlnYXRvci5jbGlwYm9hcmQud3JpdGVUZXh0KHBvcnRhbC51cmwpO1xuICAgIHNldENvcGllZElkKHBvcnRhbC5pZCk7XG4gICAgc2V0VGltZW91dCgoKSA9PiBzZXRDb3BpZWRJZChudWxsKSwgMjAwMCk7XG4gIH07XG5cbiAgLy8gT3BlbiBQb3J0YWwgSW5zaWRlIHRoZSBBcHBcbiAgY29uc3QgaGFuZGxlT3Blbkluc2lkZUFwcCA9IChwb3J0YWw6IFBvcnRhbEl0ZW0pID0+IHtcbiAgICBzZXRBY3RpdmVQb3J0YWwocG9ydGFsKTtcbiAgICBzZXRCcm93c2VyVXJsKHBvcnRhbC51cmwpO1xuICAgIHNldElmcmFtZUtleShwcmV2ID0+IHByZXYgKyAxKTtcbiAgICBzZXRVc2VQcm94eShmYWxzZSk7XG4gIH07XG5cbiAgLy8gQ2xvc2UgSW4tQXBwIEJyb3dzZXJcbiAgY29uc3QgaGFuZGxlQ2xvc2VCcm93c2VyID0gKCkgPT4ge1xuICAgIHNldEFjdGl2ZVBvcnRhbChudWxsKTtcbiAgICBzZXRCcm93c2VyVXJsKCcnKTtcbiAgfTtcblxuICAvLyBSZWZyZXNoIGN1cnJlbnQgcG9ydGFsIGlmcmFtZVxuICBjb25zdCBoYW5kbGVSZWxvYWQgPSAoKSA9PiB7XG4gICAgc2V0SWZyYW1lS2V5KHByZXYgPT4gcHJldiArIDEpO1xuICB9O1xuXG4gIC8vIEhhbmRsZSBpbi1hcHAgZG9jdW1lbnQgZ3JhYiAvIHVwbG9hZFxuICBjb25zdCBoYW5kbGVJbkFwcERvd25sb2FkRmlsZSA9IChlOiBSZWFjdC5DaGFuZ2VFdmVudDxIVE1MSW5wdXRFbGVtZW50PikgPT4ge1xuICAgIGNvbnN0IGZpbGUgPSBlLnRhcmdldC5maWxlcz8uWzBdO1xuICAgIGlmICghZmlsZSkgcmV0dXJuO1xuXG4gICAgY29uc3QgZmlsZUV4dCA9IGZpbGUubmFtZS5zcGxpdCgnLicpLnBvcCgpPy50b1VwcGVyQ2FzZSgpIHx8ICdQREYnO1xuICAgIGNvbnN0IGlzSW1hZ2UgPSBmaWxlLnR5cGUuc3RhcnRzV2l0aCgnaW1hZ2UvJyk7XG4gICAgY29uc3QgaXNQZGYgPSBmaWxlLnR5cGUgPT09ICdhcHBsaWNhdGlvbi9wZGYnIHx8IGZpbGUubmFtZS5lbmRzV2l0aCgnLnBkZicpO1xuXG4gICAgY29uc3QgZG93bmxvYWRJdGVtOiBEb3dubG9hZEl0ZW0gPSB7XG4gICAgICBpZDogYGRsLSR7RGF0ZS5ub3coKX1gLFxuICAgICAgdGl0bGU6IGAke25vdGVzQ3VzdG9tZXJOYW1lID8gbm90ZXNDdXN0b21lck5hbWUgKyAnIC0gJyA6ICcnfSR7YWN0aXZlUG9ydGFsPy50aXRsZSB8fCAnUG9ydGFsIERvY3VtZW50J30gKCR7bm90ZXNBY2tUb2tlbiB8fCAnU2xpcCd9KWAsXG4gICAgICB0eXBlOiBpc1BkZiA/ICdQVkMgQ2FyZCBQREYnIDogJ0NvbnZlcnRlZCBKUEcnLFxuICAgICAgc2l6ZTogYCR7KGZpbGUuc2l6ZSAvIDEwMjQpLnRvRml4ZWQoMSl9IEtCYCxcbiAgICAgIHRpbWVzdGFtcDogbmV3IERhdGUoKS50b0xvY2FsZVRpbWVTdHJpbmcoW10sIHsgaG91cjogJzItZGlnaXQnLCBtaW51dGU6ICcyLWRpZ2l0JyB9KSxcbiAgICAgIGRhdGFVcmw6IFVSTC5jcmVhdGVPYmplY3RVUkwoZmlsZSlcbiAgICB9O1xuXG4gICAgaWYgKG9uQWRkRG93bmxvYWQpIHtcbiAgICAgIG9uQWRkRG93bmxvYWQoZG93bmxvYWRJdGVtKTtcbiAgICB9XG5cbiAgICBzZXREb3dubG9hZFN1Y2Nlc3NNc2coYOKchSBEb2N1bWVudCBzYXZlZCB0byBJbi1BcHAgRG93bmxvYWRzIFZhdWx0IWApO1xuICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0RG93bmxvYWRTdWNjZXNzTXNnKG51bGwpLCA0MDAwKTtcbiAgfTtcblxuICBjb25zdCBnZXRFZmZlY3RpdmVJZnJhbWVTcmMgPSAoKSA9PiB7XG4gICAgaWYgKCFicm93c2VyVXJsKSByZXR1cm4gJyc7XG4gICAgaWYgKHVzZVByb3h5KSB7XG4gICAgICByZXR1cm4gYC9hcGkvcG9ydGFsLXByb3h5P3VybD0ke2VuY29kZVVSSUNvbXBvbmVudChicm93c2VyVXJsKX1gO1xuICAgIH1cbiAgICByZXR1cm4gYnJvd3NlclVybDtcbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XG4gICAgICB7LyogSGVhZGVyIGJhciAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBzbTppdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBwLTQgcm91bmRlZC0yeGwgc2hhZG93LW1kXCI+XG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBmbGV4LXdyYXBcIj5cbiAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtZXh0cmFib2xkIHRleHQtd2hpdGUgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgPEdsb2JlIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1za3ktNDAwXCIgLz5cbiAgICAgICAgICAgICAgPHNwYW4+T2ZmaWNpYWwgR292ZXJubWVudCBQb3J0YWxzICYgSW4tQXBwIFdlYiBCcm93c2VyPC9zcGFuPlxuICAgICAgICAgICAgPC9oMT5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJnLXNreS01MDAvMjAgdGV4dC1za3ktNDAwIGJvcmRlciBib3JkZXItc2t5LTUwMC8zMCB0ZXh0LXhzIHB4LTIuNSBweS0wLjUgcm91bmRlZC1mdWxsIGZvbnQtbW9ubyBmb250LWJvbGRcIj5cbiAgICAgICAgICAgICAge0FMTF9HT1ZfUE9SVEFMUy5sZW5ndGh9IENlbnRyYWwgJiBTdGF0ZSBQb3J0YWxzXG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJiZy1lbWVyYWxkLTUwMC8yMCB0ZXh0LWVtZXJhbGQtNDAwIGJvcmRlciBib3JkZXItZW1lcmFsZC01MDAvMzAgdGV4dC14cyBweC0yLjUgcHktMC41IHJvdW5kZWQtZnVsbCBmb250LWJvbGRcIj5cbiAgICAgICAgICAgICAgSW4tQXBwIEVtYmVkZGVkIE1vZGVcbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwIG10LTFcIj5cbiAgICAgICAgICAgIEFsbCA1MCsgb2ZmaWNpYWwgZ292ZXJubWVudCB3ZWJzaXRlcyBvcGVuIGRpcmVjdGx5IGluc2lkZSB0aGlzIHdvcmtzdGF0aW9uIHdpdGggYnVpbHQtaW4gZG9jdW1lbnQgZG93bmxvYWQgdmF1bHRcbiAgICAgICAgICA8L3A+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBTZWFyY2ggKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIj5cbiAgICAgICAgICA8U2VhcmNoIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtc2xhdGUtNDAwIGFic29sdXRlIGxlZnQtMyB0b3AtMS8yIC10cmFuc2xhdGUteS0xLzJcIiAvPlxuICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWFyY2ggcG9ydGFscyAoQWFkaGFhciwgUEFOLCBMYWRraSBCYWhpbikuLi5cIlxuICAgICAgICAgICAgdmFsdWU9e3NlYXJjaH1cbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2VhcmNoKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLXhsIHBsLTggcHItMyBweS0yIHRleHQteHMgdGV4dC13aGl0ZSBwbGFjZWhvbGRlci1zbGF0ZS01MDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1za3ktNTAwIHctZnVsbCBzbTp3LTcyXCJcbiAgICAgICAgICAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogQ2F0ZWdvcnkgVGFicyAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgb3ZlcmZsb3cteC1hdXRvIHBiLTFcIj5cbiAgICAgICAge1NFUlZJQ0VfQ0FURUdPUklFUy5tYXAoKGNhdCkgPT4gKFxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIGtleT17Y2F0LmlkfVxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QWN0aXZlQ2F0ZWdvcnkoY2F0LmlkKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTMuNSBweS0yIHJvdW5kZWQteGwgdGV4dC14cyBmb250LWJvbGQgd2hpdGVzcGFjZS1ub3dyYXAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSB0cmFuc2l0aW9uLWFsbCAke1xuICAgICAgICAgICAgICBhY3RpdmVDYXRlZ29yeSA9PT0gY2F0LmlkXG4gICAgICAgICAgICAgICAgPyAnYmctYmx1ZS02MDAgdGV4dC13aGl0ZSBzaGFkb3ctbWQgc2hhZG93LWJsdWUtNjAwLzMwJ1xuICAgICAgICAgICAgICAgIDogJ2JnLXNsYXRlLTkwMCB0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXdoaXRlIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGhvdmVyOmJnLXNsYXRlLTgwMCdcbiAgICAgICAgICAgIH1gfVxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxzcGFuPntjYXQuaWNvbn08L3NwYW4+XG4gICAgICAgICAgICA8c3Bhbj57Y2F0LmxhYmVsfTwvc3Bhbj5cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgKSl9XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIFBvcnRhbHMgR3JpZCAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtMyBnYXAtNFwiPlxuICAgICAgICB7ZmlsdGVyZWRQb3J0YWxzLm1hcCgocG9ydGFsKSA9PiAoXG4gICAgICAgICAgPGRpdlxuICAgICAgICAgICAga2V5PXtwb3J0YWwuaWR9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgaG92ZXI6Ym9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLTJ4bCBwLTQgc2hhZG93LW1kIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTIwMCBob3ZlcjotdHJhbnNsYXRlLXktMC41IGZsZXggZmxleC1jb2wganVzdGlmeS1iZXR3ZWVuXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQganVzdGlmeS1iZXR3ZWVuIGdhcC0zIG1iLTJcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yLjVcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMCBoLTEwIHJvdW5kZWQteGwgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQteGwgc2hhZG93LWlubmVyXCI+XG4gICAgICAgICAgICAgICAgICAgIHtwb3J0YWwuaWNvbn1cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNtIHRleHQtd2hpdGVcIj57cG9ydGFsLnRpdGxlfTwvaDM+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtbW9ubyB0ZXh0LXNsYXRlLTQwMCBjYXBpdGFsaXplXCI+XG4gICAgICAgICAgICAgICAgICAgICAge3BvcnRhbC5wb3J0YWxUeXBlfSBQb3J0YWwg4oCiIHtwb3J0YWwuY2F0ZWdvcnkucmVwbGFjZSgnXycsICcgJyl9XG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAge3BvcnRhbC5wb3B1bGFyICYmIChcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzlweF0gZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBiZy1lbWVyYWxkLTUwMC8yMCB0ZXh0LWVtZXJhbGQtNDAwIHB4LTEuNSBweS0wLjUgcm91bmRlZCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtNTAwLzMwXCI+XG4gICAgICAgICAgICAgICAgICAgIEhpZ2ggRGVtYW5kXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTMwMCBtdC0yIGxlYWRpbmctcmVsYXhlZCBsaW5lLWNsYW1wLTNcIj5cbiAgICAgICAgICAgICAgICB7cG9ydGFsLmRlc2NyaXB0aW9ufVxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00IHB0LTMgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTgwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gdGV4dC14c1wiPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2VsZWN0ZWRQb3J0YWxGb3JEb2NzKHBvcnRhbCl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC1ibHVlLTQwMCBmb250LW1lZGl1bSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSB0ZXh0LVsxMXB4XVwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8RmlsZUNoZWNrIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtYmx1ZS00MDBcIiAvPlxuICAgICAgICAgICAgICAgIDxzcGFuPkRvY3MgTmVlZGVkICh7cG9ydGFsLnJlcXVpcmVkRG9jcy5sZW5ndGh9KTwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCI+XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlQ29weUxpbmsocG9ydGFsKX1cbiAgICAgICAgICAgICAgICAgIHRpdGxlPVwiQ29weSBEaXJlY3QgT2ZmaWNpYWwgTGlua1wiXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEuNSByb3VuZGVkLWxnIGJnLXNsYXRlLTgwMCBob3ZlcjpiZy1zbGF0ZS03MDAgdGV4dC1zbGF0ZS0zMDAgaG92ZXI6dGV4dC13aGl0ZVwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAge2NvcGllZElkID09PSBwb3J0YWwuaWQgPyA8Q2hlY2sgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1lbWVyYWxkLTQwMFwiIC8+IDogPENvcHkgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPn1cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgICAgIHsvKiBQcmltYXJ5OiBPcGVuIEluc2lkZSBBcHBsaWNhdGlvbiAqL31cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVPcGVuSW5zaWRlQXBwKHBvcnRhbCl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTMgcHktMS41IHJvdW5kZWQteGwgYmctZ3JhZGllbnQtdG8tciBmcm9tLWJsdWUtNjAwIHRvLWluZGlnby02MDAgaG92ZXI6ZnJvbS1ibHVlLTUwMCBob3Zlcjp0by1pbmRpZ28tNTAwIHRleHQtd2hpdGUgZm9udC1leHRyYWJvbGQgdGV4dC14cyBzaGFkb3ctbWQgdHJhbnNpdGlvbi1hbGwgaG92ZXI6c2NhbGUtMTA1XCJcbiAgICAgICAgICAgICAgICAgIHRpdGxlPVwiT3BlbiB0aGlzIGdvdmVybm1lbnQgcG9ydGFsIGluc2lkZSB0aGUgYXBwXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8R2xvYmUgY2xhc3NOYW1lPVwidy0zIGgtMyB0ZXh0LXNreS0yMDBcIiAvPlxuICAgICAgICAgICAgICAgICAgPHNwYW4+T3BlbiBJbnNpZGUgQXBwPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApKX1cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogRlVMTC1GRUFUVVJFRCBJTi1BUFAgRU1CRURERUQgV0VCIEJST1dTRVIgTU9EQUwgKi99XG4gICAgICB7YWN0aXZlUG9ydGFsICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIGJnLWJsYWNrLzkwIGJhY2tkcm9wLWJsdXItbWQgei01MCBmbGV4IGZsZXgtY29sIHAtMiBzbTpwLTRcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTN4bCBmbGV4LTEgZmxleCBmbGV4LWNvbCBvdmVyZmxvdy1oaWRkZW4gc2hhZG93LTJ4bFwiPlxuICAgICAgICAgICAgey8qIEJyb3dzZXIgQ29udHJvbCBUb29sYmFyICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05NTAgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMCBweC00IHB5LTMgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zIGZsZXgtd3JhcFwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14bFwiPnthY3RpdmVQb3J0YWwuaWNvbn08L3NwYW4+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJmb250LWV4dHJhYm9sZCB0ZXh0LXdoaXRlIHRleHQteHMgbGVhZGluZy1ub25lIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+e2FjdGl2ZVBvcnRhbC50aXRsZX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGJnLWVtZXJhbGQtNTAwLzIwIHRleHQtZW1lcmFsZC0zMDAgcHgtMiBweS0wLjUgcm91bmRlZCBmb250LW1vbm8gZm9udC1ib2xkXCI+XG4gICAgICAgICAgICAgICAgICAgICAgSW4tQXBwIEJyb3dzZXJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9oMj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNDAwIGZvbnQtbW9ub1wiPnthY3RpdmVQb3J0YWwucG9ydGFsVHlwZX0g4oCiIHthY3RpdmVQb3J0YWwuY2F0ZWdvcnl9PC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7LyogVVJMIEFkZHJlc3MgQmFyICovfVxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBtYXgtdy14bCBmbGV4IGl0ZW1zLWNlbnRlciBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCBweC0zIHB5LTEuNSBnYXAtMiB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgICAgPEdsb2JlIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtYmx1ZS00MDAgZmxleC1zaHJpbmstMFwiIC8+XG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17YnJvd3NlclVybH1cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0QnJvd3NlclVybChlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICBvbktleURvd249eyhlKSA9PiBlLmtleSA9PT0gJ0VudGVyJyAmJiBoYW5kbGVSZWxvYWQoKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXRyYW5zcGFyZW50IHRleHQtd2hpdGUgZm9udC1tb25vIHRleHQtWzExcHhdIHctZnVsbCBmb2N1czpvdXRsaW5lLW5vbmUgdHJ1bmNhdGVcIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlUmVsb2FkfVxuICAgICAgICAgICAgICAgICAgdGl0bGU9XCJSZWxvYWQgUG9ydGFsXCJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtd2hpdGVcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxSZWZyZXNoQ3cgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7LyogQWN0aW9uIEJ1dHRvbnMgKi99XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICB7LyogUHJveHkgVG9nZ2xlIChVc2VmdWwgaWYgd2Vic2l0ZSByZXN0cmljdHMgaWZyYW1lcykgKi99XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4geyBzZXRVc2VQcm94eSghdXNlUHJveHkpOyBoYW5kbGVSZWxvYWQoKTsgfX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTIuNSBweS0xLjUgcm91bmRlZC14bCB0ZXh0LVsxMXB4XSBmb250LWJvbGQgYm9yZGVyIHRyYW5zaXRpb24tY29sb3JzICR7XG4gICAgICAgICAgICAgICAgICAgIHVzZVByb3h5IFxuICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLXB1cnBsZS02MDAgdGV4dC13aGl0ZSBib3JkZXItcHVycGxlLTQwMCBzaGFkb3cnXG4gICAgICAgICAgICAgICAgICAgICAgOiAnYmctc2xhdGUtOTAwIHRleHQtc2xhdGUtNDAwIGJvcmRlci1zbGF0ZS04MDAgaG92ZXI6dGV4dC13aGl0ZSdcbiAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgdGl0bGU9XCJUb2dnbGUgSW4tQXBwIEJ5cGFzcyBQcm94eSBmb3IgcmVzdHJpY3RlZCBwb3J0YWxzXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8c3Bhbj5Qcm94eToge3VzZVByb3h5ID8gJ09OJyA6ICdPRkYnfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgICAgIHsvKiBTcGxpdCBTY3JlZW4gVG9nZ2xlICovfVxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldElzU3BsaXRTY3JlZW4oIWlzU3BsaXRTY3JlZW4pfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcC0yIHJvdW5kZWQteGwgYm9yZGVyIHRleHQteHMgJHtcbiAgICAgICAgICAgICAgICAgICAgaXNTcGxpdFNjcmVlblxuICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLWJsdWUtNjAwIHRleHQtd2hpdGUgYm9yZGVyLWJsdWUtNDAwJ1xuICAgICAgICAgICAgICAgICAgICAgIDogJ2JnLXNsYXRlLTkwMCB0ZXh0LXNsYXRlLTQwMCBib3JkZXItc2xhdGUtODAwIGhvdmVyOnRleHQtd2hpdGUnXG4gICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgIHRpdGxlPVwiVG9nZ2xlIE9wZXJhdG9yIFNwbGl0LVNjcmVlbiBXb3Jrc3RhdGlvbiBEZXNrXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8Q29sdW1ucyBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgICAgICB7LyogQ2xvc2UgSW4tQXBwIEJyb3dzZXIgKi99XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQ2xvc2VCcm93c2VyfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0yIHJvdW5kZWQteGwgYmctc2xhdGUtODAwIGhvdmVyOmJnLXJvc2UtNjAwIHRleHQtc2xhdGUtMzAwIGhvdmVyOnRleHQtd2hpdGUgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgICAgICAgICAgdGl0bGU9XCJDbG9zZSBQb3J0YWxcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxYIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogQnJvd3NlciBNYWluIEJvZHkgKFNwbGl0IG9yIEZ1bGwpICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgZmxleCBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgICAgICAgICAgey8qIExlZnQgU2lkZTogTGl2ZSBFbWJlZGRlZCBQb3J0YWwgKi99XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgaC1mdWxsIGZsZXggZmxleC1jb2wgYmctd2hpdGUgcmVsYXRpdmUgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMjAwICR7XG4gICAgICAgICAgICAgICAgaXNTcGxpdFNjcmVlbiA/ICd3LWZ1bGwgbGc6dy04LzEyJyA6ICd3LWZ1bGwnXG4gICAgICAgICAgICAgIH1gfT5cbiAgICAgICAgICAgICAgICA8aWZyYW1lXG4gICAgICAgICAgICAgICAgICBrZXk9e2lmcmFtZUtleX1cbiAgICAgICAgICAgICAgICAgIHNyYz17Z2V0RWZmZWN0aXZlSWZyYW1lU3JjKCl9XG4gICAgICAgICAgICAgICAgICB0aXRsZT17YWN0aXZlUG9ydGFsLnRpdGxlfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtZnVsbCBib3JkZXItbm9uZVwiXG4gICAgICAgICAgICAgICAgICBzdHlsZT17eyB0cmFuc2Zvcm06IGBzY2FsZSgke3pvb21MZXZlbCAvIDEwMH0pYCwgdHJhbnNmb3JtT3JpZ2luOiAnMCAwJyB9fVxuICAgICAgICAgICAgICAgICAgc2FuZGJveD1cImFsbG93LXNhbWUtb3JpZ2luIGFsbG93LXNjcmlwdHMgYWxsb3ctZm9ybXMgYWxsb3ctcG9wdXBzIGFsbG93LWRvd25sb2Fkc1wiXG4gICAgICAgICAgICAgICAgLz5cblxuICAgICAgICAgICAgICAgIHsvKiBCb3R0b20gRmFsbGJhY2sgSW5mbyBCYXIgKi99XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBib3R0b20tMiBsZWZ0LTMgcmlnaHQtMyBiZy1zbGF0ZS05NTAvOTAgYmFja2Ryb3AtYmx1ci1tZCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBwLTIgcm91bmRlZC14bCB0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTMwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTIgc2hhZG93LWxnXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgdHJ1bmNhdGVcIj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy0yIGgtMiByb3VuZGVkLWZ1bGwgYmctZW1lcmFsZC00MDBcIj48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPkxpdmUgUG9ydGFsOiA8Yj57YWN0aXZlUG9ydGFsLnRpdGxlfTwvYj48L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgZmxleC1zaHJpbmstMFwiPlxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0VXNlUHJveHkoIXVzZVByb3h5KX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2t5LTQwMCBob3Zlcjp1bmRlcmxpbmUgZm9udC1ib2xkXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIHt1c2VQcm94eSA/ICdTd2l0Y2ggRGlyZWN0JyA6ICdCeXBhc3MgRnJhbWUgUmVzdHJpY3Rpb24nfVxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPGFcbiAgICAgICAgICAgICAgICAgICAgICBocmVmPXticm93c2VyVXJsfVxuICAgICAgICAgICAgICAgICAgICAgIHRhcmdldD1cIl9ibGFua1wiXG4gICAgICAgICAgICAgICAgICAgICAgcmVsPVwibm9vcGVuZXIgbm9yZWZlcnJlclwiXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXdoaXRlIGZsZXggaXRlbXMtY2VudGVyIGdhcC0wLjUgZm9udC1ib2xkXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPk5ldyBXaW5kb3c8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPEV4dGVybmFsTGluayBjbGFzc05hbWU9XCJ3LTMgaC0zXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9hPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHsvKiBSaWdodCBTaWRlOiBPcGVyYXRvciBTcGxpdC1TY3JlZW4gJiBJbi1BcHAgRG9jdW1lbnQgR3JhYmJlciAqL31cbiAgICAgICAgICAgICAge2lzU3BsaXRTY3JlZW4gJiYgKFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGlkZGVuIGxnOmZsZXggbGc6dy00LzEyIGgtZnVsbCBiZy1zbGF0ZS05MDAgYm9yZGVyLWwgYm9yZGVyLXNsYXRlLTgwMCBmbGV4LWNvbCBwLTQgc3BhY2UteS00IG92ZXJmbG93LXktYXV0b1wiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtZXh0cmFib2xkIHRleHQtd2hpdGUgdGV4dC14cyB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC1lbWVyYWxkLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxGb2xkZXJEb3duIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPkluLUFwcCBEb2N1bWVudCBHcmFiYmVyICYgRG93bmxvYWRzPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTQwMCBsZWFkaW5nLXNudWdcIj5cbiAgICAgICAgICAgICAgICAgICAgICBXaGVuIGNpdGl6ZW4gYWNrbm93bGVkZ2VtZW50IHNsaXAsIGUtQWFkaGFhciwgb3IgUEFOIFBERiBpcyByZWFkeSwgZ3JhYiBpdCBkaXJlY3RseSBpbnRvIHRoZSBpbi1hcHAgdmF1bHQuXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICB7ZG93bmxvYWRTdWNjZXNzTXNnICYmIChcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMgcm91bmRlZC14bCBiZy1lbWVyYWxkLTUwMC8xMCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtNTAwLzMwIHRleHQtZW1lcmFsZC00MDAgdGV4dC14cyBmb250LWJvbGQgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgYW5pbWF0ZS1pbiBmYWRlLWluXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPENoZWNrQ2lyY2xlIGNsYXNzTmFtZT1cInctNCBoLTQgZmxleC1zaHJpbmstMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e2Rvd25sb2FkU3VjY2Vzc01zZ308L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgICAgey8qIEN1c3RvbWVyIFF1aWNrIEZpZWxkcyAqL31cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yIHRleHQteHMgYmctc2xhdGUtOTUwIHAtMyByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtODAwXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNDAwIGJsb2NrIG1iLTAuNVwiPkNpdGl6ZW4gTmFtZTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImUuZy4gUmFodWwgU2hhcm1hXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtub3Rlc0N1c3RvbWVyTmFtZX1cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Tm90ZXNDdXN0b21lck5hbWUoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLWxnIHAtMiB0ZXh0LXdoaXRlIGZvbnQtYm9sZFwiXG4gICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS00MDAgYmxvY2sgbWItMC41XCI+QXBwbGljYXRpb24gVG9rZW4gLyBBY2sgTm8uPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiZS5nLiBNSC1MQlktMjAyNi05ODEyNFwiXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17bm90ZXNBY2tUb2tlbn1cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Tm90ZXNBY2tUb2tlbihlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQtbGcgcC0yIHRleHQtd2hpdGUgZm9udC1tb25vXCJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTQwMCBibG9jayBtYi0wLjVcIj5BYWRoYWFyIC8gTW9iaWxlIChSZWZlcmVuY2UpPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiWFhYWC1YWFhYLVhYWFhcIlxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e25vdGVzQWFkaGFhcn1cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Tm90ZXNBYWRoYWFyKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC1sZyBwLTIgdGV4dC13aGl0ZSBmb250LW1vbm9cIlxuICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgIHsvKiAxLUNsaWNrIERvY3VtZW50IEdyYWJiZXIgQnV0dG9uICovfVxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMgYmctc2xhdGUtOTUwIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgc3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTMwMCBibG9ja1wiPlxuICAgICAgICAgICAgICAgICAgICAgIFNhdmUgUG9ydGFsIEZpbGUgdG8gSW4tQXBwIFZhdWx0OlxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJmaWxlXCJcbiAgICAgICAgICAgICAgICAgICAgICByZWY9e2ZpbGVJbnB1dFJlZn1cbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5BcHBEb3dubG9hZEZpbGV9XG4gICAgICAgICAgICAgICAgICAgICAgYWNjZXB0PVwiLnBkZiwuanBnLC5qcGVnLC5wbmdcIlxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImhpZGRlblwiXG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBmaWxlSW5wdXRSZWYuY3VycmVudD8uY2xpY2soKX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHktMi41IGJnLWdyYWRpZW50LXRvLXIgZnJvbS1lbWVyYWxkLTYwMCB0by10ZWFsLTYwMCBob3Zlcjpmcm9tLWVtZXJhbGQtNTAwIGhvdmVyOnRvLXRlYWwtNTAwIHRleHQtd2hpdGUgZm9udC1leHRyYWJvbGQgdGV4dC14cyByb3VuZGVkLXhsIHNoYWRvdy1sZyBzaGFkb3ctZW1lcmFsZC02MDAvMjAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgdHJhbnNpdGlvbi1hbGwgaG92ZXI6c2NhbGUtMTAyXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIDxEb3dubG9hZCBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5HcmFiIFNsaXAgLyBlLUNhcmQgKEluLUFwcCk8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgIHsvKiBRdWljayBBY3Rpb24gSnVtcCB0byBTdHVkaW9zICovfVxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTIgcHQtMiBib3JkZXItdCBib3JkZXItc2xhdGUtODAwIHRleHQteHNcIj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBibG9ja1wiPlxuICAgICAgICAgICAgICAgICAgICAgIFRyYW5zZmVyIHRvIFN0dWRpbzpcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHsgaGFuZGxlQ2xvc2VCcm93c2VyKCk7IG9uTmF2aWdhdGU/LigncHZjX3N0dWRpbycpOyB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0yIHJvdW5kZWQteGwgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGhvdmVyOmJvcmRlci1ibHVlLTUwMCB0ZXh0LWxlZnQgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtd2hpdGUgdGV4dC1bMTFweF0gZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPENyZWRpdENhcmQgY2xhc3NOYW1lPVwidy0zIGgtMyB0ZXh0LWJsdWUtNDAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+UFZDIFN0dWRpbzwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTQwMFwiPkNhcmQgTWFrZXI8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHsgaGFuZGxlQ2xvc2VCcm93c2VyKCk7IG9uTmF2aWdhdGU/LigncGRmX3RvX2pwZycpOyB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0yIHJvdW5kZWQteGwgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGhvdmVyOmJvcmRlci1hbWJlci01MDAgdGV4dC1sZWZ0IHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXdoaXRlIHRleHQtWzExcHhdIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxGaWxlVGV4dCBjbGFzc05hbWU9XCJ3LTMgaC0zIHRleHQtYW1iZXItNDAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+UERGIHRvIEpQRzwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTQwMFwiPkNvbXByZXNzb3I8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHsgaGFuZGxlQ2xvc2VCcm93c2VyKCk7IG9uTmF2aWdhdGU/LignYmlsbGluZycpOyB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0yIHJvdW5kZWQteGwgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGhvdmVyOmJvcmRlci1lbWVyYWxkLTUwMCB0ZXh0LWxlZnQgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtd2hpdGUgdGV4dC1bMTFweF0gZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPFByaW50ZXIgY2xhc3NOYW1lPVwidy0zIGgtMyB0ZXh0LWVtZXJhbGQtNDAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+UE9TIEJpbGxpbmc8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS00MDBcIj5UaGVybWFsIFNsaXA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHsgaGFuZGxlQ2xvc2VCcm93c2VyKCk7IG9uTmF2aWdhdGU/LignZG93bmxvYWRzJyk7IH19XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTIgcm91bmRlZC14bCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgaG92ZXI6Ym9yZGVyLXB1cnBsZS01MDAgdGV4dC1sZWZ0IHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXdoaXRlIHRleHQtWzExcHhdIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxGb2xkZXJEb3duIGNsYXNzTmFtZT1cInctMyBoLTMgdGV4dC1wdXJwbGUtNDAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+RG93bmxvYWRzPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNDAwXCI+VmF1bHQgSGlzdG9yeTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICB7LyogUmVxdWlyZWQgRG9jdW1lbnRzIENoZWNrbGlzdCBmb3IgdGhpcyBzcGVjaWZpYyBwb3J0YWwgKi99XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTk1MCBwLTMgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBzcGFjZS15LTIgdGV4dC14c1wiPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC13aGl0ZSB0ZXh0LVsxMXB4XSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgPEZpbGVDaGVjayBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LWJsdWUtNDAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57YWN0aXZlUG9ydGFsLnRpdGxlfSBDaGVja2xpc3Q6PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAge2FjdGl2ZVBvcnRhbC5yZXF1aXJlZERvY3MubWFwKChkb2MsIGlkeCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e2lkeH0gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBnYXAtMS41IHRleHQtWzExcHhdIHRleHQtc2xhdGUtMzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZW1lcmFsZC00MDAgZm9udC1ib2xkXCI+4pyTPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57ZG9jfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgey8qIFJlcXVpcmVkIERvY3VtZW50cyBNb2RhbCAqL31cbiAgICAgIHtzZWxlY3RlZFBvcnRhbEZvckRvY3MgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgYmctYmxhY2svNzUgei01MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTRcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTJ4bCBtYXgtdy1sZyB3LWZ1bGwgcC01IHNoYWRvdy0yeGwgc3BhY2UteS00XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBib3JkZXItYiBib3JkZXItc2xhdGUtODAwIHBiLTNcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtMnhsXCI+e3NlbGVjdGVkUG9ydGFsRm9yRG9jcy5pY29ufTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXdoaXRlIHRleHQtYmFzZVwiPntzZWxlY3RlZFBvcnRhbEZvckRvY3MudGl0bGV9PC9oMz5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ibHVlLTQwMCBmb250LW1lZGl1bVwiPkN1c3RvbWVyIERvY3VtZW50cyBDaGVja2xpc3Q8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2VsZWN0ZWRQb3J0YWxGb3JEb2NzKG51bGwpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMS41IHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtd2hpdGUgcm91bmRlZC1sZyBob3ZlcjpiZy1zbGF0ZS04MDBcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPFggY2xhc3NOYW1lPVwidy01IGgtNVwiIC8+XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yIHRleHQteHNcIj5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS0zMDAgbGVhZGluZy1yZWxheGVkXCI+XG4gICAgICAgICAgICAgICAgQmVmb3JlIGFwcGx5aW5nIGZvciA8Yj57c2VsZWN0ZWRQb3J0YWxGb3JEb2NzLnRpdGxlfTwvYj4sIGNvbGxlY3QgdGhlIGZvbGxvd2luZyBvcmlnaW5hbCBkb2N1bWVudHMgZnJvbSB0aGUgY2l0aXplbjpcbiAgICAgICAgICAgICAgPC9wPlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTUwIHAtNCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHNwYWNlLXktMi41XCI+XG4gICAgICAgICAgICAgICAge3NlbGVjdGVkUG9ydGFsRm9yRG9jcy5yZXF1aXJlZERvY3MubWFwKChkb2MsIGlkeCkgPT4gKFxuICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e2lkeH0gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBnYXAtMi41IHRleHQtc2xhdGUtMjAwXCI+XG4gICAgICAgICAgICAgICAgICAgIDxDaGVja0NpcmNsZSBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtZW1lcmFsZC00MDAgZmxleC1zaHJpbmstMCBtdC0wLjVcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJsZWFkaW5nLXNudWdcIj57ZG9jfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktZW5kIGdhcC0yIHB0LTIgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgY29uc3QgcCA9IHNlbGVjdGVkUG9ydGFsRm9yRG9jcztcbiAgICAgICAgICAgICAgICAgIHNldFNlbGVjdGVkUG9ydGFsRm9yRG9jcyhudWxsKTtcbiAgICAgICAgICAgICAgICAgIGhhbmRsZU9wZW5JbnNpZGVBcHAocCk7XG4gICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIgYmctYmx1ZS02MDAgaG92ZXI6YmctYmx1ZS01MDAgdGV4dC13aGl0ZSBmb250LWJvbGQgcm91bmRlZC14bCB0ZXh0LXhzIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPEdsb2JlIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cbiAgICAgICAgICAgICAgICA8c3Bhbj5PcGVuIEluc2lkZSBBcHA8L3NwYW4+XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG4iXX0=