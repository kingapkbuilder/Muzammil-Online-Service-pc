const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=1d04f0f2";
import { ShieldCheck, Lock, Unlock, Smartphone, Laptop, RotateCcw, UserPlus, Trash2, Download, CheckCircle2, AlertCircle, Clock, Key, Check, Archive, RefreshCw, Cpu, Monitor, ClipboardList, Sparkles, Circle, Activity, Radio, Power, MessageSquare, Send, Calendar } from "/node_modules/.vite/deps/lucide-react.js?v=1d04f0f2";
import { getRegisteredOperators, resetOperatorPcBinding, resetOperatorMobileBinding, resetOperatorAllBindings, toggleOperatorLock, addNewOperator, deleteOperator, getSecurityAuditLogs, getHardwareDeviceId, getHardwareDeviceName, isMobileDevice, renewOperatorLicense, calculateRemainingDays, getLiveOperatorSessions, forceDisconnectOperator, sendOperatorBroadcastMessage } from "/src/utils/deviceSecurity.ts";
import { generateProjectZip, triggerDownloadZip } from "/src/utils/projectZip.ts";
var _jsxFileName = "/app/applet/src/components/MasterAdminView.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=1d04f0f2";
const MASTER_WORKFLOW_STEPS = [
	{
		stepNumber: 1,
		title: "Customer Intake & Service Identification",
		description: "Welcome citizen, verify Aadhaar linked mobile, check document prerequisites, and quote transparent rates.",
		toolsUsed: [
			"Dashboard",
			"50+ Govt Portals Hub",
			"AI Assistant"
		],
		checklist: [
			"Check customer Aadhaar & active mobile OTP availability",
			"Inform customer of official portal charges + service fee",
			"Record customer name & WhatsApp number in CRM",
			"Issue physical or digital queue token"
		],
		tips: "Aadhaar mein active mobile number hona PM-KISAN, Ladki Bahin, aur Mahadbt schemes ke liye anivarya hai."
	},
	{
		stepNumber: 2,
		title: "Official Portal Filing & Document Submission",
		description: "Log into central/state portal (Aaple Sarkar, Sarathi, Mahadbt), complete form entry, and submit.",
		toolsUsed: ["50+ Govt Portals Directory", "PDF to HD JPG Converter"],
		checklist: [
			"Enter applicant details matching Aadhaar letter by letter",
			"If portal requires JPG under 100KB, use PDF to JPG tool to compress documents",
			"Verify uploaded certificate previews before final submission",
			"Download and save official acknowledgement PDF"
		],
		tips: "Acknowledgement Receipt Token Number hamesha download karke Customer CRM mein note karein."
	},
	{
		stepNumber: 3,
		title: "Studio Photo & PVC Smart Card Processing",
		description: "Produce high-precision CR-80 PVC cards or 35x45mm passport photo sheets.",
		toolsUsed: ["PVC Smart Card Maker", "Passport Photo Studio Pro"],
		checklist: [
			"Passport Photo: Select 4×6 Landscape (8 Copies @ 300 DPI) or A4 Landscape",
			"Background: Use Connected Magic Wand or Pen Tool to cut out person and set White/Studio Blue BG",
			"Auto Beauty: Apply AI Face Smoothing to brighten skin tones and reduce camera shadows",
			"Exam Strip: Add Candidate Name & Date stamp for SSC GD, Police Bharti, or Railway forms",
			"PVC Card: Align Front & Back cards to standard CR-80 (85.6×54mm) with center cut guide line"
		],
		tips: "PVC Card print karte waqt printer properties mein \"High Quality Glossy Photo Paper\" select karein."
	},
	{
		stepNumber: 4,
		title: "300 DPI Physical Printing & Thermal Lamination",
		description: "Execute in-app borderless printing on photo paper, cut cards, and laminate.",
		toolsUsed: ["In-App Direct Print Engine (Ctrl + P)"],
		checklist: [
			"Load 4×6 inch (10×15 cm) Glossy Photo Paper into printer",
			"Press \"🖨️ Direct Print Sheet (Ctrl + P)\" directly inside studio",
			"Cut along pre-aligned guide marks",
			"For PVC Smart Cards: Pass through thermal laminator for durable waterproof finish"
		],
		tips: "In-app direct print zero popup blocker ke saath seedha connected printer par 300 DPI job bhejta hai."
	},
	{
		stepNumber: 5,
		title: "POS Billing & Thermal Receipt Generation",
		description: "Generate itemized tax invoice or 58mm/80mm thermal slip with dynamic UPI QR code.",
		toolsUsed: ["Fast Billing Desk POS"],
		checklist: [
			"Select service package (e.g. PVC Card ₹70, Passport Photo 8-copies ₹50, Online Form ₹100)",
			"Display dynamic UPI QR code on screen for instant customer payment",
			"Print 58mm thermal receipt or A4 official tax invoice for customer records",
			"Update payment status as \"Paid\" in ledger"
		],
		tips: "Thermal receipt par shop ka authorized signature aur non-refundable portal terms automatic aate hain."
	},
	{
		stepNumber: 6,
		title: "Customer Handover & Daily Cash Reconciliation",
		description: "Hand over laminated cards, passport photos in sleeve, and portal acknowledgement.",
		toolsUsed: ["Customer CRM & Job Tracker"],
		checklist: [
			"Hand over laminated cards, passport photos in sleeve, and portal acknowledgement",
			"Send WhatsApp confirmation with status update",
			"Mark job as \"Delivered\" in CRM Tracker",
			"Daily reconciliation: Check total cash + UPI collections in Billing Desk Summary"
		],
		tips: "Din ke end par Daily Ledger Summary se cash counter balance match karein."
	}
];
export const MasterAdminView = ({ settings, onUpdateSettings, onNavigateToWorkflow }) => {
	const [operators, setOperators] = useState([]);
	const [auditLogs, setAuditLogs] = useState([]);
	const [activeSubTab, setActiveSubTab] = useState("live_monitor");
	// Live Monitoring State
	const [liveSessions, setLiveSessions] = useState([]);
	const [isAutoRefreshing, setIsAutoRefreshing] = useState(true);
	const [lastRefreshedAt, setLastRefreshedAt] = useState("");
	// Renewal Modal State
	const [selectedOpForRenew, setSelectedOpForRenew] = useState(null);
	const [renewDaysCount, setRenewDaysCount] = useState(30);
	// Broadcast Alert Modal
	const [broadcastTargetUsername, setBroadcastTargetUsername] = useState(null);
	const [broadcastMessageText, setBroadcastMessageText] = useState("");
	// New Operator Modal State
	const [showAddModal, setShowAddModal] = useState(false);
	const [newUsername, setNewUsername] = useState("");
	const [newPassword, setNewPassword] = useState("");
	const [newDisplayName, setNewDisplayName] = useState("");
	const [newPhone, setNewPhone] = useState("");
	const [addError, setAddError] = useState("");
	// Project ZIP Export State
	const [isExportingZip, setIsExportingZip] = useState(false);
	const [zipProgress, setZipProgress] = useState({
		percent: 0,
		file: ""
	});
	// Notifications
	const [alertMessage, setAlertMessage] = useState(null);
	// Shop Settings Form
	const [shopForm, setShopForm] = useState(settings);
	// Workflow Checklist state inside Master Admin
	const [completedSteps, setCompletedSteps] = useState({});
	const currentDeviceId = getHardwareDeviceId();
	const currentDeviceName = getHardwareDeviceName();
	const currentIsMobile = isMobileDevice();
	const loadData = () => {
		setOperators(getRegisteredOperators());
		setAuditLogs(getSecurityAuditLogs());
	};
	const refreshLiveSessions = async () => {
		try {
			const sessions = await getLiveOperatorSessions();
			setLiveSessions(sessions);
			setLastRefreshedAt(new Date().toLocaleTimeString());
		} catch (e) {
			console.error(e);
		}
	};
	useEffect(() => {
		loadData();
		refreshLiveSessions();
	}, []);
	// Real-Time 3.5s Live Polling Heartbeat
	useEffect(() => {
		if (!isAutoRefreshing) return;
		const interval = setInterval(() => {
			refreshLiveSessions();
		}, 3500);
		return () => clearInterval(interval);
	}, [isAutoRefreshing]);
	// Handle License / Access Renewal
	const handleExecuteRenewal = () => {
		if (!selectedOpForRenew) return;
		const result = renewOperatorLicense(selectedOpForRenew.id, renewDaysCount);
		if (result.success) {
			loadData();
			refreshLiveSessions();
			setAlertMessage(`✅ Access Renewed for "${selectedOpForRenew.displayName}"! Valid until ${result.newExpiry} (${result.daysLeft} days remaining)`);
			setSelectedOpForRenew(null);
			setTimeout(() => setAlertMessage(null), 5e3);
		}
	};
	// Handle Force Disconnect Live Session
	const handleForceDisconnect = async (username, deviceId) => {
		if (window.confirm(`Force terminate active session for @${username}? Operator will be immediately logged out.`)) {
			await forceDisconnectOperator(username, deviceId);
			refreshLiveSessions();
			setAlertMessage(`🚨 Session for @${username} has been forcefully terminated.`);
			setTimeout(() => setAlertMessage(null), 4e3);
		}
	};
	// Handle Send In-App Broadcast Alert
	const handleSendBroadcast = async () => {
		if (!broadcastTargetUsername || !broadcastMessageText.trim()) return;
		await sendOperatorBroadcastMessage(broadcastTargetUsername, broadcastMessageText.trim());
		setAlertMessage(`📢 Alert message sent to @${broadcastTargetUsername}!`);
		setBroadcastTargetUsername(null);
		setBroadcastMessageText("");
		setTimeout(() => setAlertMessage(null), 4e3);
	};
	// Handle Reset PC Binding
	const handleResetPc = (operatorId, username) => {
		if (window.confirm(`Reset PC Device Binding for "${username}"? Operator can now log in on a new PC/Laptop.`)) {
			resetOperatorPcBinding(operatorId);
			loadData();
			refreshLiveSessions();
			setAlertMessage(`✅ PC device binding cleared for ${username}. Operator can bind a new PC.`);
			setTimeout(() => setAlertMessage(null), 4e3);
		}
	};
	// Handle Reset Mobile Binding
	const handleResetMobile = (operatorId, username) => {
		if (window.confirm(`Reset Mobile Device Binding for "${username}"? Operator can now log in on a new Smartphone.`)) {
			resetOperatorMobileBinding(operatorId);
			loadData();
			refreshLiveSessions();
			setAlertMessage(`✅ Mobile device binding cleared for ${username}. Operator can bind a new phone.`);
			setTimeout(() => setAlertMessage(null), 4e3);
		}
	};
	// Handle Reset All Devices (PC + Mobile)
	const handleResetAllDevices = (operatorId, username) => {
		if (window.confirm(`Reset BOTH PC & Mobile bindings for "${username}"?`)) {
			resetOperatorAllBindings(operatorId);
			loadData();
			refreshLiveSessions();
			setAlertMessage(`✅ All device bindings (PC & Mobile) cleared for ${username}.`);
			setTimeout(() => setAlertMessage(null), 4e3);
		}
	};
	// Handle Toggle Lock
	const handleToggleLock = (operatorId, username) => {
		toggleOperatorLock(operatorId);
		loadData();
		refreshLiveSessions();
		setAlertMessage(`Lock status updated for ${username}`);
		setTimeout(() => setAlertMessage(null), 3e3);
	};
	// Handle Delete Operator
	const handleDeleteOperator = (operatorId, username) => {
		if (window.confirm(`Permanently delete operator account "${username}"?`)) {
			deleteOperator(operatorId);
			loadData();
			refreshLiveSessions();
			setAlertMessage(`Operator ${username} deleted`);
			setTimeout(() => setAlertMessage(null), 3e3);
		}
	};
	// Handle Add Operator
	const handleCreateOperator = (e) => {
		e.preventDefault();
		setAddError("");
		if (!newUsername.trim() || !newPassword.trim() || !newDisplayName.trim()) {
			setAddError("Please fill all required fields");
			return;
		}
		const success = addNewOperator({
			username: newUsername.trim().toLowerCase(),
			password: newPassword.trim(),
			displayName: newDisplayName.trim(),
			role: "operator",
			phone: newPhone.trim() || "9561460313"
		});
		if (success) {
			setShowAddModal(false);
			setNewUsername("");
			setNewPassword("");
			setNewDisplayName("");
			setNewPhone("");
			loadData();
			refreshLiveSessions();
			setAlertMessage("✅ New Operator ID created! Permitted on 1 Authorized PC + 1 Authorized Mobile.");
			setTimeout(() => setAlertMessage(null), 4e3);
		} else {
			setAddError("Username already exists. Please choose another username.");
		}
	};
	// Handle Download Project ZIP
	const handleDownloadZip = async () => {
		setIsExportingZip(true);
		setZipProgress({
			percent: 10,
			file: "Gathering project source files..."
		});
		try {
			const zipBlob = await generateProjectZip((percent, file) => {
				setZipProgress({
					percent,
					file
				});
			});
			triggerDownloadZip(zipBlob, `Muzammil-Online-service-pc.zip`);
			setAlertMessage("📦 Complete original project source code (.ZIP) downloaded successfully!");
			setTimeout(() => setAlertMessage(null), 4e3);
		} catch (e) {
			console.error(e);
			window.location.href = "/api/download-zip";
		} finally {
			setIsExportingZip(false);
		}
	};
	// Handle Save Shop Settings
	const handleSaveSettings = (e) => {
		e.preventDefault();
		onUpdateSettings(shopForm);
		setAlertMessage("✅ Shop details and configuration saved!");
		setTimeout(() => setAlertMessage(null), 3e3);
	};
	const completedWorkflowCount = Object.values(completedSteps).filter(Boolean).length;
	const onlineCount = liveSessions.filter((s) => s.isOnline).length;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-md flex flex-col sm:flex-row sm:items-center justify-between gap-4",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2 flex-wrap",
					children: [/* @__PURE__ */ _jsxDEV("h1", {
						className: "text-xl font-extrabold text-white flex items-center gap-2",
						children: [/* @__PURE__ */ _jsxDEV(ShieldCheck, { className: "w-6 h-6 text-blue-400" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 390,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Master Admin Control & Live Monitoring Hub" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 391,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 389,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs px-2.5 py-0.5 rounded-full font-mono font-bold flex items-center gap-1.5",
						children: [/* @__PURE__ */ _jsxDEV("span", { className: "w-2 h-2 rounded-full bg-emerald-400 animate-pulse" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 394,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: [
							"Live: ",
							onlineCount,
							" Active Online"
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 395,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 393,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 388,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "text-xs text-slate-400 mt-1",
					children: "Real-Time Operator Activity Monitor • License Renewals • Dual-Device PC & Mobile Security • Central Setup"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 398,
					columnNumber: 11
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 387,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2 flex-wrap",
					children: /* @__PURE__ */ _jsxDEV("button", {
						onClick: handleDownloadZip,
						disabled: isExportingZip,
						className: "flex items-center gap-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-extrabold text-xs px-4 py-2.5 rounded-xl shadow-lg shadow-emerald-600/20 transition-all hover:scale-105 disabled:opacity-50",
						title: "Download full project source code archive (.zip)",
						children: [/* @__PURE__ */ _jsxDEV(Archive, { className: "w-4 h-4" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 411,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: isExportingZip ? "Packing ZIP..." : "📦 Download Project .ZIP" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 412,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 405,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 404,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 386,
				columnNumber: 7
			}, this),
			alertMessage && /* @__PURE__ */ _jsxDEV("div", {
				className: "p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs flex items-center justify-between animate-in fade-in",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ _jsxDEV(CheckCircle2, { className: "w-4 h-4 text-emerald-400 flex-shrink-0" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 421,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: alertMessage }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 422,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 420,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					onClick: () => setAlertMessage(null),
					className: "text-emerald-400 hover:text-white",
					children: "✕"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 424,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 419,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center gap-1.5 bg-slate-900 border border-slate-800 p-1.5 rounded-xl text-xs font-bold overflow-x-auto",
				children: [
					/* @__PURE__ */ _jsxDEV("button", {
						onClick: () => setActiveSubTab("live_monitor"),
						className: `flex items-center gap-1.5 px-4 py-2 rounded-lg transition-all ${activeSubTab === "live_monitor" ? "bg-rose-600 text-white shadow" : "text-slate-400 hover:text-white"}`,
						children: [/* @__PURE__ */ _jsxDEV(Radio, { className: "w-3.5 h-3.5 text-white animate-pulse" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 438,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: [
							"🔴 Live Operator Monitor (",
							onlineCount,
							")"
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 439,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 430,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						onClick: () => setActiveSubTab("operators"),
						className: `flex items-center gap-1.5 px-4 py-2 rounded-lg transition-all ${activeSubTab === "operators" ? "bg-blue-600 text-white shadow" : "text-slate-400 hover:text-white"}`,
						children: [/* @__PURE__ */ _jsxDEV(Monitor, { className: "w-3.5 h-3.5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 450,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: [
							"Operator IDs & Locks (",
							operators.length,
							")"
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 451,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 442,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						onClick: () => setActiveSubTab("workflow"),
						className: `flex items-center gap-1.5 px-4 py-2 rounded-lg transition-all ${activeSubTab === "workflow" ? "bg-blue-600 text-white shadow" : "text-slate-400 hover:text-white"}`,
						children: [/* @__PURE__ */ _jsxDEV(ClipboardList, { className: "w-3.5 h-3.5 text-amber-400" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 462,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Cyber Cafe Workflow & SOP" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 463,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 454,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						onClick: () => setActiveSubTab("zip_download"),
						className: `flex items-center gap-1.5 px-4 py-2 rounded-lg transition-all ${activeSubTab === "zip_download" ? "bg-blue-600 text-white shadow" : "text-slate-400 hover:text-white"}`,
						children: [/* @__PURE__ */ _jsxDEV(Archive, { className: "w-3.5 h-3.5 text-emerald-400" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 474,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Project (.ZIP) Export" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 475,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 466,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						onClick: () => setActiveSubTab("logs"),
						className: `flex items-center gap-1.5 px-4 py-2 rounded-lg transition-all ${activeSubTab === "logs" ? "bg-blue-600 text-white shadow" : "text-slate-400 hover:text-white"}`,
						children: [/* @__PURE__ */ _jsxDEV(Clock, { className: "w-3.5 h-3.5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 486,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Security & Device Logs" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 487,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 478,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						onClick: () => setActiveSubTab("settings"),
						className: `flex items-center gap-1.5 px-4 py-2 rounded-lg transition-all ${activeSubTab === "settings" ? "bg-blue-600 text-white shadow" : "text-slate-400 hover:text-white"}`,
						children: [/* @__PURE__ */ _jsxDEV(Key, { className: "w-3.5 h-3.5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 498,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Master Setup Center" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 499,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 490,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 429,
				columnNumber: 7
			}, this),
			activeSubTab === "live_monitor" && /* @__PURE__ */ _jsxDEV("div", {
				className: "bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800",
						children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
							className: "text-base font-extrabold text-white flex items-center gap-2",
							children: [
								/* @__PURE__ */ _jsxDEV(Radio, { className: "w-4 h-4 text-rose-500 animate-pulse" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 509,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("span", { children: "Live Operator Activity & Real-Time Pulse" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 510,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20 font-mono",
									children: "3.5s Live Ping"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 511,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 508,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-slate-400 mt-0.5",
							children: "See exactly which operator is working on what studio in real-time, their active PC/Mobile, and renew access."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 515,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 507,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setIsAutoRefreshing(!isAutoRefreshing),
								className: `px-3 py-1.5 rounded-xl text-xs font-bold border transition-colors flex items-center gap-1.5 ${isAutoRefreshing ? "bg-emerald-500/10 text-emerald-300 border-emerald-500/30" : "bg-slate-800 text-slate-400 border-slate-700"}`,
								children: [/* @__PURE__ */ _jsxDEV(Activity, { className: "w-3.5 h-3.5" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 529,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: isAutoRefreshing ? "Auto-Update: ON" : "Paused" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 530,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 521,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: refreshLiveSessions,
								className: "p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs",
								title: "Refresh Live Data",
								children: /* @__PURE__ */ _jsxDEV(RefreshCw, { className: "w-3.5 h-3.5" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 538,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 533,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 520,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 506,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-1",
								children: [
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-400 block text-[11px]",
										children: "Active Staff Online"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 546,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "text-2xl font-extrabold text-white font-mono flex items-center gap-2",
										children: [/* @__PURE__ */ _jsxDEV("span", { className: "w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 548,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: onlineCount }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 549,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 547,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-[10px] text-emerald-400 font-mono",
										children: "Live WebSocket Pulse"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 551,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 545,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-1",
								children: [
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-400 block text-[11px]",
										children: "PC Workstations Active"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 555,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "text-2xl font-extrabold text-blue-400 font-mono flex items-center gap-2",
										children: [/* @__PURE__ */ _jsxDEV(Laptop, { className: "w-5 h-5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 557,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: liveSessions.filter((s) => s.deviceType === "pc" && s.isOnline).length }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 558,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 556,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-[10px] text-slate-400",
										children: "Desktop Workstations"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 560,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 554,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-1",
								children: [
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-400 block text-[11px]",
										children: "Mobile Handsets Active"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 564,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "text-2xl font-extrabold text-purple-400 font-mono flex items-center gap-2",
										children: [/* @__PURE__ */ _jsxDEV(Smartphone, { className: "w-5 h-5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 566,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: liveSessions.filter((s) => s.deviceType === "mobile" && s.isOnline).length }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 567,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 565,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-[10px] text-slate-400",
										children: "Operator Handsets"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 569,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 563,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-1",
								children: [
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-400 block text-[11px]",
										children: "Last Pulse Update"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 573,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "text-sm font-bold text-white font-mono mt-1",
										children: lastRefreshedAt || "Connecting..."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 574,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-[10px] text-slate-500",
										children: "Auto Heartbeat"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 577,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 572,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 544,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "overflow-x-auto",
						children: /* @__PURE__ */ _jsxDEV("table", {
							className: "w-full text-left text-xs",
							children: [/* @__PURE__ */ _jsxDEV("thead", { children: /* @__PURE__ */ _jsxDEV("tr", {
								className: "border-b border-slate-800 text-slate-400 uppercase tracking-wider font-semibold",
								children: [
									/* @__PURE__ */ _jsxDEV("th", {
										className: "py-3 px-3",
										children: "Live Status"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 586,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("th", {
										className: "py-3 px-3",
										children: "Operator Name"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 587,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("th", {
										className: "py-3 px-3",
										children: "Device / Machine"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 588,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("th", {
										className: "py-3 px-3",
										children: "Active Studio / Task"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 589,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("th", {
										className: "py-3 px-3",
										children: "License Validity"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 590,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("th", {
										className: "py-3 px-3 text-right",
										children: "Admin Control"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 591,
										columnNumber: 19
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 585,
								columnNumber: 17
							}, this) }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 584,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("tbody", {
								className: "divide-y divide-slate-800/60 font-sans",
								children: liveSessions.map((session) => {
									const daysLeft = calculateRemainingDays(session.validityExpiresAt);
									const isExpiring = daysLeft < 15;
									return /* @__PURE__ */ _jsxDEV("tr", {
										className: "hover:bg-slate-950/40 transition-colors",
										children: [
											/* @__PURE__ */ _jsxDEV("td", {
												className: "py-3 px-3",
												children: /* @__PURE__ */ _jsxDEV("div", {
													className: "flex items-center gap-2",
													children: [/* @__PURE__ */ _jsxDEV("span", { className: `w-2.5 h-2.5 rounded-full ${session.isOnline ? "bg-emerald-400 animate-pulse" : "bg-slate-600"}` }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 604,
														columnNumber: 27
													}, this), /* @__PURE__ */ _jsxDEV("span", {
														className: `text-[11px] font-bold ${session.isOnline ? "text-emerald-400" : "text-slate-500"}`,
														children: session.isOnline ? "Active Now" : `${session.lastActiveSecondsAgo || 30}s ago`
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 607,
														columnNumber: 27
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 603,
													columnNumber: 25
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 602,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "py-3 px-3",
												children: [/* @__PURE__ */ _jsxDEV("div", {
													className: "font-extrabold text-white text-sm",
													children: session.displayName
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 617,
													columnNumber: 25
												}, this), /* @__PURE__ */ _jsxDEV("div", {
													className: "text-[11px] text-slate-400 font-mono",
													children: [
														"@",
														session.username,
														" • ",
														session.phone || "9561460313"
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 618,
													columnNumber: 25
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 616,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "py-3 px-3",
												children: [/* @__PURE__ */ _jsxDEV("div", {
													className: "flex items-center gap-1.5 font-bold text-slate-300",
													children: [session.deviceType === "mobile" ? /* @__PURE__ */ _jsxDEV(Smartphone, { className: "w-3.5 h-3.5 text-purple-400" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 625,
														columnNumber: 29
													}, this) : /* @__PURE__ */ _jsxDEV(Laptop, { className: "w-3.5 h-3.5 text-blue-400" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 627,
														columnNumber: 29
													}, this), /* @__PURE__ */ _jsxDEV("span", {
														className: "font-mono text-[11px]",
														children: session.deviceId
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 629,
														columnNumber: 27
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 623,
													columnNumber: 25
												}, this), /* @__PURE__ */ _jsxDEV("div", {
													className: "text-[10px] text-slate-400",
													children: session.deviceName
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 631,
													columnNumber: 25
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 622,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "py-3 px-3",
												children: /* @__PURE__ */ _jsxDEV("span", {
													className: "px-2.5 py-1 rounded-lg bg-blue-500/10 text-blue-300 border border-blue-500/20 font-bold text-[11px] inline-flex items-center gap-1",
													children: [/* @__PURE__ */ _jsxDEV(Activity, { className: "w-3 h-3 text-blue-400" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 637,
														columnNumber: 27
													}, this), /* @__PURE__ */ _jsxDEV("span", { children: session.currentTab || "Workstation Hub" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 638,
														columnNumber: 27
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 636,
													columnNumber: 25
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 635,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "py-3 px-3",
												children: /* @__PURE__ */ _jsxDEV("div", {
													className: "space-y-0.5",
													children: [/* @__PURE__ */ _jsxDEV("div", {
														className: `font-bold font-mono text-[11px] ${isExpiring ? "text-rose-400" : "text-emerald-400"}`,
														children: daysLeft > 0 ? `${daysLeft} Days Left` : "Expired"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 645,
														columnNumber: 27
													}, this), /* @__PURE__ */ _jsxDEV("div", {
														className: "text-[10px] text-slate-500",
														children: ["Exp: ", session.validityExpiresAt || "2026-12-31"]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 650,
														columnNumber: 27
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 644,
													columnNumber: 25
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 643,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "py-3 px-3 text-right",
												children: /* @__PURE__ */ _jsxDEV("div", {
													className: "flex items-center justify-end gap-1.5",
													children: [
														/* @__PURE__ */ _jsxDEV("button", {
															onClick: () => {
																const found = operators.find((o) => o.username === session.username);
																if (found) setSelectedOpForRenew(found);
															},
															className: "px-2.5 py-1 rounded-lg bg-emerald-500/10 text-emerald-300 border border-emerald-500/30 hover:bg-emerald-500/20 font-bold text-[10px] flex items-center gap-1 transition-colors",
															title: "Renew License Access",
															children: [/* @__PURE__ */ _jsxDEV(Calendar, { className: "w-3 h-3" }, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 666,
																columnNumber: 29
															}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Renew" }, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 667,
																columnNumber: 29
															}, this)]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 658,
															columnNumber: 27
														}, this),
														/* @__PURE__ */ _jsxDEV("button", {
															onClick: () => {
																setBroadcastTargetUsername(session.username);
																setBroadcastMessageText("");
															},
															className: "p-1 rounded-lg bg-slate-800 text-slate-300 border border-slate-700 hover:text-white",
															title: "Send In-App Toast Message",
															children: /* @__PURE__ */ _jsxDEV(MessageSquare, { className: "w-3 h-3" }, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 679,
																columnNumber: 29
															}, this)
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 671,
															columnNumber: 27
														}, this),
														/* @__PURE__ */ _jsxDEV("button", {
															onClick: () => handleForceDisconnect(session.username, session.deviceId),
															className: "p-1 rounded-lg bg-rose-500/10 text-rose-400 border border-rose-500/30 hover:bg-rose-500/20",
															title: "Force Disconnect Session",
															children: /* @__PURE__ */ _jsxDEV(Power, { className: "w-3 h-3" }, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 688,
																columnNumber: 29
															}, this)
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 683,
															columnNumber: 27
														}, this)
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 656,
													columnNumber: 25
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 655,
												columnNumber: 23
											}, this)
										]
									}, session.sessionId || `${session.username}-${session.deviceId}`, true, {
										fileName: _jsxFileName,
										lineNumber: 600,
										columnNumber: 21
									}, this);
								})
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 594,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 583,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 582,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 505,
				columnNumber: 9
			}, this),
			activeSubTab === "operators" && /* @__PURE__ */ _jsxDEV("div", {
				className: "bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800",
						children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
							className: "text-base font-extrabold text-white flex items-center gap-2",
							children: [/* @__PURE__ */ _jsxDEV("span", { children: "Authorized Operators (PC + Mobile Binding)" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 707,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20 font-mono",
								children: "1 PC + 1 Mobile Per ID"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 708,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 706,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-slate-400 mt-0.5",
							children: [
								"Each operator ID can work on ",
								/* @__PURE__ */ _jsxDEV("b", { children: "1 authorized PC" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 713,
									columnNumber: 46
								}, this),
								" AND ",
								/* @__PURE__ */ _jsxDEV("b", { children: "1 authorized Mobile" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 713,
									columnNumber: 73
								}, this),
								" at the same time. Third-party devices are blocked automatically."
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 712,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 705,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setShowAddModal(true),
							className: "flex items-center gap-1.5 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs px-3.5 py-2 rounded-xl shadow transition-all self-start sm:self-auto",
							children: [/* @__PURE__ */ _jsxDEV(UserPlus, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 721,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Register New Operator ID" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 722,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 717,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 704,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "p-3.5 rounded-xl bg-slate-950 border border-slate-800 text-xs flex items-center justify-between flex-wrap gap-2 text-slate-300",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2",
							children: [
								/* @__PURE__ */ _jsxDEV(Cpu, { className: "w-4 h-4 text-blue-400" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 729,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("span", { children: [
									"Your Current Machine (",
									currentIsMobile ? "📱 Mobile" : "💻 PC",
									"):"
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 730,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("code", {
									className: "text-white font-mono font-bold bg-slate-900 px-2 py-0.5 rounded border border-slate-700",
									children: currentDeviceId
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 731,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 728,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "text-slate-400 font-mono text-[11px]",
							children: currentDeviceName
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 735,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 727,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "overflow-x-auto",
						children: /* @__PURE__ */ _jsxDEV("table", {
							className: "w-full text-left text-xs",
							children: [/* @__PURE__ */ _jsxDEV("thead", { children: /* @__PURE__ */ _jsxDEV("tr", {
								className: "border-b border-slate-800 text-slate-400 uppercase tracking-wider font-semibold",
								children: [
									/* @__PURE__ */ _jsxDEV("th", {
										className: "py-3 px-3",
										children: "Operator / Username"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 743,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("th", {
										className: "py-3 px-3",
										children: "Role"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 744,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("th", {
										className: "py-3 px-3",
										children: "Authorized PC (1 Max)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 745,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("th", {
										className: "py-3 px-3",
										children: "Authorized Mobile (1 Max)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 746,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("th", {
										className: "py-3 px-3",
										children: "License Status"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 747,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("th", {
										className: "py-3 px-3 text-right",
										children: "Device & Renew Actions"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 748,
										columnNumber: 19
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 742,
								columnNumber: 17
							}, this) }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 741,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("tbody", {
								className: "divide-y divide-slate-800/60",
								children: operators.map((op) => {
									const daysLeft = calculateRemainingDays(op.validityExpiresAt);
									return /* @__PURE__ */ _jsxDEV("tr", {
										className: "hover:bg-slate-950/40 transition-colors",
										children: [
											/* @__PURE__ */ _jsxDEV("td", {
												className: "py-3 px-3",
												children: [/* @__PURE__ */ _jsxDEV("div", {
													className: "font-bold text-white text-sm",
													children: op.displayName
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 759,
													columnNumber: 25
												}, this), /* @__PURE__ */ _jsxDEV("div", {
													className: "text-slate-400 font-mono text-[11px]",
													children: [
														"@",
														op.username,
														" • ",
														op.phone
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 760,
													columnNumber: 25
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 758,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "py-3 px-3",
												children: /* @__PURE__ */ _jsxDEV("span", {
													className: `px-2 py-0.5 rounded text-[10px] font-bold uppercase font-mono ${op.role === "admin" ? "bg-purple-500/20 text-purple-300 border border-purple-500/30" : "bg-blue-500/20 text-blue-300 border border-blue-500/30"}`,
													children: op.role === "admin" ? "Master Admin" : "Operator"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 765,
													columnNumber: 25
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 764,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "py-3 px-3",
												children: op.boundPcDeviceId ? /* @__PURE__ */ _jsxDEV("div", {
													className: "space-y-0.5",
													children: [
														/* @__PURE__ */ _jsxDEV("div", {
															className: "flex items-center gap-1.5 font-bold text-blue-400",
															children: [/* @__PURE__ */ _jsxDEV(Laptop, { className: "w-3.5 h-3.5 text-blue-400" }, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 779,
																columnNumber: 31
															}, this), /* @__PURE__ */ _jsxDEV("span", {
																className: "font-mono text-[11px]",
																children: op.boundPcDeviceId
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 780,
																columnNumber: 31
															}, this)]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 778,
															columnNumber: 29
														}, this),
														/* @__PURE__ */ _jsxDEV("div", {
															className: "text-[10px] text-slate-400 truncate max-w-[160px]",
															children: op.boundPcDeviceName || "PC Workstation"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 782,
															columnNumber: 29
														}, this),
														/* @__PURE__ */ _jsxDEV("button", {
															onClick: () => handleResetPc(op.id, op.username),
															className: "text-[10px] text-amber-400 hover:underline flex items-center gap-0.5 font-bold pt-0.5",
															children: [/* @__PURE__ */ _jsxDEV(RotateCcw, { className: "w-2.5 h-2.5" }, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 787,
																columnNumber: 31
															}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Reset PC Binding" }, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 788,
																columnNumber: 31
															}, this)]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 783,
															columnNumber: 29
														}, this)
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 777,
													columnNumber: 27
												}, this) : /* @__PURE__ */ _jsxDEV("span", {
													className: "text-[10px] text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20 font-medium",
													children: "Unbound PC (Pending)"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 792,
													columnNumber: 27
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 775,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "py-3 px-3",
												children: op.boundMobileDeviceId ? /* @__PURE__ */ _jsxDEV("div", {
													className: "space-y-0.5",
													children: [
														/* @__PURE__ */ _jsxDEV("div", {
															className: "flex items-center gap-1.5 font-bold text-purple-400",
															children: [/* @__PURE__ */ _jsxDEV(Smartphone, { className: "w-3.5 h-3.5 text-purple-400" }, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 803,
																columnNumber: 31
															}, this), /* @__PURE__ */ _jsxDEV("span", {
																className: "font-mono text-[11px]",
																children: op.boundMobileDeviceId
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 804,
																columnNumber: 31
															}, this)]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 802,
															columnNumber: 29
														}, this),
														/* @__PURE__ */ _jsxDEV("div", {
															className: "text-[10px] text-slate-400 truncate max-w-[160px]",
															children: op.boundMobileDeviceName || "Smartphone"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 806,
															columnNumber: 29
														}, this),
														/* @__PURE__ */ _jsxDEV("button", {
															onClick: () => handleResetMobile(op.id, op.username),
															className: "text-[10px] text-amber-400 hover:underline flex items-center gap-0.5 font-bold pt-0.5",
															children: [/* @__PURE__ */ _jsxDEV(RotateCcw, { className: "w-2.5 h-2.5" }, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 811,
																columnNumber: 31
															}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Reset Mobile Binding" }, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 812,
																columnNumber: 31
															}, this)]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 807,
															columnNumber: 29
														}, this)
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 801,
													columnNumber: 27
												}, this) : /* @__PURE__ */ _jsxDEV("span", {
													className: "text-[10px] text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20 font-medium",
													children: "Unbound Mobile (Pending)"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 816,
													columnNumber: 27
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 799,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "py-3 px-3",
												children: /* @__PURE__ */ _jsxDEV("div", {
													className: "space-y-1",
													children: [/* @__PURE__ */ _jsxDEV("span", {
														className: "px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold text-[10px] font-mono flex items-center gap-1 w-fit",
														children: [/* @__PURE__ */ _jsxDEV(Calendar, { className: "w-3 h-3 text-emerald-400" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 826,
															columnNumber: 29
														}, this), /* @__PURE__ */ _jsxDEV("span", { children: [daysLeft, " Days Left"] }, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 827,
															columnNumber: 29
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 825,
														columnNumber: 27
													}, this), /* @__PURE__ */ _jsxDEV("button", {
														onClick: () => setSelectedOpForRenew(op),
														className: "text-[10px] text-sky-400 hover:underline font-bold block",
														children: "+ Renew Access"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 829,
														columnNumber: 27
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 824,
													columnNumber: 25
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 823,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "py-3 px-3 text-right",
												children: /* @__PURE__ */ _jsxDEV("div", {
													className: "flex items-center justify-end gap-1.5 flex-wrap",
													children: [
														(op.boundPcDeviceId || op.boundMobileDeviceId) && /* @__PURE__ */ _jsxDEV("button", {
															onClick: () => handleResetAllDevices(op.id, op.username),
															className: "px-2 py-1 rounded-lg bg-amber-500/10 text-amber-300 border border-amber-500/30 hover:bg-amber-500/20 font-bold text-[10px] transition-colors",
															title: "Reset both PC and Mobile bindings",
															children: "Reset All"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 843,
															columnNumber: 29
														}, this),
														op.role !== "admin" && /* @__PURE__ */ _jsxDEV("button", {
															onClick: () => handleToggleLock(op.id, op.username),
															className: `p-1.5 rounded-lg border text-xs ${op.isLocked ? "bg-emerald-500/10 text-emerald-300 border-emerald-500/30 hover:bg-emerald-500/20" : "bg-slate-800 text-slate-400 border-slate-700 hover:text-white"}`,
															title: op.isLocked ? "Unlock Operator" : "Suspend Operator",
															children: op.isLocked ? /* @__PURE__ */ _jsxDEV(Unlock, { className: "w-3.5 h-3.5" }, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 863,
																columnNumber: 46
															}, this) : /* @__PURE__ */ _jsxDEV(Lock, { className: "w-3.5 h-3.5" }, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 863,
																columnNumber: 83
															}, this)
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 854,
															columnNumber: 29
														}, this),
														op.role !== "admin" && /* @__PURE__ */ _jsxDEV("button", {
															onClick: () => handleDeleteOperator(op.id, op.username),
															className: "p-1.5 rounded-lg bg-rose-500/10 text-rose-400 border border-rose-500/20 hover:bg-rose-500/20 text-xs",
															title: "Delete Operator",
															children: /* @__PURE__ */ _jsxDEV(Trash2, { className: "w-3.5 h-3.5" }, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 874,
																columnNumber: 31
															}, this)
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 869,
															columnNumber: 29
														}, this)
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 840,
													columnNumber: 25
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 839,
												columnNumber: 23
											}, this)
										]
									}, op.id, true, {
										fileName: _jsxFileName,
										lineNumber: 756,
										columnNumber: 21
									}, this);
								})
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 751,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 740,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 739,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 703,
				columnNumber: 9
			}, this),
			activeSubTab === "workflow" && /* @__PURE__ */ _jsxDEV("div", {
				className: "bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800",
					children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
						className: "text-base font-extrabold text-white flex items-center gap-2",
						children: [
							/* @__PURE__ */ _jsxDEV(ClipboardList, { className: "w-5 h-5 text-amber-400" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 894,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("span", { children: "Cyber Cafe Standard Operating Procedure (SOP)" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 895,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20 font-mono",
								children: "Master Workflow"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 896,
								columnNumber: 17
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 893,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "text-xs text-slate-400 mt-0.5",
						children: "Standardized 6-stage operational protocol for all CSC & Cyber Cafe services"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 900,
						columnNumber: 15
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 892,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "bg-slate-950 px-3 py-1.5 rounded-xl border border-slate-800 text-xs font-mono text-slate-300",
						children: ["Checklist: ", /* @__PURE__ */ _jsxDEV("strong", {
							className: "text-emerald-400",
							children: [
								completedWorkflowCount,
								" / ",
								MASTER_WORKFLOW_STEPS.length,
								" Completed"
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 906,
							columnNumber: 26
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 905,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 891,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "grid grid-cols-1 md:grid-cols-2 gap-4",
					children: MASTER_WORKFLOW_STEPS.map((step) => {
						const isDone = !!completedSteps[step.stepNumber];
						return /* @__PURE__ */ _jsxDEV("div", {
							className: `p-4 rounded-xl border transition-all space-y-3 ${isDone ? "bg-slate-950/60 border-emerald-500/40" : "bg-slate-950 border-slate-800 hover:border-slate-700"}`,
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: `w-6 h-6 rounded-lg flex items-center justify-center font-bold text-xs font-mono ${isDone ? "bg-emerald-500 text-slate-950" : "bg-blue-600 text-white"}`,
											children: step.stepNumber
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 925,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("h3", {
											className: "font-extrabold text-white text-xs",
											children: step.title
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 930,
											columnNumber: 23
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 924,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("button", {
										onClick: () => setCompletedSteps((prev) => ({
											...prev,
											[step.stepNumber]: !prev[step.stepNumber]
										})),
										className: `flex items-center gap-1 text-[11px] font-bold px-2 py-0.5 rounded-md border ${isDone ? "bg-emerald-500/20 text-emerald-300 border-emerald-500/30" : "bg-slate-900 text-slate-400 border-slate-700"}`,
										children: [isDone ? /* @__PURE__ */ _jsxDEV(CheckCircle2, { className: "w-3.5 h-3.5 text-emerald-400" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 941,
											columnNumber: 33
										}, this) : /* @__PURE__ */ _jsxDEV(Circle, { className: "w-3.5 h-3.5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 941,
											columnNumber: 93
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: isDone ? "Done" : "Mark" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 942,
											columnNumber: 23
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 933,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 923,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-[11px] text-slate-300 leading-snug",
									children: step.description
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 946,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-1 pt-1 border-t border-slate-800/80",
									children: step.checklist.map((item, idx) => /* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-start gap-1.5 text-[11px] text-slate-400",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "text-blue-500",
											children: "•"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 951,
											columnNumber: 25
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: item }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 952,
											columnNumber: 25
										}, this)]
									}, idx, true, {
										fileName: _jsxFileName,
										lineNumber: 950,
										columnNumber: 23
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 948,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "p-2 rounded-lg bg-slate-900 text-[10px] text-amber-300/90 flex items-start gap-1.5",
									children: [/* @__PURE__ */ _jsxDEV(Sparkles, { className: "w-3 h-3 text-amber-400 flex-shrink-0 mt-0.5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 958,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: [
										/* @__PURE__ */ _jsxDEV("b", { children: "Operator Note:" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 959,
											columnNumber: 27
										}, this),
										" ",
										step.tips
									] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 959,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 957,
									columnNumber: 19
								}, this)
							]
						}, step.stepNumber, true, {
							fileName: _jsxFileName,
							lineNumber: 915,
							columnNumber: 17
						}, this);
					})
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 911,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 890,
				columnNumber: 9
			}, this),
			activeSubTab === "zip_download" && /* @__PURE__ */ _jsxDEV("div", {
				className: "bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-6",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-start gap-4",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "w-14 h-14 rounded-2xl bg-gradient-to-tr from-emerald-600/20 to-teal-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400 flex-shrink-0 shadow-inner",
							children: /* @__PURE__ */ _jsxDEV(Archive, { className: "w-7 h-7" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 973,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 972,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-1",
							children: [/* @__PURE__ */ _jsxDEV("h2", {
								className: "text-lg font-extrabold text-white",
								children: "Download Complete Original Project Source (.ZIP)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 976,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-slate-300 leading-relaxed",
								children: "Download the complete, standalone offline codebase of Muzammil Online Service suite containing all components, server, styles, package configuration, and assets."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 977,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 975,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 971,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "text-xs font-bold text-white block",
							children: "Archive Package Contents:"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 984,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2 text-xs text-slate-400",
							children: [
								/* @__PURE__ */ _jsxDEV("div", { children: "• PVC Smart Card Studio (CR-80)" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 986,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: "• Passport Photo Studio Pro" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 987,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: "• Fast POS Billing Desk & Receipts" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 988,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: "• Customer CRM & Ledger" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 989,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: "• BioData & CV Maker Engine" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 990,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: "• 50+ Govt Citizen Portals Hub" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 991,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: "• Dual Device Locking (PC + Mobile)" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 992,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: "• Live Monitoring & License Renewal" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 993,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: "• In-App Portal Browser & Downloader" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 994,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: "• Server.ts Express & Gemini Proxy" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 995,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 985,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 983,
						columnNumber: 11
					}, this),
					isExportingZip && /* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-2 p-4 rounded-xl bg-slate-950 border border-emerald-500/30 animate-pulse",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex justify-between text-xs text-emerald-400 font-bold",
							children: [/* @__PURE__ */ _jsxDEV("span", { children: ["Packing ZIP Archive: ", zipProgress.file] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1003,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: [zipProgress.percent, "%"] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1004,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1002,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "w-full bg-slate-800 h-2 rounded-full overflow-hidden",
							children: /* @__PURE__ */ _jsxDEV("div", {
								className: "bg-emerald-500 h-full transition-all duration-200",
								style: { width: `${zipProgress.percent}%` }
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1007,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1006,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1001,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-3 flex-wrap",
						children: [/* @__PURE__ */ _jsxDEV("button", {
							onClick: handleDownloadZip,
							disabled: isExportingZip,
							className: "flex items-center gap-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-extrabold text-sm px-6 py-3 rounded-xl shadow-lg shadow-emerald-600/30 transition-all hover:scale-105 disabled:opacity-50",
							children: [/* @__PURE__ */ _jsxDEV(Download, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1021,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: isExportingZip ? "Compressing Project..." : "Download Project .ZIP Archive" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1022,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1016,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("a", {
							href: "/api/download-zip",
							download: "Muzammil-Online-service-pc.zip",
							className: "text-xs text-blue-400 hover:underline flex items-center gap-1 font-semibold",
							children: /* @__PURE__ */ _jsxDEV("span", { children: "Direct Server Download Link" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1030,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1025,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1015,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 970,
				columnNumber: 9
			}, this),
			activeSubTab === "logs" && /* @__PURE__ */ _jsxDEV("div", {
				className: "bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center justify-between pb-3 border-b border-slate-800",
					children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
						className: "text-base font-extrabold text-white",
						children: "Real-Time Security & Device Audit Log"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 1041,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "text-xs text-slate-400",
						children: "Record of all authorized PC & Mobile logins, device locks, and blocked access attempts"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 1042,
						columnNumber: 15
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1040,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: loadData,
						className: "flex items-center gap-1 px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white text-xs font-semibold",
						children: [/* @__PURE__ */ _jsxDEV(RefreshCw, { className: "w-3.5 h-3.5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1048,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Refresh Logs" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1049,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1044,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 1039,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "overflow-x-auto max-h-96",
					children: /* @__PURE__ */ _jsxDEV("table", {
						className: "w-full text-left text-xs",
						children: [/* @__PURE__ */ _jsxDEV("thead", {
							className: "sticky top-0 bg-slate-900 border-b border-slate-800 text-slate-400",
							children: /* @__PURE__ */ _jsxDEV("tr", { children: [
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-2.5 px-3",
									children: "Timestamp"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1057,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-2.5 px-3",
									children: "Action"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1058,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-2.5 px-3",
									children: "Operator"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1059,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-2.5 px-3",
									children: "Type"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1060,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-2.5 px-3",
									children: "Device ID"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1061,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-2.5 px-3",
									children: "Details"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1062,
									columnNumber: 19
								}, this)
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1056,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1055,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("tbody", {
							className: "divide-y divide-slate-800/60 font-mono text-[11px]",
							children: auditLogs.length > 0 ? auditLogs.map((log) => /* @__PURE__ */ _jsxDEV("tr", {
								className: "hover:bg-slate-950/40",
								children: [
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-2.5 px-3 text-slate-400",
										children: log.timestamp
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1069,
										columnNumber: 23
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-2.5 px-3",
										children: /* @__PURE__ */ _jsxDEV("span", {
											className: `px-2 py-0.5 rounded text-[10px] font-bold ${log.action === "LOGIN_SUCCESS" ? "bg-emerald-500/20 text-emerald-400" : log.action === "DEVICE_BLOCKED" ? "bg-rose-500/20 text-rose-400" : log.action === "DEVICE_BOUND" ? "bg-blue-500/20 text-blue-400" : "bg-amber-500/20 text-amber-400"}`,
											children: log.action
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1071,
											columnNumber: 25
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1070,
										columnNumber: 23
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-2.5 px-3 text-white font-bold",
										children: ["@", log.username]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1083,
										columnNumber: 23
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-2.5 px-3 text-slate-400",
										children: log.deviceType === "mobile" ? "📱 Mobile" : "💻 PC"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1084,
										columnNumber: 23
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-2.5 px-3 text-slate-300",
										children: log.deviceId
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1085,
										columnNumber: 23
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-2.5 px-3 text-slate-400 max-w-xs truncate font-sans",
										children: log.details
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1086,
										columnNumber: 23
									}, this)
								]
							}, log.id, true, {
								fileName: _jsxFileName,
								lineNumber: 1068,
								columnNumber: 21
							}, this)) : /* @__PURE__ */ _jsxDEV("tr", { children: /* @__PURE__ */ _jsxDEV("td", {
								colSpan: 6,
								className: "py-6 text-center text-slate-500",
								children: "No security audit logs recorded yet."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1091,
								columnNumber: 21
							}, this) }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1090,
								columnNumber: 19
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1065,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1054,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 1053,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 1038,
				columnNumber: 9
			}, this),
			activeSubTab === "settings" && /* @__PURE__ */ _jsxDEV("div", {
				className: "bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-6",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800",
						children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
							className: "text-base font-extrabold text-white flex items-center gap-2",
							children: [/* @__PURE__ */ _jsxDEV(Key, { className: "w-5 h-5 text-blue-400" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1108,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Master Admin Workstation Setup & Control Center" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1109,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1107,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-slate-400 mt-0.5",
							children: "Centralized management for Shop Details, POS Rates, Hardware Settings, and Staff Security"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1111,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1106,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "bg-rose-500/10 text-rose-300 border border-rose-500/30 text-xs px-3 py-1 rounded-full font-bold w-fit",
							children: "Staff & Operator Access Only"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1116,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1105,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "p-4 rounded-xl bg-gradient-to-r from-rose-950/40 to-slate-950 border border-rose-500/30 space-y-2",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2 text-rose-400 font-extrabold text-xs",
							children: [/* @__PURE__ */ _jsxDEV(AlertCircle, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1124,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "ZERO CUSTOMER LOGIN ENFORCED (NO PUBLIC ACCESS)" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1125,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1123,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-slate-300 leading-relaxed",
							children: [
								"Is system mein ",
								/* @__PURE__ */ _jsxDEV("b", { children: "kisi bhi anjan customer ya public user ka login ya registration poori tarah band hai" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1128,
									columnNumber: 30
								}, this),
								". Sirf Master Admin ke dwara banaye gaye verified Staff Operator IDs hi login kar sakte hain. Sabhi citizen/customer details sirf shop ke internal ",
								/* @__PURE__ */ _jsxDEV("b", { children: "Customer CRM" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1130,
									columnNumber: 68
								}, this),
								" mein safe record ke taur par store hoti hain."
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1127,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1122,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("form", {
						onSubmit: handleSaveSettings,
						className: "space-y-6 text-xs",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-3",
								children: [/* @__PURE__ */ _jsxDEV("h3", {
									className: "font-extrabold text-white text-xs uppercase tracking-wider flex items-center gap-2 text-blue-400",
									children: /* @__PURE__ */ _jsxDEV("span", { children: "1. Shop Identity & Official Details" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1138,
										columnNumber: 17
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1137,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3",
									children: [
										/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "text-slate-400 block mb-1",
											children: "Shop / Center Name"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1143,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											value: shopForm.shopName,
											onChange: (e) => setShopForm({
												...shopForm,
												shopName: e.target.value
											}),
											className: "w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white font-bold"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1144,
											columnNumber: 19
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1142,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "text-slate-400 block mb-1",
											children: "Owner Name"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1153,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											value: shopForm.ownerName,
											onChange: (e) => setShopForm({
												...shopForm,
												ownerName: e.target.value
											}),
											className: "w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white font-bold"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1154,
											columnNumber: 19
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1152,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "text-slate-400 block mb-1",
											children: "WhatsApp / Contact Phone"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1163,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											value: shopForm.phone,
											onChange: (e) => setShopForm({
												...shopForm,
												phone: e.target.value
											}),
											className: "w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white font-bold"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1164,
											columnNumber: 19
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1162,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "text-slate-400 block mb-1",
											children: "UPI ID for Dynamic POS QR"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1173,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											value: shopForm.upiId,
											onChange: (e) => setShopForm({
												...shopForm,
												upiId: e.target.value
											}),
											className: "w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white font-bold font-mono"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1174,
											columnNumber: 19
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1172,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "sm:col-span-2",
											children: [/* @__PURE__ */ _jsxDEV("label", {
												className: "text-slate-400 block mb-1",
												children: "Address (Printed on Tax Invoices & Thermal Slips)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1183,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("input", {
												type: "text",
												value: shopForm.address,
												onChange: (e) => setShopForm({
													...shopForm,
													address: e.target.value
												}),
												className: "w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1184,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1182,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1141,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1136,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-3 pt-3 border-t border-slate-800",
								children: [/* @__PURE__ */ _jsxDEV("h3", {
									className: "font-extrabold text-white text-xs uppercase tracking-wider flex items-center gap-2 text-emerald-400",
									children: /* @__PURE__ */ _jsxDEV("span", { children: "2. Default POS Service Rates & Pricing (₹)" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1197,
										columnNumber: 17
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1196,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3",
									children: [
										/* @__PURE__ */ _jsxDEV("div", {
											className: "bg-slate-950 p-2.5 rounded-xl border border-slate-800",
											children: [/* @__PURE__ */ _jsxDEV("label", {
												className: "text-slate-400 block text-[11px] mb-1",
												children: "PVC Smart Card"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1202,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center gap-1 font-bold text-emerald-400",
												children: [/* @__PURE__ */ _jsxDEV("span", { children: "₹" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1204,
													columnNumber: 21
												}, this), /* @__PURE__ */ _jsxDEV("input", {
													type: "number",
													defaultValue: 0,
													placeholder: "0",
													className: "w-full bg-slate-900 border border-slate-700 rounded p-1 text-white font-mono text-xs"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1205,
													columnNumber: 21
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1203,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1201,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "bg-slate-950 p-2.5 rounded-xl border border-slate-800",
											children: [/* @__PURE__ */ _jsxDEV("label", {
												className: "text-slate-400 block text-[11px] mb-1",
												children: "Passport Photo (8x)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1215,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center gap-1 font-bold text-emerald-400",
												children: [/* @__PURE__ */ _jsxDEV("span", { children: "₹" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1217,
													columnNumber: 21
												}, this), /* @__PURE__ */ _jsxDEV("input", {
													type: "number",
													defaultValue: 0,
													placeholder: "0",
													className: "w-full bg-slate-900 border border-slate-700 rounded p-1 text-white font-mono text-xs"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1218,
													columnNumber: 21
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1216,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1214,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "bg-slate-950 p-2.5 rounded-xl border border-slate-800",
											children: [/* @__PURE__ */ _jsxDEV("label", {
												className: "text-slate-400 block text-[11px] mb-1",
												children: "Online Scheme Form"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1228,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center gap-1 font-bold text-emerald-400",
												children: [/* @__PURE__ */ _jsxDEV("span", { children: "₹" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1230,
													columnNumber: 21
												}, this), /* @__PURE__ */ _jsxDEV("input", {
													type: "number",
													defaultValue: 0,
													placeholder: "0",
													className: "w-full bg-slate-900 border border-slate-700 rounded p-1 text-white font-mono text-xs"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1231,
													columnNumber: 21
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1229,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1227,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "bg-slate-950 p-2.5 rounded-xl border border-slate-800",
											children: [/* @__PURE__ */ _jsxDEV("label", {
												className: "text-slate-400 block text-[11px] mb-1",
												children: "Exam Form (Police)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1241,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center gap-1 font-bold text-emerald-400",
												children: [/* @__PURE__ */ _jsxDEV("span", { children: "₹" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1243,
													columnNumber: 21
												}, this), /* @__PURE__ */ _jsxDEV("input", {
													type: "number",
													defaultValue: 0,
													placeholder: "0",
													className: "w-full bg-slate-900 border border-slate-700 rounded p-1 text-white font-mono text-xs"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1244,
													columnNumber: 21
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1242,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1240,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "bg-slate-950 p-2.5 rounded-xl border border-slate-800",
											children: [/* @__PURE__ */ _jsxDEV("label", {
												className: "text-slate-400 block text-[11px] mb-1",
												children: "BioData / CV"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1254,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center gap-1 font-bold text-emerald-400",
												children: [/* @__PURE__ */ _jsxDEV("span", { children: "₹" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1256,
													columnNumber: 21
												}, this), /* @__PURE__ */ _jsxDEV("input", {
													type: "number",
													defaultValue: 0,
													placeholder: "0",
													className: "w-full bg-slate-900 border border-slate-700 rounded p-1 text-white font-mono text-xs"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1257,
													columnNumber: 21
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1255,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1253,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "bg-slate-950 p-2.5 rounded-xl border border-slate-800",
											children: [/* @__PURE__ */ _jsxDEV("label", {
												className: "text-slate-400 block text-[11px] mb-1",
												children: "Thermal Lamination"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1267,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center gap-1 font-bold text-emerald-400",
												children: [/* @__PURE__ */ _jsxDEV("span", { children: "₹" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1269,
													columnNumber: 21
												}, this), /* @__PURE__ */ _jsxDEV("input", {
													type: "number",
													defaultValue: 0,
													placeholder: "0",
													className: "w-full bg-slate-900 border border-slate-700 rounded p-1 text-white font-mono text-xs"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1270,
													columnNumber: 21
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1268,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1266,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1200,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1195,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-3 pt-3 border-t border-slate-800",
								children: [/* @__PURE__ */ _jsxDEV("h3", {
									className: "font-extrabold text-white text-xs uppercase tracking-wider flex items-center gap-2 text-purple-400",
									children: /* @__PURE__ */ _jsxDEV("span", { children: "3. Hardware & Printing Standards" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1284,
										columnNumber: 17
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1283,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-1 sm:grid-cols-3 gap-3",
									children: [
										/* @__PURE__ */ _jsxDEV("div", {
											className: "bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1",
											children: [
												/* @__PURE__ */ _jsxDEV("label", {
													className: "text-slate-400 block font-bold",
													children: "PVC Card Resolution"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1289,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("div", {
													className: "text-white font-mono font-extrabold text-xs text-blue-400",
													children: "300 DPI Ultra HD"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1290,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("p", {
													className: "text-[10px] text-slate-500",
													children: "Optimized for Epson L805, L850 & Canon G-Series"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1291,
													columnNumber: 19
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1288,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1",
											children: [
												/* @__PURE__ */ _jsxDEV("label", {
													className: "text-slate-400 block font-bold",
													children: "Photo Studio Layout"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1295,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("div", {
													className: "text-white font-mono font-extrabold text-xs text-purple-400",
													children: "4×6 Inch (10×15 cm) Glossy"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1296,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("p", {
													className: "text-[10px] text-slate-500",
													children: "8 pre-aligned passport photos with border guide lines"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1297,
													columnNumber: 19
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1294,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1",
											children: [
												/* @__PURE__ */ _jsxDEV("label", {
													className: "text-slate-400 block font-bold",
													children: "POS Receipt Printer"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1301,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("div", {
													className: "text-white font-mono font-extrabold text-xs text-emerald-400",
													children: "58mm / 80mm Thermal ESC/POS"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1302,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("p", {
													className: "text-[10px] text-slate-500",
													children: "Zero-ink thermal paper with dynamic UPI QR code"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1303,
													columnNumber: 19
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1300,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1287,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1282,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "pt-2 flex items-center gap-3",
								children: /* @__PURE__ */ _jsxDEV("button", {
									type: "submit",
									className: "px-6 py-3 bg-blue-600 hover:bg-blue-500 text-white font-extrabold rounded-xl shadow-lg shadow-blue-600/30 transition-all hover:scale-105",
									children: "Save Master Setup Configuration"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1310,
									columnNumber: 15
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1309,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1134,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 1104,
				columnNumber: 9
			}, this),
			selectedOpForRenew && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed inset-0 bg-black/85 backdrop-blur-sm z-50 flex items-center justify-center p-4",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-slate-900 border border-slate-800 rounded-3xl max-w-md w-full p-6 shadow-2xl space-y-4 animate-in fade-in zoom-in-95",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between pb-2 border-b border-slate-800",
							children: [/* @__PURE__ */ _jsxDEV("h3", {
								className: "font-extrabold text-white text-base flex items-center gap-2",
								children: [/* @__PURE__ */ _jsxDEV(Calendar, { className: "w-5 h-5 text-emerald-400" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1327,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Renew License & Access Validity" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1328,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1326,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setSelectedOpForRenew(null),
								className: "text-slate-400 hover:text-white",
								children: "✕"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1330,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1325,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "p-3 bg-slate-950 rounded-xl border border-slate-800 text-xs space-y-1",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "text-white font-bold",
									children: selectedOpForRenew.displayName
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1334,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "text-slate-400 font-mono",
									children: [
										"@",
										selectedOpForRenew.username,
										" • ",
										selectedOpForRenew.phone
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1335,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "text-emerald-400 font-bold pt-1",
									children: [
										"Current Remaining: ",
										calculateRemainingDays(selectedOpForRenew.validityExpiresAt),
										" Days"
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1336,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1333,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-2 text-xs",
							children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "text-slate-300 font-bold block",
								children: "Select Extension Duration:"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1342,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-2 gap-2",
								children: [
									/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => setRenewDaysCount(30),
										className: `p-3 rounded-xl border font-bold text-center transition-all ${renewDaysCount === 30 ? "bg-blue-600 text-white border-blue-400 shadow" : "bg-slate-950 border-slate-800 text-slate-300 hover:bg-slate-800"}`,
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "text-sm",
											children: "+30 Days"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1353,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "text-[10px] text-slate-400",
											children: "1 Month Pass"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1354,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1344,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => setRenewDaysCount(90),
										className: `p-3 rounded-xl border font-bold text-center transition-all ${renewDaysCount === 90 ? "bg-blue-600 text-white border-blue-400 shadow" : "bg-slate-950 border-slate-800 text-slate-300 hover:bg-slate-800"}`,
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "text-sm",
											children: "+90 Days"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1366,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "text-[10px] text-slate-400",
											children: "Quarterly Pass"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1367,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1357,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => setRenewDaysCount(365),
										className: `p-3 rounded-xl border font-bold text-center transition-all ${renewDaysCount === 365 ? "bg-blue-600 text-white border-blue-400 shadow" : "bg-slate-950 border-slate-800 text-slate-300 hover:bg-slate-800"}`,
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "text-sm",
											children: "+365 Days"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1379,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "text-[10px] text-slate-400",
											children: "Annual License"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1380,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1370,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => setRenewDaysCount(3650),
										className: `p-3 rounded-xl border font-bold text-center transition-all ${renewDaysCount === 3650 ? "bg-emerald-600 text-white border-emerald-400 shadow" : "bg-slate-950 border-slate-800 text-slate-300 hover:bg-slate-800"}`,
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "text-sm",
											children: "Lifetime"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1392,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "text-[10px] text-slate-400",
											children: "Permanent Access"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1393,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1383,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1343,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1341,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "pt-2 flex items-center justify-end gap-2",
							children: [/* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => setSelectedOpForRenew(null),
								className: "px-4 py-2 bg-slate-800 text-slate-300 font-bold rounded-xl text-xs",
								children: "Cancel"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1399,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: handleExecuteRenewal,
								className: "px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold rounded-xl shadow text-xs flex items-center gap-1.5",
								children: [/* @__PURE__ */ _jsxDEV(Check, { className: "w-4 h-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1411,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Confirm & Apply Renewal" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1412,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1406,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1398,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 1324,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 1323,
				columnNumber: 9
			}, this),
			broadcastTargetUsername && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed inset-0 bg-black/85 backdrop-blur-sm z-50 flex items-center justify-center p-4",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-slate-900 border border-slate-800 rounded-3xl max-w-md w-full p-6 shadow-2xl space-y-4",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between pb-2 border-b border-slate-800",
							children: [/* @__PURE__ */ _jsxDEV("h3", {
								className: "font-extrabold text-white text-base flex items-center gap-2",
								children: [/* @__PURE__ */ _jsxDEV(MessageSquare, { className: "w-5 h-5 text-sky-400" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1425,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: ["Send Alert to @", broadcastTargetUsername] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1426,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1424,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setBroadcastTargetUsername(null),
								className: "text-slate-400 hover:text-white",
								children: "✕"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1428,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1423,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-slate-300",
							children: "This message will pop up immediately on the operator's computer or mobile screen."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1431,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("textarea", {
							rows: 3,
							value: broadcastMessageText,
							onChange: (e) => setBroadcastMessageText(e.target.value),
							placeholder: "e.g. Please check Ladki Bahin payment slip before handing over to customer.",
							className: "w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-white text-xs"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1435,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex justify-end gap-2",
							children: [/* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setBroadcastTargetUsername(null),
								className: "px-4 py-2 bg-slate-800 text-slate-300 font-bold rounded-xl text-xs",
								children: "Cancel"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1444,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: handleSendBroadcast,
								className: "px-5 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl shadow text-xs flex items-center gap-1.5",
								children: [/* @__PURE__ */ _jsxDEV(Send, { className: "w-3.5 h-3.5" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1454,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Send Toast Alert" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1455,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1450,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1443,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 1422,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 1421,
				columnNumber: 9
			}, this),
			showAddModal && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-slate-900 border border-slate-800 rounded-3xl max-w-md w-full p-6 shadow-2xl space-y-4 animate-in fade-in zoom-in-95",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between pb-2 border-b border-slate-800",
							children: [/* @__PURE__ */ _jsxDEV("h3", {
								className: "font-extrabold text-white text-base flex items-center gap-2",
								children: [/* @__PURE__ */ _jsxDEV(UserPlus, { className: "w-5 h-5 text-blue-400" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1468,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Register New Operator ID" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1469,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1467,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setShowAddModal(false),
								className: "text-slate-400 hover:text-white",
								children: "✕"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1471,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1466,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-slate-300",
							children: [
								"This new operator ID will bind to ",
								/* @__PURE__ */ _jsxDEV("b", { children: "1 Authorized PC" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1475,
									columnNumber: 49
								}, this),
								" + ",
								/* @__PURE__ */ _jsxDEV("b", { children: "1 Authorized Mobile" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1475,
									columnNumber: 74
								}, this),
								" upon their first login from each device."
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1474,
							columnNumber: 13
						}, this),
						addError && /* @__PURE__ */ _jsxDEV("div", {
							className: "p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs",
							children: addError
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1479,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("form", {
							onSubmit: handleCreateOperator,
							className: "space-y-3 text-xs",
							children: [
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "text-slate-400 block mb-1",
									children: "Operator Full Name"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1486,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									required: true,
									placeholder: "e.g. Shaikh Sameer",
									value: newDisplayName,
									onChange: (e) => setNewDisplayName(e.target.value),
									className: "w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white font-bold"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1487,
									columnNumber: 17
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1485,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "text-slate-400 block mb-1",
									children: "Username (Login ID)"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1498,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									required: true,
									placeholder: "e.g. operator3",
									value: newUsername,
									onChange: (e) => setNewUsername(e.target.value),
									className: "w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white font-mono font-bold"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1499,
									columnNumber: 17
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1497,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "text-slate-400 block mb-1",
									children: "Password"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1510,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "password",
									required: true,
									placeholder: "Create secure password",
									value: newPassword,
									onChange: (e) => setNewPassword(e.target.value),
									className: "w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1511,
									columnNumber: 17
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1509,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "text-slate-400 block mb-1",
									children: "Phone Number"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1522,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "tel",
									placeholder: "Mobile number",
									value: newPhone,
									onChange: (e) => setNewPhone(e.target.value),
									className: "w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1523,
									columnNumber: 17
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1521,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "pt-2 flex items-center justify-end gap-2",
									children: [/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => setShowAddModal(false),
										className: "px-4 py-2 bg-slate-800 text-slate-300 font-bold rounded-xl",
										children: "Cancel"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1533,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("button", {
										type: "submit",
										className: "px-5 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl shadow",
										children: "Register Operator"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1540,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1532,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1484,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 1465,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 1464,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 384,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsaUJBQWlCO0FBQzNDLFNBQ0UsYUFDQSxNQUNBLFFBQ0EsWUFDQSxRQUNBLFdBQ0EsVUFDQSxRQUNBLFVBQ0EsY0FDQSxhQUNBLE9BQ0EsS0FHQSxPQUNBLFNBQ0EsV0FDQSxLQUNBLFNBQ0EsZUFDQSxVQUNBLFFBRUEsVUFDQSxPQUNBLE9BQ0EsZUFDQSxNQUNBLGdCQUlLO0FBRVAsU0FDRSx3QkFDQSx3QkFDQSw0QkFDQSwwQkFDQSxvQkFDQSxnQkFDQSxnQkFDQSxzQkFFQSxxQkFDQSx1QkFDQSxnQkFDQSxzQkFDQSx3QkFDQSx5QkFDQSx5QkFDQSxvQ0FDSztBQUNQLFNBQVMsb0JBQW9CLDBCQUEwQjs7O0FBaUJ2RCxNQUFNLHdCQUF3QztDQUM1QztFQUNFLFlBQVk7RUFDWixPQUFPO0VBQ1AsYUFBYTtFQUNiLFdBQVc7R0FBQztHQUFhO0dBQXdCO0VBQWM7RUFDL0QsV0FBVztHQUNUO0dBQ0E7R0FDQTtHQUNBO0VBQ0Y7RUFDQSxNQUFNO0NBQ1I7Q0FDQTtFQUNFLFlBQVk7RUFDWixPQUFPO0VBQ1AsYUFBYTtFQUNiLFdBQVcsQ0FBQyw4QkFBOEIseUJBQXlCO0VBQ25FLFdBQVc7R0FDVDtHQUNBO0dBQ0E7R0FDQTtFQUNGO0VBQ0EsTUFBTTtDQUNSO0NBQ0E7RUFDRSxZQUFZO0VBQ1osT0FBTztFQUNQLGFBQWE7RUFDYixXQUFXLENBQUMsd0JBQXdCLDJCQUEyQjtFQUMvRCxXQUFXO0dBQ1Q7R0FDQTtHQUNBO0dBQ0E7R0FDQTtFQUNGO0VBQ0EsTUFBTTtDQUNSO0NBQ0E7RUFDRSxZQUFZO0VBQ1osT0FBTztFQUNQLGFBQWE7RUFDYixXQUFXLENBQUMsdUNBQXVDO0VBQ25ELFdBQVc7R0FDVDtHQUNBO0dBQ0E7R0FDQTtFQUNGO0VBQ0EsTUFBTTtDQUNSO0NBQ0E7RUFDRSxZQUFZO0VBQ1osT0FBTztFQUNQLGFBQWE7RUFDYixXQUFXLENBQUMsdUJBQXVCO0VBQ25DLFdBQVc7R0FDVDtHQUNBO0dBQ0E7R0FDQTtFQUNGO0VBQ0EsTUFBTTtDQUNSO0NBQ0E7RUFDRSxZQUFZO0VBQ1osT0FBTztFQUNQLGFBQWE7RUFDYixXQUFXLENBQUMsNEJBQTRCO0VBQ3hDLFdBQVc7R0FDVDtHQUNBO0dBQ0E7R0FDQTtFQUNGO0VBQ0EsTUFBTTtDQUNSO0FBQ0Y7QUFFQSxPQUFPLE1BQU0sbUJBQW1ELEVBQzlELFVBQ0Esa0JBQ0EsMkJBQ0k7Q0FDSixNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBNEIsQ0FBQyxDQUFDO0NBQ2hFLE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUE2QixDQUFDLENBQUM7Q0FDakUsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQTJGLGNBQWM7O0NBR2pKLE1BQU0sQ0FBQyxjQUFjLG1CQUFtQixTQUFnQyxDQUFDLENBQUM7Q0FDMUUsTUFBTSxDQUFDLGtCQUFrQix1QkFBdUIsU0FBa0IsSUFBSTtDQUN0RSxNQUFNLENBQUMsaUJBQWlCLHNCQUFzQixTQUFpQixFQUFFOztDQUdqRSxNQUFNLENBQUMsb0JBQW9CLHlCQUF5QixTQUFpQyxJQUFJO0NBQ3pGLE1BQU0sQ0FBQyxnQkFBZ0IscUJBQXFCLFNBQWlCLEVBQUU7O0NBRy9ELE1BQU0sQ0FBQyx5QkFBeUIsOEJBQThCLFNBQXdCLElBQUk7Q0FDMUYsTUFBTSxDQUFDLHNCQUFzQiwyQkFBMkIsU0FBaUIsRUFBRTs7Q0FHM0UsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQWtCLEtBQUs7Q0FDL0QsTUFBTSxDQUFDLGFBQWEsa0JBQWtCLFNBQWlCLEVBQUU7Q0FDekQsTUFBTSxDQUFDLGFBQWEsa0JBQWtCLFNBQWlCLEVBQUU7Q0FDekQsTUFBTSxDQUFDLGdCQUFnQixxQkFBcUIsU0FBaUIsRUFBRTtDQUMvRCxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQWlCLEVBQUU7Q0FDbkQsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFpQixFQUFFOztDQUduRCxNQUFNLENBQUMsZ0JBQWdCLHFCQUFxQixTQUFrQixLQUFLO0NBQ25FLE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUE0QztFQUFFLFNBQVM7RUFBRyxNQUFNO0NBQUcsQ0FBQzs7Q0FHMUcsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQXdCLElBQUk7O0NBR3BFLE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBdUIsUUFBUTs7Q0FHL0QsTUFBTSxDQUFDLGdCQUFnQixxQkFBcUIsU0FBa0MsQ0FBQyxDQUFDO0NBRWhGLE1BQU0sa0JBQWtCLG9CQUFvQjtDQUM1QyxNQUFNLG9CQUFvQixzQkFBc0I7Q0FDaEQsTUFBTSxrQkFBa0IsZUFBZTtDQUV2QyxNQUFNLGlCQUFpQjtFQUNyQixhQUFhLHVCQUF1QixDQUFDO0VBQ3JDLGFBQWEscUJBQXFCLENBQUM7Q0FDckM7Q0FFQSxNQUFNLHNCQUFzQixZQUFZO0VBQ3RDLElBQUk7R0FDRixNQUFNLFdBQVcsTUFBTSx3QkFBd0I7R0FDL0MsZ0JBQWdCLFFBQVE7R0FDeEIsbUJBQW1CLElBQUksS0FBSyxDQUFDLENBQUMsbUJBQW1CLENBQUM7RUFDcEQsU0FBUyxHQUFHO0dBQ1YsUUFBUSxNQUFNLENBQUM7RUFDakI7Q0FDRjtDQUVBLGdCQUFnQjtFQUNkLFNBQVM7RUFDVCxvQkFBb0I7Q0FDdEIsR0FBRyxDQUFDLENBQUM7O0NBR0wsZ0JBQWdCO0VBQ2QsSUFBSSxDQUFDLGtCQUFrQjtFQUN2QixNQUFNLFdBQVcsa0JBQWtCO0dBQ2pDLG9CQUFvQjtFQUN0QixHQUFHLElBQUk7RUFDUCxhQUFhLGNBQWMsUUFBUTtDQUNyQyxHQUFHLENBQUMsZ0JBQWdCLENBQUM7O0NBR3JCLE1BQU0sNkJBQTZCO0VBQ2pDLElBQUksQ0FBQyxvQkFBb0I7RUFDekIsTUFBTSxTQUFTLHFCQUFxQixtQkFBbUIsSUFBSSxjQUFjO0VBQ3pFLElBQUksT0FBTyxTQUFTO0dBQ2xCLFNBQVM7R0FDVCxvQkFBb0I7R0FDcEIsZ0JBQWdCLHlCQUF5QixtQkFBbUIsWUFBWSxpQkFBaUIsT0FBTyxVQUFVLElBQUksT0FBTyxTQUFTLGlCQUFpQjtHQUMvSSxzQkFBc0IsSUFBSTtHQUMxQixpQkFBaUIsZ0JBQWdCLElBQUksR0FBRyxHQUFJO0VBQzlDO0NBQ0Y7O0NBR0EsTUFBTSx3QkFBd0IsT0FBTyxVQUFrQixhQUFzQjtFQUMzRSxJQUFJLE9BQU8sUUFBUSx1Q0FBdUMsU0FBUywyQ0FBMkMsR0FBRztHQUMvRyxNQUFNLHdCQUF3QixVQUFVLFFBQVE7R0FDaEQsb0JBQW9CO0dBQ3BCLGdCQUFnQixtQkFBbUIsU0FBUyxpQ0FBaUM7R0FDN0UsaUJBQWlCLGdCQUFnQixJQUFJLEdBQUcsR0FBSTtFQUM5QztDQUNGOztDQUdBLE1BQU0sc0JBQXNCLFlBQVk7RUFDdEMsSUFBSSxDQUFDLDJCQUEyQixDQUFDLHFCQUFxQixLQUFLLEdBQUc7RUFDOUQsTUFBTSw2QkFBNkIseUJBQXlCLHFCQUFxQixLQUFLLENBQUM7RUFDdkYsZ0JBQWdCLDZCQUE2Qix3QkFBd0IsRUFBRTtFQUN2RSwyQkFBMkIsSUFBSTtFQUMvQix3QkFBd0IsRUFBRTtFQUMxQixpQkFBaUIsZ0JBQWdCLElBQUksR0FBRyxHQUFJO0NBQzlDOztDQUdBLE1BQU0saUJBQWlCLFlBQW9CLGFBQXFCO0VBQzlELElBQUksT0FBTyxRQUFRLGdDQUFnQyxTQUFTLCtDQUErQyxHQUFHO0dBQzVHLHVCQUF1QixVQUFVO0dBQ2pDLFNBQVM7R0FDVCxvQkFBb0I7R0FDcEIsZ0JBQWdCLG1DQUFtQyxTQUFTLDhCQUE4QjtHQUMxRixpQkFBaUIsZ0JBQWdCLElBQUksR0FBRyxHQUFJO0VBQzlDO0NBQ0Y7O0NBR0EsTUFBTSxxQkFBcUIsWUFBb0IsYUFBcUI7RUFDbEUsSUFBSSxPQUFPLFFBQVEsb0NBQW9DLFNBQVMsZ0RBQWdELEdBQUc7R0FDakgsMkJBQTJCLFVBQVU7R0FDckMsU0FBUztHQUNULG9CQUFvQjtHQUNwQixnQkFBZ0IsdUNBQXVDLFNBQVMsaUNBQWlDO0dBQ2pHLGlCQUFpQixnQkFBZ0IsSUFBSSxHQUFHLEdBQUk7RUFDOUM7Q0FDRjs7Q0FHQSxNQUFNLHlCQUF5QixZQUFvQixhQUFxQjtFQUN0RSxJQUFJLE9BQU8sUUFBUSx3Q0FBd0MsU0FBUyxHQUFHLEdBQUc7R0FDeEUseUJBQXlCLFVBQVU7R0FDbkMsU0FBUztHQUNULG9CQUFvQjtHQUNwQixnQkFBZ0IsbURBQW1ELFNBQVMsRUFBRTtHQUM5RSxpQkFBaUIsZ0JBQWdCLElBQUksR0FBRyxHQUFJO0VBQzlDO0NBQ0Y7O0NBR0EsTUFBTSxvQkFBb0IsWUFBb0IsYUFBcUI7RUFDakUsbUJBQW1CLFVBQVU7RUFDN0IsU0FBUztFQUNULG9CQUFvQjtFQUNwQixnQkFBZ0IsMkJBQTJCLFVBQVU7RUFDckQsaUJBQWlCLGdCQUFnQixJQUFJLEdBQUcsR0FBSTtDQUM5Qzs7Q0FHQSxNQUFNLHdCQUF3QixZQUFvQixhQUFxQjtFQUNyRSxJQUFJLE9BQU8sUUFBUSx3Q0FBd0MsU0FBUyxHQUFHLEdBQUc7R0FDeEUsZUFBZSxVQUFVO0dBQ3pCLFNBQVM7R0FDVCxvQkFBb0I7R0FDcEIsZ0JBQWdCLFlBQVksU0FBUyxTQUFTO0dBQzlDLGlCQUFpQixnQkFBZ0IsSUFBSSxHQUFHLEdBQUk7RUFDOUM7Q0FDRjs7Q0FHQSxNQUFNLHdCQUF3QixNQUF1QjtFQUNuRCxFQUFFLGVBQWU7RUFDakIsWUFBWSxFQUFFO0VBRWQsSUFBSSxDQUFDLFlBQVksS0FBSyxLQUFLLENBQUMsWUFBWSxLQUFLLEtBQUssQ0FBQyxlQUFlLEtBQUssR0FBRztHQUN4RSxZQUFZLGlDQUFpQztHQUM3QztFQUNGO0VBRUEsTUFBTSxVQUFVLGVBQWU7R0FDN0IsVUFBVSxZQUFZLEtBQUssQ0FBQyxDQUFDLFlBQVk7R0FDekMsVUFBVSxZQUFZLEtBQUs7R0FDM0IsYUFBYSxlQUFlLEtBQUs7R0FDakMsTUFBTTtHQUNOLE9BQU8sU0FBUyxLQUFLLEtBQUs7RUFDNUIsQ0FBQztFQUVELElBQUksU0FBUztHQUNYLGdCQUFnQixLQUFLO0dBQ3JCLGVBQWUsRUFBRTtHQUNqQixlQUFlLEVBQUU7R0FDakIsa0JBQWtCLEVBQUU7R0FDcEIsWUFBWSxFQUFFO0dBQ2QsU0FBUztHQUNULG9CQUFvQjtHQUNwQixnQkFBZ0IsZ0ZBQWdGO0dBQ2hHLGlCQUFpQixnQkFBZ0IsSUFBSSxHQUFHLEdBQUk7RUFDOUMsT0FBTztHQUNMLFlBQVksMERBQTBEO0VBQ3hFO0NBQ0Y7O0NBR0EsTUFBTSxvQkFBb0IsWUFBWTtFQUNwQyxrQkFBa0IsSUFBSTtFQUN0QixlQUFlO0dBQUUsU0FBUztHQUFJLE1BQU07RUFBb0MsQ0FBQztFQUV6RSxJQUFJO0dBQ0YsTUFBTSxVQUFVLE1BQU0sb0JBQW9CLFNBQVMsU0FBUztJQUMxRCxlQUFlO0tBQUU7S0FBUztJQUFLLENBQUM7R0FDbEMsQ0FBQztHQUVELG1CQUFtQixTQUFTLGdDQUFnQztHQUM1RCxnQkFBZ0IsMEVBQTBFO0dBQzFGLGlCQUFpQixnQkFBZ0IsSUFBSSxHQUFHLEdBQUk7RUFDOUMsU0FBUyxHQUFHO0dBQ1YsUUFBUSxNQUFNLENBQUM7R0FDZixPQUFPLFNBQVMsT0FBTztFQUN6QixVQUFVO0dBQ1Isa0JBQWtCLEtBQUs7RUFDekI7Q0FDRjs7Q0FHQSxNQUFNLHNCQUFzQixNQUF1QjtFQUNqRCxFQUFFLGVBQWU7RUFDakIsaUJBQWlCLFFBQVE7RUFDekIsZ0JBQWdCLHlDQUF5QztFQUN6RCxpQkFBaUIsZ0JBQWdCLElBQUksR0FBRyxHQUFJO0NBQzlDO0NBRUEsTUFBTSx5QkFBeUIsT0FBTyxPQUFPLGNBQWMsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUM7Q0FDN0UsTUFBTSxjQUFjLGFBQWEsUUFBTyxNQUFLLEVBQUUsUUFBUSxDQUFDLENBQUM7Q0FFekQsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmO0dBRUUsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQWQsQ0FDRSx3QkFBQyxhQUFELEVBQWEsV0FBVSx3QkFBeUI7Ozs7Z0JBQ2hELHdCQUFDLFFBQUQsWUFBTSw2Q0FBZ0Q7Ozs7Y0FDcEQ7Ozs7O2VBQ0osd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQWhCLENBQ0Usd0JBQUMsUUFBRCxFQUFNLFdBQVUsb0RBQTBEOzs7O2dCQUMxRSx3QkFBQyxRQUFEO09BQU07T0FBTztPQUFZO01BQW9COzs7O2NBQ3pDOzs7OzthQUNIOzs7OztjQUNMLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQThCO0lBRXhDOzs7O1lBQ0E7Ozs7Y0FHTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNiLHdCQUFDLFVBQUQ7TUFDRSxTQUFTO01BQ1QsVUFBVTtNQUNWLFdBQVU7TUFDVixPQUFNO2dCQUpSLENBTUUsd0JBQUMsU0FBRCxFQUFTLFdBQVUsVUFBVzs7OztnQkFDOUIsd0JBQUMsUUFBRCxZQUFPLGlCQUFpQixtQkFBbUIsMkJBQWlDOzs7O2NBQ3RFOzs7Ozs7SUFDTDs7OztZQUNGOzs7Ozs7R0FHSixnQkFDQyx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLGNBQUQsRUFBYyxXQUFVLHlDQUEwQzs7OztlQUNsRSx3QkFBQyxRQUFELFlBQU8sYUFBbUI7Ozs7YUFDdkI7Ozs7O2NBQ0wsd0JBQUMsVUFBRDtLQUFRLGVBQWUsZ0JBQWdCLElBQUk7S0FBRyxXQUFVO2VBQW9DO0lBQVM7Ozs7WUFDbEc7Ozs7OztHQUlQLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FDRSx3QkFBQyxVQUFEO01BQ0UsZUFBZSxnQkFBZ0IsY0FBYztNQUM3QyxXQUFXLGlFQUNULGlCQUFpQixpQkFDYixrQ0FDQTtnQkFMUixDQVFFLHdCQUFDLE9BQUQsRUFBTyxXQUFVLHVDQUF3Qzs7OztnQkFDekQsd0JBQUMsUUFBRDtPQUFNO09BQTJCO09BQVk7TUFBTzs7OztjQUM5Qzs7Ozs7O0tBRVIsd0JBQUMsVUFBRDtNQUNFLGVBQWUsZ0JBQWdCLFdBQVc7TUFDMUMsV0FBVyxpRUFDVCxpQkFBaUIsY0FDYixrQ0FDQTtnQkFMUixDQVFFLHdCQUFDLFNBQUQsRUFBUyxXQUFVLGNBQWU7Ozs7Z0JBQ2xDLHdCQUFDLFFBQUQ7T0FBTTtPQUF1QixVQUFVO09BQU87TUFBTzs7OztjQUMvQzs7Ozs7O0tBRVIsd0JBQUMsVUFBRDtNQUNFLGVBQWUsZ0JBQWdCLFVBQVU7TUFDekMsV0FBVyxpRUFDVCxpQkFBaUIsYUFDYixrQ0FDQTtnQkFMUixDQVFFLHdCQUFDLGVBQUQsRUFBZSxXQUFVLDZCQUE4Qjs7OztnQkFDdkQsd0JBQUMsUUFBRCxZQUFNLDRCQUErQjs7OztjQUMvQjs7Ozs7O0tBRVIsd0JBQUMsVUFBRDtNQUNFLGVBQWUsZ0JBQWdCLGNBQWM7TUFDN0MsV0FBVyxpRUFDVCxpQkFBaUIsaUJBQ2Isa0NBQ0E7Z0JBTFIsQ0FRRSx3QkFBQyxTQUFELEVBQVMsV0FBVSwrQkFBZ0M7Ozs7Z0JBQ25ELHdCQUFDLFFBQUQsWUFBTSx3QkFBMkI7Ozs7Y0FDM0I7Ozs7OztLQUVSLHdCQUFDLFVBQUQ7TUFDRSxlQUFlLGdCQUFnQixNQUFNO01BQ3JDLFdBQVcsaUVBQ1QsaUJBQWlCLFNBQ2Isa0NBQ0E7Z0JBTFIsQ0FRRSx3QkFBQyxPQUFELEVBQU8sV0FBVSxjQUFlOzs7O2dCQUNoQyx3QkFBQyxRQUFELFlBQU0seUJBQTRCOzs7O2NBQzVCOzs7Ozs7S0FFUix3QkFBQyxVQUFEO01BQ0UsZUFBZSxnQkFBZ0IsVUFBVTtNQUN6QyxXQUFXLGlFQUNULGlCQUFpQixhQUNiLGtDQUNBO2dCQUxSLENBUUUsd0JBQUMsS0FBRCxFQUFLLFdBQVUsY0FBZTs7OztnQkFDOUIsd0JBQUMsUUFBRCxZQUFNLHNCQUF5Qjs7OztjQUN6Qjs7Ozs7O0lBQ0w7Ozs7OztHQUdKLGlCQUFpQixrQkFDaEIsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUFkO1FBQ0Usd0JBQUMsT0FBRCxFQUFPLFdBQVUsc0NBQXVDOzs7OztRQUN4RCx3QkFBQyxRQUFELFlBQU0sMkNBQThDOzs7OztRQUNwRCx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBd0c7UUFFbEg7Ozs7O09BQ0o7Ozs7O2dCQUNKLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUFnQztNQUUxQzs7OztjQUNBOzs7O2dCQUVMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsVUFBRDtRQUNFLGVBQWUsb0JBQW9CLENBQUMsZ0JBQWdCO1FBQ3BELFdBQVcsK0ZBQ1QsbUJBQ0ksNkRBQ0E7a0JBTFIsQ0FRRSx3QkFBQyxVQUFELEVBQVUsV0FBVSxjQUFlOzs7O2tCQUNuQyx3QkFBQyxRQUFELFlBQU8sbUJBQW1CLG9CQUFvQixTQUFlOzs7O2dCQUN2RDs7Ozs7aUJBRVIsd0JBQUMsVUFBRDtRQUNFLFNBQVM7UUFDVCxXQUFVO1FBQ1YsT0FBTTtrQkFFTix3QkFBQyxXQUFELEVBQVcsV0FBVSxjQUFlOzs7OztPQUM5Qjs7OztlQUNMOzs7OztjQUNGOzs7Ozs7S0FHTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQW1DO1NBQXlCOzs7OztTQUM1RSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLFFBQUQsRUFBTSxXQUFVLHVEQUE2RDs7OztvQkFDN0Usd0JBQUMsUUFBRCxZQUFPLFlBQWtCOzs7O2tCQUN0Qjs7Ozs7O1NBQ0wsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQXlDO1NBQTBCOzs7OztRQUNoRjs7Ozs7O09BRUwsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBbUM7U0FBNEI7Ozs7O1NBQy9FLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsUUFBRCxFQUFRLFdBQVUsVUFBVzs7OztvQkFDN0Isd0JBQUMsUUFBRCxZQUFPLGFBQWEsUUFBTyxNQUFLLEVBQUUsZUFBZSxRQUFRLEVBQUUsUUFBUSxDQUFDLENBQUMsT0FBYTs7OztrQkFDL0U7Ozs7OztTQUNMLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUE2QjtTQUEwQjs7Ozs7UUFDcEU7Ozs7OztPQUVMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQW1DO1NBQTRCOzs7OztTQUMvRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLFlBQUQsRUFBWSxXQUFVLFVBQVc7Ozs7b0JBQ2pDLHdCQUFDLFFBQUQsWUFBTyxhQUFhLFFBQU8sTUFBSyxFQUFFLGVBQWUsWUFBWSxFQUFFLFFBQVEsQ0FBQyxDQUFDLE9BQWE7Ozs7a0JBQ25GOzs7Ozs7U0FDTCx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBNkI7U0FBdUI7Ozs7O1FBQ2pFOzs7Ozs7T0FFTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFtQztTQUF1Qjs7Ozs7U0FDMUUsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQ1osbUJBQW1CO1NBQ2pCOzs7OztTQUNMLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUE2QjtTQUFvQjs7Ozs7UUFDOUQ7Ozs7OztNQUNGOzs7Ozs7S0FHTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFDYix3QkFBQyxTQUFEO09BQU8sV0FBVTtpQkFBakIsQ0FDRSx3QkFBQyxTQUFELFlBQ0Usd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQWQ7U0FDRSx3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFBWTtTQUFlOzs7OztTQUN6Qyx3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFBWTtTQUFpQjs7Ozs7U0FDM0Msd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQVk7U0FBb0I7Ozs7O1NBQzlDLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUFZO1NBQXdCOzs7OztTQUNsRCx3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFBWTtTQUFvQjs7Ozs7U0FDOUMsd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQXVCO1NBQWlCOzs7OztRQUNwRDs7Ozs7Z0JBQ0M7Ozs7aUJBQ1Asd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQ2QsYUFBYSxLQUFLLFlBQVk7U0FDN0IsTUFBTSxXQUFXLHVCQUF1QixRQUFRLGlCQUFpQjtTQUNqRSxNQUFNLGFBQWEsV0FBVztTQUU5QixPQUNFLHdCQUFDLE1BQUQ7VUFBeUUsV0FBVTtvQkFBbkY7V0FFRSx3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFDWix3QkFBQyxPQUFEO2FBQUssV0FBVTt1QkFBZixDQUNFLHdCQUFDLFFBQUQsRUFBTSxXQUFXLDRCQUNmLFFBQVEsV0FBVyxpQ0FBaUMsaUJBQzVDOzs7O3VCQUNWLHdCQUFDLFFBQUQ7Y0FBTSxXQUFXLHlCQUNmLFFBQVEsV0FBVyxxQkFBcUI7d0JBRXZDLFFBQVEsV0FBVyxlQUFlLEdBQUcsUUFBUSx3QkFBd0IsR0FBRzthQUNyRTs7OztxQkFDSDs7Ozs7O1dBQ0g7Ozs7O1dBR0osd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQWQsQ0FDRSx3QkFBQyxPQUFEO2FBQUssV0FBVTt1QkFBcUMsUUFBUTtZQUFpQjs7OztzQkFDN0Usd0JBQUMsT0FBRDthQUFLLFdBQVU7dUJBQWY7Y0FBc0Q7Y0FBRSxRQUFRO2NBQVM7Y0FBSSxRQUFRLFNBQVM7YUFBa0I7Ozs7O29CQUM5Rzs7Ozs7O1dBR0osd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQWQsQ0FDRSx3QkFBQyxPQUFEO2FBQUssV0FBVTt1QkFBZixDQUNHLFFBQVEsZUFBZSxXQUN0Qix3QkFBQyxZQUFELEVBQVksV0FBVSw4QkFBK0I7Ozs7d0JBRXJELHdCQUFDLFFBQUQsRUFBUSxXQUFVLDRCQUE2Qjs7Ozt1QkFFakQsd0JBQUMsUUFBRDtjQUFNLFdBQVU7d0JBQXlCLFFBQVE7YUFBZTs7OztxQkFDN0Q7Ozs7O3NCQUNMLHdCQUFDLE9BQUQ7YUFBSyxXQUFVO3VCQUE4QixRQUFRO1lBQWdCOzs7O29CQUNuRTs7Ozs7O1dBR0osd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQ1osd0JBQUMsUUFBRDthQUFNLFdBQVU7dUJBQWhCLENBQ0Usd0JBQUMsVUFBRCxFQUFVLFdBQVUsd0JBQXlCOzs7O3VCQUM3Qyx3QkFBQyxRQUFELFlBQU8sUUFBUSxjQUFjLGtCQUF3Qjs7OztxQkFDakQ7Ozs7OztXQUNKOzs7OztXQUdKLHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUNaLHdCQUFDLE9BQUQ7YUFBSyxXQUFVO3VCQUFmLENBQ0Usd0JBQUMsT0FBRDtjQUFLLFdBQVcsbUNBQ2QsYUFBYSxrQkFBa0I7d0JBRTlCLFdBQVcsSUFBSSxHQUFHLFNBQVMsY0FBYzthQUN2Qzs7Ozt1QkFDTCx3QkFBQyxPQUFEO2NBQUssV0FBVTt3QkFBZixDQUE0QyxTQUFNLFFBQVEscUJBQXFCLFlBQWtCOzs7OztxQkFDOUY7Ozs7OztXQUNIOzs7OztXQUdKLHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUNaLHdCQUFDLE9BQUQ7YUFBSyxXQUFVO3VCQUFmO2NBRUUsd0JBQUMsVUFBRDtlQUNFLGVBQWU7Z0JBQ2IsTUFBTSxRQUFRLFVBQVUsTUFBSyxNQUFLLEVBQUUsYUFBYSxRQUFRLFFBQVE7Z0JBQ2pFLElBQUksT0FBTyxzQkFBc0IsS0FBSztlQUN4QztlQUNBLFdBQVU7ZUFDVixPQUFNO3lCQU5SLENBUUUsd0JBQUMsVUFBRCxFQUFVLFdBQVUsVUFBVzs7Ozt5QkFDL0Isd0JBQUMsUUFBRCxZQUFNLFFBQVc7Ozs7dUJBQ1g7Ozs7OztjQUdSLHdCQUFDLFVBQUQ7ZUFDRSxlQUFlO2dCQUNiLDJCQUEyQixRQUFRLFFBQVE7Z0JBQzNDLHdCQUF3QixFQUFFO2VBQzVCO2VBQ0EsV0FBVTtlQUNWLE9BQU07eUJBRU4sd0JBQUMsZUFBRCxFQUFlLFdBQVUsVUFBVzs7Ozs7Y0FDOUI7Ozs7O2NBR1Isd0JBQUMsVUFBRDtlQUNFLGVBQWUsc0JBQXNCLFFBQVEsVUFBVSxRQUFRLFFBQVE7ZUFDdkUsV0FBVTtlQUNWLE9BQU07eUJBRU4sd0JBQUMsT0FBRCxFQUFPLFdBQVUsVUFBVzs7Ozs7Y0FDdEI7Ozs7O2FBQ0w7Ozs7OztXQUNIOzs7OztVQUNGO1lBNUZLLFFBQVEsYUFBYSxHQUFHLFFBQVEsU0FBUyxHQUFHLFFBQVE7Ozs7Z0JBNEZ6RDtRQUVSLENBQUM7T0FDSTs7OztlQUNGOzs7Ozs7S0FDSjs7Ozs7SUFDRjs7Ozs7O0dBSU4saUJBQWlCLGVBQ2hCLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBZCxDQUNFLHdCQUFDLFFBQUQsWUFBTSw2Q0FBZ0Q7Ozs7aUJBQ3RELHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUF3RztPQUVsSDs7OztlQUNKOzs7OztnQkFDSix3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBYjtRQUE2QztRQUNkLHdCQUFDLEtBQUQsWUFBRyxrQkFBa0I7Ozs7O1FBQUM7UUFBSyx3QkFBQyxLQUFELFlBQUcsc0JBQXNCOzs7OztRQUFDO09BQ2pGOzs7OztjQUNBOzs7O2dCQUVMLHdCQUFDLFVBQUQ7T0FDRSxlQUFlLGdCQUFnQixJQUFJO09BQ25DLFdBQVU7aUJBRlosQ0FJRSx3QkFBQyxVQUFELEVBQVUsV0FBVSxVQUFXOzs7O2lCQUMvQix3QkFBQyxRQUFELFlBQU0sMkJBQThCOzs7O2VBQzlCOzs7OztjQUNMOzs7Ozs7S0FHTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsS0FBRCxFQUFLLFdBQVUsd0JBQXlCOzs7OztRQUN4Qyx3QkFBQyxRQUFEO1NBQU07U0FBdUIsa0JBQWtCLGNBQWM7U0FBUTtRQUFROzs7OztRQUM3RSx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFDYjtRQUNHOzs7OztPQUNIOzs7OztnQkFDTCx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBd0M7TUFBd0I7Ozs7Y0FDN0U7Ozs7OztLQUdMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNiLHdCQUFDLFNBQUQ7T0FBTyxXQUFVO2lCQUFqQixDQUNFLHdCQUFDLFNBQUQsWUFDRSx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBZDtTQUNFLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUFZO1NBQXVCOzs7OztTQUNqRCx3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFBWTtTQUFROzs7OztTQUNsQyx3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFBWTtTQUF5Qjs7Ozs7U0FDbkQsd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQVk7U0FBNkI7Ozs7O1NBQ3ZELHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUFZO1NBQWtCOzs7OztTQUM1Qyx3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFBdUI7U0FBMEI7Ozs7O1FBQzdEOzs7OztnQkFDQzs7OztpQkFDUCx3QkFBQyxTQUFEO1FBQU8sV0FBVTtrQkFDZCxVQUFVLEtBQUssT0FBTztTQUNyQixNQUFNLFdBQVcsdUJBQXVCLEdBQUcsaUJBQWlCO1NBRTVELE9BQ0Usd0JBQUMsTUFBRDtVQUFnQixXQUFVO29CQUExQjtXQUVFLHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUFkLENBQ0Usd0JBQUMsT0FBRDthQUFLLFdBQVU7dUJBQWdDLEdBQUc7WUFBaUI7Ozs7c0JBQ25FLHdCQUFDLE9BQUQ7YUFBSyxXQUFVO3VCQUFmO2NBQXNEO2NBQUUsR0FBRztjQUFTO2NBQUksR0FBRzthQUFXOzs7OztvQkFDcEY7Ozs7OztXQUdKLHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUNaLHdCQUFDLFFBQUQ7YUFBTSxXQUFXLGlFQUNmLEdBQUcsU0FBUyxVQUNSLGlFQUNBO3VCQUVILEdBQUcsU0FBUyxVQUFVLGlCQUFpQjtZQUNwQzs7Ozs7V0FDSjs7Ozs7V0FHSix3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFDWCxHQUFHLGtCQUNGLHdCQUFDLE9BQUQ7YUFBSyxXQUFVO3VCQUFmO2NBQ0Usd0JBQUMsT0FBRDtlQUFLLFdBQVU7eUJBQWYsQ0FDRSx3QkFBQyxRQUFELEVBQVEsV0FBVSw0QkFBNkI7Ozs7eUJBQy9DLHdCQUFDLFFBQUQ7Z0JBQU0sV0FBVTswQkFBeUIsR0FBRztlQUFzQjs7Ozt1QkFDL0Q7Ozs7OztjQUNMLHdCQUFDLE9BQUQ7ZUFBSyxXQUFVO3lCQUFxRCxHQUFHLHFCQUFxQjtjQUFzQjs7Ozs7Y0FDbEgsd0JBQUMsVUFBRDtlQUNFLGVBQWUsY0FBYyxHQUFHLElBQUksR0FBRyxRQUFRO2VBQy9DLFdBQVU7eUJBRlosQ0FJRSx3QkFBQyxXQUFELEVBQVcsV0FBVSxjQUFlOzs7O3lCQUNwQyx3QkFBQyxRQUFELFlBQU0sbUJBQXNCOzs7O3VCQUN0Qjs7Ozs7O2FBQ0w7Ozs7O3VCQUVMLHdCQUFDLFFBQUQ7YUFBTSxXQUFVO3VCQUF3RztZQUVsSDs7Ozs7V0FFTjs7Ozs7V0FHSix3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFDWCxHQUFHLHNCQUNGLHdCQUFDLE9BQUQ7YUFBSyxXQUFVO3VCQUFmO2NBQ0Usd0JBQUMsT0FBRDtlQUFLLFdBQVU7eUJBQWYsQ0FDRSx3QkFBQyxZQUFELEVBQVksV0FBVSw4QkFBK0I7Ozs7eUJBQ3JELHdCQUFDLFFBQUQ7Z0JBQU0sV0FBVTswQkFBeUIsR0FBRztlQUEwQjs7Ozt1QkFDbkU7Ozs7OztjQUNMLHdCQUFDLE9BQUQ7ZUFBSyxXQUFVO3lCQUFxRCxHQUFHLHlCQUF5QjtjQUFrQjs7Ozs7Y0FDbEgsd0JBQUMsVUFBRDtlQUNFLGVBQWUsa0JBQWtCLEdBQUcsSUFBSSxHQUFHLFFBQVE7ZUFDbkQsV0FBVTt5QkFGWixDQUlFLHdCQUFDLFdBQUQsRUFBVyxXQUFVLGNBQWU7Ozs7eUJBQ3BDLHdCQUFDLFFBQUQsWUFBTSx1QkFBMEI7Ozs7dUJBQzFCOzs7Ozs7YUFDTDs7Ozs7dUJBRUwsd0JBQUMsUUFBRDthQUFNLFdBQVU7dUJBQXdHO1lBRWxIOzs7OztXQUVOOzs7OztXQUdKLHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUNaLHdCQUFDLE9BQUQ7YUFBSyxXQUFVO3VCQUFmLENBQ0Usd0JBQUMsUUFBRDtjQUFNLFdBQVU7d0JBQWhCLENBQ0Usd0JBQUMsVUFBRCxFQUFVLFdBQVUsMkJBQTRCOzs7O3dCQUNoRCx3QkFBQyxRQUFELGFBQU8sVUFBUyxZQUFnQjs7OztzQkFDNUI7Ozs7O3VCQUNOLHdCQUFDLFVBQUQ7Y0FDRSxlQUFlLHNCQUFzQixFQUFFO2NBQ3ZDLFdBQVU7d0JBQ1g7YUFFTzs7OztxQkFDTDs7Ozs7O1dBQ0g7Ozs7O1dBR0osd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQ1osd0JBQUMsT0FBRDthQUFLLFdBQVU7dUJBQWY7ZUFFSSxHQUFHLG1CQUFtQixHQUFHLHdCQUN6Qix3QkFBQyxVQUFEO2VBQ0UsZUFBZSxzQkFBc0IsR0FBRyxJQUFJLEdBQUcsUUFBUTtlQUN2RCxXQUFVO2VBQ1YsT0FBTTt5QkFDUDtjQUVPOzs7OztjQUlULEdBQUcsU0FBUyxXQUNYLHdCQUFDLFVBQUQ7ZUFDRSxlQUFlLGlCQUFpQixHQUFHLElBQUksR0FBRyxRQUFRO2VBQ2xELFdBQVcsbUNBQ1QsR0FBRyxXQUNDLHFGQUNBO2VBRU4sT0FBTyxHQUFHLFdBQVcsb0JBQW9CO3lCQUV4QyxHQUFHLFdBQVcsd0JBQUMsUUFBRCxFQUFRLFdBQVUsY0FBZTs7OzswQkFBSSx3QkFBQyxNQUFELEVBQU0sV0FBVSxjQUFlOzs7OztjQUM3RTs7Ozs7Y0FJVCxHQUFHLFNBQVMsV0FDWCx3QkFBQyxVQUFEO2VBQ0UsZUFBZSxxQkFBcUIsR0FBRyxJQUFJLEdBQUcsUUFBUTtlQUN0RCxXQUFVO2VBQ1YsT0FBTTt5QkFFTix3QkFBQyxRQUFELEVBQVEsV0FBVSxjQUFlOzs7OztjQUMzQjs7Ozs7YUFFUDs7Ozs7O1dBQ0g7Ozs7O1VBQ0Y7WUEzSEssR0FBRzs7OztnQkEySFI7UUFFUixDQUFDO09BQ0k7Ozs7ZUFDRjs7Ozs7O0tBQ0o7Ozs7O0lBQ0Y7Ozs7OztHQUlOLGlCQUFpQixjQUNoQix3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBZDtPQUNFLHdCQUFDLGVBQUQsRUFBZSxXQUFVLHlCQUEwQjs7Ozs7T0FDbkQsd0JBQUMsUUFBRCxZQUFNLGdEQUFtRDs7Ozs7T0FDekQsd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQWtHO09BRTVHOzs7OztNQUNKOzs7OztlQUNKLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUFnQztLQUUxQzs7OzthQUNBOzs7O2VBRUwsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FBOEcsZUFDakcsd0JBQUMsVUFBRDtPQUFRLFdBQVU7aUJBQWxCO1FBQXNDO1FBQXVCO1FBQUksc0JBQXNCO1FBQU87T0FBa0I7Ozs7O2NBQ3hIOzs7OzthQUNGOzs7OztjQUdMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ1osc0JBQXNCLEtBQUssU0FBUztNQUNuQyxNQUFNLFNBQVMsQ0FBQyxDQUFDLGVBQWUsS0FBSztNQUNyQyxPQUNFLHdCQUFDLE9BQUQ7T0FFRSxXQUFXLGtEQUNULFNBQ0ksMENBQ0E7aUJBTFI7UUFRRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsUUFBRDtXQUFNLFdBQVcsbUZBQ2YsU0FBUyxrQ0FBa0M7cUJBRTFDLEtBQUs7VUFDRjs7OztvQkFDTix3QkFBQyxNQUFEO1dBQUksV0FBVTtxQkFBcUMsS0FBSztVQUFVOzs7O2tCQUMvRDs7Ozs7bUJBRUwsd0JBQUMsVUFBRDtVQUNFLGVBQWUsbUJBQWtCLFVBQVM7V0FBRSxHQUFHO1lBQU8sS0FBSyxhQUFhLENBQUMsS0FBSyxLQUFLO1VBQVksRUFBRTtVQUNqRyxXQUFXLCtFQUNULFNBQ0ksNkRBQ0E7b0JBTFIsQ0FRRyxTQUFTLHdCQUFDLGNBQUQsRUFBYyxXQUFVLCtCQUFnQzs7OztxQkFBSSx3QkFBQyxRQUFELEVBQVEsV0FBVSxjQUFlOzs7O29CQUN2Ryx3QkFBQyxRQUFELFlBQU8sU0FBUyxTQUFTLE9BQWE7Ozs7a0JBQ2hDOzs7OztpQkFDTDs7Ozs7O1FBRUwsd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQTJDLEtBQUs7UUFBZTs7Ozs7UUFFNUUsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQ1osS0FBSyxVQUFVLEtBQUssTUFBTSxRQUN6Qix3QkFBQyxPQUFEO1VBQWUsV0FBVTtvQkFBekIsQ0FDRSx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBZ0I7VUFBTzs7OztvQkFDdkMsd0JBQUMsUUFBRCxZQUFPLEtBQVc7Ozs7a0JBQ2Y7WUFISzs7OztnQkFHTCxDQUNOO1FBQ0U7Ozs7O1FBRUwsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxVQUFELEVBQVUsV0FBVSw4Q0FBK0M7Ozs7bUJBQ25FLHdCQUFDLFFBQUQ7VUFBTSx3QkFBQyxLQUFELFlBQUcsaUJBQWlCOzs7OztVQUFDO1VBQUUsS0FBSztTQUFXOzs7O2lCQUMxQzs7Ozs7O09BQ0Y7U0E3Q0UsS0FBSzs7OzthQTZDUDtLQUVULENBQUM7SUFDRTs7OztZQUNGOzs7Ozs7R0FJTixpQkFBaUIsa0JBQ2hCLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNiLHdCQUFDLFNBQUQsRUFBUyxXQUFVLFVBQVc7Ozs7O01BQzNCOzs7O2dCQUNMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQW9DO09BQW9EOzs7O2lCQUN0Ryx3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBeUM7T0FFbkQ7Ozs7ZUFDQTs7Ozs7Y0FDRjs7Ozs7O0tBRUwsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBcUM7TUFBK0I7Ozs7Z0JBQ3BGLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsT0FBRCxZQUFLLGtDQUFvQzs7Ozs7UUFDekMsd0JBQUMsT0FBRCxZQUFLLDhCQUFnQzs7Ozs7UUFDckMsd0JBQUMsT0FBRCxZQUFLLHFDQUF1Qzs7Ozs7UUFDNUMsd0JBQUMsT0FBRCxZQUFLLDBCQUE0Qjs7Ozs7UUFDakMsd0JBQUMsT0FBRCxZQUFLLDhCQUFnQzs7Ozs7UUFDckMsd0JBQUMsT0FBRCxZQUFLLGlDQUFtQzs7Ozs7UUFDeEMsd0JBQUMsT0FBRCxZQUFLLHNDQUF3Qzs7Ozs7UUFDN0Msd0JBQUMsT0FBRCxZQUFLLHNDQUF3Qzs7Ozs7UUFDN0Msd0JBQUMsT0FBRCxZQUFLLHVDQUF5Qzs7Ozs7UUFDOUMsd0JBQUMsT0FBRCxZQUFLLHFDQUF1Qzs7Ozs7T0FDekM7Ozs7O2NBQ0Y7Ozs7OztLQUdKLGtCQUNDLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxRQUFELGFBQU0seUJBQXNCLFlBQVksSUFBVzs7OztpQkFDbkQsd0JBQUMsUUFBRCxhQUFPLFlBQVksU0FBUSxHQUFPOzs7O2VBQy9COzs7OztnQkFDTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDYix3QkFBQyxPQUFEO1FBQ0UsV0FBVTtRQUNWLE9BQU8sRUFBRSxPQUFPLEdBQUcsWUFBWSxRQUFRLEdBQUc7T0FDM0M7Ozs7O01BQ0U7Ozs7Y0FDRjs7Ozs7O0tBR1Asd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxVQUFEO09BQ0UsU0FBUztPQUNULFVBQVU7T0FDVixXQUFVO2lCQUhaLENBS0Usd0JBQUMsVUFBRCxFQUFVLFdBQVUsVUFBVzs7OztpQkFDL0Isd0JBQUMsUUFBRCxZQUFPLGlCQUFpQiwyQkFBMkIsZ0NBQXNDOzs7O2VBQ25GOzs7OztnQkFFUix3QkFBQyxLQUFEO09BQ0UsTUFBSztPQUNMLFVBQVM7T0FDVCxXQUFVO2lCQUVWLHdCQUFDLFFBQUQsWUFBTSw4QkFBaUM7Ozs7O01BQ3RDOzs7O2NBQ0E7Ozs7OztJQUNGOzs7Ozs7R0FJTixpQkFBaUIsVUFDaEIsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQXNDO0tBQXlDOzs7O2VBQzdGLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUF5QjtLQUF5Rjs7OzthQUM1SDs7OztlQUNMLHdCQUFDLFVBQUQ7TUFDRSxTQUFTO01BQ1QsV0FBVTtnQkFGWixDQUlFLHdCQUFDLFdBQUQsRUFBVyxXQUFVLGNBQWU7Ozs7Z0JBQ3BDLHdCQUFDLFFBQUQsWUFBTSxlQUFrQjs7OztjQUNsQjs7Ozs7YUFDTDs7Ozs7Y0FFTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNiLHdCQUFDLFNBQUQ7TUFBTyxXQUFVO2dCQUFqQixDQUNFLHdCQUFDLFNBQUQ7T0FBTyxXQUFVO2lCQUNmLHdCQUFDLE1BQUQ7UUFDRSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBYztRQUFhOzs7OztRQUN6Qyx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBYztRQUFVOzs7OztRQUN0Qyx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBYztRQUFZOzs7OztRQUN4Qyx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBYztRQUFROzs7OztRQUNwQyx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBYztRQUFhOzs7OztRQUN6Qyx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBYztRQUFXOzs7OztPQUNyQzs7Ozs7TUFDQzs7OztnQkFDUCx3QkFBQyxTQUFEO09BQU8sV0FBVTtpQkFDZCxVQUFVLFNBQVMsSUFDbEIsVUFBVSxLQUFLLFFBQ2Isd0JBQUMsTUFBRDtRQUFpQixXQUFVO2tCQUEzQjtTQUNFLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUE4QixJQUFJO1NBQWM7Ozs7O1NBQzlELHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUNaLHdCQUFDLFFBQUQ7V0FBTSxXQUFXLDZDQUNmLElBQUksV0FBVyxrQkFDWCx1Q0FDQSxJQUFJLFdBQVcsbUJBQ2YsaUNBQ0EsSUFBSSxXQUFXLGlCQUNmLGlDQUNBO3FCQUVILElBQUk7VUFDRDs7Ozs7U0FDSjs7Ozs7U0FDSix3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFBZCxDQUFpRCxLQUFFLElBQUksUUFBYTs7Ozs7O1NBQ3BFLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUE4QixJQUFJLGVBQWUsV0FBVyxjQUFjO1NBQVk7Ozs7O1NBQ3BHLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUE4QixJQUFJO1NBQWE7Ozs7O1NBQzdELHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUEwRCxJQUFJO1NBQVk7Ozs7O1FBQ3RGO1VBbkJLLElBQUk7Ozs7Y0FtQlQsQ0FDTCxJQUVELHdCQUFDLE1BQUQsWUFDRSx3QkFBQyxNQUFEO1FBQUksU0FBUztRQUFHLFdBQVU7a0JBQWtDO09BRXhEOzs7O2dCQUNGOzs7OztNQUVEOzs7O2NBQ0Y7Ozs7OztJQUNKOzs7O1lBQ0Y7Ozs7OztHQUlOLGlCQUFpQixjQUNoQix3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmO0tBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQWQsQ0FDRSx3QkFBQyxLQUFELEVBQUssV0FBVSx3QkFBeUI7Ozs7aUJBQ3hDLHdCQUFDLFFBQUQsWUFBTSxrREFBcUQ7Ozs7ZUFDekQ7Ozs7O2dCQUNKLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUFnQztNQUUxQzs7OztjQUNBOzs7O2dCQUVMLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUF3RztNQUVsSDs7OztjQUNIOzs7Ozs7S0FHTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsYUFBRCxFQUFhLFdBQVUsVUFBVzs7OztpQkFDbEMsd0JBQUMsUUFBRCxZQUFNLGtEQUFxRDs7OztlQUN4RDs7Ozs7Z0JBQ0wsd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQWI7UUFBc0Q7UUFDckMsd0JBQUMsS0FBRCxZQUFHLHVGQUF1Rjs7Ozs7UUFBQztRQUVyRCx3QkFBQyxLQUFELFlBQUcsZUFBZTs7Ozs7UUFBQztPQUN2RTs7Ozs7Y0FDQTs7Ozs7O0tBRUwsd0JBQUMsUUFBRDtNQUFNLFVBQVU7TUFBb0IsV0FBVTtnQkFBOUM7T0FFRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUNaLHdCQUFDLFFBQUQsWUFBTSxzQ0FBeUM7Ozs7O1FBQzdDOzs7O2tCQUVKLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmO1VBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7V0FBTyxXQUFVO3FCQUE0QjtVQUF5Qjs7OztvQkFDdEUsd0JBQUMsU0FBRDtXQUNFLE1BQUs7V0FDTCxPQUFPLFNBQVM7V0FDaEIsV0FBVyxNQUFNLFlBQVk7WUFBRSxHQUFHO1lBQVUsVUFBVSxFQUFFLE9BQU87V0FBTSxDQUFDO1dBQ3RFLFdBQVU7VUFDWDs7OztrQkFDRTs7Ozs7VUFFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtXQUFPLFdBQVU7cUJBQTRCO1VBQWlCOzs7O29CQUM5RCx3QkFBQyxTQUFEO1dBQ0UsTUFBSztXQUNMLE9BQU8sU0FBUztXQUNoQixXQUFXLE1BQU0sWUFBWTtZQUFFLEdBQUc7WUFBVSxXQUFXLEVBQUUsT0FBTztXQUFNLENBQUM7V0FDdkUsV0FBVTtVQUNYOzs7O2tCQUNFOzs7OztVQUVMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1dBQU8sV0FBVTtxQkFBNEI7VUFBK0I7Ozs7b0JBQzVFLHdCQUFDLFNBQUQ7V0FDRSxNQUFLO1dBQ0wsT0FBTyxTQUFTO1dBQ2hCLFdBQVcsTUFBTSxZQUFZO1lBQUUsR0FBRztZQUFVLE9BQU8sRUFBRSxPQUFPO1dBQU0sQ0FBQztXQUNuRSxXQUFVO1VBQ1g7Ozs7a0JBQ0U7Ozs7O1VBRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7V0FBTyxXQUFVO3FCQUE0QjtVQUFnQzs7OztvQkFDN0Usd0JBQUMsU0FBRDtXQUNFLE1BQUs7V0FDTCxPQUFPLFNBQVM7V0FDaEIsV0FBVyxNQUFNLFlBQVk7WUFBRSxHQUFHO1lBQVUsT0FBTyxFQUFFLE9BQU87V0FBTSxDQUFDO1dBQ25FLFdBQVU7VUFDWDs7OztrQkFDRTs7Ozs7VUFFTCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNFLHdCQUFDLFNBQUQ7WUFBTyxXQUFVO3NCQUE0QjtXQUF3RDs7OztxQkFDckcsd0JBQUMsU0FBRDtZQUNFLE1BQUs7WUFDTCxPQUFPLFNBQVM7WUFDaEIsV0FBVyxNQUFNLFlBQVk7YUFBRSxHQUFHO2FBQVUsU0FBUyxFQUFFLE9BQU87WUFBTSxDQUFDO1lBQ3JFLFdBQVU7V0FDWDs7OzttQkFDRTs7Ozs7O1NBQ0Y7Ozs7O2dCQUNGOzs7Ozs7T0FHTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUNaLHdCQUFDLFFBQUQsWUFBTSw2Q0FBZ0Q7Ozs7O1FBQ3BEOzs7O2tCQUVKLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmO1VBQ0Usd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDRSx3QkFBQyxTQUFEO1lBQU8sV0FBVTtzQkFBd0M7V0FBcUI7Ozs7cUJBQzlFLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUFmLENBQ0Usd0JBQUMsUUFBRCxZQUFNLElBQU87Ozs7c0JBQ2Isd0JBQUMsU0FBRDthQUNFLE1BQUs7YUFDTCxjQUFjO2FBQ2QsYUFBWTthQUNaLFdBQVU7WUFDWDs7OztvQkFDRTs7Ozs7bUJBQ0Y7Ozs7OztVQUVMLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0Usd0JBQUMsU0FBRDtZQUFPLFdBQVU7c0JBQXdDO1dBQTBCOzs7O3FCQUNuRix3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZixDQUNFLHdCQUFDLFFBQUQsWUFBTSxJQUFPOzs7O3NCQUNiLHdCQUFDLFNBQUQ7YUFDRSxNQUFLO2FBQ0wsY0FBYzthQUNkLGFBQVk7YUFDWixXQUFVO1lBQ1g7Ozs7b0JBQ0U7Ozs7O21CQUNGOzs7Ozs7VUFFTCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNFLHdCQUFDLFNBQUQ7WUFBTyxXQUFVO3NCQUF3QztXQUF5Qjs7OztxQkFDbEYsd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQWYsQ0FDRSx3QkFBQyxRQUFELFlBQU0sSUFBTzs7OztzQkFDYix3QkFBQyxTQUFEO2FBQ0UsTUFBSzthQUNMLGNBQWM7YUFDZCxhQUFZO2FBQ1osV0FBVTtZQUNYOzs7O29CQUNFOzs7OzttQkFDRjs7Ozs7O1VBRUwsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDRSx3QkFBQyxTQUFEO1lBQU8sV0FBVTtzQkFBd0M7V0FBeUI7Ozs7cUJBQ2xGLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUFmLENBQ0Usd0JBQUMsUUFBRCxZQUFNLElBQU87Ozs7c0JBQ2Isd0JBQUMsU0FBRDthQUNFLE1BQUs7YUFDTCxjQUFjO2FBQ2QsYUFBWTthQUNaLFdBQVU7WUFDWDs7OztvQkFDRTs7Ozs7bUJBQ0Y7Ozs7OztVQUVMLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0Usd0JBQUMsU0FBRDtZQUFPLFdBQVU7c0JBQXdDO1dBQW1COzs7O3FCQUM1RSx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZixDQUNFLHdCQUFDLFFBQUQsWUFBTSxJQUFPOzs7O3NCQUNiLHdCQUFDLFNBQUQ7YUFDRSxNQUFLO2FBQ0wsY0FBYzthQUNkLGFBQVk7YUFDWixXQUFVO1lBQ1g7Ozs7b0JBQ0U7Ozs7O21CQUNGOzs7Ozs7VUFFTCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNFLHdCQUFDLFNBQUQ7WUFBTyxXQUFVO3NCQUF3QztXQUF5Qjs7OztxQkFDbEYsd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQWYsQ0FDRSx3QkFBQyxRQUFELFlBQU0sSUFBTzs7OztzQkFDYix3QkFBQyxTQUFEO2FBQ0UsTUFBSzthQUNMLGNBQWM7YUFDZCxhQUFZO2FBQ1osV0FBVTtZQUNYOzs7O29CQUNFOzs7OzttQkFDRjs7Ozs7O1NBQ0Y7Ozs7O2dCQUNGOzs7Ozs7T0FHTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUNaLHdCQUFDLFFBQUQsWUFBTSxtQ0FBc0M7Ozs7O1FBQzFDOzs7O2tCQUVKLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmO1VBQ0Usd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWY7WUFDRSx3QkFBQyxTQUFEO2FBQU8sV0FBVTt1QkFBaUM7WUFBMEI7Ozs7O1lBQzVFLHdCQUFDLE9BQUQ7YUFBSyxXQUFVO3VCQUE0RDtZQUFxQjs7Ozs7WUFDaEcsd0JBQUMsS0FBRDthQUFHLFdBQVU7dUJBQTZCO1lBQWtEOzs7OztXQUN6Rjs7Ozs7O1VBRUwsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWY7WUFDRSx3QkFBQyxTQUFEO2FBQU8sV0FBVTt1QkFBaUM7WUFBMEI7Ozs7O1lBQzVFLHdCQUFDLE9BQUQ7YUFBSyxXQUFVO3VCQUE4RDtZQUErQjs7Ozs7WUFDNUcsd0JBQUMsS0FBRDthQUFHLFdBQVU7dUJBQTZCO1lBQXdEOzs7OztXQUMvRjs7Ozs7O1VBRUwsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWY7WUFDRSx3QkFBQyxTQUFEO2FBQU8sV0FBVTt1QkFBaUM7WUFBMEI7Ozs7O1lBQzVFLHdCQUFDLE9BQUQ7YUFBSyxXQUFVO3VCQUErRDtZQUFnQzs7Ozs7WUFDOUcsd0JBQUMsS0FBRDthQUFHLFdBQVU7dUJBQTZCO1lBQWtEOzs7OztXQUN6Rjs7Ozs7O1NBQ0Y7Ozs7O2dCQUNGOzs7Ozs7T0FHTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFDYix3QkFBQyxVQUFEO1NBQ0UsTUFBSztTQUNMLFdBQVU7bUJBQ1g7UUFFTzs7Ozs7T0FDTDs7Ozs7TUFDRDs7Ozs7O0lBQ0g7Ozs7OztHQUlOLHNCQUNDLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ2Isd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQWQsQ0FDRSx3QkFBQyxVQUFELEVBQVUsV0FBVSwyQkFBNEI7Ozs7a0JBQ2hELHdCQUFDLFFBQUQsWUFBTSxrQ0FBcUM7Ozs7Z0JBQ3pDOzs7OztpQkFDSix3QkFBQyxVQUFEO1FBQVEsZUFBZSxzQkFBc0IsSUFBSTtRQUFHLFdBQVU7a0JBQWtDO09BQVM7Ozs7ZUFDdEc7Ozs7OztNQUVMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQXdCLG1CQUFtQjtRQUFpQjs7Ozs7UUFDM0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWY7VUFBMEM7VUFBRSxtQkFBbUI7VUFBUztVQUFJLG1CQUFtQjtTQUFXOzs7Ozs7UUFDMUcsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWY7VUFBaUQ7VUFDM0IsdUJBQXVCLG1CQUFtQixpQkFBaUI7VUFBRTtTQUM5RTs7Ozs7O09BQ0Y7Ozs7OztNQUVMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQWlDO09BQWlDOzs7O2lCQUNuRix3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUNFLHdCQUFDLFVBQUQ7VUFDRSxNQUFLO1VBQ0wsZUFBZSxrQkFBa0IsRUFBRTtVQUNuQyxXQUFXLDhEQUNULG1CQUFtQixLQUNmLGtEQUNBO29CQU5SLENBU0Usd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQVU7VUFBYTs7OztvQkFDdEMsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQTZCO1VBQWlCOzs7O2tCQUN2RDs7Ozs7O1NBRVIsd0JBQUMsVUFBRDtVQUNFLE1BQUs7VUFDTCxlQUFlLGtCQUFrQixFQUFFO1VBQ25DLFdBQVcsOERBQ1QsbUJBQW1CLEtBQ2Ysa0RBQ0E7b0JBTlIsQ0FTRSx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBVTtVQUFhOzs7O29CQUN0Qyx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBNkI7VUFBbUI7Ozs7a0JBQ3pEOzs7Ozs7U0FFUix3QkFBQyxVQUFEO1VBQ0UsTUFBSztVQUNMLGVBQWUsa0JBQWtCLEdBQUc7VUFDcEMsV0FBVyw4REFDVCxtQkFBbUIsTUFDZixrREFDQTtvQkFOUixDQVNFLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFVO1VBQWM7Ozs7b0JBQ3ZDLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUE2QjtVQUFtQjs7OztrQkFDekQ7Ozs7OztTQUVSLHdCQUFDLFVBQUQ7VUFDRSxNQUFLO1VBQ0wsZUFBZSxrQkFBa0IsSUFBSTtVQUNyQyxXQUFXLDhEQUNULG1CQUFtQixPQUNmLHdEQUNBO29CQU5SLENBU0Usd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQVU7VUFBYTs7OztvQkFDdEMsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQTZCO1VBQXFCOzs7O2tCQUMzRDs7Ozs7O1FBQ0w7Ozs7O2VBQ0Y7Ozs7OztNQUVMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsVUFBRDtRQUNFLE1BQUs7UUFDTCxlQUFlLHNCQUFzQixJQUFJO1FBQ3pDLFdBQVU7a0JBQ1g7T0FFTzs7OztpQkFDUix3QkFBQyxVQUFEO1FBQ0UsTUFBSztRQUNMLFNBQVM7UUFDVCxXQUFVO2tCQUhaLENBS0Usd0JBQUMsT0FBRCxFQUFPLFdBQVUsVUFBVzs7OztrQkFDNUIsd0JBQUMsUUFBRCxZQUFNLDBCQUE2Qjs7OztnQkFDN0I7Ozs7O2VBQ0w7Ozs7OztLQUNGOzs7Ozs7R0FDRjs7Ozs7R0FJTiwyQkFDQyx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNiLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUFkLENBQ0Usd0JBQUMsZUFBRCxFQUFlLFdBQVUsdUJBQXdCOzs7O2tCQUNqRCx3QkFBQyxRQUFELGFBQU0sbUJBQWdCLHVCQUE4Qjs7OztnQkFDbEQ7Ozs7O2lCQUNKLHdCQUFDLFVBQUQ7UUFBUSxlQUFlLDJCQUEyQixJQUFJO1FBQUcsV0FBVTtrQkFBa0M7T0FBUzs7OztlQUMzRzs7Ozs7O01BRUwsd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQXlCO01BRW5DOzs7OztNQUVILHdCQUFDLFlBQUQ7T0FDRSxNQUFNO09BQ04sT0FBTztPQUNQLFdBQVcsTUFBTSx3QkFBd0IsRUFBRSxPQUFPLEtBQUs7T0FDdkQsYUFBWTtPQUNaLFdBQVU7TUFDWDs7Ozs7TUFFRCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFVBQUQ7UUFDRSxlQUFlLDJCQUEyQixJQUFJO1FBQzlDLFdBQVU7a0JBQ1g7T0FFTzs7OztpQkFDUix3QkFBQyxVQUFEO1FBQ0UsU0FBUztRQUNULFdBQVU7a0JBRlosQ0FJRSx3QkFBQyxNQUFELEVBQU0sV0FBVSxjQUFlOzs7O2tCQUMvQix3QkFBQyxRQUFELFlBQU0sbUJBQXNCOzs7O2dCQUN0Qjs7Ozs7ZUFDTDs7Ozs7O0tBQ0Y7Ozs7OztHQUNGOzs7OztHQUlOLGdCQUNDLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ2Isd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQWQsQ0FDRSx3QkFBQyxVQUFELEVBQVUsV0FBVSx3QkFBeUI7Ozs7a0JBQzdDLHdCQUFDLFFBQUQsWUFBTSwyQkFBOEI7Ozs7Z0JBQ2xDOzs7OztpQkFDSix3QkFBQyxVQUFEO1FBQVEsZUFBZSxnQkFBZ0IsS0FBSztRQUFHLFdBQVU7a0JBQWtDO09BQVM7Ozs7ZUFDakc7Ozs7OztNQUVMLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUFiO1FBQXNDO1FBQ0Ysd0JBQUMsS0FBRCxZQUFHLGtCQUFrQjs7Ozs7UUFBQztRQUFHLHdCQUFDLEtBQUQsWUFBRyxzQkFBc0I7Ozs7O1FBQUM7T0FDcEY7Ozs7OztNQUVGLFlBQ0Msd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQ1o7TUFDRTs7Ozs7TUFHUCx3QkFBQyxRQUFEO09BQU0sVUFBVTtPQUFzQixXQUFVO2lCQUFoRDtRQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1NBQU8sV0FBVTttQkFBNEI7UUFBeUI7Ozs7a0JBQ3RFLHdCQUFDLFNBQUQ7U0FDRSxNQUFLO1NBQ0w7U0FDQSxhQUFZO1NBQ1osT0FBTztTQUNQLFdBQVcsTUFBTSxrQkFBa0IsRUFBRSxPQUFPLEtBQUs7U0FDakQsV0FBVTtRQUNYOzs7O2dCQUNFOzs7OztRQUVMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1NBQU8sV0FBVTttQkFBNEI7UUFBMEI7Ozs7a0JBQ3ZFLHdCQUFDLFNBQUQ7U0FDRSxNQUFLO1NBQ0w7U0FDQSxhQUFZO1NBQ1osT0FBTztTQUNQLFdBQVcsTUFBTSxlQUFlLEVBQUUsT0FBTyxLQUFLO1NBQzlDLFdBQVU7UUFDWDs7OztnQkFDRTs7Ozs7UUFFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtTQUFPLFdBQVU7bUJBQTRCO1FBQWU7Ozs7a0JBQzVELHdCQUFDLFNBQUQ7U0FDRSxNQUFLO1NBQ0w7U0FDQSxhQUFZO1NBQ1osT0FBTztTQUNQLFdBQVcsTUFBTSxlQUFlLEVBQUUsT0FBTyxLQUFLO1NBQzlDLFdBQVU7UUFDWDs7OztnQkFDRTs7Ozs7UUFFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtTQUFPLFdBQVU7bUJBQTRCO1FBQW1COzs7O2tCQUNoRSx3QkFBQyxTQUFEO1NBQ0UsTUFBSztTQUNMLGFBQVk7U0FDWixPQUFPO1NBQ1AsV0FBVyxNQUFNLFlBQVksRUFBRSxPQUFPLEtBQUs7U0FDM0MsV0FBVTtRQUNYOzs7O2dCQUNFOzs7OztRQUVMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsVUFBRDtVQUNFLE1BQUs7VUFDTCxlQUFlLGdCQUFnQixLQUFLO1VBQ3BDLFdBQVU7b0JBQ1g7U0FFTzs7OzttQkFDUix3QkFBQyxVQUFEO1VBQ0UsTUFBSztVQUNMLFdBQVU7b0JBQ1g7U0FFTzs7OztpQkFDTDs7Ozs7O09BQ0Q7Ozs7OztLQUNIOzs7Ozs7R0FDRjs7Ozs7RUFFSjs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiTWFzdGVyQWRtaW5WaWV3LnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IFxuICBTaGllbGRDaGVjaywgXG4gIExvY2ssIFxuICBVbmxvY2ssIFxuICBTbWFydHBob25lLCBcbiAgTGFwdG9wLCBcbiAgUm90YXRlQ2N3LCBcbiAgVXNlclBsdXMsIFxuICBUcmFzaDIsIFxuICBEb3dubG9hZCwgXG4gIENoZWNrQ2lyY2xlMiwgXG4gIEFsZXJ0Q2lyY2xlLCBcbiAgQ2xvY2ssIFxuICBLZXksIFxuICBGaWxlQ29kZSwgXG4gIExheWVycywgXG4gIENoZWNrLCBcbiAgQXJjaGl2ZSxcbiAgUmVmcmVzaEN3LFxuICBDcHUsXG4gIE1vbml0b3IsXG4gIENsaXBib2FyZExpc3QsXG4gIFNwYXJrbGVzLFxuICBDaXJjbGUsXG4gIEhlbHBDaXJjbGUsXG4gIEFjdGl2aXR5LFxuICBSYWRpbyxcbiAgUG93ZXIsXG4gIE1lc3NhZ2VTcXVhcmUsXG4gIFNlbmQsXG4gIENhbGVuZGFyLFxuICBBbGVydFRyaWFuZ2xlLFxuICBXaWZpLFxuICBHbG9iZVxufSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuaW1wb3J0IHsgT3BlcmF0b3JBY2NvdW50LCBTaG9wU2V0dGluZ3MsIExpdmVPcGVyYXRvclNlc3Npb24gfSBmcm9tICcuLi90eXBlcyc7XG5pbXBvcnQgeyBcbiAgZ2V0UmVnaXN0ZXJlZE9wZXJhdG9ycywgXG4gIHJlc2V0T3BlcmF0b3JQY0JpbmRpbmcsXG4gIHJlc2V0T3BlcmF0b3JNb2JpbGVCaW5kaW5nLFxuICByZXNldE9wZXJhdG9yQWxsQmluZGluZ3MsXG4gIHRvZ2dsZU9wZXJhdG9yTG9jaywgXG4gIGFkZE5ld09wZXJhdG9yLCBcbiAgZGVsZXRlT3BlcmF0b3IsXG4gIGdldFNlY3VyaXR5QXVkaXRMb2dzLFxuICBTZWN1cml0eUF1ZGl0TG9nLFxuICBnZXRIYXJkd2FyZURldmljZUlkLFxuICBnZXRIYXJkd2FyZURldmljZU5hbWUsXG4gIGlzTW9iaWxlRGV2aWNlLFxuICByZW5ld09wZXJhdG9yTGljZW5zZSxcbiAgY2FsY3VsYXRlUmVtYWluaW5nRGF5cyxcbiAgZ2V0TGl2ZU9wZXJhdG9yU2Vzc2lvbnMsXG4gIGZvcmNlRGlzY29ubmVjdE9wZXJhdG9yLFxuICBzZW5kT3BlcmF0b3JCcm9hZGNhc3RNZXNzYWdlXG59IGZyb20gJy4uL3V0aWxzL2RldmljZVNlY3VyaXR5JztcbmltcG9ydCB7IGdlbmVyYXRlUHJvamVjdFppcCwgdHJpZ2dlckRvd25sb2FkWmlwIH0gZnJvbSAnLi4vdXRpbHMvcHJvamVjdFppcCc7XG5cbmludGVyZmFjZSBNYXN0ZXJBZG1pblZpZXdQcm9wcyB7XG4gIHNldHRpbmdzOiBTaG9wU2V0dGluZ3M7XG4gIG9uVXBkYXRlU2V0dGluZ3M6IChzZXR0aW5nczogU2hvcFNldHRpbmdzKSA9PiB2b2lkO1xuICBvbk5hdmlnYXRlVG9Xb3JrZmxvdz86ICgpID0+IHZvaWQ7XG59XG5cbmludGVyZmFjZSBXb3JrZmxvd1N0ZXAge1xuICBzdGVwTnVtYmVyOiBudW1iZXI7XG4gIHRpdGxlOiBzdHJpbmc7XG4gIGRlc2NyaXB0aW9uOiBzdHJpbmc7XG4gIHRvb2xzVXNlZDogc3RyaW5nW107XG4gIGNoZWNrbGlzdDogc3RyaW5nW107XG4gIHRpcHM6IHN0cmluZztcbn1cblxuY29uc3QgTUFTVEVSX1dPUktGTE9XX1NURVBTOiBXb3JrZmxvd1N0ZXBbXSA9IFtcbiAge1xuICAgIHN0ZXBOdW1iZXI6IDEsXG4gICAgdGl0bGU6ICdDdXN0b21lciBJbnRha2UgJiBTZXJ2aWNlIElkZW50aWZpY2F0aW9uJyxcbiAgICBkZXNjcmlwdGlvbjogJ1dlbGNvbWUgY2l0aXplbiwgdmVyaWZ5IEFhZGhhYXIgbGlua2VkIG1vYmlsZSwgY2hlY2sgZG9jdW1lbnQgcHJlcmVxdWlzaXRlcywgYW5kIHF1b3RlIHRyYW5zcGFyZW50IHJhdGVzLicsXG4gICAgdG9vbHNVc2VkOiBbJ0Rhc2hib2FyZCcsICc1MCsgR292dCBQb3J0YWxzIEh1YicsICdBSSBBc3Npc3RhbnQnXSxcbiAgICBjaGVja2xpc3Q6IFtcbiAgICAgICdDaGVjayBjdXN0b21lciBBYWRoYWFyICYgYWN0aXZlIG1vYmlsZSBPVFAgYXZhaWxhYmlsaXR5JyxcbiAgICAgICdJbmZvcm0gY3VzdG9tZXIgb2Ygb2ZmaWNpYWwgcG9ydGFsIGNoYXJnZXMgKyBzZXJ2aWNlIGZlZScsXG4gICAgICAnUmVjb3JkIGN1c3RvbWVyIG5hbWUgJiBXaGF0c0FwcCBudW1iZXIgaW4gQ1JNJyxcbiAgICAgICdJc3N1ZSBwaHlzaWNhbCBvciBkaWdpdGFsIHF1ZXVlIHRva2VuJ1xuICAgIF0sXG4gICAgdGlwczogJ0FhZGhhYXIgbWVpbiBhY3RpdmUgbW9iaWxlIG51bWJlciBob25hIFBNLUtJU0FOLCBMYWRraSBCYWhpbiwgYXVyIE1haGFkYnQgc2NoZW1lcyBrZSBsaXllIGFuaXZhcnlhIGhhaS4nXG4gIH0sXG4gIHtcbiAgICBzdGVwTnVtYmVyOiAyLFxuICAgIHRpdGxlOiAnT2ZmaWNpYWwgUG9ydGFsIEZpbGluZyAmIERvY3VtZW50IFN1Ym1pc3Npb24nLFxuICAgIGRlc2NyaXB0aW9uOiAnTG9nIGludG8gY2VudHJhbC9zdGF0ZSBwb3J0YWwgKEFhcGxlIFNhcmthciwgU2FyYXRoaSwgTWFoYWRidCksIGNvbXBsZXRlIGZvcm0gZW50cnksIGFuZCBzdWJtaXQuJyxcbiAgICB0b29sc1VzZWQ6IFsnNTArIEdvdnQgUG9ydGFscyBEaXJlY3RvcnknLCAnUERGIHRvIEhEIEpQRyBDb252ZXJ0ZXInXSxcbiAgICBjaGVja2xpc3Q6IFtcbiAgICAgICdFbnRlciBhcHBsaWNhbnQgZGV0YWlscyBtYXRjaGluZyBBYWRoYWFyIGxldHRlciBieSBsZXR0ZXInLFxuICAgICAgJ0lmIHBvcnRhbCByZXF1aXJlcyBKUEcgdW5kZXIgMTAwS0IsIHVzZSBQREYgdG8gSlBHIHRvb2wgdG8gY29tcHJlc3MgZG9jdW1lbnRzJyxcbiAgICAgICdWZXJpZnkgdXBsb2FkZWQgY2VydGlmaWNhdGUgcHJldmlld3MgYmVmb3JlIGZpbmFsIHN1Ym1pc3Npb24nLFxuICAgICAgJ0Rvd25sb2FkIGFuZCBzYXZlIG9mZmljaWFsIGFja25vd2xlZGdlbWVudCBQREYnXG4gICAgXSxcbiAgICB0aXBzOiAnQWNrbm93bGVkZ2VtZW50IFJlY2VpcHQgVG9rZW4gTnVtYmVyIGhhbWVzaGEgZG93bmxvYWQga2Fya2UgQ3VzdG9tZXIgQ1JNIG1laW4gbm90ZSBrYXJlaW4uJ1xuICB9LFxuICB7XG4gICAgc3RlcE51bWJlcjogMyxcbiAgICB0aXRsZTogJ1N0dWRpbyBQaG90byAmIFBWQyBTbWFydCBDYXJkIFByb2Nlc3NpbmcnLFxuICAgIGRlc2NyaXB0aW9uOiAnUHJvZHVjZSBoaWdoLXByZWNpc2lvbiBDUi04MCBQVkMgY2FyZHMgb3IgMzV4NDVtbSBwYXNzcG9ydCBwaG90byBzaGVldHMuJyxcbiAgICB0b29sc1VzZWQ6IFsnUFZDIFNtYXJ0IENhcmQgTWFrZXInLCAnUGFzc3BvcnQgUGhvdG8gU3R1ZGlvIFBybyddLFxuICAgIGNoZWNrbGlzdDogW1xuICAgICAgJ1Bhc3Nwb3J0IFBob3RvOiBTZWxlY3QgNMOXNiBMYW5kc2NhcGUgKDggQ29waWVzIEAgMzAwIERQSSkgb3IgQTQgTGFuZHNjYXBlJyxcbiAgICAgICdCYWNrZ3JvdW5kOiBVc2UgQ29ubmVjdGVkIE1hZ2ljIFdhbmQgb3IgUGVuIFRvb2wgdG8gY3V0IG91dCBwZXJzb24gYW5kIHNldCBXaGl0ZS9TdHVkaW8gQmx1ZSBCRycsXG4gICAgICAnQXV0byBCZWF1dHk6IEFwcGx5IEFJIEZhY2UgU21vb3RoaW5nIHRvIGJyaWdodGVuIHNraW4gdG9uZXMgYW5kIHJlZHVjZSBjYW1lcmEgc2hhZG93cycsXG4gICAgICAnRXhhbSBTdHJpcDogQWRkIENhbmRpZGF0ZSBOYW1lICYgRGF0ZSBzdGFtcCBmb3IgU1NDIEdELCBQb2xpY2UgQmhhcnRpLCBvciBSYWlsd2F5IGZvcm1zJyxcbiAgICAgICdQVkMgQ2FyZDogQWxpZ24gRnJvbnQgJiBCYWNrIGNhcmRzIHRvIHN0YW5kYXJkIENSLTgwICg4NS42w5c1NG1tKSB3aXRoIGNlbnRlciBjdXQgZ3VpZGUgbGluZSdcbiAgICBdLFxuICAgIHRpcHM6ICdQVkMgQ2FyZCBwcmludCBrYXJ0ZSB3YXF0IHByaW50ZXIgcHJvcGVydGllcyBtZWluIFwiSGlnaCBRdWFsaXR5IEdsb3NzeSBQaG90byBQYXBlclwiIHNlbGVjdCBrYXJlaW4uJ1xuICB9LFxuICB7XG4gICAgc3RlcE51bWJlcjogNCxcbiAgICB0aXRsZTogJzMwMCBEUEkgUGh5c2ljYWwgUHJpbnRpbmcgJiBUaGVybWFsIExhbWluYXRpb24nLFxuICAgIGRlc2NyaXB0aW9uOiAnRXhlY3V0ZSBpbi1hcHAgYm9yZGVybGVzcyBwcmludGluZyBvbiBwaG90byBwYXBlciwgY3V0IGNhcmRzLCBhbmQgbGFtaW5hdGUuJyxcbiAgICB0b29sc1VzZWQ6IFsnSW4tQXBwIERpcmVjdCBQcmludCBFbmdpbmUgKEN0cmwgKyBQKSddLFxuICAgIGNoZWNrbGlzdDogW1xuICAgICAgJ0xvYWQgNMOXNiBpbmNoICgxMMOXMTUgY20pIEdsb3NzeSBQaG90byBQYXBlciBpbnRvIHByaW50ZXInLFxuICAgICAgJ1ByZXNzIFwi8J+WqO+4jyBEaXJlY3QgUHJpbnQgU2hlZXQgKEN0cmwgKyBQKVwiIGRpcmVjdGx5IGluc2lkZSBzdHVkaW8nLFxuICAgICAgJ0N1dCBhbG9uZyBwcmUtYWxpZ25lZCBndWlkZSBtYXJrcycsXG4gICAgICAnRm9yIFBWQyBTbWFydCBDYXJkczogUGFzcyB0aHJvdWdoIHRoZXJtYWwgbGFtaW5hdG9yIGZvciBkdXJhYmxlIHdhdGVycHJvb2YgZmluaXNoJ1xuICAgIF0sXG4gICAgdGlwczogJ0luLWFwcCBkaXJlY3QgcHJpbnQgemVybyBwb3B1cCBibG9ja2VyIGtlIHNhYXRoIHNlZWRoYSBjb25uZWN0ZWQgcHJpbnRlciBwYXIgMzAwIERQSSBqb2IgYmhlanRhIGhhaS4nXG4gIH0sXG4gIHtcbiAgICBzdGVwTnVtYmVyOiA1LFxuICAgIHRpdGxlOiAnUE9TIEJpbGxpbmcgJiBUaGVybWFsIFJlY2VpcHQgR2VuZXJhdGlvbicsXG4gICAgZGVzY3JpcHRpb246ICdHZW5lcmF0ZSBpdGVtaXplZCB0YXggaW52b2ljZSBvciA1OG1tLzgwbW0gdGhlcm1hbCBzbGlwIHdpdGggZHluYW1pYyBVUEkgUVIgY29kZS4nLFxuICAgIHRvb2xzVXNlZDogWydGYXN0IEJpbGxpbmcgRGVzayBQT1MnXSxcbiAgICBjaGVja2xpc3Q6IFtcbiAgICAgICdTZWxlY3Qgc2VydmljZSBwYWNrYWdlIChlLmcuIFBWQyBDYXJkIOKCuTcwLCBQYXNzcG9ydCBQaG90byA4LWNvcGllcyDigrk1MCwgT25saW5lIEZvcm0g4oK5MTAwKScsXG4gICAgICAnRGlzcGxheSBkeW5hbWljIFVQSSBRUiBjb2RlIG9uIHNjcmVlbiBmb3IgaW5zdGFudCBjdXN0b21lciBwYXltZW50JyxcbiAgICAgICdQcmludCA1OG1tIHRoZXJtYWwgcmVjZWlwdCBvciBBNCBvZmZpY2lhbCB0YXggaW52b2ljZSBmb3IgY3VzdG9tZXIgcmVjb3JkcycsXG4gICAgICAnVXBkYXRlIHBheW1lbnQgc3RhdHVzIGFzIFwiUGFpZFwiIGluIGxlZGdlcidcbiAgICBdLFxuICAgIHRpcHM6ICdUaGVybWFsIHJlY2VpcHQgcGFyIHNob3Aga2EgYXV0aG9yaXplZCBzaWduYXR1cmUgYXVyIG5vbi1yZWZ1bmRhYmxlIHBvcnRhbCB0ZXJtcyBhdXRvbWF0aWMgYWF0ZSBoYWluLidcbiAgfSxcbiAge1xuICAgIHN0ZXBOdW1iZXI6IDYsXG4gICAgdGl0bGU6ICdDdXN0b21lciBIYW5kb3ZlciAmIERhaWx5IENhc2ggUmVjb25jaWxpYXRpb24nLFxuICAgIGRlc2NyaXB0aW9uOiAnSGFuZCBvdmVyIGxhbWluYXRlZCBjYXJkcywgcGFzc3BvcnQgcGhvdG9zIGluIHNsZWV2ZSwgYW5kIHBvcnRhbCBhY2tub3dsZWRnZW1lbnQuJyxcbiAgICB0b29sc1VzZWQ6IFsnQ3VzdG9tZXIgQ1JNICYgSm9iIFRyYWNrZXInXSxcbiAgICBjaGVja2xpc3Q6IFtcbiAgICAgICdIYW5kIG92ZXIgbGFtaW5hdGVkIGNhcmRzLCBwYXNzcG9ydCBwaG90b3MgaW4gc2xlZXZlLCBhbmQgcG9ydGFsIGFja25vd2xlZGdlbWVudCcsXG4gICAgICAnU2VuZCBXaGF0c0FwcCBjb25maXJtYXRpb24gd2l0aCBzdGF0dXMgdXBkYXRlJyxcbiAgICAgICdNYXJrIGpvYiBhcyBcIkRlbGl2ZXJlZFwiIGluIENSTSBUcmFja2VyJyxcbiAgICAgICdEYWlseSByZWNvbmNpbGlhdGlvbjogQ2hlY2sgdG90YWwgY2FzaCArIFVQSSBjb2xsZWN0aW9ucyBpbiBCaWxsaW5nIERlc2sgU3VtbWFyeSdcbiAgICBdLFxuICAgIHRpcHM6ICdEaW4ga2UgZW5kIHBhciBEYWlseSBMZWRnZXIgU3VtbWFyeSBzZSBjYXNoIGNvdW50ZXIgYmFsYW5jZSBtYXRjaCBrYXJlaW4uJ1xuICB9XG5dO1xuXG5leHBvcnQgY29uc3QgTWFzdGVyQWRtaW5WaWV3OiBSZWFjdC5GQzxNYXN0ZXJBZG1pblZpZXdQcm9wcz4gPSAoe1xuICBzZXR0aW5ncyxcbiAgb25VcGRhdGVTZXR0aW5ncyxcbiAgb25OYXZpZ2F0ZVRvV29ya2Zsb3dcbn0pID0+IHtcbiAgY29uc3QgW29wZXJhdG9ycywgc2V0T3BlcmF0b3JzXSA9IHVzZVN0YXRlPE9wZXJhdG9yQWNjb3VudFtdPihbXSk7XG4gIGNvbnN0IFthdWRpdExvZ3MsIHNldEF1ZGl0TG9nc10gPSB1c2VTdGF0ZTxTZWN1cml0eUF1ZGl0TG9nW10+KFtdKTtcbiAgY29uc3QgW2FjdGl2ZVN1YlRhYiwgc2V0QWN0aXZlU3ViVGFiXSA9IHVzZVN0YXRlPCdsaXZlX21vbml0b3InIHwgJ29wZXJhdG9ycycgfCAnd29ya2Zsb3cnIHwgJ3ppcF9kb3dubG9hZCcgfCAnbG9ncycgfCAnc2V0dGluZ3MnPignbGl2ZV9tb25pdG9yJyk7XG5cbiAgLy8gTGl2ZSBNb25pdG9yaW5nIFN0YXRlXG4gIGNvbnN0IFtsaXZlU2Vzc2lvbnMsIHNldExpdmVTZXNzaW9uc10gPSB1c2VTdGF0ZTxMaXZlT3BlcmF0b3JTZXNzaW9uW10+KFtdKTtcbiAgY29uc3QgW2lzQXV0b1JlZnJlc2hpbmcsIHNldElzQXV0b1JlZnJlc2hpbmddID0gdXNlU3RhdGU8Ym9vbGVhbj4odHJ1ZSk7XG4gIGNvbnN0IFtsYXN0UmVmcmVzaGVkQXQsIHNldExhc3RSZWZyZXNoZWRBdF0gPSB1c2VTdGF0ZTxzdHJpbmc+KCcnKTtcblxuICAvLyBSZW5ld2FsIE1vZGFsIFN0YXRlXG4gIGNvbnN0IFtzZWxlY3RlZE9wRm9yUmVuZXcsIHNldFNlbGVjdGVkT3BGb3JSZW5ld10gPSB1c2VTdGF0ZTxPcGVyYXRvckFjY291bnQgfCBudWxsPihudWxsKTtcbiAgY29uc3QgW3JlbmV3RGF5c0NvdW50LCBzZXRSZW5ld0RheXNDb3VudF0gPSB1c2VTdGF0ZTxudW1iZXI+KDMwKTtcblxuICAvLyBCcm9hZGNhc3QgQWxlcnQgTW9kYWxcbiAgY29uc3QgW2Jyb2FkY2FzdFRhcmdldFVzZXJuYW1lLCBzZXRCcm9hZGNhc3RUYXJnZXRVc2VybmFtZV0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcbiAgY29uc3QgW2Jyb2FkY2FzdE1lc3NhZ2VUZXh0LCBzZXRCcm9hZGNhc3RNZXNzYWdlVGV4dF0gPSB1c2VTdGF0ZTxzdHJpbmc+KCcnKTtcblxuICAvLyBOZXcgT3BlcmF0b3IgTW9kYWwgU3RhdGVcbiAgY29uc3QgW3Nob3dBZGRNb2RhbCwgc2V0U2hvd0FkZE1vZGFsXSA9IHVzZVN0YXRlPGJvb2xlYW4+KGZhbHNlKTtcbiAgY29uc3QgW25ld1VzZXJuYW1lLCBzZXROZXdVc2VybmFtZV0gPSB1c2VTdGF0ZTxzdHJpbmc+KCcnKTtcbiAgY29uc3QgW25ld1Bhc3N3b3JkLCBzZXROZXdQYXNzd29yZF0gPSB1c2VTdGF0ZTxzdHJpbmc+KCcnKTtcbiAgY29uc3QgW25ld0Rpc3BsYXlOYW1lLCBzZXROZXdEaXNwbGF5TmFtZV0gPSB1c2VTdGF0ZTxzdHJpbmc+KCcnKTtcbiAgY29uc3QgW25ld1Bob25lLCBzZXROZXdQaG9uZV0gPSB1c2VTdGF0ZTxzdHJpbmc+KCcnKTtcbiAgY29uc3QgW2FkZEVycm9yLCBzZXRBZGRFcnJvcl0gPSB1c2VTdGF0ZTxzdHJpbmc+KCcnKTtcblxuICAvLyBQcm9qZWN0IFpJUCBFeHBvcnQgU3RhdGVcbiAgY29uc3QgW2lzRXhwb3J0aW5nWmlwLCBzZXRJc0V4cG9ydGluZ1ppcF0gPSB1c2VTdGF0ZTxib29sZWFuPihmYWxzZSk7XG4gIGNvbnN0IFt6aXBQcm9ncmVzcywgc2V0WmlwUHJvZ3Jlc3NdID0gdXNlU3RhdGU8eyBwZXJjZW50OiBudW1iZXI7IGZpbGU6IHN0cmluZyB9Pih7IHBlcmNlbnQ6IDAsIGZpbGU6ICcnIH0pO1xuXG4gIC8vIE5vdGlmaWNhdGlvbnNcbiAgY29uc3QgW2FsZXJ0TWVzc2FnZSwgc2V0QWxlcnRNZXNzYWdlXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuXG4gIC8vIFNob3AgU2V0dGluZ3MgRm9ybVxuICBjb25zdCBbc2hvcEZvcm0sIHNldFNob3BGb3JtXSA9IHVzZVN0YXRlPFNob3BTZXR0aW5ncz4oc2V0dGluZ3MpO1xuXG4gIC8vIFdvcmtmbG93IENoZWNrbGlzdCBzdGF0ZSBpbnNpZGUgTWFzdGVyIEFkbWluXG4gIGNvbnN0IFtjb21wbGV0ZWRTdGVwcywgc2V0Q29tcGxldGVkU3RlcHNdID0gdXNlU3RhdGU8UmVjb3JkPG51bWJlciwgYm9vbGVhbj4+KHt9KTtcblxuICBjb25zdCBjdXJyZW50RGV2aWNlSWQgPSBnZXRIYXJkd2FyZURldmljZUlkKCk7XG4gIGNvbnN0IGN1cnJlbnREZXZpY2VOYW1lID0gZ2V0SGFyZHdhcmVEZXZpY2VOYW1lKCk7XG4gIGNvbnN0IGN1cnJlbnRJc01vYmlsZSA9IGlzTW9iaWxlRGV2aWNlKCk7XG5cbiAgY29uc3QgbG9hZERhdGEgPSAoKSA9PiB7XG4gICAgc2V0T3BlcmF0b3JzKGdldFJlZ2lzdGVyZWRPcGVyYXRvcnMoKSk7XG4gICAgc2V0QXVkaXRMb2dzKGdldFNlY3VyaXR5QXVkaXRMb2dzKCkpO1xuICB9O1xuXG4gIGNvbnN0IHJlZnJlc2hMaXZlU2Vzc2lvbnMgPSBhc3luYyAoKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHNlc3Npb25zID0gYXdhaXQgZ2V0TGl2ZU9wZXJhdG9yU2Vzc2lvbnMoKTtcbiAgICAgIHNldExpdmVTZXNzaW9ucyhzZXNzaW9ucyk7XG4gICAgICBzZXRMYXN0UmVmcmVzaGVkQXQobmV3IERhdGUoKS50b0xvY2FsZVRpbWVTdHJpbmcoKSk7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgY29uc29sZS5lcnJvcihlKTtcbiAgICB9XG4gIH07XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBsb2FkRGF0YSgpO1xuICAgIHJlZnJlc2hMaXZlU2Vzc2lvbnMoKTtcbiAgfSwgW10pO1xuXG4gIC8vIFJlYWwtVGltZSAzLjVzIExpdmUgUG9sbGluZyBIZWFydGJlYXRcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoIWlzQXV0b1JlZnJlc2hpbmcpIHJldHVybjtcbiAgICBjb25zdCBpbnRlcnZhbCA9IHNldEludGVydmFsKCgpID0+IHtcbiAgICAgIHJlZnJlc2hMaXZlU2Vzc2lvbnMoKTtcbiAgICB9LCAzNTAwKTtcbiAgICByZXR1cm4gKCkgPT4gY2xlYXJJbnRlcnZhbChpbnRlcnZhbCk7XG4gIH0sIFtpc0F1dG9SZWZyZXNoaW5nXSk7XG5cbiAgLy8gSGFuZGxlIExpY2Vuc2UgLyBBY2Nlc3MgUmVuZXdhbFxuICBjb25zdCBoYW5kbGVFeGVjdXRlUmVuZXdhbCA9ICgpID0+IHtcbiAgICBpZiAoIXNlbGVjdGVkT3BGb3JSZW5ldykgcmV0dXJuO1xuICAgIGNvbnN0IHJlc3VsdCA9IHJlbmV3T3BlcmF0b3JMaWNlbnNlKHNlbGVjdGVkT3BGb3JSZW5ldy5pZCwgcmVuZXdEYXlzQ291bnQpO1xuICAgIGlmIChyZXN1bHQuc3VjY2Vzcykge1xuICAgICAgbG9hZERhdGEoKTtcbiAgICAgIHJlZnJlc2hMaXZlU2Vzc2lvbnMoKTtcbiAgICAgIHNldEFsZXJ0TWVzc2FnZShg4pyFIEFjY2VzcyBSZW5ld2VkIGZvciBcIiR7c2VsZWN0ZWRPcEZvclJlbmV3LmRpc3BsYXlOYW1lfVwiISBWYWxpZCB1bnRpbCAke3Jlc3VsdC5uZXdFeHBpcnl9ICgke3Jlc3VsdC5kYXlzTGVmdH0gZGF5cyByZW1haW5pbmcpYCk7XG4gICAgICBzZXRTZWxlY3RlZE9wRm9yUmVuZXcobnVsbCk7XG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHNldEFsZXJ0TWVzc2FnZShudWxsKSwgNTAwMCk7XG4gICAgfVxuICB9O1xuXG4gIC8vIEhhbmRsZSBGb3JjZSBEaXNjb25uZWN0IExpdmUgU2Vzc2lvblxuICBjb25zdCBoYW5kbGVGb3JjZURpc2Nvbm5lY3QgPSBhc3luYyAodXNlcm5hbWU6IHN0cmluZywgZGV2aWNlSWQ/OiBzdHJpbmcpID0+IHtcbiAgICBpZiAod2luZG93LmNvbmZpcm0oYEZvcmNlIHRlcm1pbmF0ZSBhY3RpdmUgc2Vzc2lvbiBmb3IgQCR7dXNlcm5hbWV9PyBPcGVyYXRvciB3aWxsIGJlIGltbWVkaWF0ZWx5IGxvZ2dlZCBvdXQuYCkpIHtcbiAgICAgIGF3YWl0IGZvcmNlRGlzY29ubmVjdE9wZXJhdG9yKHVzZXJuYW1lLCBkZXZpY2VJZCk7XG4gICAgICByZWZyZXNoTGl2ZVNlc3Npb25zKCk7XG4gICAgICBzZXRBbGVydE1lc3NhZ2UoYPCfmqggU2Vzc2lvbiBmb3IgQCR7dXNlcm5hbWV9IGhhcyBiZWVuIGZvcmNlZnVsbHkgdGVybWluYXRlZC5gKTtcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0QWxlcnRNZXNzYWdlKG51bGwpLCA0MDAwKTtcbiAgICB9XG4gIH07XG5cbiAgLy8gSGFuZGxlIFNlbmQgSW4tQXBwIEJyb2FkY2FzdCBBbGVydFxuICBjb25zdCBoYW5kbGVTZW5kQnJvYWRjYXN0ID0gYXN5bmMgKCkgPT4ge1xuICAgIGlmICghYnJvYWRjYXN0VGFyZ2V0VXNlcm5hbWUgfHwgIWJyb2FkY2FzdE1lc3NhZ2VUZXh0LnRyaW0oKSkgcmV0dXJuO1xuICAgIGF3YWl0IHNlbmRPcGVyYXRvckJyb2FkY2FzdE1lc3NhZ2UoYnJvYWRjYXN0VGFyZ2V0VXNlcm5hbWUsIGJyb2FkY2FzdE1lc3NhZ2VUZXh0LnRyaW0oKSk7XG4gICAgc2V0QWxlcnRNZXNzYWdlKGDwn5OiIEFsZXJ0IG1lc3NhZ2Ugc2VudCB0byBAJHticm9hZGNhc3RUYXJnZXRVc2VybmFtZX0hYCk7XG4gICAgc2V0QnJvYWRjYXN0VGFyZ2V0VXNlcm5hbWUobnVsbCk7XG4gICAgc2V0QnJvYWRjYXN0TWVzc2FnZVRleHQoJycpO1xuICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0QWxlcnRNZXNzYWdlKG51bGwpLCA0MDAwKTtcbiAgfTtcblxuICAvLyBIYW5kbGUgUmVzZXQgUEMgQmluZGluZ1xuICBjb25zdCBoYW5kbGVSZXNldFBjID0gKG9wZXJhdG9ySWQ6IHN0cmluZywgdXNlcm5hbWU6IHN0cmluZykgPT4ge1xuICAgIGlmICh3aW5kb3cuY29uZmlybShgUmVzZXQgUEMgRGV2aWNlIEJpbmRpbmcgZm9yIFwiJHt1c2VybmFtZX1cIj8gT3BlcmF0b3IgY2FuIG5vdyBsb2cgaW4gb24gYSBuZXcgUEMvTGFwdG9wLmApKSB7XG4gICAgICByZXNldE9wZXJhdG9yUGNCaW5kaW5nKG9wZXJhdG9ySWQpO1xuICAgICAgbG9hZERhdGEoKTtcbiAgICAgIHJlZnJlc2hMaXZlU2Vzc2lvbnMoKTtcbiAgICAgIHNldEFsZXJ0TWVzc2FnZShg4pyFIFBDIGRldmljZSBiaW5kaW5nIGNsZWFyZWQgZm9yICR7dXNlcm5hbWV9LiBPcGVyYXRvciBjYW4gYmluZCBhIG5ldyBQQy5gKTtcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0QWxlcnRNZXNzYWdlKG51bGwpLCA0MDAwKTtcbiAgICB9XG4gIH07XG5cbiAgLy8gSGFuZGxlIFJlc2V0IE1vYmlsZSBCaW5kaW5nXG4gIGNvbnN0IGhhbmRsZVJlc2V0TW9iaWxlID0gKG9wZXJhdG9ySWQ6IHN0cmluZywgdXNlcm5hbWU6IHN0cmluZykgPT4ge1xuICAgIGlmICh3aW5kb3cuY29uZmlybShgUmVzZXQgTW9iaWxlIERldmljZSBCaW5kaW5nIGZvciBcIiR7dXNlcm5hbWV9XCI/IE9wZXJhdG9yIGNhbiBub3cgbG9nIGluIG9uIGEgbmV3IFNtYXJ0cGhvbmUuYCkpIHtcbiAgICAgIHJlc2V0T3BlcmF0b3JNb2JpbGVCaW5kaW5nKG9wZXJhdG9ySWQpO1xuICAgICAgbG9hZERhdGEoKTtcbiAgICAgIHJlZnJlc2hMaXZlU2Vzc2lvbnMoKTtcbiAgICAgIHNldEFsZXJ0TWVzc2FnZShg4pyFIE1vYmlsZSBkZXZpY2UgYmluZGluZyBjbGVhcmVkIGZvciAke3VzZXJuYW1lfS4gT3BlcmF0b3IgY2FuIGJpbmQgYSBuZXcgcGhvbmUuYCk7XG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHNldEFsZXJ0TWVzc2FnZShudWxsKSwgNDAwMCk7XG4gICAgfVxuICB9O1xuXG4gIC8vIEhhbmRsZSBSZXNldCBBbGwgRGV2aWNlcyAoUEMgKyBNb2JpbGUpXG4gIGNvbnN0IGhhbmRsZVJlc2V0QWxsRGV2aWNlcyA9IChvcGVyYXRvcklkOiBzdHJpbmcsIHVzZXJuYW1lOiBzdHJpbmcpID0+IHtcbiAgICBpZiAod2luZG93LmNvbmZpcm0oYFJlc2V0IEJPVEggUEMgJiBNb2JpbGUgYmluZGluZ3MgZm9yIFwiJHt1c2VybmFtZX1cIj9gKSkge1xuICAgICAgcmVzZXRPcGVyYXRvckFsbEJpbmRpbmdzKG9wZXJhdG9ySWQpO1xuICAgICAgbG9hZERhdGEoKTtcbiAgICAgIHJlZnJlc2hMaXZlU2Vzc2lvbnMoKTtcbiAgICAgIHNldEFsZXJ0TWVzc2FnZShg4pyFIEFsbCBkZXZpY2UgYmluZGluZ3MgKFBDICYgTW9iaWxlKSBjbGVhcmVkIGZvciAke3VzZXJuYW1lfS5gKTtcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0QWxlcnRNZXNzYWdlKG51bGwpLCA0MDAwKTtcbiAgICB9XG4gIH07XG5cbiAgLy8gSGFuZGxlIFRvZ2dsZSBMb2NrXG4gIGNvbnN0IGhhbmRsZVRvZ2dsZUxvY2sgPSAob3BlcmF0b3JJZDogc3RyaW5nLCB1c2VybmFtZTogc3RyaW5nKSA9PiB7XG4gICAgdG9nZ2xlT3BlcmF0b3JMb2NrKG9wZXJhdG9ySWQpO1xuICAgIGxvYWREYXRhKCk7XG4gICAgcmVmcmVzaExpdmVTZXNzaW9ucygpO1xuICAgIHNldEFsZXJ0TWVzc2FnZShgTG9jayBzdGF0dXMgdXBkYXRlZCBmb3IgJHt1c2VybmFtZX1gKTtcbiAgICBzZXRUaW1lb3V0KCgpID0+IHNldEFsZXJ0TWVzc2FnZShudWxsKSwgMzAwMCk7XG4gIH07XG5cbiAgLy8gSGFuZGxlIERlbGV0ZSBPcGVyYXRvclxuICBjb25zdCBoYW5kbGVEZWxldGVPcGVyYXRvciA9IChvcGVyYXRvcklkOiBzdHJpbmcsIHVzZXJuYW1lOiBzdHJpbmcpID0+IHtcbiAgICBpZiAod2luZG93LmNvbmZpcm0oYFBlcm1hbmVudGx5IGRlbGV0ZSBvcGVyYXRvciBhY2NvdW50IFwiJHt1c2VybmFtZX1cIj9gKSkge1xuICAgICAgZGVsZXRlT3BlcmF0b3Iob3BlcmF0b3JJZCk7XG4gICAgICBsb2FkRGF0YSgpO1xuICAgICAgcmVmcmVzaExpdmVTZXNzaW9ucygpO1xuICAgICAgc2V0QWxlcnRNZXNzYWdlKGBPcGVyYXRvciAke3VzZXJuYW1lfSBkZWxldGVkYCk7XG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHNldEFsZXJ0TWVzc2FnZShudWxsKSwgMzAwMCk7XG4gICAgfVxuICB9O1xuXG4gIC8vIEhhbmRsZSBBZGQgT3BlcmF0b3JcbiAgY29uc3QgaGFuZGxlQ3JlYXRlT3BlcmF0b3IgPSAoZTogUmVhY3QuRm9ybUV2ZW50KSA9PiB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgIHNldEFkZEVycm9yKCcnKTtcblxuICAgIGlmICghbmV3VXNlcm5hbWUudHJpbSgpIHx8ICFuZXdQYXNzd29yZC50cmltKCkgfHwgIW5ld0Rpc3BsYXlOYW1lLnRyaW0oKSkge1xuICAgICAgc2V0QWRkRXJyb3IoJ1BsZWFzZSBmaWxsIGFsbCByZXF1aXJlZCBmaWVsZHMnKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBjb25zdCBzdWNjZXNzID0gYWRkTmV3T3BlcmF0b3Ioe1xuICAgICAgdXNlcm5hbWU6IG5ld1VzZXJuYW1lLnRyaW0oKS50b0xvd2VyQ2FzZSgpLFxuICAgICAgcGFzc3dvcmQ6IG5ld1Bhc3N3b3JkLnRyaW0oKSxcbiAgICAgIGRpc3BsYXlOYW1lOiBuZXdEaXNwbGF5TmFtZS50cmltKCksXG4gICAgICByb2xlOiAnb3BlcmF0b3InLFxuICAgICAgcGhvbmU6IG5ld1Bob25lLnRyaW0oKSB8fCAnOTU2MTQ2MDMxMydcbiAgICB9KTtcblxuICAgIGlmIChzdWNjZXNzKSB7XG4gICAgICBzZXRTaG93QWRkTW9kYWwoZmFsc2UpO1xuICAgICAgc2V0TmV3VXNlcm5hbWUoJycpO1xuICAgICAgc2V0TmV3UGFzc3dvcmQoJycpO1xuICAgICAgc2V0TmV3RGlzcGxheU5hbWUoJycpO1xuICAgICAgc2V0TmV3UGhvbmUoJycpO1xuICAgICAgbG9hZERhdGEoKTtcbiAgICAgIHJlZnJlc2hMaXZlU2Vzc2lvbnMoKTtcbiAgICAgIHNldEFsZXJ0TWVzc2FnZSgn4pyFIE5ldyBPcGVyYXRvciBJRCBjcmVhdGVkISBQZXJtaXR0ZWQgb24gMSBBdXRob3JpemVkIFBDICsgMSBBdXRob3JpemVkIE1vYmlsZS4nKTtcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0QWxlcnRNZXNzYWdlKG51bGwpLCA0MDAwKTtcbiAgICB9IGVsc2Uge1xuICAgICAgc2V0QWRkRXJyb3IoJ1VzZXJuYW1lIGFscmVhZHkgZXhpc3RzLiBQbGVhc2UgY2hvb3NlIGFub3RoZXIgdXNlcm5hbWUuJyk7XG4gICAgfVxuICB9O1xuXG4gIC8vIEhhbmRsZSBEb3dubG9hZCBQcm9qZWN0IFpJUFxuICBjb25zdCBoYW5kbGVEb3dubG9hZFppcCA9IGFzeW5jICgpID0+IHtcbiAgICBzZXRJc0V4cG9ydGluZ1ppcCh0cnVlKTtcbiAgICBzZXRaaXBQcm9ncmVzcyh7IHBlcmNlbnQ6IDEwLCBmaWxlOiAnR2F0aGVyaW5nIHByb2plY3Qgc291cmNlIGZpbGVzLi4uJyB9KTtcblxuICAgIHRyeSB7XG4gICAgICBjb25zdCB6aXBCbG9iID0gYXdhaXQgZ2VuZXJhdGVQcm9qZWN0WmlwKChwZXJjZW50LCBmaWxlKSA9PiB7XG4gICAgICAgIHNldFppcFByb2dyZXNzKHsgcGVyY2VudCwgZmlsZSB9KTtcbiAgICAgIH0pO1xuXG4gICAgICB0cmlnZ2VyRG93bmxvYWRaaXAoemlwQmxvYiwgYE11emFtbWlsLU9ubGluZS1zZXJ2aWNlLXBjLnppcGApO1xuICAgICAgc2V0QWxlcnRNZXNzYWdlKCfwn5OmIENvbXBsZXRlIG9yaWdpbmFsIHByb2plY3Qgc291cmNlIGNvZGUgKC5aSVApIGRvd25sb2FkZWQgc3VjY2Vzc2Z1bGx5IScpO1xuICAgICAgc2V0VGltZW91dCgoKSA9PiBzZXRBbGVydE1lc3NhZ2UobnVsbCksIDQwMDApO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoZSk7XG4gICAgICB3aW5kb3cubG9jYXRpb24uaHJlZiA9ICcvYXBpL2Rvd25sb2FkLXppcCc7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldElzRXhwb3J0aW5nWmlwKGZhbHNlKTtcbiAgICB9XG4gIH07XG5cbiAgLy8gSGFuZGxlIFNhdmUgU2hvcCBTZXR0aW5nc1xuICBjb25zdCBoYW5kbGVTYXZlU2V0dGluZ3MgPSAoZTogUmVhY3QuRm9ybUV2ZW50KSA9PiB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgIG9uVXBkYXRlU2V0dGluZ3Moc2hvcEZvcm0pO1xuICAgIHNldEFsZXJ0TWVzc2FnZSgn4pyFIFNob3AgZGV0YWlscyBhbmQgY29uZmlndXJhdGlvbiBzYXZlZCEnKTtcbiAgICBzZXRUaW1lb3V0KCgpID0+IHNldEFsZXJ0TWVzc2FnZShudWxsKSwgMzAwMCk7XG4gIH07XG5cbiAgY29uc3QgY29tcGxldGVkV29ya2Zsb3dDb3VudCA9IE9iamVjdC52YWx1ZXMoY29tcGxldGVkU3RlcHMpLmZpbHRlcihCb29sZWFuKS5sZW5ndGg7XG4gIGNvbnN0IG9ubGluZUNvdW50ID0gbGl2ZVNlc3Npb25zLmZpbHRlcihzID0+IHMuaXNPbmxpbmUpLmxlbmd0aDtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XG4gICAgICB7LyogVG9wIEJhbm5lciAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHAtNSByb3VuZGVkLTJ4bCBzaGFkb3ctbWQgZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBzbTppdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC00XCI+XG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBmbGV4LXdyYXBcIj5cbiAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtZXh0cmFib2xkIHRleHQtd2hpdGUgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgPFNoaWVsZENoZWNrIGNsYXNzTmFtZT1cInctNiBoLTYgdGV4dC1ibHVlLTQwMFwiIC8+XG4gICAgICAgICAgICAgIDxzcGFuPk1hc3RlciBBZG1pbiBDb250cm9sICYgTGl2ZSBNb25pdG9yaW5nIEh1Yjwvc3Bhbj5cbiAgICAgICAgICAgIDwvaDE+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJiZy1lbWVyYWxkLTUwMC8yMCB0ZXh0LWVtZXJhbGQtMzAwIGJvcmRlciBib3JkZXItZW1lcmFsZC01MDAvMzAgdGV4dC14cyBweC0yLjUgcHktMC41IHJvdW5kZWQtZnVsbCBmb250LW1vbm8gZm9udC1ib2xkIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy0yIGgtMiByb3VuZGVkLWZ1bGwgYmctZW1lcmFsZC00MDAgYW5pbWF0ZS1wdWxzZVwiPjwvc3Bhbj5cbiAgICAgICAgICAgICAgPHNwYW4+TGl2ZToge29ubGluZUNvdW50fSBBY3RpdmUgT25saW5lPC9zcGFuPlxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS00MDAgbXQtMVwiPlxuICAgICAgICAgICAgUmVhbC1UaW1lIE9wZXJhdG9yIEFjdGl2aXR5IE1vbml0b3Ig4oCiIExpY2Vuc2UgUmVuZXdhbHMg4oCiIER1YWwtRGV2aWNlIFBDICYgTW9iaWxlIFNlY3VyaXR5IOKAoiBDZW50cmFsIFNldHVwXG4gICAgICAgICAgPC9wPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogQWN0aW9uIEJ1dHRvbnMgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgZmxleC13cmFwXCI+XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17aGFuZGxlRG93bmxvYWRaaXB9XG4gICAgICAgICAgICBkaXNhYmxlZD17aXNFeHBvcnRpbmdaaXB9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBiZy1ncmFkaWVudC10by1yIGZyb20tZW1lcmFsZC02MDAgdG8tdGVhbC02MDAgaG92ZXI6ZnJvbS1lbWVyYWxkLTUwMCBob3Zlcjp0by10ZWFsLTUwMCB0ZXh0LXdoaXRlIGZvbnQtZXh0cmFib2xkIHRleHQteHMgcHgtNCBweS0yLjUgcm91bmRlZC14bCBzaGFkb3ctbGcgc2hhZG93LWVtZXJhbGQtNjAwLzIwIHRyYW5zaXRpb24tYWxsIGhvdmVyOnNjYWxlLTEwNSBkaXNhYmxlZDpvcGFjaXR5LTUwXCJcbiAgICAgICAgICAgIHRpdGxlPVwiRG93bmxvYWQgZnVsbCBwcm9qZWN0IHNvdXJjZSBjb2RlIGFyY2hpdmUgKC56aXApXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8QXJjaGl2ZSBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgIDxzcGFuPntpc0V4cG9ydGluZ1ppcCA/ICdQYWNraW5nIFpJUC4uLicgOiAn8J+TpiBEb3dubG9hZCBQcm9qZWN0IC5aSVAnfTwvc3Bhbj5cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIE5vdGlmaWNhdGlvbnMgKi99XG4gICAgICB7YWxlcnRNZXNzYWdlICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMuNSByb3VuZGVkLXhsIGJnLWVtZXJhbGQtNTAwLzEwIGJvcmRlciBib3JkZXItZW1lcmFsZC01MDAvMzAgdGV4dC1lbWVyYWxkLTQwMCB0ZXh0LXhzIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBhbmltYXRlLWluIGZhZGUtaW5cIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICA8Q2hlY2tDaXJjbGUyIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1lbWVyYWxkLTQwMCBmbGV4LXNocmluay0wXCIgLz5cbiAgICAgICAgICAgIDxzcGFuPnthbGVydE1lc3NhZ2V9PC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gc2V0QWxlcnRNZXNzYWdlKG51bGwpfSBjbGFzc05hbWU9XCJ0ZXh0LWVtZXJhbGQtNDAwIGhvdmVyOnRleHQtd2hpdGVcIj7inJU8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuXG4gICAgICB7LyogU3ViLU5hdmlnYXRpb24gVGFicyAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcC0xLjUgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtYm9sZCBvdmVyZmxvdy14LWF1dG9cIj5cbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZVN1YlRhYignbGl2ZV9tb25pdG9yJyl9XG4gICAgICAgICAgY2xhc3NOYW1lPXtgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC00IHB5LTIgcm91bmRlZC1sZyB0cmFuc2l0aW9uLWFsbCAke1xuICAgICAgICAgICAgYWN0aXZlU3ViVGFiID09PSAnbGl2ZV9tb25pdG9yJ1xuICAgICAgICAgICAgICA/ICdiZy1yb3NlLTYwMCB0ZXh0LXdoaXRlIHNoYWRvdydcbiAgICAgICAgICAgICAgOiAndGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC13aGl0ZSdcbiAgICAgICAgICB9YH1cbiAgICAgICAgPlxuICAgICAgICAgIDxSYWRpbyBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LXdoaXRlIGFuaW1hdGUtcHVsc2VcIiAvPlxuICAgICAgICAgIDxzcGFuPvCflLQgTGl2ZSBPcGVyYXRvciBNb25pdG9yICh7b25saW5lQ291bnR9KTwvc3Bhbj5cbiAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZVN1YlRhYignb3BlcmF0b3JzJyl9XG4gICAgICAgICAgY2xhc3NOYW1lPXtgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC00IHB5LTIgcm91bmRlZC1sZyB0cmFuc2l0aW9uLWFsbCAke1xuICAgICAgICAgICAgYWN0aXZlU3ViVGFiID09PSAnb3BlcmF0b3JzJ1xuICAgICAgICAgICAgICA/ICdiZy1ibHVlLTYwMCB0ZXh0LXdoaXRlIHNoYWRvdydcbiAgICAgICAgICAgICAgOiAndGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC13aGl0ZSdcbiAgICAgICAgICB9YH1cbiAgICAgICAgPlxuICAgICAgICAgIDxNb25pdG9yIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cbiAgICAgICAgICA8c3Bhbj5PcGVyYXRvciBJRHMgJiBMb2NrcyAoe29wZXJhdG9ycy5sZW5ndGh9KTwvc3Bhbj5cbiAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZVN1YlRhYignd29ya2Zsb3cnKX1cbiAgICAgICAgICBjbGFzc05hbWU9e2BmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTQgcHktMiByb3VuZGVkLWxnIHRyYW5zaXRpb24tYWxsICR7XG4gICAgICAgICAgICBhY3RpdmVTdWJUYWIgPT09ICd3b3JrZmxvdydcbiAgICAgICAgICAgICAgPyAnYmctYmx1ZS02MDAgdGV4dC13aGl0ZSBzaGFkb3cnXG4gICAgICAgICAgICAgIDogJ3RleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtd2hpdGUnXG4gICAgICAgICAgfWB9XG4gICAgICAgID5cbiAgICAgICAgICA8Q2xpcGJvYXJkTGlzdCBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LWFtYmVyLTQwMFwiIC8+XG4gICAgICAgICAgPHNwYW4+Q3liZXIgQ2FmZSBXb3JrZmxvdyAmIFNPUDwvc3Bhbj5cbiAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZVN1YlRhYignemlwX2Rvd25sb2FkJyl9XG4gICAgICAgICAgY2xhc3NOYW1lPXtgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC00IHB5LTIgcm91bmRlZC1sZyB0cmFuc2l0aW9uLWFsbCAke1xuICAgICAgICAgICAgYWN0aXZlU3ViVGFiID09PSAnemlwX2Rvd25sb2FkJ1xuICAgICAgICAgICAgICA/ICdiZy1ibHVlLTYwMCB0ZXh0LXdoaXRlIHNoYWRvdydcbiAgICAgICAgICAgICAgOiAndGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC13aGl0ZSdcbiAgICAgICAgICB9YH1cbiAgICAgICAgPlxuICAgICAgICAgIDxBcmNoaXZlIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtZW1lcmFsZC00MDBcIiAvPlxuICAgICAgICAgIDxzcGFuPlByb2plY3QgKC5aSVApIEV4cG9ydDwvc3Bhbj5cbiAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZVN1YlRhYignbG9ncycpfVxuICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtNCBweS0yIHJvdW5kZWQtbGcgdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgICAgIGFjdGl2ZVN1YlRhYiA9PT0gJ2xvZ3MnXG4gICAgICAgICAgICAgID8gJ2JnLWJsdWUtNjAwIHRleHQtd2hpdGUgc2hhZG93J1xuICAgICAgICAgICAgICA6ICd0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXdoaXRlJ1xuICAgICAgICAgIH1gfVxuICAgICAgICA+XG4gICAgICAgICAgPENsb2NrIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cbiAgICAgICAgICA8c3Bhbj5TZWN1cml0eSAmIERldmljZSBMb2dzPC9zcGFuPlxuICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QWN0aXZlU3ViVGFiKCdzZXR0aW5ncycpfVxuICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtNCBweS0yIHJvdW5kZWQtbGcgdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgICAgIGFjdGl2ZVN1YlRhYiA9PT0gJ3NldHRpbmdzJ1xuICAgICAgICAgICAgICA/ICdiZy1ibHVlLTYwMCB0ZXh0LXdoaXRlIHNoYWRvdydcbiAgICAgICAgICAgICAgOiAndGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC13aGl0ZSdcbiAgICAgICAgICB9YH1cbiAgICAgICAgPlxuICAgICAgICAgIDxLZXkgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICAgIDxzcGFuPk1hc3RlciBTZXR1cCBDZW50ZXI8L3NwYW4+XG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBUQUIgMDogTElWRSBVU0VSIE1PTklUT1JJTkcgJiBSRU5FV0FMIERFQ0sgKi99XG4gICAgICB7YWN0aXZlU3ViVGFiID09PSAnbGl2ZV9tb25pdG9yJyAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtMnhsIHAtNSBzaGFkb3cteGwgc3BhY2UteS00XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IHNtOml0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTMgcGItMyBib3JkZXItYiBib3JkZXItc2xhdGUtODAwXCI+XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtZXh0cmFib2xkIHRleHQtd2hpdGUgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICA8UmFkaW8gY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LXJvc2UtNTAwIGFuaW1hdGUtcHVsc2VcIiAvPlxuICAgICAgICAgICAgICAgIDxzcGFuPkxpdmUgT3BlcmF0b3IgQWN0aXZpdHkgJiBSZWFsLVRpbWUgUHVsc2U8L3NwYW4+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWVtZXJhbGQtNDAwIGJnLWVtZXJhbGQtNTAwLzEwIHB4LTIgcHktMC41IHJvdW5kZWQgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTUwMC8yMCBmb250LW1vbm9cIj5cbiAgICAgICAgICAgICAgICAgIDMuNXMgTGl2ZSBQaW5nXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8L2gyPlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwIG10LTAuNVwiPlxuICAgICAgICAgICAgICAgIFNlZSBleGFjdGx5IHdoaWNoIG9wZXJhdG9yIGlzIHdvcmtpbmcgb24gd2hhdCBzdHVkaW8gaW4gcmVhbC10aW1lLCB0aGVpciBhY3RpdmUgUEMvTW9iaWxlLCBhbmQgcmVuZXcgYWNjZXNzLlxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0SXNBdXRvUmVmcmVzaGluZyghaXNBdXRvUmVmcmVzaGluZyl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtMyBweS0xLjUgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtYm9sZCBib3JkZXIgdHJhbnNpdGlvbi1jb2xvcnMgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSAke1xuICAgICAgICAgICAgICAgICAgaXNBdXRvUmVmcmVzaGluZyBcbiAgICAgICAgICAgICAgICAgICAgPyAnYmctZW1lcmFsZC01MDAvMTAgdGV4dC1lbWVyYWxkLTMwMCBib3JkZXItZW1lcmFsZC01MDAvMzAnIFxuICAgICAgICAgICAgICAgICAgICA6ICdiZy1zbGF0ZS04MDAgdGV4dC1zbGF0ZS00MDAgYm9yZGVyLXNsYXRlLTcwMCdcbiAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxBY3Rpdml0eSBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XG4gICAgICAgICAgICAgICAgPHNwYW4+e2lzQXV0b1JlZnJlc2hpbmcgPyAnQXV0by1VcGRhdGU6IE9OJyA6ICdQYXVzZWQnfTwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e3JlZnJlc2hMaXZlU2Vzc2lvbnN9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xLjUgcm91bmRlZC14bCBiZy1zbGF0ZS04MDAgaG92ZXI6Ymctc2xhdGUtNzAwIHRleHQtc2xhdGUtMzAwIGhvdmVyOnRleHQtd2hpdGUgdGV4dC14c1wiXG4gICAgICAgICAgICAgICAgdGl0bGU9XCJSZWZyZXNoIExpdmUgRGF0YVwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8UmVmcmVzaEN3IGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBMaXZlIE1ldHJpYyBDYXJkcyAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTQgZ2FwLTMgdGV4dC14c1wiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05NTAgcC0zLjUgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBzcGFjZS15LTFcIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgYmxvY2sgdGV4dC1bMTFweF1cIj5BY3RpdmUgU3RhZmYgT25saW5lPC9zcGFuPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtZXh0cmFib2xkIHRleHQtd2hpdGUgZm9udC1tb25vIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy0yLjUgaC0yLjUgcm91bmRlZC1mdWxsIGJnLWVtZXJhbGQtNDAwIGFuaW1hdGUtcGluZ1wiPjwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8c3Bhbj57b25saW5lQ291bnR9PC9zcGFuPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1lbWVyYWxkLTQwMCBmb250LW1vbm9cIj5MaXZlIFdlYlNvY2tldCBQdWxzZTwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTk1MCBwLTMuNSByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHNwYWNlLXktMVwiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBibG9jayB0ZXh0LVsxMXB4XVwiPlBDIFdvcmtzdGF0aW9ucyBBY3RpdmU8L3NwYW4+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1leHRyYWJvbGQgdGV4dC1ibHVlLTQwMCBmb250LW1vbm8gZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICA8TGFwdG9wIGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPlxuICAgICAgICAgICAgICAgIDxzcGFuPntsaXZlU2Vzc2lvbnMuZmlsdGVyKHMgPT4gcy5kZXZpY2VUeXBlID09PSAncGMnICYmIHMuaXNPbmxpbmUpLmxlbmd0aH08L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTQwMFwiPkRlc2t0b3AgV29ya3N0YXRpb25zPC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTUwIHAtMy41IHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgc3BhY2UteS0xXCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIGJsb2NrIHRleHQtWzExcHhdXCI+TW9iaWxlIEhhbmRzZXRzIEFjdGl2ZTwvc3Bhbj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWV4dHJhYm9sZCB0ZXh0LXB1cnBsZS00MDAgZm9udC1tb25vIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgPFNtYXJ0cGhvbmUgY2xhc3NOYW1lPVwidy01IGgtNVwiIC8+XG4gICAgICAgICAgICAgICAgPHNwYW4+e2xpdmVTZXNzaW9ucy5maWx0ZXIocyA9PiBzLmRldmljZVR5cGUgPT09ICdtb2JpbGUnICYmIHMuaXNPbmxpbmUpLmxlbmd0aH08L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTQwMFwiPk9wZXJhdG9yIEhhbmRzZXRzPC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTUwIHAtMy41IHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgc3BhY2UteS0xXCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIGJsb2NrIHRleHQtWzExcHhdXCI+TGFzdCBQdWxzZSBVcGRhdGU8L3NwYW4+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdGV4dC13aGl0ZSBmb250LW1vbm8gbXQtMVwiPlxuICAgICAgICAgICAgICAgIHtsYXN0UmVmcmVzaGVkQXQgfHwgJ0Nvbm5lY3RpbmcuLi4nfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS01MDBcIj5BdXRvIEhlYXJ0YmVhdDwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIExpdmUgU2Vzc2lvbnMgVGFibGUgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvdmVyZmxvdy14LWF1dG9cIj5cbiAgICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJ3LWZ1bGwgdGV4dC1sZWZ0IHRleHQteHNcIj5cbiAgICAgICAgICAgICAgPHRoZWFkPlxuICAgICAgICAgICAgICAgIDx0ciBjbGFzc05hbWU9XCJib3JkZXItYiBib3JkZXItc2xhdGUtODAwIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBmb250LXNlbWlib2xkXCI+XG4gICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMyBweC0zXCI+TGl2ZSBTdGF0dXM8L3RoPlxuICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTMgcHgtM1wiPk9wZXJhdG9yIE5hbWU8L3RoPlxuICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTMgcHgtM1wiPkRldmljZSAvIE1hY2hpbmU8L3RoPlxuICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTMgcHgtM1wiPkFjdGl2ZSBTdHVkaW8gLyBUYXNrPC90aD5cbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zIHB4LTNcIj5MaWNlbnNlIFZhbGlkaXR5PC90aD5cbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zIHB4LTMgdGV4dC1yaWdodFwiPkFkbWluIENvbnRyb2w8L3RoPlxuICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgIDwvdGhlYWQ+XG4gICAgICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJkaXZpZGUteSBkaXZpZGUtc2xhdGUtODAwLzYwIGZvbnQtc2Fuc1wiPlxuICAgICAgICAgICAgICAgIHtsaXZlU2Vzc2lvbnMubWFwKChzZXNzaW9uKSA9PiB7XG4gICAgICAgICAgICAgICAgICBjb25zdCBkYXlzTGVmdCA9IGNhbGN1bGF0ZVJlbWFpbmluZ0RheXMoc2Vzc2lvbi52YWxpZGl0eUV4cGlyZXNBdCk7XG4gICAgICAgICAgICAgICAgICBjb25zdCBpc0V4cGlyaW5nID0gZGF5c0xlZnQgPCAxNTtcblxuICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgPHRyIGtleT17c2Vzc2lvbi5zZXNzaW9uSWQgfHwgYCR7c2Vzc2lvbi51c2VybmFtZX0tJHtzZXNzaW9uLmRldmljZUlkfWB9IGNsYXNzTmFtZT1cImhvdmVyOmJnLXNsYXRlLTk1MC80MCB0cmFuc2l0aW9uLWNvbG9yc1wiPlxuICAgICAgICAgICAgICAgICAgICAgIHsvKiBMaXZlIFB1bHNlIFN0YXR1cyAqL31cbiAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMyBweC0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YHctMi41IGgtMi41IHJvdW5kZWQtZnVsbCAke1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNlc3Npb24uaXNPbmxpbmUgPyAnYmctZW1lcmFsZC00MDAgYW5pbWF0ZS1wdWxzZScgOiAnYmctc2xhdGUtNjAwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICB9YH0+PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2B0ZXh0LVsxMXB4XSBmb250LWJvbGQgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXNzaW9uLmlzT25saW5lID8gJ3RleHQtZW1lcmFsZC00MDAnIDogJ3RleHQtc2xhdGUtNTAwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICB9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3Nlc3Npb24uaXNPbmxpbmUgPyAnQWN0aXZlIE5vdycgOiBgJHtzZXNzaW9uLmxhc3RBY3RpdmVTZWNvbmRzQWdvIHx8IDMwfXMgYWdvYH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPC90ZD5cblxuICAgICAgICAgICAgICAgICAgICAgIHsvKiBPcGVyYXRvciBEZXRhaWxzICovfVxuICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zIHB4LTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9udC1leHRyYWJvbGQgdGV4dC13aGl0ZSB0ZXh0LXNtXCI+e3Nlc3Npb24uZGlzcGxheU5hbWV9PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNDAwIGZvbnQtbW9ub1wiPkB7c2Vzc2lvbi51c2VybmFtZX0g4oCiIHtzZXNzaW9uLnBob25lIHx8ICc5NTYxNDYwMzEzJ308L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuXG4gICAgICAgICAgICAgICAgICAgICAgey8qIERldmljZSAmIEhhcmR3YXJlICovfVxuICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zIHB4LTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBmb250LWJvbGQgdGV4dC1zbGF0ZS0zMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAge3Nlc3Npb24uZGV2aWNlVHlwZSA9PT0gJ21vYmlsZScgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNtYXJ0cGhvbmUgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1wdXJwbGUtNDAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TGFwdG9wIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtYmx1ZS00MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1vbm8gdGV4dC1bMTFweF1cIj57c2Vzc2lvbi5kZXZpY2VJZH08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS00MDBcIj57c2Vzc2lvbi5kZXZpY2VOYW1lfTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG5cbiAgICAgICAgICAgICAgICAgICAgICB7LyogQ3VycmVudCBBY3RpdmUgU3R1ZGlvICovfVxuICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zIHB4LTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInB4LTIuNSBweS0xIHJvdW5kZWQtbGcgYmctYmx1ZS01MDAvMTAgdGV4dC1ibHVlLTMwMCBib3JkZXIgYm9yZGVyLWJsdWUtNTAwLzIwIGZvbnQtYm9sZCB0ZXh0LVsxMXB4XSBpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPEFjdGl2aXR5IGNsYXNzTmFtZT1cInctMyBoLTMgdGV4dC1ibHVlLTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPntzZXNzaW9uLmN1cnJlbnRUYWIgfHwgJ1dvcmtzdGF0aW9uIEh1Yid9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG5cbiAgICAgICAgICAgICAgICAgICAgICB7LyogTGljZW5zZSBWYWxpZGl0eSAmIFJlbmV3YWwgKi99XG4gICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMgcHgtM1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTAuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YGZvbnQtYm9sZCBmb250LW1vbm8gdGV4dC1bMTFweF0gJHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpc0V4cGlyaW5nID8gJ3RleHQtcm9zZS00MDAnIDogJ3RleHQtZW1lcmFsZC00MDAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1gfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZGF5c0xlZnQgPiAwID8gYCR7ZGF5c0xlZnR9IERheXMgTGVmdGAgOiAnRXhwaXJlZCd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNTAwXCI+RXhwOiB7c2Vzc2lvbi52YWxpZGl0eUV4cGlyZXNBdCB8fCAnMjAyNi0xMi0zMSd9PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuXG4gICAgICAgICAgICAgICAgICAgICAgey8qIEFjdGlvbiBidXR0b25zICovfVxuICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zIHB4LTMgdGV4dC1yaWdodFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWVuZCBnYXAtMS41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBSZW5ldyBCdXR0b24gKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBmb3VuZCA9IG9wZXJhdG9ycy5maW5kKG8gPT4gby51c2VybmFtZSA9PT0gc2Vzc2lvbi51c2VybmFtZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoZm91bmQpIHNldFNlbGVjdGVkT3BGb3JSZW5ldyhmb3VuZCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0yLjUgcHktMSByb3VuZGVkLWxnIGJnLWVtZXJhbGQtNTAwLzEwIHRleHQtZW1lcmFsZC0zMDAgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTUwMC8zMCBob3ZlcjpiZy1lbWVyYWxkLTUwMC8yMCBmb250LWJvbGQgdGV4dC1bMTBweF0gZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiUmVuZXcgTGljZW5zZSBBY2Nlc3NcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPENhbGVuZGFyIGNsYXNzTmFtZT1cInctMyBoLTNcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPlJlbmV3PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogU2VuZCBNZXNzYWdlICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0QnJvYWRjYXN0VGFyZ2V0VXNlcm5hbWUoc2Vzc2lvbi51c2VybmFtZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRCcm9hZGNhc3RNZXNzYWdlVGV4dCgnJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEgcm91bmRlZC1sZyBiZy1zbGF0ZS04MDAgdGV4dC1zbGF0ZS0zMDAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgaG92ZXI6dGV4dC13aGl0ZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJTZW5kIEluLUFwcCBUb2FzdCBNZXNzYWdlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxNZXNzYWdlU3F1YXJlIGNsYXNzTmFtZT1cInctMyBoLTNcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogRm9yY2UgRGlzY29ubmVjdCAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZUZvcmNlRGlzY29ubmVjdChzZXNzaW9uLnVzZXJuYW1lLCBzZXNzaW9uLmRldmljZUlkKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEgcm91bmRlZC1sZyBiZy1yb3NlLTUwMC8xMCB0ZXh0LXJvc2UtNDAwIGJvcmRlciBib3JkZXItcm9zZS01MDAvMzAgaG92ZXI6Ymctcm9zZS01MDAvMjBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiRm9yY2UgRGlzY29ubmVjdCBTZXNzaW9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxQb3dlciBjbGFzc05hbWU9XCJ3LTMgaC0zXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICAgIDwvdGFibGU+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgey8qIFRBQiAxOiBPUEVSQVRPUiBJRFMgJiBEVUFMLURFVklDRSAoUEMgKyBNT0JJTEUpIFRBQkxFICovfVxuICAgICAge2FjdGl2ZVN1YlRhYiA9PT0gJ29wZXJhdG9ycycgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTJ4bCBwLTUgc2hhZG93LXhsIHNwYWNlLXktNFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBzbTppdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zIHBiLTMgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LWV4dHJhYm9sZCB0ZXh0LXdoaXRlIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4+QXV0aG9yaXplZCBPcGVyYXRvcnMgKFBDICsgTW9iaWxlIEJpbmRpbmcpPC9zcGFuPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1lbWVyYWxkLTQwMCBiZy1lbWVyYWxkLTUwMC8xMCBweC0yIHB5LTAuNSByb3VuZGVkIGJvcmRlciBib3JkZXItZW1lcmFsZC01MDAvMjAgZm9udC1tb25vXCI+XG4gICAgICAgICAgICAgICAgICAxIFBDICsgMSBNb2JpbGUgUGVyIElEXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8L2gyPlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwIG10LTAuNVwiPlxuICAgICAgICAgICAgICAgIEVhY2ggb3BlcmF0b3IgSUQgY2FuIHdvcmsgb24gPGI+MSBhdXRob3JpemVkIFBDPC9iPiBBTkQgPGI+MSBhdXRob3JpemVkIE1vYmlsZTwvYj4gYXQgdGhlIHNhbWUgdGltZS4gVGhpcmQtcGFydHkgZGV2aWNlcyBhcmUgYmxvY2tlZCBhdXRvbWF0aWNhbGx5LlxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93QWRkTW9kYWwodHJ1ZSl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgYmctYmx1ZS02MDAgaG92ZXI6YmctYmx1ZS01MDAgdGV4dC13aGl0ZSBmb250LWJvbGQgdGV4dC14cyBweC0zLjUgcHktMiByb3VuZGVkLXhsIHNoYWRvdyB0cmFuc2l0aW9uLWFsbCBzZWxmLXN0YXJ0IHNtOnNlbGYtYXV0b1wiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxVc2VyUGx1cyBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgICAgPHNwYW4+UmVnaXN0ZXIgTmV3IE9wZXJhdG9yIElEPC9zcGFuPlxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogQ3VycmVudCBEZXZpY2UgQ2FsbG91dCAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMy41IHJvdW5kZWQteGwgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHRleHQteHMgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGZsZXgtd3JhcCBnYXAtMiB0ZXh0LXNsYXRlLTMwMFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICA8Q3B1IGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1ibHVlLTQwMFwiIC8+XG4gICAgICAgICAgICAgIDxzcGFuPllvdXIgQ3VycmVudCBNYWNoaW5lICh7Y3VycmVudElzTW9iaWxlID8gJ/Cfk7EgTW9iaWxlJyA6ICfwn5K7IFBDJ30pOjwvc3Bhbj5cbiAgICAgICAgICAgICAgPGNvZGUgY2xhc3NOYW1lPVwidGV4dC13aGl0ZSBmb250LW1vbm8gZm9udC1ib2xkIGJnLXNsYXRlLTkwMCBweC0yIHB5LTAuNSByb3VuZGVkIGJvcmRlciBib3JkZXItc2xhdGUtNzAwXCI+XG4gICAgICAgICAgICAgICAge2N1cnJlbnREZXZpY2VJZH1cbiAgICAgICAgICAgICAgPC9jb2RlPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBmb250LW1vbm8gdGV4dC1bMTFweF1cIj57Y3VycmVudERldmljZU5hbWV9PC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIE9wZXJhdG9ycyBUYWJsZSAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm92ZXJmbG93LXgtYXV0b1wiPlxuICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LWxlZnQgdGV4dC14c1wiPlxuICAgICAgICAgICAgICA8dGhlYWQ+XG4gICAgICAgICAgICAgICAgPHRyIGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDAgdGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIGZvbnQtc2VtaWJvbGRcIj5cbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zIHB4LTNcIj5PcGVyYXRvciAvIFVzZXJuYW1lPC90aD5cbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zIHB4LTNcIj5Sb2xlPC90aD5cbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zIHB4LTNcIj5BdXRob3JpemVkIFBDICgxIE1heCk8L3RoPlxuICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTMgcHgtM1wiPkF1dGhvcml6ZWQgTW9iaWxlICgxIE1heCk8L3RoPlxuICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTMgcHgtM1wiPkxpY2Vuc2UgU3RhdHVzPC90aD5cbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zIHB4LTMgdGV4dC1yaWdodFwiPkRldmljZSAmIFJlbmV3IEFjdGlvbnM8L3RoPlxuICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgIDwvdGhlYWQ+XG4gICAgICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJkaXZpZGUteSBkaXZpZGUtc2xhdGUtODAwLzYwXCI+XG4gICAgICAgICAgICAgICAge29wZXJhdG9ycy5tYXAoKG9wKSA9PiB7XG4gICAgICAgICAgICAgICAgICBjb25zdCBkYXlzTGVmdCA9IGNhbGN1bGF0ZVJlbWFpbmluZ0RheXMob3AudmFsaWRpdHlFeHBpcmVzQXQpO1xuXG4gICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICA8dHIga2V5PXtvcC5pZH0gY2xhc3NOYW1lPVwiaG92ZXI6Ymctc2xhdGUtOTUwLzQwIHRyYW5zaXRpb24tY29sb3JzXCI+XG4gICAgICAgICAgICAgICAgICAgICAgey8qIE9wZXJhdG9yIE5hbWUgKi99XG4gICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMgcHgtM1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC13aGl0ZSB0ZXh0LXNtXCI+e29wLmRpc3BsYXlOYW1lfTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBmb250LW1vbm8gdGV4dC1bMTFweF1cIj5Ae29wLnVzZXJuYW1lfSDigKIge29wLnBob25lfTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG5cbiAgICAgICAgICAgICAgICAgICAgICB7LyogUm9sZSAqL31cbiAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMyBweC0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2BweC0yIHB5LTAuNSByb3VuZGVkIHRleHQtWzEwcHhdIGZvbnQtYm9sZCB1cHBlcmNhc2UgZm9udC1tb25vICR7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9wLnJvbGUgPT09ICdhZG1pbidcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1wdXJwbGUtNTAwLzIwIHRleHQtcHVycGxlLTMwMCBib3JkZXIgYm9yZGVyLXB1cnBsZS01MDAvMzAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnYmctYmx1ZS01MDAvMjAgdGV4dC1ibHVlLTMwMCBib3JkZXIgYm9yZGVyLWJsdWUtNTAwLzMwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgfWB9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICB7b3Aucm9sZSA9PT0gJ2FkbWluJyA/ICdNYXN0ZXIgQWRtaW4nIDogJ09wZXJhdG9yJ31cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuXG4gICAgICAgICAgICAgICAgICAgICAgey8qIEF1dGhvcml6ZWQgUEMgKi99XG4gICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMgcHgtM1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAge29wLmJvdW5kUGNEZXZpY2VJZCA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTAuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBmb250LWJvbGQgdGV4dC1ibHVlLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPExhcHRvcCBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LWJsdWUtNDAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ubyB0ZXh0LVsxMXB4XVwiPntvcC5ib3VuZFBjRGV2aWNlSWR9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS00MDAgdHJ1bmNhdGUgbWF4LXctWzE2MHB4XVwiPntvcC5ib3VuZFBjRGV2aWNlTmFtZSB8fCAnUEMgV29ya3N0YXRpb24nfTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVJlc2V0UGMob3AuaWQsIG9wLnVzZXJuYW1lKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtYW1iZXItNDAwIGhvdmVyOnVuZGVybGluZSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMC41IGZvbnQtYm9sZCBwdC0wLjVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxSb3RhdGVDY3cgY2xhc3NOYW1lPVwidy0yLjUgaC0yLjVcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+UmVzZXQgUEMgQmluZGluZzwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LWFtYmVyLTQwMCBiZy1hbWJlci01MDAvMTAgcHgtMiBweS0wLjUgcm91bmRlZCBib3JkZXIgYm9yZGVyLWFtYmVyLTUwMC8yMCBmb250LW1lZGl1bVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFVuYm91bmQgUEMgKFBlbmRpbmcpXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgPC90ZD5cblxuICAgICAgICAgICAgICAgICAgICAgIHsvKiBBdXRob3JpemVkIE1vYmlsZSAqL31cbiAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMyBweC0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7b3AuYm91bmRNb2JpbGVEZXZpY2VJZCA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTAuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBmb250LWJvbGQgdGV4dC1wdXJwbGUtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U21hcnRwaG9uZSBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LXB1cnBsZS00MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vIHRleHQtWzExcHhdXCI+e29wLmJvdW5kTW9iaWxlRGV2aWNlSWR9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS00MDAgdHJ1bmNhdGUgbWF4LXctWzE2MHB4XVwiPntvcC5ib3VuZE1vYmlsZURldmljZU5hbWUgfHwgJ1NtYXJ0cGhvbmUnfTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVJlc2V0TW9iaWxlKG9wLmlkLCBvcC51c2VybmFtZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LWFtYmVyLTQwMCBob3Zlcjp1bmRlcmxpbmUgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTAuNSBmb250LWJvbGQgcHQtMC41XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Um90YXRlQ2N3IGNsYXNzTmFtZT1cInctMi41IGgtMi41XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPlJlc2V0IE1vYmlsZSBCaW5kaW5nPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtYW1iZXItNDAwIGJnLWFtYmVyLTUwMC8xMCBweC0yIHB5LTAuNSByb3VuZGVkIGJvcmRlciBib3JkZXItYW1iZXItNTAwLzIwIGZvbnQtbWVkaXVtXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgVW5ib3VuZCBNb2JpbGUgKFBlbmRpbmcpXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgPC90ZD5cblxuICAgICAgICAgICAgICAgICAgICAgIHsvKiBMaWNlbnNlIFZhbGlkaXR5ICovfVxuICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zIHB4LTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInB4LTIgcHktMC41IHJvdW5kZWQgYmctZW1lcmFsZC01MDAvMjAgdGV4dC1lbWVyYWxkLTMwMCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtNTAwLzMwIGZvbnQtYm9sZCB0ZXh0LVsxMHB4XSBmb250LW1vbm8gZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgdy1maXRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Q2FsZW5kYXIgY2xhc3NOYW1lPVwidy0zIGgtMyB0ZXh0LWVtZXJhbGQtNDAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57ZGF5c0xlZnR9IERheXMgTGVmdDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2VsZWN0ZWRPcEZvclJlbmV3KG9wKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNreS00MDAgaG92ZXI6dW5kZXJsaW5lIGZvbnQtYm9sZCBibG9ja1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICArIFJlbmV3IEFjY2Vzc1xuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG5cbiAgICAgICAgICAgICAgICAgICAgICB7LyogQWN0aW9uIGJ1dHRvbnMgKi99XG4gICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMgcHgtMyB0ZXh0LXJpZ2h0XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktZW5kIGdhcC0xLjUgZmxleC13cmFwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBSZXNldCBBbGwgRGV2aWNlcyBCdXR0b24gKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHsob3AuYm91bmRQY0RldmljZUlkIHx8IG9wLmJvdW5kTW9iaWxlRGV2aWNlSWQpICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVSZXNldEFsbERldmljZXMob3AuaWQsIG9wLnVzZXJuYW1lKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTIgcHktMSByb3VuZGVkLWxnIGJnLWFtYmVyLTUwMC8xMCB0ZXh0LWFtYmVyLTMwMCBib3JkZXIgYm9yZGVyLWFtYmVyLTUwMC8zMCBob3ZlcjpiZy1hbWJlci01MDAvMjAgZm9udC1ib2xkIHRleHQtWzEwcHhdIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiUmVzZXQgYm90aCBQQyBhbmQgTW9iaWxlIGJpbmRpbmdzXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBSZXNldCBBbGxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogTG9jayAvIFVubG9jayAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAge29wLnJvbGUgIT09ICdhZG1pbicgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVRvZ2dsZUxvY2sob3AuaWQsIG9wLnVzZXJuYW1lKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHAtMS41IHJvdW5kZWQtbGcgYm9yZGVyIHRleHQteHMgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb3AuaXNMb2NrZWRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1lbWVyYWxkLTUwMC8xMCB0ZXh0LWVtZXJhbGQtMzAwIGJvcmRlci1lbWVyYWxkLTUwMC8zMCBob3ZlcjpiZy1lbWVyYWxkLTUwMC8yMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6ICdiZy1zbGF0ZS04MDAgdGV4dC1zbGF0ZS00MDAgYm9yZGVyLXNsYXRlLTcwMCBob3Zlcjp0ZXh0LXdoaXRlJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT17b3AuaXNMb2NrZWQgPyAnVW5sb2NrIE9wZXJhdG9yJyA6ICdTdXNwZW5kIE9wZXJhdG9yJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7b3AuaXNMb2NrZWQgPyA8VW5sb2NrIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz4gOiA8TG9jayBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBEZWxldGUgT3BlcmF0b3IgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtvcC5yb2xlICE9PSAnYWRtaW4nICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVEZWxldGVPcGVyYXRvcihvcC5pZCwgb3AudXNlcm5hbWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xLjUgcm91bmRlZC1sZyBiZy1yb3NlLTUwMC8xMCB0ZXh0LXJvc2UtNDAwIGJvcmRlciBib3JkZXItcm9zZS01MDAvMjAgaG92ZXI6Ymctcm9zZS01MDAvMjAgdGV4dC14c1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIkRlbGV0ZSBPcGVyYXRvclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFRyYXNoMiBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICAgIDwvdGFibGU+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgey8qIFRBQiAyOiBDWUJFUiBDQUZFIFdPUktGTE9XICYgU09QICovfVxuICAgICAge2FjdGl2ZVN1YlRhYiA9PT0gJ3dvcmtmbG93JyAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtMnhsIHAtNSBzaGFkb3cteGwgc3BhY2UteS00XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IHNtOml0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTMgcGItMyBib3JkZXItYiBib3JkZXItc2xhdGUtODAwXCI+XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtZXh0cmFib2xkIHRleHQtd2hpdGUgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICA8Q2xpcGJvYXJkTGlzdCBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtYW1iZXItNDAwXCIgLz5cbiAgICAgICAgICAgICAgICA8c3Bhbj5DeWJlciBDYWZlIFN0YW5kYXJkIE9wZXJhdGluZyBQcm9jZWR1cmUgKFNPUCk8L3NwYW4+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWFtYmVyLTQwMCBiZy1hbWJlci01MDAvMTAgcHgtMiBweS0wLjUgcm91bmRlZCBib3JkZXIgYm9yZGVyLWFtYmVyLTUwMC8yMCBmb250LW1vbm9cIj5cbiAgICAgICAgICAgICAgICAgIE1hc3RlciBXb3JrZmxvd1xuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9oMj5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMCBtdC0wLjVcIj5cbiAgICAgICAgICAgICAgICBTdGFuZGFyZGl6ZWQgNi1zdGFnZSBvcGVyYXRpb25hbCBwcm90b2NvbCBmb3IgYWxsIENTQyAmIEN5YmVyIENhZmUgc2VydmljZXNcbiAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTUwIHB4LTMgcHktMS41IHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgdGV4dC14cyBmb250LW1vbm8gdGV4dC1zbGF0ZS0zMDBcIj5cbiAgICAgICAgICAgICAgQ2hlY2tsaXN0OiA8c3Ryb25nIGNsYXNzTmFtZT1cInRleHQtZW1lcmFsZC00MDBcIj57Y29tcGxldGVkV29ya2Zsb3dDb3VudH0gLyB7TUFTVEVSX1dPUktGTE9XX1NURVBTLmxlbmd0aH0gQ29tcGxldGVkPC9zdHJvbmc+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBXb3JrZmxvdyBTdGVwcyBHcmlkICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtNFwiPlxuICAgICAgICAgICAge01BU1RFUl9XT1JLRkxPV19TVEVQUy5tYXAoKHN0ZXApID0+IHtcbiAgICAgICAgICAgICAgY29uc3QgaXNEb25lID0gISFjb21wbGV0ZWRTdGVwc1tzdGVwLnN0ZXBOdW1iZXJdO1xuICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICAgIGtleT17c3RlcC5zdGVwTnVtYmVyfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcC00IHJvdW5kZWQteGwgYm9yZGVyIHRyYW5zaXRpb24tYWxsIHNwYWNlLXktMyAke1xuICAgICAgICAgICAgICAgICAgICBpc0RvbmUgXG4gICAgICAgICAgICAgICAgICAgICAgPyAnYmctc2xhdGUtOTUwLzYwIGJvcmRlci1lbWVyYWxkLTUwMC80MCcgXG4gICAgICAgICAgICAgICAgICAgICAgOiAnYmctc2xhdGUtOTUwIGJvcmRlci1zbGF0ZS04MDAgaG92ZXI6Ym9yZGVyLXNsYXRlLTcwMCdcbiAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2B3LTYgaC02IHJvdW5kZWQtbGcgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZm9udC1ib2xkIHRleHQteHMgZm9udC1tb25vICR7XG4gICAgICAgICAgICAgICAgICAgICAgICBpc0RvbmUgPyAnYmctZW1lcmFsZC01MDAgdGV4dC1zbGF0ZS05NTAnIDogJ2JnLWJsdWUtNjAwIHRleHQtd2hpdGUnXG4gICAgICAgICAgICAgICAgICAgICAgfWB9PlxuICAgICAgICAgICAgICAgICAgICAgICAge3N0ZXAuc3RlcE51bWJlcn1cbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtZXh0cmFib2xkIHRleHQtd2hpdGUgdGV4dC14c1wiPntzdGVwLnRpdGxlfTwvaDM+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRDb21wbGV0ZWRTdGVwcyhwcmV2ID0+ICh7IC4uLnByZXYsIFtzdGVwLnN0ZXBOdW1iZXJdOiAhcHJldltzdGVwLnN0ZXBOdW1iZXJdIH0pKX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSB0ZXh0LVsxMXB4XSBmb250LWJvbGQgcHgtMiBweS0wLjUgcm91bmRlZC1tZCBib3JkZXIgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlzRG9uZSBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctZW1lcmFsZC01MDAvMjAgdGV4dC1lbWVyYWxkLTMwMCBib3JkZXItZW1lcmFsZC01MDAvMzAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDogJ2JnLXNsYXRlLTkwMCB0ZXh0LXNsYXRlLTQwMCBib3JkZXItc2xhdGUtNzAwJ1xuICAgICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAge2lzRG9uZSA/IDxDaGVja0NpcmNsZTIgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1lbWVyYWxkLTQwMFwiIC8+IDogPENpcmNsZSBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+fVxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPntpc0RvbmUgPyAnRG9uZScgOiAnTWFyayd9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTMwMCBsZWFkaW5nLXNudWdcIj57c3RlcC5kZXNjcmlwdGlvbn08L3A+XG5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xIHB0LTEgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTgwMC84MFwiPlxuICAgICAgICAgICAgICAgICAgICB7c3RlcC5jaGVja2xpc3QubWFwKChpdGVtLCBpZHgpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17aWR4fSBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0xLjUgdGV4dC1bMTFweF0gdGV4dC1zbGF0ZS00MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtYmx1ZS01MDBcIj7igKI8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57aXRlbX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0yIHJvdW5kZWQtbGcgYmctc2xhdGUtOTAwIHRleHQtWzEwcHhdIHRleHQtYW1iZXItMzAwLzkwIGZsZXggaXRlbXMtc3RhcnQgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgICAgICA8U3BhcmtsZXMgY2xhc3NOYW1lPVwidy0zIGgtMyB0ZXh0LWFtYmVyLTQwMCBmbGV4LXNocmluay0wIG10LTAuNVwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPjxiPk9wZXJhdG9yIE5vdGU6PC9iPiB7c3RlcC50aXBzfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgfSl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgey8qIFRBQiAzOiBQUk9KRUNUICguWklQKSBET1dOTE9BRCBDQVJEICovfVxuICAgICAge2FjdGl2ZVN1YlRhYiA9PT0gJ3ppcF9kb3dubG9hZCcgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTJ4bCBwLTYgc2hhZG93LXhsIHNwYWNlLXktNlwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBnYXAtNFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTE0IGgtMTQgcm91bmRlZC0yeGwgYmctZ3JhZGllbnQtdG8tdHIgZnJvbS1lbWVyYWxkLTYwMC8yMCB0by10ZWFsLTUwMC8yMCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtNTAwLzMwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtZW1lcmFsZC00MDAgZmxleC1zaHJpbmstMCBzaGFkb3ctaW5uZXJcIj5cbiAgICAgICAgICAgICAgPEFyY2hpdmUgY2xhc3NOYW1lPVwidy03IGgtN1wiIC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xXCI+XG4gICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtZXh0cmFib2xkIHRleHQtd2hpdGVcIj5Eb3dubG9hZCBDb21wbGV0ZSBPcmlnaW5hbCBQcm9qZWN0IFNvdXJjZSAoLlpJUCk8L2gyPlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtMzAwIGxlYWRpbmctcmVsYXhlZFwiPlxuICAgICAgICAgICAgICAgIERvd25sb2FkIHRoZSBjb21wbGV0ZSwgc3RhbmRhbG9uZSBvZmZsaW5lIGNvZGViYXNlIG9mIE11emFtbWlsIE9ubGluZSBTZXJ2aWNlIHN1aXRlIGNvbnRhaW5pbmcgYWxsIGNvbXBvbmVudHMsIHNlcnZlciwgc3R5bGVzLCBwYWNrYWdlIGNvbmZpZ3VyYXRpb24sIGFuZCBhc3NldHMuXG4gICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgcm91bmRlZC14bCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgc3BhY2UteS0zXCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXdoaXRlIGJsb2NrXCI+QXJjaGl2ZSBQYWNrYWdlIENvbnRlbnRzOjwvc3Bhbj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMiBtZDpncmlkLWNvbHMtMyBnYXAtMiB0ZXh0LXhzIHRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICAgIDxkaXY+4oCiIFBWQyBTbWFydCBDYXJkIFN0dWRpbyAoQ1ItODApPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXY+4oCiIFBhc3Nwb3J0IFBob3RvIFN0dWRpbyBQcm88L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdj7igKIgRmFzdCBQT1MgQmlsbGluZyBEZXNrICYgUmVjZWlwdHM8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdj7igKIgQ3VzdG9tZXIgQ1JNICYgTGVkZ2VyPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXY+4oCiIEJpb0RhdGEgJiBDViBNYWtlciBFbmdpbmU8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdj7igKIgNTArIEdvdnQgQ2l0aXplbiBQb3J0YWxzIEh1YjwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2PuKAoiBEdWFsIERldmljZSBMb2NraW5nIChQQyArIE1vYmlsZSk8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdj7igKIgTGl2ZSBNb25pdG9yaW5nICYgTGljZW5zZSBSZW5ld2FsPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXY+4oCiIEluLUFwcCBQb3J0YWwgQnJvd3NlciAmIERvd25sb2FkZXI8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdj7igKIgU2VydmVyLnRzIEV4cHJlc3MgJiBHZW1pbmkgUHJveHk8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIERvd25sb2FkIFByb2dyZXNzIEJhciAqL31cbiAgICAgICAgICB7aXNFeHBvcnRpbmdaaXAgJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTIgcC00IHJvdW5kZWQteGwgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItZW1lcmFsZC01MDAvMzAgYW5pbWF0ZS1wdWxzZVwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIHRleHQteHMgdGV4dC1lbWVyYWxkLTQwMCBmb250LWJvbGRcIj5cbiAgICAgICAgICAgICAgICA8c3Bhbj5QYWNraW5nIFpJUCBBcmNoaXZlOiB7emlwUHJvZ3Jlc3MuZmlsZX08L3NwYW4+XG4gICAgICAgICAgICAgICAgPHNwYW4+e3ppcFByb2dyZXNzLnBlcmNlbnR9JTwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTgwMCBoLTIgcm91bmRlZC1mdWxsIG92ZXJmbG93LWhpZGRlblwiPlxuICAgICAgICAgICAgICAgIDxkaXYgXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1lbWVyYWxkLTUwMCBoLWZ1bGwgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMjAwXCIgXG4gICAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogYCR7emlwUHJvZ3Jlc3MucGVyY2VudH0lYCB9fVxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgZmxleC13cmFwXCI+XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZURvd25sb2FkWmlwfVxuICAgICAgICAgICAgICBkaXNhYmxlZD17aXNFeHBvcnRpbmdaaXB9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGJnLWdyYWRpZW50LXRvLXIgZnJvbS1lbWVyYWxkLTYwMCB0by10ZWFsLTYwMCBob3Zlcjpmcm9tLWVtZXJhbGQtNTAwIGhvdmVyOnRvLXRlYWwtNTAwIHRleHQtd2hpdGUgZm9udC1leHRyYWJvbGQgdGV4dC1zbSBweC02IHB5LTMgcm91bmRlZC14bCBzaGFkb3ctbGcgc2hhZG93LWVtZXJhbGQtNjAwLzMwIHRyYW5zaXRpb24tYWxsIGhvdmVyOnNjYWxlLTEwNSBkaXNhYmxlZDpvcGFjaXR5LTUwXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPERvd25sb2FkIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICAgICAgICA8c3Bhbj57aXNFeHBvcnRpbmdaaXAgPyAnQ29tcHJlc3NpbmcgUHJvamVjdC4uLicgOiAnRG93bmxvYWQgUHJvamVjdCAuWklQIEFyY2hpdmUnfTwvc3Bhbj5cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgICA8YVxuICAgICAgICAgICAgICBocmVmPVwiL2FwaS9kb3dubG9hZC16aXBcIlxuICAgICAgICAgICAgICBkb3dubG9hZD1cIk11emFtbWlsLU9ubGluZS1zZXJ2aWNlLXBjLnppcFwiXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ibHVlLTQwMCBob3Zlcjp1bmRlcmxpbmUgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgZm9udC1zZW1pYm9sZFwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxzcGFuPkRpcmVjdCBTZXJ2ZXIgRG93bmxvYWQgTGluazwvc3Bhbj5cbiAgICAgICAgICAgIDwvYT5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuXG4gICAgICB7LyogVEFCIDQ6IFNFQ1VSSVRZIEFVRElUICYgQUNDRVNTIExPR1MgKi99XG4gICAgICB7YWN0aXZlU3ViVGFiID09PSAnbG9ncycgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTJ4bCBwLTUgc2hhZG93LXhsIHNwYWNlLXktNFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHBiLTMgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LWV4dHJhYm9sZCB0ZXh0LXdoaXRlXCI+UmVhbC1UaW1lIFNlY3VyaXR5ICYgRGV2aWNlIEF1ZGl0IExvZzwvaDI+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS00MDBcIj5SZWNvcmQgb2YgYWxsIGF1dGhvcml6ZWQgUEMgJiBNb2JpbGUgbG9naW5zLCBkZXZpY2UgbG9ja3MsIGFuZCBibG9ja2VkIGFjY2VzcyBhdHRlbXB0czwvcD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICBvbkNsaWNrPXtsb2FkRGF0YX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgcHgtMyBweS0xLjUgcm91bmRlZC1sZyBiZy1zbGF0ZS04MDAgdGV4dC1zbGF0ZS0zMDAgaG92ZXI6dGV4dC13aGl0ZSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGRcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8UmVmcmVzaEN3IGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cbiAgICAgICAgICAgICAgPHNwYW4+UmVmcmVzaCBMb2dzPC9zcGFuPlxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm92ZXJmbG93LXgtYXV0byBtYXgtaC05NlwiPlxuICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LWxlZnQgdGV4dC14c1wiPlxuICAgICAgICAgICAgICA8dGhlYWQgY2xhc3NOYW1lPVwic3RpY2t5IHRvcC0wIGJnLXNsYXRlLTkwMCBib3JkZXItYiBib3JkZXItc2xhdGUtODAwIHRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTIuNSBweC0zXCI+VGltZXN0YW1wPC90aD5cbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0yLjUgcHgtM1wiPkFjdGlvbjwvdGg+XG4gICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMi41IHB4LTNcIj5PcGVyYXRvcjwvdGg+XG4gICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMi41IHB4LTNcIj5UeXBlPC90aD5cbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0yLjUgcHgtM1wiPkRldmljZSBJRDwvdGg+XG4gICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMi41IHB4LTNcIj5EZXRhaWxzPC90aD5cbiAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICA8L3RoZWFkPlxuICAgICAgICAgICAgICA8dGJvZHkgY2xhc3NOYW1lPVwiZGl2aWRlLXkgZGl2aWRlLXNsYXRlLTgwMC82MCBmb250LW1vbm8gdGV4dC1bMTFweF1cIj5cbiAgICAgICAgICAgICAgICB7YXVkaXRMb2dzLmxlbmd0aCA+IDAgPyAoXG4gICAgICAgICAgICAgICAgICBhdWRpdExvZ3MubWFwKChsb2cpID0+IChcbiAgICAgICAgICAgICAgICAgICAgPHRyIGtleT17bG9nLmlkfSBjbGFzc05hbWU9XCJob3ZlcjpiZy1zbGF0ZS05NTAvNDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMi41IHB4LTMgdGV4dC1zbGF0ZS00MDBcIj57bG9nLnRpbWVzdGFtcH08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0yLjUgcHgtM1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgcHgtMiBweS0wLjUgcm91bmRlZCB0ZXh0LVsxMHB4XSBmb250LWJvbGQgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbG9nLmFjdGlvbiA9PT0gJ0xPR0lOX1NVQ0NFU1MnIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLWVtZXJhbGQtNTAwLzIwIHRleHQtZW1lcmFsZC00MDAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBsb2cuYWN0aW9uID09PSAnREVWSUNFX0JMT0NLRUQnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctcm9zZS01MDAvMjAgdGV4dC1yb3NlLTQwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IGxvZy5hY3Rpb24gPT09ICdERVZJQ0VfQk9VTkQnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctYmx1ZS01MDAvMjAgdGV4dC1ibHVlLTQwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA6ICdiZy1hbWJlci01MDAvMjAgdGV4dC1hbWJlci00MDAnXG4gICAgICAgICAgICAgICAgICAgICAgICB9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtsb2cuYWN0aW9ufVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTIuNSBweC0zIHRleHQtd2hpdGUgZm9udC1ib2xkXCI+QHtsb2cudXNlcm5hbWV9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMi41IHB4LTMgdGV4dC1zbGF0ZS00MDBcIj57bG9nLmRldmljZVR5cGUgPT09ICdtb2JpbGUnID8gJ/Cfk7EgTW9iaWxlJyA6ICfwn5K7IFBDJ308L3RkPlxuICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0yLjUgcHgtMyB0ZXh0LXNsYXRlLTMwMFwiPntsb2cuZGV2aWNlSWR9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMi41IHB4LTMgdGV4dC1zbGF0ZS00MDAgbWF4LXcteHMgdHJ1bmNhdGUgZm9udC1zYW5zXCI+e2xvZy5kZXRhaWxzfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICApKVxuICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgICAgICAgIDx0ZCBjb2xTcGFuPXs2fSBjbGFzc05hbWU9XCJweS02IHRleHQtY2VudGVyIHRleHQtc2xhdGUtNTAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgTm8gc2VjdXJpdHkgYXVkaXQgbG9ncyByZWNvcmRlZCB5ZXQuXG4gICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDwvdGJvZHk+XG4gICAgICAgICAgICA8L3RhYmxlPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIHsvKiBUQUIgNTogTUFTVEVSIFNFVFVQICYgQ09OVFJPTCBDRU5URVIgKi99XG4gICAgICB7YWN0aXZlU3ViVGFiID09PSAnc2V0dGluZ3MnICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0yeGwgcC02IHNoYWRvdy14bCBzcGFjZS15LTZcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgc206ZmxleC1yb3cgc206aXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMyBwYi0zIGJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDBcIj5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1leHRyYWJvbGQgdGV4dC13aGl0ZSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgIDxLZXkgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LWJsdWUtNDAwXCIgLz5cbiAgICAgICAgICAgICAgICA8c3Bhbj5NYXN0ZXIgQWRtaW4gV29ya3N0YXRpb24gU2V0dXAgJiBDb250cm9sIENlbnRlcjwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9oMj5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMCBtdC0wLjVcIj5cbiAgICAgICAgICAgICAgICBDZW50cmFsaXplZCBtYW5hZ2VtZW50IGZvciBTaG9wIERldGFpbHMsIFBPUyBSYXRlcywgSGFyZHdhcmUgU2V0dGluZ3MsIGFuZCBTdGFmZiBTZWN1cml0eVxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYmctcm9zZS01MDAvMTAgdGV4dC1yb3NlLTMwMCBib3JkZXIgYm9yZGVyLXJvc2UtNTAwLzMwIHRleHQteHMgcHgtMyBweS0xIHJvdW5kZWQtZnVsbCBmb250LWJvbGQgdy1maXRcIj5cbiAgICAgICAgICAgICAgU3RhZmYgJiBPcGVyYXRvciBBY2Nlc3MgT25seVxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIFNUUklDVCBDVVNUT01FUiBBQ0NFU1MgUE9MSUNZIEJBTk5FUiAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCByb3VuZGVkLXhsIGJnLWdyYWRpZW50LXRvLXIgZnJvbS1yb3NlLTk1MC80MCB0by1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1yb3NlLTUwMC8zMCBzcGFjZS15LTJcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC1yb3NlLTQwMCBmb250LWV4dHJhYm9sZCB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgIDxBbGVydENpcmNsZSBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgICAgPHNwYW4+WkVSTyBDVVNUT01FUiBMT0dJTiBFTkZPUkNFRCAoTk8gUFVCTElDIEFDQ0VTUyk8L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS0zMDAgbGVhZGluZy1yZWxheGVkXCI+XG4gICAgICAgICAgICAgIElzIHN5c3RlbSBtZWluIDxiPmtpc2kgYmhpIGFuamFuIGN1c3RvbWVyIHlhIHB1YmxpYyB1c2VyIGthIGxvZ2luIHlhIHJlZ2lzdHJhdGlvbiBwb29yaSB0YXJhaCBiYW5kIGhhaTwvYj4uIFxuICAgICAgICAgICAgICBTaXJmIE1hc3RlciBBZG1pbiBrZSBkd2FyYSBiYW5heWUgZ2F5ZSB2ZXJpZmllZCBTdGFmZiBPcGVyYXRvciBJRHMgaGkgbG9naW4ga2FyIHNha3RlIGhhaW4uIFxuICAgICAgICAgICAgICBTYWJoaSBjaXRpemVuL2N1c3RvbWVyIGRldGFpbHMgc2lyZiBzaG9wIGtlIGludGVybmFsIDxiPkN1c3RvbWVyIENSTTwvYj4gbWVpbiBzYWZlIHJlY29yZCBrZSB0YXVyIHBhciBzdG9yZSBob3RpIGhhaW4uXG4gICAgICAgICAgICA8L3A+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlU2F2ZVNldHRpbmdzfSBjbGFzc05hbWU9XCJzcGFjZS15LTYgdGV4dC14c1wiPlxuICAgICAgICAgICAgey8qIFNlY3Rpb24gMTogU2hvcCAmIEJ1c2luZXNzIElkZW50aXR5ICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtZXh0cmFib2xkIHRleHQtd2hpdGUgdGV4dC14cyB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC1ibHVlLTQwMFwiPlxuICAgICAgICAgICAgICAgIDxzcGFuPjEuIFNob3AgSWRlbnRpdHkgJiBPZmZpY2lhbCBEZXRhaWxzPC9zcGFuPlxuICAgICAgICAgICAgICA8L2gzPlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtMyBnYXAtM1wiPlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgYmxvY2sgbWItMVwiPlNob3AgLyBDZW50ZXIgTmFtZTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2hvcEZvcm0uc2hvcE5hbWV9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2hvcEZvcm0oeyAuLi5zaG9wRm9ybSwgc2hvcE5hbWU6IGUudGFyZ2V0LnZhbHVlIH0pfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQteGwgcC0yLjUgdGV4dC13aGl0ZSBmb250LWJvbGRcIlxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgYmxvY2sgbWItMVwiPk93bmVyIE5hbWU8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3Nob3BGb3JtLm93bmVyTmFtZX1cbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTaG9wRm9ybSh7IC4uLnNob3BGb3JtLCBvd25lck5hbWU6IGUudGFyZ2V0LnZhbHVlIH0pfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQteGwgcC0yLjUgdGV4dC13aGl0ZSBmb250LWJvbGRcIlxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgYmxvY2sgbWItMVwiPldoYXRzQXBwIC8gQ29udGFjdCBQaG9uZTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2hvcEZvcm0ucGhvbmV9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2hvcEZvcm0oeyAuLi5zaG9wRm9ybSwgcGhvbmU6IGUudGFyZ2V0LnZhbHVlIH0pfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQteGwgcC0yLjUgdGV4dC13aGl0ZSBmb250LWJvbGRcIlxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgYmxvY2sgbWItMVwiPlVQSSBJRCBmb3IgRHluYW1pYyBQT1MgUVI8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3Nob3BGb3JtLnVwaUlkfVxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNob3BGb3JtKHsgLi4uc2hvcEZvcm0sIHVwaUlkOiBlLnRhcmdldC52YWx1ZSB9KX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLXhsIHAtMi41IHRleHQtd2hpdGUgZm9udC1ib2xkIGZvbnQtbW9ub1wiXG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbTpjb2wtc3Bhbi0yXCI+XG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgYmxvY2sgbWItMVwiPkFkZHJlc3MgKFByaW50ZWQgb24gVGF4IEludm9pY2VzICYgVGhlcm1hbCBTbGlwcyk8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3Nob3BGb3JtLmFkZHJlc3N9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2hvcEZvcm0oeyAuLi5zaG9wRm9ybSwgYWRkcmVzczogZS50YXJnZXQudmFsdWUgfSl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCBwLTIuNSB0ZXh0LXdoaXRlXCJcbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBTZWN0aW9uIDI6IERlZmF1bHQgUE9TIFJhdGVzIFNldHVwICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTMgcHQtMyBib3JkZXItdCBib3JkZXItc2xhdGUtODAwXCI+XG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LWV4dHJhYm9sZCB0ZXh0LXdoaXRlIHRleHQteHMgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtZW1lcmFsZC00MDBcIj5cbiAgICAgICAgICAgICAgICA8c3Bhbj4yLiBEZWZhdWx0IFBPUyBTZXJ2aWNlIFJhdGVzICYgUHJpY2luZyAo4oK5KTwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9oMz5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgc206Z3JpZC1jb2xzLTMgbGc6Z3JpZC1jb2xzLTYgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTk1MCBwLTIuNSByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtODAwXCI+XG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgYmxvY2sgdGV4dC1bMTFweF0gbWItMVwiPlBWQyBTbWFydCBDYXJkPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgZm9udC1ib2xkIHRleHQtZW1lcmFsZC00MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+4oK5PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcbiAgICAgICAgICAgICAgICAgICAgICBkZWZhdWx0VmFsdWU9ezB9XG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCIwXCJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQgcC0xIHRleHQtd2hpdGUgZm9udC1tb25vIHRleHQteHNcIlxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTk1MCBwLTIuNSByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtODAwXCI+XG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgYmxvY2sgdGV4dC1bMTFweF0gbWItMVwiPlBhc3Nwb3J0IFBob3RvICg4eCk8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSBmb250LWJvbGQgdGV4dC1lbWVyYWxkLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj7igrk8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxuICAgICAgICAgICAgICAgICAgICAgIGRlZmF1bHRWYWx1ZT17MH1cbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIjBcIlxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZCBwLTEgdGV4dC13aGl0ZSBmb250LW1vbm8gdGV4dC14c1wiXG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTUwIHAtMi41IHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDBcIj5cbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBibG9jayB0ZXh0LVsxMXB4XSBtYi0xXCI+T25saW5lIFNjaGVtZSBGb3JtPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgZm9udC1ib2xkIHRleHQtZW1lcmFsZC00MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+4oK5PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcbiAgICAgICAgICAgICAgICAgICAgICBkZWZhdWx0VmFsdWU9ezB9XG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCIwXCJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQgcC0xIHRleHQtd2hpdGUgZm9udC1tb25vIHRleHQteHNcIlxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTk1MCBwLTIuNSByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtODAwXCI+XG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgYmxvY2sgdGV4dC1bMTFweF0gbWItMVwiPkV4YW0gRm9ybSAoUG9saWNlKTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xIGZvbnQtYm9sZCB0ZXh0LWVtZXJhbGQtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPuKCuTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXG4gICAgICAgICAgICAgICAgICAgICAgZGVmYXVsdFZhbHVlPXswfVxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiMFwiXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkIHAtMSB0ZXh0LXdoaXRlIGZvbnQtbW9ubyB0ZXh0LXhzXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05NTAgcC0yLjUgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIGJsb2NrIHRleHQtWzExcHhdIG1iLTFcIj5CaW9EYXRhIC8gQ1Y8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSBmb250LWJvbGQgdGV4dC1lbWVyYWxkLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj7igrk8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxuICAgICAgICAgICAgICAgICAgICAgIGRlZmF1bHRWYWx1ZT17MH1cbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIjBcIlxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZCBwLTEgdGV4dC13aGl0ZSBmb250LW1vbm8gdGV4dC14c1wiXG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTUwIHAtMi41IHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDBcIj5cbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBibG9jayB0ZXh0LVsxMXB4XSBtYi0xXCI+VGhlcm1hbCBMYW1pbmF0aW9uPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgZm9udC1ib2xkIHRleHQtZW1lcmFsZC00MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+4oK5PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcbiAgICAgICAgICAgICAgICAgICAgICBkZWZhdWx0VmFsdWU9ezB9XG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCIwXCJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQgcC0xIHRleHQtd2hpdGUgZm9udC1tb25vIHRleHQteHNcIlxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBTZWN0aW9uIDM6IEhhcmR3YXJlICYgUHJpbnRlciBTdGFuZGFyZHMgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMyBwdC0zIGJvcmRlci10IGJvcmRlci1zbGF0ZS04MDBcIj5cbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtZXh0cmFib2xkIHRleHQtd2hpdGUgdGV4dC14cyB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC1wdXJwbGUtNDAwXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4+My4gSGFyZHdhcmUgJiBQcmludGluZyBTdGFuZGFyZHM8L3NwYW4+XG4gICAgICAgICAgICAgIDwvaDM+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0zIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05NTAgcC0zIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgc3BhY2UteS0xXCI+XG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgYmxvY2sgZm9udC1ib2xkXCI+UFZDIENhcmQgUmVzb2x1dGlvbjwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtd2hpdGUgZm9udC1tb25vIGZvbnQtZXh0cmFib2xkIHRleHQteHMgdGV4dC1ibHVlLTQwMFwiPjMwMCBEUEkgVWx0cmEgSEQ8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNTAwXCI+T3B0aW1pemVkIGZvciBFcHNvbiBMODA1LCBMODUwICYgQ2Fub24gRy1TZXJpZXM8L3A+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTk1MCBwLTMgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBzcGFjZS15LTFcIj5cbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBibG9jayBmb250LWJvbGRcIj5QaG90byBTdHVkaW8gTGF5b3V0PC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC13aGl0ZSBmb250LW1vbm8gZm9udC1leHRyYWJvbGQgdGV4dC14cyB0ZXh0LXB1cnBsZS00MDBcIj40w5c2IEluY2ggKDEww5cxNSBjbSkgR2xvc3N5PC9kaXY+XG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTUwMFwiPjggcHJlLWFsaWduZWQgcGFzc3BvcnQgcGhvdG9zIHdpdGggYm9yZGVyIGd1aWRlIGxpbmVzPC9wPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05NTAgcC0zIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgc3BhY2UteS0xXCI+XG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgYmxvY2sgZm9udC1ib2xkXCI+UE9TIFJlY2VpcHQgUHJpbnRlcjwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtd2hpdGUgZm9udC1tb25vIGZvbnQtZXh0cmFib2xkIHRleHQteHMgdGV4dC1lbWVyYWxkLTQwMFwiPjU4bW0gLyA4MG1tIFRoZXJtYWwgRVNDL1BPUzwvZGl2PlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS01MDBcIj5aZXJvLWluayB0aGVybWFsIHBhcGVyIHdpdGggZHluYW1pYyBVUEkgUVIgY29kZTwvcD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIFNhdmUgQnV0dG9uICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwdC0yIGZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC02IHB5LTMgYmctYmx1ZS02MDAgaG92ZXI6YmctYmx1ZS01MDAgdGV4dC13aGl0ZSBmb250LWV4dHJhYm9sZCByb3VuZGVkLXhsIHNoYWRvdy1sZyBzaGFkb3ctYmx1ZS02MDAvMzAgdHJhbnNpdGlvbi1hbGwgaG92ZXI6c2NhbGUtMTA1XCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIFNhdmUgTWFzdGVyIFNldHVwIENvbmZpZ3VyYXRpb25cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Zvcm0+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgey8qIFJFTkVXIEFDQ0VTUyBNT0RBTCAqL31cbiAgICAgIHtzZWxlY3RlZE9wRm9yUmVuZXcgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgYmctYmxhY2svODUgYmFja2Ryb3AtYmx1ci1zbSB6LTUwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtNFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtM3hsIG1heC13LW1kIHctZnVsbCBwLTYgc2hhZG93LTJ4bCBzcGFjZS15LTQgYW5pbWF0ZS1pbiBmYWRlLWluIHpvb20taW4tOTVcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHBiLTIgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZm9udC1leHRyYWJvbGQgdGV4dC13aGl0ZSB0ZXh0LWJhc2UgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICA8Q2FsZW5kYXIgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LWVtZXJhbGQtNDAwXCIgLz5cbiAgICAgICAgICAgICAgICA8c3Bhbj5SZW5ldyBMaWNlbnNlICYgQWNjZXNzIFZhbGlkaXR5PC9zcGFuPlxuICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IHNldFNlbGVjdGVkT3BGb3JSZW5ldyhudWxsKX0gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC13aGl0ZVwiPuKclTwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zIGJnLXNsYXRlLTk1MCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHRleHQteHMgc3BhY2UteS0xXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC13aGl0ZSBmb250LWJvbGRcIj57c2VsZWN0ZWRPcEZvclJlbmV3LmRpc3BsYXlOYW1lfTwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIGZvbnQtbW9ub1wiPkB7c2VsZWN0ZWRPcEZvclJlbmV3LnVzZXJuYW1lfSDigKIge3NlbGVjdGVkT3BGb3JSZW5ldy5waG9uZX08L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWVtZXJhbGQtNDAwIGZvbnQtYm9sZCBwdC0xXCI+XG4gICAgICAgICAgICAgICAgQ3VycmVudCBSZW1haW5pbmc6IHtjYWxjdWxhdGVSZW1haW5pbmdEYXlzKHNlbGVjdGVkT3BGb3JSZW5ldy52YWxpZGl0eUV4cGlyZXNBdCl9IERheXNcbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTIgdGV4dC14c1wiPlxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS0zMDAgZm9udC1ib2xkIGJsb2NrXCI+U2VsZWN0IEV4dGVuc2lvbiBEdXJhdGlvbjo8L2xhYmVsPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFJlbmV3RGF5c0NvdW50KDMwKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHAtMyByb3VuZGVkLXhsIGJvcmRlciBmb250LWJvbGQgdGV4dC1jZW50ZXIgdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgICAgICAgICAgICAgcmVuZXdEYXlzQ291bnQgPT09IDMwXG4gICAgICAgICAgICAgICAgICAgICAgPyAnYmctYmx1ZS02MDAgdGV4dC13aGl0ZSBib3JkZXItYmx1ZS00MDAgc2hhZG93J1xuICAgICAgICAgICAgICAgICAgICAgIDogJ2JnLXNsYXRlLTk1MCBib3JkZXItc2xhdGUtODAwIHRleHQtc2xhdGUtMzAwIGhvdmVyOmJnLXNsYXRlLTgwMCdcbiAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbVwiPiszMCBEYXlzPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNDAwXCI+MSBNb250aCBQYXNzPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFJlbmV3RGF5c0NvdW50KDkwKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHAtMyByb3VuZGVkLXhsIGJvcmRlciBmb250LWJvbGQgdGV4dC1jZW50ZXIgdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgICAgICAgICAgICAgcmVuZXdEYXlzQ291bnQgPT09IDkwXG4gICAgICAgICAgICAgICAgICAgICAgPyAnYmctYmx1ZS02MDAgdGV4dC13aGl0ZSBib3JkZXItYmx1ZS00MDAgc2hhZG93J1xuICAgICAgICAgICAgICAgICAgICAgIDogJ2JnLXNsYXRlLTk1MCBib3JkZXItc2xhdGUtODAwIHRleHQtc2xhdGUtMzAwIGhvdmVyOmJnLXNsYXRlLTgwMCdcbiAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbVwiPis5MCBEYXlzPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNDAwXCI+UXVhcnRlcmx5IFBhc3M8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0UmVuZXdEYXlzQ291bnQoMzY1KX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHAtMyByb3VuZGVkLXhsIGJvcmRlciBmb250LWJvbGQgdGV4dC1jZW50ZXIgdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgICAgICAgICAgICAgcmVuZXdEYXlzQ291bnQgPT09IDM2NVxuICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLWJsdWUtNjAwIHRleHQtd2hpdGUgYm9yZGVyLWJsdWUtNDAwIHNoYWRvdydcbiAgICAgICAgICAgICAgICAgICAgICA6ICdiZy1zbGF0ZS05NTAgYm9yZGVyLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTMwMCBob3ZlcjpiZy1zbGF0ZS04MDAnXG4gICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc21cIj4rMzY1IERheXM8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS00MDBcIj5Bbm51YWwgTGljZW5zZTwvZGl2PlxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRSZW5ld0RheXNDb3VudCgzNjUwKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHAtMyByb3VuZGVkLXhsIGJvcmRlciBmb250LWJvbGQgdGV4dC1jZW50ZXIgdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgICAgICAgICAgICAgcmVuZXdEYXlzQ291bnQgPT09IDM2NTBcbiAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1lbWVyYWxkLTYwMCB0ZXh0LXdoaXRlIGJvcmRlci1lbWVyYWxkLTQwMCBzaGFkb3cnXG4gICAgICAgICAgICAgICAgICAgICAgOiAnYmctc2xhdGUtOTUwIGJvcmRlci1zbGF0ZS04MDAgdGV4dC1zbGF0ZS0zMDAgaG92ZXI6Ymctc2xhdGUtODAwJ1xuICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXNtXCI+TGlmZXRpbWU8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS00MDBcIj5QZXJtYW5lbnQgQWNjZXNzPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHQtMiBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWVuZCBnYXAtMlwiPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2VsZWN0ZWRPcEZvclJlbmV3KG51bGwpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMiBiZy1zbGF0ZS04MDAgdGV4dC1zbGF0ZS0zMDAgZm9udC1ib2xkIHJvdW5kZWQteGwgdGV4dC14c1wiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICBDYW5jZWxcbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVFeGVjdXRlUmVuZXdhbH1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC01IHB5LTIuNSBiZy1lbWVyYWxkLTYwMCBob3ZlcjpiZy1lbWVyYWxkLTUwMCB0ZXh0LXdoaXRlIGZvbnQtZXh0cmFib2xkIHJvdW5kZWQteGwgc2hhZG93IHRleHQteHMgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8Q2hlY2sgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgICAgPHNwYW4+Q29uZmlybSAmIEFwcGx5IFJlbmV3YWw8L3NwYW4+XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgey8qIFNFTkQgQlJPQURDQVNUIE1PREFMICovfVxuICAgICAge2Jyb2FkY2FzdFRhcmdldFVzZXJuYW1lICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIGJnLWJsYWNrLzg1IGJhY2tkcm9wLWJsdXItc20gei01MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTRcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTN4bCBtYXgtdy1tZCB3LWZ1bGwgcC02IHNoYWRvdy0yeGwgc3BhY2UteS00XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBwYi0yIGJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDBcIj5cbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtZXh0cmFib2xkIHRleHQtd2hpdGUgdGV4dC1iYXNlIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgPE1lc3NhZ2VTcXVhcmUgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LXNreS00MDBcIiAvPlxuICAgICAgICAgICAgICAgIDxzcGFuPlNlbmQgQWxlcnQgdG8gQHticm9hZGNhc3RUYXJnZXRVc2VybmFtZX08L3NwYW4+XG4gICAgICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gc2V0QnJvYWRjYXN0VGFyZ2V0VXNlcm5hbWUobnVsbCl9IGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtd2hpdGVcIj7inJU8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtMzAwXCI+XG4gICAgICAgICAgICAgIFRoaXMgbWVzc2FnZSB3aWxsIHBvcCB1cCBpbW1lZGlhdGVseSBvbiB0aGUgb3BlcmF0b3IncyBjb21wdXRlciBvciBtb2JpbGUgc2NyZWVuLlxuICAgICAgICAgICAgPC9wPlxuXG4gICAgICAgICAgICA8dGV4dGFyZWFcbiAgICAgICAgICAgICAgcm93cz17M31cbiAgICAgICAgICAgICAgdmFsdWU9e2Jyb2FkY2FzdE1lc3NhZ2VUZXh0fVxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEJyb2FkY2FzdE1lc3NhZ2VUZXh0KGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJlLmcuIFBsZWFzZSBjaGVjayBMYWRraSBCYWhpbiBwYXltZW50IHNsaXAgYmVmb3JlIGhhbmRpbmcgb3ZlciB0byBjdXN0b21lci5cIlxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQteGwgcC0zIHRleHQtd2hpdGUgdGV4dC14c1wiXG4gICAgICAgICAgICAvPlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1lbmQgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEJyb2FkY2FzdFRhcmdldFVzZXJuYW1lKG51bGwpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMiBiZy1zbGF0ZS04MDAgdGV4dC1zbGF0ZS0zMDAgZm9udC1ib2xkIHJvdW5kZWQteGwgdGV4dC14c1wiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICBDYW5jZWxcbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVTZW5kQnJvYWRjYXN0fVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTUgcHktMiBiZy1ibHVlLTYwMCBob3ZlcjpiZy1ibHVlLTUwMCB0ZXh0LXdoaXRlIGZvbnQtYm9sZCByb3VuZGVkLXhsIHNoYWRvdyB0ZXh0LXhzIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPFNlbmQgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICAgICAgICAgIDxzcGFuPlNlbmQgVG9hc3QgQWxlcnQ8L3NwYW4+XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgey8qIFJFR0lTVEVSIE5FVyBPUEVSQVRPUiBNT0RBTCAqL31cbiAgICAgIHtzaG93QWRkTW9kYWwgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgYmctYmxhY2svODAgYmFja2Ryb3AtYmx1ci1zbSB6LTUwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtNFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtM3hsIG1heC13LW1kIHctZnVsbCBwLTYgc2hhZG93LTJ4bCBzcGFjZS15LTQgYW5pbWF0ZS1pbiBmYWRlLWluIHpvb20taW4tOTVcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHBiLTIgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZm9udC1leHRyYWJvbGQgdGV4dC13aGl0ZSB0ZXh0LWJhc2UgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICA8VXNlclBsdXMgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LWJsdWUtNDAwXCIgLz5cbiAgICAgICAgICAgICAgICA8c3Bhbj5SZWdpc3RlciBOZXcgT3BlcmF0b3IgSUQ8L3NwYW4+XG4gICAgICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gc2V0U2hvd0FkZE1vZGFsKGZhbHNlKX0gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC13aGl0ZVwiPuKclTwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS0zMDBcIj5cbiAgICAgICAgICAgICAgVGhpcyBuZXcgb3BlcmF0b3IgSUQgd2lsbCBiaW5kIHRvIDxiPjEgQXV0aG9yaXplZCBQQzwvYj4gKyA8Yj4xIEF1dGhvcml6ZWQgTW9iaWxlPC9iPiB1cG9uIHRoZWlyIGZpcnN0IGxvZ2luIGZyb20gZWFjaCBkZXZpY2UuXG4gICAgICAgICAgICA8L3A+XG5cbiAgICAgICAgICAgIHthZGRFcnJvciAmJiAoXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zIHJvdW5kZWQteGwgYmctcm9zZS01MDAvMTAgYm9yZGVyIGJvcmRlci1yb3NlLTUwMC8zMCB0ZXh0LXJvc2UtNDAwIHRleHQteHNcIj5cbiAgICAgICAgICAgICAgICB7YWRkRXJyb3J9XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZUNyZWF0ZU9wZXJhdG9yfSBjbGFzc05hbWU9XCJzcGFjZS15LTMgdGV4dC14c1wiPlxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBibG9jayBtYi0xXCI+T3BlcmF0b3IgRnVsbCBOYW1lPC9sYWJlbD5cbiAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImUuZy4gU2hhaWtoIFNhbWVlclwiXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17bmV3RGlzcGxheU5hbWV9XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldE5ld0Rpc3BsYXlOYW1lKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCBwLTIuNSB0ZXh0LXdoaXRlIGZvbnQtYm9sZFwiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgYmxvY2sgbWItMVwiPlVzZXJuYW1lIChMb2dpbiBJRCk8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiZS5nLiBvcGVyYXRvcjNcIlxuICAgICAgICAgICAgICAgICAgdmFsdWU9e25ld1VzZXJuYW1lfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXROZXdVc2VybmFtZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQteGwgcC0yLjUgdGV4dC13aGl0ZSBmb250LW1vbm8gZm9udC1ib2xkXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBibG9jayBtYi0xXCI+UGFzc3dvcmQ8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgdHlwZT1cInBhc3N3b3JkXCJcbiAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkNyZWF0ZSBzZWN1cmUgcGFzc3dvcmRcIlxuICAgICAgICAgICAgICAgICAgdmFsdWU9e25ld1Bhc3N3b3JkfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXROZXdQYXNzd29yZChlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQteGwgcC0yLjUgdGV4dC13aGl0ZVwiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgYmxvY2sgbWItMVwiPlBob25lIE51bWJlcjwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICB0eXBlPVwidGVsXCJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiTW9iaWxlIG51bWJlclwiXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17bmV3UGhvbmV9XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldE5ld1Bob25lKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCBwLTIuNSB0ZXh0LXdoaXRlXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTIgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1lbmQgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dBZGRNb2RhbChmYWxzZSl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIgYmctc2xhdGUtODAwIHRleHQtc2xhdGUtMzAwIGZvbnQtYm9sZCByb3VuZGVkLXhsXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICBDYW5jZWxcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTUgcHktMiBiZy1ibHVlLTYwMCBob3ZlcjpiZy1ibHVlLTUwMCB0ZXh0LXdoaXRlIGZvbnQtYm9sZCByb3VuZGVkLXhsIHNoYWRvd1wiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgUmVnaXN0ZXIgT3BlcmF0b3JcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Zvcm0+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG4iXX0=