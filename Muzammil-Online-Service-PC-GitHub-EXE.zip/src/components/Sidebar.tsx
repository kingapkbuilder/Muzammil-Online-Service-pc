const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=1d04f0f2";
import { LayoutDashboard, CreditCard, Camera, FileImage, Receipt, Users, FileText, Landmark, Sparkles, Download, Settings, Database, ChevronLeft, ChevronRight, ShieldCheck, Lock } from "/node_modules/.vite/deps/lucide-react.js?v=1d04f0f2";
var _jsxFileName = "/app/applet/src/components/Sidebar.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=1d04f0f2";
export const Sidebar = ({ activeTab, onNavigate, isCollapsed, onToggleCollapse, user, pendingJobsCount, onLogout }) => {
	const navItems = [
		{
			id: "dashboard",
			label: "Dashboard",
			icon: LayoutDashboard,
			badge: null,
			shortcut: "Alt+1"
		},
		{
			id: "pvc_studio",
			label: "PVC Card Maker",
			icon: CreditCard,
			badge: "300 DPI",
			badgeColor: "bg-blue-500/20 text-blue-400 border-blue-500/30",
			shortcut: "Alt+2"
		},
		{
			id: "passport_studio",
			label: "Passport Studio",
			icon: Camera,
			badge: "4×6 / A4",
			badgeColor: "bg-purple-500/20 text-purple-400 border-purple-500/30",
			shortcut: "Alt+3"
		},
		{
			id: "pdf_to_jpg",
			label: "PDF to HD JPG",
			icon: FileImage,
			badge: "Unlock",
			badgeColor: "bg-amber-500/20 text-amber-400 border-amber-500/30",
			shortcut: "Alt+4"
		},
		{
			id: "billing",
			label: "Billing Desk POS",
			icon: Receipt,
			badge: "Thermal",
			badgeColor: "bg-emerald-500/20 text-emerald-400 border-emerald-500/30",
			shortcut: "Alt+5"
		},
		{
			id: "customers",
			label: "Customer CRM",
			icon: Users,
			badge: pendingJobsCount > 0 ? `${pendingJobsCount} Pending` : null,
			badgeColor: "bg-rose-500/20 text-rose-400 border-rose-500/30",
			shortcut: "Alt+6"
		},
		{
			id: "biodata_maker",
			label: "CV & BioData Maker",
			icon: FileText,
			badge: "A4",
			badgeColor: "bg-indigo-500/20 text-indigo-400 border-indigo-500/30",
			shortcut: "Alt+7"
		},
		{
			id: "workflow",
			label: "Cyber Cafe Workflow",
			icon: ShieldCheck,
			badge: "SOP",
			badgeColor: "bg-emerald-500/20 text-emerald-300 border-emerald-500/30",
			shortcut: null
		},
		...user.role === "admin" ? [{
			id: "master_admin",
			label: "Master Admin Panel",
			icon: Lock,
			badge: "Admin",
			badgeColor: "bg-rose-500/20 text-rose-300 border-rose-500/30",
			shortcut: null
		}] : [],
		{
			id: "portals",
			label: "Govt Portals Hub",
			icon: Landmark,
			badge: "50+",
			badgeColor: "bg-sky-500/20 text-sky-400 border-sky-500/30",
			shortcut: "Alt+8"
		},
		{
			id: "ai_assistant",
			label: "AI Scheme Guide",
			icon: Sparkles,
			badge: "AI",
			badgeColor: "bg-amber-500/20 text-amber-300 border-amber-500/30",
			shortcut: "Alt+9"
		},
		{
			id: "downloads",
			label: "Downloads & Files",
			icon: Download,
			badge: null,
			shortcut: null
		},
		{
			id: "settings",
			label: "Shop Settings",
			icon: Settings,
			badge: null,
			shortcut: null
		},
		{
			id: "backup",
			label: "Backup & Restore",
			icon: Database,
			badge: null,
			shortcut: null
		}
	];
	return /* @__PURE__ */ _jsxDEV("aside", {
		className: `bg-slate-900/95 border-r border-slate-800 transition-all duration-200 ease-in-out flex flex-col justify-between select-none z-20 flex-shrink-0 no-print ${isCollapsed ? "w-16" : "w-64"}`,
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "p-2 space-y-1 overflow-y-auto overflow-x-hidden flex-1",
			children: [!isCollapsed && /* @__PURE__ */ _jsxDEV("div", {
				className: "px-3 py-2 text-[11px] font-bold uppercase tracking-wider text-slate-400",
				children: "Workstation Tools"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 161,
				columnNumber: 11
			}, this), navItems.map((item) => {
				const Icon = item.icon;
				const isActive = activeTab === item.id;
				return /* @__PURE__ */ _jsxDEV("button", {
					onClick: () => onNavigate(item.id),
					title: isCollapsed ? `${item.label} (${item.shortcut || ""})` : undefined,
					className: `w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold transition-all group relative ${isActive ? "bg-blue-600 text-white shadow-lg shadow-blue-600/30 font-bold" : "text-slate-300 hover:text-white hover:bg-slate-800/80"}`,
					children: [
						/* @__PURE__ */ _jsxDEV(Icon, { className: `w-4 h-4 flex-shrink-0 transition-transform group-hover:scale-110 ${isActive ? "text-white" : "text-slate-400 group-hover:text-blue-400"}` }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 180,
							columnNumber: 15
						}, this),
						!isCollapsed && /* @__PURE__ */ _jsxDEV("div", {
							className: "flex-1 flex items-center justify-between min-w-0",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "truncate",
								children: item.label
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 184,
								columnNumber: 19
							}, this), item.badge && /* @__PURE__ */ _jsxDEV("span", {
								className: `text-[10px] px-1.5 py-0.5 rounded border font-mono font-medium ${item.badgeColor || "bg-slate-800 text-slate-300 border-slate-700"}`,
								children: item.badge
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 186,
								columnNumber: 21
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 183,
							columnNumber: 17
						}, this),
						isActive && /* @__PURE__ */ _jsxDEV("div", { className: "absolute left-0 top-1/2 -translate-y-1/2 w-1 h-5 bg-white rounded-r-full" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 195,
							columnNumber: 17
						}, this)
					]
				}, item.id, true, {
					fileName: _jsxFileName,
					lineNumber: 170,
					columnNumber: 13
				}, this);
			})]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 159,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "p-2 border-t border-slate-800/80 bg-slate-950/40 space-y-1.5",
			children: [!isCollapsed && /* @__PURE__ */ _jsxDEV("div", {
				className: "p-2.5 rounded-xl bg-slate-900 border border-slate-800",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center justify-between text-xs",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-1.5 text-slate-300 font-medium",
						children: [/* @__PURE__ */ _jsxDEV(ShieldCheck, { className: "w-3.5 h-3.5 text-emerald-400" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 208,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Station Active" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 209,
							columnNumber: 17
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 207,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "text-[10px] text-slate-400 font-mono",
						children: "v98.0 PC"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 211,
						columnNumber: 15
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 206,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center justify-between mt-2 pt-1.5 border-t border-slate-800/60 text-[11px]",
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "text-slate-400 truncate max-w-[120px]",
						children: ["@", user.username]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 214,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: onLogout,
						className: "text-rose-400 hover:text-rose-300 font-bold flex items-center gap-1 hover:underline",
						title: "Lock Station & Logout",
						children: [/* @__PURE__ */ _jsxDEV(Lock, { className: "w-3 h-3" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 220,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Lock" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 221,
							columnNumber: 17
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 215,
						columnNumber: 15
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 213,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 205,
				columnNumber: 11
			}, this), /* @__PURE__ */ _jsxDEV("button", {
				onClick: onToggleCollapse,
				className: "w-full flex items-center justify-center p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors text-xs",
				title: isCollapsed ? "Expand Sidebar (Ctrl + [)" : "Collapse Sidebar (Ctrl + [)",
				children: isCollapsed ? /* @__PURE__ */ _jsxDEV(ChevronRight, { className: "w-4 h-4" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 232,
					columnNumber: 26
				}, this) : /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ _jsxDEV(ChevronLeft, { className: "w-4 h-4" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 234,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "text-xs",
						children: "Collapse Panel"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 235,
						columnNumber: 15
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 233,
					columnNumber: 13
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 227,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 203,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 153,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLFNBQ0UsaUJBQ0EsWUFDQSxRQUNBLFdBQ0EsU0FDQSxPQUNBLFVBQ0EsVUFDQSxVQUNBLFVBQ0EsVUFDQSxVQUNBLGFBQ0EsY0FDQSxhQUNBLFlBQ0s7OztBQWFQLE9BQU8sTUFBTSxXQUFtQyxFQUM5QyxXQUNBLFlBQ0EsYUFDQSxrQkFDQSxNQUNBLGtCQUNBLGVBQ0k7Q0FDSixNQUFNLFdBQVc7RUFDZjtHQUNFLElBQUk7R0FDSixPQUFPO0dBQ1AsTUFBTTtHQUNOLE9BQU87R0FDUCxVQUFVO0VBQ1o7RUFDQTtHQUNFLElBQUk7R0FDSixPQUFPO0dBQ1AsTUFBTTtHQUNOLE9BQU87R0FDUCxZQUFZO0dBQ1osVUFBVTtFQUNaO0VBQ0E7R0FDRSxJQUFJO0dBQ0osT0FBTztHQUNQLE1BQU07R0FDTixPQUFPO0dBQ1AsWUFBWTtHQUNaLFVBQVU7RUFDWjtFQUNBO0dBQ0UsSUFBSTtHQUNKLE9BQU87R0FDUCxNQUFNO0dBQ04sT0FBTztHQUNQLFlBQVk7R0FDWixVQUFVO0VBQ1o7RUFDQTtHQUNFLElBQUk7R0FDSixPQUFPO0dBQ1AsTUFBTTtHQUNOLE9BQU87R0FDUCxZQUFZO0dBQ1osVUFBVTtFQUNaO0VBQ0E7R0FDRSxJQUFJO0dBQ0osT0FBTztHQUNQLE1BQU07R0FDTixPQUFPLG1CQUFtQixJQUFJLEdBQUcsaUJBQWlCLFlBQVk7R0FDOUQsWUFBWTtHQUNaLFVBQVU7RUFDWjtFQUNBO0dBQ0UsSUFBSTtHQUNKLE9BQU87R0FDUCxNQUFNO0dBQ04sT0FBTztHQUNQLFlBQVk7R0FDWixVQUFVO0VBQ1o7RUFDQTtHQUNFLElBQUk7R0FDSixPQUFPO0dBQ1AsTUFBTTtHQUNOLE9BQU87R0FDUCxZQUFZO0dBQ1osVUFBVTtFQUNaO0VBQ0EsR0FBSSxLQUFLLFNBQVMsVUFBVSxDQUFDO0dBQzNCLElBQUk7R0FDSixPQUFPO0dBQ1AsTUFBTTtHQUNOLE9BQU87R0FDUCxZQUFZO0dBQ1osVUFBVTtFQUNaLENBQUMsSUFBSSxDQUFDO0VBQ047R0FDRSxJQUFJO0dBQ0osT0FBTztHQUNQLE1BQU07R0FDTixPQUFPO0dBQ1AsWUFBWTtHQUNaLFVBQVU7RUFDWjtFQUNBO0dBQ0UsSUFBSTtHQUNKLE9BQU87R0FDUCxNQUFNO0dBQ04sT0FBTztHQUNQLFlBQVk7R0FDWixVQUFVO0VBQ1o7RUFDQTtHQUNFLElBQUk7R0FDSixPQUFPO0dBQ1AsTUFBTTtHQUNOLE9BQU87R0FDUCxVQUFVO0VBQ1o7RUFDQTtHQUNFLElBQUk7R0FDSixPQUFPO0dBQ1AsTUFBTTtHQUNOLE9BQU87R0FDUCxVQUFVO0VBQ1o7RUFDQTtHQUNFLElBQUk7R0FDSixPQUFPO0dBQ1AsTUFBTTtHQUNOLE9BQU87R0FDUCxVQUFVO0VBQ1o7Q0FDRjtDQUVBLE9BQ0Usd0JBQUMsU0FBRDtFQUNFLFdBQVcsMkpBQ1QsY0FBYyxTQUFTO1lBRjNCLENBTUUsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZixDQUNHLENBQUMsZUFDQSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUEwRTtHQUVwRjs7OzthQUdOLFNBQVMsS0FBSyxTQUFTO0lBQ3RCLE1BQU0sT0FBTyxLQUFLO0lBQ2xCLE1BQU0sV0FBVyxjQUFjLEtBQUs7SUFDcEMsT0FDRSx3QkFBQyxVQUFEO0tBRUUsZUFBZSxXQUFXLEtBQUssRUFBRTtLQUNqQyxPQUFPLGNBQWMsR0FBRyxLQUFLLE1BQU0sSUFBSSxLQUFLLFlBQVksR0FBRyxLQUFLO0tBQ2hFLFdBQVcsNkdBQ1QsV0FDSSxrRUFDQTtlQVBSO01BVUUsd0JBQUMsTUFBRCxFQUFNLFdBQVcsb0VBQW9FLFdBQVcsZUFBZSw2Q0FBK0M7Ozs7O01BRTdKLENBQUMsZUFDQSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFZLEtBQUs7T0FBWTs7OztpQkFDNUMsS0FBSyxTQUNKLHdCQUFDLFFBQUQ7UUFBTSxXQUFXLGtFQUFrRSxLQUFLLGNBQWM7a0JBQ25HLEtBQUs7T0FDRjs7OztlQUVMOzs7Ozs7TUFJTixZQUNDLHdCQUFDLE9BQUQsRUFBSyxXQUFVLDJFQUE0RTs7Ozs7S0FFdkY7T0ExQkQsS0FBSzs7OztXQTBCSjtHQUVaLENBQUMsQ0FDRTs7Ozs7WUFHTCx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBQ0csQ0FBQyxlQUNBLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxhQUFELEVBQWEsV0FBVSwrQkFBZ0M7Ozs7Z0JBQ3ZELHdCQUFDLFFBQUQsWUFBTSxpQkFBb0I7Ozs7Y0FDdkI7Ozs7O2VBQ0wsd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQXVDO0tBQWM7Ozs7YUFDbEU7Ozs7O2NBQ0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUFoQixDQUF3RCxLQUFFLEtBQUssUUFBZTs7Ozs7ZUFDOUUsd0JBQUMsVUFBRDtNQUNFLFNBQVM7TUFDVCxXQUFVO01BQ1YsT0FBTTtnQkFIUixDQUtFLHdCQUFDLE1BQUQsRUFBTSxXQUFVLFVBQVc7Ozs7Z0JBQzNCLHdCQUFDLFFBQUQsWUFBTSxPQUFVOzs7O2NBQ1Y7Ozs7O2FBQ0w7Ozs7O1lBQ0Y7Ozs7O2FBR1Asd0JBQUMsVUFBRDtJQUNFLFNBQVM7SUFDVCxXQUFVO0lBQ1YsT0FBTyxjQUFjLDhCQUE4QjtjQUVsRCxjQUFjLHdCQUFDLGNBQUQsRUFBYyxXQUFVLFVBQVc7Ozs7ZUFDaEQsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLGFBQUQsRUFBYSxXQUFVLFVBQVc7Ozs7ZUFDbEMsd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQVU7S0FBb0I7Ozs7YUFDM0M7Ozs7OztHQUVEOzs7O1dBQ0w7Ozs7O1VBQ0E7Ozs7OztBQUVYIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlNpZGViYXIudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBcbiAgTGF5b3V0RGFzaGJvYXJkLCBcbiAgQ3JlZGl0Q2FyZCwgXG4gIENhbWVyYSwgXG4gIEZpbGVJbWFnZSwgXG4gIFJlY2VpcHQsIFxuICBVc2VycywgXG4gIEZpbGVUZXh0LCBcbiAgTGFuZG1hcmssIFxuICBTcGFya2xlcywgXG4gIERvd25sb2FkLCBcbiAgU2V0dGluZ3MsIFxuICBEYXRhYmFzZSxcbiAgQ2hldnJvbkxlZnQsXG4gIENoZXZyb25SaWdodCxcbiAgU2hpZWxkQ2hlY2ssXG4gIExvY2tcbn0gZnJvbSAnbHVjaWRlLXJlYWN0JztcbmltcG9ydCB7IFVzZXJBY2NvdW50IH0gZnJvbSAnLi4vdHlwZXMnO1xuXG5pbnRlcmZhY2UgU2lkZWJhclByb3BzIHtcbiAgYWN0aXZlVGFiOiBzdHJpbmc7XG4gIG9uTmF2aWdhdGU6ICh0YWI6IHN0cmluZykgPT4gdm9pZDtcbiAgaXNDb2xsYXBzZWQ6IGJvb2xlYW47XG4gIG9uVG9nZ2xlQ29sbGFwc2U6ICgpID0+IHZvaWQ7XG4gIHVzZXI6IFVzZXJBY2NvdW50O1xuICBwZW5kaW5nSm9ic0NvdW50OiBudW1iZXI7XG4gIG9uTG9nb3V0OiAoKSA9PiB2b2lkO1xufVxuXG5leHBvcnQgY29uc3QgU2lkZWJhcjogUmVhY3QuRkM8U2lkZWJhclByb3BzPiA9ICh7XG4gIGFjdGl2ZVRhYixcbiAgb25OYXZpZ2F0ZSxcbiAgaXNDb2xsYXBzZWQsXG4gIG9uVG9nZ2xlQ29sbGFwc2UsXG4gIHVzZXIsXG4gIHBlbmRpbmdKb2JzQ291bnQsXG4gIG9uTG9nb3V0XG59KSA9PiB7XG4gIGNvbnN0IG5hdkl0ZW1zID0gW1xuICAgIHtcbiAgICAgIGlkOiAnZGFzaGJvYXJkJyxcbiAgICAgIGxhYmVsOiAnRGFzaGJvYXJkJyxcbiAgICAgIGljb246IExheW91dERhc2hib2FyZCxcbiAgICAgIGJhZGdlOiBudWxsLFxuICAgICAgc2hvcnRjdXQ6ICdBbHQrMSdcbiAgICB9LFxuICAgIHtcbiAgICAgIGlkOiAncHZjX3N0dWRpbycsXG4gICAgICBsYWJlbDogJ1BWQyBDYXJkIE1ha2VyJyxcbiAgICAgIGljb246IENyZWRpdENhcmQsXG4gICAgICBiYWRnZTogJzMwMCBEUEknLFxuICAgICAgYmFkZ2VDb2xvcjogJ2JnLWJsdWUtNTAwLzIwIHRleHQtYmx1ZS00MDAgYm9yZGVyLWJsdWUtNTAwLzMwJyxcbiAgICAgIHNob3J0Y3V0OiAnQWx0KzInXG4gICAgfSxcbiAgICB7XG4gICAgICBpZDogJ3Bhc3Nwb3J0X3N0dWRpbycsXG4gICAgICBsYWJlbDogJ1Bhc3Nwb3J0IFN0dWRpbycsXG4gICAgICBpY29uOiBDYW1lcmEsXG4gICAgICBiYWRnZTogJzTDlzYgLyBBNCcsXG4gICAgICBiYWRnZUNvbG9yOiAnYmctcHVycGxlLTUwMC8yMCB0ZXh0LXB1cnBsZS00MDAgYm9yZGVyLXB1cnBsZS01MDAvMzAnLFxuICAgICAgc2hvcnRjdXQ6ICdBbHQrMydcbiAgICB9LFxuICAgIHtcbiAgICAgIGlkOiAncGRmX3RvX2pwZycsXG4gICAgICBsYWJlbDogJ1BERiB0byBIRCBKUEcnLFxuICAgICAgaWNvbjogRmlsZUltYWdlLFxuICAgICAgYmFkZ2U6ICdVbmxvY2snLFxuICAgICAgYmFkZ2VDb2xvcjogJ2JnLWFtYmVyLTUwMC8yMCB0ZXh0LWFtYmVyLTQwMCBib3JkZXItYW1iZXItNTAwLzMwJyxcbiAgICAgIHNob3J0Y3V0OiAnQWx0KzQnXG4gICAgfSxcbiAgICB7XG4gICAgICBpZDogJ2JpbGxpbmcnLFxuICAgICAgbGFiZWw6ICdCaWxsaW5nIERlc2sgUE9TJyxcbiAgICAgIGljb246IFJlY2VpcHQsXG4gICAgICBiYWRnZTogJ1RoZXJtYWwnLFxuICAgICAgYmFkZ2VDb2xvcjogJ2JnLWVtZXJhbGQtNTAwLzIwIHRleHQtZW1lcmFsZC00MDAgYm9yZGVyLWVtZXJhbGQtNTAwLzMwJyxcbiAgICAgIHNob3J0Y3V0OiAnQWx0KzUnXG4gICAgfSxcbiAgICB7XG4gICAgICBpZDogJ2N1c3RvbWVycycsXG4gICAgICBsYWJlbDogJ0N1c3RvbWVyIENSTScsXG4gICAgICBpY29uOiBVc2VycyxcbiAgICAgIGJhZGdlOiBwZW5kaW5nSm9ic0NvdW50ID4gMCA/IGAke3BlbmRpbmdKb2JzQ291bnR9IFBlbmRpbmdgIDogbnVsbCxcbiAgICAgIGJhZGdlQ29sb3I6ICdiZy1yb3NlLTUwMC8yMCB0ZXh0LXJvc2UtNDAwIGJvcmRlci1yb3NlLTUwMC8zMCcsXG4gICAgICBzaG9ydGN1dDogJ0FsdCs2J1xuICAgIH0sXG4gICAge1xuICAgICAgaWQ6ICdiaW9kYXRhX21ha2VyJyxcbiAgICAgIGxhYmVsOiAnQ1YgJiBCaW9EYXRhIE1ha2VyJyxcbiAgICAgIGljb246IEZpbGVUZXh0LFxuICAgICAgYmFkZ2U6ICdBNCcsXG4gICAgICBiYWRnZUNvbG9yOiAnYmctaW5kaWdvLTUwMC8yMCB0ZXh0LWluZGlnby00MDAgYm9yZGVyLWluZGlnby01MDAvMzAnLFxuICAgICAgc2hvcnRjdXQ6ICdBbHQrNydcbiAgICB9LFxuICAgIHtcbiAgICAgIGlkOiAnd29ya2Zsb3cnLFxuICAgICAgbGFiZWw6ICdDeWJlciBDYWZlIFdvcmtmbG93JyxcbiAgICAgIGljb246IFNoaWVsZENoZWNrLFxuICAgICAgYmFkZ2U6ICdTT1AnLFxuICAgICAgYmFkZ2VDb2xvcjogJ2JnLWVtZXJhbGQtNTAwLzIwIHRleHQtZW1lcmFsZC0zMDAgYm9yZGVyLWVtZXJhbGQtNTAwLzMwJyxcbiAgICAgIHNob3J0Y3V0OiBudWxsXG4gICAgfSxcbiAgICAuLi4odXNlci5yb2xlID09PSAnYWRtaW4nID8gW3tcbiAgICAgIGlkOiAnbWFzdGVyX2FkbWluJyxcbiAgICAgIGxhYmVsOiAnTWFzdGVyIEFkbWluIFBhbmVsJyxcbiAgICAgIGljb246IExvY2ssXG4gICAgICBiYWRnZTogJ0FkbWluJyxcbiAgICAgIGJhZGdlQ29sb3I6ICdiZy1yb3NlLTUwMC8yMCB0ZXh0LXJvc2UtMzAwIGJvcmRlci1yb3NlLTUwMC8zMCcsXG4gICAgICBzaG9ydGN1dDogbnVsbFxuICAgIH1dIDogW10pLFxuICAgIHtcbiAgICAgIGlkOiAncG9ydGFscycsXG4gICAgICBsYWJlbDogJ0dvdnQgUG9ydGFscyBIdWInLFxuICAgICAgaWNvbjogTGFuZG1hcmssXG4gICAgICBiYWRnZTogJzUwKycsXG4gICAgICBiYWRnZUNvbG9yOiAnYmctc2t5LTUwMC8yMCB0ZXh0LXNreS00MDAgYm9yZGVyLXNreS01MDAvMzAnLFxuICAgICAgc2hvcnRjdXQ6ICdBbHQrOCdcbiAgICB9LFxuICAgIHtcbiAgICAgIGlkOiAnYWlfYXNzaXN0YW50JyxcbiAgICAgIGxhYmVsOiAnQUkgU2NoZW1lIEd1aWRlJyxcbiAgICAgIGljb246IFNwYXJrbGVzLFxuICAgICAgYmFkZ2U6ICdBSScsXG4gICAgICBiYWRnZUNvbG9yOiAnYmctYW1iZXItNTAwLzIwIHRleHQtYW1iZXItMzAwIGJvcmRlci1hbWJlci01MDAvMzAnLFxuICAgICAgc2hvcnRjdXQ6ICdBbHQrOSdcbiAgICB9LFxuICAgIHtcbiAgICAgIGlkOiAnZG93bmxvYWRzJyxcbiAgICAgIGxhYmVsOiAnRG93bmxvYWRzICYgRmlsZXMnLFxuICAgICAgaWNvbjogRG93bmxvYWQsXG4gICAgICBiYWRnZTogbnVsbCxcbiAgICAgIHNob3J0Y3V0OiBudWxsXG4gICAgfSxcbiAgICB7XG4gICAgICBpZDogJ3NldHRpbmdzJyxcbiAgICAgIGxhYmVsOiAnU2hvcCBTZXR0aW5ncycsXG4gICAgICBpY29uOiBTZXR0aW5ncyxcbiAgICAgIGJhZGdlOiBudWxsLFxuICAgICAgc2hvcnRjdXQ6IG51bGxcbiAgICB9LFxuICAgIHtcbiAgICAgIGlkOiAnYmFja3VwJyxcbiAgICAgIGxhYmVsOiAnQmFja3VwICYgUmVzdG9yZScsXG4gICAgICBpY29uOiBEYXRhYmFzZSxcbiAgICAgIGJhZGdlOiBudWxsLFxuICAgICAgc2hvcnRjdXQ6IG51bGxcbiAgICB9XG4gIF07XG5cbiAgcmV0dXJuIChcbiAgICA8YXNpZGUgXG4gICAgICBjbGFzc05hbWU9e2BiZy1zbGF0ZS05MDAvOTUgYm9yZGVyLXIgYm9yZGVyLXNsYXRlLTgwMCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0yMDAgZWFzZS1pbi1vdXQgZmxleCBmbGV4LWNvbCBqdXN0aWZ5LWJldHdlZW4gc2VsZWN0LW5vbmUgei0yMCBmbGV4LXNocmluay0wIG5vLXByaW50ICR7XG4gICAgICAgIGlzQ29sbGFwc2VkID8gJ3ctMTYnIDogJ3ctNjQnXG4gICAgICB9YH1cbiAgICA+XG4gICAgICB7LyogTmF2aWdhdGlvbiBtZW51IGxpc3QgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMiBzcGFjZS15LTEgb3ZlcmZsb3cteS1hdXRvIG92ZXJmbG93LXgtaGlkZGVuIGZsZXgtMVwiPlxuICAgICAgICB7IWlzQ29sbGFwc2VkICYmIChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTMgcHktMiB0ZXh0LVsxMXB4XSBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICBXb3Jrc3RhdGlvbiBUb29sc1xuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApfVxuXG4gICAgICAgIHtuYXZJdGVtcy5tYXAoKGl0ZW0pID0+IHtcbiAgICAgICAgICBjb25zdCBJY29uID0gaXRlbS5pY29uO1xuICAgICAgICAgIGNvbnN0IGlzQWN0aXZlID0gYWN0aXZlVGFiID09PSBpdGVtLmlkO1xuICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIGtleT17aXRlbS5pZH1cbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb25OYXZpZ2F0ZShpdGVtLmlkKX1cbiAgICAgICAgICAgICAgdGl0bGU9e2lzQ29sbGFwc2VkID8gYCR7aXRlbS5sYWJlbH0gKCR7aXRlbS5zaG9ydGN1dCB8fCAnJ30pYCA6IHVuZGVmaW5lZH1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdy1mdWxsIGZsZXggaXRlbXMtY2VudGVyIGdhcC0zIHB4LTMgcHktMi41IHJvdW5kZWQteGwgdGV4dC14cyBmb250LXNlbWlib2xkIHRyYW5zaXRpb24tYWxsIGdyb3VwIHJlbGF0aXZlICR7XG4gICAgICAgICAgICAgICAgaXNBY3RpdmVcbiAgICAgICAgICAgICAgICAgID8gJ2JnLWJsdWUtNjAwIHRleHQtd2hpdGUgc2hhZG93LWxnIHNoYWRvdy1ibHVlLTYwMC8zMCBmb250LWJvbGQnXG4gICAgICAgICAgICAgICAgICA6ICd0ZXh0LXNsYXRlLTMwMCBob3Zlcjp0ZXh0LXdoaXRlIGhvdmVyOmJnLXNsYXRlLTgwMC84MCdcbiAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxJY29uIGNsYXNzTmFtZT17YHctNCBoLTQgZmxleC1zaHJpbmstMCB0cmFuc2l0aW9uLXRyYW5zZm9ybSBncm91cC1ob3ZlcjpzY2FsZS0xMTAgJHtpc0FjdGl2ZSA/ICd0ZXh0LXdoaXRlJyA6ICd0ZXh0LXNsYXRlLTQwMCBncm91cC1ob3Zlcjp0ZXh0LWJsdWUtNDAwJ31gfSAvPlxuICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgeyFpc0NvbGxhcHNlZCAmJiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1pbi13LTBcIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRydW5jYXRlXCI+e2l0ZW0ubGFiZWx9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAge2l0ZW0uYmFkZ2UgJiYgKFxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2B0ZXh0LVsxMHB4XSBweC0xLjUgcHktMC41IHJvdW5kZWQgYm9yZGVyIGZvbnQtbW9ubyBmb250LW1lZGl1bSAke2l0ZW0uYmFkZ2VDb2xvciB8fCAnYmctc2xhdGUtODAwIHRleHQtc2xhdGUtMzAwIGJvcmRlci1zbGF0ZS03MDAnfWB9PlxuICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLmJhZGdlfVxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgIHsvKiBBY3RpdmUgSW5kaWNhdG9yIEJhciAqL31cbiAgICAgICAgICAgICAge2lzQWN0aXZlICYmIChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGxlZnQtMCB0b3AtMS8yIC10cmFuc2xhdGUteS0xLzIgdy0xIGgtNSBiZy13aGl0ZSByb3VuZGVkLXItZnVsbFwiIC8+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICApO1xuICAgICAgICB9KX1cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogRm9vdGVyIC8gVG9nZ2xlICYgU3lzdGVtIFN0YXR1cyAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0yIGJvcmRlci10IGJvcmRlci1zbGF0ZS04MDAvODAgYmctc2xhdGUtOTUwLzQwIHNwYWNlLXktMS41XCI+XG4gICAgICAgIHshaXNDb2xsYXBzZWQgJiYgKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0yLjUgcm91bmRlZC14bCBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDBcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHRleHQteHNcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHRleHQtc2xhdGUtMzAwIGZvbnQtbWVkaXVtXCI+XG4gICAgICAgICAgICAgICAgPFNoaWVsZENoZWNrIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtZW1lcmFsZC00MDBcIiAvPlxuICAgICAgICAgICAgICAgIDxzcGFuPlN0YXRpb24gQWN0aXZlPC9zcGFuPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS00MDAgZm9udC1tb25vXCI+djk4LjAgUEM8L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG10LTIgcHQtMS41IGJvcmRlci10IGJvcmRlci1zbGF0ZS04MDAvNjAgdGV4dC1bMTFweF1cIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgdHJ1bmNhdGUgbWF4LXctWzEyMHB4XVwiPkB7dXNlci51c2VybmFtZX08L3NwYW4+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXtvbkxvZ291dH1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXJvc2UtNDAwIGhvdmVyOnRleHQtcm9zZS0zMDAgZm9udC1ib2xkIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xIGhvdmVyOnVuZGVybGluZVwiXG4gICAgICAgICAgICAgICAgdGl0bGU9XCJMb2NrIFN0YXRpb24gJiBMb2dvdXRcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPExvY2sgY2xhc3NOYW1lPVwidy0zIGgtM1wiIC8+XG4gICAgICAgICAgICAgICAgPHNwYW4+TG9jazwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKX1cblxuICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgb25DbGljaz17b25Ub2dnbGVDb2xsYXBzZX1cbiAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC0yIHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtd2hpdGUgaG92ZXI6Ymctc2xhdGUtODAwIHJvdW5kZWQtbGcgdHJhbnNpdGlvbi1jb2xvcnMgdGV4dC14c1wiXG4gICAgICAgICAgdGl0bGU9e2lzQ29sbGFwc2VkID8gXCJFeHBhbmQgU2lkZWJhciAoQ3RybCArIFspXCIgOiBcIkNvbGxhcHNlIFNpZGViYXIgKEN0cmwgKyBbKVwifVxuICAgICAgICA+XG4gICAgICAgICAge2lzQ29sbGFwc2VkID8gPENoZXZyb25SaWdodCBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz4gOiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgIDxDaGV2cm9uTGVmdCBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14c1wiPkNvbGxhcHNlIFBhbmVsPC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9idXR0b24+XG4gICAgICA8L2Rpdj5cbiAgICA8L2FzaWRlPlxuICApO1xufTtcbiJdfQ==