const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useRef = __vite__cjsImport0_react["useRef"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=1d04f0f2";
import { Upload, Printer, Sparkles, CheckCircle2, Sliders, Check, Undo2, Redo2, Layers, Minimize2 } from "/node_modules/.vite/deps/lucide-react.js?v=1d04f0f2";
import { jsPDF } from "/node_modules/.vite/deps/jspdf.js?v=1d04f0f2";
import { addDownloadRecord } from "/src/utils/storage.ts";
import { printImageSheet } from "/src/utils/printer.ts";
var _jsxFileName = "/app/applet/src/components/PassportStudioView.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=1d04f0f2";
const BEAUTY_PRESETS = [
	{
		id: "auto_beauty",
		name: "Auto Studio Beauty",
		icon: "✨",
		desc: "Smooth skin & radiant facial lighting",
		settings: {
			brightness: 8,
			contrast: 6,
			saturation: 12,
			warmth: 8,
			tint: 4,
			skinSmooth: 20,
			faceGlow: 25,
			shadowLift: 15,
			isGrayscale: false
		}
	},
	{
		id: "indian_warm",
		name: "Indian Studio Tone",
		icon: "📸",
		desc: "Golden warm glow, removes camera pale tone",
		settings: {
			brightness: 6,
			contrast: 8,
			saturation: 15,
			warmth: 18,
			tint: 2,
			skinSmooth: 16,
			faceGlow: 20,
			shadowLift: 12,
			isGrayscale: false
		}
	},
	{
		id: "glamour_soft",
		name: "Soft Glamour Glow",
		icon: "🌟",
		desc: "Airbrushed porcelain skin with soft highlights",
		settings: {
			brightness: 12,
			contrast: 4,
			saturation: 8,
			warmth: 10,
			tint: 6,
			skinSmooth: 32,
			faceGlow: 35,
			shadowLift: 20,
			isGrayscale: false
		}
	},
	{
		id: "crisp_formal",
		name: "Sharp Formal ID",
		icon: "💼",
		desc: "Neutral white balance & crisp facial edges",
		settings: {
			brightness: 4,
			contrast: 12,
			saturation: 5,
			warmth: 0,
			tint: 0,
			skinSmooth: 8,
			faceGlow: 10,
			shadowLift: 8,
			isGrayscale: false
		}
	},
	{
		id: "cool_clean",
		name: "Cool White Balance",
		icon: "❄️",
		desc: "Removes yellow/orange lighting cast",
		settings: {
			brightness: 8,
			contrast: 8,
			saturation: 4,
			warmth: -14,
			tint: -2,
			skinSmooth: 14,
			faceGlow: 15,
			shadowLift: 10,
			isGrayscale: false
		}
	},
	{
		id: "bw_formal",
		name: "B&W Official Exam",
		icon: "🖤",
		desc: "High contrast monochrome for SSC/UPSC",
		settings: {
			brightness: 6,
			contrast: 16,
			saturation: 0,
			warmth: 0,
			tint: 0,
			skinSmooth: 12,
			faceGlow: 10,
			shadowLift: 10,
			isGrayscale: true
		}
	}
];
export const PassportStudioView = () => {
	// Main Sheet Canvas (Hidden or rendered for 4x6 / A4 sheet calculation)
	const fullSheetCanvasRef = useRef(null);
	// Photoshop-Style Editing Canvas (Primary interactive workspace)
	const editorCanvasRef = useRef(null);
	// Mini Preview Canvas (Compact Sheet Preview widget)
	const miniPreviewCanvasRef = useRef(null);
	// Active Tool Selection (Photoshop Toolbar)
	const [activeTool, setActiveTool] = useState("select");
	// Photo Source & History Stack for Undo / Redo
	const [photoSrc, setPhotoSrc] = useState(null);
	const [originalPhotoSrc, setOriginalPhotoSrc] = useState(null);
	const [historyStack, setHistoryStack] = useState([]);
	const [historyIndex, setHistoryIndex] = useState(-1);
	const photoImgRef = useRef(null);
	// Paper & Layout settings: Default is 4x6 LANDSCAPE with 8 COPIES
	const [paperFormat, setPaperFormat] = useState("4x6_landscape");
	const [copies, setCopies] = useState(8);
	// Studio background replacement color
	const [bgColor, setBgColor] = useState("#ffffff");
	// Mini Preview Visibility State (Collapsible / Expandable)
	const [showMiniPreview, setShowMiniPreview] = useState(true);
	// Auto Beauty Mode Toggle
	const [autoBeauty, setAutoBeauty] = useState(true);
	const [activePreset, setActivePreset] = useState("auto_beauty");
	// Color Grading Parameters
	const [brightness, setBrightness] = useState(8);
	const [contrast, setContrast] = useState(6);
	const [saturation, setSaturation] = useState(12);
	const [warmth, setWarmth] = useState(8);
	const [tint, setTint] = useState(4);
	const [shadowLift, setShadowLift] = useState(15);
	const [skinSmooth, setSkinSmooth] = useState(20);
	const [faceGlow, setFaceGlow] = useState(25);
	const [isGrayscale, setIsGrayscale] = useState(false);
	// Canvas Viewport Pan & Zoom
	const [canvasZoom, setCanvasZoom] = useState(1);
	const [canvasPan, setCanvasPan] = useState({
		x: 0,
		y: 0
	});
	const [isSpacePressed, setIsSpacePressed] = useState(false);
	const [isPanning, setIsPanning] = useState(false);
	const [panStart, setPanStart] = useState({
		x: 0,
		y: 0
	});
	// Tool Specific States:
	// 1. Magic Wand / Magic Cut
	const [magicTolerance, setMagicTolerance] = useState(32);
	const [magicFeather, setMagicFeather] = useState(2);
	// 2. Pen Tool (Manual Vector Cutout)
	const [penPoints, setPenPoints] = useState([]);
	const [isPathClosed, setIsPathClosed] = useState(false);
	const [isNearStartPoint, setIsNearStartPoint] = useState(false);
	const [penFeather, setPenFeather] = useState(2);
	// 3. Brushes (Blemish, Beauty, Eye Brighten)
	const [brushSize, setBrushSize] = useState(24);
	const [isBrushing, setIsBrushing] = useState(false);
	// 4. Crop Tool
	const [cropBox, setCropBox] = useState(null);
	// Exam Name & Date overlay (for SSC, Police Bharti, UPSC)
	const [showNameDate, setShowNameDate] = useState(false);
	const [candidateName, setCandidateName] = useState("CANDIDATE NAME");
	const [photoDate, setPhotoDate] = useState(new Date().toLocaleDateString("en-IN", {
		day: "2-digit",
		month: "2-digit",
		year: "numeric"
	}));
	const [isProcessing, setIsProcessing] = useState(false);
	const [printAlert, setPrintAlert] = useState(null);
	// 300 DPI Canvas Dimensions for full sheet
	let SHEET_WIDTH = 1800;
	let SHEET_HEIGHT = 1200;
	if (paperFormat === "4x6_landscape") {
		SHEET_WIDTH = 1800;
		SHEET_HEIGHT = 1200;
	} else if (paperFormat === "a4_landscape") {
		SHEET_WIDTH = 3508;
		SHEET_HEIGHT = 2480;
	} else if (paperFormat === "4x6_portrait") {
		SHEET_WIDTH = 1200;
		SHEET_HEIGHT = 1800;
	} else {
		SHEET_WIDTH = 2480;
		SHEET_HEIGHT = 3508;
	}
	// -------------------------------------------------------------
	// KEYBOARD SHORTCUTS LISTENER (Photoshop Standard: V, C, W, P, B, S, H, Z, Ctrl+Z, Ctrl+P)
	// -------------------------------------------------------------
	useEffect(() => {
		const handleKeyDown = (e) => {
			// Don't trigger if user is typing in text input
			if (e.target.tagName === "INPUT" || e.target.tagName === "TEXTAREA") {
				return;
			}
			// Spacebar for temporary Hand Pan tool
			if (e.code === "Space" && !e.repeat) {
				setIsSpacePressed(true);
			}
			// Undo: Ctrl + Z
			if (e.ctrlKey && e.key.toLowerCase() === "z" && !e.shiftKey) {
				e.preventDefault();
				handleUndo();
			}
			// Redo: Ctrl + Y or Ctrl + Shift + Z
			if (e.ctrlKey && e.key.toLowerCase() === "y" || e.ctrlKey && e.shiftKey && e.key.toLowerCase() === "z") {
				e.preventDefault();
				handleRedo();
			}
			// Tools Switcher Shortcuts:
			if (!e.ctrlKey && !e.altKey && !e.metaKey) {
				switch (e.key.toLowerCase()) {
					case "v":
						setActiveTool("select");
						break;
					case "c":
						setActiveTool("crop");
						initCropBox();
						break;
					case "w":
						setActiveTool("magic_wand");
						break;
					case "p":
						setActiveTool("pen_tool");
						break;
					case "b":
						setActiveTool("blemish_brush");
						break;
					case "s":
						setActiveTool("beauty_brush");
						break;
					case "e":
						setActiveTool("eye_brighten");
						break;
					case "h":
						setActiveTool("hand");
						break;
					case "z":
						setActiveTool("zoom");
						break;
					case "m":
						setShowMiniPreview((prev) => !prev);
						break;
					case "[":
						setBrushSize((prev) => Math.max(8, prev - 4));
						break;
					case "]":
						setBrushSize((prev) => Math.min(80, prev + 4));
						break;
					case "escape":
						if (activeTool === "pen_tool") {
							setPenPoints([]);
							setIsPathClosed(false);
						}
						if (activeTool === "crop") {
							setCropBox(null);
							setActiveTool("select");
						}
						break;
				}
			}
			// Zoom Shortcuts: Ctrl + '+' / Ctrl + '-' / Ctrl + '0'
			if (e.ctrlKey && (e.key === "=" || e.key === "+")) {
				e.preventDefault();
				setCanvasZoom((prev) => Math.min(4, prev + .25));
			}
			if (e.ctrlKey && (e.key === "-" || e.key === "_")) {
				e.preventDefault();
				setCanvasZoom((prev) => Math.max(.4, prev - .25));
			}
			if (e.ctrlKey && e.key === "0") {
				e.preventDefault();
				setCanvasZoom(1);
				setCanvasPan({
					x: 0,
					y: 0
				});
			}
		};
		const handleKeyUp = (e) => {
			if (e.code === "Space") {
				setIsSpacePressed(false);
				setIsPanning(false);
			}
		};
		window.addEventListener("keydown", handleKeyDown);
		window.addEventListener("keyup", handleKeyUp);
		return () => {
			window.removeEventListener("keydown", handleKeyDown);
			window.removeEventListener("keyup", handleKeyUp);
		};
	}, [
		activeTool,
		historyIndex,
		historyStack
	]);
	// Push new state to undo/redo history
	const pushToHistory = (newSrc) => {
		setHistoryStack((prev) => {
			const upToCurrent = prev.slice(0, historyIndex + 1);
			const updated = [...upToCurrent, newSrc];
			if (updated.length > 15) updated.shift();
			return updated;
		});
		setHistoryIndex((prev) => Math.min(14, prev + 1));
	};
	const handleUndo = () => {
		if (activeTool === "pen_tool" && penPoints.length > 0) {
			if (isPathClosed) {
				setIsPathClosed(false);
			} else {
				setPenPoints((prev) => prev.slice(0, -1));
			}
			return;
		}
		if (historyIndex > 0) {
			const nextIdx = historyIndex - 1;
			setHistoryIndex(nextIdx);
			setPhotoSrc(historyStack[nextIdx]);
		}
	};
	const handleRedo = () => {
		if (historyIndex < historyStack.length - 1) {
			const nextIdx = historyIndex + 1;
			setHistoryIndex(nextIdx);
			setPhotoSrc(historyStack[nextIdx]);
		}
	};
	// Load photo into Image object
	useEffect(() => {
		if (photoSrc) {
			const img = new Image();
			img.crossOrigin = "anonymous";
			img.onload = () => {
				photoImgRef.current = img;
				renderEditorCanvas();
				renderMiniPreview();
				renderFullSheet();
			};
			img.src = photoSrc;
		} else {
			photoImgRef.current = null;
			renderEditorCanvas();
			renderMiniPreview();
			renderFullSheet();
		}
	}, [photoSrc]);
	// Re-render when adjustments change
	useEffect(() => {
		renderEditorCanvas();
		renderMiniPreview();
		renderFullSheet();
	}, [
		photoSrc,
		activeTool,
		penPoints,
		isPathClosed,
		isNearStartPoint,
		cropBox,
		canvasZoom,
		canvasPan,
		bgColor,
		autoBeauty,
		brightness,
		contrast,
		saturation,
		warmth,
		tint,
		shadowLift,
		skinSmooth,
		faceGlow,
		isGrayscale,
		paperFormat,
		copies,
		showNameDate,
		candidateName,
		photoDate
	]);
	// Initialize crop box to 35:45 ratio
	const initCropBox = () => {
		const canvas = editorCanvasRef.current;
		if (!canvas) return;
		const w = Math.min(canvas.width * .7, canvas.height * .7 * (35 / 45));
		const h = w * (45 / 35);
		setCropBox({
			x: (canvas.width - w) / 2,
			y: (canvas.height - h) / 2,
			w,
			h
		});
	};
	// Apply Crop
	const handleApplyCrop = () => {
		const canvas = editorCanvasRef.current;
		const img = photoImgRef.current;
		if (!canvas || !img || !cropBox) return;
		try {
			const cropCanvas = document.createElement("canvas");
			cropCanvas.width = 700;
			cropCanvas.height = 900;
			const cCtx = cropCanvas.getContext("2d");
			if (!cCtx) return;
			// Extract cropped area from editor canvas
			cCtx.drawImage(canvas, cropBox.x, cropBox.y, cropBox.w, cropBox.h, 0, 0, cropCanvas.width, cropCanvas.height);
			const croppedUrl = cropCanvas.toDataURL("image/jpeg", .98);
			setPhotoSrc(croppedUrl);
			pushToHistory(croppedUrl);
			setCropBox(null);
			setActiveTool("select");
			setPrintAlert("✂️ Photo cropped to 35×45mm passport ratio!");
			setTimeout(() => setPrintAlert(null), 3e3);
		} catch (e) {
			console.error(e);
		}
	};
	// -------------------------------------------------------------
	// MAGIC WAND / MAGIC CUT (FIXED & HIGH-PRECISION FLOOD FILL)
	// -------------------------------------------------------------
	// BFS Connected Flood-Fill from clicked pixel
	const executeMagicWandCut = (clickX, clickY) => {
		const img = photoImgRef.current;
		if (!img) return;
		setIsProcessing(true);
		try {
			const workCanvas = document.createElement("canvas");
			workCanvas.width = img.width;
			workCanvas.height = img.height;
			const wCtx = workCanvas.getContext("2d");
			if (!wCtx) return;
			wCtx.drawImage(img, 0, 0);
			const imgData = wCtx.getImageData(0, 0, workCanvas.width, workCanvas.height);
			const data = imgData.data;
			const w = workCanvas.width;
			const h = workCanvas.height;
			// Scale clickX, clickY to original image pixels
			const startX = Math.floor(Math.max(0, Math.min(w - 1, clickX)));
			const startY = Math.floor(Math.max(0, Math.min(h - 1, clickY)));
			const startIndex = (startY * w + startX) * 4;
			const targetR = data[startIndex];
			const targetG = data[startIndex + 1];
			const targetB = data[startIndex + 2];
			// Parse target background color
			const dummy = document.createElement("div");
			dummy.style.color = bgColor;
			document.body.appendChild(dummy);
			const computed = window.getComputedStyle(dummy).color;
			document.body.removeChild(dummy);
			const rgb = computed.match(/\d+/g)?.map(Number) || [
				255,
				255,
				255
			];
			// Visited array to prevent infinite loop
			const visited = new Uint8Array(w * h);
			const queue = [startX + startY * w];
			visited[startX + startY * w] = 1;
			const tolSq = Math.pow(magicTolerance * 2.2, 2);
			// BFS flood fill
			let head = 0;
			while (head < queue.length) {
				const curr = queue[head++];
				const cx = curr % w;
				const cy = Math.floor(curr / w);
				const idx = curr * 4;
				// Replace pixel color with studio background
				data[idx] = rgb[0];
				data[idx + 1] = rgb[1];
				data[idx + 2] = rgb[2];
				data[idx + 3] = 255;
				// Check 4-directional neighbors
				const neighbors = [
					[cx + 1, cy],
					[cx - 1, cy],
					[cx, cy + 1],
					[cx, cy - 1]
				];
				for (let i = 0; i < 4; i++) {
					const nx = neighbors[i][0];
					const ny = neighbors[i][1];
					if (nx >= 0 && nx < w && ny >= 0 && ny < h) {
						const nPos = nx + ny * w;
						if (!visited[nPos]) {
							const nIdx = nPos * 4;
							const nr = data[nIdx];
							const ng = data[nIdx + 1];
							const nb = data[nIdx + 2];
							// Color distance from target
							const distSq = Math.pow(nr - targetR, 2) + Math.pow(ng - targetG, 2) + Math.pow(nb - targetB, 2);
							if (distSq <= tolSq) {
								visited[nPos] = 1;
								queue.push(nPos);
							}
						}
					}
				}
			}
			wCtx.putImageData(imgData, 0, 0);
			const resDataUrl = workCanvas.toDataURL("image/jpeg", .98);
			if (!originalPhotoSrc && photoSrc) {
				setOriginalPhotoSrc(photoSrc);
			}
			setPhotoSrc(resDataUrl);
			pushToHistory(resDataUrl);
			setPrintAlert(`🪄 Magic Wand erased connected background at (${startX}, ${startY})!`);
			setTimeout(() => setPrintAlert(null), 3e3);
		} catch (e) {
			console.error(e);
		} finally {
			setIsProcessing(false);
		}
	};
	// 1-Click Auto Background Eraser (Seeds flood fill from all 4 outer borders)
	const handleAutoBackgroundErase = () => {
		const img = photoImgRef.current;
		if (!img) return;
		setIsProcessing(true);
		try {
			const workCanvas = document.createElement("canvas");
			workCanvas.width = img.width;
			workCanvas.height = img.height;
			const wCtx = workCanvas.getContext("2d");
			if (!wCtx) return;
			wCtx.drawImage(img, 0, 0);
			const imgData = wCtx.getImageData(0, 0, workCanvas.width, workCanvas.height);
			const data = imgData.data;
			const w = workCanvas.width;
			const h = workCanvas.height;
			// Target background color parse
			const dummy = document.createElement("div");
			dummy.style.color = bgColor;
			document.body.appendChild(dummy);
			const computed = window.getComputedStyle(dummy).color;
			document.body.removeChild(dummy);
			const rgb = computed.match(/\d+/g)?.map(Number) || [
				255,
				255,
				255
			];
			// Sample reference background color from top corners
			const cornerR = (data[0] + data[(w - 1) * 4]) / 2;
			const cornerG = (data[1] + data[(w - 1) * 4 + 1]) / 2;
			const cornerB = (data[2] + data[(w - 1) * 4 + 2]) / 2;
			const visited = new Uint8Array(w * h);
			const queue = [];
			// Seed all 4 outer borders
			for (let x = 0; x < w; x++) {
				queue.push(x);
				queue.push(x + (h - 1) * w);
				visited[x] = 1;
				visited[x + (h - 1) * w] = 1;
			}
			for (let y = 0; y < h; y++) {
				queue.push(y * w);
				queue.push(w - 1 + y * w);
				visited[y * w] = 1;
				visited[w - 1 + y * w] = 1;
			}
			const tolSq = Math.pow(magicTolerance * 2.2, 2);
			let head = 0;
			while (head < queue.length) {
				const curr = queue[head++];
				const cx = curr % w;
				const cy = Math.floor(curr / w);
				const idx = curr * 4;
				// Replace background pixel
				data[idx] = rgb[0];
				data[idx + 1] = rgb[1];
				data[idx + 2] = rgb[2];
				data[idx + 3] = 255;
				const neighbors = [
					[cx + 1, cy],
					[cx - 1, cy],
					[cx, cy + 1],
					[cx, cy - 1]
				];
				for (let i = 0; i < 4; i++) {
					const nx = neighbors[i][0];
					const ny = neighbors[i][1];
					if (nx >= 0 && nx < w && ny >= 0 && ny < h) {
						const nPos = nx + ny * w;
						if (!visited[nPos]) {
							const nIdx = nPos * 4;
							const nr = data[nIdx];
							const ng = data[nIdx + 1];
							const nb = data[nIdx + 2];
							const distSq = Math.pow(nr - cornerR, 2) + Math.pow(ng - cornerG, 2) + Math.pow(nb - cornerB, 2);
							if (distSq <= tolSq) {
								visited[nPos] = 1;
								queue.push(nPos);
							}
						}
					}
				}
			}
			wCtx.putImageData(imgData, 0, 0);
			const resDataUrl = workCanvas.toDataURL("image/jpeg", .98);
			if (!originalPhotoSrc && photoSrc) {
				setOriginalPhotoSrc(photoSrc);
			}
			setPhotoSrc(resDataUrl);
			pushToHistory(resDataUrl);
			setPrintAlert("✨ 1-Click Magic Auto Background successfully replaced!");
			setTimeout(() => setPrintAlert(null), 3e3);
		} catch (e) {
			console.error(e);
		} finally {
			setIsProcessing(false);
		}
	};
	// -------------------------------------------------------------
	// SPOT BLEMISH REMOVER & BEAUTY BRUSH
	// -------------------------------------------------------------
	const applyHealingBrush = (centerX, centerY, mode) => {
		const img = photoImgRef.current;
		if (!img) return;
		try {
			const workCanvas = document.createElement("canvas");
			workCanvas.width = img.width;
			workCanvas.height = img.height;
			const wCtx = workCanvas.getContext("2d");
			if (!wCtx) return;
			wCtx.drawImage(img, 0, 0);
			const rad = brushSize;
			const x = Math.max(0, Math.min(img.width, centerX));
			const y = Math.max(0, Math.min(img.height, centerY));
			if (mode === "blemish") {
				// Sample surrounding ring of skin pixels and blend into center
				const imgData = wCtx.getImageData(Math.max(0, x - rad), Math.max(0, y - rad), rad * 2, rad * 2);
				const data = imgData.data;
				// Average surrounding ring
				let rSum = 0, gSum = 0, bSum = 0, count = 0;
				for (let py = 0; py < rad * 2; py++) {
					for (let px = 0; px < rad * 2; px++) {
						const d = Math.hypot(px - rad, py - rad);
						if (d >= rad * .7 && d <= rad) {
							const i = (py * rad * 2 + px) * 4;
							rSum += data[i];
							gSum += data[i + 1];
							bSum += data[i + 2];
							count++;
						}
					}
				}
				if (count > 0) {
					const avgR = rSum / count;
					const avgG = gSum / count;
					const avgB = bSum / count;
					for (let py = 0; py < rad * 2; py++) {
						for (let px = 0; px < rad * 2; px++) {
							const d = Math.hypot(px - rad, py - rad);
							if (d < rad) {
								const i = (py * rad * 2 + px) * 4;
								const alphaWeight = 1 - d / rad;
								data[i] = data[i] * (1 - alphaWeight) + avgR * alphaWeight;
								data[i + 1] = data[i + 1] * (1 - alphaWeight) + avgG * alphaWeight;
								data[i + 2] = data[i + 2] * (1 - alphaWeight) + avgB * alphaWeight;
							}
						}
					}
					wCtx.putImageData(imgData, Math.max(0, x - rad), Math.max(0, y - rad));
				}
			} else if (mode === "beauty") {
				// Soft skin airbrush blur
				wCtx.save();
				wCtx.beginPath();
				wCtx.arc(x, y, rad, 0, Math.PI * 2);
				wCtx.clip();
				wCtx.filter = "blur(4px) brightness(105%)";
				wCtx.drawImage(img, 0, 0);
				wCtx.restore();
			} else {
				// Eye & Teeth Whitener
				wCtx.save();
				wCtx.beginPath();
				wCtx.arc(x, y, rad, 0, Math.PI * 2);
				wCtx.clip();
				wCtx.filter = "brightness(118%) contrast(106%) saturate(60%)";
				wCtx.drawImage(img, 0, 0);
				wCtx.restore();
			}
			const resDataUrl = workCanvas.toDataURL("image/jpeg", .98);
			setPhotoSrc(resDataUrl);
			pushToHistory(resDataUrl);
		} catch (e) {
			console.error(e);
		}
	};
	// -------------------------------------------------------------
	// PEN TOOL: APPLY VECTOR CUTOUT
	// -------------------------------------------------------------
	const handleApplyPenCutout = () => {
		const img = photoImgRef.current;
		if (!img || penPoints.length < 3) return;
		try {
			const workCanvas = document.createElement("canvas");
			workCanvas.width = img.width;
			workCanvas.height = img.height;
			const wCtx = workCanvas.getContext("2d");
			if (!wCtx) return;
			// 1. Fill studio background
			wCtx.fillStyle = bgColor;
			wCtx.fillRect(0, 0, workCanvas.width, workCanvas.height);
			// 2. Create offscreen person layer clipped to path
			const personCanvas = document.createElement("canvas");
			personCanvas.width = img.width;
			personCanvas.height = img.height;
			const pCtx = personCanvas.getContext("2d");
			if (pCtx) {
				pCtx.drawImage(img, 0, 0);
				const maskCanvas = document.createElement("canvas");
				maskCanvas.width = img.width;
				maskCanvas.height = img.height;
				const mCtx = maskCanvas.getContext("2d");
				if (mCtx) {
					if (penFeather > 0) {
						mCtx.filter = `blur(${penFeather}px)`;
					}
					mCtx.beginPath();
					mCtx.moveTo(penPoints[0].x * img.width, penPoints[0].y * img.height);
					for (let i = 1; i < penPoints.length; i++) {
						mCtx.lineTo(penPoints[i].x * img.width, penPoints[i].y * img.height);
					}
					mCtx.closePath();
					mCtx.fillStyle = "#000000";
					mCtx.fill();
					pCtx.globalCompositeOperation = "destination-in";
					pCtx.drawImage(maskCanvas, 0, 0);
				}
				wCtx.drawImage(personCanvas, 0, 0);
			}
			const resDataUrl = workCanvas.toDataURL("image/jpeg", .98);
			if (!originalPhotoSrc && photoSrc) {
				setOriginalPhotoSrc(photoSrc);
			}
			setPhotoSrc(resDataUrl);
			pushToHistory(resDataUrl);
			setPenPoints([]);
			setIsPathClosed(false);
			setActiveTool("select");
			setPrintAlert("🖊️ Pen Tool Cutout applied successfully!");
			setTimeout(() => setPrintAlert(null), 3e3);
		} catch (e) {
			console.error(e);
		}
	};
	// -------------------------------------------------------------
	// MAIN EDITOR CANVAS RENDER (Central Photoshop-Style Workspace)
	// -------------------------------------------------------------
	const renderEditorCanvas = () => {
		const canvas = editorCanvasRef.current;
		const img = photoImgRef.current;
		if (!canvas) return;
		const ctx = canvas.getContext("2d");
		if (!ctx) return;
		// Fixed internal size for sharp 2K editing canvas
		canvas.width = 900;
		canvas.height = 700;
		// Dark workspace checkered background
		ctx.fillStyle = "#090d16";
		ctx.fillRect(0, 0, canvas.width, canvas.height);
		if (!img) {
			// Empty state
			ctx.fillStyle = "#64748b";
			ctx.font = "bold 16px sans-serif";
			ctx.textAlign = "center";
			ctx.fillText("Upload or Drag Customer Photo to Edit", canvas.width / 2, canvas.height / 2 - 10);
			ctx.font = "12px sans-serif";
			ctx.fillText("Photoshop-style tools: Pen, Magic Wand, Blemish, Crop, Auto Beauty", canvas.width / 2, canvas.height / 2 + 15);
			return;
		}
		ctx.save();
		// Pan & Zoom transformations
		ctx.translate(canvas.width / 2 + canvasPan.x, canvas.height / 2 + canvasPan.y);
		ctx.scale(canvasZoom, canvasZoom);
		// Calculate dimensions maintaining aspect ratio
		const aspect = img.width / img.height;
		let renderW = 460;
		let renderH = 460 / aspect;
		if (renderH > 560) {
			renderH = 560;
			renderW = 560 * aspect;
		}
		const drawX = -renderW / 2;
		const drawY = -renderH / 2;
		// Apply color grading filters
		const effBrightness = 100 + brightness + (autoBeauty ? 6 : 0) + faceGlow * .12;
		const effContrast = 100 + contrast + (autoBeauty ? 4 : 0);
		const effSaturation = isGrayscale ? 0 : 100 + saturation + (autoBeauty ? 8 : 0);
		let filterStr = `brightness(${effBrightness}%) contrast(${effContrast}%) saturate(${effSaturation}%)`;
		if (isGrayscale) filterStr += " grayscale(100%)";
		ctx.filter = filterStr;
		ctx.drawImage(img, drawX, drawY, renderW, renderH);
		// Soft Beauty Layer (Soft-Light pass)
		const effSmooth = autoBeauty ? Math.max(skinSmooth, 16) : skinSmooth;
		const effGlow = autoBeauty ? Math.max(faceGlow, 20) : faceGlow;
		if (effSmooth > 0 || effGlow > 0) {
			ctx.save();
			ctx.globalCompositeOperation = "soft-light";
			ctx.globalAlpha = Math.min(.65, effSmooth * .012 + effGlow * .01);
			ctx.filter = `blur(${Math.max(2, effSmooth / 8)}px) brightness(120%)`;
			ctx.drawImage(img, drawX, drawY, renderW, renderH);
			ctx.restore();
		}
		// Warmth & Tint
		if (warmth !== 0 && !isGrayscale) {
			ctx.save();
			ctx.globalCompositeOperation = "color";
			ctx.fillStyle = warmth > 0 ? `rgba(255, 175, 75, ${Math.min(.35, warmth / 100 * .4)})` : `rgba(80, 165, 255, ${Math.min(.35, Math.abs(warmth) / 100 * .4)})`;
			ctx.fillRect(drawX, drawY, renderW, renderH);
			ctx.restore();
		}
		if (tint !== 0 && !isGrayscale) {
			ctx.save();
			ctx.globalCompositeOperation = "color";
			ctx.fillStyle = tint > 0 ? `rgba(255, 60, 180, ${Math.min(.25, tint / 100 * .3)})` : `rgba(60, 220, 100, ${Math.min(.25, Math.abs(tint) / 100 * .3)})`;
			ctx.fillRect(drawX, drawY, renderW, renderH);
			ctx.restore();
		}
		ctx.restore();
		// -------------------------------------------------------------
		// OVERLAYS: Pen Tool Path / Crop Box
		// -------------------------------------------------------------
		// Pen Tool Path
		if (activeTool === "pen_tool" && penPoints.length > 0) {
			ctx.save();
			ctx.translate(canvas.width / 2 + canvasPan.x, canvas.height / 2 + canvasPan.y);
			ctx.scale(canvasZoom, canvasZoom);
			ctx.beginPath();
			const firstX = drawX + penPoints[0].x * renderW;
			const firstY = drawY + penPoints[0].y * renderH;
			ctx.moveTo(firstX, firstY);
			for (let i = 1; i < penPoints.length; i++) {
				const px = drawX + penPoints[i].x * renderW;
				const py = drawY + penPoints[i].y * renderH;
				ctx.lineTo(px, py);
			}
			if (isPathClosed) {
				ctx.closePath();
				ctx.fillStyle = "rgba(14, 165, 233, 0.25)";
				ctx.fill();
			}
			ctx.strokeStyle = isPathClosed ? "#10b981" : "#38bdf8";
			ctx.lineWidth = 2 / canvasZoom;
			ctx.setLineDash(isPathClosed ? [] : [4, 4]);
			ctx.stroke();
			// Points
			penPoints.forEach((pt, idx) => {
				const px = drawX + pt.x * renderW;
				const py = drawY + pt.y * renderH;
				const isFirst = idx === 0;
				ctx.beginPath();
				ctx.arc(px, py, (isFirst ? 7 : 5) / canvasZoom, 0, Math.PI * 2);
				ctx.fillStyle = isFirst ? isNearStartPoint ? "#22c55e" : "#eab308" : "#38bdf8";
				ctx.strokeStyle = "#0f172a";
				ctx.lineWidth = 2 / canvasZoom;
				ctx.fill();
				ctx.stroke();
			});
			ctx.restore();
		}
		// Crop Tool Box Overlay
		if (activeTool === "crop" && cropBox) {
			ctx.save();
			// Dim outer area
			ctx.fillStyle = "rgba(0, 0, 0, 0.6)";
			ctx.fillRect(0, 0, canvas.width, cropBox.y);
			ctx.fillRect(0, cropBox.y + cropBox.h, canvas.width, canvas.height - (cropBox.y + cropBox.h));
			ctx.fillRect(0, cropBox.y, cropBox.x, cropBox.h);
			ctx.fillRect(cropBox.x + cropBox.w, cropBox.y, canvas.width - (cropBox.x + cropBox.w), cropBox.h);
			// Crop border
			ctx.strokeStyle = "#38bdf8";
			ctx.lineWidth = 2;
			ctx.strokeRect(cropBox.x, cropBox.y, cropBox.w, cropBox.h);
			// Rule of thirds lines
			ctx.strokeStyle = "rgba(255, 255, 255, 0.3)";
			ctx.lineWidth = 1;
			ctx.beginPath();
			ctx.moveTo(cropBox.x + cropBox.w / 3, cropBox.y);
			ctx.lineTo(cropBox.x + cropBox.w / 3, cropBox.y + cropBox.h);
			ctx.moveTo(cropBox.x + cropBox.w * 2 / 3, cropBox.y);
			ctx.lineTo(cropBox.x + cropBox.w * 2 / 3, cropBox.y + cropBox.h);
			ctx.moveTo(cropBox.x, cropBox.y + cropBox.h / 3);
			ctx.lineTo(cropBox.x + cropBox.w, cropBox.y + cropBox.h / 3);
			ctx.moveTo(cropBox.x, cropBox.y + cropBox.h * 2 / 3);
			ctx.lineTo(cropBox.x + cropBox.w, cropBox.y + cropBox.h * 2 / 3);
			ctx.stroke();
			ctx.restore();
		}
	};
	// Convert Editor Canvas Click to Image Coordinates
	const canvasToImageCoords = (clientX, clientY) => {
		const canvas = editorCanvasRef.current;
		const img = photoImgRef.current;
		if (!canvas || !img) return null;
		const rect = canvas.getBoundingClientRect();
		const scaleX = canvas.width / rect.width;
		const scaleY = canvas.height / rect.height;
		const clickX = (clientX - rect.left) * scaleX;
		const clickY = (clientY - rect.top) * scaleY;
		// Reverse Pan & Zoom
		const localX = (clickX - (canvas.width / 2 + canvasPan.x)) / canvasZoom;
		const localY = (clickY - (canvas.height / 2 + canvasPan.y)) / canvasZoom;
		const aspect = img.width / img.height;
		let renderW = 460;
		let renderH = 460 / aspect;
		if (renderH > 560) {
			renderH = 560;
			renderW = 560 * aspect;
		}
		const drawX = -renderW / 2;
		const drawY = -renderH / 2;
		const normX = (localX - drawX) / renderW;
		const normY = (localY - drawY) / renderH;
		const imgX = normX * img.width;
		const imgY = normY * img.height;
		return {
			normX,
			normY,
			imgX,
			imgY,
			isInside: normX >= 0 && normX <= 1 && normY >= 0 && normY <= 1
		};
	};
	// Canvas Mouse Down
	const handleEditorMouseDown = (e) => {
		if (isSpacePressed || activeTool === "hand" || e.button === 1) {
			setIsPanning(true);
			setPanStart({
				x: e.clientX - canvasPan.x,
				y: e.clientY - canvasPan.y
			});
			return;
		}
		const coords = canvasToImageCoords(e.clientX, e.clientY);
		if (!coords || !coords.isInside) return;
		// Tool actions
		if (activeTool === "magic_wand") {
			executeMagicWandCut(coords.imgX, coords.imgY);
		} else if (activeTool === "pen_tool") {
			if (penPoints.length >= 3 && !isPathClosed) {
				const first = penPoints[0];
				const dist = Math.hypot(coords.normX - first.x, coords.normY - first.y);
				if (dist < .05) {
					setIsPathClosed(true);
					return;
				}
			}
			if (!isPathClosed) {
				setPenPoints((prev) => [...prev, {
					x: coords.normX,
					y: coords.normY
				}]);
			}
		} else if (activeTool === "blemish_brush") {
			applyHealingBrush(coords.imgX, coords.imgY, "blemish");
		} else if (activeTool === "beauty_brush") {
			applyHealingBrush(coords.imgX, coords.imgY, "beauty");
		} else if (activeTool === "eye_brighten") {
			applyHealingBrush(coords.imgX, coords.imgY, "eye");
		} else if (activeTool === "zoom") {
			if (e.altKey) {
				setCanvasZoom((prev) => Math.max(.4, prev - .3));
			} else {
				setCanvasZoom((prev) => Math.min(4, prev + .3));
			}
		}
	};
	// Canvas Mouse Move
	const handleEditorMouseMove = (e) => {
		if (isPanning) {
			setCanvasPan({
				x: e.clientX - panStart.x,
				y: e.clientY - panStart.y
			});
			return;
		}
		if (activeTool === "pen_tool" && penPoints.length >= 3 && !isPathClosed) {
			const coords = canvasToImageCoords(e.clientX, e.clientY);
			if (coords) {
				const first = penPoints[0];
				const dist = Math.hypot(coords.normX - first.x, coords.normY - first.y);
				setIsNearStartPoint(dist < .05);
			}
		}
	};
	// Canvas Mouse Up
	const handleEditorMouseUp = () => {
		setIsPanning(false);
	};
	// Canvas Mouse Wheel (Centered Zoom)
	const handleEditorWheel = (e) => {
		e.preventDefault();
		const zoomFactor = e.deltaY < 0 ? 1.15 : .88;
		setCanvasZoom((prev) => Math.max(.4, Math.min(4, prev * zoomFactor)));
	};
	// -------------------------------------------------------------
	// MINI PREVIEW CANVAS RENDER ("preview mini dikhna chaiye")
	// -------------------------------------------------------------
	const renderMiniPreview = () => {
		const canvas = miniPreviewCanvasRef.current;
		const img = photoImgRef.current;
		if (!canvas) return;
		const ctx = canvas.getContext("2d");
		if (!ctx) return;
		canvas.width = 240;
		canvas.height = 160;
		// Pure white photo paper
		ctx.fillStyle = "#ffffff";
		ctx.fillRect(0, 0, canvas.width, canvas.height);
		if (!img) {
			ctx.fillStyle = "#94a3b8";
			ctx.font = "10px sans-serif";
			ctx.textAlign = "center";
			ctx.fillText("Mini Sheet Preview", canvas.width / 2, canvas.height / 2);
			return;
		}
		// Draw miniature grid (4x6 landscape 8 copies or A4)
		const isA4 = paperFormat.startsWith("a4");
		const cols = paperFormat === "4x6_landscape" ? 4 : isA4 ? copies === 32 ? 8 : 4 : 2;
		const rows = paperFormat === "4x6_landscape" ? 2 : isA4 ? 4 : 4;
		const gap = 4;
		const margin = 8;
		const cellW = (canvas.width - margin * 2 - (cols - 1) * gap) / cols;
		const cellH = cellW * (45 / 35);
		let count = 0;
		for (let r = 0; r < rows; r++) {
			for (let c = 0; c < cols; c++) {
				if (count >= copies) break;
				const x = margin + c * (cellW + gap);
				const y = margin + r * (cellH + gap);
				// Fill background
				ctx.fillStyle = bgColor;
				ctx.fillRect(x, y, cellW, cellH);
				// Draw photo
				ctx.drawImage(img, x, y, cellW, cellH);
				// Cut mark
				ctx.strokeStyle = "#94a3b8";
				ctx.lineWidth = .5;
				ctx.strokeRect(x, y, cellW, cellH);
				count++;
			}
		}
	};
	// -------------------------------------------------------------
	// FULL SHEET 300 DPI RENDER (For Direct Printing & PDF / JPG Export)
	// -------------------------------------------------------------
	const renderFullSheet = () => {
		const canvas = fullSheetCanvasRef.current;
		const img = photoImgRef.current;
		if (!canvas || !img) return;
		const ctx = canvas.getContext("2d");
		if (!ctx) return;
		canvas.width = SHEET_WIDTH;
		canvas.height = SHEET_HEIGHT;
		ctx.fillStyle = "#ffffff";
		ctx.fillRect(0, 0, SHEET_WIDTH, SHEET_HEIGHT);
		// Single photo canvas at 300 DPI
		const singleW = 350;
		const singleH = 450;
		const singleCanvas = document.createElement("canvas");
		singleCanvas.width = singleW;
		singleCanvas.height = singleH;
		const sCtx = singleCanvas.getContext("2d");
		if (sCtx) {
			sCtx.fillStyle = bgColor;
			sCtx.fillRect(0, 0, singleW, singleH);
			// Color filters
			const effBrightness = 100 + brightness + (autoBeauty ? 6 : 0) + faceGlow * .12;
			const effContrast = 100 + contrast + (autoBeauty ? 4 : 0);
			const effSaturation = isGrayscale ? 0 : 100 + saturation + (autoBeauty ? 8 : 0);
			let filterStr = `brightness(${effBrightness}%) contrast(${effContrast}%) saturate(${effSaturation}%)`;
			if (isGrayscale) filterStr += " grayscale(100%)";
			sCtx.filter = filterStr;
			const aspect = img.width / img.height;
			let dw = singleW;
			let dh = singleH;
			if (aspect > singleW / singleH) {
				dw = singleH * aspect;
			} else {
				dh = singleW / aspect;
			}
			sCtx.drawImage(img, (singleW - dw) / 2, (singleH - dh) / 2, dw, dh);
			// Soft light beauty pass
			const effSmooth = autoBeauty ? Math.max(skinSmooth, 16) : skinSmooth;
			const effGlow = autoBeauty ? Math.max(faceGlow, 20) : faceGlow;
			if (effSmooth > 0 || effGlow > 0) {
				sCtx.save();
				sCtx.globalCompositeOperation = "soft-light";
				sCtx.globalAlpha = Math.min(.65, effSmooth * .012 + effGlow * .01);
				sCtx.filter = `blur(${Math.max(2, effSmooth / 8)}px) brightness(120%)`;
				sCtx.drawImage(img, (singleW - dw) / 2, (singleH - dw) / 2, dw, dh);
				sCtx.restore();
			}
			// Candidate Name & Date Strip
			if (showNameDate) {
				const boxH = 58;
				sCtx.fillStyle = "#ffffff";
				sCtx.fillRect(0, singleH - boxH, singleW, boxH);
				sCtx.fillStyle = "#000000";
				sCtx.font = "bold 17px sans-serif";
				sCtx.textAlign = "center";
				sCtx.fillText(candidateName.toUpperCase(), singleW / 2, singleH - boxH + 22);
				sCtx.font = "bold 14px sans-serif";
				sCtx.fillText(`DATE: ${photoDate}`, singleW / 2, singleH - boxH + 45);
				sCtx.strokeStyle = "#000000";
				sCtx.lineWidth = 2;
				sCtx.beginPath();
				sCtx.moveTo(0, singleH - boxH);
				sCtx.lineTo(singleW, singleH - boxH);
				sCtx.stroke();
			}
			sCtx.strokeStyle = "#334155";
			sCtx.lineWidth = 2;
			sCtx.strokeRect(0, 0, singleW, singleH);
		}
		// Grid placement
		const cols = paperFormat === "4x6_landscape" ? 4 : paperFormat === "a4_landscape" ? copies === 32 ? 8 : 4 : 2;
		const rows = paperFormat === "4x6_landscape" ? 2 : 4;
		const isA4 = paperFormat.startsWith("a4");
		const marginX = isA4 ? 90 : 60;
		const marginY = isA4 ? 80 : 50;
		const availableW = SHEET_WIDTH - marginX * 2;
		const availableH = SHEET_HEIGHT - marginY * 2;
		const gap = isA4 ? 20 : 16;
		const targetW = (availableW - (cols - 1) * gap) / cols;
		let drawW = targetW;
		let drawH = targetW * (45 / 35);
		if (rows * drawH + (rows - 1) * gap > availableH) {
			drawH = (availableH - (rows - 1) * gap) / rows;
			drawW = drawH * (35 / 45);
		}
		const gapX = cols > 1 ? (availableW - cols * drawW) / (cols - 1) : 0;
		const gapY = rows > 1 ? (availableH - rows * drawH) / (rows - 1) : 0;
		let count = 0;
		for (let r = 0; r < rows; r++) {
			for (let c = 0; c < cols; c++) {
				if (count >= copies) break;
				const x = marginX + c * (drawW + gapX);
				const y = marginY + r * (drawH + gapY);
				ctx.drawImage(singleCanvas, x, y, drawW, drawH);
				ctx.strokeStyle = "#64748b";
				ctx.lineWidth = 1;
				ctx.strokeRect(x, y, drawW, drawH);
				count++;
			}
		}
		// Center cutting line
		ctx.save();
		ctx.strokeStyle = "#94a3b8";
		ctx.lineWidth = 1.5;
		ctx.setLineDash([6, 6]);
		ctx.beginPath();
		ctx.moveTo(30, SHEET_HEIGHT / 2);
		ctx.lineTo(SHEET_WIDTH - 30, SHEET_HEIGHT / 2);
		ctx.stroke();
		ctx.restore();
	};
	// Upload handler
	const handleUpload = (e) => {
		const file = e.target.files?.[0];
		if (!file) return;
		const reader = new FileReader();
		reader.onload = (event) => {
			const src = event.target?.result;
			setPhotoSrc(src);
			setOriginalPhotoSrc(src);
			setHistoryStack([src]);
			setHistoryIndex(0);
			setCanvasZoom(1);
			setCanvasPan({
				x: 0,
				y: 0
			});
			setPenPoints([]);
			setIsPathClosed(false);
			setAutoBeauty(true);
			setActivePreset("auto_beauty");
		};
		reader.readAsDataURL(file);
		e.target.value = "";
	};
	// Direct In-App Print
	const handleDirectPrint = () => {
		const canvas = fullSheetCanvasRef.current;
		if (!canvas) return;
		try {
			const dataUrl = canvas.toDataURL("image/jpeg", 1);
			printImageSheet(dataUrl, {
				paperFormat,
				title: `Passport_${paperFormat}_${copies}Copies`,
				copiesCount: copies
			});
			setPrintAlert(`🖨️ Print command sent to printer! (${paperFormat.replace("_", " ").toUpperCase()} • ${copies} Copies)`);
			setTimeout(() => setPrintAlert(null), 4e3);
		} catch (e) {
			console.error(e);
			window.print();
		}
	};
	// Download PDF
	const handleDownloadSheetPDF = () => {
		const canvas = fullSheetCanvasRef.current;
		if (!canvas) return;
		try {
			const dataUrl = canvas.toDataURL("image/jpeg", .98);
			const isLandscape = paperFormat.includes("landscape");
			const isA4 = paperFormat.startsWith("a4");
			const pdf = new jsPDF({
				orientation: isLandscape ? "landscape" : "portrait",
				unit: isA4 ? "mm" : "in",
				format: isA4 ? "a4" : [4, 6]
			});
			if (isA4) {
				pdf.addImage(dataUrl, "JPEG", 0, 0, isLandscape ? 297 : 210, isLandscape ? 210 : 297);
			} else {
				pdf.addImage(dataUrl, "JPEG", 0, 0, isLandscape ? 6 : 4, isLandscape ? 4 : 6);
			}
			const fileName = `Passport_${paperFormat}_${copies}_Copies_${Date.now()}.pdf`;
			pdf.save(fileName);
			addDownloadRecord({
				id: `pass-pdf-${Date.now()}`,
				title: fileName,
				type: "Passport Sheet PDF",
				size: `${paperFormat.replace("_", " ")} (${copies} Copies)`,
				timestamp: new Date().toLocaleTimeString("en-IN")
			});
		} catch (e) {
			console.error(e);
		}
	};
	// Download HD JPG
	const handleDownloadSheetJPG = () => {
		const canvas = fullSheetCanvasRef.current;
		if (!canvas) return;
		try {
			const dataUrl = canvas.toDataURL("image/jpeg", .98);
			const a = document.createElement("a");
			a.href = dataUrl;
			const fileName = `Passport_${paperFormat}_${copies}_Copies_300DPI_${Date.now()}.jpg`;
			a.download = fileName;
			a.click();
			addDownloadRecord({
				id: `pass-jpg-${Date.now()}`,
				title: fileName,
				type: "Passport Sheet JPG",
				size: `${paperFormat.replace("_", " ")} (${copies} Copies 300 DPI)`,
				timestamp: new Date().toLocaleTimeString("en-IN")
			});
		} catch (e) {
			console.error(e);
		}
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "space-y-3 select-none",
		children: [
			/* @__PURE__ */ _jsxDEV("canvas", {
				ref: fullSheetCanvasRef,
				className: "hidden"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 1487,
				columnNumber: 7
			}, this),
			printAlert && /* @__PURE__ */ _jsxDEV("div", {
				className: "p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs flex items-center justify-between animate-in fade-in",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ _jsxDEV(CheckCircle2, { className: "w-4 h-4 text-emerald-400 flex-shrink-0" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 1493,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: printAlert }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 1494,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 1492,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					onClick: () => setPrintAlert(null),
					className: "text-emerald-400 hover:text-white",
					children: "✕"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 1496,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 1491,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "bg-slate-900 border border-slate-800 rounded-2xl px-4 py-2.5 flex items-center justify-between gap-3 shadow-md flex-wrap text-xs",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-3 flex-wrap",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2 pr-3 border-r border-slate-800",
							children: /* @__PURE__ */ _jsxDEV("span", {
								className: "font-extrabold text-white text-sm flex items-center gap-1.5",
								children: [
									activeTool === "select" && /* @__PURE__ */ _jsxDEV("span", { children: "↖️ Pointer (V)" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1506,
										columnNumber: 43
									}, this),
									activeTool === "magic_wand" && /* @__PURE__ */ _jsxDEV("span", { children: "🪄 Magic Wand Cut (W)" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1507,
										columnNumber: 47
									}, this),
									activeTool === "pen_tool" && /* @__PURE__ */ _jsxDEV("span", { children: "🖊️ Pen Tool (P)" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1508,
										columnNumber: 45
									}, this),
									activeTool === "crop" && /* @__PURE__ */ _jsxDEV("span", { children: "✂️ Passport Crop (C)" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1509,
										columnNumber: 41
									}, this),
									activeTool === "blemish_brush" && /* @__PURE__ */ _jsxDEV("span", { children: "🩹 Spot Healing (B)" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1510,
										columnNumber: 50
									}, this),
									activeTool === "beauty_brush" && /* @__PURE__ */ _jsxDEV("span", { children: "✨ Beauty Airbrush (S)" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1511,
										columnNumber: 49
									}, this),
									activeTool === "eye_brighten" && /* @__PURE__ */ _jsxDEV("span", { children: "👁️ Eye/Teeth Brighten (E)" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1512,
										columnNumber: 49
									}, this),
									activeTool === "hand" && /* @__PURE__ */ _jsxDEV("span", { children: "✋ Hand Pan (H)" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1513,
										columnNumber: 41
									}, this),
									activeTool === "zoom" && /* @__PURE__ */ _jsxDEV("span", { children: "🔍 Zoom (Z)" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1514,
										columnNumber: 41
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1505,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1504,
							columnNumber: 11
						}, this),
						activeTool === "magic_wand" && /* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2 animate-in fade-in",
							children: [
								/* @__PURE__ */ _jsxDEV("span", {
									className: "text-slate-400",
									children: "Tolerance:"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1521,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("input", {
									type: "range",
									min: "10",
									max: "65",
									value: magicTolerance,
									onChange: (e) => setMagicTolerance(Number(e.target.value)),
									className: "w-20 accent-sky-400 cursor-pointer",
									title: "Color similarity distance (10-65)"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1522,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									className: "font-mono text-white font-bold",
									children: magicTolerance
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1531,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: handleAutoBackgroundErase,
									disabled: isProcessing || !photoSrc,
									className: "ml-2 flex items-center gap-1 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold px-3 py-1 rounded-lg shadow-sm",
									title: "1-Click Auto Erases borders inwards",
									children: [/* @__PURE__ */ _jsxDEV(Sparkles, { className: "w-3.5 h-3.5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1539,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "1-Click Auto Cut" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1540,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1533,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1520,
							columnNumber: 13
						}, this),
						activeTool === "pen_tool" && /* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2 animate-in fade-in",
							children: [
								/* @__PURE__ */ _jsxDEV("span", {
									className: "text-slate-400 font-mono text-[11px]",
									children: [
										penPoints.length,
										" Points ",
										isPathClosed ? "• Path Closed" : ""
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1548,
									columnNumber: 15
								}, this),
								!isPathClosed && penPoints.length >= 3 && /* @__PURE__ */ _jsxDEV("button", {
									onClick: () => setIsPathClosed(true),
									className: "px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg",
									children: "Close Path"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1553,
									columnNumber: 17
								}, this),
								penPoints.length >= 3 && /* @__PURE__ */ _jsxDEV("button", {
									onClick: handleApplyPenCutout,
									className: "flex items-center gap-1 px-3 py-1 bg-gradient-to-r from-emerald-600 to-teal-600 text-white font-bold rounded-lg shadow-md",
									children: [/* @__PURE__ */ _jsxDEV(Check, { className: "w-3.5 h-3.5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1566,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Apply Cutout" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1567,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1562,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => {
										setPenPoints([]);
										setIsPathClosed(false);
									},
									className: "px-2 py-1 bg-slate-800 text-rose-300 font-bold rounded-lg hover:bg-rose-900/30",
									children: "Clear"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1571,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1547,
							columnNumber: 13
						}, this),
						activeTool === "crop" && /* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2 animate-in fade-in",
							children: [
								/* @__PURE__ */ _jsxDEV("span", {
									className: "bg-sky-500/20 text-sky-300 px-2 py-0.5 rounded font-mono font-bold",
									children: "Ratio: 35×45mm Standard"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1583,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: handleApplyCrop,
									className: "px-3 py-1 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg shadow",
									children: "Apply Crop"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1586,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => {
										setCropBox(null);
										setActiveTool("select");
									},
									className: "px-2 py-1 bg-slate-800 text-slate-300 font-bold rounded-lg",
									children: "Cancel"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1592,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1582,
							columnNumber: 13
						}, this),
						(activeTool === "blemish_brush" || activeTool === "beauty_brush" || activeTool === "eye_brighten") && /* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2 animate-in fade-in",
							children: [
								/* @__PURE__ */ _jsxDEV("span", {
									className: "text-slate-400",
									children: "Brush Size:"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1604,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("input", {
									type: "range",
									min: "8",
									max: "70",
									value: brushSize,
									onChange: (e) => setBrushSize(Number(e.target.value)),
									className: "w-20 accent-amber-400 cursor-pointer"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1605,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									className: "font-mono text-white font-bold",
									children: [brushSize, "px"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1613,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									className: "text-slate-500 text-[10px]",
									children: "Use [ and ] to resize"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1614,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1603,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-1.5 pl-3 border-l border-slate-800",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-slate-400",
								children: "BG:"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1620,
								columnNumber: 13
							}, this), [
								{
									name: "White",
									color: "#ffffff"
								},
								{
									name: "Sky Blue",
									color: "#cce3f8"
								},
								{
									name: "Studio Blue",
									color: "#2563eb"
								},
								{
									name: "Grey",
									color: "#e2e8f0"
								},
								{
									name: "Red",
									color: "#dc2626"
								}
							].map((c) => /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setBgColor(c.color),
								className: `w-5 h-5 rounded-full border shadow-sm transition-transform ${bgColor === c.color ? "scale-125 ring-2 ring-sky-400 border-white" : "border-slate-500 hover:scale-110"}`,
								style: { backgroundColor: c.color },
								title: `Change studio background to ${c.name}`
							}, c.name, false, {
								fileName: _jsxFileName,
								lineNumber: 1628,
								columnNumber: 15
							}, this))]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1619,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 1503,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center bg-slate-950 border border-slate-800 rounded-lg p-0.5",
							children: [/* @__PURE__ */ _jsxDEV("button", {
								onClick: handleUndo,
								disabled: historyIndex <= 0 && penPoints.length === 0,
								className: "p-1.5 text-slate-300 hover:text-white disabled:opacity-30 disabled:hover:text-slate-300",
								title: "Undo (Ctrl + Z)",
								children: /* @__PURE__ */ _jsxDEV(Undo2, { className: "w-3.5 h-3.5" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1651,
									columnNumber: 15
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1645,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: handleRedo,
								disabled: historyIndex >= historyStack.length - 1,
								className: "p-1.5 text-slate-300 hover:text-white disabled:opacity-30 disabled:hover:text-slate-300",
								title: "Redo (Ctrl + Y)",
								children: /* @__PURE__ */ _jsxDEV(Redo2, { className: "w-3.5 h-3.5" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1659,
									columnNumber: 15
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1653,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1644,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setShowMiniPreview((prev) => !prev),
							className: `flex items-center gap-1 px-2.5 py-1.5 rounded-lg border font-bold text-xs transition-colors ${showMiniPreview ? "bg-sky-600/20 text-sky-300 border-sky-500/40" : "bg-slate-800 text-slate-400 border-slate-700"}`,
							title: "Toggle Mini Sheet Preview (M)",
							children: [/* @__PURE__ */ _jsxDEV(Layers, { className: "w-3.5 h-3.5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1671,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Mini Preview (M)" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1672,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1664,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: handleDirectPrint,
							className: "flex items-center gap-1.5 bg-gradient-to-r from-blue-600 via-indigo-600 to-blue-500 hover:from-blue-500 hover:to-indigo-500 text-white font-extrabold px-3.5 py-1.5 rounded-xl shadow-lg shadow-blue-600/30 transition-all hover:scale-105",
							title: "Direct Print Sheet (Ctrl + P)",
							children: [/* @__PURE__ */ _jsxDEV(Printer, { className: "w-3.5 h-3.5 text-white" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1681,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "🖨️ Print Sheet (Ctrl+P)" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1682,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1676,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 1642,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 1501,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "grid grid-cols-1 lg:grid-cols-12 gap-3 items-start min-h-[640px]",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "lg:col-span-1 bg-slate-900 border border-slate-800 rounded-2xl p-2 flex lg:flex-col items-center justify-center gap-2 shadow-lg",
						children: [
							[
								{
									id: "select",
									label: "Pointer / Move (V)",
									icon: "↖️"
								},
								{
									id: "crop",
									label: "Passport Crop (C)",
									icon: "✂️"
								},
								{
									id: "magic_wand",
									label: "Magic Wand / Cut (W)",
									icon: "🪄"
								},
								{
									id: "pen_tool",
									label: "Pen Tool Cutout (P)",
									icon: "🖊️"
								},
								{
									id: "blemish_brush",
									label: "Spot Healing Brush (B)",
									icon: "🩹"
								},
								{
									id: "beauty_brush",
									label: "Skin Airbrush (S)",
									icon: "✨"
								},
								{
									id: "eye_brighten",
									label: "Eye/Teeth Whitener (E)",
									icon: "👁️"
								},
								{
									id: "hand",
									label: "Hand Tool Pan (H / Space)",
									icon: "✋"
								},
								{
									id: "zoom",
									label: "Zoom Tool (Z)",
									icon: "🔍"
								}
							].map((t) => {
								const isActive = activeTool === t.id;
								return /* @__PURE__ */ _jsxDEV("button", {
									onClick: () => {
										setActiveTool(t.id);
										if (t.id === "crop") initCropBox();
									},
									className: `w-10 h-10 rounded-xl flex items-center justify-center text-lg transition-all ${isActive ? "bg-blue-600 text-white shadow-lg shadow-blue-600/40 ring-2 ring-blue-400 scale-105" : "bg-slate-950 text-slate-300 hover:bg-slate-800 border border-slate-800/80 hover:text-white"}`,
									title: t.label,
									children: /* @__PURE__ */ _jsxDEV("span", { children: t.icon }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1718,
										columnNumber: 17
									}, this)
								}, t.id, false, {
									fileName: _jsxFileName,
									lineNumber: 1705,
									columnNumber: 15
								}, this);
							}),
							/* @__PURE__ */ _jsxDEV("div", { className: "w-8 border-t border-slate-800 my-1 hidden lg:block" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1723,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("label", {
								className: "w-10 h-10 rounded-xl bg-purple-600/20 border border-purple-500/40 text-purple-300 hover:bg-purple-600/30 flex items-center justify-center cursor-pointer transition-colors",
								title: "Upload Customer Photo",
								children: [/* @__PURE__ */ _jsxDEV(Upload, { className: "w-4 h-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1727,
									columnNumber: 13
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "file",
									accept: "image/*",
									onChange: handleUpload,
									className: "hidden"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1728,
									columnNumber: 13
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1726,
								columnNumber: 11
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1690,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: `${showMiniPreview ? "lg:col-span-8" : "lg:col-span-11"} relative bg-slate-950 border border-slate-800 rounded-2xl overflow-hidden shadow-2xl flex flex-col justify-between min-h-[640px]`,
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "absolute top-3 left-3 z-10 flex items-center gap-2 bg-slate-900/85 backdrop-blur-sm border border-slate-800 px-3 py-1.5 rounded-xl text-[11px] text-slate-300 pointer-events-none",
								children: [
									/* @__PURE__ */ _jsxDEV("span", {
										className: "font-bold text-white",
										children: "Photoshop Studio Canvas"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1736,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ _jsxDEV("span", { children: "•" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1737,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "font-mono text-sky-400 font-bold",
										children: [Math.round(canvasZoom * 100), "%"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1738,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ _jsxDEV("span", { children: "•" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1739,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ _jsxDEV("span", { children: "Hold Spacebar + Drag to Pan • Wheel to Zoom" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1740,
										columnNumber: 13
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1735,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex-1 flex items-center justify-center p-2 overflow-hidden",
								children: /* @__PURE__ */ _jsxDEV("canvas", {
									ref: editorCanvasRef,
									onMouseDown: handleEditorMouseDown,
									onMouseMove: handleEditorMouseMove,
									onMouseUp: handleEditorMouseUp,
									onMouseLeave: handleEditorMouseUp,
									onWheel: handleEditorWheel,
									className: `max-w-full max-h-[580px] w-auto h-auto rounded-lg shadow-2xl ${isSpacePressed || activeTool === "hand" ? "cursor-grab active:cursor-grabbing" : activeTool === "magic_wand" || activeTool === "pen_tool" ? "cursor-crosshair" : activeTool === "blemish_brush" || activeTool === "beauty_brush" || activeTool === "eye_brighten" ? "cursor-cell" : "cursor-default"}`
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1745,
									columnNumber: 13
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1744,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "bg-slate-900/80 border-t border-slate-800/80 px-4 py-2 flex items-center justify-between text-xs text-slate-400 flex-wrap gap-2",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-3",
									children: [/* @__PURE__ */ _jsxDEV("span", { children: ["Tool: ", /* @__PURE__ */ _jsxDEV("strong", {
										className: "text-white uppercase",
										children: activeTool.replace("_", " ")
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1767,
										columnNumber: 27
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1767,
										columnNumber: 15
									}, this), photoSrc && /* @__PURE__ */ _jsxDEV("span", {
										className: "text-emerald-400 flex items-center gap-1 font-semibold",
										children: [/* @__PURE__ */ _jsxDEV(Check, { className: "w-3.5 h-3.5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1770,
											columnNumber: 19
										}, this), " High-Resolution Photo Ready"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1769,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1766,
									columnNumber: 13
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-2",
									children: [
										/* @__PURE__ */ _jsxDEV("button", {
											onClick: () => {
												setCanvasZoom(1);
												setCanvasPan({
													x: 0,
													y: 0
												});
											},
											className: "px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-[11px] font-mono",
											children: "Fit Screen (Ctrl+0)"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1776,
											columnNumber: 15
										}, this),
										/* @__PURE__ */ _jsxDEV("button", {
											onClick: () => setCanvasZoom((prev) => Math.min(4, prev + .25)),
											className: "px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-[11px] font-mono",
											children: "+"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1782,
											columnNumber: 15
										}, this),
										/* @__PURE__ */ _jsxDEV("button", {
											onClick: () => setCanvasZoom((prev) => Math.max(.4, prev - .25)),
											className: "px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-[11px] font-mono",
											children: "-"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1788,
											columnNumber: 15
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1775,
									columnNumber: 13
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1765,
								columnNumber: 11
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1733,
						columnNumber: 9
					}, this),
					showMiniPreview && /* @__PURE__ */ _jsxDEV("div", {
						className: "lg:col-span-3 space-y-3",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "bg-slate-900 border border-slate-800 rounded-2xl p-3 shadow-xl space-y-2.5",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center justify-between pb-1.5 border-b border-slate-800",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center gap-1.5",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "font-extrabold text-white text-xs",
												children: "Mini Sheet Preview"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1805,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("span", {
												className: "text-[10px] font-mono bg-blue-500/20 text-blue-300 px-1.5 py-0.5 rounded font-bold",
												children: paperFormat === "4x6_landscape" ? "4×6 (8)" : "A4"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1806,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1804,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("button", {
											onClick: () => setShowMiniPreview(false),
											className: "p-1 text-slate-500 hover:text-white rounded",
											title: "Hide Mini Preview (M)",
											children: /* @__PURE__ */ _jsxDEV(Minimize2, { className: "w-3.5 h-3.5" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1815,
												columnNumber: 19
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1810,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1803,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "relative flex justify-center bg-slate-950 p-2 rounded-xl border border-slate-800 overflow-hidden shadow-inner",
										children: /* @__PURE__ */ _jsxDEV("canvas", {
											ref: miniPreviewCanvasRef,
											width: 240,
											height: 160,
											className: "w-full h-auto bg-white rounded shadow-md border border-slate-700 pointer-events-none"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1821,
											columnNumber: 17
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1820,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "grid grid-cols-2 gap-1.5",
										children: [/* @__PURE__ */ _jsxDEV("button", {
											onClick: () => {
												setPaperFormat("4x6_landscape");
												setCopies(8);
											},
											className: `py-1.5 px-2 rounded-lg text-xs font-bold transition-all text-center ${paperFormat === "4x6_landscape" ? "bg-blue-600 text-white shadow" : "bg-slate-950 text-slate-400 hover:text-white"}`,
											children: "4×6 (8 Copies)"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1831,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("button", {
											onClick: () => {
												setPaperFormat("a4_landscape");
												setCopies(32);
											},
											className: `py-1.5 px-2 rounded-lg text-xs font-bold transition-all text-center ${paperFormat === "a4_landscape" ? "bg-purple-600 text-white shadow" : "bg-slate-950 text-slate-400 hover:text-white"}`,
											children: "A4 Landscape"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1841,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1830,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										onClick: handleDirectPrint,
										className: "w-full flex items-center justify-center gap-1.5 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-extrabold text-xs py-2 rounded-xl shadow-md transition-all active:scale-95",
										children: [/* @__PURE__ */ _jsxDEV(Printer, { className: "w-3.5 h-3.5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1858,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: "🖨️ Print Sheet Now" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1859,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1854,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1802,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "bg-slate-900 border border-slate-800 rounded-2xl p-3.5 shadow-md space-y-2.5",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5",
										children: [/* @__PURE__ */ _jsxDEV(Sparkles, { className: "w-3.5 h-3.5 text-amber-400" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1867,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Auto Beauty Presets" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1868,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1866,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-[10px] text-amber-400 font-bold bg-amber-500/10 px-1.5 py-0.5 rounded",
										children: "1-Click"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1870,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1865,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-2 gap-1.5",
									children: BEAUTY_PRESETS.map((p) => {
										const isSelected = activePreset === p.id && autoBeauty;
										return /* @__PURE__ */ _jsxDEV("button", {
											onClick: () => {
												setActivePreset(p.id);
												setBrightness(p.settings.brightness);
												setContrast(p.settings.contrast);
												setSaturation(p.settings.saturation);
												setWarmth(p.settings.warmth);
												setTint(p.settings.tint);
												setSkinSmooth(p.settings.skinSmooth);
												setFaceGlow(p.settings.faceGlow);
												setShadowLift(p.settings.shadowLift);
												setIsGrayscale(p.settings.isGrayscale);
												setAutoBeauty(true);
											},
											className: `p-2 rounded-xl text-left border transition-all ${isSelected ? "bg-amber-500/10 border-amber-500/60 text-white ring-1 ring-amber-500/30" : "bg-slate-950 border-slate-800/80 text-slate-300 hover:bg-slate-800"}`,
											children: /* @__PURE__ */ _jsxDEV("div", {
												className: "text-xs font-bold truncate flex items-center gap-1",
												children: [/* @__PURE__ */ _jsxDEV("span", { children: p.icon }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1901,
													columnNumber: 25
												}, this), /* @__PURE__ */ _jsxDEV("span", {
													className: "truncate",
													children: p.name
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1902,
													columnNumber: 25
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1900,
												columnNumber: 23
											}, this)
										}, p.id, false, {
											fileName: _jsxFileName,
											lineNumber: 1879,
											columnNumber: 21
										}, this);
									})
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1875,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1864,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "bg-slate-900 border border-slate-800 rounded-2xl p-3.5 shadow-md space-y-3 text-xs",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center justify-between pb-1 border-b border-slate-800",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "font-bold text-white uppercase tracking-wider flex items-center gap-1.5",
											children: [/* @__PURE__ */ _jsxDEV(Sliders, { className: "w-3.5 h-3.5 text-blue-400" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1914,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Color Grading & Skin" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1915,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1913,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("button", {
											onClick: () => {
												setBrightness(0);
												setContrast(0);
												setSaturation(0);
												setWarmth(0);
												setTint(0);
												setSkinSmooth(0);
												setFaceGlow(0);
												setIsGrayscale(false);
											},
											className: "text-[10px] text-slate-400 hover:text-white",
											children: "Reset"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1917,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1912,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex justify-between text-slate-400 mb-0.5",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "text-amber-300 font-semibold",
											children: "Skin Smoothing"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1937,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "font-mono text-white",
											children: [skinSmooth, "%"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1938,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1936,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "range",
										min: "0",
										max: "50",
										value: skinSmooth,
										onChange: (e) => setSkinSmooth(Number(e.target.value)),
										className: "w-full accent-amber-500 cursor-pointer h-1.5 bg-slate-800 rounded"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1940,
										columnNumber: 17
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1935,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex justify-between text-slate-400 mb-0.5",
										children: [/* @__PURE__ */ _jsxDEV("span", { children: "Brightness" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1953,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "font-mono text-white",
											children: [brightness > 0 ? `+${brightness}` : brightness, "%"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1954,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1952,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "range",
										min: "-30",
										max: "30",
										value: brightness,
										onChange: (e) => setBrightness(Number(e.target.value)),
										className: "w-full accent-blue-500 cursor-pointer h-1.5 bg-slate-800 rounded"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1956,
										columnNumber: 17
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1951,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex justify-between text-slate-400 mb-0.5",
										children: [/* @__PURE__ */ _jsxDEV("span", { children: "Contrast" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1969,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "font-mono text-white",
											children: [contrast > 0 ? `+${contrast}` : contrast, "%"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1970,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1968,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "range",
										min: "-30",
										max: "30",
										value: contrast,
										onChange: (e) => setContrast(Number(e.target.value)),
										className: "w-full accent-blue-500 cursor-pointer h-1.5 bg-slate-800 rounded"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1972,
										columnNumber: 17
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1967,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex justify-between text-slate-400 mb-0.5",
										children: [/* @__PURE__ */ _jsxDEV("span", { children: "Warmth / Tone" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1985,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "font-mono text-white",
											children: warmth > 0 ? `+${warmth}` : warmth
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1986,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1984,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "range",
										min: "-30",
										max: "30",
										value: warmth,
										onChange: (e) => setWarmth(Number(e.target.value)),
										className: "w-full accent-orange-500 cursor-pointer h-1.5 bg-slate-800 rounded"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1988,
										columnNumber: 17
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1983,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "pt-2 border-t border-slate-800",
										children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "flex items-center justify-between cursor-pointer",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "font-bold text-slate-300",
												children: "Exam Name & Date Strip"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2001,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("input", {
												type: "checkbox",
												checked: showNameDate,
												onChange: (e) => setShowNameDate(e.target.checked),
												className: "accent-blue-500 rounded"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2002,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 2e3,
											columnNumber: 17
										}, this), showNameDate && /* @__PURE__ */ _jsxDEV("div", {
											className: "mt-2 space-y-1.5",
											children: [/* @__PURE__ */ _jsxDEV("input", {
												type: "text",
												placeholder: "Candidate Name",
												value: candidateName,
												onChange: (e) => setCandidateName(e.target.value),
												className: "w-full bg-slate-950 border border-slate-700 rounded px-2 py-1 text-white text-[11px] font-bold"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2011,
												columnNumber: 21
											}, this), /* @__PURE__ */ _jsxDEV("input", {
												type: "text",
												placeholder: "Date (DD/MM/YYYY)",
												value: photoDate,
												onChange: (e) => setPhotoDate(e.target.value),
												className: "w-full bg-slate-950 border border-slate-700 rounded px-2 py-1 text-white text-[11px] font-bold"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2018,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 2010,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1999,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1911,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1800,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 1688,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 1485,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsUUFBUSxpQkFBOEI7QUFDaEUsU0FDRSxRQUNBLFNBRUEsVUFRQSxjQUdBLFNBSUEsT0FHQSxPQUNBLE9BR0EsUUFJQSxpQkFNSztBQUNQLFNBQVMsYUFBYTtBQUN0QixTQUFTLHlCQUF5QjtBQUNsQyxTQUFTLHVCQUF1Qjs7O0FBNEJoQyxNQUFNLGlCQUFpQztDQUNyQztFQUNFLElBQUk7RUFDSixNQUFNO0VBQ04sTUFBTTtFQUNOLE1BQU07RUFDTixVQUFVO0dBQ1IsWUFBWTtHQUNaLFVBQVU7R0FDVixZQUFZO0dBQ1osUUFBUTtHQUNSLE1BQU07R0FDTixZQUFZO0dBQ1osVUFBVTtHQUNWLFlBQVk7R0FDWixhQUFhO0VBQ2Y7Q0FDRjtDQUNBO0VBQ0UsSUFBSTtFQUNKLE1BQU07RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFVBQVU7R0FDUixZQUFZO0dBQ1osVUFBVTtHQUNWLFlBQVk7R0FDWixRQUFRO0dBQ1IsTUFBTTtHQUNOLFlBQVk7R0FDWixVQUFVO0dBQ1YsWUFBWTtHQUNaLGFBQWE7RUFDZjtDQUNGO0NBQ0E7RUFDRSxJQUFJO0VBQ0osTUFBTTtFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sVUFBVTtHQUNSLFlBQVk7R0FDWixVQUFVO0dBQ1YsWUFBWTtHQUNaLFFBQVE7R0FDUixNQUFNO0dBQ04sWUFBWTtHQUNaLFVBQVU7R0FDVixZQUFZO0dBQ1osYUFBYTtFQUNmO0NBQ0Y7Q0FDQTtFQUNFLElBQUk7RUFDSixNQUFNO0VBQ04sTUFBTTtFQUNOLE1BQU07RUFDTixVQUFVO0dBQ1IsWUFBWTtHQUNaLFVBQVU7R0FDVixZQUFZO0dBQ1osUUFBUTtHQUNSLE1BQU07R0FDTixZQUFZO0dBQ1osVUFBVTtHQUNWLFlBQVk7R0FDWixhQUFhO0VBQ2Y7Q0FDRjtDQUNBO0VBQ0UsSUFBSTtFQUNKLE1BQU07RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFVBQVU7R0FDUixZQUFZO0dBQ1osVUFBVTtHQUNWLFlBQVk7R0FDWixRQUFRLENBQUM7R0FDVCxNQUFNLENBQUM7R0FDUCxZQUFZO0dBQ1osVUFBVTtHQUNWLFlBQVk7R0FDWixhQUFhO0VBQ2Y7Q0FDRjtDQUNBO0VBQ0UsSUFBSTtFQUNKLE1BQU07RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFVBQVU7R0FDUixZQUFZO0dBQ1osVUFBVTtHQUNWLFlBQVk7R0FDWixRQUFRO0dBQ1IsTUFBTTtHQUNOLFlBQVk7R0FDWixVQUFVO0dBQ1YsWUFBWTtHQUNaLGFBQWE7RUFDZjtDQUNGO0FBQ0Y7QUFFQSxPQUFPLE1BQU0sMkJBQXFDOztDQUVoRCxNQUFNLHFCQUFxQixPQUFpQyxJQUFJOztDQUdoRSxNQUFNLGtCQUFrQixPQUFpQyxJQUFJOztDQUc3RCxNQUFNLHVCQUF1QixPQUFpQyxJQUFJOztDQUdsRSxNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBcUIsUUFBUTs7Q0FHakUsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUF3QixJQUFJO0NBQzVELE1BQU0sQ0FBQyxrQkFBa0IsdUJBQXVCLFNBQXdCLElBQUk7Q0FDNUUsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQW1CLENBQUMsQ0FBQztDQUM3RCxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBaUIsQ0FBQyxDQUFDO0NBRTNELE1BQU0sY0FBYyxPQUFnQyxJQUFJOztDQUd4RCxNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBc0IsZUFBZTtDQUMzRSxNQUFNLENBQUMsUUFBUSxhQUFhLFNBQWlCLENBQUM7O0NBRzlDLE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBaUIsU0FBUzs7Q0FHeEQsTUFBTSxDQUFDLGlCQUFpQixzQkFBc0IsU0FBa0IsSUFBSTs7Q0FHcEUsTUFBTSxDQUFDLFlBQVksaUJBQWlCLFNBQWtCLElBQUk7Q0FDMUQsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQWlCLGFBQWE7O0NBR3RFLE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUFpQixDQUFDO0NBQ3RELE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBaUIsQ0FBQztDQUNsRCxNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBaUIsRUFBRTtDQUN2RCxNQUFNLENBQUMsUUFBUSxhQUFhLFNBQWlCLENBQUM7Q0FDOUMsTUFBTSxDQUFDLE1BQU0sV0FBVyxTQUFpQixDQUFDO0NBQzFDLE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUFpQixFQUFFO0NBQ3ZELE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUFpQixFQUFFO0NBQ3ZELE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBaUIsRUFBRTtDQUNuRCxNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBa0IsS0FBSzs7Q0FHN0QsTUFBTSxDQUFDLFlBQVksaUJBQWlCLFNBQWlCLENBQUc7Q0FDeEQsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQW1DO0VBQUUsR0FBRztFQUFHLEdBQUc7Q0FBRSxDQUFDO0NBQ25GLE1BQU0sQ0FBQyxnQkFBZ0IscUJBQXFCLFNBQWtCLEtBQUs7Q0FDbkUsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQWtCLEtBQUs7Q0FDekQsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFtQztFQUFFLEdBQUc7RUFBRyxHQUFHO0NBQUUsQ0FBQzs7O0NBSWpGLE1BQU0sQ0FBQyxnQkFBZ0IscUJBQXFCLFNBQWlCLEVBQUU7Q0FDL0QsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQWlCLENBQUM7O0NBRzFELE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFrQixDQUFDLENBQUM7Q0FDdEQsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQWtCLEtBQUs7Q0FDL0QsTUFBTSxDQUFDLGtCQUFrQix1QkFBdUIsU0FBa0IsS0FBSztDQUN2RSxNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBaUIsQ0FBQzs7Q0FHdEQsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQWlCLEVBQUU7Q0FDckQsTUFBTSxDQUFDLFlBQVksaUJBQWlCLFNBQWtCLEtBQUs7O0NBRzNELE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBZ0UsSUFBSTs7Q0FHbEcsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQWtCLEtBQUs7Q0FDL0QsTUFBTSxDQUFDLGVBQWUsb0JBQW9CLFNBQWlCLGdCQUFnQjtDQUMzRSxNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FDaEMsSUFBSSxLQUFLLENBQUMsQ0FBQyxtQkFBbUIsU0FBUztFQUFFLEtBQUs7RUFBVyxPQUFPO0VBQVcsTUFBTTtDQUFVLENBQUMsQ0FDOUY7Q0FFQSxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBa0IsS0FBSztDQUMvRCxNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBd0IsSUFBSTs7Q0FHaEUsSUFBSSxjQUFjO0NBQ2xCLElBQUksZUFBZTtDQUVuQixJQUFJLGdCQUFnQixpQkFBaUI7RUFDbkMsY0FBYztFQUNkLGVBQWU7Q0FDakIsT0FBTyxJQUFJLGdCQUFnQixnQkFBZ0I7RUFDekMsY0FBYztFQUNkLGVBQWU7Q0FDakIsT0FBTyxJQUFJLGdCQUFnQixnQkFBZ0I7RUFDekMsY0FBYztFQUNkLGVBQWU7Q0FDakIsT0FBTztFQUNMLGNBQWM7RUFDZCxlQUFlO0NBQ2pCOzs7O0NBS0EsZ0JBQWdCO0VBQ2QsTUFBTSxpQkFBaUIsTUFBcUI7O0dBRTFDLElBQUssRUFBRSxPQUF1QixZQUFZLFdBQVksRUFBRSxPQUF1QixZQUFZLFlBQVk7SUFDckc7R0FDRjs7R0FHQSxJQUFJLEVBQUUsU0FBUyxXQUFXLENBQUMsRUFBRSxRQUFRO0lBQ25DLGtCQUFrQixJQUFJO0dBQ3hCOztHQUdBLElBQUksRUFBRSxXQUFXLEVBQUUsSUFBSSxZQUFZLE1BQU0sT0FBTyxDQUFDLEVBQUUsVUFBVTtJQUMzRCxFQUFFLGVBQWU7SUFDakIsV0FBVztHQUNiOztHQUdBLElBQUssRUFBRSxXQUFXLEVBQUUsSUFBSSxZQUFZLE1BQU0sT0FBUyxFQUFFLFdBQVcsRUFBRSxZQUFZLEVBQUUsSUFBSSxZQUFZLE1BQU0sS0FBTTtJQUMxRyxFQUFFLGVBQWU7SUFDakIsV0FBVztHQUNiOztHQUdBLElBQUksQ0FBQyxFQUFFLFdBQVcsQ0FBQyxFQUFFLFVBQVUsQ0FBQyxFQUFFLFNBQVM7SUFDekMsUUFBUSxFQUFFLElBQUksWUFBWSxHQUExQjtLQUNFLEtBQUs7TUFBSyxjQUFjLFFBQVE7TUFBRztLQUNuQyxLQUFLO01BQUssY0FBYyxNQUFNO01BQUcsWUFBWTtNQUFHO0tBQ2hELEtBQUs7TUFBSyxjQUFjLFlBQVk7TUFBRztLQUN2QyxLQUFLO01BQUssY0FBYyxVQUFVO01BQUc7S0FDckMsS0FBSztNQUFLLGNBQWMsZUFBZTtNQUFHO0tBQzFDLEtBQUs7TUFBSyxjQUFjLGNBQWM7TUFBRztLQUN6QyxLQUFLO01BQUssY0FBYyxjQUFjO01BQUc7S0FDekMsS0FBSztNQUFLLGNBQWMsTUFBTTtNQUFHO0tBQ2pDLEtBQUs7TUFBSyxjQUFjLE1BQU07TUFBRztLQUNqQyxLQUFLO01BQUssb0JBQW1CLFNBQVEsQ0FBQyxJQUFJO01BQUc7S0FDN0MsS0FBSztNQUFLLGNBQWEsU0FBUSxLQUFLLElBQUksR0FBRyxPQUFPLENBQUMsQ0FBQztNQUFHO0tBQ3ZELEtBQUs7TUFBSyxjQUFhLFNBQVEsS0FBSyxJQUFJLElBQUksT0FBTyxDQUFDLENBQUM7TUFBRztLQUN4RCxLQUFLO01BQ0gsSUFBSSxlQUFlLFlBQVk7T0FDN0IsYUFBYSxDQUFDLENBQUM7T0FDZixnQkFBZ0IsS0FBSztNQUN2QjtNQUNBLElBQUksZUFBZSxRQUFRO09BQ3pCLFdBQVcsSUFBSTtPQUNmLGNBQWMsUUFBUTtNQUN4QjtNQUNBO0lBQ0o7R0FDRjs7R0FHQSxJQUFJLEVBQUUsWUFBWSxFQUFFLFFBQVEsT0FBTyxFQUFFLFFBQVEsTUFBTTtJQUNqRCxFQUFFLGVBQWU7SUFDakIsZUFBYyxTQUFRLEtBQUssSUFBSSxHQUFLLE9BQU8sR0FBSSxDQUFDO0dBQ2xEO0dBQ0EsSUFBSSxFQUFFLFlBQVksRUFBRSxRQUFRLE9BQU8sRUFBRSxRQUFRLE1BQU07SUFDakQsRUFBRSxlQUFlO0lBQ2pCLGVBQWMsU0FBUSxLQUFLLElBQUksSUFBSyxPQUFPLEdBQUksQ0FBQztHQUNsRDtHQUNBLElBQUksRUFBRSxXQUFXLEVBQUUsUUFBUSxLQUFLO0lBQzlCLEVBQUUsZUFBZTtJQUNqQixjQUFjLENBQUc7SUFDakIsYUFBYTtLQUFFLEdBQUc7S0FBRyxHQUFHO0lBQUUsQ0FBQztHQUM3QjtFQUNGO0VBRUEsTUFBTSxlQUFlLE1BQXFCO0dBQ3hDLElBQUksRUFBRSxTQUFTLFNBQVM7SUFDdEIsa0JBQWtCLEtBQUs7SUFDdkIsYUFBYSxLQUFLO0dBQ3BCO0VBQ0Y7RUFFQSxPQUFPLGlCQUFpQixXQUFXLGFBQWE7RUFDaEQsT0FBTyxpQkFBaUIsU0FBUyxXQUFXO0VBQzVDLGFBQWE7R0FDWCxPQUFPLG9CQUFvQixXQUFXLGFBQWE7R0FDbkQsT0FBTyxvQkFBb0IsU0FBUyxXQUFXO0VBQ2pEO0NBQ0YsR0FBRztFQUFDO0VBQVk7RUFBYztDQUFZLENBQUM7O0NBRzNDLE1BQU0saUJBQWlCLFdBQW1CO0VBQ3hDLGlCQUFnQixTQUFRO0dBQ3RCLE1BQU0sY0FBYyxLQUFLLE1BQU0sR0FBRyxlQUFlLENBQUM7R0FDbEQsTUFBTSxVQUFVLENBQUMsR0FBRyxhQUFhLE1BQU07R0FDdkMsSUFBSSxRQUFRLFNBQVMsSUFBSSxRQUFRLE1BQU07R0FDdkMsT0FBTztFQUNULENBQUM7RUFDRCxpQkFBZ0IsU0FBUSxLQUFLLElBQUksSUFBSSxPQUFPLENBQUMsQ0FBQztDQUNoRDtDQUVBLE1BQU0sbUJBQW1CO0VBQ3ZCLElBQUksZUFBZSxjQUFjLFVBQVUsU0FBUyxHQUFHO0dBQ3JELElBQUksY0FBYztJQUNoQixnQkFBZ0IsS0FBSztHQUN2QixPQUFPO0lBQ0wsY0FBYSxTQUFRLEtBQUssTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDO0dBQ3hDO0dBQ0E7RUFDRjtFQUVBLElBQUksZUFBZSxHQUFHO0dBQ3BCLE1BQU0sVUFBVSxlQUFlO0dBQy9CLGdCQUFnQixPQUFPO0dBQ3ZCLFlBQVksYUFBYSxRQUFRO0VBQ25DO0NBQ0Y7Q0FFQSxNQUFNLG1CQUFtQjtFQUN2QixJQUFJLGVBQWUsYUFBYSxTQUFTLEdBQUc7R0FDMUMsTUFBTSxVQUFVLGVBQWU7R0FDL0IsZ0JBQWdCLE9BQU87R0FDdkIsWUFBWSxhQUFhLFFBQVE7RUFDbkM7Q0FDRjs7Q0FHQSxnQkFBZ0I7RUFDZCxJQUFJLFVBQVU7R0FDWixNQUFNLE1BQU0sSUFBSSxNQUFNO0dBQ3RCLElBQUksY0FBYztHQUNsQixJQUFJLGVBQWU7SUFDakIsWUFBWSxVQUFVO0lBQ3RCLG1CQUFtQjtJQUNuQixrQkFBa0I7SUFDbEIsZ0JBQWdCO0dBQ2xCO0dBQ0EsSUFBSSxNQUFNO0VBQ1osT0FBTztHQUNMLFlBQVksVUFBVTtHQUN0QixtQkFBbUI7R0FDbkIsa0JBQWtCO0dBQ2xCLGdCQUFnQjtFQUNsQjtDQUNGLEdBQUcsQ0FBQyxRQUFRLENBQUM7O0NBR2IsZ0JBQWdCO0VBQ2QsbUJBQW1CO0VBQ25CLGtCQUFrQjtFQUNsQixnQkFBZ0I7Q0FDbEIsR0FBRztFQUNEO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtDQUNGLENBQUM7O0NBR0QsTUFBTSxvQkFBb0I7RUFDeEIsTUFBTSxTQUFTLGdCQUFnQjtFQUMvQixJQUFJLENBQUMsUUFBUTtFQUNiLE1BQU0sSUFBSSxLQUFLLElBQUksT0FBTyxRQUFRLElBQUssT0FBTyxTQUFTLE1BQU8sS0FBSyxHQUFHO0VBQ3RFLE1BQU0sSUFBSSxLQUFLLEtBQUs7RUFDcEIsV0FBVztHQUNULElBQUksT0FBTyxRQUFRLEtBQUs7R0FDeEIsSUFBSSxPQUFPLFNBQVMsS0FBSztHQUN6QjtHQUNBO0VBQ0YsQ0FBQztDQUNIOztDQUdBLE1BQU0sd0JBQXdCO0VBQzVCLE1BQU0sU0FBUyxnQkFBZ0I7RUFDL0IsTUFBTSxNQUFNLFlBQVk7RUFDeEIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsU0FBUztFQUVqQyxJQUFJO0dBQ0YsTUFBTSxhQUFhLFNBQVMsY0FBYyxRQUFRO0dBQ2xELFdBQVcsUUFBUTtHQUNuQixXQUFXLFNBQVM7R0FDcEIsTUFBTSxPQUFPLFdBQVcsV0FBVyxJQUFJO0dBQ3ZDLElBQUksQ0FBQyxNQUFNOztHQUdYLEtBQUssVUFDSCxRQUNBLFFBQVEsR0FDUixRQUFRLEdBQ1IsUUFBUSxHQUNSLFFBQVEsR0FDUixHQUNBLEdBQ0EsV0FBVyxPQUNYLFdBQVcsTUFDYjtHQUVBLE1BQU0sYUFBYSxXQUFXLFVBQVUsY0FBYyxHQUFJO0dBQzFELFlBQVksVUFBVTtHQUN0QixjQUFjLFVBQVU7R0FDeEIsV0FBVyxJQUFJO0dBQ2YsY0FBYyxRQUFRO0dBQ3RCLGNBQWMsNkNBQTZDO0dBQzNELGlCQUFpQixjQUFjLElBQUksR0FBRyxHQUFJO0VBQzVDLFNBQVMsR0FBRztHQUNWLFFBQVEsTUFBTSxDQUFDO0VBQ2pCO0NBQ0Y7Ozs7O0NBTUEsTUFBTSx1QkFBdUIsUUFBZ0IsV0FBbUI7RUFDOUQsTUFBTSxNQUFNLFlBQVk7RUFDeEIsSUFBSSxDQUFDLEtBQUs7RUFFVixnQkFBZ0IsSUFBSTtFQUVwQixJQUFJO0dBQ0YsTUFBTSxhQUFhLFNBQVMsY0FBYyxRQUFRO0dBQ2xELFdBQVcsUUFBUSxJQUFJO0dBQ3ZCLFdBQVcsU0FBUyxJQUFJO0dBQ3hCLE1BQU0sT0FBTyxXQUFXLFdBQVcsSUFBSTtHQUN2QyxJQUFJLENBQUMsTUFBTTtHQUVYLEtBQUssVUFBVSxLQUFLLEdBQUcsQ0FBQztHQUN4QixNQUFNLFVBQVUsS0FBSyxhQUFhLEdBQUcsR0FBRyxXQUFXLE9BQU8sV0FBVyxNQUFNO0dBQzNFLE1BQU0sT0FBTyxRQUFRO0dBQ3JCLE1BQU0sSUFBSSxXQUFXO0dBQ3JCLE1BQU0sSUFBSSxXQUFXOztHQUdyQixNQUFNLFNBQVMsS0FBSyxNQUFNLEtBQUssSUFBSSxHQUFHLEtBQUssSUFBSSxJQUFJLEdBQUcsTUFBTSxDQUFDLENBQUM7R0FDOUQsTUFBTSxTQUFTLEtBQUssTUFBTSxLQUFLLElBQUksR0FBRyxLQUFLLElBQUksSUFBSSxHQUFHLE1BQU0sQ0FBQyxDQUFDO0dBQzlELE1BQU0sY0FBYyxTQUFTLElBQUksVUFBVTtHQUUzQyxNQUFNLFVBQVUsS0FBSztHQUNyQixNQUFNLFVBQVUsS0FBSyxhQUFhO0dBQ2xDLE1BQU0sVUFBVSxLQUFLLGFBQWE7O0dBR2xDLE1BQU0sUUFBUSxTQUFTLGNBQWMsS0FBSztHQUMxQyxNQUFNLE1BQU0sUUFBUTtHQUNwQixTQUFTLEtBQUssWUFBWSxLQUFLO0dBQy9CLE1BQU0sV0FBVyxPQUFPLGlCQUFpQixLQUFLLENBQUMsQ0FBQztHQUNoRCxTQUFTLEtBQUssWUFBWSxLQUFLO0dBQy9CLE1BQU0sTUFBTSxTQUFTLE1BQU0sTUFBTSxDQUFDLEVBQUUsSUFBSSxNQUFNLEtBQUs7SUFBQztJQUFLO0lBQUs7R0FBRzs7R0FHakUsTUFBTSxVQUFVLElBQUksV0FBVyxJQUFJLENBQUM7R0FDcEMsTUFBTSxRQUFrQixDQUFDLFNBQVMsU0FBUyxDQUFDO0dBQzVDLFFBQVEsU0FBUyxTQUFTLEtBQUs7R0FFL0IsTUFBTSxRQUFRLEtBQUssSUFBSSxpQkFBaUIsS0FBSyxDQUFDOztHQUc5QyxJQUFJLE9BQU87R0FDWCxPQUFPLE9BQU8sTUFBTSxRQUFRO0lBQzFCLE1BQU0sT0FBTyxNQUFNO0lBQ25CLE1BQU0sS0FBSyxPQUFPO0lBQ2xCLE1BQU0sS0FBSyxLQUFLLE1BQU0sT0FBTyxDQUFDO0lBQzlCLE1BQU0sTUFBTSxPQUFPOztJQUduQixLQUFLLE9BQU8sSUFBSTtJQUNoQixLQUFLLE1BQU0sS0FBSyxJQUFJO0lBQ3BCLEtBQUssTUFBTSxLQUFLLElBQUk7SUFDcEIsS0FBSyxNQUFNLEtBQUs7O0lBR2hCLE1BQU0sWUFBWTtLQUNoQixDQUFDLEtBQUssR0FBRyxFQUFFO0tBQ1gsQ0FBQyxLQUFLLEdBQUcsRUFBRTtLQUNYLENBQUMsSUFBSSxLQUFLLENBQUM7S0FDWCxDQUFDLElBQUksS0FBSyxDQUFDO0lBQ2I7SUFFQSxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksR0FBRyxLQUFLO0tBQzFCLE1BQU0sS0FBSyxVQUFVLEVBQUUsQ0FBQztLQUN4QixNQUFNLEtBQUssVUFBVSxFQUFFLENBQUM7S0FFeEIsSUFBSSxNQUFNLEtBQUssS0FBSyxLQUFLLE1BQU0sS0FBSyxLQUFLLEdBQUc7TUFDMUMsTUFBTSxPQUFPLEtBQUssS0FBSztNQUN2QixJQUFJLENBQUMsUUFBUSxPQUFPO09BQ2xCLE1BQU0sT0FBTyxPQUFPO09BQ3BCLE1BQU0sS0FBSyxLQUFLO09BQ2hCLE1BQU0sS0FBSyxLQUFLLE9BQU87T0FDdkIsTUFBTSxLQUFLLEtBQUssT0FBTzs7T0FHdkIsTUFBTSxTQUNKLEtBQUssSUFBSSxLQUFLLFNBQVMsQ0FBQyxJQUN4QixLQUFLLElBQUksS0FBSyxTQUFTLENBQUMsSUFDeEIsS0FBSyxJQUFJLEtBQUssU0FBUyxDQUFDO09BRTFCLElBQUksVUFBVSxPQUFPO1FBQ25CLFFBQVEsUUFBUTtRQUNoQixNQUFNLEtBQUssSUFBSTtPQUNqQjtNQUNGO0tBQ0Y7SUFDRjtHQUNGO0dBRUEsS0FBSyxhQUFhLFNBQVMsR0FBRyxDQUFDO0dBQy9CLE1BQU0sYUFBYSxXQUFXLFVBQVUsY0FBYyxHQUFJO0dBRTFELElBQUksQ0FBQyxvQkFBb0IsVUFBVTtJQUNqQyxvQkFBb0IsUUFBUTtHQUM5QjtHQUVBLFlBQVksVUFBVTtHQUN0QixjQUFjLFVBQVU7R0FDeEIsY0FBYyxpREFBaUQsT0FBTyxJQUFJLE9BQU8sR0FBRztHQUNwRixpQkFBaUIsY0FBYyxJQUFJLEdBQUcsR0FBSTtFQUM1QyxTQUFTLEdBQUc7R0FDVixRQUFRLE1BQU0sQ0FBQztFQUNqQixVQUFVO0dBQ1IsZ0JBQWdCLEtBQUs7RUFDdkI7Q0FDRjs7Q0FHQSxNQUFNLGtDQUFrQztFQUN0QyxNQUFNLE1BQU0sWUFBWTtFQUN4QixJQUFJLENBQUMsS0FBSztFQUVWLGdCQUFnQixJQUFJO0VBRXBCLElBQUk7R0FDRixNQUFNLGFBQWEsU0FBUyxjQUFjLFFBQVE7R0FDbEQsV0FBVyxRQUFRLElBQUk7R0FDdkIsV0FBVyxTQUFTLElBQUk7R0FDeEIsTUFBTSxPQUFPLFdBQVcsV0FBVyxJQUFJO0dBQ3ZDLElBQUksQ0FBQyxNQUFNO0dBRVgsS0FBSyxVQUFVLEtBQUssR0FBRyxDQUFDO0dBQ3hCLE1BQU0sVUFBVSxLQUFLLGFBQWEsR0FBRyxHQUFHLFdBQVcsT0FBTyxXQUFXLE1BQU07R0FDM0UsTUFBTSxPQUFPLFFBQVE7R0FDckIsTUFBTSxJQUFJLFdBQVc7R0FDckIsTUFBTSxJQUFJLFdBQVc7O0dBR3JCLE1BQU0sUUFBUSxTQUFTLGNBQWMsS0FBSztHQUMxQyxNQUFNLE1BQU0sUUFBUTtHQUNwQixTQUFTLEtBQUssWUFBWSxLQUFLO0dBQy9CLE1BQU0sV0FBVyxPQUFPLGlCQUFpQixLQUFLLENBQUMsQ0FBQztHQUNoRCxTQUFTLEtBQUssWUFBWSxLQUFLO0dBQy9CLE1BQU0sTUFBTSxTQUFTLE1BQU0sTUFBTSxDQUFDLEVBQUUsSUFBSSxNQUFNLEtBQUs7SUFBQztJQUFLO0lBQUs7R0FBRzs7R0FHakUsTUFBTSxXQUFXLEtBQUssS0FBSyxNQUFNLElBQUksS0FBSyxNQUFNO0dBQ2hELE1BQU0sV0FBVyxLQUFLLEtBQUssTUFBTSxJQUFJLEtBQUssSUFBSSxNQUFNO0dBQ3BELE1BQU0sV0FBVyxLQUFLLEtBQUssTUFBTSxJQUFJLEtBQUssSUFBSSxNQUFNO0dBRXBELE1BQU0sVUFBVSxJQUFJLFdBQVcsSUFBSSxDQUFDO0dBQ3BDLE1BQU0sUUFBa0IsQ0FBQzs7R0FHekIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEdBQUcsS0FBSztJQUMxQixNQUFNLEtBQUssQ0FBQztJQUNaLE1BQU0sS0FBSyxLQUFLLElBQUksS0FBSyxDQUFDO0lBQzFCLFFBQVEsS0FBSztJQUNiLFFBQVEsS0FBSyxJQUFJLEtBQUssS0FBSztHQUM3QjtHQUNBLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxHQUFHLEtBQUs7SUFDMUIsTUFBTSxLQUFLLElBQUksQ0FBQztJQUNoQixNQUFNLEtBQU0sSUFBSSxJQUFLLElBQUksQ0FBQztJQUMxQixRQUFRLElBQUksS0FBSztJQUNqQixRQUFTLElBQUksSUFBSyxJQUFJLEtBQUs7R0FDN0I7R0FFQSxNQUFNLFFBQVEsS0FBSyxJQUFJLGlCQUFpQixLQUFLLENBQUM7R0FFOUMsSUFBSSxPQUFPO0dBQ1gsT0FBTyxPQUFPLE1BQU0sUUFBUTtJQUMxQixNQUFNLE9BQU8sTUFBTTtJQUNuQixNQUFNLEtBQUssT0FBTztJQUNsQixNQUFNLEtBQUssS0FBSyxNQUFNLE9BQU8sQ0FBQztJQUM5QixNQUFNLE1BQU0sT0FBTzs7SUFHbkIsS0FBSyxPQUFPLElBQUk7SUFDaEIsS0FBSyxNQUFNLEtBQUssSUFBSTtJQUNwQixLQUFLLE1BQU0sS0FBSyxJQUFJO0lBQ3BCLEtBQUssTUFBTSxLQUFLO0lBRWhCLE1BQU0sWUFBWTtLQUNoQixDQUFDLEtBQUssR0FBRyxFQUFFO0tBQ1gsQ0FBQyxLQUFLLEdBQUcsRUFBRTtLQUNYLENBQUMsSUFBSSxLQUFLLENBQUM7S0FDWCxDQUFDLElBQUksS0FBSyxDQUFDO0lBQ2I7SUFFQSxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksR0FBRyxLQUFLO0tBQzFCLE1BQU0sS0FBSyxVQUFVLEVBQUUsQ0FBQztLQUN4QixNQUFNLEtBQUssVUFBVSxFQUFFLENBQUM7S0FFeEIsSUFBSSxNQUFNLEtBQUssS0FBSyxLQUFLLE1BQU0sS0FBSyxLQUFLLEdBQUc7TUFDMUMsTUFBTSxPQUFPLEtBQUssS0FBSztNQUN2QixJQUFJLENBQUMsUUFBUSxPQUFPO09BQ2xCLE1BQU0sT0FBTyxPQUFPO09BQ3BCLE1BQU0sS0FBSyxLQUFLO09BQ2hCLE1BQU0sS0FBSyxLQUFLLE9BQU87T0FDdkIsTUFBTSxLQUFLLEtBQUssT0FBTztPQUV2QixNQUFNLFNBQ0osS0FBSyxJQUFJLEtBQUssU0FBUyxDQUFDLElBQ3hCLEtBQUssSUFBSSxLQUFLLFNBQVMsQ0FBQyxJQUN4QixLQUFLLElBQUksS0FBSyxTQUFTLENBQUM7T0FFMUIsSUFBSSxVQUFVLE9BQU87UUFDbkIsUUFBUSxRQUFRO1FBQ2hCLE1BQU0sS0FBSyxJQUFJO09BQ2pCO01BQ0Y7S0FDRjtJQUNGO0dBQ0Y7R0FFQSxLQUFLLGFBQWEsU0FBUyxHQUFHLENBQUM7R0FDL0IsTUFBTSxhQUFhLFdBQVcsVUFBVSxjQUFjLEdBQUk7R0FFMUQsSUFBSSxDQUFDLG9CQUFvQixVQUFVO0lBQ2pDLG9CQUFvQixRQUFRO0dBQzlCO0dBRUEsWUFBWSxVQUFVO0dBQ3RCLGNBQWMsVUFBVTtHQUN4QixjQUFjLHdEQUF3RDtHQUN0RSxpQkFBaUIsY0FBYyxJQUFJLEdBQUcsR0FBSTtFQUM1QyxTQUFTLEdBQUc7R0FDVixRQUFRLE1BQU0sQ0FBQztFQUNqQixVQUFVO0dBQ1IsZ0JBQWdCLEtBQUs7RUFDdkI7Q0FDRjs7OztDQUtBLE1BQU0scUJBQXFCLFNBQWlCLFNBQWlCLFNBQXVDO0VBQ2xHLE1BQU0sTUFBTSxZQUFZO0VBQ3hCLElBQUksQ0FBQyxLQUFLO0VBRVYsSUFBSTtHQUNGLE1BQU0sYUFBYSxTQUFTLGNBQWMsUUFBUTtHQUNsRCxXQUFXLFFBQVEsSUFBSTtHQUN2QixXQUFXLFNBQVMsSUFBSTtHQUN4QixNQUFNLE9BQU8sV0FBVyxXQUFXLElBQUk7R0FDdkMsSUFBSSxDQUFDLE1BQU07R0FFWCxLQUFLLFVBQVUsS0FBSyxHQUFHLENBQUM7R0FFeEIsTUFBTSxNQUFNO0dBQ1osTUFBTSxJQUFJLEtBQUssSUFBSSxHQUFHLEtBQUssSUFBSSxJQUFJLE9BQU8sT0FBTyxDQUFDO0dBQ2xELE1BQU0sSUFBSSxLQUFLLElBQUksR0FBRyxLQUFLLElBQUksSUFBSSxRQUFRLE9BQU8sQ0FBQztHQUVuRCxJQUFJLFNBQVMsV0FBVzs7SUFFdEIsTUFBTSxVQUFVLEtBQUssYUFDbkIsS0FBSyxJQUFJLEdBQUcsSUFBSSxHQUFHLEdBQ25CLEtBQUssSUFBSSxHQUFHLElBQUksR0FBRyxHQUNuQixNQUFNLEdBQ04sTUFBTSxDQUNSO0lBQ0EsTUFBTSxPQUFPLFFBQVE7O0lBR3JCLElBQUksT0FBTyxHQUFHLE9BQU8sR0FBRyxPQUFPLEdBQUcsUUFBUTtJQUMxQyxLQUFLLElBQUksS0FBSyxHQUFHLEtBQUssTUFBTSxHQUFHLE1BQU07S0FDbkMsS0FBSyxJQUFJLEtBQUssR0FBRyxLQUFLLE1BQU0sR0FBRyxNQUFNO01BQ25DLE1BQU0sSUFBSSxLQUFLLE1BQU0sS0FBSyxLQUFLLEtBQUssR0FBRztNQUN2QyxJQUFJLEtBQUssTUFBTSxNQUFPLEtBQUssS0FBSztPQUM5QixNQUFNLEtBQUssS0FBSyxNQUFNLElBQUksTUFBTTtPQUNoQyxRQUFRLEtBQUs7T0FDYixRQUFRLEtBQUssSUFBSTtPQUNqQixRQUFRLEtBQUssSUFBSTtPQUNqQjtNQUNGO0tBQ0Y7SUFDRjtJQUVBLElBQUksUUFBUSxHQUFHO0tBQ2IsTUFBTSxPQUFPLE9BQU87S0FDcEIsTUFBTSxPQUFPLE9BQU87S0FDcEIsTUFBTSxPQUFPLE9BQU87S0FFcEIsS0FBSyxJQUFJLEtBQUssR0FBRyxLQUFLLE1BQU0sR0FBRyxNQUFNO01BQ25DLEtBQUssSUFBSSxLQUFLLEdBQUcsS0FBSyxNQUFNLEdBQUcsTUFBTTtPQUNuQyxNQUFNLElBQUksS0FBSyxNQUFNLEtBQUssS0FBSyxLQUFLLEdBQUc7T0FDdkMsSUFBSSxJQUFJLEtBQUs7UUFDWCxNQUFNLEtBQUssS0FBSyxNQUFNLElBQUksTUFBTTtRQUNoQyxNQUFNLGNBQWMsSUFBSyxJQUFJO1FBQzdCLEtBQUssS0FBSyxLQUFLLE1BQU0sSUFBSSxlQUFlLE9BQU87UUFDL0MsS0FBSyxJQUFJLEtBQUssS0FBSyxJQUFJLE1BQU0sSUFBSSxlQUFlLE9BQU87UUFDdkQsS0FBSyxJQUFJLEtBQUssS0FBSyxJQUFJLE1BQU0sSUFBSSxlQUFlLE9BQU87T0FDekQ7TUFDRjtLQUNGO0tBQ0EsS0FBSyxhQUFhLFNBQVMsS0FBSyxJQUFJLEdBQUcsSUFBSSxHQUFHLEdBQUcsS0FBSyxJQUFJLEdBQUcsSUFBSSxHQUFHLENBQUM7SUFDdkU7R0FDRixPQUFPLElBQUksU0FBUyxVQUFVOztJQUU1QixLQUFLLEtBQUs7SUFDVixLQUFLLFVBQVU7SUFDZixLQUFLLElBQUksR0FBRyxHQUFHLEtBQUssR0FBRyxLQUFLLEtBQUssQ0FBQztJQUNsQyxLQUFLLEtBQUs7SUFDVixLQUFLLFNBQVM7SUFDZCxLQUFLLFVBQVUsS0FBSyxHQUFHLENBQUM7SUFDeEIsS0FBSyxRQUFRO0dBQ2YsT0FBTzs7SUFFTCxLQUFLLEtBQUs7SUFDVixLQUFLLFVBQVU7SUFDZixLQUFLLElBQUksR0FBRyxHQUFHLEtBQUssR0FBRyxLQUFLLEtBQUssQ0FBQztJQUNsQyxLQUFLLEtBQUs7SUFDVixLQUFLLFNBQVM7SUFDZCxLQUFLLFVBQVUsS0FBSyxHQUFHLENBQUM7SUFDeEIsS0FBSyxRQUFRO0dBQ2Y7R0FFQSxNQUFNLGFBQWEsV0FBVyxVQUFVLGNBQWMsR0FBSTtHQUMxRCxZQUFZLFVBQVU7R0FDdEIsY0FBYyxVQUFVO0VBQzFCLFNBQVMsR0FBRztHQUNWLFFBQVEsTUFBTSxDQUFDO0VBQ2pCO0NBQ0Y7Ozs7Q0FLQSxNQUFNLDZCQUE2QjtFQUNqQyxNQUFNLE1BQU0sWUFBWTtFQUN4QixJQUFJLENBQUMsT0FBTyxVQUFVLFNBQVMsR0FBRztFQUVsQyxJQUFJO0dBQ0YsTUFBTSxhQUFhLFNBQVMsY0FBYyxRQUFRO0dBQ2xELFdBQVcsUUFBUSxJQUFJO0dBQ3ZCLFdBQVcsU0FBUyxJQUFJO0dBQ3hCLE1BQU0sT0FBTyxXQUFXLFdBQVcsSUFBSTtHQUN2QyxJQUFJLENBQUMsTUFBTTs7R0FHWCxLQUFLLFlBQVk7R0FDakIsS0FBSyxTQUFTLEdBQUcsR0FBRyxXQUFXLE9BQU8sV0FBVyxNQUFNOztHQUd2RCxNQUFNLGVBQWUsU0FBUyxjQUFjLFFBQVE7R0FDcEQsYUFBYSxRQUFRLElBQUk7R0FDekIsYUFBYSxTQUFTLElBQUk7R0FDMUIsTUFBTSxPQUFPLGFBQWEsV0FBVyxJQUFJO0dBRXpDLElBQUksTUFBTTtJQUNSLEtBQUssVUFBVSxLQUFLLEdBQUcsQ0FBQztJQUV4QixNQUFNLGFBQWEsU0FBUyxjQUFjLFFBQVE7SUFDbEQsV0FBVyxRQUFRLElBQUk7SUFDdkIsV0FBVyxTQUFTLElBQUk7SUFDeEIsTUFBTSxPQUFPLFdBQVcsV0FBVyxJQUFJO0lBRXZDLElBQUksTUFBTTtLQUNSLElBQUksYUFBYSxHQUFHO01BQ2xCLEtBQUssU0FBUyxRQUFRLFdBQVc7S0FDbkM7S0FFQSxLQUFLLFVBQVU7S0FDZixLQUFLLE9BQU8sVUFBVSxFQUFFLENBQUMsSUFBSSxJQUFJLE9BQU8sVUFBVSxFQUFFLENBQUMsSUFBSSxJQUFJLE1BQU07S0FDbkUsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFVBQVUsUUFBUSxLQUFLO01BQ3pDLEtBQUssT0FBTyxVQUFVLEVBQUUsQ0FBQyxJQUFJLElBQUksT0FBTyxVQUFVLEVBQUUsQ0FBQyxJQUFJLElBQUksTUFBTTtLQUNyRTtLQUNBLEtBQUssVUFBVTtLQUNmLEtBQUssWUFBWTtLQUNqQixLQUFLLEtBQUs7S0FFVixLQUFLLDJCQUEyQjtLQUNoQyxLQUFLLFVBQVUsWUFBWSxHQUFHLENBQUM7SUFDakM7SUFFQSxLQUFLLFVBQVUsY0FBYyxHQUFHLENBQUM7R0FDbkM7R0FFQSxNQUFNLGFBQWEsV0FBVyxVQUFVLGNBQWMsR0FBSTtHQUMxRCxJQUFJLENBQUMsb0JBQW9CLFVBQVU7SUFDakMsb0JBQW9CLFFBQVE7R0FDOUI7R0FFQSxZQUFZLFVBQVU7R0FDdEIsY0FBYyxVQUFVO0dBQ3hCLGFBQWEsQ0FBQyxDQUFDO0dBQ2YsZ0JBQWdCLEtBQUs7R0FDckIsY0FBYyxRQUFRO0dBQ3RCLGNBQWMsMkNBQTJDO0dBQ3pELGlCQUFpQixjQUFjLElBQUksR0FBRyxHQUFJO0VBQzVDLFNBQVMsR0FBRztHQUNWLFFBQVEsTUFBTSxDQUFDO0VBQ2pCO0NBQ0Y7Ozs7Q0FLQSxNQUFNLDJCQUEyQjtFQUMvQixNQUFNLFNBQVMsZ0JBQWdCO0VBQy9CLE1BQU0sTUFBTSxZQUFZO0VBQ3hCLElBQUksQ0FBQyxRQUFRO0VBRWIsTUFBTSxNQUFNLE9BQU8sV0FBVyxJQUFJO0VBQ2xDLElBQUksQ0FBQyxLQUFLOztFQUdWLE9BQU8sUUFBUTtFQUNmLE9BQU8sU0FBUzs7RUFHaEIsSUFBSSxZQUFZO0VBQ2hCLElBQUksU0FBUyxHQUFHLEdBQUcsT0FBTyxPQUFPLE9BQU8sTUFBTTtFQUU5QyxJQUFJLENBQUMsS0FBSzs7R0FFUixJQUFJLFlBQVk7R0FDaEIsSUFBSSxPQUFPO0dBQ1gsSUFBSSxZQUFZO0dBQ2hCLElBQUksU0FBUyx5Q0FBeUMsT0FBTyxRQUFRLEdBQUcsT0FBTyxTQUFTLElBQUksRUFBRTtHQUM5RixJQUFJLE9BQU87R0FDWCxJQUFJLFNBQVMsc0VBQXNFLE9BQU8sUUFBUSxHQUFHLE9BQU8sU0FBUyxJQUFJLEVBQUU7R0FDM0g7RUFDRjtFQUVBLElBQUksS0FBSzs7RUFHVCxJQUFJLFVBQVUsT0FBTyxRQUFRLElBQUksVUFBVSxHQUFHLE9BQU8sU0FBUyxJQUFJLFVBQVUsQ0FBQztFQUM3RSxJQUFJLE1BQU0sWUFBWSxVQUFVOztFQUdoQyxNQUFNLFNBQVMsSUFBSSxRQUFRLElBQUk7RUFDL0IsSUFBSSxVQUFVO0VBQ2QsSUFBSSxVQUFVLE1BQU07RUFDcEIsSUFBSSxVQUFVLEtBQUs7R0FDakIsVUFBVTtHQUNWLFVBQVUsTUFBTTtFQUNsQjtFQUVBLE1BQU0sUUFBUSxDQUFDLFVBQVU7RUFDekIsTUFBTSxRQUFRLENBQUMsVUFBVTs7RUFHekIsTUFBTSxnQkFBZ0IsTUFBTSxjQUFjLGFBQWEsSUFBSSxLQUFNLFdBQVc7RUFDNUUsTUFBTSxjQUFjLE1BQU0sWUFBWSxhQUFhLElBQUk7RUFDdkQsTUFBTSxnQkFBZ0IsY0FBYyxJQUFJLE1BQU0sY0FBYyxhQUFhLElBQUk7RUFFN0UsSUFBSSxZQUFZLGNBQWMsY0FBYyxjQUFjLFlBQVksY0FBYyxjQUFjO0VBQ2xHLElBQUksYUFBYSxhQUFhO0VBRTlCLElBQUksU0FBUztFQUNiLElBQUksVUFBVSxLQUFLLE9BQU8sT0FBTyxTQUFTLE9BQU87O0VBR2pELE1BQU0sWUFBWSxhQUFhLEtBQUssSUFBSSxZQUFZLEVBQUUsSUFBSTtFQUMxRCxNQUFNLFVBQVUsYUFBYSxLQUFLLElBQUksVUFBVSxFQUFFLElBQUk7RUFDdEQsSUFBSSxZQUFZLEtBQUssVUFBVSxHQUFHO0dBQ2hDLElBQUksS0FBSztHQUNULElBQUksMkJBQTJCO0dBQy9CLElBQUksY0FBYyxLQUFLLElBQUksS0FBTyxZQUFZLE9BQVUsVUFBVSxHQUFLO0dBQ3ZFLElBQUksU0FBUyxRQUFRLEtBQUssSUFBSSxHQUFHLFlBQVksQ0FBQyxFQUFFO0dBQ2hELElBQUksVUFBVSxLQUFLLE9BQU8sT0FBTyxTQUFTLE9BQU87R0FDakQsSUFBSSxRQUFRO0VBQ2Q7O0VBR0EsSUFBSSxXQUFXLEtBQUssQ0FBQyxhQUFhO0dBQ2hDLElBQUksS0FBSztHQUNULElBQUksMkJBQTJCO0dBQy9CLElBQUksWUFBWSxTQUFTLElBQ3JCLHNCQUFzQixLQUFLLElBQUksS0FBTyxTQUFTLE1BQU8sRUFBRyxFQUFFLEtBQzNELHNCQUFzQixLQUFLLElBQUksS0FBTyxLQUFLLElBQUksTUFBTSxJQUFJLE1BQU8sRUFBRyxFQUFFO0dBQ3pFLElBQUksU0FBUyxPQUFPLE9BQU8sU0FBUyxPQUFPO0dBQzNDLElBQUksUUFBUTtFQUNkO0VBRUEsSUFBSSxTQUFTLEtBQUssQ0FBQyxhQUFhO0dBQzlCLElBQUksS0FBSztHQUNULElBQUksMkJBQTJCO0dBQy9CLElBQUksWUFBWSxPQUFPLElBQ25CLHNCQUFzQixLQUFLLElBQUksS0FBTyxPQUFPLE1BQU8sRUFBRyxFQUFFLEtBQ3pELHNCQUFzQixLQUFLLElBQUksS0FBTyxLQUFLLElBQUksSUFBSSxJQUFJLE1BQU8sRUFBRyxFQUFFO0dBQ3ZFLElBQUksU0FBUyxPQUFPLE9BQU8sU0FBUyxPQUFPO0dBQzNDLElBQUksUUFBUTtFQUNkO0VBRUEsSUFBSSxRQUFROzs7OztFQU1aLElBQUksZUFBZSxjQUFjLFVBQVUsU0FBUyxHQUFHO0dBQ3JELElBQUksS0FBSztHQUNULElBQUksVUFBVSxPQUFPLFFBQVEsSUFBSSxVQUFVLEdBQUcsT0FBTyxTQUFTLElBQUksVUFBVSxDQUFDO0dBQzdFLElBQUksTUFBTSxZQUFZLFVBQVU7R0FFaEMsSUFBSSxVQUFVO0dBQ2QsTUFBTSxTQUFTLFFBQVEsVUFBVSxFQUFFLENBQUMsSUFBSTtHQUN4QyxNQUFNLFNBQVMsUUFBUSxVQUFVLEVBQUUsQ0FBQyxJQUFJO0dBQ3hDLElBQUksT0FBTyxRQUFRLE1BQU07R0FFekIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFVBQVUsUUFBUSxLQUFLO0lBQ3pDLE1BQU0sS0FBSyxRQUFRLFVBQVUsRUFBRSxDQUFDLElBQUk7SUFDcEMsTUFBTSxLQUFLLFFBQVEsVUFBVSxFQUFFLENBQUMsSUFBSTtJQUNwQyxJQUFJLE9BQU8sSUFBSSxFQUFFO0dBQ25CO0dBRUEsSUFBSSxjQUFjO0lBQ2hCLElBQUksVUFBVTtJQUNkLElBQUksWUFBWTtJQUNoQixJQUFJLEtBQUs7R0FDWDtHQUVBLElBQUksY0FBYyxlQUFlLFlBQVk7R0FDN0MsSUFBSSxZQUFZLElBQUk7R0FDcEIsSUFBSSxZQUFZLGVBQWUsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7R0FDMUMsSUFBSSxPQUFPOztHQUdYLFVBQVUsU0FBUyxJQUFJLFFBQVE7SUFDN0IsTUFBTSxLQUFLLFFBQVEsR0FBRyxJQUFJO0lBQzFCLE1BQU0sS0FBSyxRQUFRLEdBQUcsSUFBSTtJQUMxQixNQUFNLFVBQVUsUUFBUTtJQUV4QixJQUFJLFVBQVU7SUFDZCxJQUFJLElBQUksSUFBSSxLQUFLLFVBQVUsSUFBSSxLQUFLLFlBQVksR0FBRyxLQUFLLEtBQUssQ0FBQztJQUM5RCxJQUFJLFlBQVksVUFBVyxtQkFBbUIsWUFBWSxZQUFhO0lBQ3ZFLElBQUksY0FBYztJQUNsQixJQUFJLFlBQVksSUFBSTtJQUNwQixJQUFJLEtBQUs7SUFDVCxJQUFJLE9BQU87R0FDYixDQUFDO0dBRUQsSUFBSSxRQUFRO0VBQ2Q7O0VBR0EsSUFBSSxlQUFlLFVBQVUsU0FBUztHQUNwQyxJQUFJLEtBQUs7O0dBRVQsSUFBSSxZQUFZO0dBQ2hCLElBQUksU0FBUyxHQUFHLEdBQUcsT0FBTyxPQUFPLFFBQVEsQ0FBQztHQUMxQyxJQUFJLFNBQVMsR0FBRyxRQUFRLElBQUksUUFBUSxHQUFHLE9BQU8sT0FBTyxPQUFPLFVBQVUsUUFBUSxJQUFJLFFBQVEsRUFBRTtHQUM1RixJQUFJLFNBQVMsR0FBRyxRQUFRLEdBQUcsUUFBUSxHQUFHLFFBQVEsQ0FBQztHQUMvQyxJQUFJLFNBQVMsUUFBUSxJQUFJLFFBQVEsR0FBRyxRQUFRLEdBQUcsT0FBTyxTQUFTLFFBQVEsSUFBSSxRQUFRLElBQUksUUFBUSxDQUFDOztHQUdoRyxJQUFJLGNBQWM7R0FDbEIsSUFBSSxZQUFZO0dBQ2hCLElBQUksV0FBVyxRQUFRLEdBQUcsUUFBUSxHQUFHLFFBQVEsR0FBRyxRQUFRLENBQUM7O0dBR3pELElBQUksY0FBYztHQUNsQixJQUFJLFlBQVk7R0FDaEIsSUFBSSxVQUFVO0dBQ2QsSUFBSSxPQUFPLFFBQVEsSUFBSSxRQUFRLElBQUksR0FBRyxRQUFRLENBQUM7R0FDL0MsSUFBSSxPQUFPLFFBQVEsSUFBSSxRQUFRLElBQUksR0FBRyxRQUFRLElBQUksUUFBUSxDQUFDO0dBQzNELElBQUksT0FBTyxRQUFRLElBQUssUUFBUSxJQUFJLElBQUssR0FBRyxRQUFRLENBQUM7R0FDckQsSUFBSSxPQUFPLFFBQVEsSUFBSyxRQUFRLElBQUksSUFBSyxHQUFHLFFBQVEsSUFBSSxRQUFRLENBQUM7R0FDakUsSUFBSSxPQUFPLFFBQVEsR0FBRyxRQUFRLElBQUksUUFBUSxJQUFJLENBQUM7R0FDL0MsSUFBSSxPQUFPLFFBQVEsSUFBSSxRQUFRLEdBQUcsUUFBUSxJQUFJLFFBQVEsSUFBSSxDQUFDO0dBQzNELElBQUksT0FBTyxRQUFRLEdBQUcsUUFBUSxJQUFLLFFBQVEsSUFBSSxJQUFLLENBQUM7R0FDckQsSUFBSSxPQUFPLFFBQVEsSUFBSSxRQUFRLEdBQUcsUUFBUSxJQUFLLFFBQVEsSUFBSSxJQUFLLENBQUM7R0FDakUsSUFBSSxPQUFPO0dBRVgsSUFBSSxRQUFRO0VBQ2Q7Q0FDRjs7Q0FHQSxNQUFNLHVCQUF1QixTQUFpQixZQUFvQjtFQUNoRSxNQUFNLFNBQVMsZ0JBQWdCO0VBQy9CLE1BQU0sTUFBTSxZQUFZO0VBQ3hCLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxPQUFPO0VBRTVCLE1BQU0sT0FBTyxPQUFPLHNCQUFzQjtFQUMxQyxNQUFNLFNBQVMsT0FBTyxRQUFRLEtBQUs7RUFDbkMsTUFBTSxTQUFTLE9BQU8sU0FBUyxLQUFLO0VBRXBDLE1BQU0sVUFBVSxVQUFVLEtBQUssUUFBUTtFQUN2QyxNQUFNLFVBQVUsVUFBVSxLQUFLLE9BQU87O0VBR3RDLE1BQU0sVUFBVSxVQUFVLE9BQU8sUUFBUSxJQUFJLFVBQVUsTUFBTTtFQUM3RCxNQUFNLFVBQVUsVUFBVSxPQUFPLFNBQVMsSUFBSSxVQUFVLE1BQU07RUFFOUQsTUFBTSxTQUFTLElBQUksUUFBUSxJQUFJO0VBQy9CLElBQUksVUFBVTtFQUNkLElBQUksVUFBVSxNQUFNO0VBQ3BCLElBQUksVUFBVSxLQUFLO0dBQ2pCLFVBQVU7R0FDVixVQUFVLE1BQU07RUFDbEI7RUFFQSxNQUFNLFFBQVEsQ0FBQyxVQUFVO0VBQ3pCLE1BQU0sUUFBUSxDQUFDLFVBQVU7RUFFekIsTUFBTSxTQUFTLFNBQVMsU0FBUztFQUNqQyxNQUFNLFNBQVMsU0FBUyxTQUFTO0VBRWpDLE1BQU0sT0FBTyxRQUFRLElBQUk7RUFDekIsTUFBTSxPQUFPLFFBQVEsSUFBSTtFQUV6QixPQUFPO0dBQ0w7R0FDQTtHQUNBO0dBQ0E7R0FDQSxVQUFVLFNBQVMsS0FBSyxTQUFTLEtBQUssU0FBUyxLQUFLLFNBQVM7RUFDL0Q7Q0FDRjs7Q0FHQSxNQUFNLHlCQUF5QixNQUEyQztFQUN4RSxJQUFJLGtCQUFrQixlQUFlLFVBQVUsRUFBRSxXQUFXLEdBQUc7R0FDN0QsYUFBYSxJQUFJO0dBQ2pCLFlBQVk7SUFBRSxHQUFHLEVBQUUsVUFBVSxVQUFVO0lBQUcsR0FBRyxFQUFFLFVBQVUsVUFBVTtHQUFFLENBQUM7R0FDdEU7RUFDRjtFQUVBLE1BQU0sU0FBUyxvQkFBb0IsRUFBRSxTQUFTLEVBQUUsT0FBTztFQUN2RCxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sVUFBVTs7RUFHakMsSUFBSSxlQUFlLGNBQWM7R0FDL0Isb0JBQW9CLE9BQU8sTUFBTSxPQUFPLElBQUk7RUFDOUMsT0FBTyxJQUFJLGVBQWUsWUFBWTtHQUNwQyxJQUFJLFVBQVUsVUFBVSxLQUFLLENBQUMsY0FBYztJQUMxQyxNQUFNLFFBQVEsVUFBVTtJQUN4QixNQUFNLE9BQU8sS0FBSyxNQUFNLE9BQU8sUUFBUSxNQUFNLEdBQUcsT0FBTyxRQUFRLE1BQU0sQ0FBQztJQUN0RSxJQUFJLE9BQU8sS0FBTTtLQUNmLGdCQUFnQixJQUFJO0tBQ3BCO0lBQ0Y7R0FDRjtHQUNBLElBQUksQ0FBQyxjQUFjO0lBQ2pCLGNBQWEsU0FBUSxDQUFDLEdBQUcsTUFBTTtLQUFFLEdBQUcsT0FBTztLQUFPLEdBQUcsT0FBTztJQUFNLENBQUMsQ0FBQztHQUN0RTtFQUNGLE9BQU8sSUFBSSxlQUFlLGlCQUFpQjtHQUN6QyxrQkFBa0IsT0FBTyxNQUFNLE9BQU8sTUFBTSxTQUFTO0VBQ3ZELE9BQU8sSUFBSSxlQUFlLGdCQUFnQjtHQUN4QyxrQkFBa0IsT0FBTyxNQUFNLE9BQU8sTUFBTSxRQUFRO0VBQ3RELE9BQU8sSUFBSSxlQUFlLGdCQUFnQjtHQUN4QyxrQkFBa0IsT0FBTyxNQUFNLE9BQU8sTUFBTSxLQUFLO0VBQ25ELE9BQU8sSUFBSSxlQUFlLFFBQVE7R0FDaEMsSUFBSSxFQUFFLFFBQVE7SUFDWixlQUFjLFNBQVEsS0FBSyxJQUFJLElBQUssT0FBTyxFQUFHLENBQUM7R0FDakQsT0FBTztJQUNMLGVBQWMsU0FBUSxLQUFLLElBQUksR0FBSyxPQUFPLEVBQUcsQ0FBQztHQUNqRDtFQUNGO0NBQ0Y7O0NBR0EsTUFBTSx5QkFBeUIsTUFBMkM7RUFDeEUsSUFBSSxXQUFXO0dBQ2IsYUFBYTtJQUNYLEdBQUcsRUFBRSxVQUFVLFNBQVM7SUFDeEIsR0FBRyxFQUFFLFVBQVUsU0FBUztHQUMxQixDQUFDO0dBQ0Q7RUFDRjtFQUVBLElBQUksZUFBZSxjQUFjLFVBQVUsVUFBVSxLQUFLLENBQUMsY0FBYztHQUN2RSxNQUFNLFNBQVMsb0JBQW9CLEVBQUUsU0FBUyxFQUFFLE9BQU87R0FDdkQsSUFBSSxRQUFRO0lBQ1YsTUFBTSxRQUFRLFVBQVU7SUFDeEIsTUFBTSxPQUFPLEtBQUssTUFBTSxPQUFPLFFBQVEsTUFBTSxHQUFHLE9BQU8sUUFBUSxNQUFNLENBQUM7SUFDdEUsb0JBQW9CLE9BQU8sR0FBSTtHQUNqQztFQUNGO0NBQ0Y7O0NBR0EsTUFBTSw0QkFBNEI7RUFDaEMsYUFBYSxLQUFLO0NBQ3BCOztDQUdBLE1BQU0scUJBQXFCLE1BQTJDO0VBQ3BFLEVBQUUsZUFBZTtFQUNqQixNQUFNLGFBQWEsRUFBRSxTQUFTLElBQUksT0FBTztFQUN6QyxlQUFjLFNBQVEsS0FBSyxJQUFJLElBQUssS0FBSyxJQUFJLEdBQUssT0FBTyxVQUFVLENBQUMsQ0FBQztDQUN2RTs7OztDQUtBLE1BQU0sMEJBQTBCO0VBQzlCLE1BQU0sU0FBUyxxQkFBcUI7RUFDcEMsTUFBTSxNQUFNLFlBQVk7RUFDeEIsSUFBSSxDQUFDLFFBQVE7RUFFYixNQUFNLE1BQU0sT0FBTyxXQUFXLElBQUk7RUFDbEMsSUFBSSxDQUFDLEtBQUs7RUFFVixPQUFPLFFBQVE7RUFDZixPQUFPLFNBQVM7O0VBR2hCLElBQUksWUFBWTtFQUNoQixJQUFJLFNBQVMsR0FBRyxHQUFHLE9BQU8sT0FBTyxPQUFPLE1BQU07RUFFOUMsSUFBSSxDQUFDLEtBQUs7R0FDUixJQUFJLFlBQVk7R0FDaEIsSUFBSSxPQUFPO0dBQ1gsSUFBSSxZQUFZO0dBQ2hCLElBQUksU0FBUyxzQkFBc0IsT0FBTyxRQUFRLEdBQUcsT0FBTyxTQUFTLENBQUM7R0FDdEU7RUFDRjs7RUFHQSxNQUFNLE9BQU8sWUFBWSxXQUFXLElBQUk7RUFDeEMsTUFBTSxPQUFPLGdCQUFnQixrQkFBa0IsSUFBSSxPQUFRLFdBQVcsS0FBSyxJQUFJLElBQUs7RUFDcEYsTUFBTSxPQUFPLGdCQUFnQixrQkFBa0IsSUFBSSxPQUFPLElBQUk7RUFFOUQsTUFBTSxNQUFNO0VBQ1osTUFBTSxTQUFTO0VBQ2YsTUFBTSxTQUFTLE9BQU8sUUFBUSxTQUFTLEtBQUssT0FBTyxLQUFLLE9BQU87RUFDL0QsTUFBTSxRQUFRLFNBQVMsS0FBSztFQUU1QixJQUFJLFFBQVE7RUFDWixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksTUFBTSxLQUFLO0dBQzdCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxNQUFNLEtBQUs7SUFDN0IsSUFBSSxTQUFTLFFBQVE7SUFDckIsTUFBTSxJQUFJLFNBQVMsS0FBSyxRQUFRO0lBQ2hDLE1BQU0sSUFBSSxTQUFTLEtBQUssUUFBUTs7SUFHaEMsSUFBSSxZQUFZO0lBQ2hCLElBQUksU0FBUyxHQUFHLEdBQUcsT0FBTyxLQUFLOztJQUcvQixJQUFJLFVBQVUsS0FBSyxHQUFHLEdBQUcsT0FBTyxLQUFLOztJQUdyQyxJQUFJLGNBQWM7SUFDbEIsSUFBSSxZQUFZO0lBQ2hCLElBQUksV0FBVyxHQUFHLEdBQUcsT0FBTyxLQUFLO0lBRWpDO0dBQ0Y7RUFDRjtDQUNGOzs7O0NBS0EsTUFBTSx3QkFBd0I7RUFDNUIsTUFBTSxTQUFTLG1CQUFtQjtFQUNsQyxNQUFNLE1BQU0sWUFBWTtFQUN4QixJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUs7RUFFckIsTUFBTSxNQUFNLE9BQU8sV0FBVyxJQUFJO0VBQ2xDLElBQUksQ0FBQyxLQUFLO0VBRVYsT0FBTyxRQUFRO0VBQ2YsT0FBTyxTQUFTO0VBRWhCLElBQUksWUFBWTtFQUNoQixJQUFJLFNBQVMsR0FBRyxHQUFHLGFBQWEsWUFBWTs7RUFHNUMsTUFBTSxVQUFVO0VBQ2hCLE1BQU0sVUFBVTtFQUNoQixNQUFNLGVBQWUsU0FBUyxjQUFjLFFBQVE7RUFDcEQsYUFBYSxRQUFRO0VBQ3JCLGFBQWEsU0FBUztFQUN0QixNQUFNLE9BQU8sYUFBYSxXQUFXLElBQUk7RUFFekMsSUFBSSxNQUFNO0dBQ1IsS0FBSyxZQUFZO0dBQ2pCLEtBQUssU0FBUyxHQUFHLEdBQUcsU0FBUyxPQUFPOztHQUdwQyxNQUFNLGdCQUFnQixNQUFNLGNBQWMsYUFBYSxJQUFJLEtBQU0sV0FBVztHQUM1RSxNQUFNLGNBQWMsTUFBTSxZQUFZLGFBQWEsSUFBSTtHQUN2RCxNQUFNLGdCQUFnQixjQUFjLElBQUksTUFBTSxjQUFjLGFBQWEsSUFBSTtHQUU3RSxJQUFJLFlBQVksY0FBYyxjQUFjLGNBQWMsWUFBWSxjQUFjLGNBQWM7R0FDbEcsSUFBSSxhQUFhLGFBQWE7R0FDOUIsS0FBSyxTQUFTO0dBRWQsTUFBTSxTQUFTLElBQUksUUFBUSxJQUFJO0dBQy9CLElBQUksS0FBSztHQUNULElBQUksS0FBSztHQUNULElBQUksU0FBUyxVQUFVLFNBQVM7SUFDOUIsS0FBSyxVQUFVO0dBQ2pCLE9BQU87SUFDTCxLQUFLLFVBQVU7R0FDakI7R0FFQSxLQUFLLFVBQVUsTUFBTSxVQUFVLE1BQU0sSUFBSSxVQUFVLE1BQU0sR0FBRyxJQUFJLEVBQUU7O0dBR2xFLE1BQU0sWUFBWSxhQUFhLEtBQUssSUFBSSxZQUFZLEVBQUUsSUFBSTtHQUMxRCxNQUFNLFVBQVUsYUFBYSxLQUFLLElBQUksVUFBVSxFQUFFLElBQUk7R0FDdEQsSUFBSSxZQUFZLEtBQUssVUFBVSxHQUFHO0lBQ2hDLEtBQUssS0FBSztJQUNWLEtBQUssMkJBQTJCO0lBQ2hDLEtBQUssY0FBYyxLQUFLLElBQUksS0FBTyxZQUFZLE9BQVUsVUFBVSxHQUFLO0lBQ3hFLEtBQUssU0FBUyxRQUFRLEtBQUssSUFBSSxHQUFHLFlBQVksQ0FBQyxFQUFFO0lBQ2pELEtBQUssVUFBVSxNQUFNLFVBQVUsTUFBTSxJQUFJLFVBQVUsTUFBTSxHQUFHLElBQUksRUFBRTtJQUNsRSxLQUFLLFFBQVE7R0FDZjs7R0FHQSxJQUFJLGNBQWM7SUFDaEIsTUFBTSxPQUFPO0lBQ2IsS0FBSyxZQUFZO0lBQ2pCLEtBQUssU0FBUyxHQUFHLFVBQVUsTUFBTSxTQUFTLElBQUk7SUFDOUMsS0FBSyxZQUFZO0lBQ2pCLEtBQUssT0FBTztJQUNaLEtBQUssWUFBWTtJQUNqQixLQUFLLFNBQVMsY0FBYyxZQUFZLEdBQUcsVUFBVSxHQUFHLFVBQVUsT0FBTyxFQUFFO0lBQzNFLEtBQUssT0FBTztJQUNaLEtBQUssU0FBUyxTQUFTLGFBQWEsVUFBVSxHQUFHLFVBQVUsT0FBTyxFQUFFO0lBQ3BFLEtBQUssY0FBYztJQUNuQixLQUFLLFlBQVk7SUFDakIsS0FBSyxVQUFVO0lBQ2YsS0FBSyxPQUFPLEdBQUcsVUFBVSxJQUFJO0lBQzdCLEtBQUssT0FBTyxTQUFTLFVBQVUsSUFBSTtJQUNuQyxLQUFLLE9BQU87R0FDZDtHQUVBLEtBQUssY0FBYztHQUNuQixLQUFLLFlBQVk7R0FDakIsS0FBSyxXQUFXLEdBQUcsR0FBRyxTQUFTLE9BQU87RUFDeEM7O0VBR0EsTUFBTSxPQUFPLGdCQUFnQixrQkFBa0IsSUFBSSxnQkFBZ0IsaUJBQWtCLFdBQVcsS0FBSyxJQUFJLElBQUs7RUFDOUcsTUFBTSxPQUFPLGdCQUFnQixrQkFBa0IsSUFBSTtFQUVuRCxNQUFNLE9BQU8sWUFBWSxXQUFXLElBQUk7RUFDeEMsTUFBTSxVQUFVLE9BQU8sS0FBSztFQUM1QixNQUFNLFVBQVUsT0FBTyxLQUFLO0VBQzVCLE1BQU0sYUFBYSxjQUFjLFVBQVU7RUFDM0MsTUFBTSxhQUFhLGVBQWUsVUFBVTtFQUU1QyxNQUFNLE1BQU0sT0FBTyxLQUFLO0VBQ3hCLE1BQU0sV0FBVyxjQUFjLE9BQU8sS0FBSyxPQUFPO0VBQ2xELElBQUksUUFBUTtFQUNaLElBQUksUUFBUSxXQUFXLEtBQUs7RUFFNUIsSUFBSSxPQUFPLFNBQVMsT0FBTyxLQUFLLE1BQU0sWUFBWTtHQUNoRCxTQUFTLGNBQWMsT0FBTyxLQUFLLE9BQU87R0FDMUMsUUFBUSxTQUFTLEtBQUs7RUFDeEI7RUFFQSxNQUFNLE9BQU8sT0FBTyxLQUFLLGFBQWEsT0FBTyxVQUFVLE9BQU8sS0FBSztFQUNuRSxNQUFNLE9BQU8sT0FBTyxLQUFLLGFBQWEsT0FBTyxVQUFVLE9BQU8sS0FBSztFQUVuRSxJQUFJLFFBQVE7RUFDWixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksTUFBTSxLQUFLO0dBQzdCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxNQUFNLEtBQUs7SUFDN0IsSUFBSSxTQUFTLFFBQVE7SUFDckIsTUFBTSxJQUFJLFVBQVUsS0FBSyxRQUFRO0lBQ2pDLE1BQU0sSUFBSSxVQUFVLEtBQUssUUFBUTtJQUVqQyxJQUFJLFVBQVUsY0FBYyxHQUFHLEdBQUcsT0FBTyxLQUFLO0lBQzlDLElBQUksY0FBYztJQUNsQixJQUFJLFlBQVk7SUFDaEIsSUFBSSxXQUFXLEdBQUcsR0FBRyxPQUFPLEtBQUs7SUFDakM7R0FDRjtFQUNGOztFQUdBLElBQUksS0FBSztFQUNULElBQUksY0FBYztFQUNsQixJQUFJLFlBQVk7RUFDaEIsSUFBSSxZQUFZLENBQUMsR0FBRyxDQUFDLENBQUM7RUFDdEIsSUFBSSxVQUFVO0VBQ2QsSUFBSSxPQUFPLElBQUksZUFBZSxDQUFDO0VBQy9CLElBQUksT0FBTyxjQUFjLElBQUksZUFBZSxDQUFDO0VBQzdDLElBQUksT0FBTztFQUNYLElBQUksUUFBUTtDQUNkOztDQUdBLE1BQU0sZ0JBQWdCLE1BQTJDO0VBQy9ELE1BQU0sT0FBTyxFQUFFLE9BQU8sUUFBUTtFQUM5QixJQUFJLENBQUMsTUFBTTtFQUVYLE1BQU0sU0FBUyxJQUFJLFdBQVc7RUFDOUIsT0FBTyxVQUFVLFVBQVU7R0FDekIsTUFBTSxNQUFNLE1BQU0sUUFBUTtHQUMxQixZQUFZLEdBQUc7R0FDZixvQkFBb0IsR0FBRztHQUN2QixnQkFBZ0IsQ0FBQyxHQUFHLENBQUM7R0FDckIsZ0JBQWdCLENBQUM7R0FDakIsY0FBYyxDQUFHO0dBQ2pCLGFBQWE7SUFBRSxHQUFHO0lBQUcsR0FBRztHQUFFLENBQUM7R0FDM0IsYUFBYSxDQUFDLENBQUM7R0FDZixnQkFBZ0IsS0FBSztHQUNyQixjQUFjLElBQUk7R0FDbEIsZ0JBQWdCLGFBQWE7RUFDL0I7RUFDQSxPQUFPLGNBQWMsSUFBSTtFQUN6QixFQUFFLE9BQU8sUUFBUTtDQUNuQjs7Q0FHQSxNQUFNLDBCQUEwQjtFQUM5QixNQUFNLFNBQVMsbUJBQW1CO0VBQ2xDLElBQUksQ0FBQyxRQUFRO0VBRWIsSUFBSTtHQUNGLE1BQU0sVUFBVSxPQUFPLFVBQVUsY0FBYyxDQUFHO0dBQ2xELGdCQUFnQixTQUFTO0lBQ3ZCO0lBQ0EsT0FBTyxZQUFZLFlBQVksR0FBRyxPQUFPO0lBQ3pDLGFBQWE7R0FDZixDQUFDO0dBRUQsY0FBYyx1Q0FBdUMsWUFBWSxRQUFRLEtBQUssR0FBRyxDQUFDLENBQUMsWUFBWSxFQUFFLEtBQUssT0FBTyxTQUFTO0dBQ3RILGlCQUFpQixjQUFjLElBQUksR0FBRyxHQUFJO0VBQzVDLFNBQVMsR0FBRztHQUNWLFFBQVEsTUFBTSxDQUFDO0dBQ2YsT0FBTyxNQUFNO0VBQ2Y7Q0FDRjs7Q0FHQSxNQUFNLCtCQUErQjtFQUNuQyxNQUFNLFNBQVMsbUJBQW1CO0VBQ2xDLElBQUksQ0FBQyxRQUFRO0VBRWIsSUFBSTtHQUNGLE1BQU0sVUFBVSxPQUFPLFVBQVUsY0FBYyxHQUFJO0dBQ25ELE1BQU0sY0FBYyxZQUFZLFNBQVMsV0FBVztHQUNwRCxNQUFNLE9BQU8sWUFBWSxXQUFXLElBQUk7R0FFeEMsTUFBTSxNQUFNLElBQUksTUFBTTtJQUNwQixhQUFhLGNBQWMsY0FBYztJQUN6QyxNQUFNLE9BQU8sT0FBTztJQUNwQixRQUFRLE9BQU8sT0FBTyxDQUFDLEdBQUcsQ0FBQztHQUM3QixDQUFDO0dBRUQsSUFBSSxNQUFNO0lBQ1IsSUFBSSxTQUFTLFNBQVMsUUFBUSxHQUFHLEdBQUcsY0FBYyxNQUFNLEtBQUssY0FBYyxNQUFNLEdBQUc7R0FDdEYsT0FBTztJQUNMLElBQUksU0FBUyxTQUFTLFFBQVEsR0FBRyxHQUFHLGNBQWMsSUFBSSxHQUFHLGNBQWMsSUFBSSxDQUFDO0dBQzlFO0dBRUEsTUFBTSxXQUFXLFlBQVksWUFBWSxHQUFHLE9BQU8sVUFBVSxLQUFLLElBQUksRUFBRTtHQUN4RSxJQUFJLEtBQUssUUFBUTtHQUVqQixrQkFBa0I7SUFDaEIsSUFBSSxZQUFZLEtBQUssSUFBSTtJQUN6QixPQUFPO0lBQ1AsTUFBTTtJQUNOLE1BQU0sR0FBRyxZQUFZLFFBQVEsS0FBSyxHQUFHLEVBQUUsSUFBSSxPQUFPO0lBQ2xELFdBQVcsSUFBSSxLQUFLLENBQUMsQ0FBQyxtQkFBbUIsT0FBTztHQUNsRCxDQUFDO0VBQ0gsU0FBUyxHQUFHO0dBQ1YsUUFBUSxNQUFNLENBQUM7RUFDakI7Q0FDRjs7Q0FHQSxNQUFNLCtCQUErQjtFQUNuQyxNQUFNLFNBQVMsbUJBQW1CO0VBQ2xDLElBQUksQ0FBQyxRQUFRO0VBRWIsSUFBSTtHQUNGLE1BQU0sVUFBVSxPQUFPLFVBQVUsY0FBYyxHQUFJO0dBQ25ELE1BQU0sSUFBSSxTQUFTLGNBQWMsR0FBRztHQUNwQyxFQUFFLE9BQU87R0FDVCxNQUFNLFdBQVcsWUFBWSxZQUFZLEdBQUcsT0FBTyxpQkFBaUIsS0FBSyxJQUFJLEVBQUU7R0FDL0UsRUFBRSxXQUFXO0dBQ2IsRUFBRSxNQUFNO0dBRVIsa0JBQWtCO0lBQ2hCLElBQUksWUFBWSxLQUFLLElBQUk7SUFDekIsT0FBTztJQUNQLE1BQU07SUFDTixNQUFNLEdBQUcsWUFBWSxRQUFRLEtBQUssR0FBRyxFQUFFLElBQUksT0FBTztJQUNsRCxXQUFXLElBQUksS0FBSyxDQUFDLENBQUMsbUJBQW1CLE9BQU87R0FDbEQsQ0FBQztFQUNILFNBQVMsR0FBRztHQUNWLFFBQVEsTUFBTSxDQUFDO0VBQ2pCO0NBQ0Y7Q0FFQSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FFRSx3QkFBQyxVQUFEO0lBQVEsS0FBSztJQUFvQixXQUFVO0dBQVU7Ozs7O0dBR3BELGNBQ0Msd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxjQUFELEVBQWMsV0FBVSx5Q0FBMEM7Ozs7ZUFDbEUsd0JBQUMsUUFBRCxZQUFPLFdBQWlCOzs7O2FBQ3JCOzs7OztjQUNMLHdCQUFDLFVBQUQ7S0FBUSxlQUFlLGNBQWMsSUFBSTtLQUFHLFdBQVU7ZUFBb0M7SUFBUzs7OztZQUNoRzs7Ozs7O0dBSVAsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUVFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDYix3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBaEI7U0FDRyxlQUFlLFlBQVksd0JBQUMsUUFBRCxZQUFNLGlCQUFvQjs7Ozs7U0FDckQsZUFBZSxnQkFBZ0Isd0JBQUMsUUFBRCxZQUFNLHdCQUEyQjs7Ozs7U0FDaEUsZUFBZSxjQUFjLHdCQUFDLFFBQUQsWUFBTSxtQkFBc0I7Ozs7O1NBQ3pELGVBQWUsVUFBVSx3QkFBQyxRQUFELFlBQU0sdUJBQTBCOzs7OztTQUN6RCxlQUFlLG1CQUFtQix3QkFBQyxRQUFELFlBQU0sc0JBQXlCOzs7OztTQUNqRSxlQUFlLGtCQUFrQix3QkFBQyxRQUFELFlBQU0sd0JBQTJCOzs7OztTQUNsRSxlQUFlLGtCQUFrQix3QkFBQyxRQUFELFlBQU0sNkJBQWdDOzs7OztTQUN2RSxlQUFlLFVBQVUsd0JBQUMsUUFBRCxZQUFNLGlCQUFvQjs7Ozs7U0FDbkQsZUFBZSxVQUFVLHdCQUFDLFFBQUQsWUFBTSxjQUFpQjs7Ozs7UUFDN0M7Ozs7OztNQUNIOzs7OztNQUdKLGVBQWUsZ0JBQ2Qsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDRSx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBaUI7UUFBZ0I7Ozs7O1FBQ2pELHdCQUFDLFNBQUQ7U0FDRSxNQUFLO1NBQ0wsS0FBSTtTQUNKLEtBQUk7U0FDSixPQUFPO1NBQ1AsV0FBVyxNQUFNLGtCQUFrQixPQUFPLEVBQUUsT0FBTyxLQUFLLENBQUM7U0FDekQsV0FBVTtTQUNWLE9BQU07UUFDUDs7Ozs7UUFDRCx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBa0M7UUFBcUI7Ozs7O1FBRXZFLHdCQUFDLFVBQUQ7U0FDRSxTQUFTO1NBQ1QsVUFBVSxnQkFBZ0IsQ0FBQztTQUMzQixXQUFVO1NBQ1YsT0FBTTttQkFKUixDQU1FLHdCQUFDLFVBQUQsRUFBVSxXQUFVLGNBQWU7Ozs7bUJBQ25DLHdCQUFDLFFBQUQsWUFBTSxtQkFBc0I7Ozs7aUJBQ3RCOzs7Ozs7T0FDTDs7Ozs7O01BSU4sZUFBZSxjQUNkLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQWhCO1VBQ0csVUFBVTtVQUFPO1VBQVMsZUFBZSxrQkFBa0I7U0FDeEQ7Ozs7OztRQUVMLENBQUMsZ0JBQWdCLFVBQVUsVUFBVSxLQUNwQyx3QkFBQyxVQUFEO1NBQ0UsZUFBZSxnQkFBZ0IsSUFBSTtTQUNuQyxXQUFVO21CQUNYO1FBRU87Ozs7O1FBR1QsVUFBVSxVQUFVLEtBQ25CLHdCQUFDLFVBQUQ7U0FDRSxTQUFTO1NBQ1QsV0FBVTttQkFGWixDQUlFLHdCQUFDLE9BQUQsRUFBTyxXQUFVLGNBQWU7Ozs7bUJBQ2hDLHdCQUFDLFFBQUQsWUFBTSxlQUFrQjs7OztpQkFDbEI7Ozs7OztRQUdWLHdCQUFDLFVBQUQ7U0FDRSxlQUFlO1VBQUUsYUFBYSxDQUFDLENBQUM7VUFBRyxnQkFBZ0IsS0FBSztTQUFHO1NBQzNELFdBQVU7bUJBQ1g7UUFFTzs7Ozs7T0FDTDs7Ozs7O01BSU4sZUFBZSxVQUNkLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQXFFO1FBRS9FOzs7OztRQUNOLHdCQUFDLFVBQUQ7U0FDRSxTQUFTO1NBQ1QsV0FBVTttQkFDWDtRQUVPOzs7OztRQUNSLHdCQUFDLFVBQUQ7U0FDRSxlQUFlO1VBQUUsV0FBVyxJQUFJO1VBQUcsY0FBYyxRQUFRO1NBQUc7U0FDNUQsV0FBVTttQkFDWDtRQUVPOzs7OztPQUNMOzs7Ozs7T0FJTCxlQUFlLG1CQUFtQixlQUFlLGtCQUFrQixlQUFlLG1CQUNsRix3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNFLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFpQjtRQUFpQjs7Ozs7UUFDbEQsd0JBQUMsU0FBRDtTQUNFLE1BQUs7U0FDTCxLQUFJO1NBQ0osS0FBSTtTQUNKLE9BQU87U0FDUCxXQUFXLE1BQU0sYUFBYSxPQUFPLEVBQUUsT0FBTyxLQUFLLENBQUM7U0FDcEQsV0FBVTtRQUNYOzs7OztRQUNELHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFoQixDQUFrRCxXQUFVLElBQVE7Ozs7OztRQUNwRSx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBNkI7UUFBMkI7Ozs7O09BQ3JFOzs7Ozs7TUFJUCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFpQjtPQUFTOzs7O2lCQUN6QztRQUNDO1NBQUUsTUFBTTtTQUFTLE9BQU87UUFBVTtRQUNsQztTQUFFLE1BQU07U0FBWSxPQUFPO1FBQVU7UUFDckM7U0FBRSxNQUFNO1NBQWUsT0FBTztRQUFVO1FBQ3hDO1NBQUUsTUFBTTtTQUFRLE9BQU87UUFBVTtRQUNqQztTQUFFLE1BQU07U0FBTyxPQUFPO1FBQVU7T0FDbEMsQ0FBQyxDQUFDLEtBQUssTUFDTCx3QkFBQyxVQUFEO1FBRUUsZUFBZSxXQUFXLEVBQUUsS0FBSztRQUNqQyxXQUFXLDhEQUNULFlBQVksRUFBRSxRQUFRLCtDQUErQztRQUV2RSxPQUFPLEVBQUUsaUJBQWlCLEVBQUUsTUFBTTtRQUNsQyxPQUFPLCtCQUErQixFQUFFO09BQ3pDLEdBUE0sRUFBRTs7OztjQU9SLENBQ0YsQ0FDRTs7Ozs7O0tBQ0Y7Ozs7O2NBR0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUVFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsVUFBRDtRQUNFLFNBQVM7UUFDVCxVQUFVLGdCQUFnQixLQUFLLFVBQVUsV0FBVztRQUNwRCxXQUFVO1FBQ1YsT0FBTTtrQkFFTix3QkFBQyxPQUFELEVBQU8sV0FBVSxjQUFlOzs7OztPQUMxQjs7OztpQkFDUix3QkFBQyxVQUFEO1FBQ0UsU0FBUztRQUNULFVBQVUsZ0JBQWdCLGFBQWEsU0FBUztRQUNoRCxXQUFVO1FBQ1YsT0FBTTtrQkFFTix3QkFBQyxPQUFELEVBQU8sV0FBVSxjQUFlOzs7OztPQUMxQjs7OztlQUNMOzs7Ozs7TUFHTCx3QkFBQyxVQUFEO09BQ0UsZUFBZSxvQkFBbUIsU0FBUSxDQUFDLElBQUk7T0FDL0MsV0FBVywrRkFDVCxrQkFBa0IsaURBQWlEO09BRXJFLE9BQU07aUJBTFIsQ0FPRSx3QkFBQyxRQUFELEVBQVEsV0FBVSxjQUFlOzs7O2lCQUNqQyx3QkFBQyxRQUFELFlBQU0sbUJBQXNCOzs7O2VBQ3RCOzs7Ozs7TUFHUix3QkFBQyxVQUFEO09BQ0UsU0FBUztPQUNULFdBQVU7T0FDVixPQUFNO2lCQUhSLENBS0Usd0JBQUMsU0FBRCxFQUFTLFdBQVUseUJBQTBCOzs7O2lCQUM3Qyx3QkFBQyxRQUFELFlBQU0sMkJBQThCOzs7O2VBQzlCOzs7Ozs7S0FDTDs7Ozs7WUFDRjs7Ozs7O0dBR0wsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUVFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BRUc7UUFDQztTQUFFLElBQUk7U0FBVSxPQUFPO1NBQXNCLE1BQU07UUFBSztRQUN4RDtTQUFFLElBQUk7U0FBUSxPQUFPO1NBQXFCLE1BQU07UUFBSztRQUNyRDtTQUFFLElBQUk7U0FBYyxPQUFPO1NBQXdCLE1BQU07UUFBSztRQUM5RDtTQUFFLElBQUk7U0FBWSxPQUFPO1NBQXVCLE1BQU07UUFBTTtRQUM1RDtTQUFFLElBQUk7U0FBaUIsT0FBTztTQUEwQixNQUFNO1FBQUs7UUFDbkU7U0FBRSxJQUFJO1NBQWdCLE9BQU87U0FBcUIsTUFBTTtRQUFJO1FBQzVEO1NBQUUsSUFBSTtTQUFnQixPQUFPO1NBQTBCLE1BQU07UUFBTTtRQUNuRTtTQUFFLElBQUk7U0FBUSxPQUFPO1NBQTZCLE1BQU07UUFBSTtRQUM1RDtTQUFFLElBQUk7U0FBUSxPQUFPO1NBQWlCLE1BQU07UUFBSztPQUNuRCxDQUFDLENBQUMsS0FBSyxNQUFNO1FBQ1gsTUFBTSxXQUFXLGVBQWUsRUFBRTtRQUNsQyxPQUNFLHdCQUFDLFVBQUQ7U0FFRSxlQUFlO1VBQ2IsY0FBYyxFQUFFLEVBQWdCO1VBQ2hDLElBQUksRUFBRSxPQUFPLFFBQVEsWUFBWTtTQUNuQztTQUNBLFdBQVcsZ0ZBQ1QsV0FDSSx1RkFDQTtTQUVOLE9BQU8sRUFBRTttQkFFVCx3QkFBQyxRQUFELFlBQU8sRUFBRSxLQUFXOzs7OztRQUNkLEdBYkQsRUFBRTs7OztlQWFEO09BRVosQ0FBQztPQUVELHdCQUFDLE9BQUQsRUFBSyxXQUFVLHFEQUFzRDs7Ozs7T0FHckUsd0JBQUMsU0FBRDtRQUFPLFdBQVU7UUFBNkssT0FBTTtrQkFBcE0sQ0FDRSx3QkFBQyxRQUFELEVBQVEsV0FBVSxVQUFXOzs7O2tCQUM3Qix3QkFBQyxTQUFEO1NBQU8sTUFBSztTQUFPLFFBQU87U0FBVSxVQUFVO1NBQWMsV0FBVTtRQUFVOzs7O2dCQUMzRTs7Ozs7O01BQ0o7Ozs7OztLQUdMLHdCQUFDLE9BQUQ7TUFBSyxXQUFXLEdBQUcsa0JBQWtCLGtCQUFrQixpQkFBaUI7Z0JBQXhFO09BRUUsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBdUI7U0FBNkI7Ozs7O1NBQ3BFLHdCQUFDLFFBQUQsWUFBTSxJQUFPOzs7OztTQUNiLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFoQixDQUFvRCxLQUFLLE1BQU0sYUFBYSxHQUFHLEdBQUUsR0FBTzs7Ozs7O1NBQ3hGLHdCQUFDLFFBQUQsWUFBTSxJQUFPOzs7OztTQUNiLHdCQUFDLFFBQUQsWUFBTSw4Q0FBaUQ7Ozs7O1FBQ3BEOzs7Ozs7T0FHTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFDYix3QkFBQyxVQUFEO1NBQ0UsS0FBSztTQUNMLGFBQWE7U0FDYixhQUFhO1NBQ2IsV0FBVztTQUNYLGNBQWM7U0FDZCxTQUFTO1NBQ1QsV0FBVyxnRUFDVCxrQkFBa0IsZUFBZSxTQUM3Qix1Q0FDQSxlQUFlLGdCQUFnQixlQUFlLGFBQzlDLHFCQUNBLGVBQWUsbUJBQW1CLGVBQWUsa0JBQWtCLGVBQWUsaUJBQ2xGLGdCQUNBO1FBRVA7Ozs7O09BQ0U7Ozs7O09BR0wsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLFFBQUQsYUFBTSxVQUFNLHdCQUFDLFVBQUQ7VUFBUSxXQUFVO29CQUF3QixXQUFXLFFBQVEsS0FBSyxHQUFHO1NBQVU7Ozs7aUJBQU87Ozs7bUJBQ2pHLFlBQ0Msd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQWhCLENBQ0Usd0JBQUMsT0FBRCxFQUFPLFdBQVUsY0FBZTs7OztvQkFBQyw4QkFDN0I7Ozs7O2lCQUVMOzs7OztrQkFFTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZjtVQUNFLHdCQUFDLFVBQUQ7V0FDRSxlQUFlO1lBQUUsY0FBYyxDQUFHO1lBQUcsYUFBYTthQUFFLEdBQUc7YUFBRyxHQUFHO1lBQUUsQ0FBQztXQUFHO1dBQ25FLFdBQVU7cUJBQ1g7VUFFTzs7Ozs7VUFDUix3QkFBQyxVQUFEO1dBQ0UsZUFBZSxlQUFjLFNBQVEsS0FBSyxJQUFJLEdBQUssT0FBTyxHQUFJLENBQUM7V0FDL0QsV0FBVTtxQkFDWDtVQUVPOzs7OztVQUNSLHdCQUFDLFVBQUQ7V0FDRSxlQUFlLGVBQWMsU0FBUSxLQUFLLElBQUksSUFBSyxPQUFPLEdBQUksQ0FBQztXQUMvRCxXQUFVO3FCQUNYO1VBRU87Ozs7O1NBQ0w7Ozs7O2dCQUNGOzs7Ozs7TUFDRjs7Ozs7O0tBR0osbUJBQ0Msd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FFRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUNFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBb0M7V0FBd0I7Ozs7cUJBQzVFLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUNiLGdCQUFnQixrQkFBa0IsWUFBWTtXQUMzQzs7OzttQkFDSDs7Ozs7b0JBQ0wsd0JBQUMsVUFBRDtXQUNFLGVBQWUsbUJBQW1CLEtBQUs7V0FDdkMsV0FBVTtXQUNWLE9BQU07cUJBRU4sd0JBQUMsV0FBRCxFQUFXLFdBQVUsY0FBZTs7Ozs7VUFDOUI7Ozs7a0JBQ0w7Ozs7OztTQUdMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUNiLHdCQUFDLFVBQUQ7V0FDRSxLQUFLO1dBQ0wsT0FBTztXQUNQLFFBQVE7V0FDUixXQUFVO1VBQ1g7Ozs7O1NBQ0U7Ozs7O1NBR0wsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxVQUFEO1dBQ0UsZUFBZTtZQUFFLGVBQWUsZUFBZTtZQUFHLFVBQVUsQ0FBQztXQUFHO1dBQ2hFLFdBQVcsdUVBQ1QsZ0JBQWdCLGtCQUNaLGtDQUNBO3FCQUVQO1VBRU87Ozs7b0JBQ1Isd0JBQUMsVUFBRDtXQUNFLGVBQWU7WUFBRSxlQUFlLGNBQWM7WUFBRyxVQUFVLEVBQUU7V0FBRztXQUNoRSxXQUFXLHVFQUNULGdCQUFnQixpQkFDWixvQ0FDQTtxQkFFUDtVQUVPOzs7O2tCQUNMOzs7Ozs7U0FHTCx3QkFBQyxVQUFEO1VBQ0UsU0FBUztVQUNULFdBQVU7b0JBRlosQ0FJRSx3QkFBQyxTQUFELEVBQVMsV0FBVSxjQUFlOzs7O29CQUNsQyx3QkFBQyxRQUFELFlBQU0sc0JBQXlCOzs7O2tCQUN6Qjs7Ozs7O1FBQ0w7Ozs7OztPQUdMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBaEIsQ0FDRSx3QkFBQyxVQUFELEVBQVUsV0FBVSw2QkFBOEI7Ozs7b0JBQ2xELHdCQUFDLFFBQUQsWUFBTSxzQkFBeUI7Ozs7a0JBQzNCOzs7OzttQkFDTix3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBNkU7U0FFdkY7Ozs7aUJBQ0g7Ozs7O2tCQUVMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUNaLGVBQWUsS0FBSyxNQUFNO1VBQ3pCLE1BQU0sYUFBYSxpQkFBaUIsRUFBRSxNQUFNO1VBQzVDLE9BQ0Usd0JBQUMsVUFBRDtXQUVFLGVBQWU7WUFDYixnQkFBZ0IsRUFBRSxFQUFFO1lBQ3BCLGNBQWMsRUFBRSxTQUFTLFVBQVU7WUFDbkMsWUFBWSxFQUFFLFNBQVMsUUFBUTtZQUMvQixjQUFjLEVBQUUsU0FBUyxVQUFVO1lBQ25DLFVBQVUsRUFBRSxTQUFTLE1BQU07WUFDM0IsUUFBUSxFQUFFLFNBQVMsSUFBSTtZQUN2QixjQUFjLEVBQUUsU0FBUyxVQUFVO1lBQ25DLFlBQVksRUFBRSxTQUFTLFFBQVE7WUFDL0IsY0FBYyxFQUFFLFNBQVMsVUFBVTtZQUNuQyxlQUFlLEVBQUUsU0FBUyxXQUFXO1lBQ3JDLGNBQWMsSUFBSTtXQUNwQjtXQUNBLFdBQVcsa0RBQ1QsYUFDSSw0RUFDQTtxQkFHTix3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZixDQUNFLHdCQUFDLFFBQUQsWUFBTyxFQUFFLEtBQVc7Ozs7c0JBQ3BCLHdCQUFDLFFBQUQ7YUFBTSxXQUFVO3VCQUFZLEVBQUU7WUFBVzs7OztvQkFDdEM7Ozs7OztVQUNDLEdBeEJELEVBQUU7Ozs7aUJBd0JEO1NBRVosQ0FBQztRQUNFOzs7O2dCQUNGOzs7Ozs7T0FHTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUNFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQWhCLENBQ0Usd0JBQUMsU0FBRCxFQUFTLFdBQVUsNEJBQTZCOzs7O3FCQUNoRCx3QkFBQyxRQUFELFlBQU0sdUJBQTBCOzs7O21CQUM1Qjs7Ozs7b0JBQ04sd0JBQUMsVUFBRDtXQUNFLGVBQWU7WUFDYixjQUFjLENBQUM7WUFDZixZQUFZLENBQUM7WUFDYixjQUFjLENBQUM7WUFDZixVQUFVLENBQUM7WUFDWCxRQUFRLENBQUM7WUFDVCxjQUFjLENBQUM7WUFDZixZQUFZLENBQUM7WUFDYixlQUFlLEtBQUs7V0FDdEI7V0FDQSxXQUFVO3FCQUNYO1VBRU87Ozs7a0JBQ0w7Ozs7OztTQUdMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUErQjtVQUFvQjs7OztvQkFDbkUsd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQWhCLENBQXdDLFlBQVcsR0FBTzs7Ozs7a0JBQ3ZEOzs7OzttQkFDTCx3QkFBQyxTQUFEO1VBQ0UsTUFBSztVQUNMLEtBQUk7VUFDSixLQUFJO1VBQ0osT0FBTztVQUNQLFdBQVcsTUFBTSxjQUFjLE9BQU8sRUFBRSxPQUFPLEtBQUssQ0FBQztVQUNyRCxXQUFVO1NBQ1g7Ozs7aUJBQ0U7Ozs7O1NBR0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsUUFBRCxZQUFNLGFBQWdCOzs7O29CQUN0Qix3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBaEIsQ0FBd0MsYUFBYSxJQUFJLElBQUksZUFBZSxZQUFXLEdBQU87Ozs7O2tCQUMzRjs7Ozs7bUJBQ0wsd0JBQUMsU0FBRDtVQUNFLE1BQUs7VUFDTCxLQUFJO1VBQ0osS0FBSTtVQUNKLE9BQU87VUFDUCxXQUFXLE1BQU0sY0FBYyxPQUFPLEVBQUUsT0FBTyxLQUFLLENBQUM7VUFDckQsV0FBVTtTQUNYOzs7O2lCQUNFOzs7OztTQUdMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLFFBQUQsWUFBTSxXQUFjOzs7O29CQUNwQix3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBaEIsQ0FBd0MsV0FBVyxJQUFJLElBQUksYUFBYSxVQUFTLEdBQU87Ozs7O2tCQUNyRjs7Ozs7bUJBQ0wsd0JBQUMsU0FBRDtVQUNFLE1BQUs7VUFDTCxLQUFJO1VBQ0osS0FBSTtVQUNKLE9BQU87VUFDUCxXQUFXLE1BQU0sWUFBWSxPQUFPLEVBQUUsT0FBTyxLQUFLLENBQUM7VUFDbkQsV0FBVTtTQUNYOzs7O2lCQUNFOzs7OztTQUdMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLFFBQUQsWUFBTSxnQkFBbUI7Ozs7b0JBQ3pCLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUF3QixTQUFTLElBQUksSUFBSSxXQUFXO1VBQWE7Ozs7a0JBQzlFOzs7OzttQkFDTCx3QkFBQyxTQUFEO1VBQ0UsTUFBSztVQUNMLEtBQUk7VUFDSixLQUFJO1VBQ0osT0FBTztVQUNQLFdBQVcsTUFBTSxVQUFVLE9BQU8sRUFBRSxPQUFPLEtBQUssQ0FBQztVQUNqRCxXQUFVO1NBQ1g7Ozs7aUJBQ0U7Ozs7O1NBR0wsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxTQUFEO1dBQU8sV0FBVTtxQkFBakIsQ0FDRSx3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBMkI7V0FBNEI7Ozs7cUJBQ3ZFLHdCQUFDLFNBQUQ7WUFDRSxNQUFLO1lBQ0wsU0FBUztZQUNULFdBQVcsTUFBTSxnQkFBZ0IsRUFBRSxPQUFPLE9BQU87WUFDakQsV0FBVTtXQUNYOzs7O21CQUNJOzs7OztvQkFDTixnQkFDQyx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNFLHdCQUFDLFNBQUQ7WUFDRSxNQUFLO1lBQ0wsYUFBWTtZQUNaLE9BQU87WUFDUCxXQUFXLE1BQU0saUJBQWlCLEVBQUUsT0FBTyxLQUFLO1lBQ2hELFdBQVU7V0FDWDs7OztxQkFDRCx3QkFBQyxTQUFEO1lBQ0UsTUFBSztZQUNMLGFBQVk7WUFDWixPQUFPO1lBQ1AsV0FBVyxNQUFNLGFBQWEsRUFBRSxPQUFPLEtBQUs7WUFDNUMsV0FBVTtXQUNYOzs7O21CQUNFOzs7OztrQkFFSjs7Ozs7O1FBQ0Y7Ozs7OztNQUNGOzs7Ozs7SUFFSjs7Ozs7O0VBQ0Y7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlBhc3Nwb3J0U3R1ZGlvVmlldy50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlLCB1c2VSZWYsIHVzZUVmZmVjdCwgdXNlQ2FsbGJhY2sgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBcbiAgVXBsb2FkLCBcbiAgUHJpbnRlciwgXG4gIERvd25sb2FkLCBcbiAgU3BhcmtsZXMsIFxuICBSb3RhdGVDdywgXG4gIFpvb21JbiwgXG4gIFpvb21PdXQsXG4gIFBhbGV0dGUsIFxuICBDYWxlbmRhciwgXG4gIFN1biwgXG4gIENvbnRyYXN0LCBcbiAgQ2hlY2tDaXJjbGUyLCBcbiAgU2Npc3NvcnMsXG4gIFdhbmQyLFxuICBTbGlkZXJzLFxuICBGbGFtZSxcbiAgRHJvcGxldHMsXG4gIFJvdGF0ZUNjdyxcbiAgQ2hlY2ssXG4gIFBlblRvb2wsXG4gIE1vdmUsXG4gIFVuZG8yLFxuICBSZWRvMixcbiAgVHJhc2gyLFxuICBFeWUsXG4gIExheWVycyxcbiAgSGVscENpcmNsZSxcbiAgWCxcbiAgTWF4aW1pemUyLFxuICBNaW5pbWl6ZTIsXG4gIENyb3AsXG4gIFBhaW50YnJ1c2gsXG4gIFNwYXJrbGUsXG4gIEltYWdlIGFzIEltYWdlSWNvbixcbiAgQ2hlY2tTcXVhcmVcbn0gZnJvbSAnbHVjaWRlLXJlYWN0JztcbmltcG9ydCB7IGpzUERGIH0gZnJvbSAnanNwZGYnO1xuaW1wb3J0IHsgYWRkRG93bmxvYWRSZWNvcmQgfSBmcm9tICcuLi91dGlscy9zdG9yYWdlJztcbmltcG9ydCB7IHByaW50SW1hZ2VTaGVldCB9IGZyb20gJy4uL3V0aWxzL3ByaW50ZXInO1xuXG50eXBlIFBhcGVyRm9ybWF0ID0gJzR4Nl9sYW5kc2NhcGUnIHwgJ2E0X2xhbmRzY2FwZScgfCAnNHg2X3BvcnRyYWl0JyB8ICdhNF9wb3J0cmFpdCc7XG50eXBlIEFjdGl2ZVRvb2wgPSAnc2VsZWN0JyB8ICdtYWdpY193YW5kJyB8ICdwZW5fdG9vbCcgfCAnY3JvcCcgfCAnYmxlbWlzaF9icnVzaCcgfCAnYmVhdXR5X2JydXNoJyB8ICdleWVfYnJpZ2h0ZW4nIHwgJ2hhbmQnIHwgJ3pvb20nO1xuXG5pbnRlcmZhY2UgUG9pbnQge1xuICB4OiBudW1iZXI7XG4gIHk6IG51bWJlcjtcbn1cblxuaW50ZXJmYWNlIEJlYXV0eVByZXNldCB7XG4gIGlkOiBzdHJpbmc7XG4gIG5hbWU6IHN0cmluZztcbiAgaWNvbjogc3RyaW5nO1xuICBkZXNjOiBzdHJpbmc7XG4gIHNldHRpbmdzOiB7XG4gICAgYnJpZ2h0bmVzczogbnVtYmVyO1xuICAgIGNvbnRyYXN0OiBudW1iZXI7XG4gICAgc2F0dXJhdGlvbjogbnVtYmVyO1xuICAgIHdhcm10aDogbnVtYmVyO1xuICAgIHRpbnQ6IG51bWJlcjtcbiAgICBza2luU21vb3RoOiBudW1iZXI7XG4gICAgZmFjZUdsb3c6IG51bWJlcjtcbiAgICBzaGFkb3dMaWZ0OiBudW1iZXI7XG4gICAgaXNHcmF5c2NhbGU6IGJvb2xlYW47XG4gIH07XG59XG5cbmNvbnN0IEJFQVVUWV9QUkVTRVRTOiBCZWF1dHlQcmVzZXRbXSA9IFtcbiAge1xuICAgIGlkOiAnYXV0b19iZWF1dHknLFxuICAgIG5hbWU6ICdBdXRvIFN0dWRpbyBCZWF1dHknLFxuICAgIGljb246ICfinKgnLFxuICAgIGRlc2M6ICdTbW9vdGggc2tpbiAmIHJhZGlhbnQgZmFjaWFsIGxpZ2h0aW5nJyxcbiAgICBzZXR0aW5nczoge1xuICAgICAgYnJpZ2h0bmVzczogOCxcbiAgICAgIGNvbnRyYXN0OiA2LFxuICAgICAgc2F0dXJhdGlvbjogMTIsXG4gICAgICB3YXJtdGg6IDgsXG4gICAgICB0aW50OiA0LFxuICAgICAgc2tpblNtb290aDogMjAsXG4gICAgICBmYWNlR2xvdzogMjUsXG4gICAgICBzaGFkb3dMaWZ0OiAxNSxcbiAgICAgIGlzR3JheXNjYWxlOiBmYWxzZVxuICAgIH1cbiAgfSxcbiAge1xuICAgIGlkOiAnaW5kaWFuX3dhcm0nLFxuICAgIG5hbWU6ICdJbmRpYW4gU3R1ZGlvIFRvbmUnLFxuICAgIGljb246ICfwn5O4JyxcbiAgICBkZXNjOiAnR29sZGVuIHdhcm0gZ2xvdywgcmVtb3ZlcyBjYW1lcmEgcGFsZSB0b25lJyxcbiAgICBzZXR0aW5nczoge1xuICAgICAgYnJpZ2h0bmVzczogNixcbiAgICAgIGNvbnRyYXN0OiA4LFxuICAgICAgc2F0dXJhdGlvbjogMTUsXG4gICAgICB3YXJtdGg6IDE4LFxuICAgICAgdGludDogMixcbiAgICAgIHNraW5TbW9vdGg6IDE2LFxuICAgICAgZmFjZUdsb3c6IDIwLFxuICAgICAgc2hhZG93TGlmdDogMTIsXG4gICAgICBpc0dyYXlzY2FsZTogZmFsc2VcbiAgICB9XG4gIH0sXG4gIHtcbiAgICBpZDogJ2dsYW1vdXJfc29mdCcsXG4gICAgbmFtZTogJ1NvZnQgR2xhbW91ciBHbG93JyxcbiAgICBpY29uOiAn8J+MnycsXG4gICAgZGVzYzogJ0FpcmJydXNoZWQgcG9yY2VsYWluIHNraW4gd2l0aCBzb2Z0IGhpZ2hsaWdodHMnLFxuICAgIHNldHRpbmdzOiB7XG4gICAgICBicmlnaHRuZXNzOiAxMixcbiAgICAgIGNvbnRyYXN0OiA0LFxuICAgICAgc2F0dXJhdGlvbjogOCxcbiAgICAgIHdhcm10aDogMTAsXG4gICAgICB0aW50OiA2LFxuICAgICAgc2tpblNtb290aDogMzIsXG4gICAgICBmYWNlR2xvdzogMzUsXG4gICAgICBzaGFkb3dMaWZ0OiAyMCxcbiAgICAgIGlzR3JheXNjYWxlOiBmYWxzZVxuICAgIH1cbiAgfSxcbiAge1xuICAgIGlkOiAnY3Jpc3BfZm9ybWFsJyxcbiAgICBuYW1lOiAnU2hhcnAgRm9ybWFsIElEJyxcbiAgICBpY29uOiAn8J+SvCcsXG4gICAgZGVzYzogJ05ldXRyYWwgd2hpdGUgYmFsYW5jZSAmIGNyaXNwIGZhY2lhbCBlZGdlcycsXG4gICAgc2V0dGluZ3M6IHtcbiAgICAgIGJyaWdodG5lc3M6IDQsXG4gICAgICBjb250cmFzdDogMTIsXG4gICAgICBzYXR1cmF0aW9uOiA1LFxuICAgICAgd2FybXRoOiAwLFxuICAgICAgdGludDogMCxcbiAgICAgIHNraW5TbW9vdGg6IDgsXG4gICAgICBmYWNlR2xvdzogMTAsXG4gICAgICBzaGFkb3dMaWZ0OiA4LFxuICAgICAgaXNHcmF5c2NhbGU6IGZhbHNlXG4gICAgfVxuICB9LFxuICB7XG4gICAgaWQ6ICdjb29sX2NsZWFuJyxcbiAgICBuYW1lOiAnQ29vbCBXaGl0ZSBCYWxhbmNlJyxcbiAgICBpY29uOiAn4p2E77iPJyxcbiAgICBkZXNjOiAnUmVtb3ZlcyB5ZWxsb3cvb3JhbmdlIGxpZ2h0aW5nIGNhc3QnLFxuICAgIHNldHRpbmdzOiB7XG4gICAgICBicmlnaHRuZXNzOiA4LFxuICAgICAgY29udHJhc3Q6IDgsXG4gICAgICBzYXR1cmF0aW9uOiA0LFxuICAgICAgd2FybXRoOiAtMTQsXG4gICAgICB0aW50OiAtMixcbiAgICAgIHNraW5TbW9vdGg6IDE0LFxuICAgICAgZmFjZUdsb3c6IDE1LFxuICAgICAgc2hhZG93TGlmdDogMTAsXG4gICAgICBpc0dyYXlzY2FsZTogZmFsc2VcbiAgICB9XG4gIH0sXG4gIHtcbiAgICBpZDogJ2J3X2Zvcm1hbCcsXG4gICAgbmFtZTogJ0ImVyBPZmZpY2lhbCBFeGFtJyxcbiAgICBpY29uOiAn8J+WpCcsXG4gICAgZGVzYzogJ0hpZ2ggY29udHJhc3QgbW9ub2Nocm9tZSBmb3IgU1NDL1VQU0MnLFxuICAgIHNldHRpbmdzOiB7XG4gICAgICBicmlnaHRuZXNzOiA2LFxuICAgICAgY29udHJhc3Q6IDE2LFxuICAgICAgc2F0dXJhdGlvbjogMCxcbiAgICAgIHdhcm10aDogMCxcbiAgICAgIHRpbnQ6IDAsXG4gICAgICBza2luU21vb3RoOiAxMixcbiAgICAgIGZhY2VHbG93OiAxMCxcbiAgICAgIHNoYWRvd0xpZnQ6IDEwLFxuICAgICAgaXNHcmF5c2NhbGU6IHRydWVcbiAgICB9XG4gIH1cbl07XG5cbmV4cG9ydCBjb25zdCBQYXNzcG9ydFN0dWRpb1ZpZXc6IFJlYWN0LkZDID0gKCkgPT4ge1xuICAvLyBNYWluIFNoZWV0IENhbnZhcyAoSGlkZGVuIG9yIHJlbmRlcmVkIGZvciA0eDYgLyBBNCBzaGVldCBjYWxjdWxhdGlvbilcbiAgY29uc3QgZnVsbFNoZWV0Q2FudmFzUmVmID0gdXNlUmVmPEhUTUxDYW52YXNFbGVtZW50IHwgbnVsbD4obnVsbCk7XG4gIFxuICAvLyBQaG90b3Nob3AtU3R5bGUgRWRpdGluZyBDYW52YXMgKFByaW1hcnkgaW50ZXJhY3RpdmUgd29ya3NwYWNlKVxuICBjb25zdCBlZGl0b3JDYW52YXNSZWYgPSB1c2VSZWY8SFRNTENhbnZhc0VsZW1lbnQgfCBudWxsPihudWxsKTtcbiAgXG4gIC8vIE1pbmkgUHJldmlldyBDYW52YXMgKENvbXBhY3QgU2hlZXQgUHJldmlldyB3aWRnZXQpXG4gIGNvbnN0IG1pbmlQcmV2aWV3Q2FudmFzUmVmID0gdXNlUmVmPEhUTUxDYW52YXNFbGVtZW50IHwgbnVsbD4obnVsbCk7XG5cbiAgLy8gQWN0aXZlIFRvb2wgU2VsZWN0aW9uIChQaG90b3Nob3AgVG9vbGJhcilcbiAgY29uc3QgW2FjdGl2ZVRvb2wsIHNldEFjdGl2ZVRvb2xdID0gdXNlU3RhdGU8QWN0aXZlVG9vbD4oJ3NlbGVjdCcpO1xuXG4gIC8vIFBob3RvIFNvdXJjZSAmIEhpc3RvcnkgU3RhY2sgZm9yIFVuZG8gLyBSZWRvXG4gIGNvbnN0IFtwaG90b1NyYywgc2V0UGhvdG9TcmNdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IFtvcmlnaW5hbFBob3RvU3JjLCBzZXRPcmlnaW5hbFBob3RvU3JjXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbaGlzdG9yeVN0YWNrLCBzZXRIaXN0b3J5U3RhY2tdID0gdXNlU3RhdGU8c3RyaW5nW10+KFtdKTtcbiAgY29uc3QgW2hpc3RvcnlJbmRleCwgc2V0SGlzdG9yeUluZGV4XSA9IHVzZVN0YXRlPG51bWJlcj4oLTEpO1xuXG4gIGNvbnN0IHBob3RvSW1nUmVmID0gdXNlUmVmPEhUTUxJbWFnZUVsZW1lbnQgfCBudWxsPihudWxsKTtcblxuICAvLyBQYXBlciAmIExheW91dCBzZXR0aW5nczogRGVmYXVsdCBpcyA0eDYgTEFORFNDQVBFIHdpdGggOCBDT1BJRVNcbiAgY29uc3QgW3BhcGVyRm9ybWF0LCBzZXRQYXBlckZvcm1hdF0gPSB1c2VTdGF0ZTxQYXBlckZvcm1hdD4oJzR4Nl9sYW5kc2NhcGUnKTtcbiAgY29uc3QgW2NvcGllcywgc2V0Q29waWVzXSA9IHVzZVN0YXRlPG51bWJlcj4oOCk7XG5cbiAgLy8gU3R1ZGlvIGJhY2tncm91bmQgcmVwbGFjZW1lbnQgY29sb3JcbiAgY29uc3QgW2JnQ29sb3IsIHNldEJnQ29sb3JdID0gdXNlU3RhdGU8c3RyaW5nPignI2ZmZmZmZicpO1xuXG4gIC8vIE1pbmkgUHJldmlldyBWaXNpYmlsaXR5IFN0YXRlIChDb2xsYXBzaWJsZSAvIEV4cGFuZGFibGUpXG4gIGNvbnN0IFtzaG93TWluaVByZXZpZXcsIHNldFNob3dNaW5pUHJldmlld10gPSB1c2VTdGF0ZTxib29sZWFuPih0cnVlKTtcblxuICAvLyBBdXRvIEJlYXV0eSBNb2RlIFRvZ2dsZVxuICBjb25zdCBbYXV0b0JlYXV0eSwgc2V0QXV0b0JlYXV0eV0gPSB1c2VTdGF0ZTxib29sZWFuPih0cnVlKTtcbiAgY29uc3QgW2FjdGl2ZVByZXNldCwgc2V0QWN0aXZlUHJlc2V0XSA9IHVzZVN0YXRlPHN0cmluZz4oJ2F1dG9fYmVhdXR5Jyk7XG5cbiAgLy8gQ29sb3IgR3JhZGluZyBQYXJhbWV0ZXJzXG4gIGNvbnN0IFticmlnaHRuZXNzLCBzZXRCcmlnaHRuZXNzXSA9IHVzZVN0YXRlPG51bWJlcj4oOCk7XG4gIGNvbnN0IFtjb250cmFzdCwgc2V0Q29udHJhc3RdID0gdXNlU3RhdGU8bnVtYmVyPig2KTtcbiAgY29uc3QgW3NhdHVyYXRpb24sIHNldFNhdHVyYXRpb25dID0gdXNlU3RhdGU8bnVtYmVyPigxMik7XG4gIGNvbnN0IFt3YXJtdGgsIHNldFdhcm10aF0gPSB1c2VTdGF0ZTxudW1iZXI+KDgpO1xuICBjb25zdCBbdGludCwgc2V0VGludF0gPSB1c2VTdGF0ZTxudW1iZXI+KDQpO1xuICBjb25zdCBbc2hhZG93TGlmdCwgc2V0U2hhZG93TGlmdF0gPSB1c2VTdGF0ZTxudW1iZXI+KDE1KTtcbiAgY29uc3QgW3NraW5TbW9vdGgsIHNldFNraW5TbW9vdGhdID0gdXNlU3RhdGU8bnVtYmVyPigyMCk7XG4gIGNvbnN0IFtmYWNlR2xvdywgc2V0RmFjZUdsb3ddID0gdXNlU3RhdGU8bnVtYmVyPigyNSk7XG4gIGNvbnN0IFtpc0dyYXlzY2FsZSwgc2V0SXNHcmF5c2NhbGVdID0gdXNlU3RhdGU8Ym9vbGVhbj4oZmFsc2UpO1xuXG4gIC8vIENhbnZhcyBWaWV3cG9ydCBQYW4gJiBab29tXG4gIGNvbnN0IFtjYW52YXNab29tLCBzZXRDYW52YXNab29tXSA9IHVzZVN0YXRlPG51bWJlcj4oMS4wKTtcbiAgY29uc3QgW2NhbnZhc1Bhbiwgc2V0Q2FudmFzUGFuXSA9IHVzZVN0YXRlPHsgeDogbnVtYmVyOyB5OiBudW1iZXIgfT4oeyB4OiAwLCB5OiAwIH0pO1xuICBjb25zdCBbaXNTcGFjZVByZXNzZWQsIHNldElzU3BhY2VQcmVzc2VkXSA9IHVzZVN0YXRlPGJvb2xlYW4+KGZhbHNlKTtcbiAgY29uc3QgW2lzUGFubmluZywgc2V0SXNQYW5uaW5nXSA9IHVzZVN0YXRlPGJvb2xlYW4+KGZhbHNlKTtcbiAgY29uc3QgW3BhblN0YXJ0LCBzZXRQYW5TdGFydF0gPSB1c2VTdGF0ZTx7IHg6IG51bWJlcjsgeTogbnVtYmVyIH0+KHsgeDogMCwgeTogMCB9KTtcblxuICAvLyBUb29sIFNwZWNpZmljIFN0YXRlczpcbiAgLy8gMS4gTWFnaWMgV2FuZCAvIE1hZ2ljIEN1dFxuICBjb25zdCBbbWFnaWNUb2xlcmFuY2UsIHNldE1hZ2ljVG9sZXJhbmNlXSA9IHVzZVN0YXRlPG51bWJlcj4oMzIpO1xuICBjb25zdCBbbWFnaWNGZWF0aGVyLCBzZXRNYWdpY0ZlYXRoZXJdID0gdXNlU3RhdGU8bnVtYmVyPigyKTtcblxuICAvLyAyLiBQZW4gVG9vbCAoTWFudWFsIFZlY3RvciBDdXRvdXQpXG4gIGNvbnN0IFtwZW5Qb2ludHMsIHNldFBlblBvaW50c10gPSB1c2VTdGF0ZTxQb2ludFtdPihbXSk7XG4gIGNvbnN0IFtpc1BhdGhDbG9zZWQsIHNldElzUGF0aENsb3NlZF0gPSB1c2VTdGF0ZTxib29sZWFuPihmYWxzZSk7XG4gIGNvbnN0IFtpc05lYXJTdGFydFBvaW50LCBzZXRJc05lYXJTdGFydFBvaW50XSA9IHVzZVN0YXRlPGJvb2xlYW4+KGZhbHNlKTtcbiAgY29uc3QgW3BlbkZlYXRoZXIsIHNldFBlbkZlYXRoZXJdID0gdXNlU3RhdGU8bnVtYmVyPigyKTtcblxuICAvLyAzLiBCcnVzaGVzIChCbGVtaXNoLCBCZWF1dHksIEV5ZSBCcmlnaHRlbilcbiAgY29uc3QgW2JydXNoU2l6ZSwgc2V0QnJ1c2hTaXplXSA9IHVzZVN0YXRlPG51bWJlcj4oMjQpO1xuICBjb25zdCBbaXNCcnVzaGluZywgc2V0SXNCcnVzaGluZ10gPSB1c2VTdGF0ZTxib29sZWFuPihmYWxzZSk7XG5cbiAgLy8gNC4gQ3JvcCBUb29sXG4gIGNvbnN0IFtjcm9wQm94LCBzZXRDcm9wQm94XSA9IHVzZVN0YXRlPHsgeDogbnVtYmVyOyB5OiBudW1iZXI7IHc6IG51bWJlcjsgaDogbnVtYmVyIH0gfCBudWxsPihudWxsKTtcblxuICAvLyBFeGFtIE5hbWUgJiBEYXRlIG92ZXJsYXkgKGZvciBTU0MsIFBvbGljZSBCaGFydGksIFVQU0MpXG4gIGNvbnN0IFtzaG93TmFtZURhdGUsIHNldFNob3dOYW1lRGF0ZV0gPSB1c2VTdGF0ZTxib29sZWFuPihmYWxzZSk7XG4gIGNvbnN0IFtjYW5kaWRhdGVOYW1lLCBzZXRDYW5kaWRhdGVOYW1lXSA9IHVzZVN0YXRlPHN0cmluZz4oJ0NBTkRJREFURSBOQU1FJyk7XG4gIGNvbnN0IFtwaG90b0RhdGUsIHNldFBob3RvRGF0ZV0gPSB1c2VTdGF0ZTxzdHJpbmc+KFxuICAgIG5ldyBEYXRlKCkudG9Mb2NhbGVEYXRlU3RyaW5nKCdlbi1JTicsIHsgZGF5OiAnMi1kaWdpdCcsIG1vbnRoOiAnMi1kaWdpdCcsIHllYXI6ICdudW1lcmljJyB9KVxuICApO1xuXG4gIGNvbnN0IFtpc1Byb2Nlc3NpbmcsIHNldElzUHJvY2Vzc2luZ10gPSB1c2VTdGF0ZTxib29sZWFuPihmYWxzZSk7XG4gIGNvbnN0IFtwcmludEFsZXJ0LCBzZXRQcmludEFsZXJ0XSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuXG4gIC8vIDMwMCBEUEkgQ2FudmFzIERpbWVuc2lvbnMgZm9yIGZ1bGwgc2hlZXRcbiAgbGV0IFNIRUVUX1dJRFRIID0gMTgwMDtcbiAgbGV0IFNIRUVUX0hFSUdIVCA9IDEyMDA7XG5cbiAgaWYgKHBhcGVyRm9ybWF0ID09PSAnNHg2X2xhbmRzY2FwZScpIHtcbiAgICBTSEVFVF9XSURUSCA9IDE4MDA7XG4gICAgU0hFRVRfSEVJR0hUID0gMTIwMDtcbiAgfSBlbHNlIGlmIChwYXBlckZvcm1hdCA9PT0gJ2E0X2xhbmRzY2FwZScpIHtcbiAgICBTSEVFVF9XSURUSCA9IDM1MDg7XG4gICAgU0hFRVRfSEVJR0hUID0gMjQ4MDtcbiAgfSBlbHNlIGlmIChwYXBlckZvcm1hdCA9PT0gJzR4Nl9wb3J0cmFpdCcpIHtcbiAgICBTSEVFVF9XSURUSCA9IDEyMDA7XG4gICAgU0hFRVRfSEVJR0hUID0gMTgwMDtcbiAgfSBlbHNlIHtcbiAgICBTSEVFVF9XSURUSCA9IDI0ODA7XG4gICAgU0hFRVRfSEVJR0hUID0gMzUwODtcbiAgfVxuXG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy8gS0VZQk9BUkQgU0hPUlRDVVRTIExJU1RFTkVSIChQaG90b3Nob3AgU3RhbmRhcmQ6IFYsIEMsIFcsIFAsIEIsIFMsIEgsIFosIEN0cmwrWiwgQ3RybCtQKVxuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3QgaGFuZGxlS2V5RG93biA9IChlOiBLZXlib2FyZEV2ZW50KSA9PiB7XG4gICAgICAvLyBEb24ndCB0cmlnZ2VyIGlmIHVzZXIgaXMgdHlwaW5nIGluIHRleHQgaW5wdXRcbiAgICAgIGlmICgoZS50YXJnZXQgYXMgSFRNTEVsZW1lbnQpLnRhZ05hbWUgPT09ICdJTlBVVCcgfHwgKGUudGFyZ2V0IGFzIEhUTUxFbGVtZW50KS50YWdOYW1lID09PSAnVEVYVEFSRUEnKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cblxuICAgICAgLy8gU3BhY2ViYXIgZm9yIHRlbXBvcmFyeSBIYW5kIFBhbiB0b29sXG4gICAgICBpZiAoZS5jb2RlID09PSAnU3BhY2UnICYmICFlLnJlcGVhdCkge1xuICAgICAgICBzZXRJc1NwYWNlUHJlc3NlZCh0cnVlKTtcbiAgICAgIH1cblxuICAgICAgLy8gVW5kbzogQ3RybCArIFpcbiAgICAgIGlmIChlLmN0cmxLZXkgJiYgZS5rZXkudG9Mb3dlckNhc2UoKSA9PT0gJ3onICYmICFlLnNoaWZ0S2V5KSB7XG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgaGFuZGxlVW5kbygpO1xuICAgICAgfVxuXG4gICAgICAvLyBSZWRvOiBDdHJsICsgWSBvciBDdHJsICsgU2hpZnQgKyBaXG4gICAgICBpZiAoKGUuY3RybEtleSAmJiBlLmtleS50b0xvd2VyQ2FzZSgpID09PSAneScpIHx8IChlLmN0cmxLZXkgJiYgZS5zaGlmdEtleSAmJiBlLmtleS50b0xvd2VyQ2FzZSgpID09PSAneicpKSB7XG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgaGFuZGxlUmVkbygpO1xuICAgICAgfVxuXG4gICAgICAvLyBUb29scyBTd2l0Y2hlciBTaG9ydGN1dHM6XG4gICAgICBpZiAoIWUuY3RybEtleSAmJiAhZS5hbHRLZXkgJiYgIWUubWV0YUtleSkge1xuICAgICAgICBzd2l0Y2ggKGUua2V5LnRvTG93ZXJDYXNlKCkpIHtcbiAgICAgICAgICBjYXNlICd2Jzogc2V0QWN0aXZlVG9vbCgnc2VsZWN0Jyk7IGJyZWFrO1xuICAgICAgICAgIGNhc2UgJ2MnOiBzZXRBY3RpdmVUb29sKCdjcm9wJyk7IGluaXRDcm9wQm94KCk7IGJyZWFrO1xuICAgICAgICAgIGNhc2UgJ3cnOiBzZXRBY3RpdmVUb29sKCdtYWdpY193YW5kJyk7IGJyZWFrO1xuICAgICAgICAgIGNhc2UgJ3AnOiBzZXRBY3RpdmVUb29sKCdwZW5fdG9vbCcpOyBicmVhaztcbiAgICAgICAgICBjYXNlICdiJzogc2V0QWN0aXZlVG9vbCgnYmxlbWlzaF9icnVzaCcpOyBicmVhaztcbiAgICAgICAgICBjYXNlICdzJzogc2V0QWN0aXZlVG9vbCgnYmVhdXR5X2JydXNoJyk7IGJyZWFrO1xuICAgICAgICAgIGNhc2UgJ2UnOiBzZXRBY3RpdmVUb29sKCdleWVfYnJpZ2h0ZW4nKTsgYnJlYWs7XG4gICAgICAgICAgY2FzZSAnaCc6IHNldEFjdGl2ZVRvb2woJ2hhbmQnKTsgYnJlYWs7XG4gICAgICAgICAgY2FzZSAneic6IHNldEFjdGl2ZVRvb2woJ3pvb20nKTsgYnJlYWs7XG4gICAgICAgICAgY2FzZSAnbSc6IHNldFNob3dNaW5pUHJldmlldyhwcmV2ID0+ICFwcmV2KTsgYnJlYWs7XG4gICAgICAgICAgY2FzZSAnWyc6IHNldEJydXNoU2l6ZShwcmV2ID0+IE1hdGgubWF4KDgsIHByZXYgLSA0KSk7IGJyZWFrO1xuICAgICAgICAgIGNhc2UgJ10nOiBzZXRCcnVzaFNpemUocHJldiA9PiBNYXRoLm1pbig4MCwgcHJldiArIDQpKTsgYnJlYWs7XG4gICAgICAgICAgY2FzZSAnZXNjYXBlJzogXG4gICAgICAgICAgICBpZiAoYWN0aXZlVG9vbCA9PT0gJ3Blbl90b29sJykge1xuICAgICAgICAgICAgICBzZXRQZW5Qb2ludHMoW10pO1xuICAgICAgICAgICAgICBzZXRJc1BhdGhDbG9zZWQoZmFsc2UpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGFjdGl2ZVRvb2wgPT09ICdjcm9wJykge1xuICAgICAgICAgICAgICBzZXRDcm9wQm94KG51bGwpO1xuICAgICAgICAgICAgICBzZXRBY3RpdmVUb29sKCdzZWxlY3QnKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIC8vIFpvb20gU2hvcnRjdXRzOiBDdHJsICsgJysnIC8gQ3RybCArICctJyAvIEN0cmwgKyAnMCdcbiAgICAgIGlmIChlLmN0cmxLZXkgJiYgKGUua2V5ID09PSAnPScgfHwgZS5rZXkgPT09ICcrJykpIHtcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICBzZXRDYW52YXNab29tKHByZXYgPT4gTWF0aC5taW4oNC4wLCBwcmV2ICsgMC4yNSkpO1xuICAgICAgfVxuICAgICAgaWYgKGUuY3RybEtleSAmJiAoZS5rZXkgPT09ICctJyB8fCBlLmtleSA9PT0gJ18nKSkge1xuICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgIHNldENhbnZhc1pvb20ocHJldiA9PiBNYXRoLm1heCgwLjQsIHByZXYgLSAwLjI1KSk7XG4gICAgICB9XG4gICAgICBpZiAoZS5jdHJsS2V5ICYmIGUua2V5ID09PSAnMCcpIHtcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICBzZXRDYW52YXNab29tKDEuMCk7XG4gICAgICAgIHNldENhbnZhc1Bhbih7IHg6IDAsIHk6IDAgfSk7XG4gICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZUtleVVwID0gKGU6IEtleWJvYXJkRXZlbnQpID0+IHtcbiAgICAgIGlmIChlLmNvZGUgPT09ICdTcGFjZScpIHtcbiAgICAgICAgc2V0SXNTcGFjZVByZXNzZWQoZmFsc2UpO1xuICAgICAgICBzZXRJc1Bhbm5pbmcoZmFsc2UpO1xuICAgICAgfVxuICAgIH07XG5cbiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcigna2V5ZG93bicsIGhhbmRsZUtleURvd24pO1xuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdrZXl1cCcsIGhhbmRsZUtleVVwKTtcbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ2tleWRvd24nLCBoYW5kbGVLZXlEb3duKTtcbiAgICAgIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKCdrZXl1cCcsIGhhbmRsZUtleVVwKTtcbiAgICB9O1xuICB9LCBbYWN0aXZlVG9vbCwgaGlzdG9yeUluZGV4LCBoaXN0b3J5U3RhY2tdKTtcblxuICAvLyBQdXNoIG5ldyBzdGF0ZSB0byB1bmRvL3JlZG8gaGlzdG9yeVxuICBjb25zdCBwdXNoVG9IaXN0b3J5ID0gKG5ld1NyYzogc3RyaW5nKSA9PiB7XG4gICAgc2V0SGlzdG9yeVN0YWNrKHByZXYgPT4ge1xuICAgICAgY29uc3QgdXBUb0N1cnJlbnQgPSBwcmV2LnNsaWNlKDAsIGhpc3RvcnlJbmRleCArIDEpO1xuICAgICAgY29uc3QgdXBkYXRlZCA9IFsuLi51cFRvQ3VycmVudCwgbmV3U3JjXTtcbiAgICAgIGlmICh1cGRhdGVkLmxlbmd0aCA+IDE1KSB1cGRhdGVkLnNoaWZ0KCk7XG4gICAgICByZXR1cm4gdXBkYXRlZDtcbiAgICB9KTtcbiAgICBzZXRIaXN0b3J5SW5kZXgocHJldiA9PiBNYXRoLm1pbigxNCwgcHJldiArIDEpKTtcbiAgfTtcblxuICBjb25zdCBoYW5kbGVVbmRvID0gKCkgPT4ge1xuICAgIGlmIChhY3RpdmVUb29sID09PSAncGVuX3Rvb2wnICYmIHBlblBvaW50cy5sZW5ndGggPiAwKSB7XG4gICAgICBpZiAoaXNQYXRoQ2xvc2VkKSB7XG4gICAgICAgIHNldElzUGF0aENsb3NlZChmYWxzZSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBzZXRQZW5Qb2ludHMocHJldiA9PiBwcmV2LnNsaWNlKDAsIC0xKSk7XG4gICAgICB9XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgaWYgKGhpc3RvcnlJbmRleCA+IDApIHtcbiAgICAgIGNvbnN0IG5leHRJZHggPSBoaXN0b3J5SW5kZXggLSAxO1xuICAgICAgc2V0SGlzdG9yeUluZGV4KG5leHRJZHgpO1xuICAgICAgc2V0UGhvdG9TcmMoaGlzdG9yeVN0YWNrW25leHRJZHhdKTtcbiAgICB9XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlUmVkbyA9ICgpID0+IHtcbiAgICBpZiAoaGlzdG9yeUluZGV4IDwgaGlzdG9yeVN0YWNrLmxlbmd0aCAtIDEpIHtcbiAgICAgIGNvbnN0IG5leHRJZHggPSBoaXN0b3J5SW5kZXggKyAxO1xuICAgICAgc2V0SGlzdG9yeUluZGV4KG5leHRJZHgpO1xuICAgICAgc2V0UGhvdG9TcmMoaGlzdG9yeVN0YWNrW25leHRJZHhdKTtcbiAgICB9XG4gIH07XG5cbiAgLy8gTG9hZCBwaG90byBpbnRvIEltYWdlIG9iamVjdFxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChwaG90b1NyYykge1xuICAgICAgY29uc3QgaW1nID0gbmV3IEltYWdlKCk7XG4gICAgICBpbWcuY3Jvc3NPcmlnaW4gPSAnYW5vbnltb3VzJztcbiAgICAgIGltZy5vbmxvYWQgPSAoKSA9PiB7XG4gICAgICAgIHBob3RvSW1nUmVmLmN1cnJlbnQgPSBpbWc7XG4gICAgICAgIHJlbmRlckVkaXRvckNhbnZhcygpO1xuICAgICAgICByZW5kZXJNaW5pUHJldmlldygpO1xuICAgICAgICByZW5kZXJGdWxsU2hlZXQoKTtcbiAgICAgIH07XG4gICAgICBpbWcuc3JjID0gcGhvdG9TcmM7XG4gICAgfSBlbHNlIHtcbiAgICAgIHBob3RvSW1nUmVmLmN1cnJlbnQgPSBudWxsO1xuICAgICAgcmVuZGVyRWRpdG9yQ2FudmFzKCk7XG4gICAgICByZW5kZXJNaW5pUHJldmlldygpO1xuICAgICAgcmVuZGVyRnVsbFNoZWV0KCk7XG4gICAgfVxuICB9LCBbcGhvdG9TcmNdKTtcblxuICAvLyBSZS1yZW5kZXIgd2hlbiBhZGp1c3RtZW50cyBjaGFuZ2VcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICByZW5kZXJFZGl0b3JDYW52YXMoKTtcbiAgICByZW5kZXJNaW5pUHJldmlldygpO1xuICAgIHJlbmRlckZ1bGxTaGVldCgpO1xuICB9LCBbXG4gICAgcGhvdG9TcmMsXG4gICAgYWN0aXZlVG9vbCxcbiAgICBwZW5Qb2ludHMsXG4gICAgaXNQYXRoQ2xvc2VkLFxuICAgIGlzTmVhclN0YXJ0UG9pbnQsXG4gICAgY3JvcEJveCxcbiAgICBjYW52YXNab29tLFxuICAgIGNhbnZhc1BhbixcbiAgICBiZ0NvbG9yLFxuICAgIGF1dG9CZWF1dHksXG4gICAgYnJpZ2h0bmVzcyxcbiAgICBjb250cmFzdCxcbiAgICBzYXR1cmF0aW9uLFxuICAgIHdhcm10aCxcbiAgICB0aW50LFxuICAgIHNoYWRvd0xpZnQsXG4gICAgc2tpblNtb290aCxcbiAgICBmYWNlR2xvdyxcbiAgICBpc0dyYXlzY2FsZSxcbiAgICBwYXBlckZvcm1hdCxcbiAgICBjb3BpZXMsXG4gICAgc2hvd05hbWVEYXRlLFxuICAgIGNhbmRpZGF0ZU5hbWUsXG4gICAgcGhvdG9EYXRlXG4gIF0pO1xuXG4gIC8vIEluaXRpYWxpemUgY3JvcCBib3ggdG8gMzU6NDUgcmF0aW9cbiAgY29uc3QgaW5pdENyb3BCb3ggPSAoKSA9PiB7XG4gICAgY29uc3QgY2FudmFzID0gZWRpdG9yQ2FudmFzUmVmLmN1cnJlbnQ7XG4gICAgaWYgKCFjYW52YXMpIHJldHVybjtcbiAgICBjb25zdCB3ID0gTWF0aC5taW4oY2FudmFzLndpZHRoICogMC43LCBjYW52YXMuaGVpZ2h0ICogMC43ICogKDM1IC8gNDUpKTtcbiAgICBjb25zdCBoID0gdyAqICg0NSAvIDM1KTtcbiAgICBzZXRDcm9wQm94KHtcbiAgICAgIHg6IChjYW52YXMud2lkdGggLSB3KSAvIDIsXG4gICAgICB5OiAoY2FudmFzLmhlaWdodCAtIGgpIC8gMixcbiAgICAgIHcsXG4gICAgICBoXG4gICAgfSk7XG4gIH07XG5cbiAgLy8gQXBwbHkgQ3JvcFxuICBjb25zdCBoYW5kbGVBcHBseUNyb3AgPSAoKSA9PiB7XG4gICAgY29uc3QgY2FudmFzID0gZWRpdG9yQ2FudmFzUmVmLmN1cnJlbnQ7XG4gICAgY29uc3QgaW1nID0gcGhvdG9JbWdSZWYuY3VycmVudDtcbiAgICBpZiAoIWNhbnZhcyB8fCAhaW1nIHx8ICFjcm9wQm94KSByZXR1cm47XG5cbiAgICB0cnkge1xuICAgICAgY29uc3QgY3JvcENhbnZhcyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2NhbnZhcycpO1xuICAgICAgY3JvcENhbnZhcy53aWR0aCA9IDcwMDtcbiAgICAgIGNyb3BDYW52YXMuaGVpZ2h0ID0gOTAwO1xuICAgICAgY29uc3QgY0N0eCA9IGNyb3BDYW52YXMuZ2V0Q29udGV4dCgnMmQnKTtcbiAgICAgIGlmICghY0N0eCkgcmV0dXJuO1xuXG4gICAgICAvLyBFeHRyYWN0IGNyb3BwZWQgYXJlYSBmcm9tIGVkaXRvciBjYW52YXNcbiAgICAgIGNDdHguZHJhd0ltYWdlKFxuICAgICAgICBjYW52YXMsXG4gICAgICAgIGNyb3BCb3gueCxcbiAgICAgICAgY3JvcEJveC55LFxuICAgICAgICBjcm9wQm94LncsXG4gICAgICAgIGNyb3BCb3guaCxcbiAgICAgICAgMCxcbiAgICAgICAgMCxcbiAgICAgICAgY3JvcENhbnZhcy53aWR0aCxcbiAgICAgICAgY3JvcENhbnZhcy5oZWlnaHRcbiAgICAgICk7XG5cbiAgICAgIGNvbnN0IGNyb3BwZWRVcmwgPSBjcm9wQ2FudmFzLnRvRGF0YVVSTCgnaW1hZ2UvanBlZycsIDAuOTgpO1xuICAgICAgc2V0UGhvdG9TcmMoY3JvcHBlZFVybCk7XG4gICAgICBwdXNoVG9IaXN0b3J5KGNyb3BwZWRVcmwpO1xuICAgICAgc2V0Q3JvcEJveChudWxsKTtcbiAgICAgIHNldEFjdGl2ZVRvb2woJ3NlbGVjdCcpO1xuICAgICAgc2V0UHJpbnRBbGVydCgn4pyC77iPIFBob3RvIGNyb3BwZWQgdG8gMzXDlzQ1bW0gcGFzc3BvcnQgcmF0aW8hJyk7XG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHNldFByaW50QWxlcnQobnVsbCksIDMwMDApO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoZSk7XG4gICAgfVxuICB9O1xuXG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy8gTUFHSUMgV0FORCAvIE1BR0lDIENVVCAoRklYRUQgJiBISUdILVBSRUNJU0lPTiBGTE9PRCBGSUxMKVxuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vIEJGUyBDb25uZWN0ZWQgRmxvb2QtRmlsbCBmcm9tIGNsaWNrZWQgcGl4ZWxcbiAgY29uc3QgZXhlY3V0ZU1hZ2ljV2FuZEN1dCA9IChjbGlja1g6IG51bWJlciwgY2xpY2tZOiBudW1iZXIpID0+IHtcbiAgICBjb25zdCBpbWcgPSBwaG90b0ltZ1JlZi5jdXJyZW50O1xuICAgIGlmICghaW1nKSByZXR1cm47XG5cbiAgICBzZXRJc1Byb2Nlc3NpbmcodHJ1ZSk7XG5cbiAgICB0cnkge1xuICAgICAgY29uc3Qgd29ya0NhbnZhcyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2NhbnZhcycpO1xuICAgICAgd29ya0NhbnZhcy53aWR0aCA9IGltZy53aWR0aDtcbiAgICAgIHdvcmtDYW52YXMuaGVpZ2h0ID0gaW1nLmhlaWdodDtcbiAgICAgIGNvbnN0IHdDdHggPSB3b3JrQ2FudmFzLmdldENvbnRleHQoJzJkJyk7XG4gICAgICBpZiAoIXdDdHgpIHJldHVybjtcblxuICAgICAgd0N0eC5kcmF3SW1hZ2UoaW1nLCAwLCAwKTtcbiAgICAgIGNvbnN0IGltZ0RhdGEgPSB3Q3R4LmdldEltYWdlRGF0YSgwLCAwLCB3b3JrQ2FudmFzLndpZHRoLCB3b3JrQ2FudmFzLmhlaWdodCk7XG4gICAgICBjb25zdCBkYXRhID0gaW1nRGF0YS5kYXRhO1xuICAgICAgY29uc3QgdyA9IHdvcmtDYW52YXMud2lkdGg7XG4gICAgICBjb25zdCBoID0gd29ya0NhbnZhcy5oZWlnaHQ7XG5cbiAgICAgIC8vIFNjYWxlIGNsaWNrWCwgY2xpY2tZIHRvIG9yaWdpbmFsIGltYWdlIHBpeGVsc1xuICAgICAgY29uc3Qgc3RhcnRYID0gTWF0aC5mbG9vcihNYXRoLm1heCgwLCBNYXRoLm1pbih3IC0gMSwgY2xpY2tYKSkpO1xuICAgICAgY29uc3Qgc3RhcnRZID0gTWF0aC5mbG9vcihNYXRoLm1heCgwLCBNYXRoLm1pbihoIC0gMSwgY2xpY2tZKSkpO1xuICAgICAgY29uc3Qgc3RhcnRJbmRleCA9IChzdGFydFkgKiB3ICsgc3RhcnRYKSAqIDQ7XG5cbiAgICAgIGNvbnN0IHRhcmdldFIgPSBkYXRhW3N0YXJ0SW5kZXhdO1xuICAgICAgY29uc3QgdGFyZ2V0RyA9IGRhdGFbc3RhcnRJbmRleCArIDFdO1xuICAgICAgY29uc3QgdGFyZ2V0QiA9IGRhdGFbc3RhcnRJbmRleCArIDJdO1xuXG4gICAgICAvLyBQYXJzZSB0YXJnZXQgYmFja2dyb3VuZCBjb2xvclxuICAgICAgY29uc3QgZHVtbXkgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICAgIGR1bW15LnN0eWxlLmNvbG9yID0gYmdDb2xvcjtcbiAgICAgIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQoZHVtbXkpO1xuICAgICAgY29uc3QgY29tcHV0ZWQgPSB3aW5kb3cuZ2V0Q29tcHV0ZWRTdHlsZShkdW1teSkuY29sb3I7XG4gICAgICBkb2N1bWVudC5ib2R5LnJlbW92ZUNoaWxkKGR1bW15KTtcbiAgICAgIGNvbnN0IHJnYiA9IGNvbXB1dGVkLm1hdGNoKC9cXGQrL2cpPy5tYXAoTnVtYmVyKSB8fCBbMjU1LCAyNTUsIDI1NV07XG5cbiAgICAgIC8vIFZpc2l0ZWQgYXJyYXkgdG8gcHJldmVudCBpbmZpbml0ZSBsb29wXG4gICAgICBjb25zdCB2aXNpdGVkID0gbmV3IFVpbnQ4QXJyYXkodyAqIGgpO1xuICAgICAgY29uc3QgcXVldWU6IG51bWJlcltdID0gW3N0YXJ0WCArIHN0YXJ0WSAqIHddO1xuICAgICAgdmlzaXRlZFtzdGFydFggKyBzdGFydFkgKiB3XSA9IDE7XG5cbiAgICAgIGNvbnN0IHRvbFNxID0gTWF0aC5wb3cobWFnaWNUb2xlcmFuY2UgKiAyLjIsIDIpO1xuXG4gICAgICAvLyBCRlMgZmxvb2QgZmlsbFxuICAgICAgbGV0IGhlYWQgPSAwO1xuICAgICAgd2hpbGUgKGhlYWQgPCBxdWV1ZS5sZW5ndGgpIHtcbiAgICAgICAgY29uc3QgY3VyciA9IHF1ZXVlW2hlYWQrK107XG4gICAgICAgIGNvbnN0IGN4ID0gY3VyciAlIHc7XG4gICAgICAgIGNvbnN0IGN5ID0gTWF0aC5mbG9vcihjdXJyIC8gdyk7XG4gICAgICAgIGNvbnN0IGlkeCA9IGN1cnIgKiA0O1xuXG4gICAgICAgIC8vIFJlcGxhY2UgcGl4ZWwgY29sb3Igd2l0aCBzdHVkaW8gYmFja2dyb3VuZFxuICAgICAgICBkYXRhW2lkeF0gPSByZ2JbMF07XG4gICAgICAgIGRhdGFbaWR4ICsgMV0gPSByZ2JbMV07XG4gICAgICAgIGRhdGFbaWR4ICsgMl0gPSByZ2JbMl07XG4gICAgICAgIGRhdGFbaWR4ICsgM10gPSAyNTU7XG5cbiAgICAgICAgLy8gQ2hlY2sgNC1kaXJlY3Rpb25hbCBuZWlnaGJvcnNcbiAgICAgICAgY29uc3QgbmVpZ2hib3JzID0gW1xuICAgICAgICAgIFtjeCArIDEsIGN5XSxcbiAgICAgICAgICBbY3ggLSAxLCBjeV0sXG4gICAgICAgICAgW2N4LCBjeSArIDFdLFxuICAgICAgICAgIFtjeCwgY3kgLSAxXVxuICAgICAgICBdO1xuXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgNDsgaSsrKSB7XG4gICAgICAgICAgY29uc3QgbnggPSBuZWlnaGJvcnNbaV1bMF07XG4gICAgICAgICAgY29uc3QgbnkgPSBuZWlnaGJvcnNbaV1bMV07XG5cbiAgICAgICAgICBpZiAobnggPj0gMCAmJiBueCA8IHcgJiYgbnkgPj0gMCAmJiBueSA8IGgpIHtcbiAgICAgICAgICAgIGNvbnN0IG5Qb3MgPSBueCArIG55ICogdztcbiAgICAgICAgICAgIGlmICghdmlzaXRlZFtuUG9zXSkge1xuICAgICAgICAgICAgICBjb25zdCBuSWR4ID0gblBvcyAqIDQ7XG4gICAgICAgICAgICAgIGNvbnN0IG5yID0gZGF0YVtuSWR4XTtcbiAgICAgICAgICAgICAgY29uc3QgbmcgPSBkYXRhW25JZHggKyAxXTtcbiAgICAgICAgICAgICAgY29uc3QgbmIgPSBkYXRhW25JZHggKyAyXTtcblxuICAgICAgICAgICAgICAvLyBDb2xvciBkaXN0YW5jZSBmcm9tIHRhcmdldFxuICAgICAgICAgICAgICBjb25zdCBkaXN0U3EgPVxuICAgICAgICAgICAgICAgIE1hdGgucG93KG5yIC0gdGFyZ2V0UiwgMikgK1xuICAgICAgICAgICAgICAgIE1hdGgucG93KG5nIC0gdGFyZ2V0RywgMikgK1xuICAgICAgICAgICAgICAgIE1hdGgucG93KG5iIC0gdGFyZ2V0QiwgMik7XG5cbiAgICAgICAgICAgICAgaWYgKGRpc3RTcSA8PSB0b2xTcSkge1xuICAgICAgICAgICAgICAgIHZpc2l0ZWRbblBvc10gPSAxO1xuICAgICAgICAgICAgICAgIHF1ZXVlLnB1c2goblBvcyk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgd0N0eC5wdXRJbWFnZURhdGEoaW1nRGF0YSwgMCwgMCk7XG4gICAgICBjb25zdCByZXNEYXRhVXJsID0gd29ya0NhbnZhcy50b0RhdGFVUkwoJ2ltYWdlL2pwZWcnLCAwLjk4KTtcblxuICAgICAgaWYgKCFvcmlnaW5hbFBob3RvU3JjICYmIHBob3RvU3JjKSB7XG4gICAgICAgIHNldE9yaWdpbmFsUGhvdG9TcmMocGhvdG9TcmMpO1xuICAgICAgfVxuXG4gICAgICBzZXRQaG90b1NyYyhyZXNEYXRhVXJsKTtcbiAgICAgIHB1c2hUb0hpc3RvcnkocmVzRGF0YVVybCk7XG4gICAgICBzZXRQcmludEFsZXJ0KGDwn6qEIE1hZ2ljIFdhbmQgZXJhc2VkIGNvbm5lY3RlZCBiYWNrZ3JvdW5kIGF0ICgke3N0YXJ0WH0sICR7c3RhcnRZfSkhYCk7XG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHNldFByaW50QWxlcnQobnVsbCksIDMwMDApO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoZSk7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldElzUHJvY2Vzc2luZyhmYWxzZSk7XG4gICAgfVxuICB9O1xuXG4gIC8vIDEtQ2xpY2sgQXV0byBCYWNrZ3JvdW5kIEVyYXNlciAoU2VlZHMgZmxvb2QgZmlsbCBmcm9tIGFsbCA0IG91dGVyIGJvcmRlcnMpXG4gIGNvbnN0IGhhbmRsZUF1dG9CYWNrZ3JvdW5kRXJhc2UgPSAoKSA9PiB7XG4gICAgY29uc3QgaW1nID0gcGhvdG9JbWdSZWYuY3VycmVudDtcbiAgICBpZiAoIWltZykgcmV0dXJuO1xuXG4gICAgc2V0SXNQcm9jZXNzaW5nKHRydWUpO1xuXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHdvcmtDYW52YXMgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdjYW52YXMnKTtcbiAgICAgIHdvcmtDYW52YXMud2lkdGggPSBpbWcud2lkdGg7XG4gICAgICB3b3JrQ2FudmFzLmhlaWdodCA9IGltZy5oZWlnaHQ7XG4gICAgICBjb25zdCB3Q3R4ID0gd29ya0NhbnZhcy5nZXRDb250ZXh0KCcyZCcpO1xuICAgICAgaWYgKCF3Q3R4KSByZXR1cm47XG5cbiAgICAgIHdDdHguZHJhd0ltYWdlKGltZywgMCwgMCk7XG4gICAgICBjb25zdCBpbWdEYXRhID0gd0N0eC5nZXRJbWFnZURhdGEoMCwgMCwgd29ya0NhbnZhcy53aWR0aCwgd29ya0NhbnZhcy5oZWlnaHQpO1xuICAgICAgY29uc3QgZGF0YSA9IGltZ0RhdGEuZGF0YTtcbiAgICAgIGNvbnN0IHcgPSB3b3JrQ2FudmFzLndpZHRoO1xuICAgICAgY29uc3QgaCA9IHdvcmtDYW52YXMuaGVpZ2h0O1xuXG4gICAgICAvLyBUYXJnZXQgYmFja2dyb3VuZCBjb2xvciBwYXJzZVxuICAgICAgY29uc3QgZHVtbXkgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICAgIGR1bW15LnN0eWxlLmNvbG9yID0gYmdDb2xvcjtcbiAgICAgIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQoZHVtbXkpO1xuICAgICAgY29uc3QgY29tcHV0ZWQgPSB3aW5kb3cuZ2V0Q29tcHV0ZWRTdHlsZShkdW1teSkuY29sb3I7XG4gICAgICBkb2N1bWVudC5ib2R5LnJlbW92ZUNoaWxkKGR1bW15KTtcbiAgICAgIGNvbnN0IHJnYiA9IGNvbXB1dGVkLm1hdGNoKC9cXGQrL2cpPy5tYXAoTnVtYmVyKSB8fCBbMjU1LCAyNTUsIDI1NV07XG5cbiAgICAgIC8vIFNhbXBsZSByZWZlcmVuY2UgYmFja2dyb3VuZCBjb2xvciBmcm9tIHRvcCBjb3JuZXJzXG4gICAgICBjb25zdCBjb3JuZXJSID0gKGRhdGFbMF0gKyBkYXRhWyh3IC0gMSkgKiA0XSkgLyAyO1xuICAgICAgY29uc3QgY29ybmVyRyA9IChkYXRhWzFdICsgZGF0YVsodyAtIDEpICogNCArIDFdKSAvIDI7XG4gICAgICBjb25zdCBjb3JuZXJCID0gKGRhdGFbMl0gKyBkYXRhWyh3IC0gMSkgKiA0ICsgMl0pIC8gMjtcblxuICAgICAgY29uc3QgdmlzaXRlZCA9IG5ldyBVaW50OEFycmF5KHcgKiBoKTtcbiAgICAgIGNvbnN0IHF1ZXVlOiBudW1iZXJbXSA9IFtdO1xuXG4gICAgICAvLyBTZWVkIGFsbCA0IG91dGVyIGJvcmRlcnNcbiAgICAgIGZvciAobGV0IHggPSAwOyB4IDwgdzsgeCsrKSB7XG4gICAgICAgIHF1ZXVlLnB1c2goeCk7IC8vIHRvcFxuICAgICAgICBxdWV1ZS5wdXNoKHggKyAoaCAtIDEpICogdyk7IC8vIGJvdHRvbVxuICAgICAgICB2aXNpdGVkW3hdID0gMTtcbiAgICAgICAgdmlzaXRlZFt4ICsgKGggLSAxKSAqIHddID0gMTtcbiAgICAgIH1cbiAgICAgIGZvciAobGV0IHkgPSAwOyB5IDwgaDsgeSsrKSB7XG4gICAgICAgIHF1ZXVlLnB1c2goeSAqIHcpOyAvLyBsZWZ0XG4gICAgICAgIHF1ZXVlLnB1c2goKHcgLSAxKSArIHkgKiB3KTsgLy8gcmlnaHRcbiAgICAgICAgdmlzaXRlZFt5ICogd10gPSAxO1xuICAgICAgICB2aXNpdGVkWyh3IC0gMSkgKyB5ICogd10gPSAxO1xuICAgICAgfVxuXG4gICAgICBjb25zdCB0b2xTcSA9IE1hdGgucG93KG1hZ2ljVG9sZXJhbmNlICogMi4yLCAyKTtcblxuICAgICAgbGV0IGhlYWQgPSAwO1xuICAgICAgd2hpbGUgKGhlYWQgPCBxdWV1ZS5sZW5ndGgpIHtcbiAgICAgICAgY29uc3QgY3VyciA9IHF1ZXVlW2hlYWQrK107XG4gICAgICAgIGNvbnN0IGN4ID0gY3VyciAlIHc7XG4gICAgICAgIGNvbnN0IGN5ID0gTWF0aC5mbG9vcihjdXJyIC8gdyk7XG4gICAgICAgIGNvbnN0IGlkeCA9IGN1cnIgKiA0O1xuXG4gICAgICAgIC8vIFJlcGxhY2UgYmFja2dyb3VuZCBwaXhlbFxuICAgICAgICBkYXRhW2lkeF0gPSByZ2JbMF07XG4gICAgICAgIGRhdGFbaWR4ICsgMV0gPSByZ2JbMV07XG4gICAgICAgIGRhdGFbaWR4ICsgMl0gPSByZ2JbMl07XG4gICAgICAgIGRhdGFbaWR4ICsgM10gPSAyNTU7XG5cbiAgICAgICAgY29uc3QgbmVpZ2hib3JzID0gW1xuICAgICAgICAgIFtjeCArIDEsIGN5XSxcbiAgICAgICAgICBbY3ggLSAxLCBjeV0sXG4gICAgICAgICAgW2N4LCBjeSArIDFdLFxuICAgICAgICAgIFtjeCwgY3kgLSAxXVxuICAgICAgICBdO1xuXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgNDsgaSsrKSB7XG4gICAgICAgICAgY29uc3QgbnggPSBuZWlnaGJvcnNbaV1bMF07XG4gICAgICAgICAgY29uc3QgbnkgPSBuZWlnaGJvcnNbaV1bMV07XG5cbiAgICAgICAgICBpZiAobnggPj0gMCAmJiBueCA8IHcgJiYgbnkgPj0gMCAmJiBueSA8IGgpIHtcbiAgICAgICAgICAgIGNvbnN0IG5Qb3MgPSBueCArIG55ICogdztcbiAgICAgICAgICAgIGlmICghdmlzaXRlZFtuUG9zXSkge1xuICAgICAgICAgICAgICBjb25zdCBuSWR4ID0gblBvcyAqIDQ7XG4gICAgICAgICAgICAgIGNvbnN0IG5yID0gZGF0YVtuSWR4XTtcbiAgICAgICAgICAgICAgY29uc3QgbmcgPSBkYXRhW25JZHggKyAxXTtcbiAgICAgICAgICAgICAgY29uc3QgbmIgPSBkYXRhW25JZHggKyAyXTtcblxuICAgICAgICAgICAgICBjb25zdCBkaXN0U3EgPVxuICAgICAgICAgICAgICAgIE1hdGgucG93KG5yIC0gY29ybmVyUiwgMikgK1xuICAgICAgICAgICAgICAgIE1hdGgucG93KG5nIC0gY29ybmVyRywgMikgK1xuICAgICAgICAgICAgICAgIE1hdGgucG93KG5iIC0gY29ybmVyQiwgMik7XG5cbiAgICAgICAgICAgICAgaWYgKGRpc3RTcSA8PSB0b2xTcSkge1xuICAgICAgICAgICAgICAgIHZpc2l0ZWRbblBvc10gPSAxO1xuICAgICAgICAgICAgICAgIHF1ZXVlLnB1c2goblBvcyk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgd0N0eC5wdXRJbWFnZURhdGEoaW1nRGF0YSwgMCwgMCk7XG4gICAgICBjb25zdCByZXNEYXRhVXJsID0gd29ya0NhbnZhcy50b0RhdGFVUkwoJ2ltYWdlL2pwZWcnLCAwLjk4KTtcblxuICAgICAgaWYgKCFvcmlnaW5hbFBob3RvU3JjICYmIHBob3RvU3JjKSB7XG4gICAgICAgIHNldE9yaWdpbmFsUGhvdG9TcmMocGhvdG9TcmMpO1xuICAgICAgfVxuXG4gICAgICBzZXRQaG90b1NyYyhyZXNEYXRhVXJsKTtcbiAgICAgIHB1c2hUb0hpc3RvcnkocmVzRGF0YVVybCk7XG4gICAgICBzZXRQcmludEFsZXJ0KCfinKggMS1DbGljayBNYWdpYyBBdXRvIEJhY2tncm91bmQgc3VjY2Vzc2Z1bGx5IHJlcGxhY2VkIScpO1xuICAgICAgc2V0VGltZW91dCgoKSA9PiBzZXRQcmludEFsZXJ0KG51bGwpLCAzMDAwKTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBjb25zb2xlLmVycm9yKGUpO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRJc1Byb2Nlc3NpbmcoZmFsc2UpO1xuICAgIH1cbiAgfTtcblxuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vIFNQT1QgQkxFTUlTSCBSRU1PVkVSICYgQkVBVVRZIEJSVVNIXG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgY29uc3QgYXBwbHlIZWFsaW5nQnJ1c2ggPSAoY2VudGVyWDogbnVtYmVyLCBjZW50ZXJZOiBudW1iZXIsIG1vZGU6ICdibGVtaXNoJyB8ICdiZWF1dHknIHwgJ2V5ZScpID0+IHtcbiAgICBjb25zdCBpbWcgPSBwaG90b0ltZ1JlZi5jdXJyZW50O1xuICAgIGlmICghaW1nKSByZXR1cm47XG5cbiAgICB0cnkge1xuICAgICAgY29uc3Qgd29ya0NhbnZhcyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2NhbnZhcycpO1xuICAgICAgd29ya0NhbnZhcy53aWR0aCA9IGltZy53aWR0aDtcbiAgICAgIHdvcmtDYW52YXMuaGVpZ2h0ID0gaW1nLmhlaWdodDtcbiAgICAgIGNvbnN0IHdDdHggPSB3b3JrQ2FudmFzLmdldENvbnRleHQoJzJkJyk7XG4gICAgICBpZiAoIXdDdHgpIHJldHVybjtcblxuICAgICAgd0N0eC5kcmF3SW1hZ2UoaW1nLCAwLCAwKTtcblxuICAgICAgY29uc3QgcmFkID0gYnJ1c2hTaXplO1xuICAgICAgY29uc3QgeCA9IE1hdGgubWF4KDAsIE1hdGgubWluKGltZy53aWR0aCwgY2VudGVyWCkpO1xuICAgICAgY29uc3QgeSA9IE1hdGgubWF4KDAsIE1hdGgubWluKGltZy5oZWlnaHQsIGNlbnRlclkpKTtcblxuICAgICAgaWYgKG1vZGUgPT09ICdibGVtaXNoJykge1xuICAgICAgICAvLyBTYW1wbGUgc3Vycm91bmRpbmcgcmluZyBvZiBza2luIHBpeGVscyBhbmQgYmxlbmQgaW50byBjZW50ZXJcbiAgICAgICAgY29uc3QgaW1nRGF0YSA9IHdDdHguZ2V0SW1hZ2VEYXRhKFxuICAgICAgICAgIE1hdGgubWF4KDAsIHggLSByYWQpLFxuICAgICAgICAgIE1hdGgubWF4KDAsIHkgLSByYWQpLFxuICAgICAgICAgIHJhZCAqIDIsXG4gICAgICAgICAgcmFkICogMlxuICAgICAgICApO1xuICAgICAgICBjb25zdCBkYXRhID0gaW1nRGF0YS5kYXRhO1xuXG4gICAgICAgIC8vIEF2ZXJhZ2Ugc3Vycm91bmRpbmcgcmluZ1xuICAgICAgICBsZXQgclN1bSA9IDAsIGdTdW0gPSAwLCBiU3VtID0gMCwgY291bnQgPSAwO1xuICAgICAgICBmb3IgKGxldCBweSA9IDA7IHB5IDwgcmFkICogMjsgcHkrKykge1xuICAgICAgICAgIGZvciAobGV0IHB4ID0gMDsgcHggPCByYWQgKiAyOyBweCsrKSB7XG4gICAgICAgICAgICBjb25zdCBkID0gTWF0aC5oeXBvdChweCAtIHJhZCwgcHkgLSByYWQpO1xuICAgICAgICAgICAgaWYgKGQgPj0gcmFkICogMC43ICYmIGQgPD0gcmFkKSB7XG4gICAgICAgICAgICAgIGNvbnN0IGkgPSAocHkgKiByYWQgKiAyICsgcHgpICogNDtcbiAgICAgICAgICAgICAgclN1bSArPSBkYXRhW2ldO1xuICAgICAgICAgICAgICBnU3VtICs9IGRhdGFbaSArIDFdO1xuICAgICAgICAgICAgICBiU3VtICs9IGRhdGFbaSArIDJdO1xuICAgICAgICAgICAgICBjb3VudCsrO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChjb3VudCA+IDApIHtcbiAgICAgICAgICBjb25zdCBhdmdSID0gclN1bSAvIGNvdW50O1xuICAgICAgICAgIGNvbnN0IGF2Z0cgPSBnU3VtIC8gY291bnQ7XG4gICAgICAgICAgY29uc3QgYXZnQiA9IGJTdW0gLyBjb3VudDtcblxuICAgICAgICAgIGZvciAobGV0IHB5ID0gMDsgcHkgPCByYWQgKiAyOyBweSsrKSB7XG4gICAgICAgICAgICBmb3IgKGxldCBweCA9IDA7IHB4IDwgcmFkICogMjsgcHgrKykge1xuICAgICAgICAgICAgICBjb25zdCBkID0gTWF0aC5oeXBvdChweCAtIHJhZCwgcHkgLSByYWQpO1xuICAgICAgICAgICAgICBpZiAoZCA8IHJhZCkge1xuICAgICAgICAgICAgICAgIGNvbnN0IGkgPSAocHkgKiByYWQgKiAyICsgcHgpICogNDtcbiAgICAgICAgICAgICAgICBjb25zdCBhbHBoYVdlaWdodCA9IDEgLSAoZCAvIHJhZCk7XG4gICAgICAgICAgICAgICAgZGF0YVtpXSA9IGRhdGFbaV0gKiAoMSAtIGFscGhhV2VpZ2h0KSArIGF2Z1IgKiBhbHBoYVdlaWdodDtcbiAgICAgICAgICAgICAgICBkYXRhW2kgKyAxXSA9IGRhdGFbaSArIDFdICogKDEgLSBhbHBoYVdlaWdodCkgKyBhdmdHICogYWxwaGFXZWlnaHQ7XG4gICAgICAgICAgICAgICAgZGF0YVtpICsgMl0gPSBkYXRhW2kgKyAyXSAqICgxIC0gYWxwaGFXZWlnaHQpICsgYXZnQiAqIGFscGhhV2VpZ2h0O1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICAgIHdDdHgucHV0SW1hZ2VEYXRhKGltZ0RhdGEsIE1hdGgubWF4KDAsIHggLSByYWQpLCBNYXRoLm1heCgwLCB5IC0gcmFkKSk7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSBpZiAobW9kZSA9PT0gJ2JlYXV0eScpIHtcbiAgICAgICAgLy8gU29mdCBza2luIGFpcmJydXNoIGJsdXJcbiAgICAgICAgd0N0eC5zYXZlKCk7XG4gICAgICAgIHdDdHguYmVnaW5QYXRoKCk7XG4gICAgICAgIHdDdHguYXJjKHgsIHksIHJhZCwgMCwgTWF0aC5QSSAqIDIpO1xuICAgICAgICB3Q3R4LmNsaXAoKTtcbiAgICAgICAgd0N0eC5maWx0ZXIgPSAnYmx1cig0cHgpIGJyaWdodG5lc3MoMTA1JSknO1xuICAgICAgICB3Q3R4LmRyYXdJbWFnZShpbWcsIDAsIDApO1xuICAgICAgICB3Q3R4LnJlc3RvcmUoKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIC8vIEV5ZSAmIFRlZXRoIFdoaXRlbmVyXG4gICAgICAgIHdDdHguc2F2ZSgpO1xuICAgICAgICB3Q3R4LmJlZ2luUGF0aCgpO1xuICAgICAgICB3Q3R4LmFyYyh4LCB5LCByYWQsIDAsIE1hdGguUEkgKiAyKTtcbiAgICAgICAgd0N0eC5jbGlwKCk7XG4gICAgICAgIHdDdHguZmlsdGVyID0gJ2JyaWdodG5lc3MoMTE4JSkgY29udHJhc3QoMTA2JSkgc2F0dXJhdGUoNjAlKSc7XG4gICAgICAgIHdDdHguZHJhd0ltYWdlKGltZywgMCwgMCk7XG4gICAgICAgIHdDdHgucmVzdG9yZSgpO1xuICAgICAgfVxuXG4gICAgICBjb25zdCByZXNEYXRhVXJsID0gd29ya0NhbnZhcy50b0RhdGFVUkwoJ2ltYWdlL2pwZWcnLCAwLjk4KTtcbiAgICAgIHNldFBob3RvU3JjKHJlc0RhdGFVcmwpO1xuICAgICAgcHVzaFRvSGlzdG9yeShyZXNEYXRhVXJsKTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBjb25zb2xlLmVycm9yKGUpO1xuICAgIH1cbiAgfTtcblxuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vIFBFTiBUT09MOiBBUFBMWSBWRUNUT1IgQ1VUT1VUXG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgY29uc3QgaGFuZGxlQXBwbHlQZW5DdXRvdXQgPSAoKSA9PiB7XG4gICAgY29uc3QgaW1nID0gcGhvdG9JbWdSZWYuY3VycmVudDtcbiAgICBpZiAoIWltZyB8fCBwZW5Qb2ludHMubGVuZ3RoIDwgMykgcmV0dXJuO1xuXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHdvcmtDYW52YXMgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdjYW52YXMnKTtcbiAgICAgIHdvcmtDYW52YXMud2lkdGggPSBpbWcud2lkdGg7XG4gICAgICB3b3JrQ2FudmFzLmhlaWdodCA9IGltZy5oZWlnaHQ7XG4gICAgICBjb25zdCB3Q3R4ID0gd29ya0NhbnZhcy5nZXRDb250ZXh0KCcyZCcpO1xuICAgICAgaWYgKCF3Q3R4KSByZXR1cm47XG5cbiAgICAgIC8vIDEuIEZpbGwgc3R1ZGlvIGJhY2tncm91bmRcbiAgICAgIHdDdHguZmlsbFN0eWxlID0gYmdDb2xvcjtcbiAgICAgIHdDdHguZmlsbFJlY3QoMCwgMCwgd29ya0NhbnZhcy53aWR0aCwgd29ya0NhbnZhcy5oZWlnaHQpO1xuXG4gICAgICAvLyAyLiBDcmVhdGUgb2Zmc2NyZWVuIHBlcnNvbiBsYXllciBjbGlwcGVkIHRvIHBhdGhcbiAgICAgIGNvbnN0IHBlcnNvbkNhbnZhcyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2NhbnZhcycpO1xuICAgICAgcGVyc29uQ2FudmFzLndpZHRoID0gaW1nLndpZHRoO1xuICAgICAgcGVyc29uQ2FudmFzLmhlaWdodCA9IGltZy5oZWlnaHQ7XG4gICAgICBjb25zdCBwQ3R4ID0gcGVyc29uQ2FudmFzLmdldENvbnRleHQoJzJkJyk7XG5cbiAgICAgIGlmIChwQ3R4KSB7XG4gICAgICAgIHBDdHguZHJhd0ltYWdlKGltZywgMCwgMCk7XG5cbiAgICAgICAgY29uc3QgbWFza0NhbnZhcyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2NhbnZhcycpO1xuICAgICAgICBtYXNrQ2FudmFzLndpZHRoID0gaW1nLndpZHRoO1xuICAgICAgICBtYXNrQ2FudmFzLmhlaWdodCA9IGltZy5oZWlnaHQ7XG4gICAgICAgIGNvbnN0IG1DdHggPSBtYXNrQ2FudmFzLmdldENvbnRleHQoJzJkJyk7XG5cbiAgICAgICAgaWYgKG1DdHgpIHtcbiAgICAgICAgICBpZiAocGVuRmVhdGhlciA+IDApIHtcbiAgICAgICAgICAgIG1DdHguZmlsdGVyID0gYGJsdXIoJHtwZW5GZWF0aGVyfXB4KWA7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgbUN0eC5iZWdpblBhdGgoKTtcbiAgICAgICAgICBtQ3R4Lm1vdmVUbyhwZW5Qb2ludHNbMF0ueCAqIGltZy53aWR0aCwgcGVuUG9pbnRzWzBdLnkgKiBpbWcuaGVpZ2h0KTtcbiAgICAgICAgICBmb3IgKGxldCBpID0gMTsgaSA8IHBlblBvaW50cy5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgbUN0eC5saW5lVG8ocGVuUG9pbnRzW2ldLnggKiBpbWcud2lkdGgsIHBlblBvaW50c1tpXS55ICogaW1nLmhlaWdodCk7XG4gICAgICAgICAgfVxuICAgICAgICAgIG1DdHguY2xvc2VQYXRoKCk7XG4gICAgICAgICAgbUN0eC5maWxsU3R5bGUgPSAnIzAwMDAwMCc7XG4gICAgICAgICAgbUN0eC5maWxsKCk7XG5cbiAgICAgICAgICBwQ3R4Lmdsb2JhbENvbXBvc2l0ZU9wZXJhdGlvbiA9ICdkZXN0aW5hdGlvbi1pbic7XG4gICAgICAgICAgcEN0eC5kcmF3SW1hZ2UobWFza0NhbnZhcywgMCwgMCk7XG4gICAgICAgIH1cblxuICAgICAgICB3Q3R4LmRyYXdJbWFnZShwZXJzb25DYW52YXMsIDAsIDApO1xuICAgICAgfVxuXG4gICAgICBjb25zdCByZXNEYXRhVXJsID0gd29ya0NhbnZhcy50b0RhdGFVUkwoJ2ltYWdlL2pwZWcnLCAwLjk4KTtcbiAgICAgIGlmICghb3JpZ2luYWxQaG90b1NyYyAmJiBwaG90b1NyYykge1xuICAgICAgICBzZXRPcmlnaW5hbFBob3RvU3JjKHBob3RvU3JjKTtcbiAgICAgIH1cblxuICAgICAgc2V0UGhvdG9TcmMocmVzRGF0YVVybCk7XG4gICAgICBwdXNoVG9IaXN0b3J5KHJlc0RhdGFVcmwpO1xuICAgICAgc2V0UGVuUG9pbnRzKFtdKTtcbiAgICAgIHNldElzUGF0aENsb3NlZChmYWxzZSk7XG4gICAgICBzZXRBY3RpdmVUb29sKCdzZWxlY3QnKTtcbiAgICAgIHNldFByaW50QWxlcnQoJ/CflorvuI8gUGVuIFRvb2wgQ3V0b3V0IGFwcGxpZWQgc3VjY2Vzc2Z1bGx5IScpO1xuICAgICAgc2V0VGltZW91dCgoKSA9PiBzZXRQcmludEFsZXJ0KG51bGwpLCAzMDAwKTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBjb25zb2xlLmVycm9yKGUpO1xuICAgIH1cbiAgfTtcblxuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vIE1BSU4gRURJVE9SIENBTlZBUyBSRU5ERVIgKENlbnRyYWwgUGhvdG9zaG9wLVN0eWxlIFdvcmtzcGFjZSlcbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICBjb25zdCByZW5kZXJFZGl0b3JDYW52YXMgPSAoKSA9PiB7XG4gICAgY29uc3QgY2FudmFzID0gZWRpdG9yQ2FudmFzUmVmLmN1cnJlbnQ7XG4gICAgY29uc3QgaW1nID0gcGhvdG9JbWdSZWYuY3VycmVudDtcbiAgICBpZiAoIWNhbnZhcykgcmV0dXJuO1xuXG4gICAgY29uc3QgY3R4ID0gY2FudmFzLmdldENvbnRleHQoJzJkJyk7XG4gICAgaWYgKCFjdHgpIHJldHVybjtcblxuICAgIC8vIEZpeGVkIGludGVybmFsIHNpemUgZm9yIHNoYXJwIDJLIGVkaXRpbmcgY2FudmFzXG4gICAgY2FudmFzLndpZHRoID0gOTAwO1xuICAgIGNhbnZhcy5oZWlnaHQgPSA3MDA7XG5cbiAgICAvLyBEYXJrIHdvcmtzcGFjZSBjaGVja2VyZWQgYmFja2dyb3VuZFxuICAgIGN0eC5maWxsU3R5bGUgPSAnIzA5MGQxNic7XG4gICAgY3R4LmZpbGxSZWN0KDAsIDAsIGNhbnZhcy53aWR0aCwgY2FudmFzLmhlaWdodCk7XG5cbiAgICBpZiAoIWltZykge1xuICAgICAgLy8gRW1wdHkgc3RhdGVcbiAgICAgIGN0eC5maWxsU3R5bGUgPSAnIzY0NzQ4Yic7XG4gICAgICBjdHguZm9udCA9ICdib2xkIDE2cHggc2Fucy1zZXJpZic7XG4gICAgICBjdHgudGV4dEFsaWduID0gJ2NlbnRlcic7XG4gICAgICBjdHguZmlsbFRleHQoJ1VwbG9hZCBvciBEcmFnIEN1c3RvbWVyIFBob3RvIHRvIEVkaXQnLCBjYW52YXMud2lkdGggLyAyLCBjYW52YXMuaGVpZ2h0IC8gMiAtIDEwKTtcbiAgICAgIGN0eC5mb250ID0gJzEycHggc2Fucy1zZXJpZic7XG4gICAgICBjdHguZmlsbFRleHQoJ1Bob3Rvc2hvcC1zdHlsZSB0b29sczogUGVuLCBNYWdpYyBXYW5kLCBCbGVtaXNoLCBDcm9wLCBBdXRvIEJlYXV0eScsIGNhbnZhcy53aWR0aCAvIDIsIGNhbnZhcy5oZWlnaHQgLyAyICsgMTUpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGN0eC5zYXZlKCk7XG5cbiAgICAvLyBQYW4gJiBab29tIHRyYW5zZm9ybWF0aW9uc1xuICAgIGN0eC50cmFuc2xhdGUoY2FudmFzLndpZHRoIC8gMiArIGNhbnZhc1Bhbi54LCBjYW52YXMuaGVpZ2h0IC8gMiArIGNhbnZhc1Bhbi55KTtcbiAgICBjdHguc2NhbGUoY2FudmFzWm9vbSwgY2FudmFzWm9vbSk7XG5cbiAgICAvLyBDYWxjdWxhdGUgZGltZW5zaW9ucyBtYWludGFpbmluZyBhc3BlY3QgcmF0aW9cbiAgICBjb25zdCBhc3BlY3QgPSBpbWcud2lkdGggLyBpbWcuaGVpZ2h0O1xuICAgIGxldCByZW5kZXJXID0gNDYwO1xuICAgIGxldCByZW5kZXJIID0gNDYwIC8gYXNwZWN0O1xuICAgIGlmIChyZW5kZXJIID4gNTYwKSB7XG4gICAgICByZW5kZXJIID0gNTYwO1xuICAgICAgcmVuZGVyVyA9IDU2MCAqIGFzcGVjdDtcbiAgICB9XG5cbiAgICBjb25zdCBkcmF3WCA9IC1yZW5kZXJXIC8gMjtcbiAgICBjb25zdCBkcmF3WSA9IC1yZW5kZXJIIC8gMjtcblxuICAgIC8vIEFwcGx5IGNvbG9yIGdyYWRpbmcgZmlsdGVyc1xuICAgIGNvbnN0IGVmZkJyaWdodG5lc3MgPSAxMDAgKyBicmlnaHRuZXNzICsgKGF1dG9CZWF1dHkgPyA2IDogMCkgKyAoZmFjZUdsb3cgKiAwLjEyKTtcbiAgICBjb25zdCBlZmZDb250cmFzdCA9IDEwMCArIGNvbnRyYXN0ICsgKGF1dG9CZWF1dHkgPyA0IDogMCk7XG4gICAgY29uc3QgZWZmU2F0dXJhdGlvbiA9IGlzR3JheXNjYWxlID8gMCA6IDEwMCArIHNhdHVyYXRpb24gKyAoYXV0b0JlYXV0eSA/IDggOiAwKTtcblxuICAgIGxldCBmaWx0ZXJTdHIgPSBgYnJpZ2h0bmVzcygke2VmZkJyaWdodG5lc3N9JSkgY29udHJhc3QoJHtlZmZDb250cmFzdH0lKSBzYXR1cmF0ZSgke2VmZlNhdHVyYXRpb259JSlgO1xuICAgIGlmIChpc0dyYXlzY2FsZSkgZmlsdGVyU3RyICs9ICcgZ3JheXNjYWxlKDEwMCUpJztcblxuICAgIGN0eC5maWx0ZXIgPSBmaWx0ZXJTdHI7XG4gICAgY3R4LmRyYXdJbWFnZShpbWcsIGRyYXdYLCBkcmF3WSwgcmVuZGVyVywgcmVuZGVySCk7XG5cbiAgICAvLyBTb2Z0IEJlYXV0eSBMYXllciAoU29mdC1MaWdodCBwYXNzKVxuICAgIGNvbnN0IGVmZlNtb290aCA9IGF1dG9CZWF1dHkgPyBNYXRoLm1heChza2luU21vb3RoLCAxNikgOiBza2luU21vb3RoO1xuICAgIGNvbnN0IGVmZkdsb3cgPSBhdXRvQmVhdXR5ID8gTWF0aC5tYXgoZmFjZUdsb3csIDIwKSA6IGZhY2VHbG93O1xuICAgIGlmIChlZmZTbW9vdGggPiAwIHx8IGVmZkdsb3cgPiAwKSB7XG4gICAgICBjdHguc2F2ZSgpO1xuICAgICAgY3R4Lmdsb2JhbENvbXBvc2l0ZU9wZXJhdGlvbiA9ICdzb2Z0LWxpZ2h0JztcbiAgICAgIGN0eC5nbG9iYWxBbHBoYSA9IE1hdGgubWluKDAuNjUsIChlZmZTbW9vdGggKiAwLjAxMikgKyAoZWZmR2xvdyAqIDAuMDEpKTtcbiAgICAgIGN0eC5maWx0ZXIgPSBgYmx1cigke01hdGgubWF4KDIsIGVmZlNtb290aCAvIDgpfXB4KSBicmlnaHRuZXNzKDEyMCUpYDtcbiAgICAgIGN0eC5kcmF3SW1hZ2UoaW1nLCBkcmF3WCwgZHJhd1ksIHJlbmRlclcsIHJlbmRlckgpO1xuICAgICAgY3R4LnJlc3RvcmUoKTtcbiAgICB9XG5cbiAgICAvLyBXYXJtdGggJiBUaW50XG4gICAgaWYgKHdhcm10aCAhPT0gMCAmJiAhaXNHcmF5c2NhbGUpIHtcbiAgICAgIGN0eC5zYXZlKCk7XG4gICAgICBjdHguZ2xvYmFsQ29tcG9zaXRlT3BlcmF0aW9uID0gJ2NvbG9yJztcbiAgICAgIGN0eC5maWxsU3R5bGUgPSB3YXJtdGggPiAwXG4gICAgICAgID8gYHJnYmEoMjU1LCAxNzUsIDc1LCAke01hdGgubWluKDAuMzUsICh3YXJtdGggLyAxMDApICogMC40KX0pYFxuICAgICAgICA6IGByZ2JhKDgwLCAxNjUsIDI1NSwgJHtNYXRoLm1pbigwLjM1LCAoTWF0aC5hYnMod2FybXRoKSAvIDEwMCkgKiAwLjQpfSlgO1xuICAgICAgY3R4LmZpbGxSZWN0KGRyYXdYLCBkcmF3WSwgcmVuZGVyVywgcmVuZGVySCk7XG4gICAgICBjdHgucmVzdG9yZSgpO1xuICAgIH1cblxuICAgIGlmICh0aW50ICE9PSAwICYmICFpc0dyYXlzY2FsZSkge1xuICAgICAgY3R4LnNhdmUoKTtcbiAgICAgIGN0eC5nbG9iYWxDb21wb3NpdGVPcGVyYXRpb24gPSAnY29sb3InO1xuICAgICAgY3R4LmZpbGxTdHlsZSA9IHRpbnQgPiAwXG4gICAgICAgID8gYHJnYmEoMjU1LCA2MCwgMTgwLCAke01hdGgubWluKDAuMjUsICh0aW50IC8gMTAwKSAqIDAuMyl9KWBcbiAgICAgICAgOiBgcmdiYSg2MCwgMjIwLCAxMDAsICR7TWF0aC5taW4oMC4yNSwgKE1hdGguYWJzKHRpbnQpIC8gMTAwKSAqIDAuMyl9KWA7XG4gICAgICBjdHguZmlsbFJlY3QoZHJhd1gsIGRyYXdZLCByZW5kZXJXLCByZW5kZXJIKTtcbiAgICAgIGN0eC5yZXN0b3JlKCk7XG4gICAgfVxuXG4gICAgY3R4LnJlc3RvcmUoKTtcblxuICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAvLyBPVkVSTEFZUzogUGVuIFRvb2wgUGF0aCAvIENyb3AgQm94XG4gICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgIC8vIFBlbiBUb29sIFBhdGhcbiAgICBpZiAoYWN0aXZlVG9vbCA9PT0gJ3Blbl90b29sJyAmJiBwZW5Qb2ludHMubGVuZ3RoID4gMCkge1xuICAgICAgY3R4LnNhdmUoKTtcbiAgICAgIGN0eC50cmFuc2xhdGUoY2FudmFzLndpZHRoIC8gMiArIGNhbnZhc1Bhbi54LCBjYW52YXMuaGVpZ2h0IC8gMiArIGNhbnZhc1Bhbi55KTtcbiAgICAgIGN0eC5zY2FsZShjYW52YXNab29tLCBjYW52YXNab29tKTtcblxuICAgICAgY3R4LmJlZ2luUGF0aCgpO1xuICAgICAgY29uc3QgZmlyc3RYID0gZHJhd1ggKyBwZW5Qb2ludHNbMF0ueCAqIHJlbmRlclc7XG4gICAgICBjb25zdCBmaXJzdFkgPSBkcmF3WSArIHBlblBvaW50c1swXS55ICogcmVuZGVySDtcbiAgICAgIGN0eC5tb3ZlVG8oZmlyc3RYLCBmaXJzdFkpO1xuXG4gICAgICBmb3IgKGxldCBpID0gMTsgaSA8IHBlblBvaW50cy5sZW5ndGg7IGkrKykge1xuICAgICAgICBjb25zdCBweCA9IGRyYXdYICsgcGVuUG9pbnRzW2ldLnggKiByZW5kZXJXO1xuICAgICAgICBjb25zdCBweSA9IGRyYXdZICsgcGVuUG9pbnRzW2ldLnkgKiByZW5kZXJIO1xuICAgICAgICBjdHgubGluZVRvKHB4LCBweSk7XG4gICAgICB9XG5cbiAgICAgIGlmIChpc1BhdGhDbG9zZWQpIHtcbiAgICAgICAgY3R4LmNsb3NlUGF0aCgpO1xuICAgICAgICBjdHguZmlsbFN0eWxlID0gJ3JnYmEoMTQsIDE2NSwgMjMzLCAwLjI1KSc7XG4gICAgICAgIGN0eC5maWxsKCk7XG4gICAgICB9XG5cbiAgICAgIGN0eC5zdHJva2VTdHlsZSA9IGlzUGF0aENsb3NlZCA/ICcjMTBiOTgxJyA6ICcjMzhiZGY4JztcbiAgICAgIGN0eC5saW5lV2lkdGggPSAyIC8gY2FudmFzWm9vbTtcbiAgICAgIGN0eC5zZXRMaW5lRGFzaChpc1BhdGhDbG9zZWQgPyBbXSA6IFs0LCA0XSk7XG4gICAgICBjdHguc3Ryb2tlKCk7XG5cbiAgICAgIC8vIFBvaW50c1xuICAgICAgcGVuUG9pbnRzLmZvckVhY2goKHB0LCBpZHgpID0+IHtcbiAgICAgICAgY29uc3QgcHggPSBkcmF3WCArIHB0LnggKiByZW5kZXJXO1xuICAgICAgICBjb25zdCBweSA9IGRyYXdZICsgcHQueSAqIHJlbmRlckg7XG4gICAgICAgIGNvbnN0IGlzRmlyc3QgPSBpZHggPT09IDA7XG5cbiAgICAgICAgY3R4LmJlZ2luUGF0aCgpO1xuICAgICAgICBjdHguYXJjKHB4LCBweSwgKGlzRmlyc3QgPyA3IDogNSkgLyBjYW52YXNab29tLCAwLCBNYXRoLlBJICogMik7XG4gICAgICAgIGN0eC5maWxsU3R5bGUgPSBpc0ZpcnN0ID8gKGlzTmVhclN0YXJ0UG9pbnQgPyAnIzIyYzU1ZScgOiAnI2VhYjMwOCcpIDogJyMzOGJkZjgnO1xuICAgICAgICBjdHguc3Ryb2tlU3R5bGUgPSAnIzBmMTcyYSc7XG4gICAgICAgIGN0eC5saW5lV2lkdGggPSAyIC8gY2FudmFzWm9vbTtcbiAgICAgICAgY3R4LmZpbGwoKTtcbiAgICAgICAgY3R4LnN0cm9rZSgpO1xuICAgICAgfSk7XG5cbiAgICAgIGN0eC5yZXN0b3JlKCk7XG4gICAgfVxuXG4gICAgLy8gQ3JvcCBUb29sIEJveCBPdmVybGF5XG4gICAgaWYgKGFjdGl2ZVRvb2wgPT09ICdjcm9wJyAmJiBjcm9wQm94KSB7XG4gICAgICBjdHguc2F2ZSgpO1xuICAgICAgLy8gRGltIG91dGVyIGFyZWFcbiAgICAgIGN0eC5maWxsU3R5bGUgPSAncmdiYSgwLCAwLCAwLCAwLjYpJztcbiAgICAgIGN0eC5maWxsUmVjdCgwLCAwLCBjYW52YXMud2lkdGgsIGNyb3BCb3gueSk7XG4gICAgICBjdHguZmlsbFJlY3QoMCwgY3JvcEJveC55ICsgY3JvcEJveC5oLCBjYW52YXMud2lkdGgsIGNhbnZhcy5oZWlnaHQgLSAoY3JvcEJveC55ICsgY3JvcEJveC5oKSk7XG4gICAgICBjdHguZmlsbFJlY3QoMCwgY3JvcEJveC55LCBjcm9wQm94LngsIGNyb3BCb3guaCk7XG4gICAgICBjdHguZmlsbFJlY3QoY3JvcEJveC54ICsgY3JvcEJveC53LCBjcm9wQm94LnksIGNhbnZhcy53aWR0aCAtIChjcm9wQm94LnggKyBjcm9wQm94LncpLCBjcm9wQm94LmgpO1xuXG4gICAgICAvLyBDcm9wIGJvcmRlclxuICAgICAgY3R4LnN0cm9rZVN0eWxlID0gJyMzOGJkZjgnO1xuICAgICAgY3R4LmxpbmVXaWR0aCA9IDI7XG4gICAgICBjdHguc3Ryb2tlUmVjdChjcm9wQm94LngsIGNyb3BCb3gueSwgY3JvcEJveC53LCBjcm9wQm94LmgpO1xuXG4gICAgICAvLyBSdWxlIG9mIHRoaXJkcyBsaW5lc1xuICAgICAgY3R4LnN0cm9rZVN0eWxlID0gJ3JnYmEoMjU1LCAyNTUsIDI1NSwgMC4zKSc7XG4gICAgICBjdHgubGluZVdpZHRoID0gMTtcbiAgICAgIGN0eC5iZWdpblBhdGgoKTtcbiAgICAgIGN0eC5tb3ZlVG8oY3JvcEJveC54ICsgY3JvcEJveC53IC8gMywgY3JvcEJveC55KTtcbiAgICAgIGN0eC5saW5lVG8oY3JvcEJveC54ICsgY3JvcEJveC53IC8gMywgY3JvcEJveC55ICsgY3JvcEJveC5oKTtcbiAgICAgIGN0eC5tb3ZlVG8oY3JvcEJveC54ICsgKGNyb3BCb3gudyAqIDIpIC8gMywgY3JvcEJveC55KTtcbiAgICAgIGN0eC5saW5lVG8oY3JvcEJveC54ICsgKGNyb3BCb3gudyAqIDIpIC8gMywgY3JvcEJveC55ICsgY3JvcEJveC5oKTtcbiAgICAgIGN0eC5tb3ZlVG8oY3JvcEJveC54LCBjcm9wQm94LnkgKyBjcm9wQm94LmggLyAzKTtcbiAgICAgIGN0eC5saW5lVG8oY3JvcEJveC54ICsgY3JvcEJveC53LCBjcm9wQm94LnkgKyBjcm9wQm94LmggLyAzKTtcbiAgICAgIGN0eC5tb3ZlVG8oY3JvcEJveC54LCBjcm9wQm94LnkgKyAoY3JvcEJveC5oICogMikgLyAzKTtcbiAgICAgIGN0eC5saW5lVG8oY3JvcEJveC54ICsgY3JvcEJveC53LCBjcm9wQm94LnkgKyAoY3JvcEJveC5oICogMikgLyAzKTtcbiAgICAgIGN0eC5zdHJva2UoKTtcblxuICAgICAgY3R4LnJlc3RvcmUoKTtcbiAgICB9XG4gIH07XG5cbiAgLy8gQ29udmVydCBFZGl0b3IgQ2FudmFzIENsaWNrIHRvIEltYWdlIENvb3JkaW5hdGVzXG4gIGNvbnN0IGNhbnZhc1RvSW1hZ2VDb29yZHMgPSAoY2xpZW50WDogbnVtYmVyLCBjbGllbnRZOiBudW1iZXIpID0+IHtcbiAgICBjb25zdCBjYW52YXMgPSBlZGl0b3JDYW52YXNSZWYuY3VycmVudDtcbiAgICBjb25zdCBpbWcgPSBwaG90b0ltZ1JlZi5jdXJyZW50O1xuICAgIGlmICghY2FudmFzIHx8ICFpbWcpIHJldHVybiBudWxsO1xuXG4gICAgY29uc3QgcmVjdCA9IGNhbnZhcy5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgICBjb25zdCBzY2FsZVggPSBjYW52YXMud2lkdGggLyByZWN0LndpZHRoO1xuICAgIGNvbnN0IHNjYWxlWSA9IGNhbnZhcy5oZWlnaHQgLyByZWN0LmhlaWdodDtcblxuICAgIGNvbnN0IGNsaWNrWCA9IChjbGllbnRYIC0gcmVjdC5sZWZ0KSAqIHNjYWxlWDtcbiAgICBjb25zdCBjbGlja1kgPSAoY2xpZW50WSAtIHJlY3QudG9wKSAqIHNjYWxlWTtcblxuICAgIC8vIFJldmVyc2UgUGFuICYgWm9vbVxuICAgIGNvbnN0IGxvY2FsWCA9IChjbGlja1ggLSAoY2FudmFzLndpZHRoIC8gMiArIGNhbnZhc1Bhbi54KSkgLyBjYW52YXNab29tO1xuICAgIGNvbnN0IGxvY2FsWSA9IChjbGlja1kgLSAoY2FudmFzLmhlaWdodCAvIDIgKyBjYW52YXNQYW4ueSkpIC8gY2FudmFzWm9vbTtcblxuICAgIGNvbnN0IGFzcGVjdCA9IGltZy53aWR0aCAvIGltZy5oZWlnaHQ7XG4gICAgbGV0IHJlbmRlclcgPSA0NjA7XG4gICAgbGV0IHJlbmRlckggPSA0NjAgLyBhc3BlY3Q7XG4gICAgaWYgKHJlbmRlckggPiA1NjApIHtcbiAgICAgIHJlbmRlckggPSA1NjA7XG4gICAgICByZW5kZXJXID0gNTYwICogYXNwZWN0O1xuICAgIH1cblxuICAgIGNvbnN0IGRyYXdYID0gLXJlbmRlclcgLyAyO1xuICAgIGNvbnN0IGRyYXdZID0gLXJlbmRlckggLyAyO1xuXG4gICAgY29uc3Qgbm9ybVggPSAobG9jYWxYIC0gZHJhd1gpIC8gcmVuZGVyVztcbiAgICBjb25zdCBub3JtWSA9IChsb2NhbFkgLSBkcmF3WSkgLyByZW5kZXJIO1xuXG4gICAgY29uc3QgaW1nWCA9IG5vcm1YICogaW1nLndpZHRoO1xuICAgIGNvbnN0IGltZ1kgPSBub3JtWSAqIGltZy5oZWlnaHQ7XG5cbiAgICByZXR1cm4ge1xuICAgICAgbm9ybVgsXG4gICAgICBub3JtWSxcbiAgICAgIGltZ1gsXG4gICAgICBpbWdZLFxuICAgICAgaXNJbnNpZGU6IG5vcm1YID49IDAgJiYgbm9ybVggPD0gMSAmJiBub3JtWSA+PSAwICYmIG5vcm1ZIDw9IDFcbiAgICB9O1xuICB9O1xuXG4gIC8vIENhbnZhcyBNb3VzZSBEb3duXG4gIGNvbnN0IGhhbmRsZUVkaXRvck1vdXNlRG93biA9IChlOiBSZWFjdC5Nb3VzZUV2ZW50PEhUTUxDYW52YXNFbGVtZW50PikgPT4ge1xuICAgIGlmIChpc1NwYWNlUHJlc3NlZCB8fCBhY3RpdmVUb29sID09PSAnaGFuZCcgfHwgZS5idXR0b24gPT09IDEpIHtcbiAgICAgIHNldElzUGFubmluZyh0cnVlKTtcbiAgICAgIHNldFBhblN0YXJ0KHsgeDogZS5jbGllbnRYIC0gY2FudmFzUGFuLngsIHk6IGUuY2xpZW50WSAtIGNhbnZhc1Bhbi55IH0pO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGNvbnN0IGNvb3JkcyA9IGNhbnZhc1RvSW1hZ2VDb29yZHMoZS5jbGllbnRYLCBlLmNsaWVudFkpO1xuICAgIGlmICghY29vcmRzIHx8ICFjb29yZHMuaXNJbnNpZGUpIHJldHVybjtcblxuICAgIC8vIFRvb2wgYWN0aW9uc1xuICAgIGlmIChhY3RpdmVUb29sID09PSAnbWFnaWNfd2FuZCcpIHtcbiAgICAgIGV4ZWN1dGVNYWdpY1dhbmRDdXQoY29vcmRzLmltZ1gsIGNvb3Jkcy5pbWdZKTtcbiAgICB9IGVsc2UgaWYgKGFjdGl2ZVRvb2wgPT09ICdwZW5fdG9vbCcpIHtcbiAgICAgIGlmIChwZW5Qb2ludHMubGVuZ3RoID49IDMgJiYgIWlzUGF0aENsb3NlZCkge1xuICAgICAgICBjb25zdCBmaXJzdCA9IHBlblBvaW50c1swXTtcbiAgICAgICAgY29uc3QgZGlzdCA9IE1hdGguaHlwb3QoY29vcmRzLm5vcm1YIC0gZmlyc3QueCwgY29vcmRzLm5vcm1ZIC0gZmlyc3QueSk7XG4gICAgICAgIGlmIChkaXN0IDwgMC4wNSkge1xuICAgICAgICAgIHNldElzUGF0aENsb3NlZCh0cnVlKTtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGlmICghaXNQYXRoQ2xvc2VkKSB7XG4gICAgICAgIHNldFBlblBvaW50cyhwcmV2ID0+IFsuLi5wcmV2LCB7IHg6IGNvb3Jkcy5ub3JtWCwgeTogY29vcmRzLm5vcm1ZIH1dKTtcbiAgICAgIH1cbiAgICB9IGVsc2UgaWYgKGFjdGl2ZVRvb2wgPT09ICdibGVtaXNoX2JydXNoJykge1xuICAgICAgYXBwbHlIZWFsaW5nQnJ1c2goY29vcmRzLmltZ1gsIGNvb3Jkcy5pbWdZLCAnYmxlbWlzaCcpO1xuICAgIH0gZWxzZSBpZiAoYWN0aXZlVG9vbCA9PT0gJ2JlYXV0eV9icnVzaCcpIHtcbiAgICAgIGFwcGx5SGVhbGluZ0JydXNoKGNvb3Jkcy5pbWdYLCBjb29yZHMuaW1nWSwgJ2JlYXV0eScpO1xuICAgIH0gZWxzZSBpZiAoYWN0aXZlVG9vbCA9PT0gJ2V5ZV9icmlnaHRlbicpIHtcbiAgICAgIGFwcGx5SGVhbGluZ0JydXNoKGNvb3Jkcy5pbWdYLCBjb29yZHMuaW1nWSwgJ2V5ZScpO1xuICAgIH0gZWxzZSBpZiAoYWN0aXZlVG9vbCA9PT0gJ3pvb20nKSB7XG4gICAgICBpZiAoZS5hbHRLZXkpIHtcbiAgICAgICAgc2V0Q2FudmFzWm9vbShwcmV2ID0+IE1hdGgubWF4KDAuNCwgcHJldiAtIDAuMykpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgc2V0Q2FudmFzWm9vbShwcmV2ID0+IE1hdGgubWluKDQuMCwgcHJldiArIDAuMykpO1xuICAgICAgfVxuICAgIH1cbiAgfTtcblxuICAvLyBDYW52YXMgTW91c2UgTW92ZVxuICBjb25zdCBoYW5kbGVFZGl0b3JNb3VzZU1vdmUgPSAoZTogUmVhY3QuTW91c2VFdmVudDxIVE1MQ2FudmFzRWxlbWVudD4pID0+IHtcbiAgICBpZiAoaXNQYW5uaW5nKSB7XG4gICAgICBzZXRDYW52YXNQYW4oe1xuICAgICAgICB4OiBlLmNsaWVudFggLSBwYW5TdGFydC54LFxuICAgICAgICB5OiBlLmNsaWVudFkgLSBwYW5TdGFydC55XG4gICAgICB9KTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBpZiAoYWN0aXZlVG9vbCA9PT0gJ3Blbl90b29sJyAmJiBwZW5Qb2ludHMubGVuZ3RoID49IDMgJiYgIWlzUGF0aENsb3NlZCkge1xuICAgICAgY29uc3QgY29vcmRzID0gY2FudmFzVG9JbWFnZUNvb3JkcyhlLmNsaWVudFgsIGUuY2xpZW50WSk7XG4gICAgICBpZiAoY29vcmRzKSB7XG4gICAgICAgIGNvbnN0IGZpcnN0ID0gcGVuUG9pbnRzWzBdO1xuICAgICAgICBjb25zdCBkaXN0ID0gTWF0aC5oeXBvdChjb29yZHMubm9ybVggLSBmaXJzdC54LCBjb29yZHMubm9ybVkgLSBmaXJzdC55KTtcbiAgICAgICAgc2V0SXNOZWFyU3RhcnRQb2ludChkaXN0IDwgMC4wNSk7XG4gICAgICB9XG4gICAgfVxuICB9O1xuXG4gIC8vIENhbnZhcyBNb3VzZSBVcFxuICBjb25zdCBoYW5kbGVFZGl0b3JNb3VzZVVwID0gKCkgPT4ge1xuICAgIHNldElzUGFubmluZyhmYWxzZSk7XG4gIH07XG5cbiAgLy8gQ2FudmFzIE1vdXNlIFdoZWVsIChDZW50ZXJlZCBab29tKVxuICBjb25zdCBoYW5kbGVFZGl0b3JXaGVlbCA9IChlOiBSZWFjdC5XaGVlbEV2ZW50PEhUTUxDYW52YXNFbGVtZW50PikgPT4ge1xuICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICBjb25zdCB6b29tRmFjdG9yID0gZS5kZWx0YVkgPCAwID8gMS4xNSA6IDAuODg7XG4gICAgc2V0Q2FudmFzWm9vbShwcmV2ID0+IE1hdGgubWF4KDAuNCwgTWF0aC5taW4oNC4wLCBwcmV2ICogem9vbUZhY3RvcikpKTtcbiAgfTtcblxuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vIE1JTkkgUFJFVklFVyBDQU5WQVMgUkVOREVSIChcInByZXZpZXcgbWluaSBkaWtobmEgY2hhaXllXCIpXG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgY29uc3QgcmVuZGVyTWluaVByZXZpZXcgPSAoKSA9PiB7XG4gICAgY29uc3QgY2FudmFzID0gbWluaVByZXZpZXdDYW52YXNSZWYuY3VycmVudDtcbiAgICBjb25zdCBpbWcgPSBwaG90b0ltZ1JlZi5jdXJyZW50O1xuICAgIGlmICghY2FudmFzKSByZXR1cm47XG5cbiAgICBjb25zdCBjdHggPSBjYW52YXMuZ2V0Q29udGV4dCgnMmQnKTtcbiAgICBpZiAoIWN0eCkgcmV0dXJuO1xuXG4gICAgY2FudmFzLndpZHRoID0gMjQwO1xuICAgIGNhbnZhcy5oZWlnaHQgPSAxNjA7XG5cbiAgICAvLyBQdXJlIHdoaXRlIHBob3RvIHBhcGVyXG4gICAgY3R4LmZpbGxTdHlsZSA9ICcjZmZmZmZmJztcbiAgICBjdHguZmlsbFJlY3QoMCwgMCwgY2FudmFzLndpZHRoLCBjYW52YXMuaGVpZ2h0KTtcblxuICAgIGlmICghaW1nKSB7XG4gICAgICBjdHguZmlsbFN0eWxlID0gJyM5NGEzYjgnO1xuICAgICAgY3R4LmZvbnQgPSAnMTBweCBzYW5zLXNlcmlmJztcbiAgICAgIGN0eC50ZXh0QWxpZ24gPSAnY2VudGVyJztcbiAgICAgIGN0eC5maWxsVGV4dCgnTWluaSBTaGVldCBQcmV2aWV3JywgY2FudmFzLndpZHRoIC8gMiwgY2FudmFzLmhlaWdodCAvIDIpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIC8vIERyYXcgbWluaWF0dXJlIGdyaWQgKDR4NiBsYW5kc2NhcGUgOCBjb3BpZXMgb3IgQTQpXG4gICAgY29uc3QgaXNBNCA9IHBhcGVyRm9ybWF0LnN0YXJ0c1dpdGgoJ2E0Jyk7XG4gICAgY29uc3QgY29scyA9IHBhcGVyRm9ybWF0ID09PSAnNHg2X2xhbmRzY2FwZScgPyA0IDogaXNBNCA/IChjb3BpZXMgPT09IDMyID8gOCA6IDQpIDogMjtcbiAgICBjb25zdCByb3dzID0gcGFwZXJGb3JtYXQgPT09ICc0eDZfbGFuZHNjYXBlJyA/IDIgOiBpc0E0ID8gNCA6IDQ7XG5cbiAgICBjb25zdCBnYXAgPSA0O1xuICAgIGNvbnN0IG1hcmdpbiA9IDg7XG4gICAgY29uc3QgY2VsbFcgPSAoY2FudmFzLndpZHRoIC0gbWFyZ2luICogMiAtIChjb2xzIC0gMSkgKiBnYXApIC8gY29scztcbiAgICBjb25zdCBjZWxsSCA9IGNlbGxXICogKDQ1IC8gMzUpO1xuXG4gICAgbGV0IGNvdW50ID0gMDtcbiAgICBmb3IgKGxldCByID0gMDsgciA8IHJvd3M7IHIrKykge1xuICAgICAgZm9yIChsZXQgYyA9IDA7IGMgPCBjb2xzOyBjKyspIHtcbiAgICAgICAgaWYgKGNvdW50ID49IGNvcGllcykgYnJlYWs7XG4gICAgICAgIGNvbnN0IHggPSBtYXJnaW4gKyBjICogKGNlbGxXICsgZ2FwKTtcbiAgICAgICAgY29uc3QgeSA9IG1hcmdpbiArIHIgKiAoY2VsbEggKyBnYXApO1xuXG4gICAgICAgIC8vIEZpbGwgYmFja2dyb3VuZFxuICAgICAgICBjdHguZmlsbFN0eWxlID0gYmdDb2xvcjtcbiAgICAgICAgY3R4LmZpbGxSZWN0KHgsIHksIGNlbGxXLCBjZWxsSCk7XG5cbiAgICAgICAgLy8gRHJhdyBwaG90b1xuICAgICAgICBjdHguZHJhd0ltYWdlKGltZywgeCwgeSwgY2VsbFcsIGNlbGxIKTtcblxuICAgICAgICAvLyBDdXQgbWFya1xuICAgICAgICBjdHguc3Ryb2tlU3R5bGUgPSAnIzk0YTNiOCc7XG4gICAgICAgIGN0eC5saW5lV2lkdGggPSAwLjU7XG4gICAgICAgIGN0eC5zdHJva2VSZWN0KHgsIHksIGNlbGxXLCBjZWxsSCk7XG5cbiAgICAgICAgY291bnQrKztcbiAgICAgIH1cbiAgICB9XG4gIH07XG5cbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvLyBGVUxMIFNIRUVUIDMwMCBEUEkgUkVOREVSIChGb3IgRGlyZWN0IFByaW50aW5nICYgUERGIC8gSlBHIEV4cG9ydClcbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICBjb25zdCByZW5kZXJGdWxsU2hlZXQgPSAoKSA9PiB7XG4gICAgY29uc3QgY2FudmFzID0gZnVsbFNoZWV0Q2FudmFzUmVmLmN1cnJlbnQ7XG4gICAgY29uc3QgaW1nID0gcGhvdG9JbWdSZWYuY3VycmVudDtcbiAgICBpZiAoIWNhbnZhcyB8fCAhaW1nKSByZXR1cm47XG5cbiAgICBjb25zdCBjdHggPSBjYW52YXMuZ2V0Q29udGV4dCgnMmQnKTtcbiAgICBpZiAoIWN0eCkgcmV0dXJuO1xuXG4gICAgY2FudmFzLndpZHRoID0gU0hFRVRfV0lEVEg7XG4gICAgY2FudmFzLmhlaWdodCA9IFNIRUVUX0hFSUdIVDtcblxuICAgIGN0eC5maWxsU3R5bGUgPSAnI2ZmZmZmZic7XG4gICAgY3R4LmZpbGxSZWN0KDAsIDAsIFNIRUVUX1dJRFRILCBTSEVFVF9IRUlHSFQpO1xuXG4gICAgLy8gU2luZ2xlIHBob3RvIGNhbnZhcyBhdCAzMDAgRFBJXG4gICAgY29uc3Qgc2luZ2xlVyA9IDM1MDtcbiAgICBjb25zdCBzaW5nbGVIID0gNDUwO1xuICAgIGNvbnN0IHNpbmdsZUNhbnZhcyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2NhbnZhcycpO1xuICAgIHNpbmdsZUNhbnZhcy53aWR0aCA9IHNpbmdsZVc7XG4gICAgc2luZ2xlQ2FudmFzLmhlaWdodCA9IHNpbmdsZUg7XG4gICAgY29uc3Qgc0N0eCA9IHNpbmdsZUNhbnZhcy5nZXRDb250ZXh0KCcyZCcpO1xuXG4gICAgaWYgKHNDdHgpIHtcbiAgICAgIHNDdHguZmlsbFN0eWxlID0gYmdDb2xvcjtcbiAgICAgIHNDdHguZmlsbFJlY3QoMCwgMCwgc2luZ2xlVywgc2luZ2xlSCk7XG5cbiAgICAgIC8vIENvbG9yIGZpbHRlcnNcbiAgICAgIGNvbnN0IGVmZkJyaWdodG5lc3MgPSAxMDAgKyBicmlnaHRuZXNzICsgKGF1dG9CZWF1dHkgPyA2IDogMCkgKyAoZmFjZUdsb3cgKiAwLjEyKTtcbiAgICAgIGNvbnN0IGVmZkNvbnRyYXN0ID0gMTAwICsgY29udHJhc3QgKyAoYXV0b0JlYXV0eSA/IDQgOiAwKTtcbiAgICAgIGNvbnN0IGVmZlNhdHVyYXRpb24gPSBpc0dyYXlzY2FsZSA/IDAgOiAxMDAgKyBzYXR1cmF0aW9uICsgKGF1dG9CZWF1dHkgPyA4IDogMCk7XG5cbiAgICAgIGxldCBmaWx0ZXJTdHIgPSBgYnJpZ2h0bmVzcygke2VmZkJyaWdodG5lc3N9JSkgY29udHJhc3QoJHtlZmZDb250cmFzdH0lKSBzYXR1cmF0ZSgke2VmZlNhdHVyYXRpb259JSlgO1xuICAgICAgaWYgKGlzR3JheXNjYWxlKSBmaWx0ZXJTdHIgKz0gJyBncmF5c2NhbGUoMTAwJSknO1xuICAgICAgc0N0eC5maWx0ZXIgPSBmaWx0ZXJTdHI7XG5cbiAgICAgIGNvbnN0IGFzcGVjdCA9IGltZy53aWR0aCAvIGltZy5oZWlnaHQ7XG4gICAgICBsZXQgZHcgPSBzaW5nbGVXO1xuICAgICAgbGV0IGRoID0gc2luZ2xlSDtcbiAgICAgIGlmIChhc3BlY3QgPiBzaW5nbGVXIC8gc2luZ2xlSCkge1xuICAgICAgICBkdyA9IHNpbmdsZUggKiBhc3BlY3Q7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBkaCA9IHNpbmdsZVcgLyBhc3BlY3Q7XG4gICAgICB9XG5cbiAgICAgIHNDdHguZHJhd0ltYWdlKGltZywgKHNpbmdsZVcgLSBkdykgLyAyLCAoc2luZ2xlSCAtIGRoKSAvIDIsIGR3LCBkaCk7XG5cbiAgICAgIC8vIFNvZnQgbGlnaHQgYmVhdXR5IHBhc3NcbiAgICAgIGNvbnN0IGVmZlNtb290aCA9IGF1dG9CZWF1dHkgPyBNYXRoLm1heChza2luU21vb3RoLCAxNikgOiBza2luU21vb3RoO1xuICAgICAgY29uc3QgZWZmR2xvdyA9IGF1dG9CZWF1dHkgPyBNYXRoLm1heChmYWNlR2xvdywgMjApIDogZmFjZUdsb3c7XG4gICAgICBpZiAoZWZmU21vb3RoID4gMCB8fCBlZmZHbG93ID4gMCkge1xuICAgICAgICBzQ3R4LnNhdmUoKTtcbiAgICAgICAgc0N0eC5nbG9iYWxDb21wb3NpdGVPcGVyYXRpb24gPSAnc29mdC1saWdodCc7XG4gICAgICAgIHNDdHguZ2xvYmFsQWxwaGEgPSBNYXRoLm1pbigwLjY1LCAoZWZmU21vb3RoICogMC4wMTIpICsgKGVmZkdsb3cgKiAwLjAxKSk7XG4gICAgICAgIHNDdHguZmlsdGVyID0gYGJsdXIoJHtNYXRoLm1heCgyLCBlZmZTbW9vdGggLyA4KX1weCkgYnJpZ2h0bmVzcygxMjAlKWA7XG4gICAgICAgIHNDdHguZHJhd0ltYWdlKGltZywgKHNpbmdsZVcgLSBkdykgLyAyLCAoc2luZ2xlSCAtIGR3KSAvIDIsIGR3LCBkaCk7XG4gICAgICAgIHNDdHgucmVzdG9yZSgpO1xuICAgICAgfVxuXG4gICAgICAvLyBDYW5kaWRhdGUgTmFtZSAmIERhdGUgU3RyaXBcbiAgICAgIGlmIChzaG93TmFtZURhdGUpIHtcbiAgICAgICAgY29uc3QgYm94SCA9IDU4O1xuICAgICAgICBzQ3R4LmZpbGxTdHlsZSA9ICcjZmZmZmZmJztcbiAgICAgICAgc0N0eC5maWxsUmVjdCgwLCBzaW5nbGVIIC0gYm94SCwgc2luZ2xlVywgYm94SCk7XG4gICAgICAgIHNDdHguZmlsbFN0eWxlID0gJyMwMDAwMDAnO1xuICAgICAgICBzQ3R4LmZvbnQgPSAnYm9sZCAxN3B4IHNhbnMtc2VyaWYnO1xuICAgICAgICBzQ3R4LnRleHRBbGlnbiA9ICdjZW50ZXInO1xuICAgICAgICBzQ3R4LmZpbGxUZXh0KGNhbmRpZGF0ZU5hbWUudG9VcHBlckNhc2UoKSwgc2luZ2xlVyAvIDIsIHNpbmdsZUggLSBib3hIICsgMjIpO1xuICAgICAgICBzQ3R4LmZvbnQgPSAnYm9sZCAxNHB4IHNhbnMtc2VyaWYnO1xuICAgICAgICBzQ3R4LmZpbGxUZXh0KGBEQVRFOiAke3Bob3RvRGF0ZX1gLCBzaW5nbGVXIC8gMiwgc2luZ2xlSCAtIGJveEggKyA0NSk7XG4gICAgICAgIHNDdHguc3Ryb2tlU3R5bGUgPSAnIzAwMDAwMCc7XG4gICAgICAgIHNDdHgubGluZVdpZHRoID0gMjtcbiAgICAgICAgc0N0eC5iZWdpblBhdGgoKTtcbiAgICAgICAgc0N0eC5tb3ZlVG8oMCwgc2luZ2xlSCAtIGJveEgpO1xuICAgICAgICBzQ3R4LmxpbmVUbyhzaW5nbGVXLCBzaW5nbGVIIC0gYm94SCk7XG4gICAgICAgIHNDdHguc3Ryb2tlKCk7XG4gICAgICB9XG5cbiAgICAgIHNDdHguc3Ryb2tlU3R5bGUgPSAnIzMzNDE1NSc7XG4gICAgICBzQ3R4LmxpbmVXaWR0aCA9IDI7XG4gICAgICBzQ3R4LnN0cm9rZVJlY3QoMCwgMCwgc2luZ2xlVywgc2luZ2xlSCk7XG4gICAgfVxuXG4gICAgLy8gR3JpZCBwbGFjZW1lbnRcbiAgICBjb25zdCBjb2xzID0gcGFwZXJGb3JtYXQgPT09ICc0eDZfbGFuZHNjYXBlJyA/IDQgOiBwYXBlckZvcm1hdCA9PT0gJ2E0X2xhbmRzY2FwZScgPyAoY29waWVzID09PSAzMiA/IDggOiA0KSA6IDI7XG4gICAgY29uc3Qgcm93cyA9IHBhcGVyRm9ybWF0ID09PSAnNHg2X2xhbmRzY2FwZScgPyAyIDogNDtcblxuICAgIGNvbnN0IGlzQTQgPSBwYXBlckZvcm1hdC5zdGFydHNXaXRoKCdhNCcpO1xuICAgIGNvbnN0IG1hcmdpblggPSBpc0E0ID8gOTAgOiA2MDtcbiAgICBjb25zdCBtYXJnaW5ZID0gaXNBNCA/IDgwIDogNTA7XG4gICAgY29uc3QgYXZhaWxhYmxlVyA9IFNIRUVUX1dJRFRIIC0gbWFyZ2luWCAqIDI7XG4gICAgY29uc3QgYXZhaWxhYmxlSCA9IFNIRUVUX0hFSUdIVCAtIG1hcmdpblkgKiAyO1xuXG4gICAgY29uc3QgZ2FwID0gaXNBNCA/IDIwIDogMTY7XG4gICAgY29uc3QgdGFyZ2V0VyA9IChhdmFpbGFibGVXIC0gKGNvbHMgLSAxKSAqIGdhcCkgLyBjb2xzO1xuICAgIGxldCBkcmF3VyA9IHRhcmdldFc7XG4gICAgbGV0IGRyYXdIID0gdGFyZ2V0VyAqICg0NSAvIDM1KTtcblxuICAgIGlmIChyb3dzICogZHJhd0ggKyAocm93cyAtIDEpICogZ2FwID4gYXZhaWxhYmxlSCkge1xuICAgICAgZHJhd0ggPSAoYXZhaWxhYmxlSCAtIChyb3dzIC0gMSkgKiBnYXApIC8gcm93cztcbiAgICAgIGRyYXdXID0gZHJhd0ggKiAoMzUgLyA0NSk7XG4gICAgfVxuXG4gICAgY29uc3QgZ2FwWCA9IGNvbHMgPiAxID8gKGF2YWlsYWJsZVcgLSBjb2xzICogZHJhd1cpIC8gKGNvbHMgLSAxKSA6IDA7XG4gICAgY29uc3QgZ2FwWSA9IHJvd3MgPiAxID8gKGF2YWlsYWJsZUggLSByb3dzICogZHJhd0gpIC8gKHJvd3MgLSAxKSA6IDA7XG5cbiAgICBsZXQgY291bnQgPSAwO1xuICAgIGZvciAobGV0IHIgPSAwOyByIDwgcm93czsgcisrKSB7XG4gICAgICBmb3IgKGxldCBjID0gMDsgYyA8IGNvbHM7IGMrKykge1xuICAgICAgICBpZiAoY291bnQgPj0gY29waWVzKSBicmVhaztcbiAgICAgICAgY29uc3QgeCA9IG1hcmdpblggKyBjICogKGRyYXdXICsgZ2FwWCk7XG4gICAgICAgIGNvbnN0IHkgPSBtYXJnaW5ZICsgciAqIChkcmF3SCArIGdhcFkpO1xuXG4gICAgICAgIGN0eC5kcmF3SW1hZ2Uoc2luZ2xlQ2FudmFzLCB4LCB5LCBkcmF3VywgZHJhd0gpO1xuICAgICAgICBjdHguc3Ryb2tlU3R5bGUgPSAnIzY0NzQ4Yic7XG4gICAgICAgIGN0eC5saW5lV2lkdGggPSAxO1xuICAgICAgICBjdHguc3Ryb2tlUmVjdCh4LCB5LCBkcmF3VywgZHJhd0gpO1xuICAgICAgICBjb3VudCsrO1xuICAgICAgfVxuICAgIH1cblxuICAgIC8vIENlbnRlciBjdXR0aW5nIGxpbmVcbiAgICBjdHguc2F2ZSgpO1xuICAgIGN0eC5zdHJva2VTdHlsZSA9ICcjOTRhM2I4JztcbiAgICBjdHgubGluZVdpZHRoID0gMS41O1xuICAgIGN0eC5zZXRMaW5lRGFzaChbNiwgNl0pO1xuICAgIGN0eC5iZWdpblBhdGgoKTtcbiAgICBjdHgubW92ZVRvKDMwLCBTSEVFVF9IRUlHSFQgLyAyKTtcbiAgICBjdHgubGluZVRvKFNIRUVUX1dJRFRIIC0gMzAsIFNIRUVUX0hFSUdIVCAvIDIpO1xuICAgIGN0eC5zdHJva2UoKTtcbiAgICBjdHgucmVzdG9yZSgpO1xuICB9O1xuXG4gIC8vIFVwbG9hZCBoYW5kbGVyXG4gIGNvbnN0IGhhbmRsZVVwbG9hZCA9IChlOiBSZWFjdC5DaGFuZ2VFdmVudDxIVE1MSW5wdXRFbGVtZW50PikgPT4ge1xuICAgIGNvbnN0IGZpbGUgPSBlLnRhcmdldC5maWxlcz8uWzBdO1xuICAgIGlmICghZmlsZSkgcmV0dXJuO1xuXG4gICAgY29uc3QgcmVhZGVyID0gbmV3IEZpbGVSZWFkZXIoKTtcbiAgICByZWFkZXIub25sb2FkID0gKGV2ZW50KSA9PiB7XG4gICAgICBjb25zdCBzcmMgPSBldmVudC50YXJnZXQ/LnJlc3VsdCBhcyBzdHJpbmc7XG4gICAgICBzZXRQaG90b1NyYyhzcmMpO1xuICAgICAgc2V0T3JpZ2luYWxQaG90b1NyYyhzcmMpO1xuICAgICAgc2V0SGlzdG9yeVN0YWNrKFtzcmNdKTtcbiAgICAgIHNldEhpc3RvcnlJbmRleCgwKTtcbiAgICAgIHNldENhbnZhc1pvb20oMS4wKTtcbiAgICAgIHNldENhbnZhc1Bhbih7IHg6IDAsIHk6IDAgfSk7XG4gICAgICBzZXRQZW5Qb2ludHMoW10pO1xuICAgICAgc2V0SXNQYXRoQ2xvc2VkKGZhbHNlKTtcbiAgICAgIHNldEF1dG9CZWF1dHkodHJ1ZSk7XG4gICAgICBzZXRBY3RpdmVQcmVzZXQoJ2F1dG9fYmVhdXR5Jyk7XG4gICAgfTtcbiAgICByZWFkZXIucmVhZEFzRGF0YVVSTChmaWxlKTtcbiAgICBlLnRhcmdldC52YWx1ZSA9ICcnO1xuICB9O1xuXG4gIC8vIERpcmVjdCBJbi1BcHAgUHJpbnRcbiAgY29uc3QgaGFuZGxlRGlyZWN0UHJpbnQgPSAoKSA9PiB7XG4gICAgY29uc3QgY2FudmFzID0gZnVsbFNoZWV0Q2FudmFzUmVmLmN1cnJlbnQ7XG4gICAgaWYgKCFjYW52YXMpIHJldHVybjtcblxuICAgIHRyeSB7XG4gICAgICBjb25zdCBkYXRhVXJsID0gY2FudmFzLnRvRGF0YVVSTCgnaW1hZ2UvanBlZycsIDEuMCk7XG4gICAgICBwcmludEltYWdlU2hlZXQoZGF0YVVybCwge1xuICAgICAgICBwYXBlckZvcm1hdCxcbiAgICAgICAgdGl0bGU6IGBQYXNzcG9ydF8ke3BhcGVyRm9ybWF0fV8ke2NvcGllc31Db3BpZXNgLFxuICAgICAgICBjb3BpZXNDb3VudDogY29waWVzXG4gICAgICB9KTtcblxuICAgICAgc2V0UHJpbnRBbGVydChg8J+WqO+4jyBQcmludCBjb21tYW5kIHNlbnQgdG8gcHJpbnRlciEgKCR7cGFwZXJGb3JtYXQucmVwbGFjZSgnXycsICcgJykudG9VcHBlckNhc2UoKX0g4oCiICR7Y29waWVzfSBDb3BpZXMpYCk7XG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHNldFByaW50QWxlcnQobnVsbCksIDQwMDApO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoZSk7XG4gICAgICB3aW5kb3cucHJpbnQoKTtcbiAgICB9XG4gIH07XG5cbiAgLy8gRG93bmxvYWQgUERGXG4gIGNvbnN0IGhhbmRsZURvd25sb2FkU2hlZXRQREYgPSAoKSA9PiB7XG4gICAgY29uc3QgY2FudmFzID0gZnVsbFNoZWV0Q2FudmFzUmVmLmN1cnJlbnQ7XG4gICAgaWYgKCFjYW52YXMpIHJldHVybjtcblxuICAgIHRyeSB7XG4gICAgICBjb25zdCBkYXRhVXJsID0gY2FudmFzLnRvRGF0YVVSTCgnaW1hZ2UvanBlZycsIDAuOTgpO1xuICAgICAgY29uc3QgaXNMYW5kc2NhcGUgPSBwYXBlckZvcm1hdC5pbmNsdWRlcygnbGFuZHNjYXBlJyk7XG4gICAgICBjb25zdCBpc0E0ID0gcGFwZXJGb3JtYXQuc3RhcnRzV2l0aCgnYTQnKTtcblxuICAgICAgY29uc3QgcGRmID0gbmV3IGpzUERGKHtcbiAgICAgICAgb3JpZW50YXRpb246IGlzTGFuZHNjYXBlID8gJ2xhbmRzY2FwZScgOiAncG9ydHJhaXQnLFxuICAgICAgICB1bml0OiBpc0E0ID8gJ21tJyA6ICdpbicsXG4gICAgICAgIGZvcm1hdDogaXNBNCA/ICdhNCcgOiBbNCwgNl1cbiAgICAgIH0pO1xuXG4gICAgICBpZiAoaXNBNCkge1xuICAgICAgICBwZGYuYWRkSW1hZ2UoZGF0YVVybCwgJ0pQRUcnLCAwLCAwLCBpc0xhbmRzY2FwZSA/IDI5NyA6IDIxMCwgaXNMYW5kc2NhcGUgPyAyMTAgOiAyOTcpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcGRmLmFkZEltYWdlKGRhdGFVcmwsICdKUEVHJywgMCwgMCwgaXNMYW5kc2NhcGUgPyA2IDogNCwgaXNMYW5kc2NhcGUgPyA0IDogNik7XG4gICAgICB9XG5cbiAgICAgIGNvbnN0IGZpbGVOYW1lID0gYFBhc3Nwb3J0XyR7cGFwZXJGb3JtYXR9XyR7Y29waWVzfV9Db3BpZXNfJHtEYXRlLm5vdygpfS5wZGZgO1xuICAgICAgcGRmLnNhdmUoZmlsZU5hbWUpO1xuXG4gICAgICBhZGREb3dubG9hZFJlY29yZCh7XG4gICAgICAgIGlkOiBgcGFzcy1wZGYtJHtEYXRlLm5vdygpfWAsXG4gICAgICAgIHRpdGxlOiBmaWxlTmFtZSxcbiAgICAgICAgdHlwZTogJ1Bhc3Nwb3J0IFNoZWV0IFBERicsXG4gICAgICAgIHNpemU6IGAke3BhcGVyRm9ybWF0LnJlcGxhY2UoJ18nLCAnICcpfSAoJHtjb3BpZXN9IENvcGllcylgLFxuICAgICAgICB0aW1lc3RhbXA6IG5ldyBEYXRlKCkudG9Mb2NhbGVUaW1lU3RyaW5nKCdlbi1JTicpXG4gICAgICB9KTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBjb25zb2xlLmVycm9yKGUpO1xuICAgIH1cbiAgfTtcblxuICAvLyBEb3dubG9hZCBIRCBKUEdcbiAgY29uc3QgaGFuZGxlRG93bmxvYWRTaGVldEpQRyA9ICgpID0+IHtcbiAgICBjb25zdCBjYW52YXMgPSBmdWxsU2hlZXRDYW52YXNSZWYuY3VycmVudDtcbiAgICBpZiAoIWNhbnZhcykgcmV0dXJuO1xuXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGRhdGFVcmwgPSBjYW52YXMudG9EYXRhVVJMKCdpbWFnZS9qcGVnJywgMC45OCk7XG4gICAgICBjb25zdCBhID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnYScpO1xuICAgICAgYS5ocmVmID0gZGF0YVVybDtcbiAgICAgIGNvbnN0IGZpbGVOYW1lID0gYFBhc3Nwb3J0XyR7cGFwZXJGb3JtYXR9XyR7Y29waWVzfV9Db3BpZXNfMzAwRFBJXyR7RGF0ZS5ub3coKX0uanBnYDtcbiAgICAgIGEuZG93bmxvYWQgPSBmaWxlTmFtZTtcbiAgICAgIGEuY2xpY2soKTtcblxuICAgICAgYWRkRG93bmxvYWRSZWNvcmQoe1xuICAgICAgICBpZDogYHBhc3MtanBnLSR7RGF0ZS5ub3coKX1gLFxuICAgICAgICB0aXRsZTogZmlsZU5hbWUsXG4gICAgICAgIHR5cGU6ICdQYXNzcG9ydCBTaGVldCBKUEcnLFxuICAgICAgICBzaXplOiBgJHtwYXBlckZvcm1hdC5yZXBsYWNlKCdfJywgJyAnKX0gKCR7Y29waWVzfSBDb3BpZXMgMzAwIERQSSlgLFxuICAgICAgICB0aW1lc3RhbXA6IG5ldyBEYXRlKCkudG9Mb2NhbGVUaW1lU3RyaW5nKCdlbi1JTicpXG4gICAgICB9KTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBjb25zb2xlLmVycm9yKGUpO1xuICAgIH1cbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zIHNlbGVjdC1ub25lXCI+XG4gICAgICB7LyogSGlkZGVuIEZ1bGwgU2hlZXQgMzAwIERQSSBDYW52YXMgZm9yIFByaW50ICYgRXhwb3J0cyAqL31cbiAgICAgIDxjYW52YXMgcmVmPXtmdWxsU2hlZXRDYW52YXNSZWZ9IGNsYXNzTmFtZT1cImhpZGRlblwiIC8+XG5cbiAgICAgIHsvKiBUT1AgTk9USUZJQ0FUSU9OIEJBTk5FUiAqL31cbiAgICAgIHtwcmludEFsZXJ0ICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMgcm91bmRlZC14bCBiZy1lbWVyYWxkLTUwMC8xMCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtNTAwLzMwIHRleHQtZW1lcmFsZC00MDAgdGV4dC14cyBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gYW5pbWF0ZS1pbiBmYWRlLWluXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgPENoZWNrQ2lyY2xlMiBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtZW1lcmFsZC00MDAgZmxleC1zaHJpbmstMFwiIC8+XG4gICAgICAgICAgICA8c3Bhbj57cHJpbnRBbGVydH08L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXRQcmludEFsZXJ0KG51bGwpfSBjbGFzc05hbWU9XCJ0ZXh0LWVtZXJhbGQtNDAwIGhvdmVyOnRleHQtd2hpdGVcIj7inJU8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuXG4gICAgICB7LyogUEhPVE9TSE9QLVNUWUxFIFRPUCBPUFRJT05TIEJBUiAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtMnhsIHB4LTQgcHktMi41IGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMyBzaGFkb3ctbWQgZmxleC13cmFwIHRleHQteHNcIj5cbiAgICAgICAgey8qIExlZnQ6IEFjdGl2ZSBUb29sIE5hbWUgJiBEeW5hbWljIFRvb2wgQ29udHJvbHMgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgZmxleC13cmFwXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBwci0zIGJvcmRlci1yIGJvcmRlci1zbGF0ZS04MDBcIj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtZXh0cmFib2xkIHRleHQtd2hpdGUgdGV4dC1zbSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCI+XG4gICAgICAgICAgICAgIHthY3RpdmVUb29sID09PSAnc2VsZWN0JyAmJiA8c3Bhbj7ihpbvuI8gUG9pbnRlciAoVik8L3NwYW4+fVxuICAgICAgICAgICAgICB7YWN0aXZlVG9vbCA9PT0gJ21hZ2ljX3dhbmQnICYmIDxzcGFuPvCfqoQgTWFnaWMgV2FuZCBDdXQgKFcpPC9zcGFuPn1cbiAgICAgICAgICAgICAge2FjdGl2ZVRvb2wgPT09ICdwZW5fdG9vbCcgJiYgPHNwYW4+8J+Wiu+4jyBQZW4gVG9vbCAoUCk8L3NwYW4+fVxuICAgICAgICAgICAgICB7YWN0aXZlVG9vbCA9PT0gJ2Nyb3AnICYmIDxzcGFuPuKcgu+4jyBQYXNzcG9ydCBDcm9wIChDKTwvc3Bhbj59XG4gICAgICAgICAgICAgIHthY3RpdmVUb29sID09PSAnYmxlbWlzaF9icnVzaCcgJiYgPHNwYW4+8J+puSBTcG90IEhlYWxpbmcgKEIpPC9zcGFuPn1cbiAgICAgICAgICAgICAge2FjdGl2ZVRvb2wgPT09ICdiZWF1dHlfYnJ1c2gnICYmIDxzcGFuPuKcqCBCZWF1dHkgQWlyYnJ1c2ggKFMpPC9zcGFuPn1cbiAgICAgICAgICAgICAge2FjdGl2ZVRvb2wgPT09ICdleWVfYnJpZ2h0ZW4nICYmIDxzcGFuPvCfkYHvuI8gRXllL1RlZXRoIEJyaWdodGVuIChFKTwvc3Bhbj59XG4gICAgICAgICAgICAgIHthY3RpdmVUb29sID09PSAnaGFuZCcgJiYgPHNwYW4+4pyLIEhhbmQgUGFuIChIKTwvc3Bhbj59XG4gICAgICAgICAgICAgIHthY3RpdmVUb29sID09PSAnem9vbScgJiYgPHNwYW4+8J+UjSBab29tIChaKTwvc3Bhbj59XG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogRHluYW1pYyBvcHRpb25zIHdoZW4gTWFnaWMgV2FuZCBpcyBhY3RpdmUgKi99XG4gICAgICAgICAge2FjdGl2ZVRvb2wgPT09ICdtYWdpY193YW5kJyAmJiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGFuaW1hdGUtaW4gZmFkZS1pblwiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMFwiPlRvbGVyYW5jZTo8L3NwYW4+XG4gICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgIHR5cGU9XCJyYW5nZVwiXG4gICAgICAgICAgICAgICAgbWluPVwiMTBcIlxuICAgICAgICAgICAgICAgIG1heD1cIjY1XCJcbiAgICAgICAgICAgICAgICB2YWx1ZT17bWFnaWNUb2xlcmFuY2V9XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRNYWdpY1RvbGVyYW5jZShOdW1iZXIoZS50YXJnZXQudmFsdWUpKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTIwIGFjY2VudC1za3ktNDAwIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICB0aXRsZT1cIkNvbG9yIHNpbWlsYXJpdHkgZGlzdGFuY2UgKDEwLTY1KVwiXG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ubyB0ZXh0LXdoaXRlIGZvbnQtYm9sZFwiPnttYWdpY1RvbGVyYW5jZX08L3NwYW4+XG5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUF1dG9CYWNrZ3JvdW5kRXJhc2V9XG4gICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzUHJvY2Vzc2luZyB8fCAhcGhvdG9TcmN9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWwtMiBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSBiZy1ncmFkaWVudC10by1yIGZyb20tcHVycGxlLTYwMCB0by1pbmRpZ28tNjAwIGhvdmVyOmZyb20tcHVycGxlLTUwMCBob3Zlcjp0by1pbmRpZ28tNTAwIHRleHQtd2hpdGUgZm9udC1ib2xkIHB4LTMgcHktMSByb3VuZGVkLWxnIHNoYWRvdy1zbVwiXG4gICAgICAgICAgICAgICAgdGl0bGU9XCIxLUNsaWNrIEF1dG8gRXJhc2VzIGJvcmRlcnMgaW53YXJkc1wiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8U3BhcmtsZXMgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICAgICAgICAgIDxzcGFuPjEtQ2xpY2sgQXV0byBDdXQ8L3NwYW4+XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIHsvKiBEeW5hbWljIG9wdGlvbnMgd2hlbiBQZW4gVG9vbCBpcyBhY3RpdmUgKi99XG4gICAgICAgICAge2FjdGl2ZVRvb2wgPT09ICdwZW5fdG9vbCcgJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBhbmltYXRlLWluIGZhZGUtaW5cIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgZm9udC1tb25vIHRleHQtWzExcHhdXCI+XG4gICAgICAgICAgICAgICAge3BlblBvaW50cy5sZW5ndGh9IFBvaW50cyB7aXNQYXRoQ2xvc2VkID8gJ+KAoiBQYXRoIENsb3NlZCcgOiAnJ31cbiAgICAgICAgICAgICAgPC9zcGFuPlxuXG4gICAgICAgICAgICAgIHshaXNQYXRoQ2xvc2VkICYmIHBlblBvaW50cy5sZW5ndGggPj0gMyAmJiAoXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0SXNQYXRoQ2xvc2VkKHRydWUpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMi41IHB5LTEgYmctZW1lcmFsZC02MDAgaG92ZXI6YmctZW1lcmFsZC01MDAgdGV4dC13aGl0ZSBmb250LWJvbGQgcm91bmRlZC1sZ1wiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgQ2xvc2UgUGF0aFxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgIHtwZW5Qb2ludHMubGVuZ3RoID49IDMgJiYgKFxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUFwcGx5UGVuQ3V0b3V0fVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgcHgtMyBweS0xIGJnLWdyYWRpZW50LXRvLXIgZnJvbS1lbWVyYWxkLTYwMCB0by10ZWFsLTYwMCB0ZXh0LXdoaXRlIGZvbnQtYm9sZCByb3VuZGVkLWxnIHNoYWRvdy1tZFwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPENoZWNrIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cbiAgICAgICAgICAgICAgICAgIDxzcGFuPkFwcGx5IEN1dG91dDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4geyBzZXRQZW5Qb2ludHMoW10pOyBzZXRJc1BhdGhDbG9zZWQoZmFsc2UpOyB9fVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTIgcHktMSBiZy1zbGF0ZS04MDAgdGV4dC1yb3NlLTMwMCBmb250LWJvbGQgcm91bmRlZC1sZyBob3ZlcjpiZy1yb3NlLTkwMC8zMFwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICBDbGVhclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICB7LyogRHluYW1pYyBvcHRpb25zIHdoZW4gQ3JvcCBpcyBhY3RpdmUgKi99XG4gICAgICAgICAge2FjdGl2ZVRvb2wgPT09ICdjcm9wJyAmJiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGFuaW1hdGUtaW4gZmFkZS1pblwiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJiZy1za3ktNTAwLzIwIHRleHQtc2t5LTMwMCBweC0yIHB5LTAuNSByb3VuZGVkIGZvbnQtbW9ubyBmb250LWJvbGRcIj5cbiAgICAgICAgICAgICAgICBSYXRpbzogMzXDlzQ1bW0gU3RhbmRhcmRcbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQXBwbHlDcm9wfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTMgcHktMSBiZy1lbWVyYWxkLTYwMCBob3ZlcjpiZy1lbWVyYWxkLTUwMCB0ZXh0LXdoaXRlIGZvbnQtYm9sZCByb3VuZGVkLWxnIHNoYWRvd1wiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICBBcHBseSBDcm9wXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4geyBzZXRDcm9wQm94KG51bGwpOyBzZXRBY3RpdmVUb29sKCdzZWxlY3QnKTsgfX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0yIHB5LTEgYmctc2xhdGUtODAwIHRleHQtc2xhdGUtMzAwIGZvbnQtYm9sZCByb3VuZGVkLWxnXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIENhbmNlbFxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICB7LyogRHluYW1pYyBvcHRpb25zIHdoZW4gQnJ1c2hlcyBhcmUgYWN0aXZlICovfVxuICAgICAgICAgIHsoYWN0aXZlVG9vbCA9PT0gJ2JsZW1pc2hfYnJ1c2gnIHx8IGFjdGl2ZVRvb2wgPT09ICdiZWF1dHlfYnJ1c2gnIHx8IGFjdGl2ZVRvb2wgPT09ICdleWVfYnJpZ2h0ZW4nKSAmJiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGFuaW1hdGUtaW4gZmFkZS1pblwiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMFwiPkJydXNoIFNpemU6PC9zcGFuPlxuICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICB0eXBlPVwicmFuZ2VcIlxuICAgICAgICAgICAgICAgIG1pbj1cIjhcIlxuICAgICAgICAgICAgICAgIG1heD1cIjcwXCJcbiAgICAgICAgICAgICAgICB2YWx1ZT17YnJ1c2hTaXplfVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0QnJ1c2hTaXplKE51bWJlcihlLnRhcmdldC52YWx1ZSkpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMjAgYWNjZW50LWFtYmVyLTQwMCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ubyB0ZXh0LXdoaXRlIGZvbnQtYm9sZFwiPnticnVzaFNpemV9cHg8L3NwYW4+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNTAwIHRleHQtWzEwcHhdXCI+VXNlIFsgYW5kIF0gdG8gcmVzaXplPC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIHsvKiBTdHVkaW8gQmFja2dyb3VuZCBTd2F0Y2hlcyAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcGwtMyBib3JkZXItbCBib3JkZXItc2xhdGUtODAwXCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMFwiPkJHOjwvc3Bhbj5cbiAgICAgICAgICAgIHtbXG4gICAgICAgICAgICAgIHsgbmFtZTogJ1doaXRlJywgY29sb3I6ICcjZmZmZmZmJyB9LFxuICAgICAgICAgICAgICB7IG5hbWU6ICdTa3kgQmx1ZScsIGNvbG9yOiAnI2NjZTNmOCcgfSxcbiAgICAgICAgICAgICAgeyBuYW1lOiAnU3R1ZGlvIEJsdWUnLCBjb2xvcjogJyMyNTYzZWInIH0sXG4gICAgICAgICAgICAgIHsgbmFtZTogJ0dyZXknLCBjb2xvcjogJyNlMmU4ZjAnIH0sXG4gICAgICAgICAgICAgIHsgbmFtZTogJ1JlZCcsIGNvbG9yOiAnI2RjMjYyNicgfVxuICAgICAgICAgICAgXS5tYXAoKGMpID0+IChcbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIGtleT17Yy5uYW1lfVxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEJnQ29sb3IoYy5jb2xvcil9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdy01IGgtNSByb3VuZGVkLWZ1bGwgYm9yZGVyIHNoYWRvdy1zbSB0cmFuc2l0aW9uLXRyYW5zZm9ybSAke1xuICAgICAgICAgICAgICAgICAgYmdDb2xvciA9PT0gYy5jb2xvciA/ICdzY2FsZS0xMjUgcmluZy0yIHJpbmctc2t5LTQwMCBib3JkZXItd2hpdGUnIDogJ2JvcmRlci1zbGF0ZS01MDAgaG92ZXI6c2NhbGUtMTEwJ1xuICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgIHN0eWxlPXt7IGJhY2tncm91bmRDb2xvcjogYy5jb2xvciB9fVxuICAgICAgICAgICAgICAgIHRpdGxlPXtgQ2hhbmdlIHN0dWRpbyBiYWNrZ3JvdW5kIHRvICR7Yy5uYW1lfWB9XG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICApKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIFJpZ2h0OiBVbmRvIC8gUmVkbyAmIFByaW50IC8gRXhwb3J0IGFjdGlvbnMgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICB7LyogVW5kbyAvIFJlZG8gKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC1sZyBwLTAuNVwiPlxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVVbmRvfVxuICAgICAgICAgICAgICBkaXNhYmxlZD17aGlzdG9yeUluZGV4IDw9IDAgJiYgcGVuUG9pbnRzLmxlbmd0aCA9PT0gMH1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xLjUgdGV4dC1zbGF0ZS0zMDAgaG92ZXI6dGV4dC13aGl0ZSBkaXNhYmxlZDpvcGFjaXR5LTMwIGRpc2FibGVkOmhvdmVyOnRleHQtc2xhdGUtMzAwXCJcbiAgICAgICAgICAgICAgdGl0bGU9XCJVbmRvIChDdHJsICsgWilcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8VW5kbzIgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZVJlZG99XG4gICAgICAgICAgICAgIGRpc2FibGVkPXtoaXN0b3J5SW5kZXggPj0gaGlzdG9yeVN0YWNrLmxlbmd0aCAtIDF9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMS41IHRleHQtc2xhdGUtMzAwIGhvdmVyOnRleHQtd2hpdGUgZGlzYWJsZWQ6b3BhY2l0eS0zMCBkaXNhYmxlZDpob3Zlcjp0ZXh0LXNsYXRlLTMwMFwiXG4gICAgICAgICAgICAgIHRpdGxlPVwiUmVkbyAoQ3RybCArIFkpXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPFJlZG8yIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIE1pbmkgUHJldmlldyBUb2dnbGUgQnV0dG9uICovfVxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dNaW5pUHJldmlldyhwcmV2ID0+ICFwcmV2KX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXggaXRlbXMtY2VudGVyIGdhcC0xIHB4LTIuNSBweS0xLjUgcm91bmRlZC1sZyBib3JkZXIgZm9udC1ib2xkIHRleHQteHMgdHJhbnNpdGlvbi1jb2xvcnMgJHtcbiAgICAgICAgICAgICAgc2hvd01pbmlQcmV2aWV3ID8gJ2JnLXNreS02MDAvMjAgdGV4dC1za3ktMzAwIGJvcmRlci1za3ktNTAwLzQwJyA6ICdiZy1zbGF0ZS04MDAgdGV4dC1zbGF0ZS00MDAgYm9yZGVyLXNsYXRlLTcwMCdcbiAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgdGl0bGU9XCJUb2dnbGUgTWluaSBTaGVldCBQcmV2aWV3IChNKVwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPExheWVycyBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XG4gICAgICAgICAgICA8c3Bhbj5NaW5pIFByZXZpZXcgKE0pPC9zcGFuPlxuICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgey8qIERpcmVjdCBQcmludCBCdXR0b24gKi99XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17aGFuZGxlRGlyZWN0UHJpbnR9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IGJnLWdyYWRpZW50LXRvLXIgZnJvbS1ibHVlLTYwMCB2aWEtaW5kaWdvLTYwMCB0by1ibHVlLTUwMCBob3Zlcjpmcm9tLWJsdWUtNTAwIGhvdmVyOnRvLWluZGlnby01MDAgdGV4dC13aGl0ZSBmb250LWV4dHJhYm9sZCBweC0zLjUgcHktMS41IHJvdW5kZWQteGwgc2hhZG93LWxnIHNoYWRvdy1ibHVlLTYwMC8zMCB0cmFuc2l0aW9uLWFsbCBob3ZlcjpzY2FsZS0xMDVcIlxuICAgICAgICAgICAgdGl0bGU9XCJEaXJlY3QgUHJpbnQgU2hlZXQgKEN0cmwgKyBQKVwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPFByaW50ZXIgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC13aGl0ZVwiIC8+XG4gICAgICAgICAgICA8c3Bhbj7wn5ao77iPIFByaW50IFNoZWV0IChDdHJsK1ApPC9zcGFuPlxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogTUFJTiBQSE9UT1NIT1AgV09SS1NQQUNFIENPTlRBSU5FUiAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBsZzpncmlkLWNvbHMtMTIgZ2FwLTMgaXRlbXMtc3RhcnQgbWluLWgtWzY0MHB4XVwiPlxuICAgICAgICB7LyogMS4gTEVGVCBQSE9UT1NIT1AgVkVSVElDQUwgVE9PTEJBUiAoMSBDb2x1bW4pICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxnOmNvbC1zcGFuLTEgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtMnhsIHAtMiBmbGV4IGxnOmZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiBzaGFkb3ctbGdcIj5cbiAgICAgICAgICB7LyogVG9vbCBJY29ucyAqL31cbiAgICAgICAgICB7W1xuICAgICAgICAgICAgeyBpZDogJ3NlbGVjdCcsIGxhYmVsOiAnUG9pbnRlciAvIE1vdmUgKFYpJywgaWNvbjogJ+KGlu+4jycgfSxcbiAgICAgICAgICAgIHsgaWQ6ICdjcm9wJywgbGFiZWw6ICdQYXNzcG9ydCBDcm9wIChDKScsIGljb246ICfinILvuI8nIH0sXG4gICAgICAgICAgICB7IGlkOiAnbWFnaWNfd2FuZCcsIGxhYmVsOiAnTWFnaWMgV2FuZCAvIEN1dCAoVyknLCBpY29uOiAn8J+qhCcgfSxcbiAgICAgICAgICAgIHsgaWQ6ICdwZW5fdG9vbCcsIGxhYmVsOiAnUGVuIFRvb2wgQ3V0b3V0IChQKScsIGljb246ICfwn5aK77iPJyB9LFxuICAgICAgICAgICAgeyBpZDogJ2JsZW1pc2hfYnJ1c2gnLCBsYWJlbDogJ1Nwb3QgSGVhbGluZyBCcnVzaCAoQiknLCBpY29uOiAn8J+puScgfSxcbiAgICAgICAgICAgIHsgaWQ6ICdiZWF1dHlfYnJ1c2gnLCBsYWJlbDogJ1NraW4gQWlyYnJ1c2ggKFMpJywgaWNvbjogJ+KcqCcgfSxcbiAgICAgICAgICAgIHsgaWQ6ICdleWVfYnJpZ2h0ZW4nLCBsYWJlbDogJ0V5ZS9UZWV0aCBXaGl0ZW5lciAoRSknLCBpY29uOiAn8J+Rge+4jycgfSxcbiAgICAgICAgICAgIHsgaWQ6ICdoYW5kJywgbGFiZWw6ICdIYW5kIFRvb2wgUGFuIChIIC8gU3BhY2UpJywgaWNvbjogJ+KciycgfSxcbiAgICAgICAgICAgIHsgaWQ6ICd6b29tJywgbGFiZWw6ICdab29tIFRvb2wgKFopJywgaWNvbjogJ/CflI0nIH1cbiAgICAgICAgICBdLm1hcCgodCkgPT4ge1xuICAgICAgICAgICAgY29uc3QgaXNBY3RpdmUgPSBhY3RpdmVUb29sID09PSB0LmlkO1xuICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIGtleT17dC5pZH1cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICBzZXRBY3RpdmVUb29sKHQuaWQgYXMgQWN0aXZlVG9vbCk7XG4gICAgICAgICAgICAgICAgICBpZiAodC5pZCA9PT0gJ2Nyb3AnKSBpbml0Q3JvcEJveCgpO1xuICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdy0xMCBoLTEwIHJvdW5kZWQteGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC1sZyB0cmFuc2l0aW9uLWFsbCAke1xuICAgICAgICAgICAgICAgICAgaXNBY3RpdmVcbiAgICAgICAgICAgICAgICAgICAgPyAnYmctYmx1ZS02MDAgdGV4dC13aGl0ZSBzaGFkb3ctbGcgc2hhZG93LWJsdWUtNjAwLzQwIHJpbmctMiByaW5nLWJsdWUtNDAwIHNjYWxlLTEwNSdcbiAgICAgICAgICAgICAgICAgICAgOiAnYmctc2xhdGUtOTUwIHRleHQtc2xhdGUtMzAwIGhvdmVyOmJnLXNsYXRlLTgwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMC84MCBob3Zlcjp0ZXh0LXdoaXRlJ1xuICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgIHRpdGxlPXt0LmxhYmVsfVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPHNwYW4+e3QuaWNvbn08L3NwYW4+XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgKTtcbiAgICAgICAgICB9KX1cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy04IGJvcmRlci10IGJvcmRlci1zbGF0ZS04MDAgbXktMSBoaWRkZW4gbGc6YmxvY2tcIiAvPlxuXG4gICAgICAgICAgey8qIFVwbG9hZCBCdXR0b24gKi99XG4gICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInctMTAgaC0xMCByb3VuZGVkLXhsIGJnLXB1cnBsZS02MDAvMjAgYm9yZGVyIGJvcmRlci1wdXJwbGUtNTAwLzQwIHRleHQtcHVycGxlLTMwMCBob3ZlcjpiZy1wdXJwbGUtNjAwLzMwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGN1cnNvci1wb2ludGVyIHRyYW5zaXRpb24tY29sb3JzXCIgdGl0bGU9XCJVcGxvYWQgQ3VzdG9tZXIgUGhvdG9cIj5cbiAgICAgICAgICAgIDxVcGxvYWQgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICA8aW5wdXQgdHlwZT1cImZpbGVcIiBhY2NlcHQ9XCJpbWFnZS8qXCIgb25DaGFuZ2U9e2hhbmRsZVVwbG9hZH0gY2xhc3NOYW1lPVwiaGlkZGVuXCIgLz5cbiAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogMi4gQ0VOVEVSIEJJRyBFRElUSU5HIENBTlZBUyBXT1JLU1BBQ0UgKDggQ29sdW1ucyBvciAxMSBDb2x1bW5zIGlmIG1pbmkgcHJldmlldyBjb2xsYXBzZWQpICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YCR7c2hvd01pbmlQcmV2aWV3ID8gJ2xnOmNvbC1zcGFuLTgnIDogJ2xnOmNvbC1zcGFuLTExJ30gcmVsYXRpdmUgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtMnhsIG92ZXJmbG93LWhpZGRlbiBzaGFkb3ctMnhsIGZsZXggZmxleC1jb2wganVzdGlmeS1iZXR3ZWVuIG1pbi1oLVs2NDBweF1gfT5cbiAgICAgICAgICB7LyogWm9vbSAvIEluZm8gT3ZlcmxheSBCYXIgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtMyBsZWZ0LTMgei0xMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBiZy1zbGF0ZS05MDAvODUgYmFja2Ryb3AtYmx1ci1zbSBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBweC0zIHB5LTEuNSByb3VuZGVkLXhsIHRleHQtWzExcHhdIHRleHQtc2xhdGUtMzAwIHBvaW50ZXItZXZlbnRzLW5vbmVcIj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXdoaXRlXCI+UGhvdG9zaG9wIFN0dWRpbyBDYW52YXM8L3NwYW4+XG4gICAgICAgICAgICA8c3Bhbj7igKI8L3NwYW4+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1vbm8gdGV4dC1za3ktNDAwIGZvbnQtYm9sZFwiPntNYXRoLnJvdW5kKGNhbnZhc1pvb20gKiAxMDApfSU8L3NwYW4+XG4gICAgICAgICAgICA8c3Bhbj7igKI8L3NwYW4+XG4gICAgICAgICAgICA8c3Bhbj5Ib2xkIFNwYWNlYmFyICsgRHJhZyB0byBQYW4g4oCiIFdoZWVsIHRvIFpvb208L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogQ2VudGVyIENhbnZhcyAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTIgb3ZlcmZsb3ctaGlkZGVuXCI+XG4gICAgICAgICAgICA8Y2FudmFzXG4gICAgICAgICAgICAgIHJlZj17ZWRpdG9yQ2FudmFzUmVmfVxuICAgICAgICAgICAgICBvbk1vdXNlRG93bj17aGFuZGxlRWRpdG9yTW91c2VEb3dufVxuICAgICAgICAgICAgICBvbk1vdXNlTW92ZT17aGFuZGxlRWRpdG9yTW91c2VNb3ZlfVxuICAgICAgICAgICAgICBvbk1vdXNlVXA9e2hhbmRsZUVkaXRvck1vdXNlVXB9XG4gICAgICAgICAgICAgIG9uTW91c2VMZWF2ZT17aGFuZGxlRWRpdG9yTW91c2VVcH1cbiAgICAgICAgICAgICAgb25XaGVlbD17aGFuZGxlRWRpdG9yV2hlZWx9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17YG1heC13LWZ1bGwgbWF4LWgtWzU4MHB4XSB3LWF1dG8gaC1hdXRvIHJvdW5kZWQtbGcgc2hhZG93LTJ4bCAke1xuICAgICAgICAgICAgICAgIGlzU3BhY2VQcmVzc2VkIHx8IGFjdGl2ZVRvb2wgPT09ICdoYW5kJ1xuICAgICAgICAgICAgICAgICAgPyAnY3Vyc29yLWdyYWIgYWN0aXZlOmN1cnNvci1ncmFiYmluZydcbiAgICAgICAgICAgICAgICAgIDogYWN0aXZlVG9vbCA9PT0gJ21hZ2ljX3dhbmQnIHx8IGFjdGl2ZVRvb2wgPT09ICdwZW5fdG9vbCdcbiAgICAgICAgICAgICAgICAgID8gJ2N1cnNvci1jcm9zc2hhaXInXG4gICAgICAgICAgICAgICAgICA6IGFjdGl2ZVRvb2wgPT09ICdibGVtaXNoX2JydXNoJyB8fCBhY3RpdmVUb29sID09PSAnYmVhdXR5X2JydXNoJyB8fCBhY3RpdmVUb29sID09PSAnZXllX2JyaWdodGVuJ1xuICAgICAgICAgICAgICAgICAgPyAnY3Vyc29yLWNlbGwnXG4gICAgICAgICAgICAgICAgICA6ICdjdXJzb3ItZGVmYXVsdCdcbiAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIEJvdHRvbSBDYW52YXMgUXVpY2sgU3RhdHVzIEJhciAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMC84MCBib3JkZXItdCBib3JkZXItc2xhdGUtODAwLzgwIHB4LTQgcHktMiBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gdGV4dC14cyB0ZXh0LXNsYXRlLTQwMCBmbGV4LXdyYXAgZ2FwLTJcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgPHNwYW4+VG9vbDogPHN0cm9uZyBjbGFzc05hbWU9XCJ0ZXh0LXdoaXRlIHVwcGVyY2FzZVwiPnthY3RpdmVUb29sLnJlcGxhY2UoJ18nLCAnICcpfTwvc3Ryb25nPjwvc3Bhbj5cbiAgICAgICAgICAgICAge3Bob3RvU3JjICYmIChcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWVtZXJhbGQtNDAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xIGZvbnQtc2VtaWJvbGRcIj5cbiAgICAgICAgICAgICAgICAgIDxDaGVjayBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+IEhpZ2gtUmVzb2x1dGlvbiBQaG90byBSZWFkeVxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7IHNldENhbnZhc1pvb20oMS4wKTsgc2V0Q2FudmFzUGFuKHsgeDogMCwgeTogMCB9KTsgfX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0yIHB5LTAuNSBiZy1zbGF0ZS04MDAgaG92ZXI6Ymctc2xhdGUtNzAwIHRleHQtc2xhdGUtMjAwIHJvdW5kZWQgdGV4dC1bMTFweF0gZm9udC1tb25vXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIEZpdCBTY3JlZW4gKEN0cmwrMClcbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRDYW52YXNab29tKHByZXYgPT4gTWF0aC5taW4oNC4wLCBwcmV2ICsgMC4yNSkpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTIgcHktMC41IGJnLXNsYXRlLTgwMCBob3ZlcjpiZy1zbGF0ZS03MDAgdGV4dC1zbGF0ZS0yMDAgcm91bmRlZCB0ZXh0LVsxMXB4XSBmb250LW1vbm9cIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgK1xuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldENhbnZhc1pvb20ocHJldiA9PiBNYXRoLm1heCgwLjQsIHByZXYgLSAwLjI1KSl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMiBweS0wLjUgYmctc2xhdGUtODAwIGhvdmVyOmJnLXNsYXRlLTcwMCB0ZXh0LXNsYXRlLTIwMCByb3VuZGVkIHRleHQtWzExcHhdIGZvbnQtbW9ub1wiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAtXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiAzLiBSSUdIVCBTSURFOiBDT01QQUNUIE1JTkkgUFJFVklFVyAmIEFESlVTVE1FTlRTICgzIENvbHVtbnMpICovfVxuICAgICAgICB7c2hvd01pbmlQcmV2aWV3ICYmIChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxnOmNvbC1zcGFuLTMgc3BhY2UteS0zXCI+XG4gICAgICAgICAgICB7LyogTUlOSSBTSEVFVCBQUkVWSUVXIFdJREdFVCAoXCJwcmV2aWV3IG1pbmkgZGlraG5hIGNoYWl5ZVwiKSAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtMnhsIHAtMyBzaGFkb3cteGwgc3BhY2UteS0yLjVcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcGItMS41IGJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDBcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtZXh0cmFib2xkIHRleHQtd2hpdGUgdGV4dC14c1wiPk1pbmkgU2hlZXQgUHJldmlldzwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtbW9ubyBiZy1ibHVlLTUwMC8yMCB0ZXh0LWJsdWUtMzAwIHB4LTEuNSBweS0wLjUgcm91bmRlZCBmb250LWJvbGRcIj5cbiAgICAgICAgICAgICAgICAgICAge3BhcGVyRm9ybWF0ID09PSAnNHg2X2xhbmRzY2FwZScgPyAnNMOXNiAoOCknIDogJ0E0J31cbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93TWluaVByZXZpZXcoZmFsc2UpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xIHRleHQtc2xhdGUtNTAwIGhvdmVyOnRleHQtd2hpdGUgcm91bmRlZFwiXG4gICAgICAgICAgICAgICAgICB0aXRsZT1cIkhpZGUgTWluaSBQcmV2aWV3IChNKVwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPE1pbmltaXplMiBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHsvKiBNaW5pYXR1cmUgQ2FudmFzICovfVxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGZsZXgganVzdGlmeS1jZW50ZXIgYmctc2xhdGUtOTUwIHAtMiByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtODAwIG92ZXJmbG93LWhpZGRlbiBzaGFkb3ctaW5uZXJcIj5cbiAgICAgICAgICAgICAgICA8Y2FudmFzXG4gICAgICAgICAgICAgICAgICByZWY9e21pbmlQcmV2aWV3Q2FudmFzUmVmfVxuICAgICAgICAgICAgICAgICAgd2lkdGg9ezI0MH1cbiAgICAgICAgICAgICAgICAgIGhlaWdodD17MTYwfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtYXV0byBiZy13aGl0ZSByb3VuZGVkIHNoYWRvdy1tZCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCBwb2ludGVyLWV2ZW50cy1ub25lXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7LyogRm9ybWF0IFN3aXRjaGVyICovfVxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHsgc2V0UGFwZXJGb3JtYXQoJzR4Nl9sYW5kc2NhcGUnKTsgc2V0Q29waWVzKDgpOyB9fVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHktMS41IHB4LTIgcm91bmRlZC1sZyB0ZXh0LXhzIGZvbnQtYm9sZCB0cmFuc2l0aW9uLWFsbCB0ZXh0LWNlbnRlciAke1xuICAgICAgICAgICAgICAgICAgICBwYXBlckZvcm1hdCA9PT0gJzR4Nl9sYW5kc2NhcGUnXG4gICAgICAgICAgICAgICAgICAgICAgPyAnYmctYmx1ZS02MDAgdGV4dC13aGl0ZSBzaGFkb3cnXG4gICAgICAgICAgICAgICAgICAgICAgOiAnYmctc2xhdGUtOTUwIHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtd2hpdGUnXG4gICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA0w5c2ICg4IENvcGllcylcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7IHNldFBhcGVyRm9ybWF0KCdhNF9sYW5kc2NhcGUnKTsgc2V0Q29waWVzKDMyKTsgfX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB5LTEuNSBweC0yIHJvdW5kZWQtbGcgdGV4dC14cyBmb250LWJvbGQgdHJhbnNpdGlvbi1hbGwgdGV4dC1jZW50ZXIgJHtcbiAgICAgICAgICAgICAgICAgICAgcGFwZXJGb3JtYXQgPT09ICdhNF9sYW5kc2NhcGUnXG4gICAgICAgICAgICAgICAgICAgICAgPyAnYmctcHVycGxlLTYwMCB0ZXh0LXdoaXRlIHNoYWRvdydcbiAgICAgICAgICAgICAgICAgICAgICA6ICdiZy1zbGF0ZS05NTAgdGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC13aGl0ZSdcbiAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIEE0IExhbmRzY2FwZVxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7LyogRGlyZWN0IFByaW50IEJ1dHRvbiBvbiBNaW5pIFByZXZpZXcgKi99XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVEaXJlY3RQcmludH1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTEuNSBiZy1ncmFkaWVudC10by1yIGZyb20tYmx1ZS02MDAgdG8taW5kaWdvLTYwMCBob3Zlcjpmcm9tLWJsdWUtNTAwIGhvdmVyOnRvLWluZGlnby01MDAgdGV4dC13aGl0ZSBmb250LWV4dHJhYm9sZCB0ZXh0LXhzIHB5LTIgcm91bmRlZC14bCBzaGFkb3ctbWQgdHJhbnNpdGlvbi1hbGwgYWN0aXZlOnNjYWxlLTk1XCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxQcmludGVyIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cbiAgICAgICAgICAgICAgICA8c3Bhbj7wn5ao77iPIFByaW50IFNoZWV0IE5vdzwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIEFVVE8gQkVBVVRZICYgUFJFU0VUUyBBQ0NPUkRJT04gKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTJ4bCBwLTMuNSBzaGFkb3ctbWQgc3BhY2UteS0yLjVcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXdoaXRlIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCI+XG4gICAgICAgICAgICAgICAgICA8U3BhcmtsZXMgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1hbWJlci00MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgPHNwYW4+QXV0byBCZWF1dHkgUHJlc2V0czwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1hbWJlci00MDAgZm9udC1ib2xkIGJnLWFtYmVyLTUwMC8xMCBweC0xLjUgcHktMC41IHJvdW5kZWRcIj5cbiAgICAgICAgICAgICAgICAgIDEtQ2xpY2tcbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtMS41XCI+XG4gICAgICAgICAgICAgICAge0JFQVVUWV9QUkVTRVRTLm1hcCgocCkgPT4ge1xuICAgICAgICAgICAgICAgICAgY29uc3QgaXNTZWxlY3RlZCA9IGFjdGl2ZVByZXNldCA9PT0gcC5pZCAmJiBhdXRvQmVhdXR5O1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgIGtleT17cC5pZH1cbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRBY3RpdmVQcmVzZXQocC5pZCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRCcmlnaHRuZXNzKHAuc2V0dGluZ3MuYnJpZ2h0bmVzcyk7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRDb250cmFzdChwLnNldHRpbmdzLmNvbnRyYXN0KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldFNhdHVyYXRpb24ocC5zZXR0aW5ncy5zYXR1cmF0aW9uKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldFdhcm10aChwLnNldHRpbmdzLndhcm10aCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRUaW50KHAuc2V0dGluZ3MudGludCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRTa2luU21vb3RoKHAuc2V0dGluZ3Muc2tpblNtb290aCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRGYWNlR2xvdyhwLnNldHRpbmdzLmZhY2VHbG93KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldFNoYWRvd0xpZnQocC5zZXR0aW5ncy5zaGFkb3dMaWZ0KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldElzR3JheXNjYWxlKHAuc2V0dGluZ3MuaXNHcmF5c2NhbGUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0QXV0b0JlYXV0eSh0cnVlKTtcbiAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHAtMiByb3VuZGVkLXhsIHRleHQtbGVmdCBib3JkZXIgdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlzU2VsZWN0ZWRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctYW1iZXItNTAwLzEwIGJvcmRlci1hbWJlci01MDAvNjAgdGV4dC13aGl0ZSByaW5nLTEgcmluZy1hbWJlci01MDAvMzAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDogJ2JnLXNsYXRlLTk1MCBib3JkZXItc2xhdGUtODAwLzgwIHRleHQtc2xhdGUtMzAwIGhvdmVyOmJnLXNsYXRlLTgwMCdcbiAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdHJ1bmNhdGUgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPntwLmljb259PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidHJ1bmNhdGVcIj57cC5uYW1lfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgIH0pfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogQ09MT1IgR1JBRElORyBTTElERVJTIFBBTkVMICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0yeGwgcC0zLjUgc2hhZG93LW1kIHNwYWNlLXktMyB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHBiLTEgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXdoaXRlIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCI+XG4gICAgICAgICAgICAgICAgICA8U2xpZGVycyBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LWJsdWUtNDAwXCIgLz5cbiAgICAgICAgICAgICAgICAgIDxzcGFuPkNvbG9yIEdyYWRpbmcgJiBTa2luPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHNldEJyaWdodG5lc3MoMCk7XG4gICAgICAgICAgICAgICAgICAgIHNldENvbnRyYXN0KDApO1xuICAgICAgICAgICAgICAgICAgICBzZXRTYXR1cmF0aW9uKDApO1xuICAgICAgICAgICAgICAgICAgICBzZXRXYXJtdGgoMCk7XG4gICAgICAgICAgICAgICAgICAgIHNldFRpbnQoMCk7XG4gICAgICAgICAgICAgICAgICAgIHNldFNraW5TbW9vdGgoMCk7XG4gICAgICAgICAgICAgICAgICAgIHNldEZhY2VHbG93KDApO1xuICAgICAgICAgICAgICAgICAgICBzZXRJc0dyYXlzY2FsZShmYWxzZSk7XG4gICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC13aGl0ZVwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgUmVzZXRcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgey8qIFNraW4gU21vb3RoICovfVxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gdGV4dC1zbGF0ZS00MDAgbWItMC41XCI+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWFtYmVyLTMwMCBmb250LXNlbWlib2xkXCI+U2tpbiBTbW9vdGhpbmc8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1vbm8gdGV4dC13aGl0ZVwiPntza2luU21vb3RofSU8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICB0eXBlPVwicmFuZ2VcIlxuICAgICAgICAgICAgICAgICAgbWluPVwiMFwiXG4gICAgICAgICAgICAgICAgICBtYXg9XCI1MFwiXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17c2tpblNtb290aH1cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2tpblNtb290aChOdW1iZXIoZS50YXJnZXQudmFsdWUpKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBhY2NlbnQtYW1iZXItNTAwIGN1cnNvci1wb2ludGVyIGgtMS41IGJnLXNsYXRlLTgwMCByb3VuZGVkXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7LyogQnJpZ2h0bmVzcyAqL31cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIHRleHQtc2xhdGUtNDAwIG1iLTAuNVwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4+QnJpZ2h0bmVzczwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ubyB0ZXh0LXdoaXRlXCI+e2JyaWdodG5lc3MgPiAwID8gYCske2JyaWdodG5lc3N9YCA6IGJyaWdodG5lc3N9JTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJyYW5nZVwiXG4gICAgICAgICAgICAgICAgICBtaW49XCItMzBcIlxuICAgICAgICAgICAgICAgICAgbWF4PVwiMzBcIlxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2JyaWdodG5lc3N9XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEJyaWdodG5lc3MoTnVtYmVyKGUudGFyZ2V0LnZhbHVlKSl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYWNjZW50LWJsdWUtNTAwIGN1cnNvci1wb2ludGVyIGgtMS41IGJnLXNsYXRlLTgwMCByb3VuZGVkXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7LyogQ29udHJhc3QgKi99XG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiB0ZXh0LXNsYXRlLTQwMCBtYi0wLjVcIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuPkNvbnRyYXN0PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vIHRleHQtd2hpdGVcIj57Y29udHJhc3QgPiAwID8gYCske2NvbnRyYXN0fWAgOiBjb250cmFzdH0lPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgdHlwZT1cInJhbmdlXCJcbiAgICAgICAgICAgICAgICAgIG1pbj1cIi0zMFwiXG4gICAgICAgICAgICAgICAgICBtYXg9XCIzMFwiXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17Y29udHJhc3R9XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldENvbnRyYXN0KE51bWJlcihlLnRhcmdldC52YWx1ZSkpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGFjY2VudC1ibHVlLTUwMCBjdXJzb3ItcG9pbnRlciBoLTEuNSBiZy1zbGF0ZS04MDAgcm91bmRlZFwiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgey8qIFdhcm10aCAqL31cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIHRleHQtc2xhdGUtNDAwIG1iLTAuNVwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4+V2FybXRoIC8gVG9uZTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ubyB0ZXh0LXdoaXRlXCI+e3dhcm10aCA+IDAgPyBgKyR7d2FybXRofWAgOiB3YXJtdGh9PC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgdHlwZT1cInJhbmdlXCJcbiAgICAgICAgICAgICAgICAgIG1pbj1cIi0zMFwiXG4gICAgICAgICAgICAgICAgICBtYXg9XCIzMFwiXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17d2FybXRofVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRXYXJtdGgoTnVtYmVyKGUudGFyZ2V0LnZhbHVlKSl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYWNjZW50LW9yYW5nZS01MDAgY3Vyc29yLXBvaW50ZXIgaC0xLjUgYmctc2xhdGUtODAwIHJvdW5kZWRcIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHsvKiBDYW5kaWRhdGUgRXhhbSBTdHJpcCAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwdC0yIGJvcmRlci10IGJvcmRlci1zbGF0ZS04MDBcIj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGN1cnNvci1wb2ludGVyXCI+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbGF0ZS0zMDBcIj5FeGFtIE5hbWUgJiBEYXRlIFN0cmlwPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXG4gICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3Nob3dOYW1lRGF0ZX1cbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTaG93TmFtZURhdGUoZS50YXJnZXQuY2hlY2tlZCl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImFjY2VudC1ibHVlLTUwMCByb3VuZGVkXCJcbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICB7c2hvd05hbWVEYXRlICYmIChcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMiBzcGFjZS15LTEuNVwiPlxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJDYW5kaWRhdGUgTmFtZVwiXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2NhbmRpZGF0ZU5hbWV9XG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRDYW5kaWRhdGVOYW1lKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQgcHgtMiBweS0xIHRleHQtd2hpdGUgdGV4dC1bMTFweF0gZm9udC1ib2xkXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRGF0ZSAoREQvTU0vWVlZWSlcIlxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtwaG90b0RhdGV9XG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRQaG90b0RhdGUoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZCBweC0yIHB5LTEgdGV4dC13aGl0ZSB0ZXh0LVsxMXB4XSBmb250LWJvbGRcIlxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKX1cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufTtcbiJdfQ==