export const ALL_GOV_PORTALS = [
	(
	// Citizen IDs
	{
		id: "uidai",
		title: "Aadhaar Card (myAadhaar)",
		category: "citizen_id",
		url: "https://myaadhaar.uidai.gov.in/",
		icon: "🪪",
		description: "Download e-Aadhaar, Order PVC Card, Address Update, Check Status & Biometric Lock.",
		requiredDocs: [
			"Aadhaar Number / Enrollment ID",
			"Registered Mobile Number (OTP)",
			"Proof of Address (for update)"
		],
		popular: true,
		portalType: "central"
	}),
	{
		id: "pan_uti",
		title: "PAN Card (UTIITSL / NSDL)",
		category: "citizen_id",
		url: "https://www.pan.utiitsl.com/",
		icon: "💳",
		description: "New PAN 49A, PAN Correction, Reprint e-PAN, Link Aadhaar & Track Status.",
		requiredDocs: [
			"Aadhaar Card",
			"Passport Photo (2)",
			"Signature",
			"Old PAN copy (for correction)"
		],
		popular: true,
		portalType: "central"
	},
	{
		id: "voter_eci",
		title: "Voter ID (ECI Portal)",
		category: "citizen_id",
		url: "https://voters.eci.gov.in/",
		icon: "🗳️",
		description: "New Voter Registration (Form 6), Correction (Form 8), Shift Residence & Download e-EPIC.",
		requiredDocs: [
			"Aadhaar Card / Age Proof",
			"Address Proof (Electricity Bill / Ration Card)",
			"Passport Photo"
		],
		popular: true,
		portalType: "central"
	},
	{
		id: "ayushman_pmjay",
		title: "Ayushman Bharat (PM-JAY)",
		category: "citizen_id",
		url: "https://beneficiary.nha.gov.in/",
		icon: "🏥",
		description: "Ayushman Golden Card generation (₹5 Lakh Free Treatment), eKYC & Beneficiary search.",
		requiredDocs: [
			"Ration Card (Yellow/Orange)",
			"Aadhaar Card of all members",
			"Mobile with OTP"
		],
		popular: true,
		portalType: "central"
	},
	{
		id: "abha_health",
		title: "ABHA Health Card (ABDM)",
		category: "citizen_id",
		url: "https://abha.abdm.gov.in/",
		icon: "🩺",
		description: "Ayushman Bharat Health Account 14-digit digital card creation & health records linking.",
		requiredDocs: ["Aadhaar Card", "Aadhaar linked Mobile OTP"],
		popular: true,
		portalType: "central"
	},
	{
		id: "eshram_portal",
		title: "e-Shram Card",
		category: "citizen_id",
		url: "https://eshram.gov.in/",
		icon: "👷",
		description: "National Database for Unorganized Workers, accidental insurance & financial assistance.",
		requiredDocs: [
			"Aadhaar Card",
			"Bank Passbook / Account details",
			"Active Mobile Number"
		],
		popular: true,
		portalType: "central"
	},
	(
	// State Schemes (Maharashtra & Regional)
	{
		id: "ladki_bahin",
		title: "Majhi Ladki Bahin Yojana",
		category: "state_scheme",
		url: "https://ladakibahin.maharashtra.gov.in/",
		icon: "👩",
		description: "Maharashtra Govt scheme: ₹1,500/month financial aid for eligible women aged 21-65.",
		requiredDocs: [
			"Aadhaar Card",
			"Maharashtra Domicile / Ration Card / Birth Cert",
			"Income Certificate (<2.5L) or Yellow/Orange Ration Card",
			"Aadhaar Seeded Bank Account",
			"Applicant Photo"
		],
		popular: true,
		portalType: "state"
	}),
	{
		id: "ladki_bahin_wcd",
		title: "Ladki Bahin – WCD Dept",
		category: "state_scheme",
		url: "https://womenchild.maharashtra.gov.in/",
		icon: "📋",
		description: "Women & Child Development department notices, guidelines, and official GRs.",
		requiredDocs: [
			"Aadhaar Card",
			"Bank Passbook",
			"Ration Card"
		],
		portalType: "state"
	},
	{
		id: "aaple_sarkar",
		title: "Aaple Sarkar Maharashtra",
		category: "state_scheme",
		url: "https://aaplesarkar.mahaonline.gov.in/",
		icon: "🏛️",
		description: "Online Revenue Services: Income Certificate, Caste Certificate, Domicile, Non-Creamy Layer, 7/12 & 8A.",
		requiredDocs: [
			"Aadhaar Card",
			"Ration Card",
			"Self-Declaration Form",
			"School Leaving Certificate",
			"Income Proof / Talathi report"
		],
		popular: true,
		portalType: "state"
	},
	{
		id: "mahadbt",
		title: "MahaDBT Scholarship Portal",
		category: "state_scheme",
		url: "https://mahadbt.maharashtra.gov.in/",
		icon: "🎓",
		description: "Post-Matric Scholarships, EBC fee reimbursement, Dr. Punjabrao Deshmukh hostel scheme.",
		requiredDocs: [
			"Aadhaar Card",
			"Caste Certificate & Validity",
			"Income Certificate",
			"College Allotment / Fee Receipt",
			"Mark sheets"
		],
		popular: true,
		portalType: "state"
	},
	{
		id: "mahabhulekh",
		title: "Mahabhulekh (7/12 Online)",
		category: "revenue",
		url: "https://bhulekh.mahabhumi.gov.in/",
		icon: "🌾",
		description: "Maharashtra Digital Satbara (7/12 extract), 8A property card & digital land records.",
		requiredDocs: ["District, Taluka, Village Name", "Survey / Gat Number"],
		portalType: "state"
	},
	(
	// Central Schemes
	{
		id: "pm_kisan",
		title: "PM-KISAN Samman Nidhi",
		category: "central_scheme",
		url: "https://pmkisan.gov.in/",
		icon: "🌾",
		description: "₹6,000/year farmer benefit in 3 instalments, online biometric/face eKYC, beneficiary status.",
		requiredDocs: [
			"Aadhaar Card",
			"7/12 Land Record",
			"Aadhaar Seeded Bank Account",
			"Mobile OTP"
		],
		popular: true,
		portalType: "central"
	}),
	{
		id: "pm_surya_ghar",
		title: "PM Surya Ghar (Muft Bijli)",
		category: "central_scheme",
		url: "https://pmsuryaghar.gov.in/",
		icon: "☀️",
		description: "Rooftop Solar Subsidy up to ₹78,000 for up to 300 units free electricity every month.",
		requiredDocs: [
			"Latest Electricity Bill",
			"Aadhaar Card",
			"Roof Photo / Electricity Consumer No",
			"Bank Account Details"
		],
		popular: true,
		portalType: "central"
	},
	{
		id: "pm_awas",
		title: "PM Awas Yojana (PMAY-G/U)",
		category: "central_scheme",
		url: "https://pmaymis.gov.in/",
		icon: "🏠",
		description: "Housing for All subsidy scheme for urban and rural families to build pucca houses.",
		requiredDocs: [
			"Aadhaar Card of all family members",
			"Income Certificate",
			"Land / Property Ownership Document",
			"Bank Passbook"
		],
		popular: true,
		portalType: "central"
	},
	{
		id: "pm_vishwakarma",
		title: "PM Vishwakarma Yojana",
		category: "central_scheme",
		url: "https://pmvishwakarma.gov.in/",
		icon: "🛠️",
		description: "₹3 Lakh collateral-free loan, tool kit incentive ₹15,000 & skill training for 18 traditional trades.",
		requiredDocs: [
			"Aadhaar Card",
			"Mobile Number",
			"Bank Details",
			"Ration Card",
			"Trade Skill Certificate / Self Declaration"
		],
		popular: true,
		portalType: "central"
	},
	{
		id: "pm_svanidhi",
		title: "PM SVANidhi (Street Vendors)",
		category: "central_scheme",
		url: "https://pmsvanidhi.mohua.gov.in/",
		icon: "🛺",
		description: "Working capital micro-credit loan (₹10,000 to ₹50,000) with 7% interest subsidy for street vendors.",
		requiredDocs: [
			"Aadhaar Card",
			"Vending Certificate / Urban Local Body Survey Card",
			"Bank Account"
		],
		portalType: "central"
	},
	{
		id: "pm_fasal_bima",
		title: "PM Fasal Bima Yojana (PMFBY)",
		category: "central_scheme",
		url: "https://pmfby.gov.in/",
		icon: "🌱",
		description: "Crop insurance protection against natural calamities, pests, and unseasonal rainfall.",
		requiredDocs: [
			"7/12 extract & Sowing Certificate",
			"Aadhaar Card",
			"Bank Passbook"
		],
		portalType: "central"
	},
	{
		id: "pm_jandhan",
		title: "PM Jan-Dhan Yojana (PMJDY)",
		category: "central_scheme",
		url: "https://pmjdy.gov.in/",
		icon: "🏦",
		description: "Zero balance savings account with RuPay debit card, ₹2 Lakh accidental insurance & overdraft.",
		requiredDocs: [
			"Aadhaar Card",
			"Passport size photo",
			"Mobile Number"
		],
		portalType: "central"
	},
	{
		id: "pm_mudra",
		title: "PM Mudra Yojana (PMMY)",
		category: "central_scheme",
		url: "https://www.mudra.org.in/",
		icon: "💳",
		description: "Business micro-loans up to ₹10 Lakh (Shishu, Kishore, Tarun) for small enterprises.",
		requiredDocs: [
			"Aadhaar & PAN Card",
			"Business address proof",
			"6 months Bank Statement",
			"Quotation / Project report"
		],
		portalType: "central"
	},
	{
		id: "pm_ujjwala",
		title: "PM Ujjwala Yojana 2.0",
		category: "central_scheme",
		url: "https://www.pmuy.gov.in/",
		icon: "🔥",
		description: "Free LPG gas connection with first cylinder and stove subsidy for women in BPL households.",
		requiredDocs: [
			"BPL Ration Card",
			"Aadhaar Card of adult family members",
			"Bank Account with IFSC"
		],
		portalType: "central"
	},
	{
		id: "epfo_uan",
		title: "EPFO / UAN Member Portal",
		category: "central_scheme",
		url: "https://unifiedportal-mem.epfindia.gov.in/memberinterface/",
		icon: "🏢",
		description: "Provident Fund Passbook, PF Advance Withdrawal (Form 31/19/10C), KYC Update & Transfer.",
		requiredDocs: [
			"UAN Number",
			"EPFO Password",
			"Aadhaar Linked Mobile (for OTP)",
			"Bank Account Verification"
		],
		popular: true,
		portalType: "central"
	},
	(
	// Transport & Driving
	{
		id: "parivahan_sarathi",
		title: "Parivahan Sarathi (Driving Licence)",
		category: "transport",
		url: "https://sarathi.parivahan.gov.in/",
		icon: "🚗",
		description: "Learner's Licence test, Permanent Driving Licence slot booking, DL Renewal & Address Change.",
		requiredDocs: [
			"Aadhaar Card",
			"Medical Certificate (Form 1A if age >40)",
			"Passport Photo",
			"Signature"
		],
		popular: true,
		portalType: "central"
	}),
	{
		id: "parivahan_vahan",
		title: "Parivahan Vahan (Vehicle RC)",
		category: "transport",
		url: "https://vahan.parivahan.gov.in/",
		icon: "🏍️",
		description: "RC Transfer, Duplicate RC, High Security Number Plate (HSRP), Pollution PUC & Tax payment.",
		requiredDocs: [
			"Vehicle Registration Number",
			"Chassis Number (last 5 digits)",
			"Insurance copy",
			"Owner Aadhaar"
		],
		portalType: "central"
	},
	{
		id: "mahasarathi",
		title: "MahaSarathi Transport Portal",
		category: "transport",
		url: "https://mahasarathi.maharashtra.gov.in/",
		icon: "🚌",
		description: "Maharashtra state citizen transport helpline, online permit services and citizen grievance.",
		requiredDocs: ["Aadhaar Card", "Vehicle RC"],
		portalType: "state"
	},
	(
	// Business & MSME
	{
		id: "udyam_msme",
		title: "Udyam MSME Registration",
		category: "utility",
		url: "https://udyamregistration.gov.in/",
		icon: "🏭",
		description: "Free official Central MSME certificate for shops, cyber cafes, traders, and small businesses.",
		requiredDocs: [
			"Aadhaar Card (linked with mobile)",
			"PAN Card",
			"Bank Account details",
			"Business Name & Start Date"
		],
		popular: true,
		portalType: "central"
	}),
	{
		id: "passport_seva",
		title: "Passport Seva Kendra (PSK)",
		category: "utility",
		url: "https://www.passportindia.gov.in/",
		icon: "✈️",
		description: "Fresh Indian Passport application, Tatkaal passport, Police Clearance Certificate (PCC).",
		requiredDocs: [
			"Aadhaar Card",
			"PAN Card",
			"10th Marksheet / Birth Certificate",
			"Bank Passbook / Electricity Bill"
		],
		popular: true,
		portalType: "central"
	},
	{
		id: "csc_portal",
		title: "Digital Seva CSC Portal",
		category: "utility",
		url: "https://digitalseva.csc.gov.in/",
		icon: "🌐",
		description: "Common Service Centre VLE portal for government G2C and B2C citizen services.",
		requiredDocs: [
			"CSC ID",
			"Password",
			"Biometric / IRIS Device"
		],
		portalType: "direct"
	},
	(
	// Banking & Retailer Mitra Portals
	{
		id: "airtel_mitra",
		title: "Airtel Payments Bank Mitra",
		category: "banking",
		url: "https://portal.airtelbank.com/",
		icon: "📱",
		description: "Retailer portal for AePS cash withdrawal, money transfer, micro-ATM & utility bill payment.",
		requiredDocs: [
			"Mitra Mobile Number",
			"LAPU Password",
			"Biometric Device"
		],
		portalType: "direct"
	}),
	{
		id: "spice_money",
		title: "Spice Money Retailer",
		category: "banking",
		url: "https://b2b.spicemoney.com/",
		icon: "🌶️",
		description: "B2B portal for Aadhaar ATM, DMT, mATM, railway IRCTC booking, PAN card and bill payment.",
		requiredDocs: [
			"Spice Money ID",
			"Password",
			"OTP"
		],
		portalType: "direct"
	},
	{
		id: "paynearby",
		title: "PayNearby Retailer",
		category: "banking",
		url: "https://portal.paynearby.in/",
		icon: "💰",
		description: "Retailer platform for Digital Pradhan, cash deposit, credit card bill & loan repayment.",
		requiredDocs: ["PayNearby ID", "Password"],
		portalType: "direct"
	}
];
export const SERVICE_CATEGORIES = [
	{
		id: "all",
		label: "All Services",
		icon: "▦"
	},
	{
		id: "citizen_id",
		label: "Citizen IDs",
		icon: "🪪"
	},
	{
		id: "state_scheme",
		label: "Maharashtra Schemes",
		icon: "🏛️"
	},
	{
		id: "central_scheme",
		label: "Central Schemes",
		icon: "🌾"
	},
	{
		id: "transport",
		label: "Transport & DL",
		icon: "🚗"
	},
	{
		id: "banking",
		label: "Banking & AePS",
		icon: "🏦"
	},
	{
		id: "revenue",
		label: "Revenue & 7/12",
		icon: "📜"
	},
	{
		id: "utility",
		label: "MSME & Business",
		icon: "🏭"
	}
];
export const COMMON_SHOP_SERVICES = [
	{
		name: "Custom Citizen Service (Manual Pricing)",
		category: "General",
		govtFee: 0,
		serviceFee: 0
	},
	{
		name: "PVC Aadhaar / PAN / Smart Card Print",
		category: "PVC Printing",
		govtFee: 0,
		serviceFee: 0
	},
	{
		name: "Passport Photos (8 Copies 4x6)",
		category: "Photography",
		govtFee: 0,
		serviceFee: 0
	},
	{
		name: "Passport Photos (16 Copies A4)",
		category: "Photography",
		govtFee: 0,
		serviceFee: 0
	},
	{
		name: "Majhi Ladki Bahin Yojana Application",
		category: "Govt Schemes",
		govtFee: 0,
		serviceFee: 0
	},
	{
		name: "New PAN Card Application (Form 49A)",
		category: "PAN Services",
		govtFee: 0,
		serviceFee: 0
	},
	{
		name: "PAN Card Correction / Update",
		category: "PAN Services",
		govtFee: 0,
		serviceFee: 0
	},
	{
		name: "PAN - Aadhaar Link Online",
		category: "PAN Services",
		govtFee: 0,
		serviceFee: 0
	},
	{
		name: "PM-KISAN eKYC / New Registration",
		category: "Farmer Schemes",
		govtFee: 0,
		serviceFee: 0
	},
	{
		name: "PM Surya Ghar Rooftop Solar Application",
		category: "Govt Schemes",
		govtFee: 0,
		serviceFee: 0
	},
	{
		name: "Ayushman Bharat Card Generation",
		category: "Health Schemes",
		govtFee: 0,
		serviceFee: 0
	},
	{
		name: "New Voter ID Form 6 Application",
		category: "Election",
		govtFee: 0,
		serviceFee: 0
	},
	{
		name: "Learner's Driving Licence Slot & Test",
		category: "RTO / Transport",
		govtFee: 0,
		serviceFee: 0
	},
	{
		name: "Aaple Sarkar Income / Domicile Certificate",
		category: "Revenue",
		govtFee: 0,
		serviceFee: 0
	},
	{
		name: "Professional CV / Resume / BioData (A4)",
		category: "Documentation",
		govtFee: 0,
		serviceFee: 0
	},
	{
		name: "e-Shram Card Registration / Download",
		category: "Labor Schemes",
		govtFee: 0,
		serviceFee: 0
	},
	{
		name: "Udyam MSME Registration Certificate",
		category: "Business",
		govtFee: 0,
		serviceFee: 0
	},
	{
		name: "Aadhaar Address Update Online",
		category: "Aadhaar",
		govtFee: 0,
		serviceFee: 0
	},
	{
		name: "EPFO PF Advance Withdrawal Form 31",
		category: "EPFO",
		govtFee: 0,
		serviceFee: 0
	},
	{
		name: "High-Res Color Print / Lamination",
		category: "Printing",
		govtFee: 0,
		serviceFee: 0
	},
	{
		name: "PDF to HD JPG Conversion / Scanning",
		category: "Scanning",
		govtFee: 0,
		serviceFee: 0
	}
];

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBRUEsT0FBTyxNQUFNLGtCQUFnQzs7O0NBRTNDO0VBQ0UsSUFBSTtFQUNKLE9BQU87RUFDUCxVQUFVO0VBQ1YsS0FBSztFQUNMLE1BQU07RUFDTixhQUFhO0VBQ2IsY0FBYztHQUFDO0dBQWtDO0dBQWtDO0VBQStCO0VBQ2xILFNBQVM7RUFDVCxZQUFZO0NBQ2Q7Q0FDQTtFQUNFLElBQUk7RUFDSixPQUFPO0VBQ1AsVUFBVTtFQUNWLEtBQUs7RUFDTCxNQUFNO0VBQ04sYUFBYTtFQUNiLGNBQWM7R0FBQztHQUFnQjtHQUFzQjtHQUFhO0VBQStCO0VBQ2pHLFNBQVM7RUFDVCxZQUFZO0NBQ2Q7Q0FDQTtFQUNFLElBQUk7RUFDSixPQUFPO0VBQ1AsVUFBVTtFQUNWLEtBQUs7RUFDTCxNQUFNO0VBQ04sYUFBYTtFQUNiLGNBQWM7R0FBQztHQUE0QjtHQUFrRDtFQUFnQjtFQUM3RyxTQUFTO0VBQ1QsWUFBWTtDQUNkO0NBQ0E7RUFDRSxJQUFJO0VBQ0osT0FBTztFQUNQLFVBQVU7RUFDVixLQUFLO0VBQ0wsTUFBTTtFQUNOLGFBQWE7RUFDYixjQUFjO0dBQUM7R0FBK0I7R0FBK0I7RUFBaUI7RUFDOUYsU0FBUztFQUNULFlBQVk7Q0FDZDtDQUNBO0VBQ0UsSUFBSTtFQUNKLE9BQU87RUFDUCxVQUFVO0VBQ1YsS0FBSztFQUNMLE1BQU07RUFDTixhQUFhO0VBQ2IsY0FBYyxDQUFDLGdCQUFnQiwyQkFBMkI7RUFDMUQsU0FBUztFQUNULFlBQVk7Q0FDZDtDQUNBO0VBQ0UsSUFBSTtFQUNKLE9BQU87RUFDUCxVQUFVO0VBQ1YsS0FBSztFQUNMLE1BQU07RUFDTixhQUFhO0VBQ2IsY0FBYztHQUFDO0dBQWdCO0dBQW1DO0VBQXNCO0VBQ3hGLFNBQVM7RUFDVCxZQUFZO0NBQ2Q7OztDQUdBO0VBQ0UsSUFBSTtFQUNKLE9BQU87RUFDUCxVQUFVO0VBQ1YsS0FBSztFQUNMLE1BQU07RUFDTixhQUFhO0VBQ2IsY0FBYztHQUFDO0dBQWdCO0dBQW1EO0dBQTJEO0dBQStCO0VBQWlCO0VBQzdMLFNBQVM7RUFDVCxZQUFZO0NBQ2Q7Q0FDQTtFQUNFLElBQUk7RUFDSixPQUFPO0VBQ1AsVUFBVTtFQUNWLEtBQUs7RUFDTCxNQUFNO0VBQ04sYUFBYTtFQUNiLGNBQWM7R0FBQztHQUFnQjtHQUFpQjtFQUFhO0VBQzdELFlBQVk7Q0FDZDtDQUNBO0VBQ0UsSUFBSTtFQUNKLE9BQU87RUFDUCxVQUFVO0VBQ1YsS0FBSztFQUNMLE1BQU07RUFDTixhQUFhO0VBQ2IsY0FBYztHQUFDO0dBQWdCO0dBQWU7R0FBeUI7R0FBOEI7RUFBK0I7RUFDcEksU0FBUztFQUNULFlBQVk7Q0FDZDtDQUNBO0VBQ0UsSUFBSTtFQUNKLE9BQU87RUFDUCxVQUFVO0VBQ1YsS0FBSztFQUNMLE1BQU07RUFDTixhQUFhO0VBQ2IsY0FBYztHQUFDO0dBQWdCO0dBQWdDO0dBQXNCO0dBQW1DO0VBQWE7RUFDckksU0FBUztFQUNULFlBQVk7Q0FDZDtDQUNBO0VBQ0UsSUFBSTtFQUNKLE9BQU87RUFDUCxVQUFVO0VBQ1YsS0FBSztFQUNMLE1BQU07RUFDTixhQUFhO0VBQ2IsY0FBYyxDQUFDLGtDQUFrQyxxQkFBcUI7RUFDdEUsWUFBWTtDQUNkOzs7Q0FHQTtFQUNFLElBQUk7RUFDSixPQUFPO0VBQ1AsVUFBVTtFQUNWLEtBQUs7RUFDTCxNQUFNO0VBQ04sYUFBYTtFQUNiLGNBQWM7R0FBQztHQUFnQjtHQUFvQjtHQUErQjtFQUFZO0VBQzlGLFNBQVM7RUFDVCxZQUFZO0NBQ2Q7Q0FDQTtFQUNFLElBQUk7RUFDSixPQUFPO0VBQ1AsVUFBVTtFQUNWLEtBQUs7RUFDTCxNQUFNO0VBQ04sYUFBYTtFQUNiLGNBQWM7R0FBQztHQUEyQjtHQUFnQjtHQUF3QztFQUFzQjtFQUN4SCxTQUFTO0VBQ1QsWUFBWTtDQUNkO0NBQ0E7RUFDRSxJQUFJO0VBQ0osT0FBTztFQUNQLFVBQVU7RUFDVixLQUFLO0VBQ0wsTUFBTTtFQUNOLGFBQWE7RUFDYixjQUFjO0dBQUM7R0FBc0M7R0FBc0I7R0FBc0M7RUFBZTtFQUNoSSxTQUFTO0VBQ1QsWUFBWTtDQUNkO0NBQ0E7RUFDRSxJQUFJO0VBQ0osT0FBTztFQUNQLFVBQVU7RUFDVixLQUFLO0VBQ0wsTUFBTTtFQUNOLGFBQWE7RUFDYixjQUFjO0dBQUM7R0FBZ0I7R0FBaUI7R0FBZ0I7R0FBZTtFQUE0QztFQUMzSCxTQUFTO0VBQ1QsWUFBWTtDQUNkO0NBQ0E7RUFDRSxJQUFJO0VBQ0osT0FBTztFQUNQLFVBQVU7RUFDVixLQUFLO0VBQ0wsTUFBTTtFQUNOLGFBQWE7RUFDYixjQUFjO0dBQUM7R0FBZ0I7R0FBc0Q7RUFBYztFQUNuRyxZQUFZO0NBQ2Q7Q0FDQTtFQUNFLElBQUk7RUFDSixPQUFPO0VBQ1AsVUFBVTtFQUNWLEtBQUs7RUFDTCxNQUFNO0VBQ04sYUFBYTtFQUNiLGNBQWM7R0FBQztHQUFxQztHQUFnQjtFQUFlO0VBQ25GLFlBQVk7Q0FDZDtDQUNBO0VBQ0UsSUFBSTtFQUNKLE9BQU87RUFDUCxVQUFVO0VBQ1YsS0FBSztFQUNMLE1BQU07RUFDTixhQUFhO0VBQ2IsY0FBYztHQUFDO0dBQWdCO0dBQXVCO0VBQWU7RUFDckUsWUFBWTtDQUNkO0NBQ0E7RUFDRSxJQUFJO0VBQ0osT0FBTztFQUNQLFVBQVU7RUFDVixLQUFLO0VBQ0wsTUFBTTtFQUNOLGFBQWE7RUFDYixjQUFjO0dBQUM7R0FBc0I7R0FBMEI7R0FBMkI7RUFBNEI7RUFDdEgsWUFBWTtDQUNkO0NBQ0E7RUFDRSxJQUFJO0VBQ0osT0FBTztFQUNQLFVBQVU7RUFDVixLQUFLO0VBQ0wsTUFBTTtFQUNOLGFBQWE7RUFDYixjQUFjO0dBQUM7R0FBbUI7R0FBd0M7RUFBd0I7RUFDbEcsWUFBWTtDQUNkO0NBQ0E7RUFDRSxJQUFJO0VBQ0osT0FBTztFQUNQLFVBQVU7RUFDVixLQUFLO0VBQ0wsTUFBTTtFQUNOLGFBQWE7RUFDYixjQUFjO0dBQUM7R0FBYztHQUFpQjtHQUFtQztFQUEyQjtFQUM1RyxTQUFTO0VBQ1QsWUFBWTtDQUNkOzs7Q0FHQTtFQUNFLElBQUk7RUFDSixPQUFPO0VBQ1AsVUFBVTtFQUNWLEtBQUs7RUFDTCxNQUFNO0VBQ04sYUFBYTtFQUNiLGNBQWM7R0FBQztHQUFnQjtHQUE0QztHQUFrQjtFQUFXO0VBQ3hHLFNBQVM7RUFDVCxZQUFZO0NBQ2Q7Q0FDQTtFQUNFLElBQUk7RUFDSixPQUFPO0VBQ1AsVUFBVTtFQUNWLEtBQUs7RUFDTCxNQUFNO0VBQ04sYUFBYTtFQUNiLGNBQWM7R0FBQztHQUErQjtHQUFrQztHQUFrQjtFQUFlO0VBQ2pILFlBQVk7Q0FDZDtDQUNBO0VBQ0UsSUFBSTtFQUNKLE9BQU87RUFDUCxVQUFVO0VBQ1YsS0FBSztFQUNMLE1BQU07RUFDTixhQUFhO0VBQ2IsY0FBYyxDQUFDLGdCQUFnQixZQUFZO0VBQzNDLFlBQVk7Q0FDZDs7O0NBR0E7RUFDRSxJQUFJO0VBQ0osT0FBTztFQUNQLFVBQVU7RUFDVixLQUFLO0VBQ0wsTUFBTTtFQUNOLGFBQWE7RUFDYixjQUFjO0dBQUM7R0FBcUM7R0FBWTtHQUF3QjtFQUE0QjtFQUNwSCxTQUFTO0VBQ1QsWUFBWTtDQUNkO0NBQ0E7RUFDRSxJQUFJO0VBQ0osT0FBTztFQUNQLFVBQVU7RUFDVixLQUFLO0VBQ0wsTUFBTTtFQUNOLGFBQWE7RUFDYixjQUFjO0dBQUM7R0FBZ0I7R0FBWTtHQUFzQztFQUFrQztFQUNuSCxTQUFTO0VBQ1QsWUFBWTtDQUNkO0NBQ0E7RUFDRSxJQUFJO0VBQ0osT0FBTztFQUNQLFVBQVU7RUFDVixLQUFLO0VBQ0wsTUFBTTtFQUNOLGFBQWE7RUFDYixjQUFjO0dBQUM7R0FBVTtHQUFZO0VBQXlCO0VBQzlELFlBQVk7Q0FDZDs7O0NBR0E7RUFDRSxJQUFJO0VBQ0osT0FBTztFQUNQLFVBQVU7RUFDVixLQUFLO0VBQ0wsTUFBTTtFQUNOLGFBQWE7RUFDYixjQUFjO0dBQUM7R0FBdUI7R0FBaUI7RUFBa0I7RUFDekUsWUFBWTtDQUNkO0NBQ0E7RUFDRSxJQUFJO0VBQ0osT0FBTztFQUNQLFVBQVU7RUFDVixLQUFLO0VBQ0wsTUFBTTtFQUNOLGFBQWE7RUFDYixjQUFjO0dBQUM7R0FBa0I7R0FBWTtFQUFLO0VBQ2xELFlBQVk7Q0FDZDtDQUNBO0VBQ0UsSUFBSTtFQUNKLE9BQU87RUFDUCxVQUFVO0VBQ1YsS0FBSztFQUNMLE1BQU07RUFDTixhQUFhO0VBQ2IsY0FBYyxDQUFDLGdCQUFnQixVQUFVO0VBQ3pDLFlBQVk7Q0FDZDtBQUNGO0FBRUEsT0FBTyxNQUFNLHFCQUFxQjtDQUNoQztFQUFFLElBQUk7RUFBTyxPQUFPO0VBQWdCLE1BQU07Q0FBSTtDQUM5QztFQUFFLElBQUk7RUFBYyxPQUFPO0VBQWUsTUFBTTtDQUFLO0NBQ3JEO0VBQUUsSUFBSTtFQUFnQixPQUFPO0VBQXVCLE1BQU07Q0FBTTtDQUNoRTtFQUFFLElBQUk7RUFBa0IsT0FBTztFQUFtQixNQUFNO0NBQUs7Q0FDN0Q7RUFBRSxJQUFJO0VBQWEsT0FBTztFQUFrQixNQUFNO0NBQUs7Q0FDdkQ7RUFBRSxJQUFJO0VBQVcsT0FBTztFQUFrQixNQUFNO0NBQUs7Q0FDckQ7RUFBRSxJQUFJO0VBQVcsT0FBTztFQUFrQixNQUFNO0NBQUs7Q0FDckQ7RUFBRSxJQUFJO0VBQVcsT0FBTztFQUFtQixNQUFNO0NBQUs7QUFDeEQ7QUFFQSxPQUFPLE1BQU0sdUJBQXVCO0NBQ2xDO0VBQUUsTUFBTTtFQUEyQyxVQUFVO0VBQVcsU0FBUztFQUFHLFlBQVk7Q0FBRTtDQUNsRztFQUFFLE1BQU07RUFBd0MsVUFBVTtFQUFnQixTQUFTO0VBQUcsWUFBWTtDQUFFO0NBQ3BHO0VBQUUsTUFBTTtFQUFrQyxVQUFVO0VBQWUsU0FBUztFQUFHLFlBQVk7Q0FBRTtDQUM3RjtFQUFFLE1BQU07RUFBa0MsVUFBVTtFQUFlLFNBQVM7RUFBRyxZQUFZO0NBQUU7Q0FDN0Y7RUFBRSxNQUFNO0VBQXdDLFVBQVU7RUFBZ0IsU0FBUztFQUFHLFlBQVk7Q0FBRTtDQUNwRztFQUFFLE1BQU07RUFBdUMsVUFBVTtFQUFnQixTQUFTO0VBQUcsWUFBWTtDQUFFO0NBQ25HO0VBQUUsTUFBTTtFQUFnQyxVQUFVO0VBQWdCLFNBQVM7RUFBRyxZQUFZO0NBQUU7Q0FDNUY7RUFBRSxNQUFNO0VBQTZCLFVBQVU7RUFBZ0IsU0FBUztFQUFHLFlBQVk7Q0FBRTtDQUN6RjtFQUFFLE1BQU07RUFBb0MsVUFBVTtFQUFrQixTQUFTO0VBQUcsWUFBWTtDQUFFO0NBQ2xHO0VBQUUsTUFBTTtFQUEyQyxVQUFVO0VBQWdCLFNBQVM7RUFBRyxZQUFZO0NBQUU7Q0FDdkc7RUFBRSxNQUFNO0VBQW1DLFVBQVU7RUFBa0IsU0FBUztFQUFHLFlBQVk7Q0FBRTtDQUNqRztFQUFFLE1BQU07RUFBbUMsVUFBVTtFQUFZLFNBQVM7RUFBRyxZQUFZO0NBQUU7Q0FDM0Y7RUFBRSxNQUFNO0VBQXlDLFVBQVU7RUFBbUIsU0FBUztFQUFHLFlBQVk7Q0FBRTtDQUN4RztFQUFFLE1BQU07RUFBOEMsVUFBVTtFQUFXLFNBQVM7RUFBRyxZQUFZO0NBQUU7Q0FDckc7RUFBRSxNQUFNO0VBQTJDLFVBQVU7RUFBaUIsU0FBUztFQUFHLFlBQVk7Q0FBRTtDQUN4RztFQUFFLE1BQU07RUFBd0MsVUFBVTtFQUFpQixTQUFTO0VBQUcsWUFBWTtDQUFFO0NBQ3JHO0VBQUUsTUFBTTtFQUF1QyxVQUFVO0VBQVksU0FBUztFQUFHLFlBQVk7Q0FBRTtDQUMvRjtFQUFFLE1BQU07RUFBaUMsVUFBVTtFQUFXLFNBQVM7RUFBRyxZQUFZO0NBQUU7Q0FDeEY7RUFBRSxNQUFNO0VBQXNDLFVBQVU7RUFBUSxTQUFTO0VBQUcsWUFBWTtDQUFFO0NBQzFGO0VBQUUsTUFBTTtFQUFxQyxVQUFVO0VBQVksU0FBUztFQUFHLFlBQVk7Q0FBRTtDQUM3RjtFQUFFLE1BQU07RUFBdUMsVUFBVTtFQUFZLFNBQVM7RUFBRyxZQUFZO0NBQUU7QUFDakciLCJuYW1lcyI6W10sInNvdXJjZXMiOlsicG9ydGFsRGF0YS50cyJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBQb3J0YWxJdGVtIH0gZnJvbSAnLi4vdHlwZXMnO1xuXG5leHBvcnQgY29uc3QgQUxMX0dPVl9QT1JUQUxTOiBQb3J0YWxJdGVtW10gPSBbXG4gIC8vIENpdGl6ZW4gSURzXG4gIHtcbiAgICBpZDogJ3VpZGFpJyxcbiAgICB0aXRsZTogJ0FhZGhhYXIgQ2FyZCAobXlBYWRoYWFyKScsXG4gICAgY2F0ZWdvcnk6ICdjaXRpemVuX2lkJyxcbiAgICB1cmw6ICdodHRwczovL215YWFkaGFhci51aWRhaS5nb3YuaW4vJyxcbiAgICBpY29uOiAn8J+qqicsXG4gICAgZGVzY3JpcHRpb246ICdEb3dubG9hZCBlLUFhZGhhYXIsIE9yZGVyIFBWQyBDYXJkLCBBZGRyZXNzIFVwZGF0ZSwgQ2hlY2sgU3RhdHVzICYgQmlvbWV0cmljIExvY2suJyxcbiAgICByZXF1aXJlZERvY3M6IFsnQWFkaGFhciBOdW1iZXIgLyBFbnJvbGxtZW50IElEJywgJ1JlZ2lzdGVyZWQgTW9iaWxlIE51bWJlciAoT1RQKScsICdQcm9vZiBvZiBBZGRyZXNzIChmb3IgdXBkYXRlKSddLFxuICAgIHBvcHVsYXI6IHRydWUsXG4gICAgcG9ydGFsVHlwZTogJ2NlbnRyYWwnXG4gIH0sXG4gIHtcbiAgICBpZDogJ3Bhbl91dGknLFxuICAgIHRpdGxlOiAnUEFOIENhcmQgKFVUSUlUU0wgLyBOU0RMKScsXG4gICAgY2F0ZWdvcnk6ICdjaXRpemVuX2lkJyxcbiAgICB1cmw6ICdodHRwczovL3d3dy5wYW4udXRpaXRzbC5jb20vJyxcbiAgICBpY29uOiAn8J+SsycsXG4gICAgZGVzY3JpcHRpb246ICdOZXcgUEFOIDQ5QSwgUEFOIENvcnJlY3Rpb24sIFJlcHJpbnQgZS1QQU4sIExpbmsgQWFkaGFhciAmIFRyYWNrIFN0YXR1cy4nLFxuICAgIHJlcXVpcmVkRG9jczogWydBYWRoYWFyIENhcmQnLCAnUGFzc3BvcnQgUGhvdG8gKDIpJywgJ1NpZ25hdHVyZScsICdPbGQgUEFOIGNvcHkgKGZvciBjb3JyZWN0aW9uKSddLFxuICAgIHBvcHVsYXI6IHRydWUsXG4gICAgcG9ydGFsVHlwZTogJ2NlbnRyYWwnXG4gIH0sXG4gIHtcbiAgICBpZDogJ3ZvdGVyX2VjaScsXG4gICAgdGl0bGU6ICdWb3RlciBJRCAoRUNJIFBvcnRhbCknLFxuICAgIGNhdGVnb3J5OiAnY2l0aXplbl9pZCcsXG4gICAgdXJsOiAnaHR0cHM6Ly92b3RlcnMuZWNpLmdvdi5pbi8nLFxuICAgIGljb246ICfwn5ez77iPJyxcbiAgICBkZXNjcmlwdGlvbjogJ05ldyBWb3RlciBSZWdpc3RyYXRpb24gKEZvcm0gNiksIENvcnJlY3Rpb24gKEZvcm0gOCksIFNoaWZ0IFJlc2lkZW5jZSAmIERvd25sb2FkIGUtRVBJQy4nLFxuICAgIHJlcXVpcmVkRG9jczogWydBYWRoYWFyIENhcmQgLyBBZ2UgUHJvb2YnLCAnQWRkcmVzcyBQcm9vZiAoRWxlY3RyaWNpdHkgQmlsbCAvIFJhdGlvbiBDYXJkKScsICdQYXNzcG9ydCBQaG90byddLFxuICAgIHBvcHVsYXI6IHRydWUsXG4gICAgcG9ydGFsVHlwZTogJ2NlbnRyYWwnXG4gIH0sXG4gIHtcbiAgICBpZDogJ2F5dXNobWFuX3BtamF5JyxcbiAgICB0aXRsZTogJ0F5dXNobWFuIEJoYXJhdCAoUE0tSkFZKScsXG4gICAgY2F0ZWdvcnk6ICdjaXRpemVuX2lkJyxcbiAgICB1cmw6ICdodHRwczovL2JlbmVmaWNpYXJ5Lm5oYS5nb3YuaW4vJyxcbiAgICBpY29uOiAn8J+PpScsXG4gICAgZGVzY3JpcHRpb246ICdBeXVzaG1hbiBHb2xkZW4gQ2FyZCBnZW5lcmF0aW9uICjigrk1IExha2ggRnJlZSBUcmVhdG1lbnQpLCBlS1lDICYgQmVuZWZpY2lhcnkgc2VhcmNoLicsXG4gICAgcmVxdWlyZWREb2NzOiBbJ1JhdGlvbiBDYXJkIChZZWxsb3cvT3JhbmdlKScsICdBYWRoYWFyIENhcmQgb2YgYWxsIG1lbWJlcnMnLCAnTW9iaWxlIHdpdGggT1RQJ10sXG4gICAgcG9wdWxhcjogdHJ1ZSxcbiAgICBwb3J0YWxUeXBlOiAnY2VudHJhbCdcbiAgfSxcbiAge1xuICAgIGlkOiAnYWJoYV9oZWFsdGgnLFxuICAgIHRpdGxlOiAnQUJIQSBIZWFsdGggQ2FyZCAoQUJETSknLFxuICAgIGNhdGVnb3J5OiAnY2l0aXplbl9pZCcsXG4gICAgdXJsOiAnaHR0cHM6Ly9hYmhhLmFiZG0uZ292LmluLycsXG4gICAgaWNvbjogJ/CfqbonLFxuICAgIGRlc2NyaXB0aW9uOiAnQXl1c2htYW4gQmhhcmF0IEhlYWx0aCBBY2NvdW50IDE0LWRpZ2l0IGRpZ2l0YWwgY2FyZCBjcmVhdGlvbiAmIGhlYWx0aCByZWNvcmRzIGxpbmtpbmcuJyxcbiAgICByZXF1aXJlZERvY3M6IFsnQWFkaGFhciBDYXJkJywgJ0FhZGhhYXIgbGlua2VkIE1vYmlsZSBPVFAnXSxcbiAgICBwb3B1bGFyOiB0cnVlLFxuICAgIHBvcnRhbFR5cGU6ICdjZW50cmFsJ1xuICB9LFxuICB7XG4gICAgaWQ6ICdlc2hyYW1fcG9ydGFsJyxcbiAgICB0aXRsZTogJ2UtU2hyYW0gQ2FyZCcsXG4gICAgY2F0ZWdvcnk6ICdjaXRpemVuX2lkJyxcbiAgICB1cmw6ICdodHRwczovL2VzaHJhbS5nb3YuaW4vJyxcbiAgICBpY29uOiAn8J+RtycsXG4gICAgZGVzY3JpcHRpb246ICdOYXRpb25hbCBEYXRhYmFzZSBmb3IgVW5vcmdhbml6ZWQgV29ya2VycywgYWNjaWRlbnRhbCBpbnN1cmFuY2UgJiBmaW5hbmNpYWwgYXNzaXN0YW5jZS4nLFxuICAgIHJlcXVpcmVkRG9jczogWydBYWRoYWFyIENhcmQnLCAnQmFuayBQYXNzYm9vayAvIEFjY291bnQgZGV0YWlscycsICdBY3RpdmUgTW9iaWxlIE51bWJlciddLFxuICAgIHBvcHVsYXI6IHRydWUsXG4gICAgcG9ydGFsVHlwZTogJ2NlbnRyYWwnXG4gIH0sXG5cbiAgLy8gU3RhdGUgU2NoZW1lcyAoTWFoYXJhc2h0cmEgJiBSZWdpb25hbClcbiAge1xuICAgIGlkOiAnbGFka2lfYmFoaW4nLFxuICAgIHRpdGxlOiAnTWFqaGkgTGFka2kgQmFoaW4gWW9qYW5hJyxcbiAgICBjYXRlZ29yeTogJ3N0YXRlX3NjaGVtZScsXG4gICAgdXJsOiAnaHR0cHM6Ly9sYWRha2liYWhpbi5tYWhhcmFzaHRyYS5nb3YuaW4vJyxcbiAgICBpY29uOiAn8J+RqScsXG4gICAgZGVzY3JpcHRpb246ICdNYWhhcmFzaHRyYSBHb3Z0IHNjaGVtZTog4oK5MSw1MDAvbW9udGggZmluYW5jaWFsIGFpZCBmb3IgZWxpZ2libGUgd29tZW4gYWdlZCAyMS02NS4nLFxuICAgIHJlcXVpcmVkRG9jczogWydBYWRoYWFyIENhcmQnLCAnTWFoYXJhc2h0cmEgRG9taWNpbGUgLyBSYXRpb24gQ2FyZCAvIEJpcnRoIENlcnQnLCAnSW5jb21lIENlcnRpZmljYXRlICg8Mi41TCkgb3IgWWVsbG93L09yYW5nZSBSYXRpb24gQ2FyZCcsICdBYWRoYWFyIFNlZWRlZCBCYW5rIEFjY291bnQnLCAnQXBwbGljYW50IFBob3RvJ10sXG4gICAgcG9wdWxhcjogdHJ1ZSxcbiAgICBwb3J0YWxUeXBlOiAnc3RhdGUnXG4gIH0sXG4gIHtcbiAgICBpZDogJ2xhZGtpX2JhaGluX3djZCcsXG4gICAgdGl0bGU6ICdMYWRraSBCYWhpbiDigJMgV0NEIERlcHQnLFxuICAgIGNhdGVnb3J5OiAnc3RhdGVfc2NoZW1lJyxcbiAgICB1cmw6ICdodHRwczovL3dvbWVuY2hpbGQubWFoYXJhc2h0cmEuZ292LmluLycsXG4gICAgaWNvbjogJ/Cfk4snLFxuICAgIGRlc2NyaXB0aW9uOiAnV29tZW4gJiBDaGlsZCBEZXZlbG9wbWVudCBkZXBhcnRtZW50IG5vdGljZXMsIGd1aWRlbGluZXMsIGFuZCBvZmZpY2lhbCBHUnMuJyxcbiAgICByZXF1aXJlZERvY3M6IFsnQWFkaGFhciBDYXJkJywgJ0JhbmsgUGFzc2Jvb2snLCAnUmF0aW9uIENhcmQnXSxcbiAgICBwb3J0YWxUeXBlOiAnc3RhdGUnXG4gIH0sXG4gIHtcbiAgICBpZDogJ2FhcGxlX3NhcmthcicsXG4gICAgdGl0bGU6ICdBYXBsZSBTYXJrYXIgTWFoYXJhc2h0cmEnLFxuICAgIGNhdGVnb3J5OiAnc3RhdGVfc2NoZW1lJyxcbiAgICB1cmw6ICdodHRwczovL2FhcGxlc2Fya2FyLm1haGFvbmxpbmUuZ292LmluLycsXG4gICAgaWNvbjogJ/Cfj5vvuI8nLFxuICAgIGRlc2NyaXB0aW9uOiAnT25saW5lIFJldmVudWUgU2VydmljZXM6IEluY29tZSBDZXJ0aWZpY2F0ZSwgQ2FzdGUgQ2VydGlmaWNhdGUsIERvbWljaWxlLCBOb24tQ3JlYW15IExheWVyLCA3LzEyICYgOEEuJyxcbiAgICByZXF1aXJlZERvY3M6IFsnQWFkaGFhciBDYXJkJywgJ1JhdGlvbiBDYXJkJywgJ1NlbGYtRGVjbGFyYXRpb24gRm9ybScsICdTY2hvb2wgTGVhdmluZyBDZXJ0aWZpY2F0ZScsICdJbmNvbWUgUHJvb2YgLyBUYWxhdGhpIHJlcG9ydCddLFxuICAgIHBvcHVsYXI6IHRydWUsXG4gICAgcG9ydGFsVHlwZTogJ3N0YXRlJ1xuICB9LFxuICB7XG4gICAgaWQ6ICdtYWhhZGJ0JyxcbiAgICB0aXRsZTogJ01haGFEQlQgU2Nob2xhcnNoaXAgUG9ydGFsJyxcbiAgICBjYXRlZ29yeTogJ3N0YXRlX3NjaGVtZScsXG4gICAgdXJsOiAnaHR0cHM6Ly9tYWhhZGJ0Lm1haGFyYXNodHJhLmdvdi5pbi8nLFxuICAgIGljb246ICfwn46TJyxcbiAgICBkZXNjcmlwdGlvbjogJ1Bvc3QtTWF0cmljIFNjaG9sYXJzaGlwcywgRUJDIGZlZSByZWltYnVyc2VtZW50LCBEci4gUHVuamFicmFvIERlc2htdWtoIGhvc3RlbCBzY2hlbWUuJyxcbiAgICByZXF1aXJlZERvY3M6IFsnQWFkaGFhciBDYXJkJywgJ0Nhc3RlIENlcnRpZmljYXRlICYgVmFsaWRpdHknLCAnSW5jb21lIENlcnRpZmljYXRlJywgJ0NvbGxlZ2UgQWxsb3RtZW50IC8gRmVlIFJlY2VpcHQnLCAnTWFyayBzaGVldHMnXSxcbiAgICBwb3B1bGFyOiB0cnVlLFxuICAgIHBvcnRhbFR5cGU6ICdzdGF0ZSdcbiAgfSxcbiAge1xuICAgIGlkOiAnbWFoYWJodWxla2gnLFxuICAgIHRpdGxlOiAnTWFoYWJodWxla2ggKDcvMTIgT25saW5lKScsXG4gICAgY2F0ZWdvcnk6ICdyZXZlbnVlJyxcbiAgICB1cmw6ICdodHRwczovL2JodWxla2gubWFoYWJodW1pLmdvdi5pbi8nLFxuICAgIGljb246ICfwn4y+JyxcbiAgICBkZXNjcmlwdGlvbjogJ01haGFyYXNodHJhIERpZ2l0YWwgU2F0YmFyYSAoNy8xMiBleHRyYWN0KSwgOEEgcHJvcGVydHkgY2FyZCAmIGRpZ2l0YWwgbGFuZCByZWNvcmRzLicsXG4gICAgcmVxdWlyZWREb2NzOiBbJ0Rpc3RyaWN0LCBUYWx1a2EsIFZpbGxhZ2UgTmFtZScsICdTdXJ2ZXkgLyBHYXQgTnVtYmVyJ10sXG4gICAgcG9ydGFsVHlwZTogJ3N0YXRlJ1xuICB9LFxuXG4gIC8vIENlbnRyYWwgU2NoZW1lc1xuICB7XG4gICAgaWQ6ICdwbV9raXNhbicsXG4gICAgdGl0bGU6ICdQTS1LSVNBTiBTYW1tYW4gTmlkaGknLFxuICAgIGNhdGVnb3J5OiAnY2VudHJhbF9zY2hlbWUnLFxuICAgIHVybDogJ2h0dHBzOi8vcG1raXNhbi5nb3YuaW4vJyxcbiAgICBpY29uOiAn8J+MvicsXG4gICAgZGVzY3JpcHRpb246ICfigrk2LDAwMC95ZWFyIGZhcm1lciBiZW5lZml0IGluIDMgaW5zdGFsbWVudHMsIG9ubGluZSBiaW9tZXRyaWMvZmFjZSBlS1lDLCBiZW5lZmljaWFyeSBzdGF0dXMuJyxcbiAgICByZXF1aXJlZERvY3M6IFsnQWFkaGFhciBDYXJkJywgJzcvMTIgTGFuZCBSZWNvcmQnLCAnQWFkaGFhciBTZWVkZWQgQmFuayBBY2NvdW50JywgJ01vYmlsZSBPVFAnXSxcbiAgICBwb3B1bGFyOiB0cnVlLFxuICAgIHBvcnRhbFR5cGU6ICdjZW50cmFsJ1xuICB9LFxuICB7XG4gICAgaWQ6ICdwbV9zdXJ5YV9naGFyJyxcbiAgICB0aXRsZTogJ1BNIFN1cnlhIEdoYXIgKE11ZnQgQmlqbGkpJyxcbiAgICBjYXRlZ29yeTogJ2NlbnRyYWxfc2NoZW1lJyxcbiAgICB1cmw6ICdodHRwczovL3Btc3VyeWFnaGFyLmdvdi5pbi8nLFxuICAgIGljb246ICfimIDvuI8nLFxuICAgIGRlc2NyaXB0aW9uOiAnUm9vZnRvcCBTb2xhciBTdWJzaWR5IHVwIHRvIOKCuTc4LDAwMCBmb3IgdXAgdG8gMzAwIHVuaXRzIGZyZWUgZWxlY3RyaWNpdHkgZXZlcnkgbW9udGguJyxcbiAgICByZXF1aXJlZERvY3M6IFsnTGF0ZXN0IEVsZWN0cmljaXR5IEJpbGwnLCAnQWFkaGFhciBDYXJkJywgJ1Jvb2YgUGhvdG8gLyBFbGVjdHJpY2l0eSBDb25zdW1lciBObycsICdCYW5rIEFjY291bnQgRGV0YWlscyddLFxuICAgIHBvcHVsYXI6IHRydWUsXG4gICAgcG9ydGFsVHlwZTogJ2NlbnRyYWwnXG4gIH0sXG4gIHtcbiAgICBpZDogJ3BtX2F3YXMnLFxuICAgIHRpdGxlOiAnUE0gQXdhcyBZb2phbmEgKFBNQVktRy9VKScsXG4gICAgY2F0ZWdvcnk6ICdjZW50cmFsX3NjaGVtZScsXG4gICAgdXJsOiAnaHR0cHM6Ly9wbWF5bWlzLmdvdi5pbi8nLFxuICAgIGljb246ICfwn4+gJyxcbiAgICBkZXNjcmlwdGlvbjogJ0hvdXNpbmcgZm9yIEFsbCBzdWJzaWR5IHNjaGVtZSBmb3IgdXJiYW4gYW5kIHJ1cmFsIGZhbWlsaWVzIHRvIGJ1aWxkIHB1Y2NhIGhvdXNlcy4nLFxuICAgIHJlcXVpcmVkRG9jczogWydBYWRoYWFyIENhcmQgb2YgYWxsIGZhbWlseSBtZW1iZXJzJywgJ0luY29tZSBDZXJ0aWZpY2F0ZScsICdMYW5kIC8gUHJvcGVydHkgT3duZXJzaGlwIERvY3VtZW50JywgJ0JhbmsgUGFzc2Jvb2snXSxcbiAgICBwb3B1bGFyOiB0cnVlLFxuICAgIHBvcnRhbFR5cGU6ICdjZW50cmFsJ1xuICB9LFxuICB7XG4gICAgaWQ6ICdwbV92aXNod2FrYXJtYScsXG4gICAgdGl0bGU6ICdQTSBWaXNod2FrYXJtYSBZb2phbmEnLFxuICAgIGNhdGVnb3J5OiAnY2VudHJhbF9zY2hlbWUnLFxuICAgIHVybDogJ2h0dHBzOi8vcG12aXNod2FrYXJtYS5nb3YuaW4vJyxcbiAgICBpY29uOiAn8J+boO+4jycsXG4gICAgZGVzY3JpcHRpb246ICfigrkzIExha2ggY29sbGF0ZXJhbC1mcmVlIGxvYW4sIHRvb2wga2l0IGluY2VudGl2ZSDigrkxNSwwMDAgJiBza2lsbCB0cmFpbmluZyBmb3IgMTggdHJhZGl0aW9uYWwgdHJhZGVzLicsXG4gICAgcmVxdWlyZWREb2NzOiBbJ0FhZGhhYXIgQ2FyZCcsICdNb2JpbGUgTnVtYmVyJywgJ0JhbmsgRGV0YWlscycsICdSYXRpb24gQ2FyZCcsICdUcmFkZSBTa2lsbCBDZXJ0aWZpY2F0ZSAvIFNlbGYgRGVjbGFyYXRpb24nXSxcbiAgICBwb3B1bGFyOiB0cnVlLFxuICAgIHBvcnRhbFR5cGU6ICdjZW50cmFsJ1xuICB9LFxuICB7XG4gICAgaWQ6ICdwbV9zdmFuaWRoaScsXG4gICAgdGl0bGU6ICdQTSBTVkFOaWRoaSAoU3RyZWV0IFZlbmRvcnMpJyxcbiAgICBjYXRlZ29yeTogJ2NlbnRyYWxfc2NoZW1lJyxcbiAgICB1cmw6ICdodHRwczovL3Btc3ZhbmlkaGkubW9odWEuZ292LmluLycsXG4gICAgaWNvbjogJ/Cfm7onLFxuICAgIGRlc2NyaXB0aW9uOiAnV29ya2luZyBjYXBpdGFsIG1pY3JvLWNyZWRpdCBsb2FuICjigrkxMCwwMDAgdG8g4oK5NTAsMDAwKSB3aXRoIDclIGludGVyZXN0IHN1YnNpZHkgZm9yIHN0cmVldCB2ZW5kb3JzLicsXG4gICAgcmVxdWlyZWREb2NzOiBbJ0FhZGhhYXIgQ2FyZCcsICdWZW5kaW5nIENlcnRpZmljYXRlIC8gVXJiYW4gTG9jYWwgQm9keSBTdXJ2ZXkgQ2FyZCcsICdCYW5rIEFjY291bnQnXSxcbiAgICBwb3J0YWxUeXBlOiAnY2VudHJhbCdcbiAgfSxcbiAge1xuICAgIGlkOiAncG1fZmFzYWxfYmltYScsXG4gICAgdGl0bGU6ICdQTSBGYXNhbCBCaW1hIFlvamFuYSAoUE1GQlkpJyxcbiAgICBjYXRlZ29yeTogJ2NlbnRyYWxfc2NoZW1lJyxcbiAgICB1cmw6ICdodHRwczovL3BtZmJ5Lmdvdi5pbi8nLFxuICAgIGljb246ICfwn4yxJyxcbiAgICBkZXNjcmlwdGlvbjogJ0Nyb3AgaW5zdXJhbmNlIHByb3RlY3Rpb24gYWdhaW5zdCBuYXR1cmFsIGNhbGFtaXRpZXMsIHBlc3RzLCBhbmQgdW5zZWFzb25hbCByYWluZmFsbC4nLFxuICAgIHJlcXVpcmVkRG9jczogWyc3LzEyIGV4dHJhY3QgJiBTb3dpbmcgQ2VydGlmaWNhdGUnLCAnQWFkaGFhciBDYXJkJywgJ0JhbmsgUGFzc2Jvb2snXSxcbiAgICBwb3J0YWxUeXBlOiAnY2VudHJhbCdcbiAgfSxcbiAge1xuICAgIGlkOiAncG1famFuZGhhbicsXG4gICAgdGl0bGU6ICdQTSBKYW4tRGhhbiBZb2phbmEgKFBNSkRZKScsXG4gICAgY2F0ZWdvcnk6ICdjZW50cmFsX3NjaGVtZScsXG4gICAgdXJsOiAnaHR0cHM6Ly9wbWpkeS5nb3YuaW4vJyxcbiAgICBpY29uOiAn8J+PpicsXG4gICAgZGVzY3JpcHRpb246ICdaZXJvIGJhbGFuY2Ugc2F2aW5ncyBhY2NvdW50IHdpdGggUnVQYXkgZGViaXQgY2FyZCwg4oK5MiBMYWtoIGFjY2lkZW50YWwgaW5zdXJhbmNlICYgb3ZlcmRyYWZ0LicsXG4gICAgcmVxdWlyZWREb2NzOiBbJ0FhZGhhYXIgQ2FyZCcsICdQYXNzcG9ydCBzaXplIHBob3RvJywgJ01vYmlsZSBOdW1iZXInXSxcbiAgICBwb3J0YWxUeXBlOiAnY2VudHJhbCdcbiAgfSxcbiAge1xuICAgIGlkOiAncG1fbXVkcmEnLFxuICAgIHRpdGxlOiAnUE0gTXVkcmEgWW9qYW5hIChQTU1ZKScsXG4gICAgY2F0ZWdvcnk6ICdjZW50cmFsX3NjaGVtZScsXG4gICAgdXJsOiAnaHR0cHM6Ly93d3cubXVkcmEub3JnLmluLycsXG4gICAgaWNvbjogJ/CfkrMnLFxuICAgIGRlc2NyaXB0aW9uOiAnQnVzaW5lc3MgbWljcm8tbG9hbnMgdXAgdG8g4oK5MTAgTGFraCAoU2hpc2h1LCBLaXNob3JlLCBUYXJ1bikgZm9yIHNtYWxsIGVudGVycHJpc2VzLicsXG4gICAgcmVxdWlyZWREb2NzOiBbJ0FhZGhhYXIgJiBQQU4gQ2FyZCcsICdCdXNpbmVzcyBhZGRyZXNzIHByb29mJywgJzYgbW9udGhzIEJhbmsgU3RhdGVtZW50JywgJ1F1b3RhdGlvbiAvIFByb2plY3QgcmVwb3J0J10sXG4gICAgcG9ydGFsVHlwZTogJ2NlbnRyYWwnXG4gIH0sXG4gIHtcbiAgICBpZDogJ3BtX3VqandhbGEnLFxuICAgIHRpdGxlOiAnUE0gVWpqd2FsYSBZb2phbmEgMi4wJyxcbiAgICBjYXRlZ29yeTogJ2NlbnRyYWxfc2NoZW1lJyxcbiAgICB1cmw6ICdodHRwczovL3d3dy5wbXV5Lmdvdi5pbi8nLFxuICAgIGljb246ICfwn5SlJyxcbiAgICBkZXNjcmlwdGlvbjogJ0ZyZWUgTFBHIGdhcyBjb25uZWN0aW9uIHdpdGggZmlyc3QgY3lsaW5kZXIgYW5kIHN0b3ZlIHN1YnNpZHkgZm9yIHdvbWVuIGluIEJQTCBob3VzZWhvbGRzLicsXG4gICAgcmVxdWlyZWREb2NzOiBbJ0JQTCBSYXRpb24gQ2FyZCcsICdBYWRoYWFyIENhcmQgb2YgYWR1bHQgZmFtaWx5IG1lbWJlcnMnLCAnQmFuayBBY2NvdW50IHdpdGggSUZTQyddLFxuICAgIHBvcnRhbFR5cGU6ICdjZW50cmFsJ1xuICB9LFxuICB7XG4gICAgaWQ6ICdlcGZvX3VhbicsXG4gICAgdGl0bGU6ICdFUEZPIC8gVUFOIE1lbWJlciBQb3J0YWwnLFxuICAgIGNhdGVnb3J5OiAnY2VudHJhbF9zY2hlbWUnLFxuICAgIHVybDogJ2h0dHBzOi8vdW5pZmllZHBvcnRhbC1tZW0uZXBmaW5kaWEuZ292LmluL21lbWJlcmludGVyZmFjZS8nLFxuICAgIGljb246ICfwn4+iJyxcbiAgICBkZXNjcmlwdGlvbjogJ1Byb3ZpZGVudCBGdW5kIFBhc3Nib29rLCBQRiBBZHZhbmNlIFdpdGhkcmF3YWwgKEZvcm0gMzEvMTkvMTBDKSwgS1lDIFVwZGF0ZSAmIFRyYW5zZmVyLicsXG4gICAgcmVxdWlyZWREb2NzOiBbJ1VBTiBOdW1iZXInLCAnRVBGTyBQYXNzd29yZCcsICdBYWRoYWFyIExpbmtlZCBNb2JpbGUgKGZvciBPVFApJywgJ0JhbmsgQWNjb3VudCBWZXJpZmljYXRpb24nXSxcbiAgICBwb3B1bGFyOiB0cnVlLFxuICAgIHBvcnRhbFR5cGU6ICdjZW50cmFsJ1xuICB9LFxuXG4gIC8vIFRyYW5zcG9ydCAmIERyaXZpbmdcbiAge1xuICAgIGlkOiAncGFyaXZhaGFuX3NhcmF0aGknLFxuICAgIHRpdGxlOiAnUGFyaXZhaGFuIFNhcmF0aGkgKERyaXZpbmcgTGljZW5jZSknLFxuICAgIGNhdGVnb3J5OiAndHJhbnNwb3J0JyxcbiAgICB1cmw6ICdodHRwczovL3NhcmF0aGkucGFyaXZhaGFuLmdvdi5pbi8nLFxuICAgIGljb246ICfwn5qXJyxcbiAgICBkZXNjcmlwdGlvbjogXCJMZWFybmVyJ3MgTGljZW5jZSB0ZXN0LCBQZXJtYW5lbnQgRHJpdmluZyBMaWNlbmNlIHNsb3QgYm9va2luZywgREwgUmVuZXdhbCAmIEFkZHJlc3MgQ2hhbmdlLlwiLFxuICAgIHJlcXVpcmVkRG9jczogWydBYWRoYWFyIENhcmQnLCAnTWVkaWNhbCBDZXJ0aWZpY2F0ZSAoRm9ybSAxQSBpZiBhZ2UgPjQwKScsICdQYXNzcG9ydCBQaG90bycsICdTaWduYXR1cmUnXSxcbiAgICBwb3B1bGFyOiB0cnVlLFxuICAgIHBvcnRhbFR5cGU6ICdjZW50cmFsJ1xuICB9LFxuICB7XG4gICAgaWQ6ICdwYXJpdmFoYW5fdmFoYW4nLFxuICAgIHRpdGxlOiAnUGFyaXZhaGFuIFZhaGFuIChWZWhpY2xlIFJDKScsXG4gICAgY2F0ZWdvcnk6ICd0cmFuc3BvcnQnLFxuICAgIHVybDogJ2h0dHBzOi8vdmFoYW4ucGFyaXZhaGFuLmdvdi5pbi8nLFxuICAgIGljb246ICfwn4+N77iPJyxcbiAgICBkZXNjcmlwdGlvbjogJ1JDIFRyYW5zZmVyLCBEdXBsaWNhdGUgUkMsIEhpZ2ggU2VjdXJpdHkgTnVtYmVyIFBsYXRlIChIU1JQKSwgUG9sbHV0aW9uIFBVQyAmIFRheCBwYXltZW50LicsXG4gICAgcmVxdWlyZWREb2NzOiBbJ1ZlaGljbGUgUmVnaXN0cmF0aW9uIE51bWJlcicsICdDaGFzc2lzIE51bWJlciAobGFzdCA1IGRpZ2l0cyknLCAnSW5zdXJhbmNlIGNvcHknLCAnT3duZXIgQWFkaGFhciddLFxuICAgIHBvcnRhbFR5cGU6ICdjZW50cmFsJ1xuICB9LFxuICB7XG4gICAgaWQ6ICdtYWhhc2FyYXRoaScsXG4gICAgdGl0bGU6ICdNYWhhU2FyYXRoaSBUcmFuc3BvcnQgUG9ydGFsJyxcbiAgICBjYXRlZ29yeTogJ3RyYW5zcG9ydCcsXG4gICAgdXJsOiAnaHR0cHM6Ly9tYWhhc2FyYXRoaS5tYWhhcmFzaHRyYS5nb3YuaW4vJyxcbiAgICBpY29uOiAn8J+ajCcsXG4gICAgZGVzY3JpcHRpb246ICdNYWhhcmFzaHRyYSBzdGF0ZSBjaXRpemVuIHRyYW5zcG9ydCBoZWxwbGluZSwgb25saW5lIHBlcm1pdCBzZXJ2aWNlcyBhbmQgY2l0aXplbiBncmlldmFuY2UuJyxcbiAgICByZXF1aXJlZERvY3M6IFsnQWFkaGFhciBDYXJkJywgJ1ZlaGljbGUgUkMnXSxcbiAgICBwb3J0YWxUeXBlOiAnc3RhdGUnXG4gIH0sXG5cbiAgLy8gQnVzaW5lc3MgJiBNU01FXG4gIHtcbiAgICBpZDogJ3VkeWFtX21zbWUnLFxuICAgIHRpdGxlOiAnVWR5YW0gTVNNRSBSZWdpc3RyYXRpb24nLFxuICAgIGNhdGVnb3J5OiAndXRpbGl0eScsXG4gICAgdXJsOiAnaHR0cHM6Ly91ZHlhbXJlZ2lzdHJhdGlvbi5nb3YuaW4vJyxcbiAgICBpY29uOiAn8J+PrScsXG4gICAgZGVzY3JpcHRpb246ICdGcmVlIG9mZmljaWFsIENlbnRyYWwgTVNNRSBjZXJ0aWZpY2F0ZSBmb3Igc2hvcHMsIGN5YmVyIGNhZmVzLCB0cmFkZXJzLCBhbmQgc21hbGwgYnVzaW5lc3Nlcy4nLFxuICAgIHJlcXVpcmVkRG9jczogWydBYWRoYWFyIENhcmQgKGxpbmtlZCB3aXRoIG1vYmlsZSknLCAnUEFOIENhcmQnLCAnQmFuayBBY2NvdW50IGRldGFpbHMnLCAnQnVzaW5lc3MgTmFtZSAmIFN0YXJ0IERhdGUnXSxcbiAgICBwb3B1bGFyOiB0cnVlLFxuICAgIHBvcnRhbFR5cGU6ICdjZW50cmFsJ1xuICB9LFxuICB7XG4gICAgaWQ6ICdwYXNzcG9ydF9zZXZhJyxcbiAgICB0aXRsZTogJ1Bhc3Nwb3J0IFNldmEgS2VuZHJhIChQU0spJyxcbiAgICBjYXRlZ29yeTogJ3V0aWxpdHknLFxuICAgIHVybDogJ2h0dHBzOi8vd3d3LnBhc3Nwb3J0aW5kaWEuZ292LmluLycsXG4gICAgaWNvbjogJ+KciO+4jycsXG4gICAgZGVzY3JpcHRpb246ICdGcmVzaCBJbmRpYW4gUGFzc3BvcnQgYXBwbGljYXRpb24sIFRhdGthYWwgcGFzc3BvcnQsIFBvbGljZSBDbGVhcmFuY2UgQ2VydGlmaWNhdGUgKFBDQykuJyxcbiAgICByZXF1aXJlZERvY3M6IFsnQWFkaGFhciBDYXJkJywgJ1BBTiBDYXJkJywgJzEwdGggTWFya3NoZWV0IC8gQmlydGggQ2VydGlmaWNhdGUnLCAnQmFuayBQYXNzYm9vayAvIEVsZWN0cmljaXR5IEJpbGwnXSxcbiAgICBwb3B1bGFyOiB0cnVlLFxuICAgIHBvcnRhbFR5cGU6ICdjZW50cmFsJ1xuICB9LFxuICB7XG4gICAgaWQ6ICdjc2NfcG9ydGFsJyxcbiAgICB0aXRsZTogJ0RpZ2l0YWwgU2V2YSBDU0MgUG9ydGFsJyxcbiAgICBjYXRlZ29yeTogJ3V0aWxpdHknLFxuICAgIHVybDogJ2h0dHBzOi8vZGlnaXRhbHNldmEuY3NjLmdvdi5pbi8nLFxuICAgIGljb246ICfwn4yQJyxcbiAgICBkZXNjcmlwdGlvbjogJ0NvbW1vbiBTZXJ2aWNlIENlbnRyZSBWTEUgcG9ydGFsIGZvciBnb3Zlcm5tZW50IEcyQyBhbmQgQjJDIGNpdGl6ZW4gc2VydmljZXMuJyxcbiAgICByZXF1aXJlZERvY3M6IFsnQ1NDIElEJywgJ1Bhc3N3b3JkJywgJ0Jpb21ldHJpYyAvIElSSVMgRGV2aWNlJ10sXG4gICAgcG9ydGFsVHlwZTogJ2RpcmVjdCdcbiAgfSxcblxuICAvLyBCYW5raW5nICYgUmV0YWlsZXIgTWl0cmEgUG9ydGFsc1xuICB7XG4gICAgaWQ6ICdhaXJ0ZWxfbWl0cmEnLFxuICAgIHRpdGxlOiAnQWlydGVsIFBheW1lbnRzIEJhbmsgTWl0cmEnLFxuICAgIGNhdGVnb3J5OiAnYmFua2luZycsXG4gICAgdXJsOiAnaHR0cHM6Ly9wb3J0YWwuYWlydGVsYmFuay5jb20vJyxcbiAgICBpY29uOiAn8J+TsScsXG4gICAgZGVzY3JpcHRpb246ICdSZXRhaWxlciBwb3J0YWwgZm9yIEFlUFMgY2FzaCB3aXRoZHJhd2FsLCBtb25leSB0cmFuc2ZlciwgbWljcm8tQVRNICYgdXRpbGl0eSBiaWxsIHBheW1lbnQuJyxcbiAgICByZXF1aXJlZERvY3M6IFsnTWl0cmEgTW9iaWxlIE51bWJlcicsICdMQVBVIFBhc3N3b3JkJywgJ0Jpb21ldHJpYyBEZXZpY2UnXSxcbiAgICBwb3J0YWxUeXBlOiAnZGlyZWN0J1xuICB9LFxuICB7XG4gICAgaWQ6ICdzcGljZV9tb25leScsXG4gICAgdGl0bGU6ICdTcGljZSBNb25leSBSZXRhaWxlcicsXG4gICAgY2F0ZWdvcnk6ICdiYW5raW5nJyxcbiAgICB1cmw6ICdodHRwczovL2IyYi5zcGljZW1vbmV5LmNvbS8nLFxuICAgIGljb246ICfwn4y277iPJyxcbiAgICBkZXNjcmlwdGlvbjogJ0IyQiBwb3J0YWwgZm9yIEFhZGhhYXIgQVRNLCBETVQsIG1BVE0sIHJhaWx3YXkgSVJDVEMgYm9va2luZywgUEFOIGNhcmQgYW5kIGJpbGwgcGF5bWVudC4nLFxuICAgIHJlcXVpcmVkRG9jczogWydTcGljZSBNb25leSBJRCcsICdQYXNzd29yZCcsICdPVFAnXSxcbiAgICBwb3J0YWxUeXBlOiAnZGlyZWN0J1xuICB9LFxuICB7XG4gICAgaWQ6ICdwYXluZWFyYnknLFxuICAgIHRpdGxlOiAnUGF5TmVhcmJ5IFJldGFpbGVyJyxcbiAgICBjYXRlZ29yeTogJ2JhbmtpbmcnLFxuICAgIHVybDogJ2h0dHBzOi8vcG9ydGFsLnBheW5lYXJieS5pbi8nLFxuICAgIGljb246ICfwn5KwJyxcbiAgICBkZXNjcmlwdGlvbjogJ1JldGFpbGVyIHBsYXRmb3JtIGZvciBEaWdpdGFsIFByYWRoYW4sIGNhc2ggZGVwb3NpdCwgY3JlZGl0IGNhcmQgYmlsbCAmIGxvYW4gcmVwYXltZW50LicsXG4gICAgcmVxdWlyZWREb2NzOiBbJ1BheU5lYXJieSBJRCcsICdQYXNzd29yZCddLFxuICAgIHBvcnRhbFR5cGU6ICdkaXJlY3QnXG4gIH1cbl07XG5cbmV4cG9ydCBjb25zdCBTRVJWSUNFX0NBVEVHT1JJRVMgPSBbXG4gIHsgaWQ6ICdhbGwnLCBsYWJlbDogJ0FsbCBTZXJ2aWNlcycsIGljb246ICfilqYnIH0sXG4gIHsgaWQ6ICdjaXRpemVuX2lkJywgbGFiZWw6ICdDaXRpemVuIElEcycsIGljb246ICfwn6qqJyB9LFxuICB7IGlkOiAnc3RhdGVfc2NoZW1lJywgbGFiZWw6ICdNYWhhcmFzaHRyYSBTY2hlbWVzJywgaWNvbjogJ/Cfj5vvuI8nIH0sXG4gIHsgaWQ6ICdjZW50cmFsX3NjaGVtZScsIGxhYmVsOiAnQ2VudHJhbCBTY2hlbWVzJywgaWNvbjogJ/CfjL4nIH0sXG4gIHsgaWQ6ICd0cmFuc3BvcnQnLCBsYWJlbDogJ1RyYW5zcG9ydCAmIERMJywgaWNvbjogJ/CfmpcnIH0sXG4gIHsgaWQ6ICdiYW5raW5nJywgbGFiZWw6ICdCYW5raW5nICYgQWVQUycsIGljb246ICfwn4+mJyB9LFxuICB7IGlkOiAncmV2ZW51ZScsIGxhYmVsOiAnUmV2ZW51ZSAmIDcvMTInLCBpY29uOiAn8J+TnCcgfSxcbiAgeyBpZDogJ3V0aWxpdHknLCBsYWJlbDogJ01TTUUgJiBCdXNpbmVzcycsIGljb246ICfwn4+tJyB9LFxuXTtcblxuZXhwb3J0IGNvbnN0IENPTU1PTl9TSE9QX1NFUlZJQ0VTID0gW1xuICB7IG5hbWU6ICdDdXN0b20gQ2l0aXplbiBTZXJ2aWNlIChNYW51YWwgUHJpY2luZyknLCBjYXRlZ29yeTogJ0dlbmVyYWwnLCBnb3Z0RmVlOiAwLCBzZXJ2aWNlRmVlOiAwIH0sXG4gIHsgbmFtZTogJ1BWQyBBYWRoYWFyIC8gUEFOIC8gU21hcnQgQ2FyZCBQcmludCcsIGNhdGVnb3J5OiAnUFZDIFByaW50aW5nJywgZ292dEZlZTogMCwgc2VydmljZUZlZTogMCB9LFxuICB7IG5hbWU6ICdQYXNzcG9ydCBQaG90b3MgKDggQ29waWVzIDR4NiknLCBjYXRlZ29yeTogJ1Bob3RvZ3JhcGh5JywgZ292dEZlZTogMCwgc2VydmljZUZlZTogMCB9LFxuICB7IG5hbWU6ICdQYXNzcG9ydCBQaG90b3MgKDE2IENvcGllcyBBNCknLCBjYXRlZ29yeTogJ1Bob3RvZ3JhcGh5JywgZ292dEZlZTogMCwgc2VydmljZUZlZTogMCB9LFxuICB7IG5hbWU6ICdNYWpoaSBMYWRraSBCYWhpbiBZb2phbmEgQXBwbGljYXRpb24nLCBjYXRlZ29yeTogJ0dvdnQgU2NoZW1lcycsIGdvdnRGZWU6IDAsIHNlcnZpY2VGZWU6IDAgfSxcbiAgeyBuYW1lOiAnTmV3IFBBTiBDYXJkIEFwcGxpY2F0aW9uIChGb3JtIDQ5QSknLCBjYXRlZ29yeTogJ1BBTiBTZXJ2aWNlcycsIGdvdnRGZWU6IDAsIHNlcnZpY2VGZWU6IDAgfSxcbiAgeyBuYW1lOiAnUEFOIENhcmQgQ29ycmVjdGlvbiAvIFVwZGF0ZScsIGNhdGVnb3J5OiAnUEFOIFNlcnZpY2VzJywgZ292dEZlZTogMCwgc2VydmljZUZlZTogMCB9LFxuICB7IG5hbWU6ICdQQU4gLSBBYWRoYWFyIExpbmsgT25saW5lJywgY2F0ZWdvcnk6ICdQQU4gU2VydmljZXMnLCBnb3Z0RmVlOiAwLCBzZXJ2aWNlRmVlOiAwIH0sXG4gIHsgbmFtZTogJ1BNLUtJU0FOIGVLWUMgLyBOZXcgUmVnaXN0cmF0aW9uJywgY2F0ZWdvcnk6ICdGYXJtZXIgU2NoZW1lcycsIGdvdnRGZWU6IDAsIHNlcnZpY2VGZWU6IDAgfSxcbiAgeyBuYW1lOiAnUE0gU3VyeWEgR2hhciBSb29mdG9wIFNvbGFyIEFwcGxpY2F0aW9uJywgY2F0ZWdvcnk6ICdHb3Z0IFNjaGVtZXMnLCBnb3Z0RmVlOiAwLCBzZXJ2aWNlRmVlOiAwIH0sXG4gIHsgbmFtZTogJ0F5dXNobWFuIEJoYXJhdCBDYXJkIEdlbmVyYXRpb24nLCBjYXRlZ29yeTogJ0hlYWx0aCBTY2hlbWVzJywgZ292dEZlZTogMCwgc2VydmljZUZlZTogMCB9LFxuICB7IG5hbWU6ICdOZXcgVm90ZXIgSUQgRm9ybSA2IEFwcGxpY2F0aW9uJywgY2F0ZWdvcnk6ICdFbGVjdGlvbicsIGdvdnRGZWU6IDAsIHNlcnZpY2VGZWU6IDAgfSxcbiAgeyBuYW1lOiBcIkxlYXJuZXIncyBEcml2aW5nIExpY2VuY2UgU2xvdCAmIFRlc3RcIiwgY2F0ZWdvcnk6ICdSVE8gLyBUcmFuc3BvcnQnLCBnb3Z0RmVlOiAwLCBzZXJ2aWNlRmVlOiAwIH0sXG4gIHsgbmFtZTogJ0FhcGxlIFNhcmthciBJbmNvbWUgLyBEb21pY2lsZSBDZXJ0aWZpY2F0ZScsIGNhdGVnb3J5OiAnUmV2ZW51ZScsIGdvdnRGZWU6IDAsIHNlcnZpY2VGZWU6IDAgfSxcbiAgeyBuYW1lOiAnUHJvZmVzc2lvbmFsIENWIC8gUmVzdW1lIC8gQmlvRGF0YSAoQTQpJywgY2F0ZWdvcnk6ICdEb2N1bWVudGF0aW9uJywgZ292dEZlZTogMCwgc2VydmljZUZlZTogMCB9LFxuICB7IG5hbWU6ICdlLVNocmFtIENhcmQgUmVnaXN0cmF0aW9uIC8gRG93bmxvYWQnLCBjYXRlZ29yeTogJ0xhYm9yIFNjaGVtZXMnLCBnb3Z0RmVlOiAwLCBzZXJ2aWNlRmVlOiAwIH0sXG4gIHsgbmFtZTogJ1VkeWFtIE1TTUUgUmVnaXN0cmF0aW9uIENlcnRpZmljYXRlJywgY2F0ZWdvcnk6ICdCdXNpbmVzcycsIGdvdnRGZWU6IDAsIHNlcnZpY2VGZWU6IDAgfSxcbiAgeyBuYW1lOiAnQWFkaGFhciBBZGRyZXNzIFVwZGF0ZSBPbmxpbmUnLCBjYXRlZ29yeTogJ0FhZGhhYXInLCBnb3Z0RmVlOiAwLCBzZXJ2aWNlRmVlOiAwIH0sXG4gIHsgbmFtZTogJ0VQRk8gUEYgQWR2YW5jZSBXaXRoZHJhd2FsIEZvcm0gMzEnLCBjYXRlZ29yeTogJ0VQRk8nLCBnb3Z0RmVlOiAwLCBzZXJ2aWNlRmVlOiAwIH0sXG4gIHsgbmFtZTogJ0hpZ2gtUmVzIENvbG9yIFByaW50IC8gTGFtaW5hdGlvbicsIGNhdGVnb3J5OiAnUHJpbnRpbmcnLCBnb3Z0RmVlOiAwLCBzZXJ2aWNlRmVlOiAwIH0sXG4gIHsgbmFtZTogJ1BERiB0byBIRCBKUEcgQ29udmVyc2lvbiAvIFNjYW5uaW5nJywgY2F0ZWdvcnk6ICdTY2FubmluZycsIGdvdnRGZWU6IDAsIHNlcnZpY2VGZWU6IDAgfVxuXTtcbiJdfQ==