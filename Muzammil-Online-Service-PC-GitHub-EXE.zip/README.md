# Muzammil Online Service PC

Windows desktop build for Muzammil Online Service & Xerox.

## GitHub se EXE banana

1. Is project ko GitHub repository mein upload karein.
2. GitHub mein **Actions** tab kholein.
3. **Build Windows EXE** workflow select karein.
4. **Run workflow** dabayein.
5. Build complete hone ke baad workflow ke **Artifacts** section se:
   - Portable `.exe` — bina installation ke chalane ke liye
   - Setup `.exe` — Windows mein install karne ke liye

Workflow `release/*.exe` ko artifact ke roop mein upload karta hai.

> Note: Yeh desktop build React/Vite production files ko Electron mein package karta hai. Server-side API features (jaise local Express proxy/Gemini endpoint) ko alag backend ke saath configure karna padega agar unhe desktop EXE ke andar bhi chalana hai.
