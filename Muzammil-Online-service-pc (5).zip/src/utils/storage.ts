import { BillItem, CustomerRecord, DownloadItem, ShopSettings, UserAccount } from '../types';

const STORAGE_KEYS = {
  SETTINGS: 'mos_pc_settings',
  USER: 'mos_pc_active_user',
  BILLS: 'mos_pc_bills',
  CUSTOMERS: 'mos_pc_customers',
  DOWNLOADS: 'mos_pc_downloads',
  BIODATA_DRAFT: 'mos_pc_biodata_draft',
  PVC_PRESET: 'mos_pc_pvc_preset',
};

export const DEFAULT_SETTINGS: ShopSettings = {
  shopName: 'Muzammil Online Service',
  tagline: 'CSC & Digital Citizen Services Hub',
  ownerName: 'Imran Khan',
  phone: '9561460313',
  address: 'Naya Munshi Shaban Nagar, Main Road',
  upiId: '9561460313@ybl',
  thermalWidth: '58mm',
  gstNo: ''
};

export const DEFAULT_USER: UserAccount = {
  username: '',
  displayName: '',
  role: 'operator',
  phone: '',
  shopName: 'Muzammil Online Service',
  isLoggedIn: false
};

const INITIAL_CUSTOMERS: CustomerRecord[] = [
  {
    id: 'c1',
    name: 'Shaikh Sameer',
    mobile: '9876543210',
    serviceType: 'Majhi Ladki Bahin Yojana',
    ackToken: 'LB-MH-2026-8812',
    status: 'Ready',
    date: '2026-09-28',
    amount: 0,
    notes: 'Aadhaar bank link completed. Form submitted.'
  },
  {
    id: 'c2',
    name: 'Adil Shaikh',
    mobile: '9123456780',
    serviceType: 'PVC Smart Card (Aadhaar & PAN)',
    ackToken: 'PVC-99120',
    status: 'Delivered',
    date: '2026-09-29',
    amount: 0,
    notes: '2 copies laminated printed.'
  },
  {
    id: 'c3',
    name: 'Rameshwar Patil',
    mobile: '9421098765',
    serviceType: 'PM-KISAN eKYC & 7/12 Update',
    ackToken: 'PMK-77124',
    status: 'Processing',
    date: '2026-09-30',
    amount: 0,
    notes: 'Biometric fingerprint verified, awaiting land portal sync.'
  }
];

const INITIAL_BILLS: BillItem[] = [];

export const loadSettings = (): ShopSettings => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    return raw ? { ...DEFAULT_SETTINGS, ...JSON.parse(raw) } : DEFAULT_SETTINGS;
  } catch {
    return DEFAULT_SETTINGS;
  }
};

export const saveSettings = (settings: ShopSettings) => {
  try {
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
  } catch (e) {
    console.error('Failed to save settings', e);
  }
};

export const loadUser = (): UserAccount => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.USER);
    return raw ? JSON.parse(raw) : DEFAULT_USER;
  } catch {
    return DEFAULT_USER;
  }
};

export const saveUser = (user: UserAccount) => {
  try {
    localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(user));
  } catch (e) {
    console.error('Failed to save user', e);
  }
};

export const logoutUser = () => {
  try {
    localStorage.removeItem(STORAGE_KEYS.USER);
  } catch (e) {
    console.error('Failed to logout user', e);
  }
};

export const loadBills = (): BillItem[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.BILLS);
    return raw ? JSON.parse(raw) : INITIAL_BILLS;
  } catch {
    return INITIAL_BILLS;
  }
};

export const saveBills = (bills: BillItem[]) => {
  try {
    localStorage.setItem(STORAGE_KEYS.BILLS, JSON.stringify(bills));
  } catch (e) {
    console.error('Failed to save bills', e);
  }
};

export const loadCustomers = (): CustomerRecord[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.CUSTOMERS);
    return raw ? JSON.parse(raw) : INITIAL_CUSTOMERS;
  } catch {
    return INITIAL_CUSTOMERS;
  }
};

export const saveCustomers = (customers: CustomerRecord[]) => {
  try {
    localStorage.setItem(STORAGE_KEYS.CUSTOMERS, JSON.stringify(customers));
  } catch (e) {
    console.error('Failed to save customers', e);
  }
};

export const loadDownloads = (): DownloadItem[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.DOWNLOADS);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
};

export const saveDownloads = (downloads: DownloadItem[]) => {
  try {
    localStorage.setItem(STORAGE_KEYS.DOWNLOADS, JSON.stringify(downloads));
  } catch (e) {
    console.error('Failed to save downloads', e);
  }
};

export const addDownloadRecord = (item: DownloadItem) => {
  try {
    const existing = loadDownloads();
    const updated = [item, ...existing.filter(d => d.id !== item.id)].slice(0, 50);
    localStorage.setItem(STORAGE_KEYS.DOWNLOADS, JSON.stringify(updated));
  } catch (e) {
    console.error('Failed to add download record', e);
  }
};

export const deleteDownloadRecord = (id: string) => {
  try {
    const existing = loadDownloads();
    const updated = existing.filter(d => d.id !== id);
    localStorage.setItem(STORAGE_KEYS.DOWNLOADS, JSON.stringify(updated));
  } catch (e) {
    console.error('Failed to delete download record', e);
  }
};

export const exportAllData = () => {
  const data = {
    version: '98.0.0-pc',
    timestamp: new Date().toISOString(),
    settings: loadSettings(),
    user: loadUser(),
    bills: loadBills(),
    customers: loadCustomers(),
    downloads: loadDownloads()
  };
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `Muzammil_Online_Service_PC_Backup_${new Date().toISOString().slice(0, 10)}.json`;
  a.click();
  URL.revokeObjectURL(url);
};

export const importDataFromJSON = (jsonString: string): boolean => {
  try {
    const parsed = JSON.parse(jsonString);
    if (parsed.settings) saveSettings(parsed.settings);
    if (parsed.bills) saveBills(parsed.bills);
    if (parsed.customers) saveCustomers(parsed.customers);
    return true;
  } catch {
    return false;
  }
};
