/**
 * Universal In-App Print Engine for Muzammil Online Service PC Suite
 * Works without window.open / popup blocker issues in all desktop browsers & iframes
 */

export interface PrintOptions {
  title?: string;
  pageSize?: '4in 6in landscape' | '4in 6in portrait' | 'A4 landscape' | 'A4 portrait' | '58mm' | '80mm';
  orientation?: 'landscape' | 'portrait';
  margins?: string;
}

export const printImageSheet = (
  dataUrl: string,
  options: {
    paperFormat: '4x6_landscape' | 'a4_landscape' | '4x6_portrait' | 'a4_portrait';
    title: string;
    copiesCount?: number;
  }
) => {
  let pageSizeStyle = '6in 4in landscape';
  let imgStyle = 'width: 6in; height: 4in;';

  if (options.paperFormat === 'a4_landscape') {
    pageSizeStyle = 'A4 landscape';
    imgStyle = 'width: 297mm; height: 210mm;';
  } else if (options.paperFormat === 'a4_portrait') {
    pageSizeStyle = 'A4 portrait';
    imgStyle = 'width: 210mm; height: 297mm;';
  } else if (options.paperFormat === '4x6_portrait') {
    pageSizeStyle = '4in 6in portrait';
    imgStyle = 'width: 4in; height: 6in;';
  } else {
    // 4x6 landscape
    pageSizeStyle = '6in 4in landscape';
    imgStyle = 'width: 6in; height: 4in;';
  }

  const html = `
    <!DOCTYPE html>
    <html>
      <head>
        <meta charset="utf-8" />
        <title>${options.title}</title>
        <style>
          @page {
            size: ${pageSizeStyle};
            margin: 0mm;
          }
          * {
            box-sizing: border-box;
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
          }
          html, body {
            margin: 0 !important;
            padding: 0 !important;
            background: #ffffff !important;
            width: 100%;
            height: 100%;
            overflow: hidden;
            display: flex;
            align-items: center;
            justify-content: center;
          }
          img {
            ${imgStyle}
            display: block;
            margin: 0 auto;
            image-rendering: -webkit-optimize-contrast;
            image-rendering: crisp-edges;
          }
        </style>
      </head>
      <body>
        <img id="print-target" src="${dataUrl}" />
      </body>
    </html>
  `;

  executePrint(html);
};

export const printHtmlDocument = (htmlBody: string, title: string, pageStyle: string) => {
  const html = `
    <!DOCTYPE html>
    <html>
      <head>
        <meta charset="utf-8" />
        <title>${title}</title>
        <style>
          ${pageStyle}
          * {
            box-sizing: border-box;
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
          }
          body {
            margin: 0;
            padding: 0;
            background: #fff;
            color: #0f172a;
          }
        </style>
      </head>
      <body>
        ${htmlBody}
      </body>
    </html>
  `;

  executePrint(html);
};

function executePrint(fullHtml: string) {
  // Use a dedicated print iframe in document body
  let iframe = document.getElementById('mos-universal-print-frame') as HTMLIFrameElement;
  if (!iframe) {
    iframe = document.createElement('iframe');
    iframe.id = 'mos-universal-print-frame';
    iframe.style.position = 'fixed';
    iframe.style.right = '0';
    iframe.style.bottom = '0';
    iframe.style.width = '0px';
    iframe.style.height = '0px';
    iframe.style.border = '0px none transparent';
    iframe.style.opacity = '0';
    iframe.style.pointerEvents = 'none';
    iframe.style.zIndex = '-9999';
    document.body.appendChild(iframe);
  }

  const doc = iframe.contentWindow?.document || iframe.contentDocument;
  if (!doc) {
    window.print();
    return;
  }

  doc.open();
  doc.write(fullHtml);
  doc.close();

  // Wait for all assets in iframe to load
  setTimeout(() => {
    try {
      iframe.contentWindow?.focus();
      iframe.contentWindow?.print();
    } catch (e) {
      console.warn('Iframe print error, falling back to window.print', e);
      window.print();
    }
  }, 250);
}
