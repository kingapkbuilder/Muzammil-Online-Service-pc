import React, { useState } from 'react';
import { 
  Sparkles, 
  Send, 
  User, 
  Bot, 
  Copy, 
  Check, 
  HelpCircle, 
  BookOpen, 
  ExternalLink 
} from 'lucide-react';
import { SCHEME_GUIDES } from '../data/schemeKnowledge';

interface Message {
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
}

export const AiAssistantView: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      sender: 'assistant',
      text: `Namaskar! Welcome to the **Muzammil Online Service AI Digital Assistant**.\n\nI can help you with:\n• Required documents checklist for any scheme (Ladki Bahin, PM-KISAN, Ayushman Bharat, etc.)\n• Step-by-step portal application procedures\n• PAN card correction & Aadhaar update rules\n• PVC Card & Passport photo print presets\n\nType your question in Hindi, English, or Hinglish below, or click any quick topic!`,
      timestamp: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })
    }
  ]);

  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  const quickPrompts = [
    'Majhi Ladki Bahin Yojana ke liye kya documents lagenge?',
    'PAN Card correction kaise karein?',
    'PM-KISAN eKYC aur land seeding process',
    'Ayushman Golden Card banane ka tarika',
    'PVC card 4x6 print setup on Epson L805'
  ];

  const handleSendMessage = async (textToSend?: string) => {
    const query = (textToSend || input).trim();
    if (!query || isLoading) return;

    const userMsg: Message = {
      sender: 'user',
      text: query,
      timestamp: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    try {
      // 1. Try server-side Gemini API endpoint
      const response = await fetch('/api/assistant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: query })
      });

      if (response.ok) {
        const data = await response.json();
        if (data.reply) {
          setMessages(prev => [
            ...prev,
            {
              sender: 'assistant',
              text: data.reply,
              timestamp: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })
            }
          ]);
          setIsLoading(false);
          return;
        }
      }
    } catch {
      // Fallback to local intelligent knowledge base
    }

    // Smart Local Knowledge Base Fallback
    setTimeout(() => {
      const q = query.toLowerCase();
      let reply = '';

      if (q.includes('ladki') || q.includes('bahin') || q.includes('nari')) {
        const g = SCHEME_GUIDES.ladki_bahin;
        reply = `### ${g.title}\n\n**Eligibility:**\n${g.eligibility.map(e => `• ${e}`).join('\n')}\n\n**Documents Required:**\n${g.documents.map(d => `• ${d}`).join('\n')}\n\n**Application Steps:**\n${g.procedure.join('\n')}\n\n**Official Portal:** ${g.officialUrl}\n\n💡 **Tip:** ${g.notes}`;
      } else if (q.includes('kisan') || q.includes('pmkisan') || q.includes('farmer')) {
        const g = SCHEME_GUIDES.pm_kisan;
        reply = `### ${g.title}\n\n**Eligibility:**\n${g.eligibility.map(e => `• ${e}`).join('\n')}\n\n**Documents Required:**\n${g.documents.map(d => `• ${d}`).join('\n')}\n\n**Procedure:**\n${g.procedure.join('\n')}\n\n**Portal:** ${g.officialUrl}\n\n💡 ${g.notes}`;
      } else if (q.includes('pan') || q.includes('uti') || q.includes('nsdl')) {
        const g = SCHEME_GUIDES.pan_card;
        reply = `### ${g.title}\n\n**Required Documents:**\n${g.documents.map(d => `• ${d}`).join('\n')}\n\n**Procedure:**\n${g.procedure.join('\n')}\n\n**Portal:** ${g.officialUrl}\n\n💡 ${g.notes}`;
      } else if (q.includes('ayushman') || q.includes('golden') || q.includes('health') || q.includes('pmjay')) {
        const g = SCHEME_GUIDES.ayushman_bharat;
        reply = `### ${g.title}\n\n**Eligibility:**\n${g.eligibility.map(e => `• ${e}`).join('\n')}\n\n**Documents Required:**\n${g.documents.map(d => `• ${d}`).join('\n')}\n\n**Procedure:**\n${g.procedure.join('\n')}\n\n**Portal:** ${g.officialUrl}\n\n💡 ${g.notes}`;
      } else if (q.includes('pvc') || q.includes('epson') || q.includes('print')) {
        reply = `### PVC Card Printing Setup for Cyber Cafe\n\n• **Standard Dimensions:** CR-80 format (85.6 mm × 54.0 mm, aspect ratio ~1.586).\n• **Sheet Paper:** 4×6 inch (10×15 cm) Premium Glossy Photo Paper.\n• **Resolution:** 300 DPI (1200 × 1800 px).\n• **Epson / Canon Setup:** In print properties, select Paper Type = 'Photo Paper Glossy', Quality = 'High', Scale = '100% / Actual Size'.\n• Our PVC Card Maker tool automatically aligns Front and Back cards with standard cutting guide lines!`;
      } else {
        reply = `Citizen Service Guidelines for **${query}**:\n\n1. **Standard Document Verification:** Always check original Aadhaar card with active mobile number.\n2. **Bank Account Seeding:** Ensure customer bank account has NPCI / DBT mapping active.\n3. **Application Acknowledgment:** Always generate and provide a printed receipt to the customer using our Billing Desk.\n4. **Official Portals:** Check our 'Govt Portals Hub' tab to launch verified central and state websites safely.`;
      }

      setMessages(prev => [
        ...prev,
        {
          sender: 'assistant',
          text: reply,
          timestamp: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })
        }
      ]);
      setIsLoading(false);
    }, 400);
  };

  const handleCopy = (text: string, idx: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(idx);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  return (
    <div className="space-y-4 max-w-5xl mx-auto">
      {/* Header bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900 border border-slate-800 p-4 rounded-2xl shadow-md">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-extrabold text-white">AI Scheme & Citizen Service Assistant</h1>
            <span className="bg-amber-500/20 text-amber-300 border border-amber-500/30 text-xs px-2 py-0.5 rounded-full font-mono font-bold flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-amber-400" />
              <span>Smart Assistant</span>
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Instant guidance on government rules, document checklists, and portal procedures for cyber cafe operators
          </p>
        </div>
      </div>

      {/* Quick Prompts Bar */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
        {quickPrompts.map((prompt, idx) => (
          <button
            key={idx}
            onClick={() => handleSendMessage(prompt)}
            className="bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800 px-3 py-1.5 rounded-xl whitespace-nowrap transition-colors"
          >
            {prompt}
          </button>
        ))}
      </div>

      {/* Chat Messages Panel */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl min-h-[500px] flex flex-col justify-between space-y-4">
        <div className="space-y-4 overflow-y-auto max-h-[550px] pr-2">
          {messages.map((msg, idx) => (
            <div
              key={idx}
              className={`flex items-start gap-3 ${
                msg.sender === 'user' ? 'flex-row-reverse' : 'flex-row'
              }`}
            >
              <div className={`w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0 text-white shadow-md ${
                msg.sender === 'user' ? 'bg-blue-600' : 'bg-gradient-to-tr from-amber-500 to-indigo-600'
              }`}>
                {msg.sender === 'user' ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
              </div>

              <div className={`max-w-2xl rounded-2xl p-4 text-xs leading-relaxed ${
                msg.sender === 'user'
                  ? 'bg-blue-600 text-white shadow-md shadow-blue-600/20'
                  : 'bg-slate-950 text-slate-200 border border-slate-800 shadow-md'
              }`}>
                <div className="whitespace-pre-line select-text">
                  {msg.text}
                </div>

                <div className="mt-2.5 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[10px] text-slate-400">
                  <span>{msg.timestamp}</span>
                  {msg.sender === 'assistant' && (
                    <button
                      onClick={() => handleCopy(msg.text, idx)}
                      className="hover:text-white flex items-center gap-1"
                    >
                      {copiedIndex === idx ? (
                        <>
                          <Check className="w-3 h-3 text-emerald-400" />
                          <span className="text-emerald-400">Copied</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3 h-3" />
                          <span>Copy Text</span>
                        </>
                      )}
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))}

          {isLoading && (
            <div className="flex items-center gap-2 text-slate-400 text-xs italic pl-11">
              <Sparkles className="w-4 h-4 animate-spin text-amber-400" />
              <span>Analyzing government rules and procedure...</span>
            </div>
          )}
        </div>

        {/* Input Bar */}
        <div className="pt-3 border-t border-slate-800">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              placeholder="Ask anything about Aadhaar, Ladki Bahin, PAN, PVC, Ration Card..."
              value={input}
              onChange={(e) => setInput(e.target.value)}
              className="flex-1 bg-slate-950 border border-slate-700 rounded-xl px-4 py-3 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
            />
            <button
              type="submit"
              disabled={isLoading || !input.trim()}
              className="bg-gradient-to-r from-amber-500 to-indigo-600 hover:from-amber-400 hover:to-indigo-500 text-white font-bold p-3 rounded-xl shadow-lg transition-transform active:scale-95 disabled:opacity-50"
            >
              <Send className="w-5 h-5" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
