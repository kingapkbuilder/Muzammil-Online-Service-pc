import React, { useState, useRef, useEffect, useCallback } from 'react';
import { 
  Film, 
  Video, 
  Play, 
  Pause, 
  RotateCcw, 
  Scissors, 
  Volume2, 
  VolumeX, 
  RotateCw, 
  Type, 
  Image as ImageIcon, 
  Music, 
  Download, 
  Layers, 
  Sliders, 
  Sparkles, 
  Clock, 
  Upload, 
  RefreshCw, 
  Check, 
  FastForward, 
  Rewind, 
  Plus, 
  Trash2, 
  Eye, 
  EyeOff, 
  Flame, 
  Sun, 
  Contrast, 
  Droplets, 
  CheckCircle2, 
  Camera,
  FolderDown,
  FileVideo,
  SplitSquareVertical,
  FlipHorizontal,
  FlipVertical
} from 'lucide-react';
import { DownloadItem } from '../types';

interface VideoStudioViewProps {
  onAddDownload?: (download: DownloadItem) => void;
  onNavigate?: (tab: string) => void;
}

type AspectRatio = '16:9' | '9:16' | '1:1' | '4:5';

interface TextOverlay {
  id: string;
  text: string;
  fontSize: number;
  color: string;
  bgColor: string;
  position: 'top' | 'center' | 'bottom';
  style: 'banner' | 'clean' | 'neon' | 'lower_third';
  startTime: number;
  endTime: number;
}

interface AudioTrack {
  id: string;
  name: string;
  src: string;
  volume: number;
  isMuted: boolean;
}

export const VideoStudioView: React.FC<VideoStudioViewProps> = ({ onAddDownload }) => {
  // Video Source & Element
  const [videoSrc, setVideoSrc] = useState<string | null>(null);
  const [videoFileName, setVideoFileName] = useState<string>('project_video.mp4');
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Secondary Overlay Image/Video Track (Track 2)
  const [overlayImageSrc, setOverlayImageSrc] = useState<string | null>(null);
  const [overlayScale, setOverlayScale] = useState<number>(0.3);
  const [overlayPosition, setOverlayPosition] = useState<'top-right' | 'top-left' | 'bottom-right' | 'bottom-left' | 'center'>('top-right');
  const [overlayOpacity, setOverlayOpacity] = useState<number>(0.9);
  const overlayImgRef = useRef<HTMLImageElement | null>(null);

  // Audio / Music Track (Track 3)
  const [musicSrc, setMusicSrc] = useState<string | null>(null);
  const [musicVolume, setMusicVolume] = useState<number>(70);
  const [isMusicMuted, setIsMusicMuted] = useState<boolean>(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // Playback & Timing
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [duration, setDuration] = useState<number>(10);
  const [inPoint, setInPoint] = useState<number>(0);
  const [outPoint, setOutPoint] = useState<number>(10);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1.0);
  const [masterVolume, setMasterVolume] = useState<number>(100);
  const [isMasterMuted, setIsMasterMuted] = useState<boolean>(false);
  const [isLooping, setIsLooping] = useState<boolean>(true);

  // Canvas Geometry & Aspect Ratio
  const [aspectRatio, setAspectRatio] = useState<AspectRatio>('16:9');
  const [rotation, setRotation] = useState<number>(0); // 0, 90, 180, 270
  const [flipH, setFlipH] = useState<boolean>(false);
  const [flipV, setFlipV] = useState<boolean>(false);
  const [zoomLevel, setZoomLevel] = useState<number>(1.0);

  // Color Grading & Filters
  const [brightness, setBrightness] = useState<number>(0);
  const [contrast, setContrast] = useState<number>(0);
  const [saturation, setSaturation] = useState<number>(0);
  const [warmth, setWarmth] = useState<number>(0);
  const [filterPreset, setFilterPreset] = useState<string>('normal');

  // Text & Title Layers (Track 4)
  const [textOverlays, setTextOverlays] = useState<TextOverlay[]>([
    {
      id: 'txt-1',
      text: 'Muzammil Online Service • CSC Cyber Cafe',
      fontSize: 28,
      color: '#ffffff',
      bgColor: 'rgba(15, 23, 42, 0.85)',
      position: 'bottom',
      style: 'lower_third',
      startTime: 0,
      endTime: 10
    }
  ]);
  const [activeTextId, setActiveTextId] = useState<string>('txt-1');

  // Watermark / Cyber Cafe Stamp (Track 5)
  const [showWatermark, setShowWatermark] = useState<boolean>(true);
  const [watermarkText, setWatermarkText] = useState<string>('Muzammil Online • 9561460313');
  const [watermarkPos, setWatermarkPos] = useState<'top-left' | 'top-right' | 'bottom-left' | 'bottom-right'>('top-right');
  const [watermarkOpacity, setWatermarkOpacity] = useState<number>(0.8);

  // Active Editing Sub-Deck: 'timeline' | 'color' | 'audio' | 'text' | 'overlay' | 'crop'
  const [activeToolTab, setActiveToolTab] = useState<'timeline' | 'color' | 'audio' | 'text' | 'overlay' | 'crop'>('timeline');

  // Timeline UI state
  const [timelineZoom, setTimelineZoom] = useState<number>(1);
  const [isExporting, setIsExporting] = useState<boolean>(false);
  const [exportProgress, setExportProgress] = useState<number>(0);
  const [statusAlert, setStatusAlert] = useState<string | null>(null);

  // MediaRecorder Ref for Video Render
  const recorderRef = useRef<MediaRecorder | null>(null);
  const recordedBlobsRef = useRef<Blob[]>([]);

  // Resolution targets based on aspect ratio
  const getCanvasDimensions = useCallback((): { width: number; height: number } => {
    switch (aspectRatio) {
      case '16:9': return { width: 1280, height: 720 };
      case '9:16': return { width: 720, height: 1280 };
      case '1:1': return { width: 1080, height: 1080 };
      case '4:5': return { width: 864, height: 1080 };
      default: return { width: 1280, height: 720 };
    }
  }, [aspectRatio]);

  // Format seconds to 00:00:00
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    const ms = Math.floor((seconds % 1) * 10);
    return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}.${ms}`;
  };

  // 1. Generate Interactive Motion Sample Video on Canvas if no file uploaded
  const handleLoadSampleVideo = () => {
    const sampleCanvas = document.createElement('canvas');
    sampleCanvas.width = 1280;
    sampleCanvas.height = 720;
    const sCtx = sampleCanvas.getContext('2d');
    if (!sCtx) return;

    // Use WebM/MP4 generator stream
    const stream = sampleCanvas.captureStream(30);
    const rec = new MediaRecorder(stream, { mimeType: 'video/webm' });
    const chunks: Blob[] = [];

    rec.ondataavailable = (e) => {
      if (e.data.size > 0) chunks.push(e.data);
    };

    rec.onstop = () => {
      const blob = new Blob(chunks, { type: 'video/webm' });
      const url = URL.createObjectURL(blob);
      setVideoSrc(url);
      setVideoFileName('CyberCafe_Sample_Demo.webm');
      setDuration(8);
      setInPoint(0);
      setOutPoint(8);
      setCurrentTime(0);
      setStatusAlert('🎬 Sample Cyber Cafe Video clip generated successfully!');
      setTimeout(() => setStatusAlert(null), 3500);
    };

    rec.start();

    // Render 8 seconds of dynamic cyber graphics animation
    let frame = 0;
    const totalFrames = 8 * 30; // 240 frames
    const animInterval = setInterval(() => {
      frame++;
      const progress = frame / totalFrames;
      const timeSec = frame / 30;

      // Dark cyber background
      const grad = sCtx.createLinearGradient(0, 0, 1280, 720);
      grad.addColorStop(0, '#020617');
      grad.addColorStop(0.5, '#0f172a');
      grad.addColorStop(1, '#1e1b4b');
      sCtx.fillStyle = grad;
      sCtx.fillRect(0, 0, 1280, 720);

      // Moving Grid lines
      sCtx.strokeStyle = 'rgba(56, 189, 248, 0.15)';
      sCtx.lineWidth = 1;
      const offset = (frame * 2) % 40;
      for (let x = offset; x < 1280; x += 40) {
        sCtx.beginPath();
        sCtx.moveTo(x, 0);
        sCtx.lineTo(x, 720);
        sCtx.stroke();
      }
      for (let y = offset; y < 720; y += 40) {
        sCtx.beginPath();
        sCtx.moveTo(0, y);
        sCtx.lineTo(1280, y);
        sCtx.stroke();
      }

      // Glowing Center Card
      sCtx.save();
      sCtx.translate(640, 360);
      sCtx.rotate(Math.sin(progress * Math.PI * 2) * 0.05);

      sCtx.fillStyle = 'rgba(15, 23, 42, 0.9)';
      sCtx.strokeStyle = '#38bdf8';
      sCtx.lineWidth = 4;
      sCtx.beginPath();
      sCtx.roundRect(-300, -180, 600, 360, 24);
      sCtx.fill();
      sCtx.stroke();

      // Brand Title
      sCtx.fillStyle = '#ffffff';
      sCtx.font = 'bold 38px sans-serif';
      sCtx.textAlign = 'center';
      sCtx.fillText('MUZAMMIL ONLINE SERVICE', 0, -60);

      // Subtitle
      sCtx.fillStyle = '#38bdf8';
      sCtx.font = 'bold 22px sans-serif';
      sCtx.fillText('CSC & Cyber Cafe Professional Video Studio', 0, -15);

      // Floating particles
      sCtx.fillStyle = '#22c55e';
      sCtx.font = '16px monospace';
      sCtx.fillText(`LIVE TIMECODE: 00:0${Math.floor(timeSec)}.${(frame % 30)}`, 0, 45);

      sCtx.fillStyle = '#94a3b8';
      sCtx.font = '14px sans-serif';
      sCtx.fillText('PVC Card • Passport Photo • Online Citizen Services', 0, 95);

      sCtx.restore();

      if (frame >= totalFrames) {
        clearInterval(animInterval);
        rec.stop();
      }
    }, 1000 / 30);
  };

  // Video File Upload Handler
  const handleUploadVideo = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const url = URL.createObjectURL(file);
    setVideoSrc(url);
    setVideoFileName(file.name);
    setCurrentTime(0);
    setIsPlaying(false);
    setStatusAlert(`🎬 Video "${file.name}" loaded into Multi-Layer Timeline!`);
    setTimeout(() => setStatusAlert(null), 3500);
  };

  // Overlay Image Upload (Track 2)
  const handleUploadOverlayImage = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const url = URL.createObjectURL(file);
    setOverlayImageSrc(url);
    const img = new Image();
    img.src = url;
    img.onload = () => {
      overlayImgRef.current = img;
    };
    setStatusAlert('🖼️ Overlay Picture-in-Picture added to Track 2!');
    setTimeout(() => setStatusAlert(null), 3000);
  };

  // Background Audio Upload (Track 3)
  const handleUploadMusic = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const url = URL.createObjectURL(file);
    setMusicSrc(url);
    setStatusAlert(`🎵 Audio Track "${file.name}" added to Track 3!`);
    setTimeout(() => setStatusAlert(null), 3000);
  };

  // Video Metadata Loaded
  const handleVideoLoadedMetadata = () => {
    const v = videoRef.current;
    if (!v) return;
    const dur = v.duration || 10;
    setDuration(dur);
    setInPoint(0);
    setOutPoint(dur);
  };

  // Toggle Play / Pause
  const handleTogglePlay = () => {
    const v = videoRef.current;
    if (!v) return;

    if (isPlaying) {
      v.pause();
      if (audioRef.current) audioRef.current.pause();
      setIsPlaying(false);
    } else {
      // Loop if at end
      if (currentTime >= outPoint) {
        v.currentTime = inPoint;
        setCurrentTime(inPoint);
      }
      v.playbackRate = playbackSpeed;
      v.volume = isMasterMuted ? 0 : Math.min(1.0, masterVolume / 100);
      v.play();

      if (audioRef.current && musicSrc) {
        audioRef.current.currentTime = v.currentTime;
        audioRef.current.volume = isMusicMuted ? 0 : Math.min(1.0, musicVolume / 100);
        audioRef.current.play();
      }
      setIsPlaying(true);
    }
  };

  // Playhead scrub
  const handleSeek = (newTime: number) => {
    const clamped = Math.max(0, Math.min(duration, newTime));
    setCurrentTime(clamped);
    if (videoRef.current) {
      videoRef.current.currentTime = clamped;
    }
    if (audioRef.current) {
      audioRef.current.currentTime = clamped;
    }
  };

  // Trim Points
  const handleSetInPoint = () => {
    setInPoint(currentTime);
    setStatusAlert(`✂️ In-Point (Cut Start) set to ${formatTime(currentTime)}`);
    setTimeout(() => setStatusAlert(null), 2500);
  };

  const handleSetOutPoint = () => {
    setOutPoint(currentTime);
    setStatusAlert(`✂️ Out-Point (Cut End) set to ${formatTime(currentTime)}`);
    setTimeout(() => setStatusAlert(null), 2500);
  };

  const handleResetTrim = () => {
    setInPoint(0);
    setOutPoint(duration);
    setStatusAlert('🔄 Trim range reset to full video');
    setTimeout(() => setStatusAlert(null), 2000);
  };

  // Speed changer
  const handleSpeedChange = (speed: number) => {
    setPlaybackSpeed(speed);
    if (videoRef.current) {
      videoRef.current.playbackRate = speed;
    }
    setStatusAlert(`⚡ Playback speed set to ${speed}x`);
    setTimeout(() => setStatusAlert(null), 2000);
  };

  // Snapshot current frame as 1080p JPG
  const handleCaptureSnapshot = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    try {
      const dataUrl = canvas.toDataURL('image/jpeg', 0.95);
      const a = document.createElement('a');
      a.href = dataUrl;
      const fileName = `Video_Snapshot_${Date.now()}.jpg`;
      a.download = fileName;
      a.click();

      if (onAddDownload) {
        onAddDownload({
          id: `vid-snap-${Date.now()}`,
          title: fileName,
          type: 'Converted JPG',
          size: `${canvas.width}×${canvas.height} px`,
          timestamp: new Date().toLocaleTimeString('en-IN')
        });
      }

      setStatusAlert('📸 High-Resolution Frame Snapshot downloaded & saved to Vault!');
      setTimeout(() => setStatusAlert(null), 3000);
    } catch (e) {
      console.error(e);
    }
  };

  // -------------------------------------------------------------
  // MULTI-LAYER VIDEO COMPOSITING LOOP (HTML5 Canvas 60 FPS)
  // -------------------------------------------------------------
  const renderCompositeFrame = useCallback(() => {
    const canvas = canvasRef.current;
    const video = videoRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const { width: targetW, height: targetH } = getCanvasDimensions();
    canvas.width = targetW;
    canvas.height = targetH;

    // 1. LAYER 0: Canvas Background Fill
    ctx.fillStyle = '#020617';
    ctx.fillRect(0, 0, targetW, targetH);

    // 2. LAYER 1: Main Video Track
    if (video && video.readyState >= 2) {
      ctx.save();

      // Transform, Rotation & Flip
      ctx.translate(targetW / 2, targetH / 2);
      ctx.rotate((rotation * Math.PI) / 180);
      ctx.scale(flipH ? -1 : 1, flipV ? -1 : 1);
      ctx.scale(zoomLevel, zoomLevel);

      // Calculate video aspect fit
      const vAspect = video.videoWidth / video.videoHeight;
      const cAspect = targetW / targetH;
      let drawW = targetW;
      let drawH = targetH;

      if (vAspect > cAspect) {
        drawH = targetW / vAspect;
      } else {
        drawW = targetH * vAspect;
      }

      // Color Grading Filters
      let filterStr = `brightness(${100 + brightness}%) contrast(${100 + contrast}%) saturate(${100 + saturation}%)`;
      if (filterPreset === 'cinematic') {
        filterStr += ' contrast(115%) saturate(125%)';
      } else if (filterPreset === 'bw') {
        filterStr += ' grayscale(100%) contrast(120%)';
      } else if (filterPreset === 'vintage') {
        filterStr += ' sepia(50%) contrast(110%)';
      } else if (filterPreset === 'neon') {
        filterStr += ' saturate(160%) hue-rotate(15deg)';
      }
      ctx.filter = filterStr;

      ctx.drawImage(video, -drawW / 2, -drawH / 2, drawW, drawH);

      // Warmth color overlay
      if (warmth !== 0) {
        ctx.globalCompositeOperation = 'color';
        ctx.fillStyle = warmth > 0
          ? `rgba(255, 160, 60, ${Math.min(0.35, (warmth / 100) * 0.4)})`
          : `rgba(60, 160, 255, ${Math.min(0.35, (Math.abs(warmth) / 100) * 0.4)})`;
        ctx.fillRect(-drawW / 2, -drawH / 2, drawW, drawH);
      }

      ctx.restore();
    } else {
      // Placeholder screen
      ctx.fillStyle = '#64748b';
      ctx.font = 'bold 24px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('Upload Video or Click "Load Sample Video"', targetW / 2, targetH / 2 - 15);
      ctx.font = '16px sans-serif';
      ctx.fillStyle = '#94a3b8';
      ctx.fillText('Multi-Layer Timeline Ready (Main Video • Overlay • Audio • Titles • Watermark)', targetW / 2, targetH / 2 + 25);
    }

    // 3. LAYER 2: Overlay B-Roll Picture-in-Picture Track
    if (overlayImgRef.current && overlayImageSrc) {
      ctx.save();
      ctx.globalAlpha = overlayOpacity;

      const img = overlayImgRef.current;
      const imgAspect = img.width / img.height;
      const pipW = targetW * overlayScale;
      const pipH = pipW / imgAspect;

      let px = 20;
      let py = 20;

      if (overlayPosition === 'top-right') {
        px = targetW - pipW - 24;
        py = 24;
      } else if (overlayPosition === 'top-left') {
        px = 24;
        py = 24;
      } else if (overlayPosition === 'bottom-right') {
        px = targetW - pipW - 24;
        py = targetH - pipH - 24;
      } else if (overlayPosition === 'bottom-left') {
        px = 24;
        py = targetH - pipH - 24;
      } else {
        px = (targetW - pipW) / 2;
        py = (targetH - pipH) / 2;
      }

      // Border & Shadow
      ctx.fillStyle = 'rgba(15, 23, 42, 0.6)';
      ctx.fillRect(px - 4, py - 4, pipW + 8, pipH + 8);
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 2;
      ctx.strokeRect(px - 4, py - 4, pipW + 8, pipH + 8);

      ctx.drawImage(img, px, py, pipW, pipH);
      ctx.restore();
    }

    // 4. LAYER 4: Animated Lower-Thirds & Text Captions Track
    textOverlays.forEach((txt) => {
      if (currentTime >= txt.startTime && currentTime <= txt.endTime && txt.text.trim()) {
        ctx.save();
        ctx.font = `bold ${txt.fontSize}px sans-serif`;
        ctx.textAlign = 'center';

        const textMetrics = ctx.measureText(txt.text);
        const textW = textMetrics.width;
        const boxPaddingX = 24;
        const boxPaddingY = 12;
        const boxH = txt.fontSize + boxPaddingY * 2;

        let ty = targetH - 80;
        if (txt.position === 'top') ty = 80;
        else if (txt.position === 'center') ty = targetH / 2;

        // Background Banner
        ctx.fillStyle = txt.bgColor;
        ctx.beginPath();
        ctx.roundRect(
          (targetW - textW - boxPaddingX * 2) / 2,
          ty - boxH / 2,
          textW + boxPaddingX * 2,
          boxH,
          12
        );
        ctx.fill();

        if (txt.style === 'lower_third') {
          ctx.strokeStyle = '#38bdf8';
          ctx.lineWidth = 2.5;
          ctx.stroke();
        } else if (txt.style === 'neon') {
          ctx.shadowColor = '#06b6d4';
          ctx.shadowBlur = 15;
        }

        // Text
        ctx.fillStyle = txt.color;
        ctx.textBaseline = 'middle';
        ctx.fillText(txt.text, targetW / 2, ty);
        ctx.restore();
      }
    });

    // 5. LAYER 5: Cyber Cafe Digital Watermark Track
    if (showWatermark && watermarkText.trim()) {
      ctx.save();
      ctx.globalAlpha = watermarkOpacity;
      ctx.font = 'bold 15px sans-serif';

      const wMetrics = ctx.measureText(watermarkText);
      const wWidth = wMetrics.width + 24;
      const wHeight = 30;

      let wx = targetW - wWidth - 16;
      let wy = 16;

      if (watermarkPos === 'top-left') {
        wx = 16;
        wy = 16;
      } else if (watermarkPos === 'bottom-right') {
        wx = targetW - wWidth - 16;
        wy = targetH - wHeight - 16;
      } else if (watermarkPos === 'bottom-left') {
        wx = 16;
        wy = targetH - wHeight - 16;
      }

      ctx.fillStyle = 'rgba(15, 23, 42, 0.75)';
      ctx.beginPath();
      ctx.roundRect(wx, wy, wWidth, wHeight, 8);
      ctx.fill();
      ctx.strokeStyle = 'rgba(56, 189, 248, 0.4)';
      ctx.lineWidth = 1;
      ctx.stroke();

      ctx.fillStyle = '#ffffff';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(watermarkText, wx + wWidth / 2, wy + wHeight / 2);
      ctx.restore();
    }
  }, [
    getCanvasDimensions, 
    rotation, 
    flipH, 
    flipV, 
    zoomLevel, 
    brightness, 
    contrast, 
    saturation, 
    warmth, 
    filterPreset, 
    overlayImageSrc, 
    overlayScale, 
    overlayPosition, 
    overlayOpacity, 
    textOverlays, 
    currentTime, 
    showWatermark, 
    watermarkText, 
    watermarkPos, 
    watermarkOpacity
  ]);

  // Video Time Update Listener Loop
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    let animId: number;
    const updateLoop = () => {
      if (video && !video.paused && !video.ended) {
        setCurrentTime(video.currentTime);

        // Check Out-Point Trim boundary
        if (video.currentTime >= outPoint) {
          if (isLooping) {
            video.currentTime = inPoint;
            if (audioRef.current) audioRef.current.currentTime = inPoint;
          } else {
            video.pause();
            if (audioRef.current) audioRef.current.pause();
            setIsPlaying(false);
          }
        }
      }
      renderCompositeFrame();
      animId = requestAnimationFrame(updateLoop);
    };

    animId = requestAnimationFrame(updateLoop);
    return () => cancelAnimationFrame(animId);
  }, [inPoint, outPoint, isLooping, renderCompositeFrame]);

  // Keyboard Spacebar to Play/Pause
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.target as HTMLElement).tagName === 'INPUT' || (e.target as HTMLElement).tagName === 'TEXTAREA') {
        return;
      }
      if (e.code === 'Space') {
        e.preventDefault();
        handleTogglePlay();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  });

  // -------------------------------------------------------------
  // REAL VIDEO EXPORT ENGINE (WebM/MP4 Canvas Recorder)
  // -------------------------------------------------------------
  const handleExportVideo = () => {
    const canvas = canvasRef.current;
    const video = videoRef.current;
    if (!canvas) return;

    setIsExporting(true);
    setExportProgress(5);

    try {
      const stream = canvas.captureStream(30);
      const mime = MediaRecorder.isTypeSupported('video/mp4;codecs=avc1')
        ? 'video/mp4;codecs=avc1'
        : 'video/webm;codecs=vp9';

      const recorder = new MediaRecorder(stream, { mimeType: mime });
      recordedBlobsRef.current = [];

      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) recordedBlobsRef.current.push(e.data);
      };

      recorder.onstop = () => {
        const blob = new Blob(recordedBlobsRef.current, { type: mime });
        const ext = mime.includes('mp4') ? 'mp4' : 'webm';
        const exportName = `Muzammil_Studio_${videoFileName.replace(/\.[^/.]+$/, "")}_Edited.${ext}`;
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = exportName;
        a.click();

        if (onAddDownload) {
          onAddDownload({
            id: `vid-export-${Date.now()}`,
            title: exportName,
            type: 'PVC Card PDF', // reuse vault download item format
            size: `${(blob.size / (1024 * 1024)).toFixed(2)} MB (${aspectRatio})`,
            timestamp: new Date().toLocaleTimeString('en-IN')
          });
        }

        setIsExporting(false);
        setExportProgress(100);
        setStatusAlert(`🎉 Video Export Complete! "${exportName}" downloaded.`);
        setTimeout(() => setStatusAlert(null), 4000);
      };

      recorderRef.current = recorder;
      recorder.start();

      // Reset video to in-point and play to record
      if (video) {
        video.currentTime = inPoint;
        video.playbackRate = 1.0;
        video.play();
        setIsPlaying(true);
      }

      const totalRecordTime = (outPoint - inPoint) * 1000;
      const startTime = Date.now();

      const progInterval = setInterval(() => {
        const elapsed = Date.now() - startTime;
        const pct = Math.min(98, Math.round((elapsed / totalRecordTime) * 100));
        setExportProgress(pct);

        if (elapsed >= totalRecordTime) {
          clearInterval(progInterval);
          recorder.stop();
          if (video) video.pause();
          setIsPlaying(false);
        }
      }, 200);

    } catch (e) {
      console.error(e);
      setIsExporting(false);
      setStatusAlert('❌ Export error. Try using a standard WebM/MP4 format.');
      setTimeout(() => setStatusAlert(null), 4000);
    }
  };

  return (
    <div className="space-y-4 select-none">
      {/* Hidden audio element for Track 3 */}
      {musicSrc && <audio ref={audioRef} src={musicSrc} loop />}

      {/* TOP HEADER BAR */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900 border border-slate-800 p-4 rounded-2xl shadow-md">
        <div>
          <div className="flex items-center gap-2 flex-wrap">
            <h1 className="text-xl font-extrabold text-white flex items-center gap-2">
              <Film className="w-5 h-5 text-rose-500" />
              <span>Multi-Layer Video Studio Pro</span>
            </h1>
            <span className="bg-rose-500/20 text-rose-400 border border-rose-500/30 text-xs px-2.5 py-0.5 rounded-full font-mono font-bold">
              5 Timeline Tracks
            </span>
            <span className="bg-blue-500/20 text-blue-400 border border-blue-500/30 text-xs px-2.5 py-0.5 rounded-full font-bold">
              Full HD 1080p Export
            </span>
            <span className="bg-purple-500/20 text-purple-300 border border-purple-500/30 text-xs px-2.5 py-0.5 rounded-full font-bold">
              Reels / YouTube / CSC Branding
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Cut, trim, speed control, color grading, lower-thirds, audio mixing, picture-in-picture, and watermark export in 1 click.
          </p>
        </div>

        {/* Quick Top Actions */}
        <div className="flex items-center gap-2 flex-wrap">
          <button
            type="button"
            onClick={handleLoadSampleVideo}
            className="flex items-center gap-1.5 px-3 py-2 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-xs rounded-xl shadow-md transition-all hover:scale-105"
            title="Generate a dynamic CSC Cyber Cafe motion video clip for instant testing"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>Load Sample Clip</span>
          </button>

          <label className="flex items-center gap-1.5 px-3.5 py-2 bg-slate-800 hover:bg-slate-750 text-slate-200 hover:text-white font-bold text-xs rounded-xl border border-slate-700 cursor-pointer transition-colors shadow">
            <Upload className="w-3.5 h-3.5 text-blue-400" />
            <span>Upload Video</span>
            <input type="file" accept="video/*" onChange={handleUploadVideo} className="hidden" />
          </label>

          <button
            type="button"
            onClick={handleCaptureSnapshot}
            className="flex items-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs rounded-xl border border-slate-700"
            title="Capture current video frame as high-res JPG"
          >
            <Camera className="w-3.5 h-3.5 text-emerald-400" />
            <span>Snapshot JPG</span>
          </button>

          <button
            type="button"
            onClick={handleExportVideo}
            disabled={isExporting}
            className="flex items-center gap-1.5 px-4 py-2 bg-gradient-to-r from-rose-600 via-pink-600 to-rose-500 hover:from-rose-500 hover:to-pink-500 text-white font-extrabold text-xs rounded-xl shadow-lg shadow-rose-600/30 transition-all hover:scale-105 disabled:opacity-50"
            title="Render and Download Final Video with all 5 layers"
          >
            <Download className="w-4 h-4 text-white" />
            <span>{isExporting ? `Exporting (${exportProgress}%)` : 'Export Video'}</span>
          </button>
        </div>
      </div>

      {/* Status Alert Banner */}
      {statusAlert && (
        <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-center justify-between animate-in fade-in">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
            <span>{statusAlert}</span>
          </div>
          <button onClick={() => setStatusAlert(null)} className="text-emerald-400 hover:text-white">✕</button>
        </div>
      )}

      {/* Export Progress Bar */}
      {isExporting && (
        <div className="bg-slate-900 border border-rose-500/40 p-3 rounded-xl space-y-2">
          <div className="flex justify-between text-xs text-rose-300 font-bold">
            <span>Rendering Multi-Layer Video at 30 FPS...</span>
            <span>{exportProgress}%</span>
          </div>
          <div className="w-full bg-slate-950 h-2 rounded-full overflow-hidden">
            <div 
              className="bg-gradient-to-r from-rose-500 to-indigo-500 h-full transition-all duration-200"
              style={{ width: `${exportProgress}%` }}
            />
          </div>
        </div>
      )}

      {/* MAIN DUAL-PANE WORKSPACE: LEFT PREVIEW (7 Cols) + RIGHT DECK (5 Cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-start">
        {/* LEFT: MONITOR PREVIEW & PLAYBACK CONTROLS (7 Columns) */}
        <div className="lg:col-span-7 bg-slate-950 border border-slate-800 rounded-3xl p-3 sm:p-4 shadow-2xl space-y-3 flex flex-col justify-between min-h-[500px]">
          {/* Top Monitor Status Bar */}
          <div className="flex items-center justify-between text-xs text-slate-400 pb-2 border-b border-slate-800">
            <div className="flex items-center gap-2 font-mono">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-pulse"></span>
              <span className="text-white font-bold">{videoFileName}</span>
              <span className="text-slate-600">•</span>
              <span className="text-sky-400 font-bold">{aspectRatio}</span>
            </div>

            <div className="flex items-center gap-1.5 font-mono text-[11px]">
              <span className="text-emerald-400 font-bold">{formatTime(currentTime)}</span>
              <span className="text-slate-600">/</span>
              <span>{formatTime(duration)}</span>
            </div>
          </div>

          {/* Central Composite Video Canvas */}
          <div className="relative flex-1 flex items-center justify-center p-2 overflow-hidden bg-slate-900/60 rounded-2xl border border-slate-800">
            <canvas
              ref={canvasRef}
              className="max-w-full max-h-[440px] w-auto h-auto rounded-lg shadow-2xl cursor-pointer"
              onClick={handleTogglePlay}
            />

            {/* Hidden HTML5 Video element used as raw stream source */}
            {videoSrc && (
              <video
                ref={videoRef}
                src={videoSrc}
                onLoadedMetadata={handleVideoLoadedMetadata}
                onEnded={() => {
                  if (isLooping) {
                    if (videoRef.current) videoRef.current.currentTime = inPoint;
                    if (audioRef.current) audioRef.current.currentTime = inPoint;
                  } else {
                    setIsPlaying(false);
                  }
                }}
                className="hidden"
                playsInline
              />
            )}
          </div>

          {/* Player Transport Bar */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-3 space-y-2.5 shadow-inner">
            {/* Scrubber Range Slider */}
            <div className="space-y-1">
              <div className="relative flex items-center">
                <input
                  type="range"
                  min="0"
                  max={duration || 10}
                  step="0.05"
                  value={currentTime}
                  onChange={(e) => handleSeek(Number(e.target.value))}
                  className="w-full accent-rose-500 h-2 bg-slate-800 rounded-lg cursor-pointer"
                />
              </div>

              {/* Trim Markers Indicators */}
              <div className="flex justify-between text-[10px] font-mono text-slate-500">
                <span className="text-sky-400">In: {formatTime(inPoint)}</span>
                <span className="text-white font-bold">{formatTime(currentTime)}</span>
                <span className="text-purple-400">Out: {formatTime(outPoint)}</span>
              </div>
            </div>

            {/* Transport Control Buttons */}
            <div className="flex items-center justify-between gap-2 flex-wrap">
              <div className="flex items-center gap-1.5">
                {/* Play / Pause */}
                <button
                  type="button"
                  onClick={handleTogglePlay}
                  className="w-10 h-10 rounded-xl bg-gradient-to-r from-rose-600 to-pink-600 hover:from-rose-500 hover:to-pink-500 text-white flex items-center justify-center shadow-lg shadow-rose-600/30 transition-transform active:scale-95"
                  title="Play / Pause (Spacebar)"
                >
                  {isPlaying ? <Pause className="w-5 h-5 fill-white" /> : <Play className="w-5 h-5 fill-white ml-0.5" />}
                </button>

                {/* Step -1s */}
                <button
                  type="button"
                  onClick={() => handleSeek(currentTime - 1)}
                  className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white"
                  title="Step Back 1s"
                >
                  <Rewind className="w-4 h-4" />
                </button>

                {/* Step +1s */}
                <button
                  type="button"
                  onClick={() => handleSeek(currentTime + 1)}
                  className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white"
                  title="Step Forward 1s"
                >
                  <FastForward className="w-4 h-4" />
                </button>

                {/* Trim In Button */}
                <button
                  type="button"
                  onClick={handleSetInPoint}
                  className="px-2.5 py-1.5 rounded-lg bg-sky-500/10 hover:bg-sky-500/20 text-sky-400 border border-sky-500/30 text-xs font-bold font-mono"
                  title="Set In-Point (Cut Start)"
                >
                  [ In
                </button>

                {/* Trim Out Button */}
                <button
                  type="button"
                  onClick={handleSetOutPoint}
                  className="px-2.5 py-1.5 rounded-lg bg-purple-500/10 hover:bg-purple-500/20 text-purple-400 border border-purple-500/30 text-xs font-bold font-mono"
                  title="Set Out-Point (Cut End)"
                >
                  Out ]
                </button>

                <button
                  type="button"
                  onClick={handleResetTrim}
                  className="p-1.5 text-slate-400 hover:text-white text-xs"
                  title="Reset Trim Range"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Speed & Audio controls */}
              <div className="flex items-center gap-2">
                {/* Speed selector */}
                <div className="flex items-center bg-slate-950 border border-slate-800 rounded-lg p-0.5 text-[10px] font-bold">
                  {[0.5, 1.0, 1.5, 2.0].map((s) => (
                    <button
                      key={s}
                      type="button"
                      onClick={() => handleSpeedChange(s)}
                      className={`px-2 py-1 rounded transition-colors ${
                        playbackSpeed === s ? 'bg-rose-600 text-white' : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      {s}x
                    </button>
                  ))}
                </div>

                {/* Volume toggle */}
                <button
                  type="button"
                  onClick={() => setIsMasterMuted(!isMasterMuted)}
                  className={`p-2 rounded-xl border text-xs ${
                    isMasterMuted
                      ? 'bg-rose-600/20 text-rose-400 border-rose-500/40'
                      : 'bg-slate-800 text-slate-300 border-slate-700'
                  }`}
                  title="Mute / Unmute"
                >
                  {isMasterMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* RIGHT: MULTI-LAYER TOOLS & ATTRIBUTES DECK (5 Columns) */}
        <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-3xl p-4 shadow-xl space-y-4">
          {/* Sub-Deck Navigation Tabs */}
          <div className="grid grid-cols-3 sm:grid-cols-6 gap-1 bg-slate-950 p-1.5 rounded-2xl border border-slate-800 text-[11px] font-bold">
            {[
              { id: 'timeline', label: 'Timeline', icon: Layers },
              { id: 'crop', label: 'Canvas', icon: SplitSquareVertical },
              { id: 'color', label: 'Color', icon: Sliders },
              { id: 'text', label: 'Titles', icon: Type },
              { id: 'overlay', label: 'Overlay', icon: ImageIcon },
              { id: 'audio', label: 'Audio', icon: Music }
            ].map((tab) => {
              const Icon = tab.icon;
              const isActive = activeToolTab === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setActiveToolTab(tab.id as any)}
                  className={`py-2 px-1 rounded-xl flex flex-col items-center justify-center gap-1 transition-all ${
                    isActive
                      ? 'bg-rose-600 text-white shadow-md shadow-rose-600/30'
                      : 'text-slate-400 hover:text-white hover:bg-slate-900'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span className="truncate">{tab.label}</span>
                </button>
              );
            })}
          </div>

          {/* TAB 1: MULTI-LAYER TIMELINE TRACKS OVERVIEW */}
          {activeToolTab === 'timeline' && (
            <div className="space-y-3 animate-in fade-in text-xs">
              <div className="flex items-center justify-between pb-1 border-b border-slate-800">
                <span className="font-extrabold text-white uppercase tracking-wider flex items-center gap-1.5">
                  <Layers className="w-4 h-4 text-rose-500" />
                  <span>5-Layer Timeline Tracks</span>
                </span>
                <span className="text-[10px] text-slate-400 font-mono">Synchronized</span>
              </div>

              {/* Track 1: Main Video */}
              <div className="bg-slate-950 p-3 rounded-2xl border border-slate-800 space-y-1.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-blue-500"></span>
                    <strong className="text-white">Track 1: Main Video</strong>
                  </div>
                  <span className="text-[10px] font-mono text-sky-400">{formatTime(duration)}</span>
                </div>
                <div className="text-[11px] text-slate-400 flex items-center justify-between">
                  <span>Clip: {videoFileName}</span>
                  <span className="text-emerald-400 font-bold">Active</span>
                </div>
              </div>

              {/* Track 2: Overlay B-Roll */}
              <div className="bg-slate-950 p-3 rounded-2xl border border-slate-800 space-y-1.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-purple-500"></span>
                    <strong className="text-white">Track 2: Picture-in-Picture Overlay</strong>
                  </div>
                  <label className="text-[10px] text-purple-400 hover:underline cursor-pointer font-bold">
                    + Add Image
                    <input type="file" accept="image/*" onChange={handleUploadOverlayImage} className="hidden" />
                  </label>
                </div>
                <div className="text-[11px] text-slate-400 flex items-center justify-between">
                  <span>{overlayImageSrc ? 'Image Overlay Active' : 'No Overlay Attached'}</span>
                  {overlayImageSrc && (
                    <button onClick={() => setOverlayImageSrc(null)} className="text-rose-400 hover:underline">
                      Remove
                    </button>
                  )}
                </div>
              </div>

              {/* Track 3: Audio / Music */}
              <div className="bg-slate-950 p-3 rounded-2xl border border-slate-800 space-y-1.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span>
                    <strong className="text-white">Track 3: Background Audio</strong>
                  </div>
                  <label className="text-[10px] text-amber-400 hover:underline cursor-pointer font-bold">
                    + Add Audio
                    <input type="file" accept="audio/*" onChange={handleUploadMusic} className="hidden" />
                  </label>
                </div>
                <div className="text-[11px] text-slate-400 flex items-center justify-between">
                  <span>{musicSrc ? 'Background Music Active' : 'Default / Muted'}</span>
                  {musicSrc && (
                    <button onClick={() => setMusicSrc(null)} className="text-rose-400 hover:underline">
                      Remove
                    </button>
                  )}
                </div>
              </div>

              {/* Track 4: Lower-Thirds & Titles */}
              <div className="bg-slate-950 p-3 rounded-2xl border border-slate-800 space-y-1.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
                    <strong className="text-white">Track 4: Animated Titles & Subtitles</strong>
                  </div>
                  <span className="text-[10px] text-emerald-400 font-mono font-bold">
                    {textOverlays.length} Text Blocks
                  </span>
                </div>
                <div className="text-[11px] text-slate-400 truncate">
                  "{textOverlays[0]?.text || 'No Text'}"
                </div>
              </div>

              {/* Track 5: Cyber Cafe Watermark */}
              <div className="bg-slate-950 p-3 rounded-2xl border border-slate-800 space-y-1.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-rose-500"></span>
                    <strong className="text-white">Track 5: Digital CSC Shop Watermark</strong>
                  </div>
                  <input
                    type="checkbox"
                    checked={showWatermark}
                    onChange={(e) => setShowWatermark(e.target.checked)}
                    className="accent-rose-500 rounded"
                  />
                </div>
                <div className="text-[11px] text-slate-400 truncate">
                  {showWatermark ? watermarkText : 'Disabled'}
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: CANVAS RATIO, GEOMETRY & ROTATION */}
          {activeToolTab === 'crop' && (
            <div className="space-y-4 animate-in fade-in text-xs">
              <div className="pb-1 border-b border-slate-800 font-extrabold text-white uppercase tracking-wider">
                Aspect Ratio & Framing Presets
              </div>

              {/* Ratio presets */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {[
                  { id: '16:9', label: '16:9', desc: 'YouTube / PC' },
                  { id: '9:16', label: '9:16', desc: 'Reels / Shorts' },
                  { id: '1:1', label: '1:1', desc: 'Instagram Post' },
                  { id: '4:5', label: '4:5', desc: 'Portrait Feed' }
                ].map((r) => (
                  <button
                    key={r.id}
                    type="button"
                    onClick={() => setAspectRatio(r.id as AspectRatio)}
                    className={`p-2.5 rounded-xl border text-center transition-all ${
                      aspectRatio === r.id
                        ? 'bg-rose-600/20 border-rose-500 text-white font-extrabold ring-1 ring-rose-500/40'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    <div className="font-mono text-sm">{r.label}</div>
                    <div className="text-[10px] text-slate-400">{r.desc}</div>
                  </button>
                ))}
              </div>

              {/* Rotation & Flip Controls */}
              <div className="space-y-2 pt-2">
                <span className="text-slate-400 font-bold block">Orientation & Mirroring:</span>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setRotation((prev) => (prev + 90) % 360)}
                    className="p-2 rounded-xl bg-slate-950 border border-slate-800 text-slate-200 hover:text-white flex items-center justify-center gap-1.5 font-bold"
                  >
                    <RotateCw className="w-3.5 h-3.5 text-blue-400" />
                    <span>Rotate 90°</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setFlipH(!flipH)}
                    className={`p-2 rounded-xl border flex items-center justify-center gap-1.5 font-bold ${
                      flipH ? 'bg-sky-600 text-white border-sky-400' : 'bg-slate-950 border-slate-800 text-slate-400'
                    }`}
                  >
                    <FlipHorizontal className="w-3.5 h-3.5" />
                    <span>Flip H</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setFlipV(!flipV)}
                    className={`p-2 rounded-xl border flex items-center justify-center gap-1.5 font-bold ${
                      flipV ? 'bg-sky-600 text-white border-sky-400' : 'bg-slate-950 border-slate-800 text-slate-400'
                    }`}
                  >
                    <FlipVertical className="w-3.5 h-3.5" />
                    <span>Flip V</span>
                  </button>
                </div>
              </div>

              {/* Frame Zoom */}
              <div className="space-y-1 pt-1">
                <div className="flex justify-between text-slate-400 font-semibold">
                  <span>Frame Scale / Zoom</span>
                  <span className="font-mono text-white">{Math.round(zoomLevel * 100)}%</span>
                </div>
                <input
                  type="range"
                  min="0.5"
                  max="2.0"
                  step="0.05"
                  value={zoomLevel}
                  onChange={(e) => setZoomLevel(Number(e.target.value))}
                  className="w-full accent-rose-500 h-1.5 bg-slate-800 rounded cursor-pointer"
                />
              </div>
            </div>
          )}

          {/* TAB 3: COLOR GRADING & CINEMATIC FILTERS */}
          {activeToolTab === 'color' && (
            <div className="space-y-3 animate-in fade-in text-xs">
              <div className="flex items-center justify-between pb-1 border-b border-slate-800 font-extrabold text-white uppercase tracking-wider">
                <span>Color Grading & Cinematic Filters</span>
                <button
                  onClick={() => {
                    setBrightness(0);
                    setContrast(0);
                    setSaturation(0);
                    setWarmth(0);
                    setFilterPreset('normal');
                  }}
                  className="text-[10px] text-slate-400 hover:text-white"
                >
                  Reset
                </button>
              </div>

              {/* Presets */}
              <div className="grid grid-cols-3 gap-1.5">
                {[
                  { id: 'normal', label: 'Original' },
                  { id: 'cinematic', label: '🎬 35mm Film' },
                  { id: 'vintage', label: '🎞️ Vintage Sepia' },
                  { id: 'neon', label: '🔮 Cyber Neon' },
                  { id: 'bw', label: '🖤 Noir B&W' }
                ].map((p) => (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => setFilterPreset(p.id)}
                    className={`py-1.5 px-2 rounded-lg border font-bold text-center transition-all ${
                      filterPreset === p.id
                        ? 'bg-rose-600 text-white border-rose-400 shadow'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    {p.label}
                  </button>
                ))}
              </div>

              {/* Brightness */}
              <div className="space-y-1">
                <div className="flex justify-between text-slate-300 font-semibold">
                  <span className="flex items-center gap-1 text-amber-300"><Sun className="w-3.5 h-3.5" /> Brightness</span>
                  <span className="font-mono text-white">{brightness > 0 ? `+${brightness}` : brightness}%</span>
                </div>
                <input
                  type="range"
                  min="-40"
                  max="40"
                  value={brightness}
                  onChange={(e) => setBrightness(Number(e.target.value))}
                  className="w-full accent-amber-500 h-1.5 bg-slate-800 rounded cursor-pointer"
                />
              </div>

              {/* Contrast */}
              <div className="space-y-1">
                <div className="flex justify-between text-slate-300 font-semibold">
                  <span className="flex items-center gap-1 text-sky-300"><Contrast className="w-3.5 h-3.5" /> Contrast</span>
                  <span className="font-mono text-white">{contrast > 0 ? `+${contrast}` : contrast}%</span>
                </div>
                <input
                  type="range"
                  min="-40"
                  max="40"
                  value={contrast}
                  onChange={(e) => setContrast(Number(e.target.value))}
                  className="w-full accent-sky-500 h-1.5 bg-slate-800 rounded cursor-pointer"
                />
              </div>

              {/* Saturation */}
              <div className="space-y-1">
                <div className="flex justify-between text-slate-300 font-semibold">
                  <span className="flex items-center gap-1 text-pink-300"><Droplets className="w-3.5 h-3.5" /> Saturation</span>
                  <span className="font-mono text-white">{saturation > 0 ? `+${saturation}` : saturation}%</span>
                </div>
                <input
                  type="range"
                  min="-50"
                  max="50"
                  value={saturation}
                  onChange={(e) => setSaturation(Number(e.target.value))}
                  className="w-full accent-pink-500 h-1.5 bg-slate-800 rounded cursor-pointer"
                />
              </div>

              {/* Warmth */}
              <div className="space-y-1">
                <div className="flex justify-between text-slate-300 font-semibold">
                  <span className="flex items-center gap-1 text-orange-300"><Flame className="w-3.5 h-3.5" /> Warmth / Color Cast</span>
                  <span className="font-mono text-white">{warmth > 0 ? `+${warmth}` : warmth}</span>
                </div>
                <input
                  type="range"
                  min="-40"
                  max="40"
                  value={warmth}
                  onChange={(e) => setWarmth(Number(e.target.value))}
                  className="w-full accent-orange-500 h-1.5 bg-slate-800 rounded cursor-pointer"
                />
              </div>
            </div>
          )}

          {/* TAB 4: TITLES, LOWER-THIRDS & CAPTIONS */}
          {activeToolTab === 'text' && (
            <div className="space-y-3 animate-in fade-in text-xs">
              <div className="flex items-center justify-between pb-1 border-b border-slate-800 font-extrabold text-white uppercase tracking-wider">
                <span>Animated Titles & Lower-Thirds</span>
              </div>

              {/* Text Input */}
              <div className="space-y-1">
                <label className="text-slate-400 font-semibold">Overlay Text Content:</label>
                <input
                  type="text"
                  value={textOverlays[0]?.text || ''}
                  onChange={(e) => {
                    const val = e.target.value;
                    setTextOverlays((prev) => [
                      {
                        ...prev[0],
                        text: val
                      }
                    ]);
                  }}
                  placeholder="Enter shop name, offer, or title..."
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white font-bold"
                />
              </div>

              {/* Position */}
              <div className="space-y-1">
                <label className="text-slate-400 font-semibold">Screen Position:</label>
                <div className="grid grid-cols-3 gap-2">
                  {['top', 'center', 'bottom'].map((pos) => (
                    <button
                      key={pos}
                      type="button"
                      onClick={() => {
                        setTextOverlays((prev) => [
                          { ...prev[0], position: pos as any }
                        ]);
                      }}
                      className={`py-1.5 rounded-lg border font-bold capitalize ${
                        textOverlays[0]?.position === pos
                          ? 'bg-rose-600 text-white border-rose-400 shadow'
                          : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                      }`}
                    >
                      {pos}
                    </button>
                  ))}
                </div>
              </div>

              {/* Style Presets */}
              <div className="space-y-1">
                <label className="text-slate-400 font-semibold">Graphic Style:</label>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { id: 'lower_third', label: 'Broadcast Lower-Third' },
                    { id: 'neon', label: 'Cyber Glow' },
                    { id: 'banner', label: 'Dark Solid Banner' },
                    { id: 'clean', label: 'Minimalist Clean' }
                  ].map((st) => (
                    <button
                      key={st.id}
                      type="button"
                      onClick={() => {
                        setTextOverlays((prev) => [
                          { ...prev[0], style: st.id as any }
                        ]);
                      }}
                      className={`p-2 rounded-lg border text-left font-bold ${
                        textOverlays[0]?.style === st.id
                          ? 'bg-purple-600/20 text-purple-300 border-purple-500'
                          : 'bg-slate-950 border-slate-800 text-slate-400'
                      }`}
                    >
                      {st.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Font Size */}
              <div className="space-y-1">
                <div className="flex justify-between text-slate-400">
                  <span>Font Size</span>
                  <span className="font-mono text-white">{textOverlays[0]?.fontSize || 28}px</span>
                </div>
                <input
                  type="range"
                  min="16"
                  max="60"
                  value={textOverlays[0]?.fontSize || 28}
                  onChange={(e) => {
                    const sz = Number(e.target.value);
                    setTextOverlays((prev) => [{ ...prev[0], fontSize: sz }]);
                  }}
                  className="w-full accent-rose-500 h-1.5 bg-slate-800 rounded cursor-pointer"
                />
              </div>
            </div>
          )}

          {/* TAB 5: OVERLAY B-ROLL & WATERMARK */}
          {activeToolTab === 'overlay' && (
            <div className="space-y-4 animate-in fade-in text-xs">
              <div className="pb-1 border-b border-slate-800 font-extrabold text-white uppercase tracking-wider">
                Picture-in-Picture & Watermark
              </div>

              {/* Watermark Section */}
              <div className="bg-slate-950 p-3 rounded-2xl border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <strong className="text-white">Shop Brand Stamp / Watermark:</strong>
                  <input
                    type="checkbox"
                    checked={showWatermark}
                    onChange={(e) => setShowWatermark(e.target.checked)}
                    className="accent-rose-500 rounded"
                  />
                </div>
                <input
                  type="text"
                  value={watermarkText}
                  onChange={(e) => setWatermarkText(e.target.value)}
                  placeholder="e.g. Muzammil Online Service - 9561460313"
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white font-bold"
                />

                <div className="grid grid-cols-4 gap-1.5 pt-1 text-[10px]">
                  {['top-left', 'top-right', 'bottom-left', 'bottom-right'].map((pos) => (
                    <button
                      key={pos}
                      type="button"
                      onClick={() => setWatermarkPos(pos as any)}
                      className={`py-1 rounded border capitalize ${
                        watermarkPos === pos
                          ? 'bg-rose-600 text-white border-rose-400'
                          : 'bg-slate-900 border-slate-800 text-slate-400'
                      }`}
                    >
                      {pos.replace('-', ' ')}
                    </button>
                  ))}
                </div>
              </div>

              {/* Overlay Image Controls */}
              <div className="bg-slate-950 p-3 rounded-2xl border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <strong className="text-white">Picture-in-Picture (Track 2):</strong>
                  <label className="text-[10px] text-purple-400 font-bold hover:underline cursor-pointer">
                    Upload
                    <input type="file" accept="image/*" onChange={handleUploadOverlayImage} className="hidden" />
                  </label>
                </div>

                {overlayImageSrc ? (
                  <div className="space-y-2 pt-1">
                    <div className="flex justify-between text-slate-400">
                      <span>Overlay Scale</span>
                      <span className="font-mono text-white">{Math.round(overlayScale * 100)}%</span>
                    </div>
                    <input
                      type="range"
                      min="0.1"
                      max="0.6"
                      step="0.05"
                      value={overlayScale}
                      onChange={(e) => setOverlayScale(Number(e.target.value))}
                      className="w-full accent-purple-500 h-1.5 bg-slate-800 rounded cursor-pointer"
                    />

                    <div className="flex justify-between text-slate-400">
                      <span>Opacity</span>
                      <span className="font-mono text-white">{Math.round(overlayOpacity * 100)}%</span>
                    </div>
                    <input
                      type="range"
                      min="0.2"
                      max="1.0"
                      step="0.05"
                      value={overlayOpacity}
                      onChange={(e) => setOverlayOpacity(Number(e.target.value))}
                      className="w-full accent-purple-500 h-1.5 bg-slate-800 rounded cursor-pointer"
                    />
                  </div>
                ) : (
                  <p className="text-[11px] text-slate-500">
                    No image overlay attached. Click Upload to insert a logo or photo inside the video.
                  </p>
                )}
              </div>
            </div>
          )}

          {/* TAB 6: AUDIO MIXING & SOUND */}
          {activeToolTab === 'audio' && (
            <div className="space-y-4 animate-in fade-in text-xs">
              <div className="pb-1 border-b border-slate-800 font-extrabold text-white uppercase tracking-wider">
                Audio Mixing & Soundtracks
              </div>

              {/* Master Video Volume */}
              <div className="bg-slate-950 p-3 rounded-2xl border border-slate-800 space-y-2">
                <div className="flex justify-between text-slate-300 font-semibold">
                  <span className="flex items-center gap-1.5"><Volume2 className="w-4 h-4 text-blue-400" /> Main Video Audio</span>
                  <span className="font-mono text-white">{masterVolume}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="200"
                  value={masterVolume}
                  onChange={(e) => {
                    const vol = Number(e.target.value);
                    setMasterVolume(vol);
                    if (videoRef.current) videoRef.current.volume = Math.min(1.0, vol / 100);
                  }}
                  className="w-full accent-blue-500 h-1.5 bg-slate-800 rounded cursor-pointer"
                />
              </div>

              {/* Background Music Volume */}
              <div className="bg-slate-950 p-3 rounded-2xl border border-slate-800 space-y-2">
                <div className="flex justify-between text-slate-300 font-semibold">
                  <span className="flex items-center gap-1.5"><Music className="w-4 h-4 text-amber-400" /> Track 3: BGM Volume</span>
                  <span className="font-mono text-white">{musicVolume}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={musicVolume}
                  onChange={(e) => {
                    const vol = Number(e.target.value);
                    setMusicVolume(vol);
                    if (audioRef.current) audioRef.current.volume = vol / 100;
                  }}
                  className="w-full accent-amber-500 h-1.5 bg-slate-800 rounded cursor-pointer"
                />
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
