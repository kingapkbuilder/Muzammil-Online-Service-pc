import React, { useState, useRef, useEffect } from 'react';
import { 
  Upload, 
  Printer, 
  Download, 
  RotateCw, 
  ZoomIn, 
  ZoomOut, 
  Move, 
  Sparkles, 
  RefreshCw, 
  Check, 
  Scissors, 
  Layers, 
  ArrowUpDown, 
  Sun, 
  Contrast, 
  HelpCircle,
  FileText,
  Square,
  Sliders,
  X,
  Droplets,
  Flame,
  CheckCircle2
} from 'lucide-react';
import { jsPDF } from 'jspdf';
import { addDownloadRecord } from '../utils/storage';
import { printImageSheet } from '../utils/printer';

interface SectionBox {
  x: number; // 0..1 relative to card width
  y: number; // 0..1 relative to card height
  w: number; // 0..1 relative to card width
  h: number; // 0..1 relative to card height
}

export const PvcStudioView: React.FC = () => {
  // Canvas references
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Card images (Data URLs or Image objects)
  const [card1Src, setCard1Src] = useState<string | null>(null);
  const [card2Src, setCard2Src] = useState<string | null>(null);

  // Active editing card: 'card1' | 'card2'
  const [activeCard, setActiveCard] = useState<'card1' | 'card2'>('card1');

  // Adjustments per card
  const [card1Config, setCard1Config] = useState({
    x: 0,
    y: 0,
    scale: 1.0,
    rotation: 0
  });

  const [card2Config, setCard2Config] = useState({
    x: 0,
    y: 0,
    scale: 1.0,
    rotation: 0
  });

  // Global card adjustments
  const [brightness, setBrightness] = useState<number>(0);
  const [contrast, setContrast] = useState<number>(0);
  const [showCutMarks, setShowCutMarks] = useState<boolean>(true);
  const [roundedCorners, setRoundedCorners] = useState<boolean>(true);
  const [borderStroke, setBorderStroke] = useState<boolean>(true);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [printAlert, setPrintAlert] = useState<string | null>(null);

  // SECTION SELECTION TOOL & LOCAL COLOR GRADING STATE
  const [interactionMode, setInteractionMode] = useState<'move' | 'section_select'>('move');
  const [card1Section, setCard1Section] = useState<SectionBox | null>(null);
  const [card2Section, setCard2Section] = useState<SectionBox | null>(null);
  
  // Local Color Grading parameters for the selected section
  const [sectionBrightness, setSectionBrightness] = useState<number>(15);
  const [sectionContrast, setSectionContrast] = useState<number>(10);
  const [sectionSaturation, setSectionSaturation] = useState<number>(0);
  const [sectionWarmth, setSectionWarmth] = useState<number>(0);
  const [sectionFeather, setSectionFeather] = useState<number>(6);

  // Interactive mouse dragging & box selection state
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [dragCard, setDragCard] = useState<'card1' | 'card2' | null>(null);
  const [dragStart, setDragStart] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isSelectingBox, setIsSelectingBox] = useState<boolean>(false);
  const [selectionStartNorm, setSelectionStartNorm] = useState<{ x: number; y: number } | null>(null);

  // 300 DPI constants for 4x6 inch paper:
  // 4 inches = 1200 px, 6 inches = 1800 px
  const CANVAS_WIDTH = 1200;
  const CANVAS_HEIGHT = 1800;

  // Exact 5.5 cm × 8.5 cm (85 mm × 55 mm) dimensions at 300 DPI:
  // 1 inch = 2.54 cm -> 300 px / 2.54 cm = 118.1102 px per cm
  // Width: 8.5 cm * 118.1102 ≈ 1004 px
  // Height: 5.5 cm * 118.1102 ≈ 650 px
  const CARD_WIDTH = 1004;
  const CARD_HEIGHT = 650;

  // Position on 4x6 inch Portrait Sheet (1200 x 1800 px):
  // X Center: 1200 / 2 = 600 px (98 px margin on left and right = ~8.3 mm)
  // Top Card Center (Front): Y = 465 px
  // Center Cut Guideline: Y = 900 px
  // Bottom Card Center (Back): Y = 1335 px
  const CARD_CENTER_X = 600;
  const CARD1_DEFAULT_Y = 465;
  const CARD2_DEFAULT_Y = 1335;

  // Pre-load images for canvas drawing
  const card1ImgRef = useRef<HTMLImageElement | null>(null);
  const card2ImgRef = useRef<HTMLImageElement | null>(null);

  // Load card 1 image
  useEffect(() => {
    if (card1Src) {
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.onload = () => {
        card1ImgRef.current = img;
        renderCanvas();
      };
      img.src = card1Src;
    } else {
      card1ImgRef.current = null;
      renderCanvas();
    }
  }, [card1Src]);

  // Load card 2 image
  useEffect(() => {
    if (card2Src) {
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.onload = () => {
        card2ImgRef.current = img;
        renderCanvas();
      };
      img.src = card2Src;
    } else {
      card2ImgRef.current = null;
      renderCanvas();
    }
  }, [card2Src]);

  // Global Keyboard shortcuts listener (Ctrl+P, Ctrl+S, Ctrl+J)
  useEffect(() => {
    const handleGlobalPrint = () => handleDirectPrint();
    const handleGlobalPdf = () => handleDownloadPDF();
    const handleGlobalJpg = () => handleDownloadJPG();

    window.addEventListener('app-direct-print', handleGlobalPrint);
    window.addEventListener('app-direct-pdf', handleGlobalPdf);
    window.addEventListener('app-direct-jpg', handleGlobalJpg);

    return () => {
      window.removeEventListener('app-direct-print', handleGlobalPrint);
      window.removeEventListener('app-direct-pdf', handleGlobalPdf);
      window.removeEventListener('app-direct-jpg', handleGlobalJpg);
    };
  });

  // Re-render canvas whenever configs or section adjustments change
  useEffect(() => {
    renderCanvas();
  }, [
    card1Config, 
    card2Config, 
    brightness, 
    contrast, 
    showCutMarks, 
    roundedCorners, 
    borderStroke, 
    card1Section, 
    card2Section, 
    sectionBrightness, 
    sectionContrast, 
    sectionSaturation, 
    sectionWarmth, 
    sectionFeather,
    interactionMode,
    activeCard
  ]);

  // Main Render Function to Canvas @ 300 DPI
  const renderCanvas = (hideMarquee: boolean = false) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear background to pure white (for photo paper print)
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

    // Global filter string
    const globalFilterStr = `brightness(${100 + brightness}%) contrast(${100 + contrast}%)`;

    // 1. Draw Card 1 (Top / Front)
    drawSingleCard(
      ctx,
      card1ImgRef.current,
      CARD_CENTER_X + card1Config.x,
      CARD1_DEFAULT_Y + card1Config.y,
      card1Config.scale,
      card1Config.rotation,
      'Card 1 (Front)',
      globalFilterStr,
      card1Section,
      activeCard === 'card1',
      hideMarquee
    );

    // 2. Draw Card 2 (Bottom / Back)
    drawSingleCard(
      ctx,
      card2ImgRef.current,
      CARD_CENTER_X + card2Config.x,
      CARD2_DEFAULT_Y + card2Config.y,
      card2Config.scale,
      card2Config.rotation,
      'Card 2 (Back)',
      globalFilterStr,
      card2Section,
      activeCard === 'card2',
      hideMarquee
    );

    // 3. Draw Cut Guide Line between cards
    if (showCutMarks) {
      ctx.save();
      ctx.strokeStyle = '#94a3b8';
      ctx.lineWidth = 2;
      ctx.setLineDash([8, 8]);

      // Horizontal center cut mark (exact center of 4x6 inch sheet)
      const midY = 900;
      ctx.beginPath();
      ctx.moveTo(40, midY);
      ctx.lineTo(CANVAS_WIDTH - 40, midY);
      ctx.stroke();

      // Scissor indicator text
      ctx.setLineDash([]);
      ctx.fillStyle = '#64748b';
      ctx.font = 'bold 20px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('✂ Cut Here (Fold / Separate • 5.5 cm × 8.5 cm Each)', CANVAS_WIDTH / 2, midY - 12);

      // Sheet boundary crop corners
      drawCropMarks(ctx, 40, 40);
      drawCropMarks(ctx, CANVAS_WIDTH - 40, 40);
      drawCropMarks(ctx, 40, CANVAS_HEIGHT - 40);
      drawCropMarks(ctx, CANVAS_WIDTH - 40, CANVAS_HEIGHT - 40);

      ctx.restore();
    }
  };

  const drawCropMarks = (ctx: CanvasRenderingContext2D, x: number, y: number) => {
    ctx.strokeStyle = '#cbd5e1';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(x - 20, y);
    ctx.lineTo(x + 20, y);
    ctx.moveTo(x, y - 20);
    ctx.lineTo(x, y + 20);
    ctx.stroke();
  };

  const drawSingleCard = (
    ctx: CanvasRenderingContext2D,
    img: HTMLImageElement | null,
    centerX: number,
    centerY: number,
    scale: number,
    rotation: number,
    placeholderLabel: string,
    filter: string,
    section: SectionBox | null,
    isActiveCard: boolean,
    hideMarquee: boolean = false
  ) => {
    const w = CARD_WIDTH;
    const h = CARD_HEIGHT;
    const left = centerX - w / 2;
    const top = centerY - h / 2;

    ctx.save();

    // Clip to rounded CR-80 card standard boundary (3.18mm radius = ~35px @ 300 DPI)
    const radius = roundedCorners ? 35 : 0;
    ctx.beginPath();
    ctx.roundRect(left, top, w, h, radius);
    ctx.clip();

    if (img) {
      // 1. Draw base card image
      ctx.save();
      ctx.filter = filter;
      ctx.translate(centerX, centerY);
      ctx.rotate((rotation * Math.PI) / 180);
      ctx.scale(scale, scale);
      ctx.drawImage(img, -w / 2, -h / 2, w, h);
      ctx.restore();

      // 2. Draw Local Section Color Grading if a section is defined on this card
      if (section && section.w > 0.01 && section.h > 0.01) {
        ctx.save();

        // Calculate section box in canvas pixels
        const secX = left + section.x * w;
        const secY = top + section.y * h;
        const secW = section.w * w;
        const secH = section.h * h;

        // Clip to the selected section box with optional feathering
        ctx.save();
        ctx.beginPath();
        ctx.rect(secX, secY, secW, secH);
        ctx.clip();

        // Local filter string
        const effBright = 100 + brightness + sectionBrightness;
        const effCont = 100 + contrast + sectionContrast;
        const effSat = 100 + sectionSaturation;
        ctx.filter = `brightness(${effBright}%) contrast(${effCont}%) saturate(${effSat}%)`;

        // Redraw image inside the clipped section with the enhanced color grading
        ctx.translate(centerX, centerY);
        ctx.rotate((rotation * Math.PI) / 180);
        ctx.scale(scale, scale);
        ctx.drawImage(img, -w / 2, -h / 2, w, h);
        ctx.restore();

        // Apply warmth overlay to the section if set
        if (sectionWarmth !== 0) {
          ctx.save();
          ctx.beginPath();
          ctx.rect(secX, secY, secW, secH);
          ctx.clip();
          ctx.globalCompositeOperation = 'color';
          ctx.fillStyle = sectionWarmth > 0 
            ? `rgba(255, 170, 70, ${Math.min(0.4, (sectionWarmth / 100) * 0.5)})`
            : `rgba(70, 160, 255, ${Math.min(0.4, (Math.abs(sectionWarmth) / 100) * 0.5)})`;
          ctx.fillRect(secX, secY, secW, secH);
          ctx.restore();
        }

        // Draw animated/high-visibility selection dashed marquee border only in screen UI mode
        if (!hideMarquee) {
          ctx.save();
          ctx.strokeStyle = isActiveCard ? '#06b6d4' : '#64748b';
          ctx.lineWidth = 3;
          ctx.setLineDash([8, 6]);
          ctx.strokeRect(secX, secY, secW, secH);

          // Selection Tag Badge
          ctx.fillStyle = isActiveCard ? 'rgba(6, 182, 212, 0.9)' : 'rgba(100, 116, 139, 0.8)';
          ctx.fillRect(secX, Math.max(top, secY - 24), 160, 22);
          ctx.fillStyle = '#ffffff';
          ctx.font = 'bold 12px sans-serif';
          ctx.fillText(`🎯 Section (${sectionBrightness > 0 ? '+' : ''}${sectionBrightness}B / ${sectionContrast > 0 ? '+' : ''}${sectionContrast}C)`, secX + 6, Math.max(top, secY - 24) + 16);
          ctx.restore();
        }

        ctx.restore();
      }
    } else {
      // Empty placeholder slot
      ctx.fillStyle = '#f8fafc';
      ctx.fill();

      ctx.strokeStyle = '#cbd5e1';
      ctx.lineWidth = 4;
      ctx.setLineDash([12, 8]);
      ctx.stroke();

      // Placeholder text
      ctx.fillStyle = '#64748b';
      ctx.font = 'bold 36px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(placeholderLabel, centerX, centerY - 20);
      ctx.font = '24px sans-serif';
      ctx.fillStyle = '#94a3b8';
      ctx.fillText('Drop image or PDF to place here', centerX, centerY + 30);
      ctx.fillText('Official Size: 5.5 cm × 8.5 cm (85 mm × 55 mm)', centerX, centerY + 70);
    }

    // Border line around card
    if (borderStroke) {
      ctx.beginPath();
      ctx.roundRect(left, top, w, h, radius);
      ctx.strokeStyle = (!hideMarquee && isActiveCard && interactionMode === 'section_select') ? '#38bdf8' : '#1e293b';
      ctx.lineWidth = (!hideMarquee && isActiveCard && interactionMode === 'section_select') ? 3 : 2;
      ctx.setLineDash([]);
      ctx.stroke();
    }

    ctx.restore();
  };

  // Convert click on canvas to card-normalized coordinate (0..1)
  const getCardNormalizedCoords = (canvasX: number, canvasY: number, targetCard: 'card1' | 'card2') => {
    const centerX = CARD_CENTER_X + (targetCard === 'card1' ? card1Config.x : card2Config.x);
    const centerY = (targetCard === 'card1' ? CARD1_DEFAULT_Y : CARD2_DEFAULT_Y) + (targetCard === 'card1' ? card1Config.y : card2Config.y);
    const left = centerX - CARD_WIDTH / 2;
    const top = centerY - CARD_HEIGHT / 2;

    const normX = (canvasX - left) / CARD_WIDTH;
    const normY = (canvasY - top) / CARD_HEIGHT;

    return {
      normX,
      normY,
      isInside: normX >= 0 && normX <= 1 && normY >= 0 && normY <= 1
    };
  };

  // Upload handler for Card 1 or Card 2
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>, target: 'card1' | 'card2') => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const result = event.target?.result as string;
      if (target === 'card1') {
        setCard1Src(result);
        setActiveCard('card1');
      } else {
        setCard2Src(result);
        setActiveCard('card2');
      }
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  // Swap Front & Back cards
  const handleSwapCards = () => {
    const tempSrc = card1Src;
    setCard1Src(card2Src);
    setCard2Src(tempSrc);

    const tempCfg = { ...card1Config };
    setCard1Config({ ...card2Config });
    setCard2Config(tempCfg);

    const tempSec = card1Section;
    setCard1Section(card2Section);
    setCard2Section(tempSec);
  };

  // Quick Preset Selection on active card
  const handleApplyPresetSection = (preset: 'photo' | 'details' | 'qr' | 'signature') => {
    let box: SectionBox;
    switch (preset) {
      case 'photo':
        // Standard ID photo region on citizen cards (top-left)
        box = { x: 0.04, y: 0.18, w: 0.34, h: 0.64 };
        break;
      case 'details':
        // Name, address, DOB text region (center-right)
        box = { x: 0.40, y: 0.18, w: 0.56, h: 0.68 };
        break;
      case 'qr':
        // QR Code region (bottom or right)
        box = { x: 0.62, y: 0.18, w: 0.34, h: 0.64 };
        break;
      case 'signature':
        // Signature box
        box = { x: 0.04, y: 0.68, w: 0.42, h: 0.28 };
        break;
    }

    if (activeCard === 'card1') {
      setCard1Section(box);
    } else {
      setCard2Section(box);
    }
    setInteractionMode('section_select');
  };

  // Bake Section Color Grading directly into the Card image
  const handleBakeSectionGrading = () => {
    const targetSrc = activeCard === 'card1' ? card1Src : card2Src;
    const targetSection = activeCard === 'card1' ? card1Section : card2Section;
    if (!targetSrc || !targetSection) return;

    setIsProcessing(true);

    try {
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.onload = () => {
        const offCanvas = document.createElement('canvas');
        offCanvas.width = img.width;
        offCanvas.height = img.height;
        const ctx = offCanvas.getContext('2d');
        if (!ctx) return;

        // 1. Draw original base
        ctx.drawImage(img, 0, 0);

        // 2. Draw graded section on top
        const secX = targetSection.x * img.width;
        const secY = targetSection.y * img.height;
        const secW = targetSection.w * img.width;
        const secH = targetSection.h * img.height;

        ctx.save();
        ctx.beginPath();
        ctx.rect(secX, secY, secW, secH);
        ctx.clip();

        const effBright = 100 + sectionBrightness;
        const effCont = 100 + sectionContrast;
        const effSat = 100 + sectionSaturation;
        ctx.filter = `brightness(${effBright}%) contrast(${effCont}%) saturate(${effSat}%)`;
        ctx.drawImage(img, 0, 0);

        if (sectionWarmth !== 0) {
          ctx.globalCompositeOperation = 'color';
          ctx.fillStyle = sectionWarmth > 0 
            ? `rgba(255, 170, 70, ${Math.min(0.4, (sectionWarmth / 100) * 0.5)})`
            : `rgba(70, 160, 255, ${Math.min(0.4, (Math.abs(sectionWarmth) / 100) * 0.5)})`;
          ctx.fillRect(secX, secY, secW, secH);
        }

        ctx.restore();

        const bakedUrl = offCanvas.toDataURL('image/jpeg', 0.98);
        if (activeCard === 'card1') {
          setCard1Src(bakedUrl);
          setCard1Section(null);
        } else {
          setCard2Src(bakedUrl);
          setCard2Section(null);
        }

        setPrintAlert(`✅ Section grading permanently baked into ${activeCard === 'card1' ? 'Card 1 (Front)' : 'Card 2 (Back)'}!`);
        setTimeout(() => setPrintAlert(null), 4000);
      };
      img.src = targetSrc;
    } catch (e) {
      console.error(e);
    } finally {
      setIsProcessing(false);
    }
  };

  // Clear Section Box
  const handleClearSection = () => {
    if (activeCard === 'card1') {
      setCard1Section(null);
    } else {
      setCard2Section(null);
    }
  };

  // Download High-Res 300 DPI JPG
  const handleDownloadJPG = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    setIsProcessing(true);

    try {
      // Re-render without marquee for pristine export
      renderCanvas(true);
      const dataUrl = canvas.toDataURL('image/jpeg', 0.98);
      // Restore interactive UI canvas
      renderCanvas(false);

      const a = document.createElement('a');
      a.href = dataUrl;
      const fileName = `PVC_Card_5.5x8.5cm_4x6_${Date.now()}.jpg`;
      a.download = fileName;
      a.click();

      addDownloadRecord({
        id: `pvc-jpg-${Date.now()}`,
        title: fileName,
        type: 'PVC Card JPG',
        size: '1200×1800 px (300 DPI)',
        timestamp: new Date().toLocaleTimeString('en-IN')
      });
    } catch (e) {
      console.error(e);
      renderCanvas(false);
    } finally {
      setIsProcessing(false);
    }
  };

  // Download 300 DPI PDF (Exact 4x6 inch paper size)
  const handleDownloadPDF = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    setIsProcessing(true);

    try {
      // Re-render without marquee for pristine export
      renderCanvas(true);
      const dataUrl = canvas.toDataURL('image/jpeg', 0.98);
      // Restore interactive UI canvas
      renderCanvas(false);

      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'in',
        format: [4, 6]
      });

      pdf.addImage(dataUrl, 'JPEG', 0, 0, 4, 6);
      const fileName = `PVC_Card_5.5x8.5cm_4x6_${Date.now()}.pdf`;
      pdf.save(fileName);

      addDownloadRecord({
        id: `pvc-pdf-${Date.now()}`,
        title: fileName,
        type: 'PVC Card PDF',
        size: '4×6 inch (300 DPI)',
        timestamp: new Date().toLocaleTimeString('en-IN')
      });
    } catch (e) {
      console.error(e);
      renderCanvas(false);
    } finally {
      setIsProcessing(false);
    }
  };

  // Direct Browser Print (Formatted for 4x6 photo paper)
  const handleDirectPrint = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    try {
      // Re-render without marquee for pristine print
      renderCanvas(true);
      const dataUrl = canvas.toDataURL('image/jpeg', 1.0);
      // Restore interactive UI canvas
      renderCanvas(false);

      printImageSheet(dataUrl, {
        paperFormat: '4x6_portrait',
        title: 'PVC_Card_5.5x8.5cm_Print'
      });
      setPrintAlert('🖨️ PVC Card print command sent to printer! (4×6 Photo Paper Portrait • Exact 5.5 cm × 8.5 cm)');
      setTimeout(() => setPrintAlert(null), 4000);
    } catch (e) {
      console.error(e);
      renderCanvas(false);
      window.print();
    }
  };

  // Interactive Mouse Down on Canvas (Supports Move Card and Drag-to-Select-Section)
  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const scaleX = CANVAS_WIDTH / rect.width;
    const scaleY = CANVAS_HEIGHT / rect.height;

    const mouseX = (e.clientX - rect.left) * scaleX;
    const mouseY = (e.clientY - rect.top) * scaleY;

    // Detect clicked card
    const clickedCard = mouseY < CANVAS_HEIGHT / 2 ? 'card1' : 'card2';
    setActiveCard(clickedCard);

    if (interactionMode === 'section_select') {
      // Start drag box selection on clicked card
      const coords = getCardNormalizedCoords(mouseX, mouseY, clickedCard);
      if (coords.isInside) {
        setIsSelectingBox(true);
        setSelectionStartNorm({ x: coords.normX, y: coords.normY });
        const initialBox: SectionBox = { x: coords.normX, y: coords.normY, w: 0.01, h: 0.01 };
        if (clickedCard === 'card1') setCard1Section(initialBox);
        else setCard2Section(initialBox);
      }
    } else {
      // Move mode
      setDragCard(clickedCard);
      setIsDragging(true);
      const cfg = clickedCard === 'card1' ? card1Config : card2Config;
      setDragStart({ x: mouseX - cfg.x, y: mouseY - cfg.y });
    }
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const scaleX = CANVAS_WIDTH / rect.width;
    const scaleY = CANVAS_HEIGHT / rect.height;

    const mouseX = (e.clientX - rect.left) * scaleX;
    const mouseY = (e.clientY - rect.top) * scaleY;

    // If drawing a selection marquee box
    if (isSelectingBox && selectionStartNorm) {
      const coords = getCardNormalizedCoords(mouseX, mouseY, activeCard);
      const currentX = Math.max(0, Math.min(1, coords.normX));
      const currentY = Math.max(0, Math.min(1, coords.normY));

      const boxX = Math.min(selectionStartNorm.x, currentX);
      const boxY = Math.min(selectionStartNorm.y, currentY);
      const boxW = Math.max(0.01, Math.abs(currentX - selectionStartNorm.x));
      const boxH = Math.max(0.01, Math.abs(currentY - selectionStartNorm.y));

      const updatedBox: SectionBox = { x: boxX, y: boxY, w: boxW, h: boxH };
      if (activeCard === 'card1') setCard1Section(updatedBox);
      else setCard2Section(updatedBox);
      return;
    }

    // If dragging card position
    if (isDragging && dragCard) {
      if (dragCard === 'card1') {
        setCard1Config(prev => ({
          ...prev,
          x: Math.round(mouseX - dragStart.x),
          y: Math.round(mouseY - dragStart.y)
        }));
      } else {
        setCard2Config(prev => ({
          ...prev,
          x: Math.round(mouseX - dragStart.x),
          y: Math.round(mouseY - dragStart.y)
        }));
      }
    }
  };

  const handleMouseUp = () => {
    setIsDragging(false);
    setDragCard(null);
    setIsSelectingBox(false);
    setSelectionStartNorm(null);
  };

  const activeCardSection = activeCard === 'card1' ? card1Section : card2Section;

  return (
    <div className="space-y-4">
      {/* Header bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900 border border-slate-800 p-4 rounded-2xl shadow-md">
        <div>
          <div className="flex items-center gap-2 flex-wrap">
            <h1 className="text-xl font-extrabold text-white flex items-center gap-2">
              <Layers className="w-5 h-5 text-blue-400" />
              <span>PVC Smart Card Studio (5.5 cm × 8.5 cm)</span>
            </h1>
            <span className="bg-blue-500/20 text-blue-400 border border-blue-500/30 text-xs px-2.5 py-0.5 rounded-full font-mono font-bold">
              300 DPI Ultra HD
            </span>
            <span className="bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-xs px-2.5 py-0.5 rounded-full font-bold">
              4×6 inch Portrait Layout
            </span>
            <span className="bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 text-xs px-2.5 py-0.5 rounded-full font-bold flex items-center gap-1">
              <Square className="w-3 h-3" />
              <span>Section Color Grading Active</span>
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Print 5.5 cm × 8.5 cm CR-80 cards on 4×6 inch portrait photo paper with pinpoint local color grading for dark photos & faint text.
          </p>
        </div>

        {/* Primary Export Actions for PC */}
        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={handleDirectPrint}
            className="flex items-center gap-2 bg-gradient-to-r from-blue-600 via-indigo-600 to-blue-500 hover:from-blue-500 hover:to-indigo-500 text-white font-extrabold text-xs px-4 py-2.5 rounded-xl shadow-lg shadow-blue-600/30 transition-all hover:scale-105 active:scale-95 border border-blue-400/30"
            title="Direct Print to Epson / Canon (Ctrl + P)"
          >
            <Printer className="w-4 h-4 text-white" />
            <span>🖨️ Direct Print PVC Card</span>
          </button>

          <button
            onClick={handleDownloadPDF}
            disabled={isProcessing}
            className="flex items-center gap-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs px-3.5 py-2.5 rounded-xl shadow-lg shadow-indigo-600/30 transition-all hover:scale-105 disabled:opacity-50"
            title="Download Printable 300 DPI PDF"
          >
            <Download className="w-4 h-4" />
            <span>📄 PDF (4×6)</span>
          </button>

          <button
            onClick={handleDownloadJPG}
            disabled={isProcessing}
            className="flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white font-bold text-xs px-3 py-2.5 rounded-xl border border-slate-700 transition-all"
            title="Download High-Res 1200x1800 JPG"
          >
            <Download className="w-3.5 h-3.5" />
            <span>🖼️ HD JPG</span>
          </button>
        </div>
      </div>

      {/* Print Notification Banner */}
      {printAlert && (
        <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs flex items-center gap-2 animate-in fade-in">
          <Check className="w-4 h-4 text-emerald-400 flex-shrink-0" />
          <span>{printAlert}</span>
        </div>
      )}

      {/* Main Dual-Pane PC Workspace */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
        {/* Left Side: Controls & Uploads (5 columns) */}
        <div className="lg:col-span-5 space-y-4">
          {/* Card Slots (Card 1 & Card 2) */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-md space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-300 uppercase tracking-wider">Card Slots & Images</span>
              <button
                onClick={handleSwapCards}
                className="text-xs font-semibold text-blue-400 hover:text-blue-300 flex items-center gap-1"
                title="Swap Front and Back Cards"
              >
                <ArrowUpDown className="w-3.5 h-3.5" />
                <span>Swap Front/Back</span>
              </button>
            </div>

            {/* Card 1 Slot */}
            <div className={`p-3 rounded-xl border transition-all ${
              activeCard === 'card1' 
                ? 'bg-blue-950/30 border-blue-500/50 shadow-sm' 
                : 'bg-slate-950/40 border-slate-800 hover:border-slate-700'
            }`}>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-blue-500"></span>
                  <span className="font-bold text-xs text-white">Card 1 (Front Side)</span>
                </div>
                <button
                  onClick={() => setActiveCard('card1')}
                  className={`text-[11px] px-2 py-0.5 rounded font-bold transition-colors ${
                    activeCard === 'card1' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Active
                </button>
              </div>

              <div className="flex items-center gap-2">
                <label className="flex-1 flex items-center justify-center gap-2 py-2 px-3 bg-slate-800 hover:bg-slate-750 text-slate-200 text-xs font-semibold rounded-lg cursor-pointer border border-slate-700 transition-colors">
                  <Upload className="w-3.5 h-3.5 text-blue-400" />
                  <span>{card1Src ? 'Change Front Photo/PDF' : 'Upload Card 1 (Front)'}</span>
                  <input type="file" accept="image/*,.pdf" onChange={(e) => handleFileUpload(e, 'card1')} className="hidden" />
                </label>
                {card1Src && (
                  <button 
                    onClick={() => setCard1Src(null)}
                    className="p-2 text-rose-400 hover:bg-rose-500/10 rounded-lg text-xs"
                    title="Remove Card 1"
                  >
                    ✕
                  </button>
                )}
              </div>
            </div>

            {/* Card 2 Slot */}
            <div className={`p-3 rounded-xl border transition-all ${
              activeCard === 'card2' 
                ? 'bg-purple-950/30 border-purple-500/50 shadow-sm' 
                : 'bg-slate-950/40 border-slate-800 hover:border-slate-700'
            }`}>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-purple-500"></span>
                  <span className="font-bold text-xs text-white">Card 2 (Back Side)</span>
                </div>
                <button
                  onClick={() => setActiveCard('card2')}
                  className={`text-[11px] px-2 py-0.5 rounded font-bold transition-colors ${
                    activeCard === 'card2' ? 'bg-purple-600 text-white' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Active
                </button>
              </div>

              <div className="flex items-center gap-2">
                <label className="flex-1 flex items-center justify-center gap-2 py-2 px-3 bg-slate-800 hover:bg-slate-750 text-slate-200 text-xs font-semibold rounded-lg cursor-pointer border border-slate-700 transition-colors">
                  <Upload className="w-3.5 h-3.5 text-purple-400" />
                  <span>{card2Src ? 'Change Back Photo/PDF' : 'Upload Card 2 (Back)'}</span>
                  <input type="file" accept="image/*,.pdf" onChange={(e) => handleFileUpload(e, 'card2')} className="hidden" />
                </label>
                {card2Src && (
                  <button 
                    onClick={() => setCard2Src(null)}
                    className="p-2 text-rose-400 hover:bg-rose-500/10 rounded-lg text-xs"
                    title="Remove Card 2"
                  >
                    ✕
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* SECTION SELECTION TOOL & LOCAL COLOR GRADING PANEL */}
          <div className="bg-slate-900 border border-cyan-500/30 rounded-2xl p-4 shadow-xl space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Square className="w-4 h-4 text-cyan-400" />
                <span className="text-xs font-extrabold text-white uppercase tracking-wider">
                  Section Selection & Color Grading
                </span>
              </div>
              <span className="text-[10px] bg-cyan-500/20 text-cyan-300 font-bold px-2 py-0.5 rounded font-mono">
                {activeCard === 'card1' ? 'Card 1 Front' : 'Card 2 Back'}
              </span>
            </div>

            <p className="text-[11px] text-slate-300 leading-snug">
              Card ke kisi bhi hisse (e.g. Aadhaar Photo, Address Text, QR Code) ko select karke <b>sirf usi jagah ki Brightness aur Contrast</b> adjust karein.
            </p>

            {/* Mode Switcher */}
            <div className="grid grid-cols-2 gap-2 text-xs">
              <button
                type="button"
                onClick={() => setInteractionMode('move')}
                className={`py-2 px-3 rounded-xl font-bold flex items-center justify-center gap-1.5 border transition-all ${
                  interactionMode === 'move'
                    ? 'bg-blue-600 text-white border-blue-400 shadow-md'
                    : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white'
                }`}
              >
                <Move className="w-3.5 h-3.5" />
                <span>Move Card Position</span>
              </button>

              <button
                type="button"
                onClick={() => setInteractionMode('section_select')}
                className={`py-2 px-3 rounded-xl font-bold flex items-center justify-center gap-1.5 border transition-all ${
                  interactionMode === 'section_select'
                    ? 'bg-gradient-to-r from-cyan-600 to-blue-600 text-white border-cyan-400 shadow-md shadow-cyan-600/30'
                    : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white'
                }`}
              >
                <Square className="w-3.5 h-3.5 text-cyan-300" />
                <span>Select Section Tool</span>
              </button>
            </div>

            {/* Quick Preset Selection Boxes */}
            <div className="space-y-1.5 pt-1">
              <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">
                1-Click Quick Select Preset:
              </span>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 text-[11px]">
                <button
                  type="button"
                  onClick={() => handleApplyPresetSection('photo')}
                  className="p-1.5 rounded-lg bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 font-bold text-center"
                >
                  👤 Photo Box
                </button>
                <button
                  type="button"
                  onClick={() => handleApplyPresetSection('details')}
                  className="p-1.5 rounded-lg bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 font-bold text-center"
                >
                  📝 Details Text
                </button>
                <button
                  type="button"
                  onClick={() => handleApplyPresetSection('qr')}
                  className="p-1.5 rounded-lg bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 font-bold text-center"
                >
                  📱 QR Code
                </button>
                <button
                  type="button"
                  onClick={() => handleApplyPresetSection('signature')}
                  className="p-1.5 rounded-lg bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 font-bold text-center"
                >
                  ✍️ Signature
                </button>
              </div>
            </div>

            {/* Local Grading Sliders (Shown when section is selected) */}
            {activeCardSection ? (
              <div className="space-y-3 pt-2 border-t border-slate-800/80 animate-in fade-in">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-extrabold text-cyan-300 flex items-center gap-1">
                    <Sliders className="w-3.5 h-3.5" />
                    <span>Grading Selected Region Only</span>
                  </span>
                  <button
                    onClick={handleClearSection}
                    className="text-[10px] text-rose-400 hover:underline font-bold"
                  >
                    Clear Box
                  </button>
                </div>

                {/* Section Brightness */}
                <div className="text-xs space-y-1">
                  <div className="flex justify-between text-slate-300 font-semibold">
                    <span className="flex items-center gap-1.5 text-amber-300">
                      <Sun className="w-3.5 h-3.5" /> Section Brightness
                    </span>
                    <span className="font-mono text-white">{sectionBrightness > 0 ? `+${sectionBrightness}` : sectionBrightness}%</span>
                  </div>
                  <input
                    type="range"
                    min="-50"
                    max="50"
                    value={sectionBrightness}
                    onChange={(e) => setSectionBrightness(Number(e.target.value))}
                    className="w-full accent-amber-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
                  />
                  <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                    <span>Darken -50%</span>
                    <span>0</span>
                    <span>Brighten +50%</span>
                  </div>
                </div>

                {/* Section Contrast */}
                <div className="text-xs space-y-1">
                  <div className="flex justify-between text-slate-300 font-semibold">
                    <span className="flex items-center gap-1.5 text-sky-300">
                      <Contrast className="w-3.5 h-3.5" /> Section Contrast & Sharpness
                    </span>
                    <span className="font-mono text-white">{sectionContrast > 0 ? `+${sectionContrast}` : sectionContrast}%</span>
                  </div>
                  <input
                    type="range"
                    min="-50"
                    max="50"
                    value={sectionContrast}
                    onChange={(e) => setSectionContrast(Number(e.target.value))}
                    className="w-full accent-sky-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
                  />
                  <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                    <span>Soft</span>
                    <span>0</span>
                    <span>Deep Contrast +50%</span>
                  </div>
                </div>

                {/* Section Saturation */}
                <div className="text-xs space-y-1">
                  <div className="flex justify-between text-slate-300 font-semibold">
                    <span className="flex items-center gap-1.5 text-pink-300">
                      <Droplets className="w-3.5 h-3.5" /> Section Saturation
                    </span>
                    <span className="font-mono text-white">{sectionSaturation > 0 ? `+${sectionSaturation}` : sectionSaturation}%</span>
                  </div>
                  <input
                    type="range"
                    min="-50"
                    max="50"
                    value={sectionSaturation}
                    onChange={(e) => setSectionSaturation(Number(e.target.value))}
                    className="w-full accent-pink-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
                  />
                </div>

                {/* Section Warmth / Tone */}
                <div className="text-xs space-y-1">
                  <div className="flex justify-between text-slate-300 font-semibold">
                    <span className="flex items-center gap-1.5 text-orange-300">
                      <Flame className="w-3.5 h-3.5" /> Section Warmth / Tone
                    </span>
                    <span className="font-mono text-white">{sectionWarmth > 0 ? `+${sectionWarmth}` : sectionWarmth}</span>
                  </div>
                  <input
                    type="range"
                    min="-50"
                    max="50"
                    value={sectionWarmth}
                    onChange={(e) => setSectionWarmth(Number(e.target.value))}
                    className="w-full accent-orange-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
                  />
                  <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                    <span>Cool Blue</span>
                    <span>Neutral</span>
                    <span>Warm Glow</span>
                  </div>
                </div>

                {/* Bake Adjustment Button */}
                <div className="pt-2 flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleBakeSectionGrading}
                    disabled={isProcessing}
                    className="flex-1 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-extrabold text-xs rounded-xl shadow-md flex items-center justify-center gap-1.5 transition-all"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Apply / Bake to Card Image</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleClearSection}
                    className="px-3 py-2 bg-slate-800 hover:bg-slate-750 text-slate-300 text-xs font-bold rounded-xl"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            ) : (
              <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80 text-[11px] text-slate-400 space-y-1">
                <span className="font-bold text-slate-300 block">💡 How to Select:</span>
                <span>Click <b>"Select Section Tool"</b> above, then drag a rectangle over the dark photo or text area directly on the card preview!</span>
              </div>
            )}
          </div>

          {/* Whole Card Global Enhancements */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-md space-y-3">
            <span className="text-xs font-bold text-slate-300 uppercase tracking-wider block">
              Whole Card Exposure & Cutting Guides
            </span>

            <div className="space-y-3 text-xs">
              <div>
                <div className="flex justify-between text-slate-400 mb-1">
                  <span className="flex items-center gap-1.5"><Sun className="w-3.5 h-3.5 text-amber-400" /> Whole Card Brightness</span>
                  <span className="font-mono text-slate-200">{brightness > 0 ? `+${brightness}` : brightness}</span>
                </div>
                <input
                  type="range"
                  min="-30"
                  max="30"
                  value={brightness}
                  onChange={(e) => setBrightness(parseInt(e.target.value))}
                  className="w-full accent-amber-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between text-slate-400 mb-1">
                  <span className="flex items-center gap-1.5"><Contrast className="w-3.5 h-3.5 text-sky-400" /> Whole Card Contrast</span>
                  <span className="font-mono text-slate-200">{contrast > 0 ? `+${contrast}` : contrast}</span>
                </div>
                <input
                  type="range"
                  min="-30"
                  max="30"
                  value={contrast}
                  onChange={(e) => setContrast(parseInt(e.target.value))}
                  className="w-full accent-sky-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
                />
              </div>

              <div className="pt-2 border-t border-slate-800 grid grid-cols-2 gap-2">
                <label className="flex items-center gap-2 cursor-pointer text-slate-300">
                  <input
                    type="checkbox"
                    checked={showCutMarks}
                    onChange={(e) => setShowCutMarks(e.target.checked)}
                    className="rounded accent-blue-600"
                  />
                  <span>✂ Center Cut Line</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer text-slate-300">
                  <input
                    type="checkbox"
                    checked={roundedCorners}
                    onChange={(e) => setRoundedCorners(e.target.checked)}
                    className="rounded accent-blue-600"
                  />
                  <span>Rounded CR80 Corner</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer text-slate-300">
                  <input
                    type="checkbox"
                    checked={borderStroke}
                    onChange={(e) => setBorderStroke(e.target.checked)}
                    className="rounded accent-blue-600"
                  />
                  <span>Card Outline Border</span>
                </label>
              </div>
            </div>
          </div>
        </div>

        {/* Right Side: Live Interactive 300 DPI Canvas Preview (7 columns) */}
        <div className="lg:col-span-7 space-y-3">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-xl">
            <div className="flex items-center justify-between mb-3 text-xs flex-wrap gap-2">
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-white text-sm">4×6 inch Portrait Sheet Preview</span>
                <span className="bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-[10px] px-2 py-0.5 rounded font-mono font-bold">
                  Exact 5.5 cm × 8.5 cm
                </span>
                <span className="text-[10px] text-slate-400 font-mono">1200×1800 px @ 300 DPI</span>
              </div>

              {/* Mode indicator */}
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => setInteractionMode(interactionMode === 'move' ? 'section_select' : 'move')}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold flex items-center gap-1 border transition-all ${
                    interactionMode === 'section_select'
                      ? 'bg-cyan-600 text-white border-cyan-400 shadow'
                      : 'bg-slate-800 text-slate-300 border-slate-700'
                  }`}
                >
                  {interactionMode === 'section_select' ? <Square className="w-3.5 h-3.5 text-cyan-200" /> : <Move className="w-3.5 h-3.5" />}
                  <span>{interactionMode === 'section_select' ? 'Tool: Drag Selection Box' : 'Tool: Drag to Move'}</span>
                </button>
              </div>
            </div>

            {/* Canvas Container */}
            <div className="relative bg-slate-950 p-2 sm:p-4 rounded-xl border border-slate-800 overflow-hidden flex items-center justify-center shadow-inner">
              <canvas
                ref={canvasRef}
                width={CANVAS_WIDTH}
                height={CANVAS_HEIGHT}
                onMouseDown={handleMouseDown}
                onMouseMove={handleMouseMove}
                onMouseUp={handleMouseUp}
                onMouseLeave={handleMouseUp}
                className={`max-w-full h-auto bg-white rounded-lg shadow-2xl transition-all ${
                  interactionMode === 'section_select' ? 'cursor-crosshair' : 'cursor-move'
                }`}
                style={{ maxHeight: '720px' }}
              />

              {/* Helper badge */}
              <div className="absolute bottom-6 left-6 right-6 bg-slate-950/85 backdrop-blur-md border border-slate-800 p-2 rounded-xl text-[11px] text-slate-300 flex items-center justify-between gap-2 shadow-lg pointer-events-none">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-cyan-400"></span>
                  <span>{interactionMode === 'section_select' ? 'Drag over dark photo or text to color grade only that section' : 'Drag Card 1 or Card 2 to align'}</span>
                </div>
                <span className="font-mono text-cyan-300 font-bold">CR-80: 5.5 cm × 8.5 cm</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
