import React, { useState, useEffect, useRef } from 'react';
import { 
  Receipt, 
  Printer, 
  Send, 
  Plus, 
  Search, 
  Trash2, 
  QrCode, 
  IndianRupee, 
  CheckCircle, 
  Clock, 
  FileSpreadsheet, 
  HelpCircle,
  CreditCard,
  Smartphone
} from 'lucide-react';
import QRCode from 'qrcode';
import { BillItem, ShopSettings } from '../types';
import { COMMON_SHOP_SERVICES } from '../data/portalData';
import { printHtmlDocument } from '../utils/printer';

interface BillingDeskViewProps {
  bills: BillItem[];
  settings: ShopSettings;
  onAddBill: (bill: BillItem) => void;
  onDeleteBill: (id: string) => void;
}

export const BillingDeskView: React.FC<BillingDeskViewProps> = ({
  bills,
  settings,
  onAddBill,
  onDeleteBill
}) => {
  // New Bill Form State
  const [customerName, setCustomerName] = useState('');
  const [customerMobile, setCustomerMobile] = useState('');
  const [selectedService, setSelectedService] = useState(COMMON_SHOP_SERVICES[0].name);
  const [category, setCategory] = useState(COMMON_SHOP_SERVICES[0].category);
  const [govtFee, setGovtFee] = useState<number>(0);
  const [serviceFee, setServiceFee] = useState<number>(0);
  const [paymentMode, setPaymentMode] = useState<'Cash' | 'UPI / QR' | 'Card' | 'Pending'>('Cash');
  const [paymentStatus, setPaymentStatus] = useState<'Paid' | 'Pending' | 'Due'>('Paid');
  const [notes, setNotes] = useState('');

  // Generated QR Code Data URL
  const [qrDataUrl, setQrDataUrl] = useState<string>('');

  // Filter & Search
  const [searchTerm, setSearchTerm] = useState('');
  const [dateFilter, setDateFilter] = useState('');

  // Active bill for preview
  const [activePreviewBill, setActivePreviewBill] = useState<BillItem | null>(null);

  const totalAmount = (Number(govtFee) || 0) + (Number(serviceFee) || 0);

  // Auto-generate invoice number
  const nextInvoiceNo = `MOS-${new Date().getFullYear()}-${String(bills.length + 101).padStart(4, '0')}`;

  // When selected service changes, populate defaults
  const handleServiceSelect = (serviceName: string) => {
    setSelectedService(serviceName);
    const found = COMMON_SHOP_SERVICES.find(s => s.name === serviceName);
    if (found) {
      setCategory(found.category);
      setGovtFee(found.govtFee);
      setServiceFee(found.serviceFee);
    }
  };

  // Generate UPI QR Code whenever total or UPI ID changes
  useEffect(() => {
    const upiString = `upi://pay?pa=${settings.upiId}&pn=${encodeURIComponent(settings.shopName)}&am=${totalAmount}&cu=INR&tn=${encodeURIComponent(nextInvoiceNo)}`;
    QRCode.toDataURL(upiString, { width: 180, margin: 1 })
      .then(url => setQrDataUrl(url))
      .catch(() => setQrDataUrl(''));
  }, [totalAmount, settings.upiId, settings.shopName, nextInvoiceNo]);

  // Handle Form Submission
  const handleCreateBill = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName.trim()) {
      alert('Please enter Customer Name');
      return;
    }

    const newBill: BillItem = {
      id: `bill-${Date.now()}`,
      invoiceNo: nextInvoiceNo,
      customerName: customerName.trim(),
      customerMobile: customerMobile.trim() || 'N/A',
      serviceName: selectedService,
      category: category,
      govtFee: Number(govtFee) || 0,
      serviceFee: Number(serviceFee) || 0,
      total: totalAmount,
      paymentMode: paymentMode,
      status: paymentStatus,
      createdAt: new Date().toLocaleString('en-IN', {
        dateStyle: 'medium',
        timeStyle: 'short'
      }),
      notes: notes.trim()
    };

    onAddBill(newBill);
    setActivePreviewBill(newBill);

    // Reset customer name & mobile for next transaction
    setCustomerName('');
    setCustomerMobile('');
    setNotes('');
  };

  // Direct Thermal POS Print (58mm or 80mm format)
  const handlePrintThermal = (billToPrint: BillItem) => {
    const is80 = settings.thermalWidth === '80mm';
    const paperWidth = is80 ? '76mm' : '56mm';

    const pageStyle = `
      @page {
        size: ${paperWidth} auto;
        margin: 0;
      }
      body {
        font-family: 'Courier New', Courier, monospace;
        width: ${paperWidth};
        margin: 0 auto;
        padding: 6px;
        font-size: 12px;
        color: #000;
        line-height: 1.3;
      }
      .center { text-align: center; }
      .right { text-align: right; }
      .bold { font-weight: bold; }
      .divider { border-top: 1px dashed #000; margin: 6px 0; }
      .header { font-size: 15px; font-weight: bold; }
      .qr { text-align: center; margin: 8px 0; }
      .qr img { width: 120px; height: 120px; }
      table { width: 100%; border-collapse: collapse; font-size: 12px; }
      td { padding: 2px 0; }
    `;

    const htmlBody = `
      <div class="center">
        <div class="header">${settings.shopName}</div>
        <div>${settings.tagline}</div>
        <div>${settings.address}</div>
        <div>Mob: ${settings.phone}</div>
      </div>
      <div class="divider"></div>
      <div><b>Invoice:</b> ${billToPrint.invoiceNo}</div>
      <div><b>Date:</b> ${billToPrint.createdAt}</div>
      <div><b>Customer:</b> ${billToPrint.customerName}</div>
      <div><b>Phone:</b> ${billToPrint.customerMobile}</div>
      <div class="divider"></div>
      <table>
        <tr><td class="bold">Service:</td><td class="right">${billToPrint.serviceName}</td></tr>
        ${billToPrint.govtFee > 0 ? `<tr><td>Govt Fee:</td><td class="right">₹${billToPrint.govtFee}</td></tr>` : ''}
        <tr><td>Service Charge:</td><td class="right">₹${billToPrint.serviceFee}</td></tr>
        <tr style="border-top:1px solid #000; font-weight:bold;">
          <td style="font-size:14px;">TOTAL:</td>
          <td class="right" style="font-size:14px;">₹${billToPrint.total}</td>
        </tr>
      </table>
      <div class="divider"></div>
      <div><b>Payment:</b> ${billToPrint.paymentMode} (${billToPrint.status})</div>
      ${settings.upiId ? `
        <div class="qr">
          <div>Scan UPI to Pay:</div>
          <img src="${qrDataUrl}" />
          <div style="font-size:10px;">${settings.upiId}</div>
        </div>
      ` : ''}
      <div class="center" style="font-size:11px; margin-top:8px;">
        <div>*** Thank You Visit Again ***</div>
        <div>Computerized Online Service Receipt</div>
      </div>
    `;

    printHtmlDocument(htmlBody, `Receipt_${billToPrint.invoiceNo}`, pageStyle);
  };

  // Direct A4 Official Invoice Print
  const handlePrintA4 = (billToPrint: BillItem) => {
    const pageStyle = `
      @page { size: A4; margin: 15mm; }
      body { font-family: sans-serif; margin: 0; padding: 20px; color: #1e293b; font-size: 14px; }
      .header-table { width: 100%; border-bottom: 2px solid #2563eb; padding-bottom: 15px; margin-bottom: 20px; }
      .shop-title { font-size: 24px; font-weight: 800; color: #1e40af; }
      .info-box { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 12px; margin-bottom: 20px; }
      table.items { width: 100%; border-collapse: collapse; margin-top: 15px; }
      table.items th { background: #2563eb; color: #fff; text-align: left; padding: 10px; font-size: 13px; }
      table.items td { padding: 10px; border-bottom: 1px solid #e2e8f0; }
      .total-row { font-size: 16px; font-weight: bold; background: #eff6ff; }
      .footer { margin-top: 40px; display: flex; justify-content: space-between; align-items: flex-end; }
      .sign { border-top: 1px solid #94a3b8; width: 180px; text-align: center; padding-top: 5px; font-size: 12px; }
    `;

    const htmlBody = `
          <table class="header-table">
            <tr>
              <td>
                <div class="shop-title">${settings.shopName}</div>
                <div>${settings.tagline}</div>
                <div>${settings.address}</div>
                <div>Phone / WhatsApp: ${settings.phone}</div>
                ${settings.gstNo ? `<div>GSTIN: ${settings.gstNo}</div>` : ''}
              </td>
              <td style="text-align:right;">
                <h2 style="margin:0; color:#1e40af;">SERVICE INVOICE</h2>
                <div style="font-family:monospace; font-size:16px; font-weight:bold;">${billToPrint.invoiceNo}</div>
                <div style="margin-top:4px;">Date: ${billToPrint.createdAt}</div>
              </td>
            </tr>
          </table>

          <div class="info-box">
            <table style="width:100%;">
              <tr>
                <td><b>Billed To:</b> ${billToPrint.customerName}</td>
                <td style="text-align:right;"><b>Mobile:</b> ${billToPrint.customerMobile}</td>
              </tr>
            </table>
          </div>

          <table class="items">
            <thead>
              <tr>
                <th>Sr.</th>
                <th>Service Description</th>
                <th>Category</th>
                <th style="text-align:right;">Govt Fee</th>
                <th style="text-align:right;">Service Charge</th>
                <th style="text-align:right;">Total (₹)</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>1</td>
                <td><b>${billToPrint.serviceName}</b></td>
                <td>${billToPrint.category}</td>
                <td style="text-align:right;">₹${billToPrint.govtFee}</td>
                <td style="text-align:right;">₹${billToPrint.serviceFee}</td>
                <td style="text-align:right; font-weight:bold;">₹${billToPrint.total}</td>
              </tr>
              <tr class="total-row">
                <td colspan="5" style="text-align:right;">GRAND TOTAL:</td>
                <td style="text-align:right; color:#1e40af;">₹${billToPrint.total}.00</td>
              </tr>
            </tbody>
          </table>

          <div style="margin-top:15px; font-size:12px; color:#64748b;">
            Payment Mode: <b>${billToPrint.paymentMode}</b> | Status: <b>${billToPrint.status}</b>
          </div>

          <div class="footer">
            <div style="font-size:11px; color:#64748b;">
              This is a computer generated invoice.<br>Terms: Fees once paid for government portal submissions are non-refundable.
            </div>
            <div class="sign">
              Authorized Signatory<br><b>${settings.shopName}</b>
            </div>
          </div>
        </body>
      </html>
    `;

    printHtmlDocument(htmlBody, `Invoice_${billToPrint.invoiceNo}`, pageStyle);
  };

  // Export ledger to CSV
  const handleExportCSV = () => {
    let csv = 'Invoice No,Customer Name,Mobile,Service,Govt Fee,Service Fee,Total,Payment Mode,Status,Date\n';
    bills.forEach(b => {
      csv += `"${b.invoiceNo}","${b.customerName}","${b.customerMobile}","${b.serviceName}",${b.govtFee},${b.serviceFee},${b.total},"${b.paymentMode}","${b.status}","${b.createdAt}"\n`;
    });
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Muzammil_Bills_Ledger_${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Filter bills
  const filteredBills = bills.filter(b => {
    const matchesSearch = 
      b.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      b.customerMobile.includes(searchTerm) ||
      b.invoiceNo.toLowerCase().includes(searchTerm.toLowerCase()) ||
      b.serviceName.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesDate = !dateFilter || b.createdAt.includes(dateFilter);
    return matchesSearch && matchesDate;
  });

  const activeDisplayBill = activePreviewBill || (bills.length > 0 ? bills[0] : null);

  return (
    <div className="space-y-5">
      {/* Header bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900 border border-slate-800 p-4 rounded-2xl shadow-md">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-extrabold text-white">Billing Desk & POS Station</h1>
            <span className="bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-xs px-2 py-0.5 rounded-full font-mono font-bold">
              {settings.thermalWidth} POS / A4
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Quick customer billing, dynamic UPI QR payments, 58mm/80mm thermal receipt printing & WhatsApp notification
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCSV}
            className="flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white font-bold text-xs px-3 py-2 rounded-xl border border-slate-700 transition-all"
            title="Export Bills Ledger to Excel CSV"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      {/* Main Dual Pane: Left = New Bill Form, Right = Live POS Receipt Preview */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
        {/* Left Side: Fast POS Entry Form (7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          <form onSubmit={handleCreateBill} className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-md space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <span className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-2">
                <Receipt className="w-4 h-4 text-emerald-400" />
                <span>Create New Customer Receipt</span>
              </span>
              <span className="text-xs font-mono font-bold text-blue-400 bg-blue-500/10 px-2 py-0.5 rounded border border-blue-500/20">
                Next: {nextInvoiceNo}
              </span>
            </div>

            {/* Customer Name & Mobile */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div>
                <label className="font-semibold text-slate-300 block mb-1">Customer Full Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Shaikh Sameer"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 text-sm font-medium"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-300 block mb-1">Customer Mobile (WhatsApp) *</label>
                <input
                  type="tel"
                  placeholder="10 digit mobile (e.g. 9561460313)"
                  value={customerMobile}
                  onChange={(e) => setCustomerMobile(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 text-sm font-mono"
                />
              </div>
            </div>

            {/* Service Preset Dropdown */}
            <div className="text-xs space-y-1">
              <label className="font-semibold text-slate-300 block">Select Service / Application *</label>
              <select
                value={selectedService}
                onChange={(e) => handleServiceSelect(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2.5 text-white focus:outline-none focus:border-emerald-500 text-sm font-medium"
              >
                {COMMON_SHOP_SERVICES.map((s) => (
                  <option key={s.name} value={s.name}>
                    {s.name} (Govt: ₹{s.govtFee} + Fee: ₹{s.serviceFee} = ₹{s.govtFee + s.serviceFee})
                  </option>
                ))}
              </select>
            </div>

            {/* Fee Breakdown (Govt Fee vs Service Charge) */}
            <div className="space-y-2 bg-slate-950/60 p-3 rounded-xl border border-slate-800">
              <div className="grid grid-cols-3 gap-3 text-xs">
                <div>
                  <label className="text-slate-400 block mb-1">Govt Portal Fee (₹)</label>
                  <input
                    type="number"
                    min="0"
                    placeholder="0"
                    value={govtFee || ''}
                    onChange={(e) => setGovtFee(Number(e.target.value) || 0)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white font-mono text-sm"
                  />
                </div>

                <div>
                  <label className="text-slate-400 block mb-1">Shop Service Fee (₹)</label>
                  <input
                    type="number"
                    min="0"
                    placeholder="0"
                    value={serviceFee || ''}
                    onChange={(e) => setServiceFee(Number(e.target.value) || 0)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white font-mono text-sm"
                  />
                </div>

                <div>
                  <label className="text-emerald-400 font-bold block mb-1">Total Bill Amount</label>
                  <div className="h-8 rounded-lg bg-emerald-950/40 border border-emerald-500/40 flex items-center px-3 font-mono font-black text-emerald-400 text-base">
                    ₹{totalAmount}
                  </div>
                </div>
              </div>

              {/* Quick Amount Chips */}
              <div className="flex items-center gap-1.5 pt-1 flex-wrap text-[11px]">
                <span className="text-slate-500 text-[10px]">Quick Add:</span>
                {[10, 20, 30, 50, 70, 100, 150].map((amt) => (
                  <button
                    type="button"
                    key={amt}
                    onClick={() => setServiceFee((prev) => (Number(prev) || 0) + amt)}
                    className="px-2 py-0.5 rounded bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-700 font-mono"
                  >
                    +₹{amt}
                  </button>
                ))}
                <button
                  type="button"
                  onClick={() => { setGovtFee(0); setServiceFee(0); }}
                  className="px-2 py-0.5 rounded bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/30 font-bold ml-auto"
                >
                  Reset ₹0
                </button>
              </div>
            </div>

            {/* Payment Mode & Status */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div>
                <label className="font-semibold text-slate-300 block mb-1">Payment Method</label>
                <div className="grid grid-cols-3 gap-1.5">
                  {(['Cash', 'UPI / QR', 'Pending'] as const).map((mode) => (
                    <button
                      type="button"
                      key={mode}
                      onClick={() => setPaymentMode(mode)}
                      className={`py-1.5 px-2 rounded-lg font-bold border transition-all ${
                        paymentMode === mode
                          ? 'bg-blue-600 text-white border-blue-500 shadow-sm'
                          : 'bg-slate-950 text-slate-400 border-slate-800 hover:bg-slate-800'
                      }`}
                    >
                      {mode}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="font-semibold text-slate-300 block mb-1">Payment Status</label>
                <div className="grid grid-cols-2 gap-1.5">
                  {(['Paid', 'Due'] as const).map((st) => (
                    <button
                      type="button"
                      key={st}
                      onClick={() => setPaymentStatus(st === 'Due' ? 'Due' : 'Paid')}
                      className={`py-1.5 px-2 rounded-lg font-bold border transition-all ${
                        paymentStatus === st
                          ? st === 'Paid'
                            ? 'bg-emerald-600 text-white border-emerald-500'
                            : 'bg-rose-600 text-white border-rose-500'
                          : 'bg-slate-950 text-slate-400 border-slate-800 hover:bg-slate-800'
                      }`}
                    >
                      {st}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Notes */}
            <div className="text-xs">
              <label className="text-slate-400 block mb-1">Service Remarks / Ack Token (Optional)</label>
              <input
                type="text"
                placeholder="e.g. Ack token 88124, 2 copies printed"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-1.5 text-white placeholder-slate-500 text-xs"
              />
            </div>

            {/* Submit & Generate Button */}
            <button
              type="submit"
              className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-extrabold text-sm py-3 rounded-xl shadow-lg shadow-emerald-600/30 transition-all hover:scale-[1.01] active:scale-[0.99]"
            >
              <Receipt className="w-4 h-4" />
              <span>Generate Receipt & Save (₹{totalAmount})</span>
            </button>
          </form>
        </div>

        {/* Right Side: Live Thermal POS Receipt Preview (5 cols) */}
        <div className="lg:col-span-5 space-y-3">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-xl">
            <div className="flex items-center justify-between mb-3 text-xs">
              <span className="font-bold text-white flex items-center gap-1.5">
                <Printer className="w-3.5 h-3.5 text-blue-400" />
                <span>Live POS Thermal Slip Preview</span>
              </span>
              <span className="text-[11px] font-mono text-slate-400 bg-slate-800 px-2 py-0.5 rounded">
                {settings.thermalWidth} Monospace
              </span>
            </div>

            {/* White Thermal Receipt Slip Box */}
            {activeDisplayBill ? (
              <div className="bg-white text-slate-950 p-5 rounded-xl shadow-2xl font-mono text-xs select-text border border-slate-300 mx-auto max-w-[340px] leading-relaxed">
                {/* Shop Header */}
                <div className="text-center space-y-0.5 border-b border-dashed border-slate-400 pb-3">
                  <div className="font-black text-sm uppercase tracking-tight">{settings.shopName}</div>
                  <div className="text-[11px] text-slate-600">{settings.tagline}</div>
                  <div className="text-[10px] text-slate-600">{settings.address}</div>
                  <div className="text-[11px] font-bold">Mob: {settings.phone}</div>
                </div>

                {/* Bill Metadata */}
                <div className="py-2.5 border-b border-dashed border-slate-400 space-y-0.5 text-[11px]">
                  <div className="flex justify-between">
                    <span>Invoice:</span>
                    <span className="font-bold">{activeDisplayBill.invoiceNo}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Date:</span>
                    <span>{activeDisplayBill.createdAt}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Customer:</span>
                    <span className="font-bold">{activeDisplayBill.customerName}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Phone:</span>
                    <span>{activeDisplayBill.customerMobile}</span>
                  </div>
                </div>

                {/* Items & Fees */}
                <div className="py-2.5 border-b border-dashed border-slate-400 space-y-1 text-xs">
                  <div className="font-bold">{activeDisplayBill.serviceName}</div>
                  {activeDisplayBill.govtFee > 0 && (
                    <div className="flex justify-between text-[11px] text-slate-700">
                      <span>Govt Portal Fee:</span>
                      <span>₹{activeDisplayBill.govtFee}</span>
                    </div>
                  )}
                  <div className="flex justify-between text-[11px] text-slate-700">
                    <span>Service Charge:</span>
                    <span>₹{activeDisplayBill.serviceFee}</span>
                  </div>
                  <div className="flex justify-between font-black text-sm pt-1 border-t border-slate-900 mt-1">
                    <span>NET TOTAL:</span>
                    <span>₹{activeDisplayBill.total}.00</span>
                  </div>
                </div>

                {/* Payment & QR */}
                <div className="pt-2 text-center space-y-2">
                  <div className="text-[11px] font-semibold">
                    Payment Mode: <b>{activeDisplayBill.paymentMode}</b> ({activeDisplayBill.status})
                  </div>

                  {settings.upiId && (
                    <div className="flex flex-col items-center justify-center p-2 bg-slate-50 rounded-lg border border-slate-200">
                      <span className="text-[10px] text-slate-500 mb-1">Scan QR via GPay / PhonePe / Paytm:</span>
                      {qrDataUrl && <img src={qrDataUrl} alt="UPI QR" className="w-28 h-28" />}
                      <span className="text-[10px] font-bold font-mono text-slate-700 mt-1">{settings.upiId}</span>
                    </div>
                  )}

                  <div className="text-[10px] text-slate-500 pt-1">
                    *** Thank You Visit Again ***<br />
                    Muzammil Online Service Digital Hub
                  </div>
                </div>
              </div>
            ) : (
              <div className="p-8 text-center text-slate-500 text-xs">
                No bill selected. Create a bill on the left to see live preview.
              </div>
            )}

            {/* Slip Action Buttons */}
            {activeDisplayBill && (
              <div className="grid grid-cols-3 gap-2 mt-4 pt-3 border-t border-slate-800">
                <button
                  onClick={() => handlePrintThermal(activeDisplayBill)}
                  className="flex items-center justify-center gap-1.5 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs py-2 rounded-xl shadow-md transition-colors"
                  title="Print on 58mm/80mm Thermal Printer"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Thermal</span>
                </button>

                <button
                  onClick={() => handlePrintA4(activeDisplayBill)}
                  className="flex items-center justify-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white font-bold text-xs py-2 rounded-xl border border-slate-700 transition-colors"
                  title="Print Official A4 Tax Invoice"
                >
                  <Printer className="w-3.5 h-3.5 text-purple-400" />
                  <span>A4 Invoice</span>
                </button>

                <a
                  href={`https://wa.me/91${activeDisplayBill.customerMobile}?text=Hello%20${encodeURIComponent(activeDisplayBill.customerName)},%20your%20receipt%20for%20${encodeURIComponent(activeDisplayBill.serviceName)}%20at%20${encodeURIComponent(settings.shopName)}%20is%20ready.%20Total:%20Rs.${activeDisplayBill.total}.%20Invoice:%20${activeDisplayBill.invoiceNo}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs py-2 rounded-xl shadow-md transition-colors"
                  title="Send Receipt via WhatsApp"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>WhatsApp</span>
                </a>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Bottom Section: Full Billing Ledger & Sales History Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-md space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="font-bold text-base text-white">Billing History & Sales Ledger</h3>
            <p className="text-xs text-slate-400">Total {bills.length} bills recorded in local database</p>
          </div>

          <div className="flex items-center gap-2">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Filter by customer, phone, invoice..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="bg-slate-950 border border-slate-700 rounded-xl pl-8 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 w-56"
              />
            </div>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950 text-slate-400 border-b border-slate-800 font-mono">
              <tr>
                <th className="py-2.5 px-3">Invoice</th>
                <th className="py-2.5 px-3">Date & Time</th>
                <th className="py-2.5 px-3">Customer</th>
                <th className="py-2.5 px-3">Mobile</th>
                <th className="py-2.5 px-3">Service</th>
                <th className="py-2.5 px-3 text-right">Govt</th>
                <th className="py-2.5 px-3 text-right">Fee</th>
                <th className="py-2.5 px-3 text-right">Total</th>
                <th className="py-2.5 px-3 text-center">Status</th>
                <th className="py-2.5 px-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredBills.map((b) => (
                <tr 
                  key={b.id} 
                  onClick={() => setActivePreviewBill(b)}
                  className={`cursor-pointer transition-colors ${
                    activePreviewBill?.id === b.id ? 'bg-blue-950/30' : 'hover:bg-slate-800/40'
                  }`}
                >
                  <td className="py-3 px-3 font-mono font-bold text-blue-400">{b.invoiceNo}</td>
                  <td className="py-3 px-3 text-slate-400 font-mono text-[11px]">{b.createdAt}</td>
                  <td className="py-3 px-3 font-semibold text-white">{b.customerName}</td>
                  <td className="py-3 px-3 font-mono text-slate-400">{b.customerMobile}</td>
                  <td className="py-3 px-3 text-slate-300 max-w-[200px] truncate">{b.serviceName}</td>
                  <td className="py-3 px-3 text-right font-mono text-slate-400">₹{b.govtFee}</td>
                  <td className="py-3 px-3 text-right font-mono text-slate-400">₹{b.serviceFee}</td>
                  <td className="py-3 px-3 text-right font-mono font-bold text-emerald-400">₹{b.total}</td>
                  <td className="py-3 px-3 text-center">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      b.status === 'Paid' 
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' 
                        : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                    }`}>
                      {b.status}
                    </span>
                  </td>
                  <td className="py-3 px-3 text-right space-x-1 whitespace-nowrap">
                    <button
                      onClick={(e) => { e.stopPropagation(); handlePrintThermal(b); }}
                      title="Print Thermal Slip"
                      className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors"
                    >
                      <Printer className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={(e) => { e.stopPropagation(); onDeleteBill(b.id); }}
                      title="Delete Bill"
                      className="p-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
