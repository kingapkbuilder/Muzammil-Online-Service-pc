import React from 'react';
import { 
  LayoutDashboard, 
  CreditCard, 
  Camera, 
  FileImage, 
  Receipt, 
  Users, 
  FileText, 
  Landmark, 
  Sparkles, 
  Download, 
  Settings, 
  Database,
  ChevronLeft,
  ChevronRight,
  ShieldCheck,
  Lock,
  Film
} from 'lucide-react';
import { UserAccount } from '../types';

interface SidebarProps {
  activeTab: string;
  onNavigate: (tab: string) => void;
  isCollapsed: boolean;
  onToggleCollapse: () => void;
  user: UserAccount;
  pendingJobsCount: number;
  onLogout: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  onNavigate,
  isCollapsed,
  onToggleCollapse,
  user,
  pendingJobsCount,
  onLogout
}) => {
  const navItems = [
    {
      id: 'dashboard',
      label: 'Dashboard',
      icon: LayoutDashboard,
      badge: null,
      shortcut: 'Alt+1'
    },
    {
      id: 'pvc_studio',
      label: 'PVC Card Maker',
      icon: CreditCard,
      badge: '300 DPI',
      badgeColor: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
      shortcut: 'Alt+2'
    },
    {
      id: 'passport_studio',
      label: 'Passport Studio',
      icon: Camera,
      badge: '4×6 / A4',
      badgeColor: 'bg-purple-500/20 text-purple-400 border-purple-500/30',
      shortcut: 'Alt+3'
    },
    {
      id: 'video_studio',
      label: 'Video Editing Studio',
      icon: Film,
      badge: 'Multi-Layer',
      badgeColor: 'bg-rose-500/20 text-rose-400 border-rose-500/30',
      shortcut: 'Alt+V'
    },
    {
      id: 'pdf_to_jpg',
      label: 'PDF to HD JPG',
      icon: FileImage,
      badge: 'Unlock',
      badgeColor: 'bg-amber-500/20 text-amber-400 border-amber-500/30',
      shortcut: 'Alt+4'
    },
    {
      id: 'billing',
      label: 'Billing Desk POS',
      icon: Receipt,
      badge: 'Thermal',
      badgeColor: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
      shortcut: 'Alt+5'
    },
    {
      id: 'customers',
      label: 'Customer CRM',
      icon: Users,
      badge: pendingJobsCount > 0 ? `${pendingJobsCount} Pending` : null,
      badgeColor: 'bg-rose-500/20 text-rose-400 border-rose-500/30',
      shortcut: 'Alt+6'
    },
    {
      id: 'biodata_maker',
      label: 'CV & BioData Maker',
      icon: FileText,
      badge: 'A4',
      badgeColor: 'bg-indigo-500/20 text-indigo-400 border-indigo-500/30',
      shortcut: 'Alt+7'
    },
    {
      id: 'workflow',
      label: 'Cyber Cafe Workflow',
      icon: ShieldCheck,
      badge: 'SOP',
      badgeColor: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30',
      shortcut: null
    },
    ...(user.role === 'admin' ? [{
      id: 'master_admin',
      label: 'Master Admin Panel',
      icon: Lock,
      badge: 'Admin',
      badgeColor: 'bg-rose-500/20 text-rose-300 border-rose-500/30',
      shortcut: null
    }] : []),
    {
      id: 'portals',
      label: 'Govt Portals Hub',
      icon: Landmark,
      badge: '50+',
      badgeColor: 'bg-sky-500/20 text-sky-400 border-sky-500/30',
      shortcut: 'Alt+8'
    },
    {
      id: 'ai_assistant',
      label: 'AI Scheme Guide',
      icon: Sparkles,
      badge: 'AI',
      badgeColor: 'bg-amber-500/20 text-amber-300 border-amber-500/30',
      shortcut: 'Alt+9'
    },
    {
      id: 'downloads',
      label: 'Downloads & Files',
      icon: Download,
      badge: null,
      shortcut: null
    },
    {
      id: 'settings',
      label: 'Shop Settings',
      icon: Settings,
      badge: null,
      shortcut: null
    },
    {
      id: 'backup',
      label: 'Backup & Restore',
      icon: Database,
      badge: null,
      shortcut: null
    }
  ];

  return (
    <aside 
      className={`bg-slate-900/95 border-r border-slate-800 transition-all duration-200 ease-in-out flex flex-col justify-between select-none z-20 flex-shrink-0 no-print ${
        isCollapsed ? 'w-16' : 'w-64'
      }`}
    >
      {/* Navigation menu list */}
      <div className="p-2 space-y-1 overflow-y-auto overflow-x-hidden flex-1">
        {!isCollapsed && (
          <div className="px-3 py-2 text-[11px] font-bold uppercase tracking-wider text-slate-400">
            Workstation Tools
          </div>
        )}

        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              title={isCollapsed ? `${item.label} (${item.shortcut || ''})` : undefined}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold transition-all group relative ${
                isActive
                  ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/30 font-bold'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/80'
              }`}
            >
              <Icon className={`w-4 h-4 flex-shrink-0 transition-transform group-hover:scale-110 ${isActive ? 'text-white' : 'text-slate-400 group-hover:text-blue-400'}`} />
              
              {!isCollapsed && (
                <div className="flex-1 flex items-center justify-between min-w-0">
                  <span className="truncate">{item.label}</span>
                  {item.badge && (
                    <span className={`text-[10px] px-1.5 py-0.5 rounded border font-mono font-medium ${item.badgeColor || 'bg-slate-800 text-slate-300 border-slate-700'}`}>
                      {item.badge}
                    </span>
                  )}
                </div>
              )}

              {/* Active Indicator Bar */}
              {isActive && (
                <div className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-5 bg-white rounded-r-full" />
              )}
            </button>
          );
        })}
      </div>

      {/* Footer / Toggle & System Status */}
      <div className="p-2 border-t border-slate-800/80 bg-slate-950/40 space-y-1.5">
        {!isCollapsed && (
          <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800">
            <div className="flex items-center justify-between text-xs">
              <div className="flex items-center gap-1.5 text-slate-300 font-medium">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>Station Active</span>
              </div>
              <span className="text-[10px] text-slate-400 font-mono">v98.0 PC</span>
            </div>
            <div className="flex items-center justify-between mt-2 pt-1.5 border-t border-slate-800/60 text-[11px]">
              <span className="text-slate-400 truncate max-w-[120px]">@{user.username}</span>
              <button
                onClick={onLogout}
                className="text-rose-400 hover:text-rose-300 font-bold flex items-center gap-1 hover:underline"
                title="Lock Station & Logout"
              >
                <Lock className="w-3 h-3" />
                <span>Lock</span>
              </button>
            </div>
          </div>
        )}

        <button
          onClick={onToggleCollapse}
          className="w-full flex items-center justify-center p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors text-xs"
          title={isCollapsed ? "Expand Sidebar (Ctrl + [)" : "Collapse Sidebar (Ctrl + [)"}
        >
          {isCollapsed ? <ChevronRight className="w-4 h-4" /> : (
            <div className="flex items-center gap-2">
              <ChevronLeft className="w-4 h-4" />
              <span className="text-xs">Collapse Panel</span>
            </div>
          )}
        </button>
      </div>
    </aside>
  );
};
