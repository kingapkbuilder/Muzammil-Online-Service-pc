import React from 'react';
import { 
  Download, 
  Trash2, 
  FileText, 
  CreditCard, 
  Camera, 
  FileImage, 
  Receipt, 
  Clock 
} from 'lucide-react';
import { DownloadItem } from '../types';

interface DownloadsViewProps {
  downloads: DownloadItem[];
  onDeleteDownload: (id: string) => void;
  onClearAll: () => void;
}

export const DownloadsView: React.FC<DownloadsViewProps> = ({
  downloads,
  onDeleteDownload,
  onClearAll
}) => {
  const getIcon = (type: DownloadItem['type']) => {
    switch (type) {
      case 'PVC Card PDF':
      case 'PVC Card JPG':
        return <CreditCard className="w-5 h-5 text-blue-400" />;
      case 'Passport Sheet PDF':
      case 'Passport Sheet JPG':
        return <Camera className="w-5 h-5 text-purple-400" />;
      case 'BioData PDF':
        return <FileText className="w-5 h-5 text-indigo-400" />;
      case 'Converted JPG':
        return <FileImage className="w-5 h-5 text-amber-400" />;
      default:
        return <Receipt className="w-5 h-5 text-emerald-400" />;
    }
  };

  return (
    <div className="space-y-4 max-w-5xl mx-auto">
      {/* Header bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900 border border-slate-800 p-4 rounded-2xl shadow-md">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-extrabold text-white">Generated Downloads & Print History</h1>
            <span className="bg-blue-500/20 text-blue-400 border border-blue-500/30 text-xs px-2 py-0.5 rounded-full font-mono font-bold">
              {downloads.length} Files
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Log of all generated PVC cards, passport sheets, converted PDFs, and receipts created on this PC
          </p>
        </div>

        {downloads.length > 0 && (
          <button
            onClick={onClearAll}
            className="flex items-center gap-1.5 bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/30 text-xs font-bold px-3 py-2 rounded-xl transition-colors"
          >
            <Trash2 className="w-4 h-4" />
            <span>Clear History</span>
          </button>
        )}
      </div>

      {/* Downloads List */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-md">
        {downloads.length === 0 ? (
          <div className="p-12 text-center text-slate-500 text-xs space-y-2">
            <Download className="w-10 h-10 mx-auto text-slate-600" />
            <p className="font-bold text-slate-400 text-sm">No Downloads Logged Yet</p>
            <p>Generated PVC cards, passport photo sheets, and converted PDFs will be listed here.</p>
          </div>
        ) : (
          <div className="divide-y divide-slate-800">
            {downloads.map((item) => (
              <div
                key={item.id}
                className="p-4 flex items-center justify-between gap-4 hover:bg-slate-800/40 transition-colors"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-10 h-10 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-center flex-shrink-0 shadow-inner">
                    {getIcon(item.type)}
                  </div>
                  <div className="min-w-0">
                    <h4 className="text-xs font-bold text-white truncate">{item.title}</h4>
                    <div className="flex items-center gap-2 text-[11px] text-slate-400 font-mono mt-0.5">
                      <span>{item.type}</span>
                      <span>•</span>
                      <span>{item.size}</span>
                      <span>•</span>
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3 text-slate-500" />
                        <span>{item.timestamp}</span>
                      </span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => onDeleteDownload(item.id)}
                    title="Remove record"
                    className="p-2 text-slate-500 hover:text-rose-400 rounded-lg hover:bg-slate-800 transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
