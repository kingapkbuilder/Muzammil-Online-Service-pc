import React from 'react';
import { X, Keyboard, Mouse, Sparkles, Printer, Zap } from 'lucide-react';

interface ShortcutsModalProps {
  onClose: () => void;
}

export const ShortcutsModal: React.FC<ShortcutsModalProps> = ({ onClose }) => {
  const keyboardShortcuts = [
    { key: 'Ctrl + P', desc: 'Direct print active sheet / PVC card / invoice (zero popup blocker)' },
    { key: 'Ctrl + B', desc: 'Fast Billing Desk & POS' },
    { key: 'Ctrl + K or /', desc: 'Focus global search bar (all 50+ portals)' },
    { key: 'Ctrl + Z', desc: 'Undo last point in Passport Pen Tool' },
    { key: 'Ctrl + S', desc: 'Download printable 300 DPI PDF' },
    { key: 'Ctrl + J', desc: 'Download HD JPG' },
    { key: 'Alt + 1', desc: 'Go to Dashboard & Daily Summary' },
    { key: 'Alt + 2', desc: 'Go to PVC Smart Card Studio (CR-80)' },
    { key: 'Alt + 3', desc: 'Go to Passport Photo Studio' },
    { key: 'Alt + 4', desc: 'Go to PDF to JPG Converter' },
    { key: 'Alt + 5', desc: 'Go to Fast Billing Desk' },
    { key: 'Alt + 6', desc: 'Go to Customer CRM & Job Tracker' },
    { key: 'Alt + 7', desc: 'Go to CV & BioData Maker' },
    { key: 'Alt + 8', desc: 'Go to Govt Portals Hub' },
    { key: 'Alt + 9', desc: 'Go to AI Scheme Assistant' },
    { key: 'F11', desc: 'Toggle Fullscreen PC Station Mode' },
    { key: 'Esc', desc: 'Close dialogs / Cancel Pen tool path' }
  ];

  const mouseControls = [
    { action: 'Left Click (Pen Tool)', desc: 'Place anchor points around person to trace cutout' },
    { action: 'Click First Point (Pen Tool)', desc: 'Close polygon loop and preview studio background' },
    { action: 'Mouse Drag (Canvas)', desc: 'Pan image or reposition cards on sheet' },
    { action: 'Mouse Wheel / Pinch', desc: 'Zoom in / out on photo for precision tracing' },
    { action: 'Right Click (Pen Tool)', desc: 'Delete nearest anchor point' }
  ];

  return (
    <div className="fixed inset-0 bg-black/85 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-2xl w-full p-6 shadow-2xl space-y-5 animate-in fade-in zoom-in-95">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-blue-600/20 border border-blue-500/30 flex items-center justify-center text-blue-400">
              <Keyboard className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-white text-base">PC Keyboard & Mouse Shortcuts</h3>
              <p className="text-xs text-slate-400">High-speed operator hotkeys for Muzammil Online Service</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-h-[65vh] overflow-y-auto pr-1">
          {/* Keyboard Shortcuts */}
          <div className="space-y-2">
            <div className="flex items-center gap-1.5 text-xs font-bold text-blue-400 uppercase tracking-wider pb-1">
              <Zap className="w-3.5 h-3.5" />
              <span>Keyboard Hotkeys</span>
            </div>
            <div className="space-y-1.5">
              {keyboardShortcuts.map((sc, i) => (
                <div
                  key={i}
                  className="flex items-center justify-between p-2 rounded-xl bg-slate-950 border border-slate-800/80 text-xs"
                >
                  <span className="text-slate-300 font-medium truncate pr-2">{sc.desc}</span>
                  <kbd className="px-2 py-0.5 bg-slate-800 text-blue-300 font-mono font-bold rounded-lg border border-slate-700 shadow-sm text-[11px] whitespace-nowrap flex-shrink-0">
                    {sc.key}
                  </kbd>
                </div>
              ))}
            </div>
          </div>

          {/* Mouse Controls */}
          <div className="space-y-2">
            <div className="flex items-center gap-1.5 text-xs font-bold text-purple-400 uppercase tracking-wider pb-1">
              <Mouse className="w-3.5 h-3.5" />
              <span>Mouse & Pen Tool Controls</span>
            </div>
            <div className="space-y-1.5">
              {mouseControls.map((mc, i) => (
                <div
                  key={i}
                  className="p-2 rounded-xl bg-slate-950 border border-slate-800/80 text-xs space-y-1"
                >
                  <div className="font-bold text-purple-300 font-mono text-[11px]">{mc.action}</div>
                  <div className="text-slate-400 text-[11px] leading-snug">{mc.desc}</div>
                </div>
              ))}
            </div>

            <div className="p-3 rounded-2xl bg-blue-600/10 border border-blue-500/20 text-xs text-slate-300 space-y-1 mt-3">
              <span className="font-bold text-white block">💡 Studio Tip:</span>
              <p className="text-[11px] text-slate-400">
                Passport Photo Studio mein <b>Pen Tool</b> se points lagakar kisi bhi photo ka background direct change karein. Live Dual Preview se cut ki hui photo ka preview saath-saath dekhein!
              </p>
            </div>
          </div>
        </div>

        <div className="pt-2 border-t border-slate-800 flex items-center justify-between">
          <span className="text-xs text-slate-500 font-mono">Press ? anytime to open this guide</span>
          <button
            onClick={onClose}
            className="px-5 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-xl shadow-lg shadow-blue-600/30 transition-all hover:scale-105"
          >
            Got It (Esc)
          </button>
        </div>
      </div>
    </div>
  );
};
