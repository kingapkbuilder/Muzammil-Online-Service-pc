import React, { useState, useRef, useEffect, useCallback } from 'react';
import { 
  Upload, 
  Printer, 
  Download, 
  Sparkles, 
  RotateCw, 
  ZoomIn, 
  ZoomOut,
  Palette, 
  Calendar, 
  Sun, 
  Contrast, 
  CheckCircle2, 
  Scissors,
  Wand2,
  Sliders,
  Flame,
  Droplets,
  RotateCcw,
  Check,
  PenTool,
  Move,
  Undo2,
  Redo2,
  Trash2,
  Eye,
  Layers,
  HelpCircle,
  X,
  Maximize2,
  Minimize2,
  Crop,
  Paintbrush,
  Sparkle,
  Image as ImageIcon,
  CheckSquare
} from 'lucide-react';
import { jsPDF } from 'jspdf';
import { addDownloadRecord } from '../utils/storage';
import { printImageSheet } from '../utils/printer';

type PaperFormat = '4x6_landscape' | 'a4_landscape' | '4x6_portrait' | 'a4_portrait';
type ActiveTool = 'select' | 'section_select' | 'magic_wand' | 'pen_tool' | 'crop' | 'blemish_brush' | 'beauty_brush' | 'eye_brighten' | 'hand' | 'zoom';

interface Point {
  x: number;
  y: number;
}

interface BeautyPreset {
  id: string;
  name: string;
  icon: string;
  desc: string;
  settings: {
    brightness: number;
    contrast: number;
    saturation: number;
    warmth: number;
    tint: number;
    skinSmooth: number;
    faceGlow: number;
    shadowLift: number;
    isGrayscale: boolean;
  };
}

const BEAUTY_PRESETS: BeautyPreset[] = [
  {
    id: 'auto_beauty',
    name: 'Auto Studio Beauty',
    icon: '✨',
    desc: 'Smooth skin & radiant facial lighting',
    settings: {
      brightness: 8,
      contrast: 6,
      saturation: 12,
      warmth: 8,
      tint: 4,
      skinSmooth: 20,
      faceGlow: 25,
      shadowLift: 15,
      isGrayscale: false
    }
  },
  {
    id: 'indian_warm',
    name: 'Indian Studio Tone',
    icon: '📸',
    desc: 'Golden warm glow, removes camera pale tone',
    settings: {
      brightness: 6,
      contrast: 8,
      saturation: 15,
      warmth: 18,
      tint: 2,
      skinSmooth: 16,
      faceGlow: 20,
      shadowLift: 12,
      isGrayscale: false
    }
  },
  {
    id: 'glamour_soft',
    name: 'Soft Glamour Glow',
    icon: '🌟',
    desc: 'Airbrushed porcelain skin with soft highlights',
    settings: {
      brightness: 12,
      contrast: 4,
      saturation: 8,
      warmth: 10,
      tint: 6,
      skinSmooth: 32,
      faceGlow: 35,
      shadowLift: 20,
      isGrayscale: false
    }
  },
  {
    id: 'crisp_formal',
    name: 'Sharp Formal ID',
    icon: '💼',
    desc: 'Neutral white balance & crisp facial edges',
    settings: {
      brightness: 4,
      contrast: 12,
      saturation: 5,
      warmth: 0,
      tint: 0,
      skinSmooth: 8,
      faceGlow: 10,
      shadowLift: 8,
      isGrayscale: false
    }
  },
  {
    id: 'cool_clean',
    name: 'Cool White Balance',
    icon: '❄️',
    desc: 'Removes yellow/orange lighting cast',
    settings: {
      brightness: 8,
      contrast: 8,
      saturation: 4,
      warmth: -14,
      tint: -2,
      skinSmooth: 14,
      faceGlow: 15,
      shadowLift: 10,
      isGrayscale: false
    }
  },
  {
    id: 'bw_formal',
    name: 'B&W Official Exam',
    icon: '🖤',
    desc: 'High contrast monochrome for SSC/UPSC',
    settings: {
      brightness: 6,
      contrast: 16,
      saturation: 0,
      warmth: 0,
      tint: 0,
      skinSmooth: 12,
      faceGlow: 10,
      shadowLift: 10,
      isGrayscale: true
    }
  }
];

export const PassportStudioView: React.FC = () => {
  // Main Sheet Canvas (Hidden or rendered for 4x6 / A4 sheet calculation)
  const fullSheetCanvasRef = useRef<HTMLCanvasElement | null>(null);
  
  // Photoshop-Style Editing Canvas (Primary interactive workspace)
  const editorCanvasRef = useRef<HTMLCanvasElement | null>(null);
  
  // Mini Preview Canvas (Compact Sheet Preview widget)
  const miniPreviewCanvasRef = useRef<HTMLCanvasElement | null>(null);

  // Active Tool Selection (Photoshop Toolbar)
  const [activeTool, setActiveTool] = useState<ActiveTool>('select');

  // Photo Source & History Stack for Undo / Redo
  const [photoSrc, setPhotoSrc] = useState<string | null>(null);
  const [originalPhotoSrc, setOriginalPhotoSrc] = useState<string | null>(null);
  const [historyStack, setHistoryStack] = useState<string[]>([]);
  const [historyIndex, setHistoryIndex] = useState<number>(-1);

  const photoImgRef = useRef<HTMLImageElement | null>(null);

  // Paper & Layout settings: Default is 4x6 LANDSCAPE with 8 COPIES
  const [paperFormat, setPaperFormat] = useState<PaperFormat>('4x6_landscape');
  const [copies, setCopies] = useState<number>(8);

  // Studio background replacement color
  const [bgColor, setBgColor] = useState<string>('#ffffff');

  // Mini Preview Visibility State (Collapsible / Expandable)
  const [showMiniPreview, setShowMiniPreview] = useState<boolean>(true);

  // Auto Beauty Mode Toggle
  const [autoBeauty, setAutoBeauty] = useState<boolean>(true);
  const [activePreset, setActivePreset] = useState<string>('auto_beauty');

  // Color Grading Parameters
  const [brightness, setBrightness] = useState<number>(8);
  const [contrast, setContrast] = useState<number>(6);
  const [saturation, setSaturation] = useState<number>(12);
  const [warmth, setWarmth] = useState<number>(8);
  const [tint, setTint] = useState<number>(4);
  const [shadowLift, setShadowLift] = useState<number>(15);
  const [skinSmooth, setSkinSmooth] = useState<number>(20);
  const [faceGlow, setFaceGlow] = useState<number>(25);
  const [isGrayscale, setIsGrayscale] = useState<boolean>(false);

  // Canvas Viewport Pan & Zoom
  const [canvasZoom, setCanvasZoom] = useState<number>(1.0);
  const [canvasPan, setCanvasPan] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isSpacePressed, setIsSpacePressed] = useState<boolean>(false);
  const [isPanning, setIsPanning] = useState<boolean>(false);
  const [panStart, setPanStart] = useState<{ x: number; y: number }>({ x: 0, y: 0 });

  // Tool Specific States:
  // 1. Magic Wand / Magic Cut
  const [magicTolerance, setMagicTolerance] = useState<number>(32);
  const [magicFeather, setMagicFeather] = useState<number>(2);

  // 2. Pen Tool (Manual Vector Cutout)
  const [penPoints, setPenPoints] = useState<Point[]>([]);
  const [isPathClosed, setIsPathClosed] = useState<boolean>(false);
  const [isNearStartPoint, setIsNearStartPoint] = useState<boolean>(false);
  const [penFeather, setPenFeather] = useState<number>(2);

  // 3. Brushes (Blemish, Beauty, Eye Brighten)
  const [brushSize, setBrushSize] = useState<number>(24);
  const [isBrushing, setIsBrushing] = useState<boolean>(false);

  // 4. Crop Tool
  const [cropBox, setCropBox] = useState<{ x: number; y: number; w: number; h: number } | null>(null);

  // 5. Section Selection & Local Color Grading State
  const [selectionBox, setSelectionBox] = useState<{ x: number; y: number; w: number; h: number } | null>(null);
  const [isSelectingBox, setIsSelectingBox] = useState<boolean>(false);
  const [selectionStartNorm, setSelectionStartNorm] = useState<{ x: number; y: number } | null>(null);
  const [gradingScope, setGradingScope] = useState<'full' | 'selection'>('full');

  // Local section color grading parameters
  const [secBrightness, setSecBrightness] = useState<number>(15);
  const [secContrast, setSecContrast] = useState<number>(12);
  const [secWarmth, setSecWarmth] = useState<number>(0);
  const [secSaturation, setSecSaturation] = useState<number>(0);
  const [secSmooth, setSecSmooth] = useState<number>(15);
  const [secFeather, setSecFeather] = useState<number>(8);

  // Exam Name & Date overlay (for SSC, Police Bharti, UPSC)
  const [showNameDate, setShowNameDate] = useState<boolean>(false);
  const [candidateName, setCandidateName] = useState<string>('CANDIDATE NAME');
  const [photoDate, setPhotoDate] = useState<string>(
    new Date().toLocaleDateString('en-IN', { day: '2-digit', month: '2-digit', year: 'numeric' })
  );

  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [printAlert, setPrintAlert] = useState<string | null>(null);

  // 300 DPI Canvas Dimensions for full sheet
  let SHEET_WIDTH = 1800;
  let SHEET_HEIGHT = 1200;

  if (paperFormat === '4x6_landscape') {
    SHEET_WIDTH = 1800;
    SHEET_HEIGHT = 1200;
  } else if (paperFormat === 'a4_landscape') {
    SHEET_WIDTH = 3508;
    SHEET_HEIGHT = 2480;
  } else if (paperFormat === '4x6_portrait') {
    SHEET_WIDTH = 1200;
    SHEET_HEIGHT = 1800;
  } else {
    SHEET_WIDTH = 2480;
    SHEET_HEIGHT = 3508;
  }

  // -------------------------------------------------------------
  // KEYBOARD SHORTCUTS LISTENER (Photoshop Standard: V, C, W, P, B, S, H, Z, Ctrl+Z, Ctrl+P)
  // -------------------------------------------------------------
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't trigger if user is typing in text input
      if ((e.target as HTMLElement).tagName === 'INPUT' || (e.target as HTMLElement).tagName === 'TEXTAREA') {
        return;
      }

      // Spacebar for temporary Hand Pan tool
      if (e.code === 'Space' && !e.repeat) {
        setIsSpacePressed(true);
      }

      // Undo: Ctrl + Z
      if (e.ctrlKey && e.key.toLowerCase() === 'z' && !e.shiftKey) {
        e.preventDefault();
        handleUndo();
      }

      // Redo: Ctrl + Y or Ctrl + Shift + Z
      if ((e.ctrlKey && e.key.toLowerCase() === 'y') || (e.ctrlKey && e.shiftKey && e.key.toLowerCase() === 'z')) {
        e.preventDefault();
        handleRedo();
      }

      // Tools Switcher Shortcuts:
      if (!e.ctrlKey && !e.altKey && !e.metaKey) {
        switch (e.key.toLowerCase()) {
          case 'v': setActiveTool('select'); break;
          case 'q': setActiveTool('section_select'); setGradingScope('selection'); break;
          case 'r': handleAutoBackgroundErase(); break;
          case 'c': setActiveTool('crop'); initCropBox(); break;
          case 'w': setActiveTool('magic_wand'); break;
          case 'p': setActiveTool('pen_tool'); break;
          case 'b': setActiveTool('blemish_brush'); break;
          case 's': setActiveTool('beauty_brush'); break;
          case 'e': setActiveTool('eye_brighten'); break;
          case 'h': setActiveTool('hand'); break;
          case 'z': setActiveTool('zoom'); break;
          case 'm': setShowMiniPreview(prev => !prev); break;
          case '[': setBrushSize(prev => Math.max(8, prev - 4)); break;
          case ']': setBrushSize(prev => Math.min(80, prev + 4)); break;
          case 'escape': 
            if (activeTool === 'pen_tool') {
              setPenPoints([]);
              setIsPathClosed(false);
            }
            if (activeTool === 'crop') {
              setCropBox(null);
              setActiveTool('select');
            }
            break;
        }
      }

      // Zoom Shortcuts: Ctrl + '+' / Ctrl + '-' / Ctrl + '0'
      if (e.ctrlKey && (e.key === '=' || e.key === '+')) {
        e.preventDefault();
        setCanvasZoom(prev => Math.min(4.0, prev + 0.25));
      }
      if (e.ctrlKey && (e.key === '-' || e.key === '_')) {
        e.preventDefault();
        setCanvasZoom(prev => Math.max(0.4, prev - 0.25));
      }
      if (e.ctrlKey && e.key === '0') {
        e.preventDefault();
        setCanvasZoom(1.0);
        setCanvasPan({ x: 0, y: 0 });
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      if (e.code === 'Space') {
        setIsSpacePressed(false);
        setIsPanning(false);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [activeTool, historyIndex, historyStack]);

  // Push new state to undo/redo history
  const pushToHistory = (newSrc: string) => {
    setHistoryStack(prev => {
      const upToCurrent = prev.slice(0, historyIndex + 1);
      const updated = [...upToCurrent, newSrc];
      if (updated.length > 15) updated.shift();
      return updated;
    });
    setHistoryIndex(prev => Math.min(14, prev + 1));
  };

  const handleUndo = () => {
    if (activeTool === 'pen_tool' && penPoints.length > 0) {
      if (isPathClosed) {
        setIsPathClosed(false);
      } else {
        setPenPoints(prev => prev.slice(0, -1));
      }
      return;
    }

    if (historyIndex > 0) {
      const nextIdx = historyIndex - 1;
      setHistoryIndex(nextIdx);
      setPhotoSrc(historyStack[nextIdx]);
    }
  };

  const handleRedo = () => {
    if (historyIndex < historyStack.length - 1) {
      const nextIdx = historyIndex + 1;
      setHistoryIndex(nextIdx);
      setPhotoSrc(historyStack[nextIdx]);
    }
  };

  // Load photo into Image object
  useEffect(() => {
    if (photoSrc) {
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.onload = () => {
        photoImgRef.current = img;
        renderEditorCanvas();
        renderMiniPreview();
        renderFullSheet();
      };
      img.src = photoSrc;
    } else {
      photoImgRef.current = null;
      renderEditorCanvas();
      renderMiniPreview();
      renderFullSheet();
    }
  }, [photoSrc]);

  // Re-render when adjustments change
  useEffect(() => {
    renderEditorCanvas();
    renderMiniPreview();
    renderFullSheet();
  }, [
    photoSrc,
    activeTool,
    penPoints,
    isPathClosed,
    isNearStartPoint,
    cropBox,
    canvasZoom,
    canvasPan,
    bgColor,
    autoBeauty,
    brightness,
    contrast,
    saturation,
    warmth,
    tint,
    shadowLift,
    skinSmooth,
    faceGlow,
    isGrayscale,
    paperFormat,
    copies,
    showNameDate,
    candidateName,
    photoDate
  ]);

  // Initialize crop box to 35:45 ratio
  const initCropBox = () => {
    const canvas = editorCanvasRef.current;
    if (!canvas) return;
    const w = Math.min(canvas.width * 0.7, canvas.height * 0.7 * (35 / 45));
    const h = w * (45 / 35);
    setCropBox({
      x: (canvas.width - w) / 2,
      y: (canvas.height - h) / 2,
      w,
      h
    });
  };

  // Apply Crop
  const handleApplyCrop = () => {
    const canvas = editorCanvasRef.current;
    const img = photoImgRef.current;
    if (!canvas || !img || !cropBox) return;

    try {
      const cropCanvas = document.createElement('canvas');
      cropCanvas.width = 700;
      cropCanvas.height = 900;
      const cCtx = cropCanvas.getContext('2d');
      if (!cCtx) return;

      // Extract cropped area from editor canvas
      cCtx.drawImage(
        canvas,
        cropBox.x,
        cropBox.y,
        cropBox.w,
        cropBox.h,
        0,
        0,
        cropCanvas.width,
        cropCanvas.height
      );

      const croppedUrl = cropCanvas.toDataURL('image/jpeg', 0.98);
      setPhotoSrc(croppedUrl);
      pushToHistory(croppedUrl);
      setCropBox(null);
      setActiveTool('select');
      setPrintAlert('✂️ Photo cropped to 35×45mm passport ratio!');
      setTimeout(() => setPrintAlert(null), 3000);
    } catch (e) {
      console.error(e);
    }
  };

  // -------------------------------------------------------------
  // MAGIC WAND / MAGIC CUT (FIXED & HIGH-PRECISION FLOOD FILL)
  // -------------------------------------------------------------
  // BFS Connected Flood-Fill from clicked pixel
  const executeMagicWandCut = (clickX: number, clickY: number) => {
    const img = photoImgRef.current;
    if (!img) return;

    setIsProcessing(true);

    try {
      const workCanvas = document.createElement('canvas');
      workCanvas.width = img.width;
      workCanvas.height = img.height;
      const wCtx = workCanvas.getContext('2d');
      if (!wCtx) return;

      wCtx.drawImage(img, 0, 0);
      const imgData = wCtx.getImageData(0, 0, workCanvas.width, workCanvas.height);
      const data = imgData.data;
      const w = workCanvas.width;
      const h = workCanvas.height;

      // Scale clickX, clickY to original image pixels
      const startX = Math.floor(Math.max(0, Math.min(w - 1, clickX)));
      const startY = Math.floor(Math.max(0, Math.min(h - 1, clickY)));
      const startIndex = (startY * w + startX) * 4;

      const targetR = data[startIndex];
      const targetG = data[startIndex + 1];
      const targetB = data[startIndex + 2];

      // Parse target background color
      const dummy = document.createElement('div');
      dummy.style.color = bgColor;
      document.body.appendChild(dummy);
      const computed = window.getComputedStyle(dummy).color;
      document.body.removeChild(dummy);
      const rgb = computed.match(/\d+/g)?.map(Number) || [255, 255, 255];

      // Visited array to prevent infinite loop
      const visited = new Uint8Array(w * h);
      const queue: number[] = [startX + startY * w];
      visited[startX + startY * w] = 1;

      const tolSq = Math.pow(magicTolerance * 2.2, 2);

      // BFS flood fill
      let head = 0;
      while (head < queue.length) {
        const curr = queue[head++];
        const cx = curr % w;
        const cy = Math.floor(curr / w);
        const idx = curr * 4;

        // Replace pixel color with studio background
        data[idx] = rgb[0];
        data[idx + 1] = rgb[1];
        data[idx + 2] = rgb[2];
        data[idx + 3] = 255;

        // Check 4-directional neighbors
        const neighbors = [
          [cx + 1, cy],
          [cx - 1, cy],
          [cx, cy + 1],
          [cx, cy - 1]
        ];

        for (let i = 0; i < 4; i++) {
          const nx = neighbors[i][0];
          const ny = neighbors[i][1];

          if (nx >= 0 && nx < w && ny >= 0 && ny < h) {
            const nPos = nx + ny * w;
            if (!visited[nPos]) {
              const nIdx = nPos * 4;
              const nr = data[nIdx];
              const ng = data[nIdx + 1];
              const nb = data[nIdx + 2];

              // Color distance from target
              const distSq =
                Math.pow(nr - targetR, 2) +
                Math.pow(ng - targetG, 2) +
                Math.pow(nb - targetB, 2);

              if (distSq <= tolSq) {
                visited[nPos] = 1;
                queue.push(nPos);
              }
            }
          }
        }
      }

      wCtx.putImageData(imgData, 0, 0);
      const resDataUrl = workCanvas.toDataURL('image/jpeg', 0.98);

      if (!originalPhotoSrc && photoSrc) {
        setOriginalPhotoSrc(photoSrc);
      }

      setPhotoSrc(resDataUrl);
      pushToHistory(resDataUrl);
      setPrintAlert(`🪄 Magic Wand erased connected background at (${startX}, ${startY})!`);
      setTimeout(() => setPrintAlert(null), 3000);
    } catch (e) {
      console.error(e);
    } finally {
      setIsProcessing(false);
    }
  };

  // 1-Click Auto Background Eraser (Seeds flood fill from all 4 outer borders)
  const handleAutoBackgroundErase = () => {
    const img = photoImgRef.current;
    if (!img) return;

    setIsProcessing(true);

    try {
      const workCanvas = document.createElement('canvas');
      workCanvas.width = img.width;
      workCanvas.height = img.height;
      const wCtx = workCanvas.getContext('2d');
      if (!wCtx) return;

      wCtx.drawImage(img, 0, 0);
      const imgData = wCtx.getImageData(0, 0, workCanvas.width, workCanvas.height);
      const data = imgData.data;
      const w = workCanvas.width;
      const h = workCanvas.height;

      // Target background color parse
      const isTransparent = bgColor === 'transparent';
      let rgb = [255, 255, 255];
      if (!isTransparent) {
        const dummy = document.createElement('div');
        dummy.style.color = bgColor;
        document.body.appendChild(dummy);
        const computed = window.getComputedStyle(dummy).color;
        document.body.removeChild(dummy);
        rgb = computed.match(/\d+/g)?.map(Number) || [255, 255, 255];
      }

      // Sample reference background color from top corners
      const cornerR = (data[0] + data[(w - 1) * 4]) / 2;
      const cornerG = (data[1] + data[(w - 1) * 4 + 1]) / 2;
      const cornerB = (data[2] + data[(w - 1) * 4 + 2]) / 2;

      const visited = new Uint8Array(w * h);
      const queue: number[] = [];

      // Seed all 4 outer borders
      for (let x = 0; x < w; x++) {
        queue.push(x); // top
        queue.push(x + (h - 1) * w); // bottom
        visited[x] = 1;
        visited[x + (h - 1) * w] = 1;
      }
      for (let y = 0; y < h; y++) {
        queue.push(y * w); // left
        queue.push((w - 1) + y * w); // right
        visited[y * w] = 1;
        visited[(w - 1) + y * w] = 1;
      }

      const tolSq = Math.pow(magicTolerance * 2.2, 2);

      let head = 0;
      while (head < queue.length) {
        const curr = queue[head++];
        const cx = curr % w;
        const cy = Math.floor(curr / w);
        const idx = curr * 4;

        // Replace background pixel
        if (isTransparent) {
          data[idx + 3] = 0; // Transparent cutout
        } else {
          data[idx] = rgb[0];
          data[idx + 1] = rgb[1];
          data[idx + 2] = rgb[2];
          data[idx + 3] = 255;
        }

        const neighbors = [
          [cx + 1, cy],
          [cx - 1, cy],
          [cx, cy + 1],
          [cx, cy - 1]
        ];

        for (let i = 0; i < 4; i++) {
          const nx = neighbors[i][0];
          const ny = neighbors[i][1];

          if (nx >= 0 && nx < w && ny >= 0 && ny < h) {
            const nPos = nx + ny * w;
            if (!visited[nPos]) {
              const nIdx = nPos * 4;
              const nr = data[nIdx];
              const ng = data[nIdx + 1];
              const nb = data[nIdx + 2];

              const distSq =
                Math.pow(nr - cornerR, 2) +
                Math.pow(ng - cornerG, 2) +
                Math.pow(nb - cornerB, 2);

              if (distSq <= tolSq) {
                visited[nPos] = 1;
                queue.push(nPos);
              }
            }
          }
        }
      }

      wCtx.putImageData(imgData, 0, 0);
      const resDataUrl = workCanvas.toDataURL(isTransparent ? 'image/png' : 'image/jpeg', 0.98);

      if (!originalPhotoSrc && photoSrc) {
        setOriginalPhotoSrc(photoSrc);
      }

      setPhotoSrc(resDataUrl);
      pushToHistory(resDataUrl);
      setPrintAlert(isTransparent ? '✨ 1-Click Transparent Background Cutout created!' : '✨ 1-Click Magic Auto Background successfully replaced!');
      setTimeout(() => setPrintAlert(null), 3000);
    } catch (e) {
      console.error(e);
    } finally {
      setIsProcessing(false);
    }
  };

  // -------------------------------------------------------------
  // SPOT BLEMISH REMOVER & BEAUTY BRUSH
  // -------------------------------------------------------------
  const applyHealingBrush = (centerX: number, centerY: number, mode: 'blemish' | 'beauty' | 'eye') => {
    const img = photoImgRef.current;
    if (!img) return;

    try {
      const workCanvas = document.createElement('canvas');
      workCanvas.width = img.width;
      workCanvas.height = img.height;
      const wCtx = workCanvas.getContext('2d');
      if (!wCtx) return;

      wCtx.drawImage(img, 0, 0);

      const rad = brushSize;
      const x = Math.max(0, Math.min(img.width, centerX));
      const y = Math.max(0, Math.min(img.height, centerY));

      if (mode === 'blemish') {
        // Sample surrounding ring of skin pixels and blend into center
        const imgData = wCtx.getImageData(
          Math.max(0, x - rad),
          Math.max(0, y - rad),
          rad * 2,
          rad * 2
        );
        const data = imgData.data;

        // Average surrounding ring
        let rSum = 0, gSum = 0, bSum = 0, count = 0;
        for (let py = 0; py < rad * 2; py++) {
          for (let px = 0; px < rad * 2; px++) {
            const d = Math.hypot(px - rad, py - rad);
            if (d >= rad * 0.7 && d <= rad) {
              const i = (py * rad * 2 + px) * 4;
              rSum += data[i];
              gSum += data[i + 1];
              bSum += data[i + 2];
              count++;
            }
          }
        }

        if (count > 0) {
          const avgR = rSum / count;
          const avgG = gSum / count;
          const avgB = bSum / count;

          for (let py = 0; py < rad * 2; py++) {
            for (let px = 0; px < rad * 2; px++) {
              const d = Math.hypot(px - rad, py - rad);
              if (d < rad) {
                const i = (py * rad * 2 + px) * 4;
                const alphaWeight = 1 - (d / rad);
                data[i] = data[i] * (1 - alphaWeight) + avgR * alphaWeight;
                data[i + 1] = data[i + 1] * (1 - alphaWeight) + avgG * alphaWeight;
                data[i + 2] = data[i + 2] * (1 - alphaWeight) + avgB * alphaWeight;
              }
            }
          }
          wCtx.putImageData(imgData, Math.max(0, x - rad), Math.max(0, y - rad));
        }
      } else if (mode === 'beauty') {
        // Soft skin airbrush blur
        wCtx.save();
        wCtx.beginPath();
        wCtx.arc(x, y, rad, 0, Math.PI * 2);
        wCtx.clip();
        wCtx.filter = 'blur(4px) brightness(105%)';
        wCtx.drawImage(img, 0, 0);
        wCtx.restore();
      } else {
        // Eye & Teeth Whitener
        wCtx.save();
        wCtx.beginPath();
        wCtx.arc(x, y, rad, 0, Math.PI * 2);
        wCtx.clip();
        wCtx.filter = 'brightness(118%) contrast(106%) saturate(60%)';
        wCtx.drawImage(img, 0, 0);
        wCtx.restore();
      }

      const resDataUrl = workCanvas.toDataURL('image/jpeg', 0.98);
      setPhotoSrc(resDataUrl);
      pushToHistory(resDataUrl);
    } catch (e) {
      console.error(e);
    }
  };

  // -------------------------------------------------------------
  // PEN TOOL: APPLY VECTOR CUTOUT
  // -------------------------------------------------------------
  const handleApplyPenCutout = () => {
    const img = photoImgRef.current;
    if (!img || penPoints.length < 3) return;

    try {
      const workCanvas = document.createElement('canvas');
      workCanvas.width = img.width;
      workCanvas.height = img.height;
      const wCtx = workCanvas.getContext('2d');
      if (!wCtx) return;

      // 1. Fill studio background
      wCtx.fillStyle = bgColor;
      wCtx.fillRect(0, 0, workCanvas.width, workCanvas.height);

      // 2. Create offscreen person layer clipped to path
      const personCanvas = document.createElement('canvas');
      personCanvas.width = img.width;
      personCanvas.height = img.height;
      const pCtx = personCanvas.getContext('2d');

      if (pCtx) {
        pCtx.drawImage(img, 0, 0);

        const maskCanvas = document.createElement('canvas');
        maskCanvas.width = img.width;
        maskCanvas.height = img.height;
        const mCtx = maskCanvas.getContext('2d');

        if (mCtx) {
          if (penFeather > 0) {
            mCtx.filter = `blur(${penFeather}px)`;
          }

          mCtx.beginPath();
          mCtx.moveTo(penPoints[0].x * img.width, penPoints[0].y * img.height);
          for (let i = 1; i < penPoints.length; i++) {
            mCtx.lineTo(penPoints[i].x * img.width, penPoints[i].y * img.height);
          }
          mCtx.closePath();
          mCtx.fillStyle = '#000000';
          mCtx.fill();

          pCtx.globalCompositeOperation = 'destination-in';
          pCtx.drawImage(maskCanvas, 0, 0);
        }

        wCtx.drawImage(personCanvas, 0, 0);
      }

      const resDataUrl = workCanvas.toDataURL('image/jpeg', 0.98);
      if (!originalPhotoSrc && photoSrc) {
        setOriginalPhotoSrc(photoSrc);
      }

      setPhotoSrc(resDataUrl);
      pushToHistory(resDataUrl);
      setPenPoints([]);
      setIsPathClosed(false);
      setActiveTool('select');
      setPrintAlert('🖊️ Pen Tool Cutout applied successfully!');
      setTimeout(() => setPrintAlert(null), 3000);
    } catch (e) {
      console.error(e);
    }
  };

  // -------------------------------------------------------------
  // SECTION SELECTION & LOCAL COLOR GRADING HANDLERS
  // -------------------------------------------------------------
  const handleSelectPreset = (type: 'face' | 'clothes' | 'eyes' | 'full') => {
    switch (type) {
      case 'face':
        setSelectionBox({ x: 0.18, y: 0.10, w: 0.64, h: 0.52 });
        break;
      case 'clothes':
        setSelectionBox({ x: 0.05, y: 0.58, w: 0.90, h: 0.42 });
        break;
      case 'eyes':
        setSelectionBox({ x: 0.22, y: 0.24, w: 0.56, h: 0.20 });
        break;
      case 'full':
        setSelectionBox({ x: 0.02, y: 0.02, w: 0.96, h: 0.96 });
        break;
    }
    setActiveTool('section_select');
    setGradingScope('selection');
  };

  const handleClearSelection = () => {
    setSelectionBox(null);
    setGradingScope('full');
  };

  const handleInvertSelection = () => {
    if (!selectionBox) return;
    // Invert selection box coordinates
    setSelectionBox({
      x: Math.max(0, 1 - (selectionBox.x + selectionBox.w)),
      y: selectionBox.y,
      w: selectionBox.w,
      h: selectionBox.h
    });
  };

  const handleBakeSectionAdjustment = () => {
    const img = photoImgRef.current;
    if (!img || !selectionBox) return;

    setIsProcessing(true);
    try {
      const workCanvas = document.createElement('canvas');
      workCanvas.width = img.width;
      workCanvas.height = img.height;
      const wCtx = workCanvas.getContext('2d');
      if (!wCtx) return;

      // 1. Draw base photo
      wCtx.drawImage(img, 0, 0);

      // 2. Draw section with local adjustments
      const secX = selectionBox.x * img.width;
      const secY = selectionBox.y * img.height;
      const secW = selectionBox.w * img.width;
      const secH = selectionBox.h * img.height;

      wCtx.save();
      wCtx.beginPath();
      wCtx.rect(secX, secY, secW, secH);
      wCtx.clip();

      const secEffBright = 100 + secBrightness;
      const secEffCont = 100 + secContrast;
      const secEffSat = 100 + secSaturation;
      wCtx.filter = `brightness(${secEffBright}%) contrast(${secEffCont}%) saturate(${secEffSat}%)`;
      wCtx.drawImage(img, 0, 0);

      if (secWarmth !== 0 && !isGrayscale) {
        wCtx.globalCompositeOperation = 'color';
        wCtx.fillStyle = secWarmth > 0
          ? `rgba(255, 175, 75, ${Math.min(0.45, (secWarmth / 100) * 0.5)})`
          : `rgba(80, 165, 255, ${Math.min(0.45, (Math.abs(secWarmth) / 100) * 0.5)})`;
        wCtx.fillRect(secX, secY, secW, secH);
      }

      wCtx.restore();

      const resDataUrl = workCanvas.toDataURL('image/jpeg', 0.98);
      if (!originalPhotoSrc && photoSrc) {
        setOriginalPhotoSrc(photoSrc);
      }
      setPhotoSrc(resDataUrl);
      pushToHistory(resDataUrl);
      setPrintAlert('✅ Section color grading permanently baked into photo!');
      setTimeout(() => setPrintAlert(null), 4000);
    } catch (e) {
      console.error(e);
    } finally {
      setIsProcessing(false);
    }
  };

  // -------------------------------------------------------------
  // MAIN EDITOR CANVAS RENDER (Central Photoshop-Style Workspace)
  // -------------------------------------------------------------
  const renderEditorCanvas = () => {
    const canvas = editorCanvasRef.current;
    const img = photoImgRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Fixed internal size for sharp 2K editing canvas
    canvas.width = 900;
    canvas.height = 700;

    // Dark workspace checkered background
    ctx.fillStyle = '#090d16';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    if (!img) {
      // Empty state
      ctx.fillStyle = '#64748b';
      ctx.font = 'bold 16px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('Upload or Drag Customer Photo to Edit', canvas.width / 2, canvas.height / 2 - 10);
      ctx.font = '12px sans-serif';
      ctx.fillText('Photoshop-style tools: Pen, Magic Wand, Blemish, Crop, Auto Beauty', canvas.width / 2, canvas.height / 2 + 15);
      return;
    }

    ctx.save();

    // Pan & Zoom transformations
    ctx.translate(canvas.width / 2 + canvasPan.x, canvas.height / 2 + canvasPan.y);
    ctx.scale(canvasZoom, canvasZoom);

    // Calculate dimensions maintaining aspect ratio
    const aspect = img.width / img.height;
    let renderW = 460;
    let renderH = 460 / aspect;
    if (renderH > 560) {
      renderH = 560;
      renderW = 560 * aspect;
    }

    const drawX = -renderW / 2;
    const drawY = -renderH / 2;

    // Apply color grading filters
    const effBrightness = 100 + brightness + (autoBeauty ? 6 : 0) + (faceGlow * 0.12);
    const effContrast = 100 + contrast + (autoBeauty ? 4 : 0);
    const effSaturation = isGrayscale ? 0 : 100 + saturation + (autoBeauty ? 8 : 0);

    let filterStr = `brightness(${effBrightness}%) contrast(${effContrast}%) saturate(${effSaturation}%)`;
    if (isGrayscale) filterStr += ' grayscale(100%)';

    ctx.filter = filterStr;
    ctx.drawImage(img, drawX, drawY, renderW, renderH);

    // Soft Beauty Layer (Soft-Light pass)
    const effSmooth = autoBeauty ? Math.max(skinSmooth, 16) : skinSmooth;
    const effGlow = autoBeauty ? Math.max(faceGlow, 20) : faceGlow;
    if (effSmooth > 0 || effGlow > 0) {
      ctx.save();
      ctx.globalCompositeOperation = 'soft-light';
      ctx.globalAlpha = Math.min(0.65, (effSmooth * 0.012) + (effGlow * 0.01));
      ctx.filter = `blur(${Math.max(2, effSmooth / 8)}px) brightness(120%)`;
      ctx.drawImage(img, drawX, drawY, renderW, renderH);
      ctx.restore();
    }

    // Warmth & Tint
    if (warmth !== 0 && !isGrayscale) {
      ctx.save();
      ctx.globalCompositeOperation = 'color';
      ctx.fillStyle = warmth > 0
        ? `rgba(255, 175, 75, ${Math.min(0.35, (warmth / 100) * 0.4)})`
        : `rgba(80, 165, 255, ${Math.min(0.35, (Math.abs(warmth) / 100) * 0.4)})`;
      ctx.fillRect(drawX, drawY, renderW, renderH);
      ctx.restore();
    }

    if (tint !== 0 && !isGrayscale) {
      ctx.save();
      ctx.globalCompositeOperation = 'color';
      ctx.fillStyle = tint > 0
        ? `rgba(255, 60, 180, ${Math.min(0.25, (tint / 100) * 0.3)})`
        : `rgba(60, 220, 100, ${Math.min(0.25, (Math.abs(tint) / 100) * 0.3)})`;
      ctx.fillRect(drawX, drawY, renderW, renderH);
      ctx.restore();
    }

    // -------------------------------------------------------------
    // LOCAL SECTION COLOR GRADING OVERLAY (Inside Photo Coordinates)
    // -------------------------------------------------------------
    if (selectionBox && selectionBox.w > 0.005 && selectionBox.h > 0.005) {
      const secX = drawX + selectionBox.x * renderW;
      const secY = drawY + selectionBox.y * renderH;
      const secW = selectionBox.w * renderW;
      const secH = selectionBox.h * renderH;

      ctx.save();
      ctx.beginPath();
      ctx.rect(secX, secY, secW, secH);
      ctx.clip();

      const secEffBright = effBrightness + secBrightness;
      const secEffCont = effContrast + secContrast;
      const secEffSat = isGrayscale ? 0 : effSaturation + secSaturation;

      ctx.filter = `brightness(${secEffBright}%) contrast(${secEffCont}%) saturate(${secEffSat}%)`;
      ctx.drawImage(img, drawX, drawY, renderW, renderH);

      // Local Soft Airbrush Pass
      if (secSmooth > 0) {
        ctx.save();
        ctx.globalCompositeOperation = 'soft-light';
        ctx.globalAlpha = Math.min(0.65, secSmooth * 0.015);
        ctx.filter = `blur(${Math.max(2, secSmooth / 7)}px) brightness(120%)`;
        ctx.drawImage(img, drawX, drawY, renderW, renderH);
        ctx.restore();
      }

      // Local Warmth
      if (secWarmth !== 0 && !isGrayscale) {
        ctx.save();
        ctx.globalCompositeOperation = 'color';
        ctx.fillStyle = secWarmth > 0
          ? `rgba(255, 175, 75, ${Math.min(0.45, (secWarmth / 100) * 0.5)})`
          : `rgba(80, 165, 255, ${Math.min(0.45, (Math.abs(secWarmth) / 100) * 0.5)})`;
        ctx.fillRect(secX, secY, secW, secH);
        ctx.restore();
      }

      ctx.restore();

      // Draw Animated Cyan Selection Marquee
      ctx.save();
      ctx.strokeStyle = '#06b6d4';
      ctx.lineWidth = 2.5;
      ctx.setLineDash([8, 6]);
      ctx.strokeRect(secX, secY, secW, secH);

      // Corner handles
      const handleSize = 8;
      ctx.fillStyle = '#ffffff';
      ctx.strokeStyle = '#0891b2';
      ctx.lineWidth = 1.5;
      ctx.setLineDash([]);
      [
        [secX, secY],
        [secX + secW, secY],
        [secX, secY + secH],
        [secX + secW, secY + secH]
      ].forEach(([hx, hy]) => {
        ctx.fillRect(hx - handleSize / 2, hy - handleSize / 2, handleSize, handleSize);
        ctx.strokeRect(hx - handleSize / 2, hy - handleSize / 2, handleSize, handleSize);
      });

      // Section Badge
      ctx.fillStyle = 'rgba(6, 182, 212, 0.95)';
      ctx.fillRect(secX, Math.max(drawY, secY - 24), 170, 22);
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 12px sans-serif';
      ctx.fillText(`🎯 Section (${secBrightness > 0 ? '+' : ''}${secBrightness}B / ${secContrast > 0 ? '+' : ''}${secContrast}C)`, secX + 6, Math.max(drawY, secY - 24) + 16);
      ctx.restore();
    }

    ctx.restore();

    // -------------------------------------------------------------
    // OVERLAYS: Pen Tool Path / Crop Box
    // -------------------------------------------------------------
    // Pen Tool Path
    if (activeTool === 'pen_tool' && penPoints.length > 0) {
      ctx.save();
      ctx.translate(canvas.width / 2 + canvasPan.x, canvas.height / 2 + canvasPan.y);
      ctx.scale(canvasZoom, canvasZoom);

      ctx.beginPath();
      const firstX = drawX + penPoints[0].x * renderW;
      const firstY = drawY + penPoints[0].y * renderH;
      ctx.moveTo(firstX, firstY);

      for (let i = 1; i < penPoints.length; i++) {
        const px = drawX + penPoints[i].x * renderW;
        const py = drawY + penPoints[i].y * renderH;
        ctx.lineTo(px, py);
      }

      if (isPathClosed) {
        ctx.closePath();
        ctx.fillStyle = 'rgba(14, 165, 233, 0.25)';
        ctx.fill();
      }

      ctx.strokeStyle = isPathClosed ? '#10b981' : '#38bdf8';
      ctx.lineWidth = 2 / canvasZoom;
      ctx.setLineDash(isPathClosed ? [] : [4, 4]);
      ctx.stroke();

      // Points
      penPoints.forEach((pt, idx) => {
        const px = drawX + pt.x * renderW;
        const py = drawY + pt.y * renderH;
        const isFirst = idx === 0;

        ctx.beginPath();
        ctx.arc(px, py, (isFirst ? 7 : 5) / canvasZoom, 0, Math.PI * 2);
        ctx.fillStyle = isFirst ? (isNearStartPoint ? '#22c55e' : '#eab308') : '#38bdf8';
        ctx.strokeStyle = '#0f172a';
        ctx.lineWidth = 2 / canvasZoom;
        ctx.fill();
        ctx.stroke();
      });

      ctx.restore();
    }

    // Crop Tool Box Overlay
    if (activeTool === 'crop' && cropBox) {
      ctx.save();
      // Dim outer area
      ctx.fillStyle = 'rgba(0, 0, 0, 0.6)';
      ctx.fillRect(0, 0, canvas.width, cropBox.y);
      ctx.fillRect(0, cropBox.y + cropBox.h, canvas.width, canvas.height - (cropBox.y + cropBox.h));
      ctx.fillRect(0, cropBox.y, cropBox.x, cropBox.h);
      ctx.fillRect(cropBox.x + cropBox.w, cropBox.y, canvas.width - (cropBox.x + cropBox.w), cropBox.h);

      // Crop border
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 2;
      ctx.strokeRect(cropBox.x, cropBox.y, cropBox.w, cropBox.h);

      // Rule of thirds lines
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.3)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(cropBox.x + cropBox.w / 3, cropBox.y);
      ctx.lineTo(cropBox.x + cropBox.w / 3, cropBox.y + cropBox.h);
      ctx.moveTo(cropBox.x + (cropBox.w * 2) / 3, cropBox.y);
      ctx.lineTo(cropBox.x + (cropBox.w * 2) / 3, cropBox.y + cropBox.h);
      ctx.moveTo(cropBox.x, cropBox.y + cropBox.h / 3);
      ctx.lineTo(cropBox.x + cropBox.w, cropBox.y + cropBox.h / 3);
      ctx.moveTo(cropBox.x, cropBox.y + (cropBox.h * 2) / 3);
      ctx.lineTo(cropBox.x + cropBox.w, cropBox.y + (cropBox.h * 2) / 3);
      ctx.stroke();

      ctx.restore();
    }
  };

  // Convert Editor Canvas Click to Image Coordinates
  const canvasToImageCoords = (clientX: number, clientY: number) => {
    const canvas = editorCanvasRef.current;
    const img = photoImgRef.current;
    if (!canvas || !img) return null;

    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;

    const clickX = (clientX - rect.left) * scaleX;
    const clickY = (clientY - rect.top) * scaleY;

    // Reverse Pan & Zoom
    const localX = (clickX - (canvas.width / 2 + canvasPan.x)) / canvasZoom;
    const localY = (clickY - (canvas.height / 2 + canvasPan.y)) / canvasZoom;

    const aspect = img.width / img.height;
    let renderW = 460;
    let renderH = 460 / aspect;
    if (renderH > 560) {
      renderH = 560;
      renderW = 560 * aspect;
    }

    const drawX = -renderW / 2;
    const drawY = -renderH / 2;

    const normX = (localX - drawX) / renderW;
    const normY = (localY - drawY) / renderH;

    const imgX = normX * img.width;
    const imgY = normY * img.height;

    return {
      normX,
      normY,
      imgX,
      imgY,
      isInside: normX >= 0 && normX <= 1 && normY >= 0 && normY <= 1
    };
  };

  // Canvas Mouse Down
  const handleEditorMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (isSpacePressed || activeTool === 'hand' || e.button === 1) {
      setIsPanning(true);
      setPanStart({ x: e.clientX - canvasPan.x, y: e.clientY - canvasPan.y });
      return;
    }

    const coords = canvasToImageCoords(e.clientX, e.clientY);
    if (!coords || !coords.isInside) return;

    // Tool actions
    if (activeTool === 'section_select') {
      setIsSelectingBox(true);
      setSelectionStartNorm({ x: coords.normX, y: coords.normY });
      setSelectionBox({ x: coords.normX, y: coords.normY, w: 0.01, h: 0.01 });
      setGradingScope('selection');
    } else if (activeTool === 'magic_wand') {
      executeMagicWandCut(coords.imgX, coords.imgY);
    } else if (activeTool === 'pen_tool') {
      if (penPoints.length >= 3 && !isPathClosed) {
        const first = penPoints[0];
        const dist = Math.hypot(coords.normX - first.x, coords.normY - first.y);
        if (dist < 0.05) {
          setIsPathClosed(true);
          return;
        }
      }
      if (!isPathClosed) {
        setPenPoints(prev => [...prev, { x: coords.normX, y: coords.normY }]);
      }
    } else if (activeTool === 'blemish_brush') {
      applyHealingBrush(coords.imgX, coords.imgY, 'blemish');
    } else if (activeTool === 'beauty_brush') {
      applyHealingBrush(coords.imgX, coords.imgY, 'beauty');
    } else if (activeTool === 'eye_brighten') {
      applyHealingBrush(coords.imgX, coords.imgY, 'eye');
    } else if (activeTool === 'zoom') {
      if (e.altKey) {
        setCanvasZoom(prev => Math.max(0.4, prev - 0.3));
      } else {
        setCanvasZoom(prev => Math.min(4.0, prev + 0.3));
      }
    }
  };

  // Canvas Mouse Move
  const handleEditorMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (isPanning) {
      setCanvasPan({
        x: e.clientX - panStart.x,
        y: e.clientY - panStart.y
      });
      return;
    }

    if (isSelectingBox && selectionStartNorm && activeTool === 'section_select') {
      const coords = canvasToImageCoords(e.clientX, e.clientY);
      if (coords) {
        const curX = Math.max(0, Math.min(1, coords.normX));
        const curY = Math.max(0, Math.min(1, coords.normY));
        const boxX = Math.min(selectionStartNorm.x, curX);
        const boxY = Math.min(selectionStartNorm.y, curY);
        const boxW = Math.max(0.01, Math.abs(curX - selectionStartNorm.x));
        const boxH = Math.max(0.01, Math.abs(curY - selectionStartNorm.y));
        setSelectionBox({ x: boxX, y: boxY, w: boxW, h: boxH });
      }
      return;
    }

    if (activeTool === 'pen_tool' && penPoints.length >= 3 && !isPathClosed) {
      const coords = canvasToImageCoords(e.clientX, e.clientY);
      if (coords) {
        const first = penPoints[0];
        const dist = Math.hypot(coords.normX - first.x, coords.normY - first.y);
        setIsNearStartPoint(dist < 0.05);
      }
    }
  };

  // Canvas Mouse Up
  const handleEditorMouseUp = () => {
    setIsPanning(false);
    setIsSelectingBox(false);
    setSelectionStartNorm(null);
  };

  // Canvas Mouse Wheel (Centered Zoom)
  const handleEditorWheel = (e: React.WheelEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    const zoomFactor = e.deltaY < 0 ? 1.15 : 0.88;
    setCanvasZoom(prev => Math.max(0.4, Math.min(4.0, prev * zoomFactor)));
  };

  // -------------------------------------------------------------
  // MINI PREVIEW CANVAS RENDER ("preview mini dikhna chaiye")
  // -------------------------------------------------------------
  const renderMiniPreview = () => {
    const canvas = miniPreviewCanvasRef.current;
    const img = photoImgRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = 240;
    canvas.height = 160;

    // Pure white photo paper
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    if (!img) {
      ctx.fillStyle = '#94a3b8';
      ctx.font = '10px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('Mini Sheet Preview', canvas.width / 2, canvas.height / 2);
      return;
    }

    // Draw miniature grid (4x6 landscape 8 copies or A4)
    const isA4 = paperFormat.startsWith('a4');
    const cols = paperFormat === '4x6_landscape' ? 4 : isA4 ? (copies === 32 ? 8 : 4) : 2;
    const rows = paperFormat === '4x6_landscape' ? 2 : isA4 ? 4 : 4;

    const gap = 4;
    const margin = 8;
    const cellW = (canvas.width - margin * 2 - (cols - 1) * gap) / cols;
    const cellH = cellW * (45 / 35);

    let count = 0;
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        if (count >= copies) break;
        const x = margin + c * (cellW + gap);
        const y = margin + r * (cellH + gap);

        // Fill background
        ctx.fillStyle = bgColor;
        ctx.fillRect(x, y, cellW, cellH);

        // Draw photo
        ctx.drawImage(img, x, y, cellW, cellH);

        // Cut mark
        ctx.strokeStyle = '#94a3b8';
        ctx.lineWidth = 0.5;
        ctx.strokeRect(x, y, cellW, cellH);

        count++;
      }
    }
  };

  // -------------------------------------------------------------
  // FULL SHEET 300 DPI RENDER (For Direct Printing & PDF / JPG Export)
  // -------------------------------------------------------------
  const renderFullSheet = () => {
    const canvas = fullSheetCanvasRef.current;
    const img = photoImgRef.current;
    if (!canvas || !img) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = SHEET_WIDTH;
    canvas.height = SHEET_HEIGHT;

    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, SHEET_WIDTH, SHEET_HEIGHT);

    // Single photo canvas at 300 DPI
    const singleW = 350;
    const singleH = 450;
    const singleCanvas = document.createElement('canvas');
    singleCanvas.width = singleW;
    singleCanvas.height = singleH;
    const sCtx = singleCanvas.getContext('2d');

    if (sCtx) {
      sCtx.fillStyle = bgColor;
      sCtx.fillRect(0, 0, singleW, singleH);

      // Color filters
      const effBrightness = 100 + brightness + (autoBeauty ? 6 : 0) + (faceGlow * 0.12);
      const effContrast = 100 + contrast + (autoBeauty ? 4 : 0);
      const effSaturation = isGrayscale ? 0 : 100 + saturation + (autoBeauty ? 8 : 0);

      let filterStr = `brightness(${effBrightness}%) contrast(${effContrast}%) saturate(${effSaturation}%)`;
      if (isGrayscale) filterStr += ' grayscale(100%)';
      sCtx.filter = filterStr;

      const aspect = img.width / img.height;
      let dw = singleW;
      let dh = singleH;
      if (aspect > singleW / singleH) {
        dw = singleH * aspect;
      } else {
        dh = singleW / aspect;
      }

      sCtx.drawImage(img, (singleW - dw) / 2, (singleH - dh) / 2, dw, dh);

      // Local Section Color Grading pass on print sheet
      if (selectionBox && selectionBox.w > 0.005 && selectionBox.h > 0.005) {
        const secX = (singleW - dw) / 2 + selectionBox.x * dw;
        const secY = (singleH - dh) / 2 + selectionBox.y * dh;
        const secW = selectionBox.w * dw;
        const secH = selectionBox.h * dh;

        sCtx.save();
        sCtx.beginPath();
        sCtx.rect(secX, secY, secW, secH);
        sCtx.clip();

        const secEffBright = effBrightness + secBrightness;
        const secEffCont = effContrast + secContrast;
        const secEffSat = isGrayscale ? 0 : effSaturation + secSaturation;

        sCtx.filter = `brightness(${secEffBright}%) contrast(${secEffCont}%) saturate(${secEffSat}%)`;
        sCtx.drawImage(img, (singleW - dw) / 2, (singleH - dh) / 2, dw, dh);

        if (secWarmth !== 0 && !isGrayscale) {
          sCtx.globalCompositeOperation = 'color';
          sCtx.fillStyle = secWarmth > 0
            ? `rgba(255, 175, 75, ${Math.min(0.45, (secWarmth / 100) * 0.5)})`
            : `rgba(80, 165, 255, ${Math.min(0.45, (Math.abs(secWarmth) / 100) * 0.5)})`;
          sCtx.fillRect(secX, secY, secW, secH);
        }
        sCtx.restore();
      }

      // Soft light beauty pass
      const effSmooth = autoBeauty ? Math.max(skinSmooth, 16) : skinSmooth;
      const effGlow = autoBeauty ? Math.max(faceGlow, 20) : faceGlow;
      if (effSmooth > 0 || effGlow > 0) {
        sCtx.save();
        sCtx.globalCompositeOperation = 'soft-light';
        sCtx.globalAlpha = Math.min(0.65, (effSmooth * 0.012) + (effGlow * 0.01));
        sCtx.filter = `blur(${Math.max(2, effSmooth / 8)}px) brightness(120%)`;
        sCtx.drawImage(img, (singleW - dw) / 2, (singleH - dh) / 2, dw, dh);
        sCtx.restore();
      }

      // Candidate Name & Date Strip
      if (showNameDate) {
        const boxH = 58;
        sCtx.fillStyle = '#ffffff';
        sCtx.fillRect(0, singleH - boxH, singleW, boxH);
        sCtx.fillStyle = '#000000';
        sCtx.font = 'bold 17px sans-serif';
        sCtx.textAlign = 'center';
        sCtx.fillText(candidateName.toUpperCase(), singleW / 2, singleH - boxH + 22);
        sCtx.font = 'bold 14px sans-serif';
        sCtx.fillText(`DATE: ${photoDate}`, singleW / 2, singleH - boxH + 45);
        sCtx.strokeStyle = '#000000';
        sCtx.lineWidth = 2;
        sCtx.beginPath();
        sCtx.moveTo(0, singleH - boxH);
        sCtx.lineTo(singleW, singleH - boxH);
        sCtx.stroke();
      }

      sCtx.strokeStyle = '#334155';
      sCtx.lineWidth = 2;
      sCtx.strokeRect(0, 0, singleW, singleH);
    }

    // Grid placement
    const cols = paperFormat === '4x6_landscape' ? 4 : paperFormat === 'a4_landscape' ? (copies === 32 ? 8 : 4) : 2;
    const rows = paperFormat === '4x6_landscape' ? 2 : 4;

    const isA4 = paperFormat.startsWith('a4');
    const marginX = isA4 ? 90 : 60;
    const marginY = isA4 ? 80 : 50;
    const availableW = SHEET_WIDTH - marginX * 2;
    const availableH = SHEET_HEIGHT - marginY * 2;

    const gap = isA4 ? 20 : 16;
    const targetW = (availableW - (cols - 1) * gap) / cols;
    let drawW = targetW;
    let drawH = targetW * (45 / 35);

    if (rows * drawH + (rows - 1) * gap > availableH) {
      drawH = (availableH - (rows - 1) * gap) / rows;
      drawW = drawH * (35 / 45);
    }

    const gapX = cols > 1 ? (availableW - cols * drawW) / (cols - 1) : 0;
    const gapY = rows > 1 ? (availableH - rows * drawH) / (rows - 1) : 0;

    let count = 0;
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        if (count >= copies) break;
        const x = marginX + c * (drawW + gapX);
        const y = marginY + r * (drawH + gapY);

        ctx.drawImage(singleCanvas, x, y, drawW, drawH);
        ctx.strokeStyle = '#64748b';
        ctx.lineWidth = 1;
        ctx.strokeRect(x, y, drawW, drawH);
        count++;
      }
    }

    // Center cutting line
    ctx.save();
    ctx.strokeStyle = '#94a3b8';
    ctx.lineWidth = 1.5;
    ctx.setLineDash([6, 6]);
    ctx.beginPath();
    ctx.moveTo(30, SHEET_HEIGHT / 2);
    ctx.lineTo(SHEET_WIDTH - 30, SHEET_HEIGHT / 2);
    ctx.stroke();
    ctx.restore();
  };

  // Upload handler
  const handleUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const src = event.target?.result as string;
      setPhotoSrc(src);
      setOriginalPhotoSrc(src);
      setHistoryStack([src]);
      setHistoryIndex(0);
      setCanvasZoom(1.0);
      setCanvasPan({ x: 0, y: 0 });
      setPenPoints([]);
      setIsPathClosed(false);
      setAutoBeauty(true);
      setActivePreset('auto_beauty');
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  // Direct In-App Print
  const handleDirectPrint = () => {
    const canvas = fullSheetCanvasRef.current;
    if (!canvas) return;

    try {
      const dataUrl = canvas.toDataURL('image/jpeg', 1.0);
      printImageSheet(dataUrl, {
        paperFormat,
        title: `Passport_${paperFormat}_${copies}Copies`,
        copiesCount: copies
      });

      setPrintAlert(`🖨️ Print command sent to printer! (${paperFormat.replace('_', ' ').toUpperCase()} • ${copies} Copies)`);
      setTimeout(() => setPrintAlert(null), 4000);
    } catch (e) {
      console.error(e);
      window.print();
    }
  };

  // Download PDF
  const handleDownloadSheetPDF = () => {
    const canvas = fullSheetCanvasRef.current;
    if (!canvas) return;

    try {
      const dataUrl = canvas.toDataURL('image/jpeg', 0.98);
      const isLandscape = paperFormat.includes('landscape');
      const isA4 = paperFormat.startsWith('a4');

      const pdf = new jsPDF({
        orientation: isLandscape ? 'landscape' : 'portrait',
        unit: isA4 ? 'mm' : 'in',
        format: isA4 ? 'a4' : [4, 6]
      });

      if (isA4) {
        pdf.addImage(dataUrl, 'JPEG', 0, 0, isLandscape ? 297 : 210, isLandscape ? 210 : 297);
      } else {
        pdf.addImage(dataUrl, 'JPEG', 0, 0, isLandscape ? 6 : 4, isLandscape ? 4 : 6);
      }

      const fileName = `Passport_${paperFormat}_${copies}_Copies_${Date.now()}.pdf`;
      pdf.save(fileName);

      addDownloadRecord({
        id: `pass-pdf-${Date.now()}`,
        title: fileName,
        type: 'Passport Sheet PDF',
        size: `${paperFormat.replace('_', ' ')} (${copies} Copies)`,
        timestamp: new Date().toLocaleTimeString('en-IN')
      });
    } catch (e) {
      console.error(e);
    }
  };

  // Download HD JPG
  const handleDownloadSheetJPG = () => {
    const canvas = fullSheetCanvasRef.current;
    if (!canvas) return;

    try {
      const dataUrl = canvas.toDataURL('image/jpeg', 0.98);
      const a = document.createElement('a');
      a.href = dataUrl;
      const fileName = `Passport_${paperFormat}_${copies}_Copies_300DPI_${Date.now()}.jpg`;
      a.download = fileName;
      a.click();

      addDownloadRecord({
        id: `pass-jpg-${Date.now()}`,
        title: fileName,
        type: 'Passport Sheet JPG',
        size: `${paperFormat.replace('_', ' ')} (${copies} Copies 300 DPI)`,
        timestamp: new Date().toLocaleTimeString('en-IN')
      });
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <div className="space-y-3 select-none">
      {/* Hidden Full Sheet 300 DPI Canvas for Print & Exports */}
      <canvas ref={fullSheetCanvasRef} className="hidden" />

      {/* TOP NOTIFICATION BANNER */}
      {printAlert && (
        <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs flex items-center justify-between animate-in fade-in">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
            <span>{printAlert}</span>
          </div>
          <button onClick={() => setPrintAlert(null)} className="text-emerald-400 hover:text-white">✕</button>
        </div>
      )}

      {/* PHOTOSHOP-STYLE TOP OPTIONS BAR */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl px-4 py-2.5 flex items-center justify-between gap-3 shadow-md flex-wrap text-xs">
        {/* Left: Active Tool Name & Dynamic Tool Controls */}
        <div className="flex items-center gap-3 flex-wrap">
          <div className="flex items-center gap-2 pr-3 border-r border-slate-800">
            <span className="font-extrabold text-white text-sm flex items-center gap-1.5">
              {activeTool === 'select' && <span>↖️ Pointer (V)</span>}
              {activeTool === 'section_select' && <span>🔲 Section Select & Color Grading (Q)</span>}
              {activeTool === 'magic_wand' && <span>🪄 Magic Wand Cut (W)</span>}
              {activeTool === 'pen_tool' && <span>🖊️ Pen Tool (P)</span>}
              {activeTool === 'crop' && <span>✂️ Passport Crop (C)</span>}
              {activeTool === 'blemish_brush' && <span>🩹 Spot Healing (B)</span>}
              {activeTool === 'beauty_brush' && <span>✨ Beauty Airbrush (S)</span>}
              {activeTool === 'eye_brighten' && <span>👁️ Eye/Teeth Brighten (E)</span>}
              {activeTool === 'hand' && <span>✋ Hand Pan (H)</span>}
              {activeTool === 'zoom' && <span>🔍 Zoom (Z)</span>}
            </span>
          </div>

          {/* Dynamic options when Section Select is active */}
          {activeTool === 'section_select' && (
            <div className="flex items-center gap-1.5 animate-in fade-in flex-wrap">
              <span className="text-slate-400 font-semibold text-[11px]">Presets:</span>
              <button
                type="button"
                onClick={() => handleSelectPreset('face')}
                className="px-2 py-0.5 rounded-md bg-slate-950 hover:bg-slate-800 text-slate-200 border border-slate-700 font-bold text-[11px]"
              >
                👤 Face
              </button>
              <button
                type="button"
                onClick={() => handleSelectPreset('clothes')}
                className="px-2 py-0.5 rounded-md bg-slate-950 hover:bg-slate-800 text-slate-200 border border-slate-700 font-bold text-[11px]"
              >
                👔 Clothes
              </button>
              <button
                type="button"
                onClick={() => handleSelectPreset('eyes')}
                className="px-2 py-0.5 rounded-md bg-slate-950 hover:bg-slate-800 text-slate-200 border border-slate-700 font-bold text-[11px]"
              >
                👁️ Eyes
              </button>
              <button
                type="button"
                onClick={() => handleSelectPreset('full')}
                className="px-2 py-0.5 rounded-md bg-slate-950 hover:bg-slate-800 text-slate-200 border border-slate-700 font-bold text-[11px]"
              >
                🔲 Full
              </button>

              {selectionBox && (
                <>
                  <button
                    type="button"
                    onClick={handleInvertSelection}
                    className="px-2 py-0.5 rounded-md bg-slate-800 text-slate-300 font-bold hover:text-white text-[11px]"
                    title="Invert Selection"
                  >
                    🔄 Invert
                  </button>
                  <button
                    type="button"
                    onClick={handleBakeSectionAdjustment}
                    className="flex items-center gap-1 px-2.5 py-0.5 rounded-md bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[11px] shadow"
                    title="Bake local adjustments into photo"
                  >
                    <Check className="w-3.5 h-3.5" />
                    <span>Bake Section</span>
                  </button>
                  <button
                    type="button"
                    onClick={handleClearSelection}
                    className="px-2 py-0.5 rounded-md bg-slate-800 text-rose-300 hover:text-rose-200 font-bold text-[11px]"
                  >
                    Clear
                  </button>
                </>
              )}
            </div>
          )}

          {/* Dynamic options when Magic Wand is active */}
          {activeTool === 'magic_wand' && (
            <div className="flex items-center gap-2 animate-in fade-in">
              <span className="text-slate-400">Tolerance:</span>
              <input
                type="range"
                min="10"
                max="65"
                value={magicTolerance}
                onChange={(e) => setMagicTolerance(Number(e.target.value))}
                className="w-20 accent-sky-400 cursor-pointer"
                title="Color similarity distance (10-65)"
              />
              <span className="font-mono text-white font-bold">{magicTolerance}</span>

              <button
                onClick={handleAutoBackgroundErase}
                disabled={isProcessing || !photoSrc}
                className="ml-2 flex items-center gap-1 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold px-3 py-1 rounded-lg shadow-sm"
                title="1-Click Auto Erases borders inwards"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>1-Click Auto Cut</span>
              </button>
            </div>
          )}

          {/* Dynamic options when Pen Tool is active */}
          {activeTool === 'pen_tool' && (
            <div className="flex items-center gap-2 animate-in fade-in">
              <span className="text-slate-400 font-mono text-[11px]">
                {penPoints.length} Points {isPathClosed ? '• Path Closed' : ''}
              </span>

              {!isPathClosed && penPoints.length >= 3 && (
                <button
                  onClick={() => setIsPathClosed(true)}
                  className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg"
                >
                  Close Path
                </button>
              )}

              {penPoints.length >= 3 && (
                <button
                  onClick={handleApplyPenCutout}
                  className="flex items-center gap-1 px-3 py-1 bg-gradient-to-r from-emerald-600 to-teal-600 text-white font-bold rounded-lg shadow-md"
                >
                  <Check className="w-3.5 h-3.5" />
                  <span>Apply Cutout</span>
                </button>
              )}

              <button
                onClick={() => { setPenPoints([]); setIsPathClosed(false); }}
                className="px-2 py-1 bg-slate-800 text-rose-300 font-bold rounded-lg hover:bg-rose-900/30"
              >
                Clear
              </button>
            </div>
          )}

          {/* Dynamic options when Crop is active */}
          {activeTool === 'crop' && (
            <div className="flex items-center gap-2 animate-in fade-in">
              <span className="bg-sky-500/20 text-sky-300 px-2 py-0.5 rounded font-mono font-bold">
                Ratio: 35×45mm Standard
              </span>
              <button
                onClick={handleApplyCrop}
                className="px-3 py-1 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg shadow"
              >
                Apply Crop
              </button>
              <button
                onClick={() => { setCropBox(null); setActiveTool('select'); }}
                className="px-2 py-1 bg-slate-800 text-slate-300 font-bold rounded-lg"
              >
                Cancel
              </button>
            </div>
          )}

          {/* Dynamic options when Brushes are active */}
          {(activeTool === 'blemish_brush' || activeTool === 'beauty_brush' || activeTool === 'eye_brighten') && (
            <div className="flex items-center gap-2 animate-in fade-in">
              <span className="text-slate-400">Brush Size:</span>
              <input
                type="range"
                min="8"
                max="70"
                value={brushSize}
                onChange={(e) => setBrushSize(Number(e.target.value))}
                className="w-20 accent-amber-400 cursor-pointer"
              />
              <span className="font-mono text-white font-bold">{brushSize}px</span>
              <span className="text-slate-500 text-[10px]">Use [ and ] to resize</span>
            </div>
          )}

          {/* 1-Click Remove BG Quick Action */}
          <button
            type="button"
            onClick={handleAutoBackgroundErase}
            disabled={isProcessing || !photoSrc}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-gradient-to-r from-purple-600 via-indigo-600 to-purple-500 hover:from-purple-500 hover:to-indigo-500 text-white font-extrabold text-xs rounded-xl shadow-md shadow-purple-600/30 transition-all hover:scale-105 active:scale-95 disabled:opacity-40"
            title="1-Click Automatic Background Remove / Replace with selected studio color"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>⚡ 1-Click Remove BG</span>
          </button>

          {/* Studio Background Swatches */}
          <div className="flex items-center gap-1.5 pl-3 border-l border-slate-800">
            <span className="text-slate-400">BG:</span>
            {[
              { name: 'White', color: '#ffffff' },
              { name: 'Sky Blue', color: '#cce3f8' },
              { name: 'Studio Blue', color: '#2563eb' },
              { name: 'Grey', color: '#e2e8f0' },
              { name: 'Red', color: '#dc2626' },
              { name: 'Transparent Cutout', color: 'transparent' }
            ].map((c) => (
              <button
                key={c.name}
                onClick={() => setBgColor(c.color)}
                className={`w-5 h-5 rounded-full border shadow-sm transition-transform ${
                  bgColor === c.color ? 'scale-125 ring-2 ring-sky-400 border-white' : 'border-slate-500 hover:scale-110'
                } ${c.color === 'transparent' ? 'bg-[linear-gradient(45deg,#ccc_25%,transparent_25%),linear-gradient(-45deg,#ccc_25%,transparent_25%),linear-gradient(45deg,transparent_75%,#ccc_75%),linear-gradient(-45deg,transparent_75%,#ccc_75%)] bg-[size:6px_6px] bg-white' : ''}`}
                style={c.color !== 'transparent' ? { backgroundColor: c.color } : {}}
                title={`Change studio background to ${c.name}`}
              />
            ))}
          </div>
        </div>

        {/* Right: Undo / Redo & Print / Export actions */}
        <div className="flex items-center gap-2">
          {/* Undo / Redo */}
          <div className="flex items-center bg-slate-950 border border-slate-800 rounded-lg p-0.5">
            <button
              onClick={handleUndo}
              disabled={historyIndex <= 0 && penPoints.length === 0}
              className="p-1.5 text-slate-300 hover:text-white disabled:opacity-30 disabled:hover:text-slate-300"
              title="Undo (Ctrl + Z)"
            >
              <Undo2 className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={handleRedo}
              disabled={historyIndex >= historyStack.length - 1}
              className="p-1.5 text-slate-300 hover:text-white disabled:opacity-30 disabled:hover:text-slate-300"
              title="Redo (Ctrl + Y)"
            >
              <Redo2 className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Mini Preview Toggle Button */}
          <button
            onClick={() => setShowMiniPreview(prev => !prev)}
            className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg border font-bold text-xs transition-colors ${
              showMiniPreview ? 'bg-sky-600/20 text-sky-300 border-sky-500/40' : 'bg-slate-800 text-slate-400 border-slate-700'
            }`}
            title="Toggle Mini Sheet Preview (M)"
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Mini Preview (M)</span>
          </button>

          {/* Direct Print Button */}
          <button
            onClick={handleDirectPrint}
            className="flex items-center gap-1.5 bg-gradient-to-r from-blue-600 via-indigo-600 to-blue-500 hover:from-blue-500 hover:to-indigo-500 text-white font-extrabold px-3.5 py-1.5 rounded-xl shadow-lg shadow-blue-600/30 transition-all hover:scale-105"
            title="Direct Print Sheet (Ctrl + P)"
          >
            <Printer className="w-3.5 h-3.5 text-white" />
            <span>🖨️ Print Sheet (Ctrl+P)</span>
          </button>
        </div>
      </div>

      {/* MAIN PHOTOSHOP WORKSPACE CONTAINER */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-3 items-start min-h-[640px]">
        {/* 1. LEFT PHOTOSHOP VERTICAL TOOLBAR (1 Column) */}
        <div className="lg:col-span-1 bg-slate-900 border border-slate-800 rounded-2xl p-2 flex lg:flex-col items-center justify-center gap-2 shadow-lg">
          {/* Tool Icons */}
          {[
            { id: 'select', label: 'Pointer / Move (V)', icon: '↖️' },
            { id: 'section_select', label: 'Section Selection Tool (Q)', icon: '🔲' },
            { id: 'auto_bg', label: '1-Click Auto Remove BG (R)', icon: '⚡' },
            { id: 'crop', label: 'Passport Crop (C)', icon: '✂️' },
            { id: 'magic_wand', label: 'Magic Wand / Cut (W)', icon: '🪄' },
            { id: 'pen_tool', label: 'Pen Tool Cutout (P)', icon: '🖊️' },
            { id: 'blemish_brush', label: 'Spot Healing Brush (B)', icon: '🩹' },
            { id: 'beauty_brush', label: 'Skin Airbrush (S)', icon: '✨' },
            { id: 'eye_brighten', label: 'Eye/Teeth Whitener (E)', icon: '👁️' },
            { id: 'hand', label: 'Hand Tool Pan (H / Space)', icon: '✋' },
            { id: 'zoom', label: 'Zoom Tool (Z)', icon: '🔍' }
          ].map((t) => {
            const isActive = activeTool === t.id;
            return (
              <button
                key={t.id}
                onClick={() => {
                  if (t.id === 'auto_bg') {
                    handleAutoBackgroundErase();
                    return;
                  }
                  setActiveTool(t.id as ActiveTool);
                  if (t.id === 'crop') initCropBox();
                  if (t.id === 'section_select') {
                    setGradingScope('selection');
                    if (!selectionBox) handleSelectPreset('face');
                  }
                }}
                className={`w-10 h-10 rounded-xl flex items-center justify-center text-lg transition-all ${
                  isActive
                    ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/40 ring-2 ring-blue-400 scale-105'
                    : 'bg-slate-950 text-slate-300 hover:bg-slate-800 border border-slate-800/80 hover:text-white'
                }`}
                title={t.label}
              >
                <span>{t.icon}</span>
              </button>
            );
          })}

          <div className="w-8 border-t border-slate-800 my-1 hidden lg:block" />

          {/* Upload Button */}
          <label className="w-10 h-10 rounded-xl bg-purple-600/20 border border-purple-500/40 text-purple-300 hover:bg-purple-600/30 flex items-center justify-center cursor-pointer transition-colors" title="Upload Customer Photo">
            <Upload className="w-4 h-4" />
            <input type="file" accept="image/*" onChange={handleUpload} className="hidden" />
          </label>
        </div>

        {/* 2. CENTER BIG EDITING CANVAS WORKSPACE (8 Columns or 11 Columns if mini preview collapsed) */}
        <div className={`${showMiniPreview ? 'lg:col-span-8' : 'lg:col-span-11'} relative bg-slate-950 border border-slate-800 rounded-2xl overflow-hidden shadow-2xl flex flex-col justify-between min-h-[640px]`}>
          {/* Zoom / Info Overlay Bar */}
          <div className="absolute top-3 left-3 z-10 flex items-center gap-2 bg-slate-900/85 backdrop-blur-sm border border-slate-800 px-3 py-1.5 rounded-xl text-[11px] text-slate-300 pointer-events-none">
            <span className="font-bold text-white">Photoshop Studio Canvas</span>
            <span>•</span>
            <span className="font-mono text-sky-400 font-bold">{Math.round(canvasZoom * 100)}%</span>
            <span>•</span>
            <span>Hold Spacebar + Drag to Pan • Wheel to Zoom</span>
          </div>

          {/* Center Canvas */}
          <div className="flex-1 flex items-center justify-center p-2 overflow-hidden">
            <canvas
              ref={editorCanvasRef}
              onMouseDown={handleEditorMouseDown}
              onMouseMove={handleEditorMouseMove}
              onMouseUp={handleEditorMouseUp}
              onMouseLeave={handleEditorMouseUp}
              onWheel={handleEditorWheel}
              className={`max-w-full max-h-[580px] w-auto h-auto rounded-lg shadow-2xl ${
                isSpacePressed || activeTool === 'hand'
                  ? 'cursor-grab active:cursor-grabbing'
                  : activeTool === 'magic_wand' || activeTool === 'pen_tool'
                  ? 'cursor-crosshair'
                  : activeTool === 'blemish_brush' || activeTool === 'beauty_brush' || activeTool === 'eye_brighten'
                  ? 'cursor-cell'
                  : 'cursor-default'
              }`}
            />
          </div>

          {/* Bottom Canvas Quick Status Bar */}
          <div className="bg-slate-900/80 border-t border-slate-800/80 px-4 py-2 flex items-center justify-between text-xs text-slate-400 flex-wrap gap-2">
            <div className="flex items-center gap-3">
              <span>Tool: <strong className="text-white uppercase">{activeTool.replace('_', ' ')}</strong></span>
              {photoSrc && (
                <span className="text-emerald-400 flex items-center gap-1 font-semibold">
                  <Check className="w-3.5 h-3.5" /> High-Resolution Photo Ready
                </span>
              )}
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => { setCanvasZoom(1.0); setCanvasPan({ x: 0, y: 0 }); }}
                className="px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-[11px] font-mono"
              >
                Fit Screen (Ctrl+0)
              </button>
              <button
                onClick={() => setCanvasZoom(prev => Math.min(4.0, prev + 0.25))}
                className="px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-[11px] font-mono"
              >
                +
              </button>
              <button
                onClick={() => setCanvasZoom(prev => Math.max(0.4, prev - 0.25))}
                className="px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-[11px] font-mono"
              >
                -
              </button>
            </div>
          </div>
        </div>

        {/* 3. RIGHT SIDE: COMPACT MINI PREVIEW & ADJUSTMENTS (3 Columns) */}
        {showMiniPreview && (
          <div className="lg:col-span-3 space-y-3">
            {/* MINI SHEET PREVIEW WIDGET ("preview mini dikhna chaiye") */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3 shadow-xl space-y-2.5">
              <div className="flex items-center justify-between pb-1.5 border-b border-slate-800">
                <div className="flex items-center gap-1.5">
                  <span className="font-extrabold text-white text-xs">Mini Sheet Preview</span>
                  <span className="text-[10px] font-mono bg-blue-500/20 text-blue-300 px-1.5 py-0.5 rounded font-bold">
                    {paperFormat === '4x6_landscape' ? '4×6 (8)' : 'A4'}
                  </span>
                </div>
                <button
                  onClick={() => setShowMiniPreview(false)}
                  className="p-1 text-slate-500 hover:text-white rounded"
                  title="Hide Mini Preview (M)"
                >
                  <Minimize2 className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Miniature Canvas */}
              <div className="relative flex justify-center bg-slate-950 p-2 rounded-xl border border-slate-800 overflow-hidden shadow-inner">
                <canvas
                  ref={miniPreviewCanvasRef}
                  width={240}
                  height={160}
                  className="w-full h-auto bg-white rounded shadow-md border border-slate-700 pointer-events-none"
                />
              </div>

              {/* Format Switcher */}
              <div className="grid grid-cols-2 gap-1.5">
                <button
                  onClick={() => { setPaperFormat('4x6_landscape'); setCopies(8); }}
                  className={`py-1.5 px-2 rounded-lg text-xs font-bold transition-all text-center ${
                    paperFormat === '4x6_landscape'
                      ? 'bg-blue-600 text-white shadow'
                      : 'bg-slate-950 text-slate-400 hover:text-white'
                  }`}
                >
                  4×6 (8 Copies)
                </button>
                <button
                  onClick={() => { setPaperFormat('a4_landscape'); setCopies(32); }}
                  className={`py-1.5 px-2 rounded-lg text-xs font-bold transition-all text-center ${
                    paperFormat === 'a4_landscape'
                      ? 'bg-purple-600 text-white shadow'
                      : 'bg-slate-950 text-slate-400 hover:text-white'
                  }`}
                >
                  A4 Landscape
                </button>
              </div>

              {/* Direct Print Button on Mini Preview */}
              <button
                onClick={handleDirectPrint}
                className="w-full flex items-center justify-center gap-1.5 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-extrabold text-xs py-2 rounded-xl shadow-md transition-all active:scale-95"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>🖨️ Print Sheet Now</span>
              </button>
            </div>

            {/* AUTO BEAUTY & PRESETS ACCORDION */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3.5 shadow-md space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                  <span>Auto Beauty Presets</span>
                </span>
                <span className="text-[10px] text-amber-400 font-bold bg-amber-500/10 px-1.5 py-0.5 rounded">
                  1-Click
                </span>
              </div>

              <div className="grid grid-cols-2 gap-1.5">
                {BEAUTY_PRESETS.map((p) => {
                  const isSelected = activePreset === p.id && autoBeauty;
                  return (
                    <button
                      key={p.id}
                      onClick={() => {
                        setActivePreset(p.id);
                        setBrightness(p.settings.brightness);
                        setContrast(p.settings.contrast);
                        setSaturation(p.settings.saturation);
                        setWarmth(p.settings.warmth);
                        setTint(p.settings.tint);
                        setSkinSmooth(p.settings.skinSmooth);
                        setFaceGlow(p.settings.faceGlow);
                        setShadowLift(p.settings.shadowLift);
                        setIsGrayscale(p.settings.isGrayscale);
                        setAutoBeauty(true);
                      }}
                      className={`p-2 rounded-xl text-left border transition-all ${
                        isSelected
                          ? 'bg-amber-500/10 border-amber-500/60 text-white ring-1 ring-amber-500/30'
                          : 'bg-slate-950 border-slate-800/80 text-slate-300 hover:bg-slate-800'
                      }`}
                    >
                      <div className="text-xs font-bold truncate flex items-center gap-1">
                        <span>{p.icon}</span>
                        <span className="truncate">{p.name}</span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* COLOR GRADING & SECTION GRADING SLIDERS PANEL */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3.5 shadow-md space-y-3 text-xs">
              <div className="flex items-center justify-between pb-1 border-b border-slate-800">
                <span className="font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                  <Sliders className="w-3.5 h-3.5 text-blue-400" />
                  <span>Color Grading & Skin</span>
                </span>
                <button
                  onClick={() => {
                    if (gradingScope === 'selection') {
                      setSecBrightness(0);
                      setSecContrast(0);
                      setSecSaturation(0);
                      setSecWarmth(0);
                      setSecSmooth(0);
                    } else {
                      setBrightness(0);
                      setContrast(0);
                      setSaturation(0);
                      setWarmth(0);
                      setTint(0);
                      setSkinSmooth(0);
                      setFaceGlow(0);
                      setIsGrayscale(false);
                    }
                  }}
                  className="text-[10px] text-slate-400 hover:text-white"
                >
                  Reset
                </button>
              </div>

              {/* SCOPE TOGGLE: WHOLE PHOTO vs SELECTED SECTION */}
              <div className="grid grid-cols-2 gap-1.5 p-1 bg-slate-950 rounded-xl border border-slate-800 text-[11px]">
                <button
                  type="button"
                  onClick={() => setGradingScope('full')}
                  className={`py-1.5 px-2 rounded-lg font-bold flex items-center justify-center gap-1 transition-all ${
                    gradingScope === 'full'
                      ? 'bg-blue-600 text-white shadow'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <span>🌐 Whole Photo</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setGradingScope('selection');
                    if (!selectionBox) handleSelectPreset('face');
                    setActiveTool('section_select');
                  }}
                  className={`py-1.5 px-2 rounded-lg font-bold flex items-center justify-center gap-1 transition-all ${
                    gradingScope === 'selection'
                      ? 'bg-gradient-to-r from-cyan-600 to-blue-600 text-white shadow shadow-cyan-600/30'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <span>🔲 Section Only</span>
                </button>
              </div>

              {/* CONDITIONAL CONTROLS BASED ON SCOPE */}
              {gradingScope === 'selection' ? (
                /* SECTION COLOR GRADING CONTROLS */
                <div className="space-y-2.5 pt-1 animate-in fade-in">
                  <div className="flex items-center justify-between text-[11px] bg-cyan-950/40 p-2 rounded-lg border border-cyan-500/30">
                    <span className="font-extrabold text-cyan-300">
                      🎯 Section Preset & Box:
                    </span>
                    {selectionBox ? (
                      <button
                        type="button"
                        onClick={handleClearSelection}
                        className="text-rose-400 hover:underline text-[10px] font-bold"
                      >
                        Clear
                      </button>
                    ) : (
                      <span className="text-amber-400 text-[10px]">Draw box on photo</span>
                    )}
                  </div>

                  {/* Preset chips */}
                  <div className="grid grid-cols-4 gap-1 text-[10px]">
                    <button
                      type="button"
                      onClick={() => handleSelectPreset('face')}
                      className="p-1.5 rounded-lg bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 font-bold text-center"
                    >
                      👤 Face
                    </button>
                    <button
                      type="button"
                      onClick={() => handleSelectPreset('clothes')}
                      className="p-1.5 rounded-lg bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 font-bold text-center"
                    >
                      👔 Clothes
                    </button>
                    <button
                      type="button"
                      onClick={() => handleSelectPreset('eyes')}
                      className="p-1.5 rounded-lg bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 font-bold text-center"
                    >
                      👁️ Eyes
                    </button>
                    <button
                      type="button"
                      onClick={() => handleSelectPreset('full')}
                      className="p-1.5 rounded-lg bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 font-bold text-center"
                    >
                      🔲 Full
                    </button>
                  </div>

                  {/* Section Brightness */}
                  <div>
                    <div className="flex justify-between text-slate-300 mb-0.5 font-semibold">
                      <span className="text-amber-300 flex items-center gap-1">
                        <Sun className="w-3.5 h-3.5" /> Section Brightness
                      </span>
                      <span className="font-mono text-white">{secBrightness > 0 ? `+${secBrightness}` : secBrightness}%</span>
                    </div>
                    <input
                      type="range"
                      min="-40"
                      max="40"
                      value={secBrightness}
                      onChange={(e) => setSecBrightness(Number(e.target.value))}
                      className="w-full accent-amber-500 cursor-pointer h-1.5 bg-slate-800 rounded"
                    />
                  </div>

                  {/* Section Contrast */}
                  <div>
                    <div className="flex justify-between text-slate-300 mb-0.5 font-semibold">
                      <span className="text-sky-300 flex items-center gap-1">
                        <Contrast className="w-3.5 h-3.5" /> Section Contrast
                      </span>
                      <span className="font-mono text-white">{secContrast > 0 ? `+${secContrast}` : secContrast}%</span>
                    </div>
                    <input
                      type="range"
                      min="-40"
                      max="40"
                      value={secContrast}
                      onChange={(e) => setSecContrast(Number(e.target.value))}
                      className="w-full accent-sky-500 cursor-pointer h-1.5 bg-slate-800 rounded"
                    />
                  </div>

                  {/* Section Warmth */}
                  <div>
                    <div className="flex justify-between text-slate-300 mb-0.5 font-semibold">
                      <span className="text-orange-300 flex items-center gap-1">
                        <Flame className="w-3.5 h-3.5" /> Section Warmth / Tone
                      </span>
                      <span className="font-mono text-white">{secWarmth > 0 ? `+${secWarmth}` : secWarmth}</span>
                    </div>
                    <input
                      type="range"
                      min="-40"
                      max="40"
                      value={secWarmth}
                      onChange={(e) => setSecWarmth(Number(e.target.value))}
                      className="w-full accent-orange-500 cursor-pointer h-1.5 bg-slate-800 rounded"
                    />
                  </div>

                  {/* Section Saturation */}
                  <div>
                    <div className="flex justify-between text-slate-300 mb-0.5 font-semibold">
                      <span className="text-pink-300 flex items-center gap-1">
                        <Droplets className="w-3.5 h-3.5" /> Section Saturation
                      </span>
                      <span className="font-mono text-white">{secSaturation > 0 ? `+${secSaturation}` : secSaturation}%</span>
                    </div>
                    <input
                      type="range"
                      min="-40"
                      max="40"
                      value={secSaturation}
                      onChange={(e) => setSecSaturation(Number(e.target.value))}
                      className="w-full accent-pink-500 cursor-pointer h-1.5 bg-slate-800 rounded"
                    />
                  </div>

                  {/* Section Skin Smooth */}
                  <div>
                    <div className="flex justify-between text-slate-300 mb-0.5 font-semibold">
                      <span className="text-emerald-300 flex items-center gap-1">
                        <Sparkles className="w-3.5 h-3.5" /> Section Smoothness
                      </span>
                      <span className="font-mono text-white">{secSmooth}%</span>
                    </div>
                    <input
                      type="range"
                      min="0"
                      max="40"
                      value={secSmooth}
                      onChange={(e) => setSecSmooth(Number(e.target.value))}
                      className="w-full accent-emerald-500 cursor-pointer h-1.5 bg-slate-800 rounded"
                    />
                  </div>

                  {/* Bake / Invert Buttons */}
                  <div className="pt-1 flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={handleBakeSectionAdjustment}
                      disabled={!selectionBox || isProcessing}
                      className="flex-1 py-1.5 px-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-extrabold text-[11px] rounded-xl shadow-md flex items-center justify-center gap-1 disabled:opacity-50"
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span>Bake into Photo</span>
                    </button>
                    <button
                      type="button"
                      onClick={handleInvertSelection}
                      disabled={!selectionBox}
                      className="py-1.5 px-2 bg-slate-800 text-slate-300 hover:text-white font-bold text-[11px] rounded-xl border border-slate-700 disabled:opacity-50"
                      title="Invert Selection Box"
                    >
                      🔄 Invert
                    </button>
                  </div>
                </div>
              ) : (
                /* WHOLE PHOTO COLOR GRADING CONTROLS */
                <div className="space-y-2.5 animate-in fade-in">
                  {/* Skin Smooth */}
                  <div>
                    <div className="flex justify-between text-slate-400 mb-0.5">
                      <span className="text-amber-300 font-semibold">Skin Smoothing</span>
                      <span className="font-mono text-white">{skinSmooth}%</span>
                    </div>
                    <input
                      type="range"
                      min="0"
                      max="50"
                      value={skinSmooth}
                      onChange={(e) => setSkinSmooth(Number(e.target.value))}
                      className="w-full accent-amber-500 cursor-pointer h-1.5 bg-slate-800 rounded"
                    />
                  </div>

                  {/* Brightness */}
                  <div>
                    <div className="flex justify-between text-slate-400 mb-0.5">
                      <span>Brightness</span>
                      <span className="font-mono text-white">{brightness > 0 ? `+${brightness}` : brightness}%</span>
                    </div>
                    <input
                      type="range"
                      min="-30"
                      max="30"
                      value={brightness}
                      onChange={(e) => setBrightness(Number(e.target.value))}
                      className="w-full accent-blue-500 cursor-pointer h-1.5 bg-slate-800 rounded"
                    />
                  </div>

                  {/* Contrast */}
                  <div>
                    <div className="flex justify-between text-slate-400 mb-0.5">
                      <span>Contrast</span>
                      <span className="font-mono text-white">{contrast > 0 ? `+${contrast}` : contrast}%</span>
                    </div>
                    <input
                      type="range"
                      min="-30"
                      max="30"
                      value={contrast}
                      onChange={(e) => setContrast(Number(e.target.value))}
                      className="w-full accent-blue-500 cursor-pointer h-1.5 bg-slate-800 rounded"
                    />
                  </div>

                  {/* Warmth */}
                  <div>
                    <div className="flex justify-between text-slate-400 mb-0.5">
                      <span>Warmth / Tone</span>
                      <span className="font-mono text-white">{warmth > 0 ? `+${warmth}` : warmth}</span>
                    </div>
                    <input
                      type="range"
                      min="-30"
                      max="30"
                      value={warmth}
                      onChange={(e) => setWarmth(Number(e.target.value))}
                      className="w-full accent-orange-500 cursor-pointer h-1.5 bg-slate-800 rounded"
                    />
                  </div>
                </div>
              )}

              {/* Candidate Exam Strip */}
              <div className="pt-2 border-t border-slate-800">
                <label className="flex items-center justify-between cursor-pointer">
                  <span className="font-bold text-slate-300">Exam Name & Date Strip</span>
                  <input
                    type="checkbox"
                    checked={showNameDate}
                    onChange={(e) => setShowNameDate(e.target.checked)}
                    className="accent-blue-500 rounded"
                  />
                </label>
                {showNameDate && (
                  <div className="mt-2 space-y-1.5">
                    <input
                      type="text"
                      placeholder="Candidate Name"
                      value={candidateName}
                      onChange={(e) => setCandidateName(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-700 rounded px-2 py-1 text-white text-[11px] font-bold"
                    />
                    <input
                      type="text"
                      placeholder="Date (DD/MM/YYYY)"
                      value={photoDate}
                      onChange={(e) => setPhotoDate(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-700 rounded px-2 py-1 text-white text-[11px] font-bold"
                    />
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
