export interface SchemeGuide {
  title: string;
  schemeId: string;
  eligibility: string[];
  documents: string[];
  procedure: string[];
  officialUrl: string;
  notes: string;
}

export const SCHEME_GUIDES: Record<string, SchemeGuide> = {
  ladki_bahin: {
    title: 'Majhi Ladki Bahin Yojana (Maharashtra)',
    schemeId: 'ladki_bahin',
    eligibility: [
      'Age between 21 to 65 years as of current year.',
      'Resident of Maharashtra state (Domicile or Ration card or 15-year old School LC).',
      'Annual household income must not exceed ₹2,50,000/- (or family must hold Yellow or Orange Ration Card).',
      'Bank account must be Aadhaar-seeded (DBT Active).',
      'Only one married woman or eligible unmarried woman per family.'
    ],
    documents: [
      'Aadhaar Card (Applicant)',
      'Bank Passbook / Cancelled Cheque (Aadhaar Seeded)',
      'Maharashtra Domicile Certificate OR Ration Card (Yellow/Orange) OR Voter ID older than 15 years OR Birth Certificate',
      'Income Certificate (Issued by Tehsildar / Aaple Sarkar) - NOT required if holding Yellow/Orange Ration Card',
      'Self-Declaration (Hamipatra)',
      'Passport size Photo'
    ],
    procedure: [
      '1. Open official portal: https://ladakibahin.maharashtra.gov.in/ or Nari Shakti Doot App.',
      '2. Click on "Applicant Login" or create account using mobile number with OTP.',
      '3. Fill applicant name, father/husband name, date of birth, marital status.',
      '4. Enter Aadhaar number and verify via OTP.',
      '5. Enter Bank account number and IFSC code.',
      '6. Upload front/back photos of Aadhaar card, Ration card, Hamipatra, and photo.',
      '7. Submit application and print acknowledgment receipt for the customer.'
    ],
    officialUrl: 'https://ladakibahin.maharashtra.gov.in/',
    notes: 'Verify DBT status in bank account before submitting. If DBT is inactive, payment will fail.'
  },
  pm_kisan: {
    title: 'PM-KISAN Samman Nidhi',
    schemeId: 'pm_kisan',
    eligibility: [
      'Landholding farmer families with cultivable land in their name.',
      'Land record must be updated in state land revenue records (7/12).',
      'Institutional landholders and income tax payers are NOT eligible.'
    ],
    documents: [
      'Aadhaar Card',
      'Land Ownership document (7/12 Extract / Khatauni / Jamabandi)',
      'Bank Account (Aadhaar seeded DBT)',
      'Mobile Number linked with Aadhaar'
    ],
    procedure: [
      '1. Visit https://pmkisan.gov.in/.',
      '2. Under "Farmers Corner", click "New Farmer Registration" or "eKYC".',
      '3. Select Rural or Urban Farmer Registration.',
      '4. Enter Aadhaar number, mobile number, and select state.',
      '5. Enter OTP, land registration ID, survey number, and area in hectares.',
      '6. Upload 7/12 copy and submit for district level verification.'
    ],
    officialUrl: 'https://pmkisan.gov.in/',
    notes: 'Biometric or Face eKYC is mandatory every year to receive the 3 instalments of ₹2,000 (total ₹6,000/year).'
  },
  pm_surya_ghar: {
    title: 'PM Surya Ghar: Muft Bijli Yojana',
    schemeId: 'pm_surya_ghar',
    eligibility: [
      'Indian citizen with a residential home with a suitable rooftop.',
      'Valid residential electricity connection (DISCOM).',
      'Applicant should not have availed any other solar subsidy earlier.'
    ],
    documents: [
      'Latest Electricity Bill (Consumer Number)',
      'Aadhaar Card',
      'Bank Passbook / Cancelled Cheque',
      'Photo of rooftop'
    ],
    procedure: [
      '1. Visit https://pmsuryaghar.gov.in/ and register with Electricity DISCOM and Consumer Account Number.',
      '2. Apply for Rooftop Solar installation.',
      '3. Wait for feasibility approval from DISCOM.',
      '4. Install solar plant through registered vendors.',
      '5. Submit net-metering application & bank details for direct subsidy credit.'
    ],
    officialUrl: 'https://pmsuryaghar.gov.in/',
    notes: 'Subsidy is ₹30,000 for 1 kW, ₹60,000 for 2 kW, and up to ₹78,000 for 3 kW systems.'
  },
  ayushman_bharat: {
    title: 'Ayushman Bharat (PM-JAY)',
    schemeId: 'ayushman_bharat',
    eligibility: [
      'Families listed in SECC 2011 database or state food security card (NFSA Ration Card).',
      'Yellow or Orange Ration Card holders in Maharashtra (Mahatma Jyotirao Phule Jan Arogya Yojana).'
    ],
    documents: [
      'Ration Card (Yellow or Orange)',
      'Aadhaar Card for all family members',
      'Mobile with active OTP'
    ],
    procedure: [
      '1. Visit https://beneficiary.nha.gov.in/ and select "Beneficiary" login.',
      '2. Enter mobile number, generate OTP.',
      '3. Search beneficiary using Ration card / Family ID / Aadhaar.',
      '4. If eKYC is pending, click "Do eKYC" with Aadhaar OTP or Biometric/Iris.',
      '5. Capture customer webcam photo.',
      '6. Download Golden Card PDF and print on PVC card (₹5 Lakh free hospitalization coverage per family).'
    ],
    officialUrl: 'https://beneficiary.nha.gov.in/',
    notes: 'Golden cards can be printed directly on our PVC Card maker!'
  },
  pan_card: {
    title: 'PAN Card (New & Correction)',
    schemeId: 'pan_card',
    eligibility: [
      'Any individual or entity requiring PAN for tax, banking, or identification.'
    ],
    documents: [
      'Identity Proof (Aadhaar Card is sufficient for all three proofs)',
      'Address Proof (Aadhaar / Voter ID / Utility Bill)',
      'Date of Birth Proof (Aadhaar / 10th marksheet / Birth Cert)',
      '2 Passport size photos with white background',
      'Signature on blank white paper'
    ],
    procedure: [
      '1. Open UTIITSL (https://www.pan.utiitsl.com/) or NSDL Protean.',
      '2. Select Form 49A (Indian Citizen) or CSF (Correction/Change).',
      '3. Fill applicant personal details, father name, address.',
      '4. Choose physical PAN card + e-PAN option (Govt fee ₹107).',
      '5. Upload cropped photo (213x213 px 300 DPI, <30KB) and signature (400x200 px, <30KB).',
      '6. Pay fee and provide generated acknowledgment slip to customer.'
    ],
    officialUrl: 'https://www.pan.utiitsl.com/',
    notes: 'Use our Passport Photo Maker to generate exact 213x213 PAN photo requirement.'
  }
};
