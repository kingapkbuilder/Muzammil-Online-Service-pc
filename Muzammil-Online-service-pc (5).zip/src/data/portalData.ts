import { PortalItem } from '../types';

export const ALL_GOV_PORTALS: PortalItem[] = [
  // Citizen IDs
  {
    id: 'uidai',
    title: 'Aadhaar Card (myAadhaar)',
    category: 'citizen_id',
    url: 'https://myaadhaar.uidai.gov.in/',
    icon: '🪪',
    description: 'Download e-Aadhaar, Order PVC Card, Address Update, Check Status & Biometric Lock.',
    requiredDocs: ['Aadhaar Number / Enrollment ID', 'Registered Mobile Number (OTP)', 'Proof of Address (for update)'],
    popular: true,
    portalType: 'central'
  },
  {
    id: 'pan_uti',
    title: 'PAN Card (UTIITSL / NSDL)',
    category: 'citizen_id',
    url: 'https://www.pan.utiitsl.com/',
    icon: '💳',
    description: 'New PAN 49A, PAN Correction, Reprint e-PAN, Link Aadhaar & Track Status.',
    requiredDocs: ['Aadhaar Card', 'Passport Photo (2)', 'Signature', 'Old PAN copy (for correction)'],
    popular: true,
    portalType: 'central'
  },
  {
    id: 'voter_eci',
    title: 'Voter ID (ECI Portal)',
    category: 'citizen_id',
    url: 'https://voters.eci.gov.in/',
    icon: '🗳️',
    description: 'New Voter Registration (Form 6), Correction (Form 8), Shift Residence & Download e-EPIC.',
    requiredDocs: ['Aadhaar Card / Age Proof', 'Address Proof (Electricity Bill / Ration Card)', 'Passport Photo'],
    popular: true,
    portalType: 'central'
  },
  {
    id: 'ayushman_pmjay',
    title: 'Ayushman Bharat (PM-JAY)',
    category: 'citizen_id',
    url: 'https://beneficiary.nha.gov.in/',
    icon: '🏥',
    description: 'Ayushman Golden Card generation (₹5 Lakh Free Treatment), eKYC & Beneficiary search.',
    requiredDocs: ['Ration Card (Yellow/Orange)', 'Aadhaar Card of all members', 'Mobile with OTP'],
    popular: true,
    portalType: 'central'
  },
  {
    id: 'abha_health',
    title: 'ABHA Health Card (ABDM)',
    category: 'citizen_id',
    url: 'https://abha.abdm.gov.in/',
    icon: '🩺',
    description: 'Ayushman Bharat Health Account 14-digit digital card creation & health records linking.',
    requiredDocs: ['Aadhaar Card', 'Aadhaar linked Mobile OTP'],
    popular: true,
    portalType: 'central'
  },
  {
    id: 'eshram_portal',
    title: 'e-Shram Card',
    category: 'citizen_id',
    url: 'https://eshram.gov.in/',
    icon: '👷',
    description: 'National Database for Unorganized Workers, accidental insurance & financial assistance.',
    requiredDocs: ['Aadhaar Card', 'Bank Passbook / Account details', 'Active Mobile Number'],
    popular: true,
    portalType: 'central'
  },

  // State Schemes (Maharashtra & Regional)
  {
    id: 'ladki_bahin',
    title: 'Majhi Ladki Bahin Yojana',
    category: 'state_scheme',
    url: 'https://ladakibahin.maharashtra.gov.in/',
    icon: '👩',
    description: 'Maharashtra Govt scheme: ₹1,500/month financial aid for eligible women aged 21-65.',
    requiredDocs: ['Aadhaar Card', 'Maharashtra Domicile / Ration Card / Birth Cert', 'Income Certificate (<2.5L) or Yellow/Orange Ration Card', 'Aadhaar Seeded Bank Account', 'Applicant Photo'],
    popular: true,
    portalType: 'state'
  },
  {
    id: 'ladki_bahin_wcd',
    title: 'Ladki Bahin – WCD Dept',
    category: 'state_scheme',
    url: 'https://womenchild.maharashtra.gov.in/',
    icon: '📋',
    description: 'Women & Child Development department notices, guidelines, and official GRs.',
    requiredDocs: ['Aadhaar Card', 'Bank Passbook', 'Ration Card'],
    portalType: 'state'
  },
  {
    id: 'aaple_sarkar',
    title: 'Aaple Sarkar Maharashtra',
    category: 'state_scheme',
    url: 'https://aaplesarkar.mahaonline.gov.in/',
    icon: '🏛️',
    description: 'Online Revenue Services: Income Certificate, Caste Certificate, Domicile, Non-Creamy Layer, 7/12 & 8A.',
    requiredDocs: ['Aadhaar Card', 'Ration Card', 'Self-Declaration Form', 'School Leaving Certificate', 'Income Proof / Talathi report'],
    popular: true,
    portalType: 'state'
  },
  {
    id: 'mahadbt',
    title: 'MahaDBT Scholarship Portal',
    category: 'state_scheme',
    url: 'https://mahadbt.maharashtra.gov.in/',
    icon: '🎓',
    description: 'Post-Matric Scholarships, EBC fee reimbursement, Dr. Punjabrao Deshmukh hostel scheme.',
    requiredDocs: ['Aadhaar Card', 'Caste Certificate & Validity', 'Income Certificate', 'College Allotment / Fee Receipt', 'Mark sheets'],
    popular: true,
    portalType: 'state'
  },
  {
    id: 'mahabhulekh',
    title: 'Mahabhulekh (7/12 Online)',
    category: 'revenue',
    url: 'https://bhulekh.mahabhumi.gov.in/',
    icon: '🌾',
    description: 'Maharashtra Digital Satbara (7/12 extract), 8A property card & digital land records.',
    requiredDocs: ['District, Taluka, Village Name', 'Survey / Gat Number'],
    portalType: 'state'
  },

  // Central Schemes
  {
    id: 'pm_kisan',
    title: 'PM-KISAN Samman Nidhi',
    category: 'central_scheme',
    url: 'https://pmkisan.gov.in/',
    icon: '🌾',
    description: '₹6,000/year farmer benefit in 3 instalments, online biometric/face eKYC, beneficiary status.',
    requiredDocs: ['Aadhaar Card', '7/12 Land Record', 'Aadhaar Seeded Bank Account', 'Mobile OTP'],
    popular: true,
    portalType: 'central'
  },
  {
    id: 'pm_surya_ghar',
    title: 'PM Surya Ghar (Muft Bijli)',
    category: 'central_scheme',
    url: 'https://pmsuryaghar.gov.in/',
    icon: '☀️',
    description: 'Rooftop Solar Subsidy up to ₹78,000 for up to 300 units free electricity every month.',
    requiredDocs: ['Latest Electricity Bill', 'Aadhaar Card', 'Roof Photo / Electricity Consumer No', 'Bank Account Details'],
    popular: true,
    portalType: 'central'
  },
  {
    id: 'pm_awas',
    title: 'PM Awas Yojana (PMAY-G/U)',
    category: 'central_scheme',
    url: 'https://pmaymis.gov.in/',
    icon: '🏠',
    description: 'Housing for All subsidy scheme for urban and rural families to build pucca houses.',
    requiredDocs: ['Aadhaar Card of all family members', 'Income Certificate', 'Land / Property Ownership Document', 'Bank Passbook'],
    popular: true,
    portalType: 'central'
  },
  {
    id: 'pm_vishwakarma',
    title: 'PM Vishwakarma Yojana',
    category: 'central_scheme',
    url: 'https://pmvishwakarma.gov.in/',
    icon: '🛠️',
    description: '₹3 Lakh collateral-free loan, tool kit incentive ₹15,000 & skill training for 18 traditional trades.',
    requiredDocs: ['Aadhaar Card', 'Mobile Number', 'Bank Details', 'Ration Card', 'Trade Skill Certificate / Self Declaration'],
    popular: true,
    portalType: 'central'
  },
  {
    id: 'pm_svanidhi',
    title: 'PM SVANidhi (Street Vendors)',
    category: 'central_scheme',
    url: 'https://pmsvanidhi.mohua.gov.in/',
    icon: '🛺',
    description: 'Working capital micro-credit loan (₹10,000 to ₹50,000) with 7% interest subsidy for street vendors.',
    requiredDocs: ['Aadhaar Card', 'Vending Certificate / Urban Local Body Survey Card', 'Bank Account'],
    portalType: 'central'
  },
  {
    id: 'pm_fasal_bima',
    title: 'PM Fasal Bima Yojana (PMFBY)',
    category: 'central_scheme',
    url: 'https://pmfby.gov.in/',
    icon: '🌱',
    description: 'Crop insurance protection against natural calamities, pests, and unseasonal rainfall.',
    requiredDocs: ['7/12 extract & Sowing Certificate', 'Aadhaar Card', 'Bank Passbook'],
    portalType: 'central'
  },
  {
    id: 'pm_jandhan',
    title: 'PM Jan-Dhan Yojana (PMJDY)',
    category: 'central_scheme',
    url: 'https://pmjdy.gov.in/',
    icon: '🏦',
    description: 'Zero balance savings account with RuPay debit card, ₹2 Lakh accidental insurance & overdraft.',
    requiredDocs: ['Aadhaar Card', 'Passport size photo', 'Mobile Number'],
    portalType: 'central'
  },
  {
    id: 'pm_mudra',
    title: 'PM Mudra Yojana (PMMY)',
    category: 'central_scheme',
    url: 'https://www.mudra.org.in/',
    icon: '💳',
    description: 'Business micro-loans up to ₹10 Lakh (Shishu, Kishore, Tarun) for small enterprises.',
    requiredDocs: ['Aadhaar & PAN Card', 'Business address proof', '6 months Bank Statement', 'Quotation / Project report'],
    portalType: 'central'
  },
  {
    id: 'pm_ujjwala',
    title: 'PM Ujjwala Yojana 2.0',
    category: 'central_scheme',
    url: 'https://www.pmuy.gov.in/',
    icon: '🔥',
    description: 'Free LPG gas connection with first cylinder and stove subsidy for women in BPL households.',
    requiredDocs: ['BPL Ration Card', 'Aadhaar Card of adult family members', 'Bank Account with IFSC'],
    portalType: 'central'
  },
  {
    id: 'epfo_uan',
    title: 'EPFO / UAN Member Portal',
    category: 'central_scheme',
    url: 'https://unifiedportal-mem.epfindia.gov.in/memberinterface/',
    icon: '🏢',
    description: 'Provident Fund Passbook, PF Advance Withdrawal (Form 31/19/10C), KYC Update & Transfer.',
    requiredDocs: ['UAN Number', 'EPFO Password', 'Aadhaar Linked Mobile (for OTP)', 'Bank Account Verification'],
    popular: true,
    portalType: 'central'
  },

  // Transport & Driving
  {
    id: 'parivahan_sarathi',
    title: 'Parivahan Sarathi (Driving Licence)',
    category: 'transport',
    url: 'https://sarathi.parivahan.gov.in/',
    icon: '🚗',
    description: "Learner's Licence test, Permanent Driving Licence slot booking, DL Renewal & Address Change.",
    requiredDocs: ['Aadhaar Card', 'Medical Certificate (Form 1A if age >40)', 'Passport Photo', 'Signature'],
    popular: true,
    portalType: 'central'
  },
  {
    id: 'parivahan_vahan',
    title: 'Parivahan Vahan (Vehicle RC)',
    category: 'transport',
    url: 'https://vahan.parivahan.gov.in/',
    icon: '🏍️',
    description: 'RC Transfer, Duplicate RC, High Security Number Plate (HSRP), Pollution PUC & Tax payment.',
    requiredDocs: ['Vehicle Registration Number', 'Chassis Number (last 5 digits)', 'Insurance copy', 'Owner Aadhaar'],
    portalType: 'central'
  },
  {
    id: 'mahasarathi',
    title: 'MahaSarathi Transport Portal',
    category: 'transport',
    url: 'https://mahasarathi.maharashtra.gov.in/',
    icon: '🚌',
    description: 'Maharashtra state citizen transport helpline, online permit services and citizen grievance.',
    requiredDocs: ['Aadhaar Card', 'Vehicle RC'],
    portalType: 'state'
  },

  // Business & MSME
  {
    id: 'udyam_msme',
    title: 'Udyam MSME Registration',
    category: 'utility',
    url: 'https://udyamregistration.gov.in/',
    icon: '🏭',
    description: 'Free official Central MSME certificate for shops, cyber cafes, traders, and small businesses.',
    requiredDocs: ['Aadhaar Card (linked with mobile)', 'PAN Card', 'Bank Account details', 'Business Name & Start Date'],
    popular: true,
    portalType: 'central'
  },
  {
    id: 'passport_seva',
    title: 'Passport Seva Kendra (PSK)',
    category: 'utility',
    url: 'https://www.passportindia.gov.in/',
    icon: '✈️',
    description: 'Fresh Indian Passport application, Tatkaal passport, Police Clearance Certificate (PCC).',
    requiredDocs: ['Aadhaar Card', 'PAN Card', '10th Marksheet / Birth Certificate', 'Bank Passbook / Electricity Bill'],
    popular: true,
    portalType: 'central'
  },
  {
    id: 'csc_portal',
    title: 'Digital Seva CSC Portal',
    category: 'utility',
    url: 'https://digitalseva.csc.gov.in/',
    icon: '🌐',
    description: 'Common Service Centre VLE portal for government G2C and B2C citizen services.',
    requiredDocs: ['CSC ID', 'Password', 'Biometric / IRIS Device'],
    portalType: 'direct'
  },

  // Banking & Retailer Mitra Portals
  {
    id: 'airtel_mitra',
    title: 'Airtel Payments Bank Mitra',
    category: 'banking',
    url: 'https://portal.airtelbank.com/',
    icon: '📱',
    description: 'Retailer portal for AePS cash withdrawal, money transfer, micro-ATM & utility bill payment.',
    requiredDocs: ['Mitra Mobile Number', 'LAPU Password', 'Biometric Device'],
    portalType: 'direct'
  },
  {
    id: 'spice_money',
    title: 'Spice Money Retailer',
    category: 'banking',
    url: 'https://b2b.spicemoney.com/',
    icon: '🌶️',
    description: 'B2B portal for Aadhaar ATM, DMT, mATM, railway IRCTC booking, PAN card and bill payment.',
    requiredDocs: ['Spice Money ID', 'Password', 'OTP'],
    portalType: 'direct'
  },
  {
    id: 'paynearby',
    title: 'PayNearby Retailer',
    category: 'banking',
    url: 'https://portal.paynearby.in/',
    icon: '💰',
    description: 'Retailer platform for Digital Pradhan, cash deposit, credit card bill & loan repayment.',
    requiredDocs: ['PayNearby ID', 'Password'],
    portalType: 'direct'
  }
];

export const SERVICE_CATEGORIES = [
  { id: 'all', label: 'All Services', icon: '▦' },
  { id: 'citizen_id', label: 'Citizen IDs', icon: '🪪' },
  { id: 'state_scheme', label: 'Maharashtra Schemes', icon: '🏛️' },
  { id: 'central_scheme', label: 'Central Schemes', icon: '🌾' },
  { id: 'transport', label: 'Transport & DL', icon: '🚗' },
  { id: 'banking', label: 'Banking & AePS', icon: '🏦' },
  { id: 'revenue', label: 'Revenue & 7/12', icon: '📜' },
  { id: 'utility', label: 'MSME & Business', icon: '🏭' },
];

export const COMMON_SHOP_SERVICES = [
  { name: 'Custom Citizen Service (Manual Pricing)', category: 'General', govtFee: 0, serviceFee: 0 },
  { name: 'PVC Aadhaar / PAN / Smart Card Print', category: 'PVC Printing', govtFee: 0, serviceFee: 0 },
  { name: 'Passport Photos (8 Copies 4x6)', category: 'Photography', govtFee: 0, serviceFee: 0 },
  { name: 'Passport Photos (16 Copies A4)', category: 'Photography', govtFee: 0, serviceFee: 0 },
  { name: 'Majhi Ladki Bahin Yojana Application', category: 'Govt Schemes', govtFee: 0, serviceFee: 0 },
  { name: 'New PAN Card Application (Form 49A)', category: 'PAN Services', govtFee: 0, serviceFee: 0 },
  { name: 'PAN Card Correction / Update', category: 'PAN Services', govtFee: 0, serviceFee: 0 },
  { name: 'PAN - Aadhaar Link Online', category: 'PAN Services', govtFee: 0, serviceFee: 0 },
  { name: 'PM-KISAN eKYC / New Registration', category: 'Farmer Schemes', govtFee: 0, serviceFee: 0 },
  { name: 'PM Surya Ghar Rooftop Solar Application', category: 'Govt Schemes', govtFee: 0, serviceFee: 0 },
  { name: 'Ayushman Bharat Card Generation', category: 'Health Schemes', govtFee: 0, serviceFee: 0 },
  { name: 'New Voter ID Form 6 Application', category: 'Election', govtFee: 0, serviceFee: 0 },
  { name: "Learner's Driving Licence Slot & Test", category: 'RTO / Transport', govtFee: 0, serviceFee: 0 },
  { name: 'Aaple Sarkar Income / Domicile Certificate', category: 'Revenue', govtFee: 0, serviceFee: 0 },
  { name: 'Professional CV / Resume / BioData (A4)', category: 'Documentation', govtFee: 0, serviceFee: 0 },
  { name: 'e-Shram Card Registration / Download', category: 'Labor Schemes', govtFee: 0, serviceFee: 0 },
  { name: 'Udyam MSME Registration Certificate', category: 'Business', govtFee: 0, serviceFee: 0 },
  { name: 'Aadhaar Address Update Online', category: 'Aadhaar', govtFee: 0, serviceFee: 0 },
  { name: 'EPFO PF Advance Withdrawal Form 31', category: 'EPFO', govtFee: 0, serviceFee: 0 },
  { name: 'High-Res Color Print / Lamination', category: 'Printing', govtFee: 0, serviceFee: 0 },
  { name: 'PDF to HD JPG Conversion / Scanning', category: 'Scanning', govtFee: 0, serviceFee: 0 }
];
