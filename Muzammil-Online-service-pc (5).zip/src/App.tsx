import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { DashboardView } from './components/DashboardView';
import { PvcStudioView } from './components/PvcStudioView';
import { PassportStudioView } from './components/PassportStudioView';
import { PdfToJpgView } from './components/PdfToJpgView';
import { BillingDeskView } from './components/BillingDeskView';
import { CustomerCrmView } from './components/CustomerCrmView';
import { BioDataMakerView } from './components/BioDataMakerView';
import { GovernmentPortalsView } from './components/GovernmentPortalsView';
import { AiAssistantView } from './components/AiAssistantView';
import { DownloadsView } from './components/DownloadsView';
import { SettingsView } from './components/SettingsView';
import { MasterAdminView } from './components/MasterAdminView';
import { WorkflowGuideView } from './components/WorkflowGuideView';
import { VideoStudioView } from './components/VideoStudioView';
import { AuthModal } from './components/AuthModal';
import { ShortcutsModal } from './components/ShortcutsModal';

import { 
  BillItem, 
  CustomerRecord, 
  DownloadItem, 
  ShopSettings, 
  UserAccount 
} from './types';
import { 
  loadSettings, 
  saveSettings, 
  loadUser, 
  saveUser, 
  logoutUser,
  loadBills, 
  saveBills, 
  loadCustomers, 
  saveCustomers, 
  loadDownloads, 
  deleteDownloadRecord, 
  exportAllData,
  saveDownloads 
} from './utils/storage';
import { sendOperatorHeartbeat } from './utils/deviceSecurity';
import { LoginScreen } from './components/LoginScreen';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [settings, setSettings] = useState<ShopSettings>(loadSettings);
  const [user, setUser] = useState<UserAccount>(loadUser);
  const [bills, setBills] = useState<BillItem[]>(loadBills);
  const [customers, setCustomers] = useState<CustomerRecord[]>(loadCustomers);
  const [downloads, setDownloads] = useState<DownloadItem[]>(loadDownloads);
  const [adminBroadcastToast, setAdminBroadcastToast] = useState<string | null>(null);

  const [searchQuery, setSearchQuery] = useState<string>('');
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState<boolean>(false);
  const [showAuthModal, setShowAuthModal] = useState<boolean>(false);
  const [showShortcutsModal, setShowShortcutsModal] = useState<boolean>(false);

  // Live Operator Heartbeat loop
  useEffect(() => {
    if (!user.isLoggedIn || !user.username) return;

    const reportHeartbeat = async () => {
      try {
        const res = await sendOperatorHeartbeat({
          username: user.username,
          displayName: user.displayName,
          role: user.role,
          phone: user.phone,
          currentTab: activeTab,
          currentTask: `Active on ${activeTab}`
        });

        if (res && res.broadcastMessage) {
          if (res.broadcastMessage === 'FORCE_DISCONNECTED_BY_ADMIN') {
            alert('🚨 Your workstation session was disconnected by Master Admin.');
            handleLogout();
          } else {
            setAdminBroadcastToast(res.broadcastMessage);
            setTimeout(() => setAdminBroadcastToast(null), 8000);
          }
        }
      } catch {}
    };

    reportHeartbeat();
    const interval = setInterval(reportHeartbeat, 5000);
    return () => clearInterval(interval);
  }, [user.isLoggedIn, user.username, activeTab]);

  const handleAddDownload = (newDl: DownloadItem) => {
    const updated = [newDl, ...downloads];
    setDownloads(updated);
    saveDownloads(updated);
  };

  // Sync to storage
  const handleSaveSettings = (newSettings: ShopSettings) => {
    setSettings(newSettings);
    saveSettings(newSettings);
  };

  const handleSelectUser = (newUser: UserAccount) => {
    setUser(newUser);
    saveUser(newUser);
  };

  const handleLogout = () => {
    logoutUser();
    setUser({
      username: '',
      displayName: '',
      role: 'operator',
      phone: '',
      shopName: settings.shopName,
      isLoggedIn: false
    });
  };

  const handleAddBill = (newBill: BillItem) => {
    const updated = [newBill, ...bills];
    setBills(updated);
    saveBills(updated);
  };

  const handleDeleteBill = (id: string) => {
    const updated = bills.filter(b => b.id !== id);
    setBills(updated);
    saveBills(updated);
  };

  const handleAddCustomer = (newCustomer: CustomerRecord) => {
    const updated = [newCustomer, ...customers];
    setCustomers(updated);
    saveCustomers(updated);
  };

  const handleUpdateCustomerStatus = (id: string, newStatus: CustomerRecord['status']) => {
    const updated = customers.map(c => c.id === id ? { ...c, status: newStatus } : c);
    setCustomers(updated);
    saveCustomers(updated);
  };

  const handleDeleteCustomer = (id: string) => {
    const updated = customers.filter(c => c.id !== id);
    setCustomers(updated);
    saveCustomers(updated);
  };

  const handleDeleteDownload = (id: string) => {
    deleteDownloadRecord(id);
    setDownloads(loadDownloads());
  };

  const handleClearDownloads = () => {
    localStorage.removeItem('mos_pc_downloads');
    setDownloads([]);
  };

  // Keyboard Shortcuts for PC
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Focus search: Ctrl + K or '/'
      if ((e.ctrlKey && e.key === 'k') || (e.key === '/' && (e.target as HTMLElement).tagName !== 'INPUT' && (e.target as HTMLElement).tagName !== 'TEXTAREA')) {
        e.preventDefault();
        const searchInput = document.getElementById('pc-global-search');
        searchInput?.focus();
      }

      // Fast Bill: Ctrl + B
      if (e.ctrlKey && e.key === 'b') {
        e.preventDefault();
        setActiveTab('billing');
      }

      // Direct In-App Studio Print: Ctrl + P
      if (e.ctrlKey && e.key === 'p') {
        e.preventDefault();
        window.dispatchEvent(new CustomEvent('app-direct-print'));
      }

      // Direct In-App PDF Download: Ctrl + S
      if (e.ctrlKey && e.key === 's') {
        e.preventDefault();
        window.dispatchEvent(new CustomEvent('app-direct-pdf'));
      }

      // Direct In-App HD JPG Download: Ctrl + J
      if (e.ctrlKey && e.key === 'j') {
        e.preventDefault();
        window.dispatchEvent(new CustomEvent('app-direct-jpg'));
      }

      // Tab switcher: Alt + 1 to 9
      if (e.altKey) {
        const tabMap: Record<string, string> = {
          '1': 'dashboard',
          '2': 'pvc_studio',
          '3': 'passport_studio',
          '4': 'pdf_to_jpg',
          '5': 'billing',
          '6': 'customers',
          '7': 'biodata_maker',
          '8': 'portals',
          '9': 'ai_assistant'
        };
        if (tabMap[e.key]) {
          e.preventDefault();
          setActiveTab(tabMap[e.key]);
        }
      }

      // Shortcuts Modal: '?'
      if (e.key === '?' && (e.target as HTMLElement).tagName !== 'INPUT' && (e.target as HTMLElement).tagName !== 'TEXTAREA') {
        setShowShortcutsModal(true);
      }

      // Escape to close modals
      if (e.key === 'Escape') {
        setShowAuthModal(false);
        setShowShortcutsModal(false);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // When global search is typed, automatically switch to portals or show matches if not empty
  useEffect(() => {
    if (searchQuery.trim().length > 1 && activeTab !== 'portals' && activeTab !== 'dashboard') {
      setActiveTab('portals');
    }
  }, [searchQuery]);

  const pendingJobsCount = customers.filter(c => c.status === 'Pending' || c.status === 'Processing').length;

  // STRICT LOGIN WALL: Nothing works or displays without authentication!
  if (!user.isLoggedIn) {
    return (
      <LoginScreen
        settings={settings}
        onLoginSuccess={handleSelectUser}
      />
    );
  }

  return (
    <div className="flex flex-col h-screen w-screen bg-slate-950 text-slate-100 overflow-hidden font-sans selection:bg-blue-600 selection:text-white">
      {/* PC Top Navigation Header */}
      <Header
        settings={settings}
        user={user}
        activeTab={activeTab}
        onNavigate={(tab) => {
          setActiveTab(tab);
          setSearchQuery('');
        }}
        onOpenLogin={() => setShowAuthModal(true)}
        onOpenShortcuts={() => setShowShortcutsModal(true)}
        onLogout={handleLogout}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        isSidebarCollapsed={isSidebarCollapsed}
        onToggleSidebar={() => setIsSidebarCollapsed(prev => !prev)}
      />

      {/* Main Container: Sidebar + Workspace */}
      <div className="flex flex-1 overflow-hidden relative">
        {/* PC Sidebar Navigation */}
        <Sidebar
          activeTab={activeTab}
          onNavigate={(tab) => {
            setActiveTab(tab);
            setSearchQuery('');
          }}
          isCollapsed={isSidebarCollapsed}
          onToggleCollapse={() => setIsSidebarCollapsed(prev => !prev)}
          user={user}
          pendingJobsCount={pendingJobsCount}
          onLogout={handleLogout}
        />

        {/* Main Workstation View Area */}
        <main className="flex-1 overflow-y-auto p-4 lg:p-6 bg-slate-950 relative">
          {/* Admin Live Broadcast Toast */}
          {adminBroadcastToast && (
            <div className="mb-4 p-4 rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-xl flex items-center justify-between gap-3 animate-in fade-in slide-in-from-top-4 z-30">
              <div className="flex items-center gap-3">
                <span className="text-xl">📢</span>
                <div>
                  <span className="font-extrabold text-xs block uppercase tracking-wider text-blue-200">Broadcast from Master Admin:</span>
                  <p className="text-xs font-semibold">{adminBroadcastToast}</p>
                </div>
              </div>
              <button 
                onClick={() => setAdminBroadcastToast(null)}
                className="text-white/80 hover:text-white px-2 py-1 bg-white/10 rounded-lg text-xs font-bold"
              >
                Dismiss
              </button>
            </div>
          )}

          {activeTab === 'dashboard' && (
            <DashboardView
              bills={bills}
              customers={customers}
              settings={settings}
              onNavigate={setActiveTab}
              onOpenQuickBill={() => setActiveTab('billing')}
              onPrintBill={() => setActiveTab('billing')}
            />
          )}

          {activeTab === 'pvc_studio' && (
            <PvcStudioView />
          )}

          {activeTab === 'passport_studio' && (
            <PassportStudioView />
          )}

          {activeTab === 'video_studio' && (
            <VideoStudioView 
              onAddDownload={handleAddDownload}
              onNavigate={setActiveTab}
            />
          )}

          {activeTab === 'pdf_to_jpg' && (
            <PdfToJpgView />
          )}

          {activeTab === 'billing' && (
            <BillingDeskView
              bills={bills}
              settings={settings}
              onAddBill={handleAddBill}
              onDeleteBill={handleDeleteBill}
            />
          )}

          {activeTab === 'customers' && (
            <CustomerCrmView
              customers={customers}
              settings={settings}
              onAddCustomer={handleAddCustomer}
              onUpdateStatus={handleUpdateCustomerStatus}
              onDeleteCustomer={handleDeleteCustomer}
            />
          )}

          {activeTab === 'biodata_maker' && (
            <BioDataMakerView />
          )}

          {activeTab === 'workflow' && (
            <WorkflowGuideView onNavigate={setActiveTab} />
          )}

          {activeTab === 'master_admin' && (
            user.role === 'admin' ? (
              <MasterAdminView
                settings={settings}
                onUpdateSettings={handleSaveSettings}
                onNavigateToWorkflow={() => setActiveTab('workflow')}
              />
            ) : (
              <div className="max-w-md mx-auto text-center p-8 bg-slate-900 border border-slate-800 rounded-3xl mt-12 space-y-3 shadow-2xl">
                <div className="w-12 h-12 bg-rose-500/20 text-rose-400 rounded-2xl flex items-center justify-center mx-auto text-2xl font-bold border border-rose-500/30">
                  🔒
                </div>
                <h3 className="text-base font-extrabold text-white">Master Admin Restricted Access</h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Access Denied. The project source .ZIP archive, executable setup builder, and central security controls are strictly reserved for Master Admin (Imran Khan). Staff operators or customers cannot view or download this data.
                </p>
              </div>
            )
          )}

          {activeTab === 'portals' && (
            <GovernmentPortalsView 
              onAddDownload={handleAddDownload}
              onNavigate={setActiveTab}
            />
          )}

          {activeTab === 'ai_assistant' && (
            <AiAssistantView />
          )}

          {activeTab === 'downloads' && (
            <DownloadsView
              downloads={downloads}
              onDeleteDownload={handleDeleteDownload}
              onClearAll={handleClearDownloads}
            />
          )}

          {activeTab === 'settings' && (
            <SettingsView
              settings={settings}
              onSaveSettings={handleSaveSettings}
            />
          )}

          {activeTab === 'backup' && (
            <div className="max-w-2xl mx-auto space-y-4 pt-6">
              <div className="bg-slate-900 border border-slate-800 p-6 rounded-3xl shadow-xl text-center space-y-4">
                <div className="w-16 h-16 rounded-2xl bg-purple-600/20 border border-purple-500/30 flex items-center justify-center text-purple-400 mx-auto">
                  <span className="text-3xl">💾</span>
                </div>
                <h2 className="text-xl font-bold text-white">Full Station Data Backup</h2>
                <p className="text-xs text-slate-300 leading-relaxed max-w-md mx-auto">
                  Export all your bills ({bills.length}), customer records ({customers.length}), settings, and recent download logs into a single secure file.
                </p>
                <div className="flex justify-center gap-3 pt-2">
                  <button
                    onClick={exportAllData}
                    className="bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs px-5 py-2.5 rounded-xl shadow-lg shadow-purple-600/30 transition-all hover:scale-105"
                  >
                    Download Complete Backup JSON
                  </button>
                </div>
              </div>
            </div>
          )}
        </main>
      </div>

      {/* Auth Modal */}
      {showAuthModal && (
        <AuthModal
          currentUser={user}
          onSelectUser={handleSelectUser}
          onClose={() => setShowAuthModal(false)}
        />
      )}

      {/* Shortcuts Modal */}
      {showShortcutsModal && (
        <ShortcutsModal
          onClose={() => setShowShortcutsModal(false)}
        />
      )}
    </div>
  );
}
