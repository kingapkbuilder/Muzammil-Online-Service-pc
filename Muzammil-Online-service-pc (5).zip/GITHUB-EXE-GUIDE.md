# GitHub Actions Se Windows .EXE File Kaise Banayein (Full Step-by-Step Guide)

Agar aapke computer par heavy RAM ya software install karne ki suvidha nahi hai, to aap **GitHub ke cloud servers** ka use karke bilkul free mein 2 minute ke andar official Windows `.exe` setup file bana sakte hain.

Humne project ke andar **GitHub Actions Workflow** (`.github/workflows/build-windows-exe.yml`) pehle se set kar diya hai.

---

## 🚀 Step 1: GitHub par New Repository Banayein

1. **[https://github.com](https://github.com)** par jayein aur apna free account login karein.
2. Top-Right mein **`+` (Plus icon)** -> **"New repository"** par click karein.
3. Repository name dein: `muzammil-online-service` (ya koi bhi naam).
4. Isko **Private** ya **Public** rakhein, aur **"Create repository"** par click karein.

---

## 📤 Step 2: Code Ko GitHub par Upload Karein

Aapke paas 2 simple tareeqe hain:

### Tareeqa A (Git Command - Sabse Fast):
Apne computer par extract kiye gaye project folder mein CMD open karein aur yeh commands run karein:
```bash
git init
git add .
git commit -m "Muzammil Online Service Workstation v98"
git branch -M main
git remote add origin https://github.com/AAPKA_USERNAME/muzammil-online-service.git
git push -u origin main
```

### Tareeqa B (Direct Website par Upload):
1. GitHub par nayi repository page par **"uploading an existing file"** link par click karein.
2. Project ke sabhi files ko drag-and-drop karke **Commit changes** kar dein.

---

## ⚡ Step 3: GitHub Actions se Automatic .EXE Build Run Karein

1. Apni GitHub repository mein upar **"Actions"** tab par click karein.
2. Left side mein **"Build Windows Desktop EXE Setup"** workflow par click karein.
3. Right side mein **"Run workflow"** button par click karein:
   - Branch: `main` chunein.
   - Green button **"Run workflow"** par click kar dein!

---

## 📥 Step 4: Ready .EXE File Download Karein!

1. GitHub ka cloud computer automatic start ho jayega aur 2 se 3 minute ke andar green tick (✅) aa jayega.
2. Us successful build par click karein.
3. Page ke neeche **"Artifacts"** section mein aapko file milegi:
   - **`Muzammil-Online-Service-Windows-x64`** (Download Size: ~80-120 MB)
4. Is par click karke ZIP download karein.
5. ZIP extract karein — iske andar aapki **`Muzammil Online service pc.exe`** ready milegi!
6. Is `.exe` file ko double-click karke direct kisi bhi Windows 10 / 11 computer par chala sakte hain!

---

## 💡 Release Create Karke Permanent Download Link Banana (Optional)
Agar aap chahte hain ki aapke doston ya doosre cyber cafe operators ke liye ek direct download link ban jaye:
1. GitHub repository mein **Releases** -> **"Create a new release"** par click karein.
2. Tag version dein (jaise: `v1.0.0`).
3. Title dein: `Muzammil Online Service Desktop v1.0.0`.
4. **"Publish release"** par click karein.
5. GitHub automatically build karke Release page par direct `Muzammil-Online-Service-Windows-x64.zip` upload kar dega, jise koi bhi direct click karke download kar sakta hai!
