const express = __vite__cjsImport0_express;const cors = __vite__cjsImport1_cors;const dotenv = __vite__cjsImport2_dotenv;const fileURLToPath = __vite__cjsImport4_url["fileURLToPath"];import __vite__cjsImport0_express from "/node_modules/.vite/deps/express.js?v=090625a0";
import __vite__cjsImport1_cors from "/node_modules/.vite/deps/cors.js?v=090625a0";
import __vite__cjsImport2_dotenv from "/node_modules/.vite/deps/dotenv.js?v=090625a0";
import path from "/@id/__vite-browser-external:path";
import __vite__cjsImport4_url from "/@id/__vite-browser-external:url";
import { GoogleGenAI } from "/node_modules/.vite/deps/@google_genai.js?v=090625a0";
dotenv.config();
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();
const PORT = Number(process.env.PORT) || 3e3;
app.use(cors());
app.use(express.json({ limit: "10mb" }));
// Initialize Google Gen AI
let ai = null;
if (process.env.GEMINI_API_KEY) {
	ai = new GoogleGenAI({
		apiKey: process.env.GEMINI_API_KEY,
		httpOptions: { headers: { "User-Agent": "aistudio-build" } }
	});
}
// AI Assistant Endpoint for citizen schemes
app.post("/api/assistant", async (req, res) => {
	const { prompt } = req.body;
	if (!prompt) {
		return res.status(400).json({ error: "Prompt is required" });
	}
	if (!ai) {
		return res.json({
			reply: null,
			message: "Server Gemini API key not initialized"
		});
	}
	try {
		const response = await ai.models.generateContent({
			model: "gemini-3.8-flash",
			contents: prompt,
			config: { systemInstruction: `You are the AI Digital Assistant for Muzammil Online Service (a premier CSC & Cyber Cafe in Maharashtra, India).
You provide accurate, polite, and practical guidance in Hindi, English, or Hinglish to operators and citizens for:
- Majhi Ladki Bahin Yojana, PM-KISAN, Ayushman Bharat (PM-JAY), PM Surya Ghar, PM Awas, Ration Card
- Aadhaar update/download, PAN card (New 49A / Correction / Link), Voter ID, Driving Licence (Sarathi/Parivahan)
- Mahadbt scholarships, Aaple Sarkar revenue certificates (Income, Caste, Domicile, Non-Creamy Layer, 7/12)
- PVC card printing (CR-80 standard 85.6x54mm, 4x6 300 DPI) and passport photo specifications.
Always provide clear bullet points: 1) Eligibility, 2) Required Documents Checklist, 3) Official Portal Procedure, and 4) Important Deadlines / Tips. Keep the tone helpful, professional, and cyber cafe oriented.` }
		});
		const reply = response.text || "";
		return res.json({ reply });
	} catch (error) {
		console.error("Gemini error:", error);
		return res.json({
			reply: null,
			error: error.message || "Gemini API call failed"
		});
	}
});
// Endpoint to download original complete project source ZIP
app.get("/api/download-zip", async (_req, res) => {
	try {
		const { default: JSZip } = await import('/node_modules/.vite/deps/jszip.js?v=090625a0').then(m => ((m, n) => n || !m?.__esModule ? {	...typeof m === "object" && !Array.isArray(m) || typeof m === "function" ? m : {},	default: m} : m)(m.default, 1));
		const fs = await import("/@id/__vite-browser-external:fs");
		const zip = new JSZip();
		function addDirToZip(dirPath, zipFolder) {
			const entries = fs.readdirSync(dirPath, { withFileTypes: true });
			for (const entry of entries) {
				const fullPath = path.join(dirPath, entry.name);
				if (entry.name === "node_modules" || entry.name === ".git" || entry.name === "dist") {
					continue;
				}
				if (entry.isDirectory()) {
					const subFolder = zipFolder.folder(entry.name);
					addDirToZip(fullPath, subFolder);
				} else {
					const fileData = fs.readFileSync(fullPath);
					zipFolder.file(entry.name, fileData);
				}
			}
		}
		addDirToZip(__dirname, zip);
		const zipBuffer = await zip.generateAsync({
			type: "nodebuffer",
			compression: "DEFLATE",
			compressionOptions: { level: 9 }
		});
		res.setHeader("Content-Type", "application/zip");
		res.setHeader("Content-Disposition", "attachment; filename=\"Muzammil-Online-Service-Complete-Source.zip\"");
		return res.send(zipBuffer);
	} catch (err) {
		console.error("ZIP generation error:", err);
		return res.status(500).json({ error: "Failed to generate project ZIP: " + err.message });
	}
});
// Mount Vite middleware in development
if ("development" !== "production") {
	const { createServer: createViteServer } = await import("/node_modules/.vite/deps/vite.js?v=090625a0");
	const vite = await createViteServer({
		server: { middlewareMode: true },
		appType: "spa"
	});
	app.use(vite.middlewares);
} else {
	app.use(express.static(path.join(__dirname, "dist")));
	app.get("*", (_req, res) => {
		res.sendFile(path.join(__dirname, "dist", "index.html"));
	});
}
app.listen(PORT, "0.0.0.0", () => {
	console.log(`Server running at http://0.0.0.0:${PORT}`);
});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxhQUFhO0FBQ3BCLE9BQU8sVUFBVTtBQUNqQixPQUFPLFlBQVk7QUFDbkIsT0FBTyxVQUFVO0FBQ2pCLFNBQVMscUJBQXFCO0FBQzlCLFNBQVMsbUJBQW1CO0FBRTVCLE9BQU8sT0FBTztBQUVkLE1BQU0sYUFBYSxjQUFjLFlBQVksR0FBRztBQUNoRCxNQUFNLFlBQVksS0FBSyxRQUFRLFVBQVU7QUFFekMsTUFBTSxNQUFNLFFBQVE7QUFDcEIsTUFBTSxPQUFPLE9BQU8sUUFBUSxJQUFJLElBQUksS0FBSztBQUV6QyxJQUFJLElBQUksS0FBSyxDQUFDO0FBQ2QsSUFBSSxJQUFJLFFBQVEsS0FBSyxFQUFFLE9BQU8sT0FBTyxDQUFDLENBQUM7O0FBR3ZDLElBQUksS0FBeUI7QUFDN0IsSUFBSSxRQUFRLElBQUksZ0JBQWdCO0NBQzlCLEtBQUssSUFBSSxZQUFZO0VBQ25CLFFBQVEsUUFBUSxJQUFJO0VBQ3BCLGFBQWEsRUFDWCxTQUFTLEVBQ1AsY0FBYyxpQkFDaEIsRUFDRjtDQUNGLENBQUM7QUFDSDs7QUFHQSxJQUFJLEtBQUssa0JBQWtCLE9BQU8sS0FBSyxRQUFRO0NBQzdDLE1BQU0sRUFBRSxXQUFXLElBQUk7Q0FDdkIsSUFBSSxDQUFDLFFBQVE7RUFDWCxPQUFPLElBQUksT0FBTyxHQUFHLENBQUMsQ0FBQyxLQUFLLEVBQUUsT0FBTyxxQkFBcUIsQ0FBQztDQUM3RDtDQUVBLElBQUksQ0FBQyxJQUFJO0VBQ1AsT0FBTyxJQUFJLEtBQUs7R0FDZCxPQUFPO0dBQ1AsU0FBUztFQUNYLENBQUM7Q0FDSDtDQUVBLElBQUk7RUFDRixNQUFNLFdBQVcsTUFBTSxHQUFHLE9BQU8sZ0JBQWdCO0dBQy9DLE9BQU87R0FDUCxVQUFVO0dBQ1YsUUFBUSxFQUNOLG1CQUFtQjs7Ozs7O3FOQU9yQjtFQUNGLENBQUM7RUFFRCxNQUFNLFFBQVEsU0FBUyxRQUFRO0VBQy9CLE9BQU8sSUFBSSxLQUFLLEVBQUUsTUFBTSxDQUFDO0NBQzNCLFNBQVMsT0FBWTtFQUNuQixRQUFRLE1BQU0saUJBQWlCLEtBQUs7RUFDcEMsT0FBTyxJQUFJLEtBQUs7R0FDZCxPQUFPO0dBQ1AsT0FBTyxNQUFNLFdBQVc7RUFDMUIsQ0FBQztDQUNIO0FBQ0YsQ0FBQzs7QUFHRCxJQUFJLElBQUkscUJBQXFCLE9BQU8sTUFBTSxRQUFRO0NBQ2hELElBQUk7RUFDRixNQUFNLEVBQUUsU0FBUyxVQUFVLE1BQU0sT0FBTztFQUN4QyxNQUFNLEtBQUssTUFBTSxPQUFPO0VBQ3hCLE1BQU0sTUFBTSxJQUFJLE1BQU07RUFFdEIsU0FBUyxZQUFZLFNBQWlCLFdBQWdCO0dBQ3BELE1BQU0sVUFBVSxHQUFHLFlBQVksU0FBUyxFQUFFLGVBQWUsS0FBSyxDQUFDO0dBQy9ELEtBQUssTUFBTSxTQUFTLFNBQVM7SUFDM0IsTUFBTSxXQUFXLEtBQUssS0FBSyxTQUFTLE1BQU0sSUFBSTtJQUM5QyxJQUFJLE1BQU0sU0FBUyxrQkFBa0IsTUFBTSxTQUFTLFVBQVUsTUFBTSxTQUFTLFFBQVE7S0FDbkY7SUFDRjtJQUNBLElBQUksTUFBTSxZQUFZLEdBQUc7S0FDdkIsTUFBTSxZQUFZLFVBQVUsT0FBTyxNQUFNLElBQUk7S0FDN0MsWUFBWSxVQUFVLFNBQVM7SUFDakMsT0FBTztLQUNMLE1BQU0sV0FBVyxHQUFHLGFBQWEsUUFBUTtLQUN6QyxVQUFVLEtBQUssTUFBTSxNQUFNLFFBQVE7SUFDckM7R0FDRjtFQUNGO0VBRUEsWUFBWSxXQUFXLEdBQUc7RUFFMUIsTUFBTSxZQUFZLE1BQU0sSUFBSSxjQUFjO0dBQ3hDLE1BQU07R0FDTixhQUFhO0dBQ2Isb0JBQW9CLEVBQUUsT0FBTyxFQUFFO0VBQ2pDLENBQUM7RUFFRCxJQUFJLFVBQVUsZ0JBQWdCLGlCQUFpQjtFQUMvQyxJQUFJLFVBQVUsdUJBQXVCLHNFQUFvRTtFQUN6RyxPQUFPLElBQUksS0FBSyxTQUFTO0NBQzNCLFNBQVMsS0FBVTtFQUNqQixRQUFRLE1BQU0seUJBQXlCLEdBQUc7RUFDMUMsT0FBTyxJQUFJLE9BQU8sR0FBRyxDQUFDLENBQUMsS0FBSyxFQUFFLE9BQU8scUNBQXFDLElBQUksUUFBUSxDQUFDO0NBQ3pGO0FBQ0YsQ0FBQzs7QUFHRCxzQkFBNkIsY0FBYztDQUN6QyxNQUFNLEVBQUUsY0FBYyxxQkFBcUIsTUFBTSxPQUFPO0NBQ3hELE1BQU0sT0FBTyxNQUFNLGlCQUFpQjtFQUNsQyxRQUFRLEVBQUUsZ0JBQWdCLEtBQUs7RUFDL0IsU0FBUztDQUNYLENBQUM7Q0FDRCxJQUFJLElBQUksS0FBSyxXQUFXO0FBQzFCLE9BQU87Q0FDTCxJQUFJLElBQUksUUFBUSxPQUFPLEtBQUssS0FBSyxXQUFXLE1BQU0sQ0FBQyxDQUFDO0NBQ3BELElBQUksSUFBSSxNQUFNLE1BQU0sUUFBUTtFQUMxQixJQUFJLFNBQVMsS0FBSyxLQUFLLFdBQVcsUUFBUSxZQUFZLENBQUM7Q0FDekQsQ0FBQztBQUNIO0FBRUEsSUFBSSxPQUFPLE1BQU0saUJBQWlCO0NBQ2hDLFFBQVEsSUFBSSxvQ0FBb0MsTUFBTTtBQUN4RCxDQUFDIiwibmFtZXMiOltdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJzZXJ2ZXIudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IGV4cHJlc3MgZnJvbSAnZXhwcmVzcyc7XG5pbXBvcnQgY29ycyBmcm9tICdjb3JzJztcbmltcG9ydCBkb3RlbnYgZnJvbSAnZG90ZW52JztcbmltcG9ydCBwYXRoIGZyb20gJ3BhdGgnO1xuaW1wb3J0IHsgZmlsZVVSTFRvUGF0aCB9IGZyb20gJ3VybCc7XG5pbXBvcnQgeyBHb29nbGVHZW5BSSB9IGZyb20gJ0Bnb29nbGUvZ2VuYWknO1xuXG5kb3RlbnYuY29uZmlnKCk7XG5cbmNvbnN0IF9fZmlsZW5hbWUgPSBmaWxlVVJMVG9QYXRoKGltcG9ydC5tZXRhLnVybCk7XG5jb25zdCBfX2Rpcm5hbWUgPSBwYXRoLmRpcm5hbWUoX19maWxlbmFtZSk7XG5cbmNvbnN0IGFwcCA9IGV4cHJlc3MoKTtcbmNvbnN0IFBPUlQgPSBOdW1iZXIocHJvY2Vzcy5lbnYuUE9SVCkgfHwgMzAwMDtcblxuYXBwLnVzZShjb3JzKCkpO1xuYXBwLnVzZShleHByZXNzLmpzb24oeyBsaW1pdDogJzEwbWInIH0pKTtcblxuLy8gSW5pdGlhbGl6ZSBHb29nbGUgR2VuIEFJXG5sZXQgYWk6IEdvb2dsZUdlbkFJIHwgbnVsbCA9IG51bGw7XG5pZiAocHJvY2Vzcy5lbnYuR0VNSU5JX0FQSV9LRVkpIHtcbiAgYWkgPSBuZXcgR29vZ2xlR2VuQUkoe1xuICAgIGFwaUtleTogcHJvY2Vzcy5lbnYuR0VNSU5JX0FQSV9LRVksXG4gICAgaHR0cE9wdGlvbnM6IHtcbiAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgJ1VzZXItQWdlbnQnOiAnYWlzdHVkaW8tYnVpbGQnLFxuICAgICAgfSxcbiAgICB9LFxuICB9KTtcbn1cblxuLy8gQUkgQXNzaXN0YW50IEVuZHBvaW50IGZvciBjaXRpemVuIHNjaGVtZXNcbmFwcC5wb3N0KCcvYXBpL2Fzc2lzdGFudCcsIGFzeW5jIChyZXEsIHJlcykgPT4ge1xuICBjb25zdCB7IHByb21wdCB9ID0gcmVxLmJvZHk7XG4gIGlmICghcHJvbXB0KSB7XG4gICAgcmV0dXJuIHJlcy5zdGF0dXMoNDAwKS5qc29uKHsgZXJyb3I6ICdQcm9tcHQgaXMgcmVxdWlyZWQnIH0pO1xuICB9XG5cbiAgaWYgKCFhaSkge1xuICAgIHJldHVybiByZXMuanNvbih7XG4gICAgICByZXBseTogbnVsbCxcbiAgICAgIG1lc3NhZ2U6ICdTZXJ2ZXIgR2VtaW5pIEFQSSBrZXkgbm90IGluaXRpYWxpemVkJ1xuICAgIH0pO1xuICB9XG5cbiAgdHJ5IHtcbiAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFpLm1vZGVscy5nZW5lcmF0ZUNvbnRlbnQoe1xuICAgICAgbW9kZWw6ICdnZW1pbmktMy44LWZsYXNoJyxcbiAgICAgIGNvbnRlbnRzOiBwcm9tcHQsXG4gICAgICBjb25maWc6IHtcbiAgICAgICAgc3lzdGVtSW5zdHJ1Y3Rpb246IGBZb3UgYXJlIHRoZSBBSSBEaWdpdGFsIEFzc2lzdGFudCBmb3IgTXV6YW1taWwgT25saW5lIFNlcnZpY2UgKGEgcHJlbWllciBDU0MgJiBDeWJlciBDYWZlIGluIE1haGFyYXNodHJhLCBJbmRpYSkuXG5Zb3UgcHJvdmlkZSBhY2N1cmF0ZSwgcG9saXRlLCBhbmQgcHJhY3RpY2FsIGd1aWRhbmNlIGluIEhpbmRpLCBFbmdsaXNoLCBvciBIaW5nbGlzaCB0byBvcGVyYXRvcnMgYW5kIGNpdGl6ZW5zIGZvcjpcbi0gTWFqaGkgTGFka2kgQmFoaW4gWW9qYW5hLCBQTS1LSVNBTiwgQXl1c2htYW4gQmhhcmF0IChQTS1KQVkpLCBQTSBTdXJ5YSBHaGFyLCBQTSBBd2FzLCBSYXRpb24gQ2FyZFxuLSBBYWRoYWFyIHVwZGF0ZS9kb3dubG9hZCwgUEFOIGNhcmQgKE5ldyA0OUEgLyBDb3JyZWN0aW9uIC8gTGluayksIFZvdGVyIElELCBEcml2aW5nIExpY2VuY2UgKFNhcmF0aGkvUGFyaXZhaGFuKVxuLSBNYWhhZGJ0IHNjaG9sYXJzaGlwcywgQWFwbGUgU2Fya2FyIHJldmVudWUgY2VydGlmaWNhdGVzIChJbmNvbWUsIENhc3RlLCBEb21pY2lsZSwgTm9uLUNyZWFteSBMYXllciwgNy8xMilcbi0gUFZDIGNhcmQgcHJpbnRpbmcgKENSLTgwIHN0YW5kYXJkIDg1LjZ4NTRtbSwgNHg2IDMwMCBEUEkpIGFuZCBwYXNzcG9ydCBwaG90byBzcGVjaWZpY2F0aW9ucy5cbkFsd2F5cyBwcm92aWRlIGNsZWFyIGJ1bGxldCBwb2ludHM6IDEpIEVsaWdpYmlsaXR5LCAyKSBSZXF1aXJlZCBEb2N1bWVudHMgQ2hlY2tsaXN0LCAzKSBPZmZpY2lhbCBQb3J0YWwgUHJvY2VkdXJlLCBhbmQgNCkgSW1wb3J0YW50IERlYWRsaW5lcyAvIFRpcHMuIEtlZXAgdGhlIHRvbmUgaGVscGZ1bCwgcHJvZmVzc2lvbmFsLCBhbmQgY3liZXIgY2FmZSBvcmllbnRlZC5gXG4gICAgICB9XG4gICAgfSk7XG5cbiAgICBjb25zdCByZXBseSA9IHJlc3BvbnNlLnRleHQgfHwgJyc7XG4gICAgcmV0dXJuIHJlcy5qc29uKHsgcmVwbHkgfSk7XG4gIH0gY2F0Y2ggKGVycm9yOiBhbnkpIHtcbiAgICBjb25zb2xlLmVycm9yKCdHZW1pbmkgZXJyb3I6JywgZXJyb3IpO1xuICAgIHJldHVybiByZXMuanNvbih7XG4gICAgICByZXBseTogbnVsbCxcbiAgICAgIGVycm9yOiBlcnJvci5tZXNzYWdlIHx8ICdHZW1pbmkgQVBJIGNhbGwgZmFpbGVkJ1xuICAgIH0pO1xuICB9XG59KTtcblxuLy8gRW5kcG9pbnQgdG8gZG93bmxvYWQgb3JpZ2luYWwgY29tcGxldGUgcHJvamVjdCBzb3VyY2UgWklQXG5hcHAuZ2V0KCcvYXBpL2Rvd25sb2FkLXppcCcsIGFzeW5jIChfcmVxLCByZXMpID0+IHtcbiAgdHJ5IHtcbiAgICBjb25zdCB7IGRlZmF1bHQ6IEpTWmlwIH0gPSBhd2FpdCBpbXBvcnQoJ2pzemlwJyk7XG4gICAgY29uc3QgZnMgPSBhd2FpdCBpbXBvcnQoJ2ZzJyk7XG4gICAgY29uc3QgemlwID0gbmV3IEpTWmlwKCk7XG5cbiAgICBmdW5jdGlvbiBhZGREaXJUb1ppcChkaXJQYXRoOiBzdHJpbmcsIHppcEZvbGRlcjogYW55KSB7XG4gICAgICBjb25zdCBlbnRyaWVzID0gZnMucmVhZGRpclN5bmMoZGlyUGF0aCwgeyB3aXRoRmlsZVR5cGVzOiB0cnVlIH0pO1xuICAgICAgZm9yIChjb25zdCBlbnRyeSBvZiBlbnRyaWVzKSB7XG4gICAgICAgIGNvbnN0IGZ1bGxQYXRoID0gcGF0aC5qb2luKGRpclBhdGgsIGVudHJ5Lm5hbWUpO1xuICAgICAgICBpZiAoZW50cnkubmFtZSA9PT0gJ25vZGVfbW9kdWxlcycgfHwgZW50cnkubmFtZSA9PT0gJy5naXQnIHx8IGVudHJ5Lm5hbWUgPT09ICdkaXN0Jykge1xuICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICB9XG4gICAgICAgIGlmIChlbnRyeS5pc0RpcmVjdG9yeSgpKSB7XG4gICAgICAgICAgY29uc3Qgc3ViRm9sZGVyID0gemlwRm9sZGVyLmZvbGRlcihlbnRyeS5uYW1lKTtcbiAgICAgICAgICBhZGREaXJUb1ppcChmdWxsUGF0aCwgc3ViRm9sZGVyKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBjb25zdCBmaWxlRGF0YSA9IGZzLnJlYWRGaWxlU3luYyhmdWxsUGF0aCk7XG4gICAgICAgICAgemlwRm9sZGVyLmZpbGUoZW50cnkubmFtZSwgZmlsZURhdGEpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuXG4gICAgYWRkRGlyVG9aaXAoX19kaXJuYW1lLCB6aXApO1xuXG4gICAgY29uc3QgemlwQnVmZmVyID0gYXdhaXQgemlwLmdlbmVyYXRlQXN5bmMoe1xuICAgICAgdHlwZTogJ25vZGVidWZmZXInLFxuICAgICAgY29tcHJlc3Npb246ICdERUZMQVRFJyxcbiAgICAgIGNvbXByZXNzaW9uT3B0aW9uczogeyBsZXZlbDogOSB9XG4gICAgfSk7XG5cbiAgICByZXMuc2V0SGVhZGVyKCdDb250ZW50LVR5cGUnLCAnYXBwbGljYXRpb24vemlwJyk7XG4gICAgcmVzLnNldEhlYWRlcignQ29udGVudC1EaXNwb3NpdGlvbicsICdhdHRhY2htZW50OyBmaWxlbmFtZT1cIk11emFtbWlsLU9ubGluZS1TZXJ2aWNlLUNvbXBsZXRlLVNvdXJjZS56aXBcIicpO1xuICAgIHJldHVybiByZXMuc2VuZCh6aXBCdWZmZXIpO1xuICB9IGNhdGNoIChlcnI6IGFueSkge1xuICAgIGNvbnNvbGUuZXJyb3IoJ1pJUCBnZW5lcmF0aW9uIGVycm9yOicsIGVycik7XG4gICAgcmV0dXJuIHJlcy5zdGF0dXMoNTAwKS5qc29uKHsgZXJyb3I6ICdGYWlsZWQgdG8gZ2VuZXJhdGUgcHJvamVjdCBaSVA6ICcgKyBlcnIubWVzc2FnZSB9KTtcbiAgfVxufSk7XG5cbi8vIE1vdW50IFZpdGUgbWlkZGxld2FyZSBpbiBkZXZlbG9wbWVudFxuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHtcbiAgY29uc3QgeyBjcmVhdGVTZXJ2ZXI6IGNyZWF0ZVZpdGVTZXJ2ZXIgfSA9IGF3YWl0IGltcG9ydCgndml0ZScpO1xuICBjb25zdCB2aXRlID0gYXdhaXQgY3JlYXRlVml0ZVNlcnZlcih7XG4gICAgc2VydmVyOiB7IG1pZGRsZXdhcmVNb2RlOiB0cnVlIH0sXG4gICAgYXBwVHlwZTogJ3NwYSdcbiAgfSk7XG4gIGFwcC51c2Uodml0ZS5taWRkbGV3YXJlcyk7XG59IGVsc2Uge1xuICBhcHAudXNlKGV4cHJlc3Muc3RhdGljKHBhdGguam9pbihfX2Rpcm5hbWUsICdkaXN0JykpKTtcbiAgYXBwLmdldCgnKicsIChfcmVxLCByZXMpID0+IHtcbiAgICByZXMuc2VuZEZpbGUocGF0aC5qb2luKF9fZGlybmFtZSwgJ2Rpc3QnLCAnaW5kZXguaHRtbCcpKTtcbiAgfSk7XG59XG5cbmFwcC5saXN0ZW4oUE9SVCwgJzAuMC4wLjAnLCAoKSA9PiB7XG4gIGNvbnNvbGUubG9nKGBTZXJ2ZXIgcnVubmluZyBhdCBodHRwOi8vMC4wLjAuMDoke1BPUlR9YCk7XG59KTtcbiJdLCJmaWxlIjoiL2FwcC9hcHBsZXQvc2VydmVyLnRzIn0=