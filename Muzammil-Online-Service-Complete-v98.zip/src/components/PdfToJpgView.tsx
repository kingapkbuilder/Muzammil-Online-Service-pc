const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useRef = __vite__cjsImport0_react["useRef"];const JSZip = __vite__cjsImport3_jszip;const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=090625a0";
import { FileImage, Lock, Unlock, Download, Printer, FileArchive, AlertCircle, Loader2 } from "/node_modules/.vite/deps/lucide-react.js?v=090625a0";
import * as pdfjsLib from "/node_modules/.vite/deps/pdfjs-dist.js?v=090625a0";
import __vite__cjsImport3_jszip from "/node_modules/.vite/deps/jszip.js?v=090625a0";
import { addDownloadRecord } from "/src/utils/storage.ts";
var _jsxFileName = "/app/applet/src/components/PdfToJpgView.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=090625a0";
// Configure PDF.js worker
pdfjsLib.GlobalWorkerOptions.workerSrc = `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjsLib.version}/pdf.worker.min.mjs`;
export const PdfToJpgView = () => {
	const [selectedFile, setSelectedFile] = useState(null);
	const [password, setPassword] = useState("");
	const [isPasswordRequired, setIsPasswordRequired] = useState(false);
	const [dpi, setDpi] = useState(300);
	const [isRendering, setIsRendering] = useState(false);
	const [renderProgress, setRenderProgress] = useState("");
	const [renderedPages, setRenderedPages] = useState([]);
	const [errorMessage, setErrorMessage] = useState("");
	const fileInputRef = useRef(null);
	const handleFileChange = (e) => {
		const file = e.target.files?.[0];
		if (!file) return;
		if (file.type !== "application/pdf" && !file.name.endsWith(".pdf")) {
			setErrorMessage("Please select a valid PDF file.");
			return;
		}
		setSelectedFile(file);
		setErrorMessage("");
		setIsPasswordRequired(false);
		setRenderedPages([]);
		processPDF(file, password);
	};
	const processPDF = async (file, pass) => {
		setIsRendering(true);
		setErrorMessage("");
		setRenderedPages([]);
		setRenderProgress("Reading PDF file...");
		try {
			const arrayBuffer = await file.arrayBuffer();
			const loadingTask = pdfjsLib.getDocument({
				data: arrayBuffer,
				password: pass || undefined
			});
			loadingTask.onPassword = (callback, reason) => {
				setIsPasswordRequired(true);
				setIsRendering(false);
				setRenderProgress("");
				if (reason === pdfjsLib.PasswordResponses.INCORRECT_PASSWORD) {
					setErrorMessage("Incorrect password. Please enter the correct password.");
				} else {
					setErrorMessage("This PDF is password protected. Enter password below to unlock.");
				}
			};
			const pdfDoc = await loadingTask.promise;
			setIsPasswordRequired(false);
			const totalPages = pdfDoc.numPages;
			const pagesArr = [];
			// Scale factor: standard PDF 72 DPI -> desired DPI
			// scale = dpi / 72 (e.g. 300 / 72 ≈ 4.166)
			const scale = dpi / 72;
			for (let pageNum = 1; pageNum <= totalPages; pageNum++) {
				setRenderProgress(`Rendering Page ${pageNum} of ${totalPages} at ${dpi} DPI...`);
				const page = await pdfDoc.getPage(pageNum);
				const viewport = page.getViewport({ scale });
				const canvas = document.createElement("canvas");
				canvas.width = viewport.width;
				canvas.height = viewport.height;
				const ctx = canvas.getContext("2d");
				if (ctx) {
					ctx.fillStyle = "#ffffff";
					ctx.fillRect(0, 0, canvas.width, canvas.height);
					await page.render({
						canvasContext: ctx,
						viewport,
						canvas
					}).promise;
					pagesArr.push({
						pageNum,
						dataUrl: canvas.toDataURL("image/jpeg", .96),
						width: viewport.width,
						height: viewport.height
					});
				}
			}
			setRenderedPages(pagesArr);
			setRenderProgress("");
		} catch (err) {
			console.error(err);
			if (err.name === "PasswordException") {
				setIsPasswordRequired(true);
				setErrorMessage("This PDF is protected. Please enter password (e.g. Aadhaar: CAPITAL 4 letters of name + Birth Year).");
			} else {
				setErrorMessage(err.message || "Failed to parse PDF.");
			}
		} finally {
			setIsRendering(false);
		}
	};
	const handlePasswordSubmit = (e) => {
		e.preventDefault();
		if (!selectedFile) return;
		processPDF(selectedFile, password);
	};
	// Download single page JPG
	const handleDownloadSingle = (page) => {
		const a = document.createElement("a");
		a.href = page.dataUrl;
		const fileName = `${selectedFile?.name.replace(".pdf", "") || "Document"}_Page_${page.pageNum}_${dpi}DPI.jpg`;
		a.download = fileName;
		a.click();
		addDownloadRecord({
			id: `pdf-jpg-${Date.now()}-${page.pageNum}`,
			title: fileName,
			type: "Converted JPG",
			size: `${Math.round(page.width)}×${Math.round(page.height)} px (${dpi} DPI)`,
			timestamp: new Date().toLocaleTimeString("en-IN")
		});
	};
	// Download all pages as a ZIP
	const handleDownloadAllZip = async () => {
		if (renderedPages.length === 0) return;
		setIsRendering(true);
		setRenderProgress("Creating ZIP archive of all pages...");
		try {
			const zip = new JSZip();
			const baseName = selectedFile?.name.replace(".pdf", "") || "Document";
			renderedPages.forEach((p) => {
				// Strip data:image/jpeg;base64,
				const base64Data = p.dataUrl.split(",")[1];
				zip.file(`${baseName}_Page_${p.pageNum}.jpg`, base64Data, { base64: true });
			});
			const content = await zip.generateAsync({ type: "blob" });
			const url = URL.createObjectURL(content);
			const a = document.createElement("a");
			a.href = url;
			const zipName = `${baseName}_All_Pages_${dpi}DPI.zip`;
			a.download = zipName;
			a.click();
			URL.revokeObjectURL(url);
			addDownloadRecord({
				id: `pdf-zip-${Date.now()}`,
				title: zipName,
				type: "Converted JPG",
				size: `${renderedPages.length} Pages in ZIP (${dpi} DPI)`,
				timestamp: new Date().toLocaleTimeString("en-IN")
			});
		} catch (e) {
			console.error(e);
		} finally {
			setIsRendering(false);
			setRenderProgress("");
		}
	};
	// Direct Print single page
	const handlePrintPage = (page) => {
		const printWin = window.open("", "_blank", "width=800,height=950");
		if (!printWin) return;
		printWin.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>Print Page ${page.pageNum}</title>
          <style>
            @page { size: auto; margin: 5mm; }
            body { margin: 0; padding: 0; display: flex; align-items: center; justify-content: center; background: #fff; }
            img { max-width: 100%; height: auto; display: block; image-rendering: -webkit-optimize-contrast; }
          </style>
        </head>
        <body>
          <img src="${page.dataUrl}" onload="window.print(); window.close();" />
        </body>
      </html>
    `);
		printWin.document.close();
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "space-y-4",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900 border border-slate-800 p-4 rounded-2xl shadow-md",
			children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center gap-2",
				children: [/* @__PURE__ */ _jsxDEV("h1", {
					className: "text-xl font-extrabold text-white",
					children: "PDF to HD JPG Converter Pro"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 226,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("span", {
					className: "bg-amber-500/20 text-amber-300 border border-amber-500/30 text-xs px-2 py-0.5 rounded-full font-mono font-bold",
					children: "Password Unlock & 300 DPI"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 227,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 225,
				columnNumber: 11
			}, this), /* @__PURE__ */ _jsxDEV("p", {
				className: "text-xs text-slate-400 mt-0.5",
				children: "Convert e-Aadhaar, PAN cards, marksheet PDFs to high-resolution JPEGs with batch ZIP export"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 231,
				columnNumber: 11
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 224,
				columnNumber: 9
			}, this), renderedPages.length > 0 && /* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center gap-2",
				children: /* @__PURE__ */ _jsxDEV("button", {
					onClick: handleDownloadAllZip,
					className: "flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs px-3.5 py-2 rounded-xl shadow-lg shadow-emerald-600/30 transition-all hover:scale-105",
					children: [/* @__PURE__ */ _jsxDEV(FileArchive, { className: "w-4 h-4" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 242,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: [
						"Download All as ZIP (",
						renderedPages.length,
						")"
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 243,
						columnNumber: 15
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 238,
					columnNumber: 13
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 237,
				columnNumber: 11
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 223,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "grid grid-cols-1 lg:grid-cols-12 gap-5 items-start",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "lg:col-span-4 space-y-4",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-md space-y-3",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "text-xs font-bold text-slate-300 uppercase tracking-wider block",
							children: "Select PDF Document"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 255,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("label", {
							className: "flex flex-col items-center justify-center border-2 border-dashed border-slate-700 hover:border-amber-500 p-5 rounded-xl cursor-pointer bg-slate-950/40 hover:bg-amber-950/10 transition-colors text-center",
							children: [
								/* @__PURE__ */ _jsxDEV(FileImage, { className: "w-8 h-8 text-amber-400 mb-2" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 258,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs font-bold text-white",
									children: selectedFile ? selectedFile.name : "Choose or Drag PDF File"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 259,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									className: "text-[11px] text-slate-400 mt-0.5",
									children: selectedFile ? `${(selectedFile.size / 1024 / 1024).toFixed(2)} MB` : "e-Aadhaar, PAN, Marksheets, Certificates"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 262,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("input", {
									ref: fileInputRef,
									type: "file",
									accept: "application/pdf",
									onChange: handleFileChange,
									className: "hidden"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 265,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 257,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 254,
						columnNumber: 11
					}, this),
					(isPasswordRequired || isPasswordRequired) && /* @__PURE__ */ _jsxDEV("div", {
						className: "bg-slate-900/90 border border-amber-500/40 rounded-2xl p-4 shadow-md space-y-3",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2 text-amber-400",
								children: [/* @__PURE__ */ _jsxDEV(Lock, { className: "w-4 h-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 279,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs font-bold uppercase tracking-wider",
									children: "Password Protected PDF"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 280,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 278,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("form", {
								onSubmit: handlePasswordSubmit,
								className: "space-y-2 text-xs",
								children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "text-[11px] text-slate-300 block mb-1",
									children: "Enter Password:"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 285,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "password",
									placeholder: "Enter document password",
									value: password,
									onChange: (e) => setPassword(e.target.value),
									className: "w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono text-sm focus:outline-none focus:border-amber-500"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 286,
									columnNumber: 19
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 284,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									type: "submit",
									disabled: isRendering || !password,
									className: "w-full flex items-center justify-center gap-1.5 bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs py-2 rounded-xl transition-colors disabled:opacity-50",
									children: [/* @__PURE__ */ _jsxDEV(Unlock, { className: "w-3.5 h-3.5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 300,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Unlock & Convert PDF" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 301,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 295,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 283,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "p-2.5 rounded-lg bg-slate-950 border border-slate-800 text-[11px] text-slate-400 space-y-1",
								children: [
									/* @__PURE__ */ _jsxDEV("b", {
										className: "text-slate-300 block",
										children: "Common Password Formats:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 307,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [
										"• ",
										/* @__PURE__ */ _jsxDEV("b", { children: "e-Aadhaar:" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 308,
											columnNumber: 24
										}, this),
										" 1st 4 letters of name in CAPITAL + Birth Year (e.g. ",
										/* @__PURE__ */ _jsxDEV("code", { children: "IMRA1995" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 308,
											columnNumber: 94
										}, this),
										")"
									] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 308,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [
										"• ",
										/* @__PURE__ */ _jsxDEV("b", { children: "e-PAN:" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 309,
											columnNumber: 24
										}, this),
										" Date of Birth in DDMMYYYY format (e.g. ",
										/* @__PURE__ */ _jsxDEV("code", { children: "15081998" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 309,
											columnNumber: 77
										}, this),
										")"
									] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 309,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 306,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 277,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-md space-y-3",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "text-xs font-bold text-slate-300 uppercase tracking-wider block",
							children: "Output Resolution (DPI)"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 316,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "grid grid-cols-3 gap-2",
							children: [
								{
									dpiVal: 150,
									label: "150 DPI",
									sub: "Standard"
								},
								{
									dpiVal: 300,
									label: "300 DPI",
									sub: "Print HD"
								},
								{
									dpiVal: 400,
									label: "400 DPI",
									sub: "Ultra Clear"
								}
							].map((item) => /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => {
									setDpi(item.dpiVal);
									if (selectedFile) processPDF(selectedFile, password);
								},
								className: `p-2 rounded-xl text-xs font-bold border transition-all ${dpi === item.dpiVal ? "bg-blue-600 text-white border-blue-500 shadow-md" : "bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-750"}`,
								children: [/* @__PURE__ */ _jsxDEV("div", { children: item.label }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 336,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "text-[10px] font-normal opacity-80",
									children: item.sub
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 337,
									columnNumber: 19
								}, this)]
							}, item.dpiVal, true, {
								fileName: _jsxFileName,
								lineNumber: 324,
								columnNumber: 17
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 318,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 315,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 252,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "lg:col-span-8 space-y-3",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-xl min-h-[460px]",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between mb-3 text-xs",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "font-bold text-white flex items-center gap-1.5",
								children: [/* @__PURE__ */ _jsxDEV(FileImage, { className: "w-3.5 h-3.5 text-blue-400" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 349,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Rendered Document Pages" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 350,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 348,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "text-slate-400 font-mono",
								children: renderedPages.length > 0 ? `${renderedPages.length} Pages Ready` : "No file loaded"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 352,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 347,
							columnNumber: 13
						}, this),
						isRendering && /* @__PURE__ */ _jsxDEV("div", {
							className: "p-4 rounded-xl bg-blue-950/40 border border-blue-500/30 text-blue-300 flex items-center gap-3 text-xs",
							children: [/* @__PURE__ */ _jsxDEV(Loader2, { className: "w-4 h-4 animate-spin text-blue-400" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 360,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: renderProgress }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 361,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 359,
							columnNumber: 15
						}, this),
						errorMessage && /* @__PURE__ */ _jsxDEV("div", {
							className: "p-3.5 rounded-xl bg-rose-950/40 border border-rose-500/30 text-rose-300 flex items-center gap-2.5 text-xs mb-3",
							children: [/* @__PURE__ */ _jsxDEV(AlertCircle, { className: "w-4 h-4 flex-shrink-0 text-rose-400" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 367,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: errorMessage }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 368,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 366,
							columnNumber: 15
						}, this),
						!isRendering && renderedPages.length === 0 && !errorMessage && /* @__PURE__ */ _jsxDEV("div", {
							className: "h-80 flex flex-col items-center justify-center text-center p-6 border-2 border-dashed border-slate-800 rounded-xl",
							children: [
								/* @__PURE__ */ _jsxDEV(FileImage, { className: "w-12 h-12 text-slate-600 mb-2" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 375,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									className: "text-sm font-bold text-slate-400",
									children: "No PDF Processed Yet"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 376,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-slate-500 max-w-sm mt-1",
									children: "Upload an e-Aadhaar, PAN card, or multi-page PDF on the left. High resolution 300 DPI pages will appear here."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 377,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 374,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "grid grid-cols-1 md:grid-cols-2 gap-4",
							children: renderedPages.map((page) => /* @__PURE__ */ _jsxDEV("div", {
								className: "bg-slate-950 border border-slate-800 rounded-xl overflow-hidden p-3 shadow-md flex flex-col justify-between",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-2",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center justify-between text-xs text-slate-400 border-b border-slate-800/80 pb-2",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "font-bold text-white",
											children: ["Page ", page.pageNum]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 392,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "font-mono text-[11px] text-slate-500",
											children: [
												Math.round(page.width),
												" × ",
												Math.round(page.height),
												" px"
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 393,
											columnNumber: 23
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 391,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "bg-white rounded-lg overflow-hidden border border-slate-700 shadow-inner flex items-center justify-center p-1",
										children: /* @__PURE__ */ _jsxDEV("img", {
											src: page.dataUrl,
											alt: `Page ${page.pageNum}`,
											className: "w-full h-auto object-contain max-h-[360px]"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 399,
											columnNumber: 23
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 398,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 390,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-2 gap-2 mt-3 pt-2.5 border-t border-slate-800/80",
									children: [/* @__PURE__ */ _jsxDEV("button", {
										onClick: () => handleDownloadSingle(page),
										className: "flex items-center justify-center gap-1.5 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs py-2 rounded-lg transition-colors",
										title: "Download Page as HD JPG",
										children: [/* @__PURE__ */ _jsxDEV(Download, { className: "w-3.5 h-3.5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 413,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Download JPG" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 414,
											columnNumber: 23
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 408,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("button", {
										onClick: () => handlePrintPage(page),
										className: "flex items-center justify-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white font-bold text-xs py-2 rounded-lg border border-slate-700 transition-colors",
										title: "Print Page Directly",
										children: [/* @__PURE__ */ _jsxDEV(Printer, { className: "w-3.5 h-3.5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 422,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Print Page" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 423,
											columnNumber: 23
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 417,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 407,
									columnNumber: 19
								}, this)]
							}, page.pageNum, true, {
								fileName: _jsxFileName,
								lineNumber: 386,
								columnNumber: 17
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 384,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 346,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 345,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 250,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 221,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsY0FBYztBQUN4QyxTQUNFLFdBRUEsTUFDQSxRQUNBLFVBQ0EsU0FDQSxhQUVBLGFBQ0EsZUFHSztBQUNQLFlBQVksY0FBYztBQUMxQixPQUFPLFdBQVc7QUFDbEIsU0FBUyx5QkFBeUI7Ozs7QUFHbEMsU0FBUyxvQkFBb0IsWUFBWSxpREFBaUQsU0FBUyxRQUFRO0FBUzNHLE9BQU8sTUFBTSxxQkFBK0I7Q0FDMUMsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQXNCLElBQUk7Q0FDbEUsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFpQixFQUFFO0NBQ25ELE1BQU0sQ0FBQyxvQkFBb0IseUJBQXlCLFNBQWtCLEtBQUs7Q0FDM0UsTUFBTSxDQUFDLEtBQUssVUFBVSxTQUFpQixHQUFHO0NBQzFDLE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFrQixLQUFLO0NBQzdELE1BQU0sQ0FBQyxnQkFBZ0IscUJBQXFCLFNBQWlCLEVBQUU7Q0FDL0QsTUFBTSxDQUFDLGVBQWUsb0JBQW9CLFNBQTJCLENBQUMsQ0FBQztDQUN2RSxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBaUIsRUFBRTtDQUUzRCxNQUFNLGVBQWUsT0FBZ0MsSUFBSTtDQUV6RCxNQUFNLG9CQUFvQixNQUEyQztFQUNuRSxNQUFNLE9BQU8sRUFBRSxPQUFPLFFBQVE7RUFDOUIsSUFBSSxDQUFDLE1BQU07RUFDWCxJQUFJLEtBQUssU0FBUyxxQkFBcUIsQ0FBQyxLQUFLLEtBQUssU0FBUyxNQUFNLEdBQUc7R0FDbEUsZ0JBQWdCLGlDQUFpQztHQUNqRDtFQUNGO0VBQ0EsZ0JBQWdCLElBQUk7RUFDcEIsZ0JBQWdCLEVBQUU7RUFDbEIsc0JBQXNCLEtBQUs7RUFDM0IsaUJBQWlCLENBQUMsQ0FBQztFQUNuQixXQUFXLE1BQU0sUUFBUTtDQUMzQjtDQUVBLE1BQU0sYUFBYSxPQUFPLE1BQVksU0FBaUI7RUFDckQsZUFBZSxJQUFJO0VBQ25CLGdCQUFnQixFQUFFO0VBQ2xCLGlCQUFpQixDQUFDLENBQUM7RUFDbkIsa0JBQWtCLHFCQUFxQjtFQUV2QyxJQUFJO0dBQ0YsTUFBTSxjQUFjLE1BQU0sS0FBSyxZQUFZO0dBQzNDLE1BQU0sY0FBYyxTQUFTLFlBQVk7SUFDdkMsTUFBTTtJQUNOLFVBQVUsUUFBUTtHQUNwQixDQUFDO0dBRUQsWUFBWSxjQUFjLFVBQWUsV0FBZ0I7SUFDdkQsc0JBQXNCLElBQUk7SUFDMUIsZUFBZSxLQUFLO0lBQ3BCLGtCQUFrQixFQUFFO0lBQ3BCLElBQUksV0FBVyxTQUFTLGtCQUFrQixvQkFBb0I7S0FDNUQsZ0JBQWdCLHdEQUF3RDtJQUMxRSxPQUFPO0tBQ0wsZ0JBQWdCLGlFQUFpRTtJQUNuRjtHQUNGO0dBRUEsTUFBTSxTQUFTLE1BQU0sWUFBWTtHQUNqQyxzQkFBc0IsS0FBSztHQUMzQixNQUFNLGFBQWEsT0FBTztHQUMxQixNQUFNLFdBQTZCLENBQUM7OztHQUlwQyxNQUFNLFFBQVEsTUFBTTtHQUVwQixLQUFLLElBQUksVUFBVSxHQUFHLFdBQVcsWUFBWSxXQUFXO0lBQ3RELGtCQUFrQixrQkFBa0IsUUFBUSxNQUFNLFdBQVcsTUFBTSxJQUFJLFFBQVE7SUFDL0UsTUFBTSxPQUFPLE1BQU0sT0FBTyxRQUFRLE9BQU87SUFDekMsTUFBTSxXQUFXLEtBQUssWUFBWSxFQUFFLE1BQU0sQ0FBQztJQUUzQyxNQUFNLFNBQVMsU0FBUyxjQUFjLFFBQVE7SUFDOUMsT0FBTyxRQUFRLFNBQVM7SUFDeEIsT0FBTyxTQUFTLFNBQVM7SUFDekIsTUFBTSxNQUFNLE9BQU8sV0FBVyxJQUFJO0lBRWxDLElBQUksS0FBSztLQUNQLElBQUksWUFBWTtLQUNoQixJQUFJLFNBQVMsR0FBRyxHQUFHLE9BQU8sT0FBTyxPQUFPLE1BQU07S0FFOUMsTUFBTyxLQUFLLE9BQU87TUFDakIsZUFBZTtNQUNMO01BQ0Y7S0FDVixDQUFRLENBQUMsQ0FBRTtLQUVYLFNBQVMsS0FBSztNQUNaO01BQ0EsU0FBUyxPQUFPLFVBQVUsY0FBYyxHQUFJO01BQzVDLE9BQU8sU0FBUztNQUNoQixRQUFRLFNBQVM7S0FDbkIsQ0FBQztJQUNIO0dBQ0Y7R0FFQSxpQkFBaUIsUUFBUTtHQUN6QixrQkFBa0IsRUFBRTtFQUN0QixTQUFTLEtBQVU7R0FDakIsUUFBUSxNQUFNLEdBQUc7R0FDakIsSUFBSSxJQUFJLFNBQVMscUJBQXFCO0lBQ3BDLHNCQUFzQixJQUFJO0lBQzFCLGdCQUFnQixzR0FBc0c7R0FDeEgsT0FBTztJQUNMLGdCQUFnQixJQUFJLFdBQVcsc0JBQXNCO0dBQ3ZEO0VBQ0YsVUFBVTtHQUNSLGVBQWUsS0FBSztFQUN0QjtDQUNGO0NBRUEsTUFBTSx3QkFBd0IsTUFBdUI7RUFDbkQsRUFBRSxlQUFlO0VBQ2pCLElBQUksQ0FBQyxjQUFjO0VBQ25CLFdBQVcsY0FBYyxRQUFRO0NBQ25DOztDQUdBLE1BQU0sd0JBQXdCLFNBQXlCO0VBQ3JELE1BQU0sSUFBSSxTQUFTLGNBQWMsR0FBRztFQUNwQyxFQUFFLE9BQU8sS0FBSztFQUNkLE1BQU0sV0FBVyxHQUFHLGNBQWMsS0FBSyxRQUFRLFFBQVEsRUFBRSxLQUFLLFdBQVcsUUFBUSxLQUFLLFFBQVEsR0FBRyxJQUFJO0VBQ3JHLEVBQUUsV0FBVztFQUNiLEVBQUUsTUFBTTtFQUVSLGtCQUFrQjtHQUNoQixJQUFJLFdBQVcsS0FBSyxJQUFJLEVBQUUsR0FBRyxLQUFLO0dBQ2xDLE9BQU87R0FDUCxNQUFNO0dBQ04sTUFBTSxHQUFHLEtBQUssTUFBTSxLQUFLLEtBQUssRUFBRSxHQUFHLEtBQUssTUFBTSxLQUFLLE1BQU0sRUFBRSxPQUFPLElBQUk7R0FDdEUsV0FBVyxJQUFJLEtBQUssQ0FBQyxDQUFDLG1CQUFtQixPQUFPO0VBQ2xELENBQUM7Q0FDSDs7Q0FHQSxNQUFNLHVCQUF1QixZQUFZO0VBQ3ZDLElBQUksY0FBYyxXQUFXLEdBQUc7RUFDaEMsZUFBZSxJQUFJO0VBQ25CLGtCQUFrQixzQ0FBc0M7RUFFeEQsSUFBSTtHQUNGLE1BQU0sTUFBTSxJQUFJLE1BQU07R0FDdEIsTUFBTSxXQUFXLGNBQWMsS0FBSyxRQUFRLFFBQVEsRUFBRSxLQUFLO0dBRTNELGNBQWMsU0FBUyxNQUFNOztJQUUzQixNQUFNLGFBQWEsRUFBRSxRQUFRLE1BQU0sR0FBRyxDQUFDLENBQUM7SUFDeEMsSUFBSSxLQUFLLEdBQUcsU0FBUyxRQUFRLEVBQUUsUUFBUSxPQUFPLFlBQVksRUFBRSxRQUFRLEtBQUssQ0FBQztHQUM1RSxDQUFDO0dBRUQsTUFBTSxVQUFVLE1BQU0sSUFBSSxjQUFjLEVBQUUsTUFBTSxPQUFPLENBQUM7R0FDeEQsTUFBTSxNQUFNLElBQUksZ0JBQWdCLE9BQU87R0FDdkMsTUFBTSxJQUFJLFNBQVMsY0FBYyxHQUFHO0dBQ3BDLEVBQUUsT0FBTztHQUNULE1BQU0sVUFBVSxHQUFHLFNBQVMsYUFBYSxJQUFJO0dBQzdDLEVBQUUsV0FBVztHQUNiLEVBQUUsTUFBTTtHQUNSLElBQUksZ0JBQWdCLEdBQUc7R0FFdkIsa0JBQWtCO0lBQ2hCLElBQUksV0FBVyxLQUFLLElBQUk7SUFDeEIsT0FBTztJQUNQLE1BQU07SUFDTixNQUFNLEdBQUcsY0FBYyxPQUFPLGlCQUFpQixJQUFJO0lBQ25ELFdBQVcsSUFBSSxLQUFLLENBQUMsQ0FBQyxtQkFBbUIsT0FBTztHQUNsRCxDQUFDO0VBQ0gsU0FBUyxHQUFHO0dBQ1YsUUFBUSxNQUFNLENBQUM7RUFDakIsVUFBVTtHQUNSLGVBQWUsS0FBSztHQUNwQixrQkFBa0IsRUFBRTtFQUN0QjtDQUNGOztDQUdBLE1BQU0sbUJBQW1CLFNBQXlCO0VBQ2hELE1BQU0sV0FBVyxPQUFPLEtBQUssSUFBSSxVQUFVLHNCQUFzQjtFQUNqRSxJQUFJLENBQUMsVUFBVTtFQUVmLFNBQVMsU0FBUyxNQUFNOzs7OzhCQUlFLEtBQUssUUFBUTs7Ozs7Ozs7c0JBUXJCLEtBQUssUUFBUTs7O0tBRzlCO0VBQ0QsU0FBUyxTQUFTLE1BQU07Q0FDMUI7Q0FFQSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWYsQ0FFRSx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxNQUFEO0tBQUksV0FBVTtlQUFvQztJQUErQjs7OztjQUNqRix3QkFBQyxRQUFEO0tBQU0sV0FBVTtlQUFpSDtJQUUzSDs7OztZQUNIOzs7OzthQUNMLHdCQUFDLEtBQUQ7SUFBRyxXQUFVO2NBQWdDO0dBRTFDOzs7O1dBQ0E7Ozs7YUFFSixjQUFjLFNBQVMsS0FDdEIsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FDYix3QkFBQyxVQUFEO0tBQ0UsU0FBUztLQUNULFdBQVU7ZUFGWixDQUlFLHdCQUFDLGFBQUQsRUFBYSxXQUFVLFVBQVc7Ozs7ZUFDbEMsd0JBQUMsUUFBRDtNQUFNO01BQXNCLGNBQWM7TUFBTztLQUFPOzs7O2FBQ2xEOzs7Ozs7R0FDTDs7OztXQUVKOzs7OztZQUdMLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FFRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmO0tBRUUsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBa0U7TUFBeUI7Ozs7Z0JBRTNHLHdCQUFDLFNBQUQ7T0FBTyxXQUFVO2lCQUFqQjtRQUNFLHdCQUFDLFdBQUQsRUFBVyxXQUFVLDhCQUErQjs7Ozs7UUFDcEQsd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQ2IsZUFBZSxhQUFhLE9BQU87UUFDaEM7Ozs7O1FBQ04sd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQ2IsZUFBZSxJQUFJLGFBQWEsT0FBTyxPQUFPLEtBQUksQ0FBRSxRQUFRLENBQUMsRUFBRSxPQUFPO1FBQ25FOzs7OztRQUNOLHdCQUFDLFNBQUQ7U0FDRSxLQUFLO1NBQ0wsTUFBSztTQUNMLFFBQU87U0FDUCxVQUFVO1NBQ1YsV0FBVTtRQUNYOzs7OztPQUNJOzs7OztjQUNKOzs7Ozs7TUFHSCxzQkFBc0IsdUJBQ3RCLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxNQUFELEVBQU0sV0FBVSxVQUFXOzs7O2tCQUMzQix3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBNkM7UUFBNEI7Ozs7Z0JBQ3RGOzs7Ozs7T0FFTCx3QkFBQyxRQUFEO1FBQU0sVUFBVTtRQUFzQixXQUFVO2tCQUFoRCxDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1NBQU8sV0FBVTttQkFBd0M7UUFBc0I7Ozs7a0JBQy9FLHdCQUFDLFNBQUQ7U0FDRSxNQUFLO1NBQ0wsYUFBWTtTQUNaLE9BQU87U0FDUCxXQUFXLE1BQU0sWUFBWSxFQUFFLE9BQU8sS0FBSztTQUMzQyxXQUFVO1FBQ1g7Ozs7Z0JBQ0U7Ozs7a0JBRUwsd0JBQUMsVUFBRDtTQUNFLE1BQUs7U0FDTCxVQUFVLGVBQWUsQ0FBQztTQUMxQixXQUFVO21CQUhaLENBS0Usd0JBQUMsUUFBRCxFQUFRLFdBQVUsY0FBZTs7OzttQkFDakMsd0JBQUMsUUFBRCxZQUFNLHVCQUEwQjs7OztpQkFDMUI7Ozs7O2dCQUNKOzs7Ozs7T0FHTix3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUNFLHdCQUFDLEtBQUQ7VUFBRyxXQUFVO29CQUF1QjtTQUEyQjs7Ozs7U0FDL0Qsd0JBQUMsT0FBRDtVQUFLO1VBQUUsd0JBQUMsS0FBRCxZQUFHLGFBQWE7Ozs7O1VBQUM7VUFBcUQsd0JBQUMsUUFBRCxZQUFNLFdBQWM7Ozs7O1VBQUM7U0FBTTs7Ozs7U0FDeEcsd0JBQUMsT0FBRDtVQUFLO1VBQUUsd0JBQUMsS0FBRCxZQUFHLFNBQVM7Ozs7O1VBQUM7VUFBd0Msd0JBQUMsUUFBRCxZQUFNLFdBQWM7Ozs7O1VBQUM7U0FBTTs7Ozs7UUFDcEY7Ozs7OztNQUNGOzs7Ozs7S0FJUCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFrRTtNQUE2Qjs7OztnQkFFL0csd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQ1o7UUFDQztTQUFFLFFBQVE7U0FBSyxPQUFPO1NBQVcsS0FBSztRQUFXO1FBQ2pEO1NBQUUsUUFBUTtTQUFLLE9BQU87U0FBVyxLQUFLO1FBQVc7UUFDakQ7U0FBRSxRQUFRO1NBQUssT0FBTztTQUFXLEtBQUs7UUFBYztPQUN0RCxDQUFDLENBQUMsS0FBSyxTQUNMLHdCQUFDLFVBQUQ7UUFFRSxlQUFlO1NBQ2IsT0FBTyxLQUFLLE1BQU07U0FDbEIsSUFBSSxjQUFjLFdBQVcsY0FBYyxRQUFRO1FBQ3JEO1FBQ0EsV0FBVywwREFDVCxRQUFRLEtBQUssU0FDVCxxREFDQTtrQkFUUixDQVlFLHdCQUFDLE9BQUQsWUFBTSxLQUFLLE1BQVc7Ozs7a0JBQ3RCLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFzQyxLQUFLO1FBQVM7Ozs7Z0JBQzdEO1VBYkQsS0FBSzs7OztjQWFKLENBQ1Q7TUFDRTs7OztjQUNGOzs7Ozs7SUFDRjs7Ozs7YUFHTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNiLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFoQixDQUNFLHdCQUFDLFdBQUQsRUFBVyxXQUFVLDRCQUE2Qjs7OztrQkFDbEQsd0JBQUMsUUFBRCxZQUFNLDBCQUE2Qjs7OztnQkFDL0I7Ozs7O2lCQUNOLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUNiLGNBQWMsU0FBUyxJQUFJLEdBQUcsY0FBYyxPQUFPLGdCQUFnQjtPQUNoRTs7OztlQUNIOzs7Ozs7TUFHSixlQUNDLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsU0FBRCxFQUFTLFdBQVUscUNBQXNDOzs7O2lCQUN6RCx3QkFBQyxRQUFELFlBQU8sZUFBcUI7Ozs7ZUFDekI7Ozs7OztNQUdOLGdCQUNDLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsYUFBRCxFQUFhLFdBQVUsc0NBQXVDOzs7O2lCQUM5RCx3QkFBQyxRQUFELFlBQU8sYUFBbUI7Ozs7ZUFDdkI7Ozs7OztNQUlOLENBQUMsZUFBZSxjQUFjLFdBQVcsS0FBSyxDQUFDLGdCQUM5Qyx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNFLHdCQUFDLFdBQUQsRUFBVyxXQUFVLGdDQUFpQzs7Ozs7UUFDdEQsd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQW1DO1FBQTBCOzs7OztRQUM3RSx3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFBdUM7UUFFakQ7Ozs7O09BQ0E7Ozs7OztNQUlQLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNaLGNBQWMsS0FBSyxTQUNsQix3QkFBQyxPQUFEO1FBRUUsV0FBVTtrQkFGWixDQUlFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBaEIsQ0FBdUMsU0FBTSxLQUFLLE9BQWM7Ozs7O29CQUNoRSx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBaEI7WUFDRyxLQUFLLE1BQU0sS0FBSyxLQUFLO1lBQUU7WUFBSSxLQUFLLE1BQU0sS0FBSyxNQUFNO1lBQUU7V0FDaEQ7Ozs7O2tCQUNIOzs7OzttQkFFTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFDYix3QkFBQyxPQUFEO1dBQ0UsS0FBSyxLQUFLO1dBQ1YsS0FBSyxRQUFRLEtBQUs7V0FDbEIsV0FBVTtVQUNYOzs7OztTQUNFOzs7O2lCQUNGOzs7OztrQkFFTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLFVBQUQ7VUFDRSxlQUFlLHFCQUFxQixJQUFJO1VBQ3hDLFdBQVU7VUFDVixPQUFNO29CQUhSLENBS0Usd0JBQUMsVUFBRCxFQUFVLFdBQVUsY0FBZTs7OztvQkFDbkMsd0JBQUMsUUFBRCxZQUFNLGVBQWtCOzs7O2tCQUNsQjs7Ozs7bUJBRVIsd0JBQUMsVUFBRDtVQUNFLGVBQWUsZ0JBQWdCLElBQUk7VUFDbkMsV0FBVTtVQUNWLE9BQU07b0JBSFIsQ0FLRSx3QkFBQyxTQUFELEVBQVMsV0FBVSxjQUFlOzs7O29CQUNsQyx3QkFBQyxRQUFELFlBQU0sYUFBZ0I7Ozs7a0JBQ2hCOzs7OztpQkFDTDs7Ozs7Z0JBQ0Y7VUF2Q0UsS0FBSzs7OztjQXVDUCxDQUNOO01BQ0U7Ozs7O0tBQ0Y7Ozs7OztHQUNGOzs7O1dBQ0Y7Ozs7O1VBQ0Y7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlBkZlRvSnBnVmlldy50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlLCB1c2VSZWYgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBcbiAgRmlsZUltYWdlLCBcbiAgVXBsb2FkLCBcbiAgTG9jaywgXG4gIFVubG9jaywgXG4gIERvd25sb2FkLCBcbiAgUHJpbnRlciwgXG4gIEZpbGVBcmNoaXZlLCBcbiAgQ2hlY2ssIFxuICBBbGVydENpcmNsZSwgXG4gIExvYWRlcjIsIFxuICBIZWxwQ2lyY2xlLFxuICBFeWVcbn0gZnJvbSAnbHVjaWRlLXJlYWN0JztcbmltcG9ydCAqIGFzIHBkZmpzTGliIGZyb20gJ3BkZmpzLWRpc3QnO1xuaW1wb3J0IEpTWmlwIGZyb20gJ2pzemlwJztcbmltcG9ydCB7IGFkZERvd25sb2FkUmVjb3JkIH0gZnJvbSAnLi4vdXRpbHMvc3RvcmFnZSc7XG5cbi8vIENvbmZpZ3VyZSBQREYuanMgd29ya2VyXG5wZGZqc0xpYi5HbG9iYWxXb3JrZXJPcHRpb25zLndvcmtlclNyYyA9IGBodHRwczovL2NkbmpzLmNsb3VkZmxhcmUuY29tL2FqYXgvbGlicy9wZGYuanMvJHtwZGZqc0xpYi52ZXJzaW9ufS9wZGYud29ya2VyLm1pbi5tanNgO1xuXG5pbnRlcmZhY2UgUGFnZVJlbmRlckl0ZW0ge1xuICBwYWdlTnVtOiBudW1iZXI7XG4gIGRhdGFVcmw6IHN0cmluZztcbiAgd2lkdGg6IG51bWJlcjtcbiAgaGVpZ2h0OiBudW1iZXI7XG59XG5cbmV4cG9ydCBjb25zdCBQZGZUb0pwZ1ZpZXc6IFJlYWN0LkZDID0gKCkgPT4ge1xuICBjb25zdCBbc2VsZWN0ZWRGaWxlLCBzZXRTZWxlY3RlZEZpbGVdID0gdXNlU3RhdGU8RmlsZSB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbcGFzc3dvcmQsIHNldFBhc3N3b3JkXSA9IHVzZVN0YXRlPHN0cmluZz4oJycpO1xuICBjb25zdCBbaXNQYXNzd29yZFJlcXVpcmVkLCBzZXRJc1Bhc3N3b3JkUmVxdWlyZWRdID0gdXNlU3RhdGU8Ym9vbGVhbj4oZmFsc2UpO1xuICBjb25zdCBbZHBpLCBzZXREcGldID0gdXNlU3RhdGU8bnVtYmVyPigzMDApOyAvLyAxNTAsIDMwMCwgNDAwXG4gIGNvbnN0IFtpc1JlbmRlcmluZywgc2V0SXNSZW5kZXJpbmddID0gdXNlU3RhdGU8Ym9vbGVhbj4oZmFsc2UpO1xuICBjb25zdCBbcmVuZGVyUHJvZ3Jlc3MsIHNldFJlbmRlclByb2dyZXNzXSA9IHVzZVN0YXRlPHN0cmluZz4oJycpO1xuICBjb25zdCBbcmVuZGVyZWRQYWdlcywgc2V0UmVuZGVyZWRQYWdlc10gPSB1c2VTdGF0ZTxQYWdlUmVuZGVySXRlbVtdPihbXSk7XG4gIGNvbnN0IFtlcnJvck1lc3NhZ2UsIHNldEVycm9yTWVzc2FnZV0gPSB1c2VTdGF0ZTxzdHJpbmc+KCcnKTtcblxuICBjb25zdCBmaWxlSW5wdXRSZWYgPSB1c2VSZWY8SFRNTElucHV0RWxlbWVudCB8IG51bGw+KG51bGwpO1xuXG4gIGNvbnN0IGhhbmRsZUZpbGVDaGFuZ2UgPSAoZTogUmVhY3QuQ2hhbmdlRXZlbnQ8SFRNTElucHV0RWxlbWVudD4pID0+IHtcbiAgICBjb25zdCBmaWxlID0gZS50YXJnZXQuZmlsZXM/LlswXTtcbiAgICBpZiAoIWZpbGUpIHJldHVybjtcbiAgICBpZiAoZmlsZS50eXBlICE9PSAnYXBwbGljYXRpb24vcGRmJyAmJiAhZmlsZS5uYW1lLmVuZHNXaXRoKCcucGRmJykpIHtcbiAgICAgIHNldEVycm9yTWVzc2FnZSgnUGxlYXNlIHNlbGVjdCBhIHZhbGlkIFBERiBmaWxlLicpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBzZXRTZWxlY3RlZEZpbGUoZmlsZSk7XG4gICAgc2V0RXJyb3JNZXNzYWdlKCcnKTtcbiAgICBzZXRJc1Bhc3N3b3JkUmVxdWlyZWQoZmFsc2UpO1xuICAgIHNldFJlbmRlcmVkUGFnZXMoW10pO1xuICAgIHByb2Nlc3NQREYoZmlsZSwgcGFzc3dvcmQpO1xuICB9O1xuXG4gIGNvbnN0IHByb2Nlc3NQREYgPSBhc3luYyAoZmlsZTogRmlsZSwgcGFzczogc3RyaW5nKSA9PiB7XG4gICAgc2V0SXNSZW5kZXJpbmcodHJ1ZSk7XG4gICAgc2V0RXJyb3JNZXNzYWdlKCcnKTtcbiAgICBzZXRSZW5kZXJlZFBhZ2VzKFtdKTtcbiAgICBzZXRSZW5kZXJQcm9ncmVzcygnUmVhZGluZyBQREYgZmlsZS4uLicpO1xuXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGFycmF5QnVmZmVyID0gYXdhaXQgZmlsZS5hcnJheUJ1ZmZlcigpO1xuICAgICAgY29uc3QgbG9hZGluZ1Rhc2sgPSBwZGZqc0xpYi5nZXREb2N1bWVudCh7XG4gICAgICAgIGRhdGE6IGFycmF5QnVmZmVyLFxuICAgICAgICBwYXNzd29yZDogcGFzcyB8fCB1bmRlZmluZWRcbiAgICAgIH0pO1xuXG4gICAgICBsb2FkaW5nVGFzay5vblBhc3N3b3JkID0gKGNhbGxiYWNrOiBhbnksIHJlYXNvbjogYW55KSA9PiB7XG4gICAgICAgIHNldElzUGFzc3dvcmRSZXF1aXJlZCh0cnVlKTtcbiAgICAgICAgc2V0SXNSZW5kZXJpbmcoZmFsc2UpO1xuICAgICAgICBzZXRSZW5kZXJQcm9ncmVzcygnJyk7XG4gICAgICAgIGlmIChyZWFzb24gPT09IHBkZmpzTGliLlBhc3N3b3JkUmVzcG9uc2VzLklOQ09SUkVDVF9QQVNTV09SRCkge1xuICAgICAgICAgIHNldEVycm9yTWVzc2FnZSgnSW5jb3JyZWN0IHBhc3N3b3JkLiBQbGVhc2UgZW50ZXIgdGhlIGNvcnJlY3QgcGFzc3dvcmQuJyk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgc2V0RXJyb3JNZXNzYWdlKCdUaGlzIFBERiBpcyBwYXNzd29yZCBwcm90ZWN0ZWQuIEVudGVyIHBhc3N3b3JkIGJlbG93IHRvIHVubG9jay4nKTtcbiAgICAgICAgfVxuICAgICAgfTtcblxuICAgICAgY29uc3QgcGRmRG9jID0gYXdhaXQgbG9hZGluZ1Rhc2sucHJvbWlzZTtcbiAgICAgIHNldElzUGFzc3dvcmRSZXF1aXJlZChmYWxzZSk7XG4gICAgICBjb25zdCB0b3RhbFBhZ2VzID0gcGRmRG9jLm51bVBhZ2VzO1xuICAgICAgY29uc3QgcGFnZXNBcnI6IFBhZ2VSZW5kZXJJdGVtW10gPSBbXTtcblxuICAgICAgLy8gU2NhbGUgZmFjdG9yOiBzdGFuZGFyZCBQREYgNzIgRFBJIC0+IGRlc2lyZWQgRFBJXG4gICAgICAvLyBzY2FsZSA9IGRwaSAvIDcyIChlLmcuIDMwMCAvIDcyIOKJiCA0LjE2NilcbiAgICAgIGNvbnN0IHNjYWxlID0gZHBpIC8gNzI7XG5cbiAgICAgIGZvciAobGV0IHBhZ2VOdW0gPSAxOyBwYWdlTnVtIDw9IHRvdGFsUGFnZXM7IHBhZ2VOdW0rKykge1xuICAgICAgICBzZXRSZW5kZXJQcm9ncmVzcyhgUmVuZGVyaW5nIFBhZ2UgJHtwYWdlTnVtfSBvZiAke3RvdGFsUGFnZXN9IGF0ICR7ZHBpfSBEUEkuLi5gKTtcbiAgICAgICAgY29uc3QgcGFnZSA9IGF3YWl0IHBkZkRvYy5nZXRQYWdlKHBhZ2VOdW0pO1xuICAgICAgICBjb25zdCB2aWV3cG9ydCA9IHBhZ2UuZ2V0Vmlld3BvcnQoeyBzY2FsZSB9KTtcblxuICAgICAgICBjb25zdCBjYW52YXMgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdjYW52YXMnKTtcbiAgICAgICAgY2FudmFzLndpZHRoID0gdmlld3BvcnQud2lkdGg7XG4gICAgICAgIGNhbnZhcy5oZWlnaHQgPSB2aWV3cG9ydC5oZWlnaHQ7XG4gICAgICAgIGNvbnN0IGN0eCA9IGNhbnZhcy5nZXRDb250ZXh0KCcyZCcpO1xuXG4gICAgICAgIGlmIChjdHgpIHtcbiAgICAgICAgICBjdHguZmlsbFN0eWxlID0gJyNmZmZmZmYnO1xuICAgICAgICAgIGN0eC5maWxsUmVjdCgwLCAwLCBjYW52YXMud2lkdGgsIGNhbnZhcy5oZWlnaHQpO1xuXG4gICAgICAgICAgYXdhaXQgKHBhZ2UucmVuZGVyKHtcbiAgICAgICAgICAgIGNhbnZhc0NvbnRleHQ6IGN0eCxcbiAgICAgICAgICAgIHZpZXdwb3J0OiB2aWV3cG9ydCxcbiAgICAgICAgICAgIGNhbnZhczogY2FudmFzXG4gICAgICAgICAgfSBhcyBhbnkpKS5wcm9taXNlO1xuXG4gICAgICAgICAgcGFnZXNBcnIucHVzaCh7XG4gICAgICAgICAgICBwYWdlTnVtLFxuICAgICAgICAgICAgZGF0YVVybDogY2FudmFzLnRvRGF0YVVSTCgnaW1hZ2UvanBlZycsIDAuOTYpLFxuICAgICAgICAgICAgd2lkdGg6IHZpZXdwb3J0LndpZHRoLFxuICAgICAgICAgICAgaGVpZ2h0OiB2aWV3cG9ydC5oZWlnaHRcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICBzZXRSZW5kZXJlZFBhZ2VzKHBhZ2VzQXJyKTtcbiAgICAgIHNldFJlbmRlclByb2dyZXNzKCcnKTtcbiAgICB9IGNhdGNoIChlcnI6IGFueSkge1xuICAgICAgY29uc29sZS5lcnJvcihlcnIpO1xuICAgICAgaWYgKGVyci5uYW1lID09PSAnUGFzc3dvcmRFeGNlcHRpb24nKSB7XG4gICAgICAgIHNldElzUGFzc3dvcmRSZXF1aXJlZCh0cnVlKTtcbiAgICAgICAgc2V0RXJyb3JNZXNzYWdlKCdUaGlzIFBERiBpcyBwcm90ZWN0ZWQuIFBsZWFzZSBlbnRlciBwYXNzd29yZCAoZS5nLiBBYWRoYWFyOiBDQVBJVEFMIDQgbGV0dGVycyBvZiBuYW1lICsgQmlydGggWWVhcikuJyk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBzZXRFcnJvck1lc3NhZ2UoZXJyLm1lc3NhZ2UgfHwgJ0ZhaWxlZCB0byBwYXJzZSBQREYuJyk7XG4gICAgICB9XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldElzUmVuZGVyaW5nKGZhbHNlKTtcbiAgICB9XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlUGFzc3dvcmRTdWJtaXQgPSAoZTogUmVhY3QuRm9ybUV2ZW50KSA9PiB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgIGlmICghc2VsZWN0ZWRGaWxlKSByZXR1cm47XG4gICAgcHJvY2Vzc1BERihzZWxlY3RlZEZpbGUsIHBhc3N3b3JkKTtcbiAgfTtcblxuICAvLyBEb3dubG9hZCBzaW5nbGUgcGFnZSBKUEdcbiAgY29uc3QgaGFuZGxlRG93bmxvYWRTaW5nbGUgPSAocGFnZTogUGFnZVJlbmRlckl0ZW0pID0+IHtcbiAgICBjb25zdCBhID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnYScpO1xuICAgIGEuaHJlZiA9IHBhZ2UuZGF0YVVybDtcbiAgICBjb25zdCBmaWxlTmFtZSA9IGAke3NlbGVjdGVkRmlsZT8ubmFtZS5yZXBsYWNlKCcucGRmJywgJycpIHx8ICdEb2N1bWVudCd9X1BhZ2VfJHtwYWdlLnBhZ2VOdW19XyR7ZHBpfURQSS5qcGdgO1xuICAgIGEuZG93bmxvYWQgPSBmaWxlTmFtZTtcbiAgICBhLmNsaWNrKCk7XG5cbiAgICBhZGREb3dubG9hZFJlY29yZCh7XG4gICAgICBpZDogYHBkZi1qcGctJHtEYXRlLm5vdygpfS0ke3BhZ2UucGFnZU51bX1gLFxuICAgICAgdGl0bGU6IGZpbGVOYW1lLFxuICAgICAgdHlwZTogJ0NvbnZlcnRlZCBKUEcnLFxuICAgICAgc2l6ZTogYCR7TWF0aC5yb3VuZChwYWdlLndpZHRoKX3DlyR7TWF0aC5yb3VuZChwYWdlLmhlaWdodCl9IHB4ICgke2RwaX0gRFBJKWAsXG4gICAgICB0aW1lc3RhbXA6IG5ldyBEYXRlKCkudG9Mb2NhbGVUaW1lU3RyaW5nKCdlbi1JTicpXG4gICAgfSk7XG4gIH07XG5cbiAgLy8gRG93bmxvYWQgYWxsIHBhZ2VzIGFzIGEgWklQXG4gIGNvbnN0IGhhbmRsZURvd25sb2FkQWxsWmlwID0gYXN5bmMgKCkgPT4ge1xuICAgIGlmIChyZW5kZXJlZFBhZ2VzLmxlbmd0aCA9PT0gMCkgcmV0dXJuO1xuICAgIHNldElzUmVuZGVyaW5nKHRydWUpO1xuICAgIHNldFJlbmRlclByb2dyZXNzKCdDcmVhdGluZyBaSVAgYXJjaGl2ZSBvZiBhbGwgcGFnZXMuLi4nKTtcblxuICAgIHRyeSB7XG4gICAgICBjb25zdCB6aXAgPSBuZXcgSlNaaXAoKTtcbiAgICAgIGNvbnN0IGJhc2VOYW1lID0gc2VsZWN0ZWRGaWxlPy5uYW1lLnJlcGxhY2UoJy5wZGYnLCAnJykgfHwgJ0RvY3VtZW50JztcblxuICAgICAgcmVuZGVyZWRQYWdlcy5mb3JFYWNoKChwKSA9PiB7XG4gICAgICAgIC8vIFN0cmlwIGRhdGE6aW1hZ2UvanBlZztiYXNlNjQsXG4gICAgICAgIGNvbnN0IGJhc2U2NERhdGEgPSBwLmRhdGFVcmwuc3BsaXQoJywnKVsxXTtcbiAgICAgICAgemlwLmZpbGUoYCR7YmFzZU5hbWV9X1BhZ2VfJHtwLnBhZ2VOdW19LmpwZ2AsIGJhc2U2NERhdGEsIHsgYmFzZTY0OiB0cnVlIH0pO1xuICAgICAgfSk7XG5cbiAgICAgIGNvbnN0IGNvbnRlbnQgPSBhd2FpdCB6aXAuZ2VuZXJhdGVBc3luYyh7IHR5cGU6ICdibG9iJyB9KTtcbiAgICAgIGNvbnN0IHVybCA9IFVSTC5jcmVhdGVPYmplY3RVUkwoY29udGVudCk7XG4gICAgICBjb25zdCBhID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnYScpO1xuICAgICAgYS5ocmVmID0gdXJsO1xuICAgICAgY29uc3QgemlwTmFtZSA9IGAke2Jhc2VOYW1lfV9BbGxfUGFnZXNfJHtkcGl9RFBJLnppcGA7XG4gICAgICBhLmRvd25sb2FkID0gemlwTmFtZTtcbiAgICAgIGEuY2xpY2soKTtcbiAgICAgIFVSTC5yZXZva2VPYmplY3RVUkwodXJsKTtcblxuICAgICAgYWRkRG93bmxvYWRSZWNvcmQoe1xuICAgICAgICBpZDogYHBkZi16aXAtJHtEYXRlLm5vdygpfWAsXG4gICAgICAgIHRpdGxlOiB6aXBOYW1lLFxuICAgICAgICB0eXBlOiAnQ29udmVydGVkIEpQRycsXG4gICAgICAgIHNpemU6IGAke3JlbmRlcmVkUGFnZXMubGVuZ3RofSBQYWdlcyBpbiBaSVAgKCR7ZHBpfSBEUEkpYCxcbiAgICAgICAgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLnRvTG9jYWxlVGltZVN0cmluZygnZW4tSU4nKVxuICAgICAgfSk7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgY29uc29sZS5lcnJvcihlKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0SXNSZW5kZXJpbmcoZmFsc2UpO1xuICAgICAgc2V0UmVuZGVyUHJvZ3Jlc3MoJycpO1xuICAgIH1cbiAgfTtcblxuICAvLyBEaXJlY3QgUHJpbnQgc2luZ2xlIHBhZ2VcbiAgY29uc3QgaGFuZGxlUHJpbnRQYWdlID0gKHBhZ2U6IFBhZ2VSZW5kZXJJdGVtKSA9PiB7XG4gICAgY29uc3QgcHJpbnRXaW4gPSB3aW5kb3cub3BlbignJywgJ19ibGFuaycsICd3aWR0aD04MDAsaGVpZ2h0PTk1MCcpO1xuICAgIGlmICghcHJpbnRXaW4pIHJldHVybjtcblxuICAgIHByaW50V2luLmRvY3VtZW50LndyaXRlKGBcbiAgICAgIDwhRE9DVFlQRSBodG1sPlxuICAgICAgPGh0bWw+XG4gICAgICAgIDxoZWFkPlxuICAgICAgICAgIDx0aXRsZT5QcmludCBQYWdlICR7cGFnZS5wYWdlTnVtfTwvdGl0bGU+XG4gICAgICAgICAgPHN0eWxlPlxuICAgICAgICAgICAgQHBhZ2UgeyBzaXplOiBhdXRvOyBtYXJnaW46IDVtbTsgfVxuICAgICAgICAgICAgYm9keSB7IG1hcmdpbjogMDsgcGFkZGluZzogMDsgZGlzcGxheTogZmxleDsgYWxpZ24taXRlbXM6IGNlbnRlcjsganVzdGlmeS1jb250ZW50OiBjZW50ZXI7IGJhY2tncm91bmQ6ICNmZmY7IH1cbiAgICAgICAgICAgIGltZyB7IG1heC13aWR0aDogMTAwJTsgaGVpZ2h0OiBhdXRvOyBkaXNwbGF5OiBibG9jazsgaW1hZ2UtcmVuZGVyaW5nOiAtd2Via2l0LW9wdGltaXplLWNvbnRyYXN0OyB9XG4gICAgICAgICAgPC9zdHlsZT5cbiAgICAgICAgPC9oZWFkPlxuICAgICAgICA8Ym9keT5cbiAgICAgICAgICA8aW1nIHNyYz1cIiR7cGFnZS5kYXRhVXJsfVwiIG9ubG9hZD1cIndpbmRvdy5wcmludCgpOyB3aW5kb3cuY2xvc2UoKTtcIiAvPlxuICAgICAgICA8L2JvZHk+XG4gICAgICA8L2h0bWw+XG4gICAgYCk7XG4gICAgcHJpbnRXaW4uZG9jdW1lbnQuY2xvc2UoKTtcbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XG4gICAgICB7LyogSGVhZGVyIGJhciAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBzbTppdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBwLTQgcm91bmRlZC0yeGwgc2hhZG93LW1kXCI+XG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1leHRyYWJvbGQgdGV4dC13aGl0ZVwiPlBERiB0byBIRCBKUEcgQ29udmVydGVyIFBybzwvaDE+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJiZy1hbWJlci01MDAvMjAgdGV4dC1hbWJlci0zMDAgYm9yZGVyIGJvcmRlci1hbWJlci01MDAvMzAgdGV4dC14cyBweC0yIHB5LTAuNSByb3VuZGVkLWZ1bGwgZm9udC1tb25vIGZvbnQtYm9sZFwiPlxuICAgICAgICAgICAgICBQYXNzd29yZCBVbmxvY2sgJiAzMDAgRFBJXG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMCBtdC0wLjVcIj5cbiAgICAgICAgICAgIENvbnZlcnQgZS1BYWRoYWFyLCBQQU4gY2FyZHMsIG1hcmtzaGVldCBQREZzIHRvIGhpZ2gtcmVzb2x1dGlvbiBKUEVHcyB3aXRoIGJhdGNoIFpJUCBleHBvcnRcbiAgICAgICAgICA8L3A+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHtyZW5kZXJlZFBhZ2VzLmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlRG93bmxvYWRBbGxaaXB9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgYmctZW1lcmFsZC02MDAgaG92ZXI6YmctZW1lcmFsZC01MDAgdGV4dC13aGl0ZSBmb250LWJvbGQgdGV4dC14cyBweC0zLjUgcHktMiByb3VuZGVkLXhsIHNoYWRvdy1sZyBzaGFkb3ctZW1lcmFsZC02MDAvMzAgdHJhbnNpdGlvbi1hbGwgaG92ZXI6c2NhbGUtMTA1XCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPEZpbGVBcmNoaXZlIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICAgICAgICA8c3Bhbj5Eb3dubG9hZCBBbGwgYXMgWklQICh7cmVuZGVyZWRQYWdlcy5sZW5ndGh9KTwvc3Bhbj5cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApfVxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBNYWluIER1YWwtUGFuZTogTGVmdCA9IEZpbGUgVXBsb2FkICYgRFBJIHNldHRpbmdzLCBSaWdodCA9IFBhZ2UgUHJldmlld3MgR3JpZCAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBsZzpncmlkLWNvbHMtMTIgZ2FwLTUgaXRlbXMtc3RhcnRcIj5cbiAgICAgICAgey8qIExlZnQgU2lkZTogVXBsb2FkICYgUGFzc3dvcmQgVG9vbHMgKDQgY29scykgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibGc6Y29sLXNwYW4tNCBzcGFjZS15LTRcIj5cbiAgICAgICAgICB7LyogRmlsZSBVcGxvYWQgQm94ICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwLzkwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtMnhsIHAtNCBzaGFkb3ctbWQgc3BhY2UteS0zXCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTMwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgYmxvY2tcIj5TZWxlY3QgUERGIERvY3VtZW50PC9zcGFuPlxuXG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYm9yZGVyLTIgYm9yZGVyLWRhc2hlZCBib3JkZXItc2xhdGUtNzAwIGhvdmVyOmJvcmRlci1hbWJlci01MDAgcC01IHJvdW5kZWQteGwgY3Vyc29yLXBvaW50ZXIgYmctc2xhdGUtOTUwLzQwIGhvdmVyOmJnLWFtYmVyLTk1MC8xMCB0cmFuc2l0aW9uLWNvbG9ycyB0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgICAgICA8RmlsZUltYWdlIGNsYXNzTmFtZT1cInctOCBoLTggdGV4dC1hbWJlci00MDAgbWItMlwiIC8+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgICAgICB7c2VsZWN0ZWRGaWxlID8gc2VsZWN0ZWRGaWxlLm5hbWUgOiAnQ2hvb3NlIG9yIERyYWcgUERGIEZpbGUnfVxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNDAwIG10LTAuNVwiPlxuICAgICAgICAgICAgICAgIHtzZWxlY3RlZEZpbGUgPyBgJHsoc2VsZWN0ZWRGaWxlLnNpemUgLyAxMDI0IC8gMTAyNCkudG9GaXhlZCgyKX0gTUJgIDogJ2UtQWFkaGFhciwgUEFOLCBNYXJrc2hlZXRzLCBDZXJ0aWZpY2F0ZXMnfVxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgIHJlZj17ZmlsZUlucHV0UmVmfVxuICAgICAgICAgICAgICAgIHR5cGU9XCJmaWxlXCJcbiAgICAgICAgICAgICAgICBhY2NlcHQ9XCJhcHBsaWNhdGlvbi9wZGZcIlxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVGaWxlQ2hhbmdlfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImhpZGRlblwiXG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIFBhc3N3b3JkIFVubG9jayBCb3ggKElmIHByb3RlY3RlZCkgKi99XG4gICAgICAgICAgeyhpc1Bhc3N3b3JkUmVxdWlyZWQgfHwgaXNQYXNzd29yZFJlcXVpcmVkKSAmJiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMC85MCBib3JkZXIgYm9yZGVyLWFtYmVyLTUwMC80MCByb3VuZGVkLTJ4bCBwLTQgc2hhZG93LW1kIHNwYWNlLXktM1wiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtYW1iZXItNDAwXCI+XG4gICAgICAgICAgICAgICAgPExvY2sgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+UGFzc3dvcmQgUHJvdGVjdGVkIFBERjwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVBhc3N3b3JkU3VibWl0fSBjbGFzc05hbWU9XCJzcGFjZS15LTIgdGV4dC14c1wiPlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS0zMDAgYmxvY2sgbWItMVwiPkVudGVyIFBhc3N3b3JkOjwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInBhc3N3b3JkXCJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBkb2N1bWVudCBwYXNzd29yZFwiXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtwYXNzd29yZH1cbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRQYXNzd29yZChlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCBweC0zIHB5LTIgdGV4dC13aGl0ZSBmb250LW1vbm8gdGV4dC1zbSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLWFtYmVyLTUwMFwiXG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXG4gICAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNSZW5kZXJpbmcgfHwgIXBhc3N3b3JkfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0xLjUgYmctYW1iZXItNjAwIGhvdmVyOmJnLWFtYmVyLTUwMCB0ZXh0LXdoaXRlIGZvbnQtYm9sZCB0ZXh0LXhzIHB5LTIgcm91bmRlZC14bCB0cmFuc2l0aW9uLWNvbG9ycyBkaXNhYmxlZDpvcGFjaXR5LTUwXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8VW5sb2NrIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cbiAgICAgICAgICAgICAgICAgIDxzcGFuPlVubG9jayAmIENvbnZlcnQgUERGPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8L2Zvcm0+XG5cbiAgICAgICAgICAgICAgey8qIFBhc3N3b3JkIEhpbnQgR3VpZGUgKi99XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0yLjUgcm91bmRlZC1sZyBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgdGV4dC1bMTFweF0gdGV4dC1zbGF0ZS00MDAgc3BhY2UteS0xXCI+XG4gICAgICAgICAgICAgICAgPGIgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS0zMDAgYmxvY2tcIj5Db21tb24gUGFzc3dvcmQgRm9ybWF0czo8L2I+XG4gICAgICAgICAgICAgICAgPGRpdj7igKIgPGI+ZS1BYWRoYWFyOjwvYj4gMXN0IDQgbGV0dGVycyBvZiBuYW1lIGluIENBUElUQUwgKyBCaXJ0aCBZZWFyIChlLmcuIDxjb2RlPklNUkExOTk1PC9jb2RlPik8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2PuKAoiA8Yj5lLVBBTjo8L2I+IERhdGUgb2YgQmlydGggaW4gRERNTVlZWVkgZm9ybWF0IChlLmcuIDxjb2RlPjE1MDgxOTk4PC9jb2RlPik8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAgey8qIFF1YWxpdHkgJiBEUEkgU2VsZWN0b3IgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAvOTAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0yeGwgcC00IHNoYWRvdy1tZCBzcGFjZS15LTNcIj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtMzAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBibG9ja1wiPk91dHB1dCBSZXNvbHV0aW9uIChEUEkpPC9zcGFuPlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTMgZ2FwLTJcIj5cbiAgICAgICAgICAgICAge1tcbiAgICAgICAgICAgICAgICB7IGRwaVZhbDogMTUwLCBsYWJlbDogJzE1MCBEUEknLCBzdWI6ICdTdGFuZGFyZCcgfSxcbiAgICAgICAgICAgICAgICB7IGRwaVZhbDogMzAwLCBsYWJlbDogJzMwMCBEUEknLCBzdWI6ICdQcmludCBIRCcgfSxcbiAgICAgICAgICAgICAgICB7IGRwaVZhbDogNDAwLCBsYWJlbDogJzQwMCBEUEknLCBzdWI6ICdVbHRyYSBDbGVhcicgfVxuICAgICAgICAgICAgICBdLm1hcCgoaXRlbSkgPT4gKFxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIGtleT17aXRlbS5kcGlWYWx9XG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHNldERwaShpdGVtLmRwaVZhbCk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChzZWxlY3RlZEZpbGUpIHByb2Nlc3NQREYoc2VsZWN0ZWRGaWxlLCBwYXNzd29yZCk7XG4gICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcC0yIHJvdW5kZWQteGwgdGV4dC14cyBmb250LWJvbGQgYm9yZGVyIHRyYW5zaXRpb24tYWxsICR7XG4gICAgICAgICAgICAgICAgICAgIGRwaSA9PT0gaXRlbS5kcGlWYWxcbiAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1ibHVlLTYwMCB0ZXh0LXdoaXRlIGJvcmRlci1ibHVlLTUwMCBzaGFkb3ctbWQnXG4gICAgICAgICAgICAgICAgICAgICAgOiAnYmctc2xhdGUtODAwIHRleHQtc2xhdGUtMzAwIGJvcmRlci1zbGF0ZS03MDAgaG92ZXI6Ymctc2xhdGUtNzUwJ1xuICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPGRpdj57aXRlbS5sYWJlbH08L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1ub3JtYWwgb3BhY2l0eS04MFwiPntpdGVtLnN1Yn08L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIFJpZ2h0IFNpZGU6IFBhZ2UgUHJldmlld3MgR3JpZCAoOCBjb2xzKSAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJsZzpjb2wtc3Bhbi04IHNwYWNlLXktM1wiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtMnhsIHAtNCBzaGFkb3cteGwgbWluLWgtWzQ2MHB4XVwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItMyB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXdoaXRlIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgICA8RmlsZUltYWdlIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtYmx1ZS00MDBcIiAvPlxuICAgICAgICAgICAgICAgIDxzcGFuPlJlbmRlcmVkIERvY3VtZW50IFBhZ2VzPC9zcGFuPlxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIGZvbnQtbW9ub1wiPlxuICAgICAgICAgICAgICAgIHtyZW5kZXJlZFBhZ2VzLmxlbmd0aCA+IDAgPyBgJHtyZW5kZXJlZFBhZ2VzLmxlbmd0aH0gUGFnZXMgUmVhZHlgIDogJ05vIGZpbGUgbG9hZGVkJ31cbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBFcnJvciBvciBQcm9ncmVzcyBBbGVydCAqL31cbiAgICAgICAgICAgIHtpc1JlbmRlcmluZyAmJiAoXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IHJvdW5kZWQteGwgYmctYmx1ZS05NTAvNDAgYm9yZGVyIGJvcmRlci1ibHVlLTUwMC8zMCB0ZXh0LWJsdWUtMzAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0zIHRleHQteHNcIj5cbiAgICAgICAgICAgICAgICA8TG9hZGVyMiBjbGFzc05hbWU9XCJ3LTQgaC00IGFuaW1hdGUtc3BpbiB0ZXh0LWJsdWUtNDAwXCIgLz5cbiAgICAgICAgICAgICAgICA8c3Bhbj57cmVuZGVyUHJvZ3Jlc3N9PC9zcGFuPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgIHtlcnJvck1lc3NhZ2UgJiYgKFxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMy41IHJvdW5kZWQteGwgYmctcm9zZS05NTAvNDAgYm9yZGVyIGJvcmRlci1yb3NlLTUwMC8zMCB0ZXh0LXJvc2UtMzAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yLjUgdGV4dC14cyBtYi0zXCI+XG4gICAgICAgICAgICAgICAgPEFsZXJ0Q2lyY2xlIGNsYXNzTmFtZT1cInctNCBoLTQgZmxleC1zaHJpbmstMCB0ZXh0LXJvc2UtNDAwXCIgLz5cbiAgICAgICAgICAgICAgICA8c3Bhbj57ZXJyb3JNZXNzYWdlfTwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApfVxuXG4gICAgICAgICAgICB7LyogRW1wdHkgU3RhdGUgKi99XG4gICAgICAgICAgICB7IWlzUmVuZGVyaW5nICYmIHJlbmRlcmVkUGFnZXMubGVuZ3RoID09PSAwICYmICFlcnJvck1lc3NhZ2UgJiYgKFxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtODAgZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC1jZW50ZXIgcC02IGJvcmRlci0yIGJvcmRlci1kYXNoZWQgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLXhsXCI+XG4gICAgICAgICAgICAgICAgPEZpbGVJbWFnZSBjbGFzc05hbWU9XCJ3LTEyIGgtMTIgdGV4dC1zbGF0ZS02MDAgbWItMlwiIC8+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDBcIj5ObyBQREYgUHJvY2Vzc2VkIFlldDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTAwIG1heC13LXNtIG10LTFcIj5cbiAgICAgICAgICAgICAgICAgIFVwbG9hZCBhbiBlLUFhZGhhYXIsIFBBTiBjYXJkLCBvciBtdWx0aS1wYWdlIFBERiBvbiB0aGUgbGVmdC4gSGlnaCByZXNvbHV0aW9uIDMwMCBEUEkgcGFnZXMgd2lsbCBhcHBlYXIgaGVyZS5cbiAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgey8qIFBhZ2VzIEdyaWQgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTRcIj5cbiAgICAgICAgICAgICAge3JlbmRlcmVkUGFnZXMubWFwKChwYWdlKSA9PiAoXG4gICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAga2V5PXtwYWdlLnBhZ2VOdW19XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC14bCBvdmVyZmxvdy1oaWRkZW4gcC0zIHNoYWRvdy1tZCBmbGV4IGZsZXgtY29sIGp1c3RpZnktYmV0d2VlblwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gdGV4dC14cyB0ZXh0LXNsYXRlLTQwMCBib3JkZXItYiBib3JkZXItc2xhdGUtODAwLzgwIHBiLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC13aGl0ZVwiPlBhZ2Uge3BhZ2UucGFnZU51bX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vIHRleHQtWzExcHhdIHRleHQtc2xhdGUtNTAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7TWF0aC5yb3VuZChwYWdlLndpZHRoKX0gw5cge01hdGgucm91bmQocGFnZS5oZWlnaHQpfSBweFxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLWxnIG92ZXJmbG93LWhpZGRlbiBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCBzaGFkb3ctaW5uZXIgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGltZ1xuICAgICAgICAgICAgICAgICAgICAgICAgc3JjPXtwYWdlLmRhdGFVcmx9XG4gICAgICAgICAgICAgICAgICAgICAgICBhbHQ9e2BQYWdlICR7cGFnZS5wYWdlTnVtfWB9XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaC1hdXRvIG9iamVjdC1jb250YWluIG1heC1oLVszNjBweF1cIlxuICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtMiBtdC0zIHB0LTIuNSBib3JkZXItdCBib3JkZXItc2xhdGUtODAwLzgwXCI+XG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVEb3dubG9hZFNpbmdsZShwYWdlKX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMS41IGJnLWJsdWUtNjAwIGhvdmVyOmJnLWJsdWUtNTAwIHRleHQtd2hpdGUgZm9udC1ib2xkIHRleHQteHMgcHktMiByb3VuZGVkLWxnIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIkRvd25sb2FkIFBhZ2UgYXMgSEQgSlBHXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIDxEb3dubG9hZCBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+RG93bmxvYWQgSlBHPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlUHJpbnRQYWdlKHBhZ2UpfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0xLjUgYmctc2xhdGUtODAwIGhvdmVyOmJnLXNsYXRlLTcwMCB0ZXh0LXNsYXRlLTIwMCBob3Zlcjp0ZXh0LXdoaXRlIGZvbnQtYm9sZCB0ZXh0LXhzIHB5LTIgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJQcmludCBQYWdlIERpcmVjdGx5XCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIDxQcmludGVyIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5QcmludCBQYWdlPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufTtcbiJdfQ==