const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=090625a0";
import { CheckCircle2, Circle, Sparkles } from "/node_modules/.vite/deps/lucide-react.js?v=090625a0";
var _jsxFileName = "/app/applet/src/components/WorkflowGuideView.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=090625a0";
const WORKFLOW_STEPS = [
	{
		id: "step-1",
		stepNumber: 1,
		title: "Customer Intake & Service Identification",
		description: "Welcome citizen, identify requested scheme or document service, and verify basic eligibility.",
		toolsUsed: [
			"Dashboard",
			"50+ Govt Portals Hub",
			"AI Scheme Assistant"
		],
		checklist: [
			"Ask for Aadhaar Number / Registered Mobile Number",
			"Verify active OTP on mobile for Aadhaar/PAN based portals",
			"Inform customer of official Govt portal fee + cyber cafe service charges upfront",
			"Record customer name and phone in Customer CRM"
		],
		tips: "Aadhaar mein mobile number linked hona zaroori hai PM-KISAN, Ladki Bahin, aur Mahadbt schemes ke liye."
	},
	{
		id: "step-2",
		stepNumber: 2,
		title: "Portal Submission & Application Filing",
		description: "Navigate to the official Central or State portal, enter verified details, and submit application.",
		toolsUsed: ["50+ Govt Portals Directory", "PDF to HD JPG Converter"],
		checklist: [
			"Open official portal via Direct Portal Hub (Aaple Sarkar, Mahadbt, Sarathi, etc.)",
			"Fill candidate name matching exactly with Aadhaar card",
			"If portal requires JPG under 100KB, use PDF to JPG tool to compress documents",
			"Save final submission PDF / Acknowledgement slip"
		],
		tips: "Acknowledgement Receipt Token Number hamesha download karke Customer CRM mein note karein."
	},
	{
		id: "step-3",
		stepNumber: 3,
		title: "Studio Photo & PVC Card Processing",
		description: "Format photos for official exam specifications or prepare dual CR-80 PVC cards.",
		toolsUsed: ["Passport Photo Studio Pro", "PVC Smart Card Maker"],
		checklist: [
			"Passport Photo: Choose 4×6 Landscape (8 Copies @ 300 DPI) or A4 Landscape",
			"Background: Use Magic Wand or Pen Tool to change background to Official White or Studio Blue",
			"Auto Beauty: Apply AI Face Smoothing to remove camera noise and brighten facial features",
			"Exam Strip: Add Candidate Name & Date stamp if applying for SSC GD, Police Bharti, or Railway",
			"PVC Card: Upload Front & Back side, align to CR-80 85.6×54mm template with center cut line"
		],
		tips: "PVC Card print karte waqt printer properties mein \"High Quality Glossy Photo Paper\" select karein."
	},
	{
		id: "step-4",
		stepNumber: 4,
		title: "Printing & Quality Lamination",
		description: "Execute high-resolution physical printing on connected Epson, Canon, or HP printers.",
		toolsUsed: ["Direct In-App Print Engine (Ctrl + P)"],
		checklist: [
			"Load 4×6 inch (10×15 cm) Glossy Photo Paper in printer tray",
			"Press \"🖨️ Direct Print Sheet (Ctrl + P)\" directly inside the app",
			"Inspect printed colors, crop marks, and cut along pre-aligned guide line",
			"For PVC Cards: Pass card through thermal laminator for waterproof finish"
		],
		tips: "In-app direct print zero popup blocker ke saath seedha connected printer par 300 DPI job bhejta hai."
	},
	{
		id: "step-5",
		stepNumber: 5,
		title: "POS Billing & Thermal Receipt",
		description: "Generate itemized tax invoice or 58mm/80mm thermal slip with UPI dynamic QR code.",
		toolsUsed: ["Fast Billing Desk POS"],
		checklist: [
			"Select service package (e.g. PVC Card ₹70, Passport Photo 8-copies ₹50, Online Form ₹100)",
			"Display dynamic UPI QR code on screen for instant customer payment",
			"Print 58mm thermal receipt or A4 official tax invoice for customer records",
			"Update payment status as \"Paid\" in ledger"
		],
		tips: "Thermal receipt par shop ka authorized signature aur non-refundable portal terms automatic aate hain."
	},
	{
		id: "step-6",
		stepNumber: 6,
		title: "Customer Handover & Delivery Tracking",
		description: "Hand over printed copies, send WhatsApp acknowledgement, and close job ticket.",
		toolsUsed: ["Customer CRM & Job Tracker"],
		checklist: [
			"Hand over laminated cards, passport photos in sleeve, and portal acknowledgement",
			"Send WhatsApp confirmation with status update",
			"Mark job as \"Delivered\" in CRM Tracker",
			"Daily reconciliation: Check total cash + UPI collections in Billing Desk Summary"
		],
		tips: "Din ke end par Daily Ledger Summary se cash counter balance match karein."
	}
];
export const WorkflowGuideView = () => {
	const [completedSteps, setCompletedSteps] = useState({});
	const toggleStep = (stepId) => {
		setCompletedSteps((prev) => ({
			...prev,
			[stepId]: !prev[stepId]
		}));
	};
	const completedCount = Object.values(completedSteps).filter(Boolean).length;
	const progressPercent = Math.round(completedCount / WORKFLOW_STEPS.length * 100);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "space-y-4",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-md flex flex-col sm:flex-row sm:items-center justify-between gap-4",
			children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center gap-2",
				children: [/* @__PURE__ */ _jsxDEV("h1", {
					className: "text-xl font-extrabold text-white",
					children: "Cyber Cafe Standard Operating Procedure (SOP)"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 136,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("span", {
					className: "bg-blue-500/20 text-blue-300 border border-blue-500/30 text-xs px-2.5 py-0.5 rounded-full font-mono font-bold",
					children: "v98.0 Master Workflow"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 137,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 135,
				columnNumber: 11
			}, this), /* @__PURE__ */ _jsxDEV("p", {
				className: "text-xs text-slate-400 mt-1",
				children: "End-to-End Cyber Cafe Workstation Flow • Citizen Intake to 300 DPI Printing & POS Settlement"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 141,
				columnNumber: 11
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 134,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "bg-slate-950 border border-slate-800 p-3 rounded-xl min-w-[200px] text-xs space-y-1.5",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex justify-between items-center text-slate-300 font-bold",
					children: [/* @__PURE__ */ _jsxDEV("span", { children: "Daily Job Checklist:" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 149,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "text-blue-400 font-mono",
						children: [
							completedCount,
							" / ",
							WORKFLOW_STEPS.length,
							" Completed"
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 150,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 148,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "w-full bg-slate-800 h-2 rounded-full overflow-hidden",
					children: /* @__PURE__ */ _jsxDEV("div", {
						className: "bg-gradient-to-r from-blue-600 to-indigo-500 h-full transition-all duration-300",
						style: { width: `${progressPercent}%` }
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 153,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 152,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 147,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 133,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "grid grid-cols-1 md:grid-cols-2 gap-4",
			children: WORKFLOW_STEPS.map((step) => {
				const isDone = !!completedSteps[step.id];
				return /* @__PURE__ */ _jsxDEV("div", {
					className: `border rounded-2xl p-5 transition-all shadow-md flex flex-col justify-between space-y-4 ${isDone ? "bg-slate-900/40 border-emerald-500/40" : "bg-slate-900 border-slate-800 hover:border-slate-700"}`,
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-3",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-2.5",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: `w-7 h-7 rounded-xl flex items-center justify-center font-extrabold text-xs font-mono shadow-sm ${isDone ? "bg-emerald-500 text-slate-950 font-bold" : "bg-blue-600 text-white"}`,
										children: step.stepNumber
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 177,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("h3", {
										className: "font-extrabold text-white text-sm",
										children: step.title
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 184,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 176,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									onClick: () => toggleStep(step.id),
									className: `flex items-center gap-1.5 text-xs font-bold px-2.5 py-1 rounded-lg border transition-all ${isDone ? "bg-emerald-500/20 text-emerald-300 border-emerald-500/30" : "bg-slate-800 text-slate-400 border-slate-700 hover:text-white"}`,
									children: [isDone ? /* @__PURE__ */ _jsxDEV(CheckCircle2, { className: "w-4 h-4 text-emerald-400" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 195,
										columnNumber: 31
									}, this) : /* @__PURE__ */ _jsxDEV(Circle, { className: "w-4 h-4" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 195,
										columnNumber: 87
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: isDone ? "Completed" : "Mark Done" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 196,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 187,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 175,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-slate-300 leading-relaxed",
								children: step.description
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 200,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-1.5 flex-wrap pt-1",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-[10px] text-slate-500 font-bold uppercase tracking-wider",
									children: "Tools:"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 206,
									columnNumber: 19
								}, this), step.toolsUsed.map((tool) => /* @__PURE__ */ _jsxDEV("span", {
									className: "text-[10px] bg-slate-950 text-blue-300 border border-slate-800 px-2 py-0.5 rounded font-mono font-medium",
									children: tool
								}, tool, false, {
									fileName: _jsxFileName,
									lineNumber: 208,
									columnNumber: 21
								}, this))]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 205,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "pt-2 border-t border-slate-800/80 space-y-1.5",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-[11px] font-bold text-slate-300 block",
									children: "Operator Action Items:"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 219,
									columnNumber: 19
								}, this), step.checklist.map((item, idx) => /* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-start gap-2 text-xs text-slate-400 leading-snug",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-blue-500 mt-0.5",
										children: "•"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 222,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: item }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 223,
										columnNumber: 23
									}, this)]
								}, idx, true, {
									fileName: _jsxFileName,
									lineNumber: 221,
									columnNumber: 21
								}, this))]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 218,
								columnNumber: 17
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 174,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "p-3 rounded-xl bg-slate-950 border border-slate-800 text-[11px] text-amber-300/90 flex items-start gap-2",
						children: [/* @__PURE__ */ _jsxDEV(Sparkles, { className: "w-3.5 h-3.5 text-amber-400 flex-shrink-0 mt-0.5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 231,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("b", {
							className: "text-white",
							children: "Pro Tip: "
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 233,
							columnNumber: 19
						}, this), step.tips] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 232,
							columnNumber: 17
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 230,
						columnNumber: 15
					}, this)]
				}, step.id, true, {
					fileName: _jsxFileName,
					lineNumber: 166,
					columnNumber: 13
				}, this);
			})
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 162,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 131,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxTQUNFLGNBQ0EsUUFPQSxnQkFNSzs7O0FBWVAsTUFBTSxpQkFBaUM7Q0FDckM7RUFDRSxJQUFJO0VBQ0osWUFBWTtFQUNaLE9BQU87RUFDUCxhQUFhO0VBQ2IsV0FBVztHQUFDO0dBQWE7R0FBd0I7RUFBcUI7RUFDdEUsV0FBVztHQUNUO0dBQ0E7R0FDQTtHQUNBO0VBQ0Y7RUFDQSxNQUFNO0NBQ1I7Q0FDQTtFQUNFLElBQUk7RUFDSixZQUFZO0VBQ1osT0FBTztFQUNQLGFBQWE7RUFDYixXQUFXLENBQUMsOEJBQThCLHlCQUF5QjtFQUNuRSxXQUFXO0dBQ1Q7R0FDQTtHQUNBO0dBQ0E7RUFDRjtFQUNBLE1BQU07Q0FDUjtDQUNBO0VBQ0UsSUFBSTtFQUNKLFlBQVk7RUFDWixPQUFPO0VBQ1AsYUFBYTtFQUNiLFdBQVcsQ0FBQyw2QkFBNkIsc0JBQXNCO0VBQy9ELFdBQVc7R0FDVDtHQUNBO0dBQ0E7R0FDQTtHQUNBO0VBQ0Y7RUFDQSxNQUFNO0NBQ1I7Q0FDQTtFQUNFLElBQUk7RUFDSixZQUFZO0VBQ1osT0FBTztFQUNQLGFBQWE7RUFDYixXQUFXLENBQUMsdUNBQXVDO0VBQ25ELFdBQVc7R0FDVDtHQUNBO0dBQ0E7R0FDQTtFQUNGO0VBQ0EsTUFBTTtDQUNSO0NBQ0E7RUFDRSxJQUFJO0VBQ0osWUFBWTtFQUNaLE9BQU87RUFDUCxhQUFhO0VBQ2IsV0FBVyxDQUFDLHVCQUF1QjtFQUNuQyxXQUFXO0dBQ1Q7R0FDQTtHQUNBO0dBQ0E7RUFDRjtFQUNBLE1BQU07Q0FDUjtDQUNBO0VBQ0UsSUFBSTtFQUNKLFlBQVk7RUFDWixPQUFPO0VBQ1AsYUFBYTtFQUNiLFdBQVcsQ0FBQyw0QkFBNEI7RUFDeEMsV0FBVztHQUNUO0dBQ0E7R0FDQTtHQUNBO0VBQ0Y7RUFDQSxNQUFNO0NBQ1I7QUFDRjtBQUVBLE9BQU8sTUFBTSwwQkFBb0M7Q0FDL0MsTUFBTSxDQUFDLGdCQUFnQixxQkFBcUIsU0FBa0MsQ0FBQyxDQUFDO0NBRWhGLE1BQU0sY0FBYyxXQUFtQjtFQUNyQyxtQkFBa0IsVUFBUztHQUN6QixHQUFHO0lBQ0YsU0FBUyxDQUFDLEtBQUs7RUFDbEIsRUFBRTtDQUNKO0NBRUEsTUFBTSxpQkFBaUIsT0FBTyxPQUFPLGNBQWMsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUM7Q0FDckUsTUFBTSxrQkFBa0IsS0FBSyxNQUFPLGlCQUFpQixlQUFlLFNBQVUsR0FBRztDQUVqRixPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWYsQ0FFRSx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxNQUFEO0tBQUksV0FBVTtlQUFvQztJQUFpRDs7OztjQUNuRyx3QkFBQyxRQUFEO0tBQU0sV0FBVTtlQUFnSDtJQUUxSDs7OztZQUNIOzs7OzthQUNMLHdCQUFDLEtBQUQ7SUFBRyxXQUFVO2NBQThCO0dBRXhDOzs7O1dBQ0E7Ozs7YUFHTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLFFBQUQsWUFBTSx1QkFBMEI7Ozs7ZUFDaEMsd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQWhCO09BQTJDO09BQWU7T0FBSSxlQUFlO09BQU87TUFBZ0I7Ozs7O2FBQ2pHOzs7OztjQUNMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ2Isd0JBQUMsT0FBRDtNQUNFLFdBQVU7TUFDVixPQUFPLEVBQUUsT0FBTyxHQUFHLGdCQUFnQixHQUFHO0tBQ3ZDOzs7OztJQUNFOzs7O1lBQ0Y7Ozs7O1dBQ0Y7Ozs7O1lBR0wsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFDWixlQUFlLEtBQUssU0FBUztJQUM1QixNQUFNLFNBQVMsQ0FBQyxDQUFDLGVBQWUsS0FBSztJQUNyQyxPQUNFLHdCQUFDLE9BQUQ7S0FFRSxXQUFXLDJGQUNULFNBQ0ksMENBQ0E7ZUFMUixDQVFFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFXLGtHQUNmLFNBQ0ksNENBQ0E7b0JBRUgsS0FBSztTQUNGOzs7O21CQUNOLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUFxQyxLQUFLO1NBQVU7Ozs7aUJBQy9EOzs7OztrQkFFTCx3QkFBQyxVQUFEO1NBQ0UsZUFBZSxXQUFXLEtBQUssRUFBRTtTQUNqQyxXQUFXLDRGQUNULFNBQ0ksNkRBQ0E7bUJBTFIsQ0FRRyxTQUFTLHdCQUFDLGNBQUQsRUFBYyxXQUFVLDJCQUE0Qjs7OztvQkFBSSx3QkFBQyxRQUFELEVBQVEsV0FBVSxVQUFXOzs7O21CQUMvRix3QkFBQyxRQUFELFlBQU8sU0FBUyxjQUFjLFlBQWtCOzs7O2lCQUMxQzs7Ozs7Z0JBQ0w7Ozs7OztPQUVMLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUNWLEtBQUs7T0FDTDs7Ozs7T0FHSCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFnRTtRQUFZOzs7O2tCQUMzRixLQUFLLFVBQVUsS0FBSyxTQUNuQix3QkFBQyxRQUFEO1NBRUUsV0FBVTttQkFFVDtRQUNHLEdBSkM7Ozs7ZUFJRCxDQUNQLENBQ0U7Ozs7OztPQUdMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQTZDO1FBQTRCOzs7O2tCQUN4RixLQUFLLFVBQVUsS0FBSyxNQUFNLFFBQ3pCLHdCQUFDLE9BQUQ7U0FBZSxXQUFVO21CQUF6QixDQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUF1QjtTQUFPOzs7O21CQUM5Qyx3QkFBQyxRQUFELFlBQU8sS0FBVzs7OztpQkFDZjtXQUhLOzs7O2VBR0wsQ0FDTixDQUNFOzs7Ozs7TUFDRjs7Ozs7ZUFHTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLFVBQUQsRUFBVSxXQUFVLGtEQUFtRDs7OztnQkFDdkUsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUFhO01BQVk7Ozs7Z0JBQUUsS0FBSyxJQUMxQzs7OztjQUNGOzs7OzthQUNGO09BckVFLEtBQUs7Ozs7V0FxRVA7R0FFVCxDQUFDO0VBQ0U7Ozs7VUFDRjs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiV29ya2Zsb3dHdWlkZVZpZXcudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IFxuICBDaGVja0NpcmNsZTIsIFxuICBDaXJjbGUsIFxuICBBcnJvd1JpZ2h0LCBcbiAgUHJpbnRlciwgXG4gIEZpbGVUZXh0LCBcbiAgQ3JlZGl0Q2FyZCwgXG4gIENhbWVyYSwgXG4gIFVzZXJzLCBcbiAgU3BhcmtsZXMsIFxuICBMYXllcnMsIFxuICBTaGllbGRDaGVjaywgXG4gIEhlbHBDaXJjbGUsXG4gIENsb2NrLFxuICBRckNvZGVcbn0gZnJvbSAnbHVjaWRlLXJlYWN0JztcblxuaW50ZXJmYWNlIFdvcmtmbG93U3RlcCB7XG4gIGlkOiBzdHJpbmc7XG4gIHN0ZXBOdW1iZXI6IG51bWJlcjtcbiAgdGl0bGU6IHN0cmluZztcbiAgZGVzY3JpcHRpb246IHN0cmluZztcbiAgdG9vbHNVc2VkOiBzdHJpbmdbXTtcbiAgY2hlY2tsaXN0OiBzdHJpbmdbXTtcbiAgdGlwczogc3RyaW5nO1xufVxuXG5jb25zdCBXT1JLRkxPV19TVEVQUzogV29ya2Zsb3dTdGVwW10gPSBbXG4gIHtcbiAgICBpZDogJ3N0ZXAtMScsXG4gICAgc3RlcE51bWJlcjogMSxcbiAgICB0aXRsZTogJ0N1c3RvbWVyIEludGFrZSAmIFNlcnZpY2UgSWRlbnRpZmljYXRpb24nLFxuICAgIGRlc2NyaXB0aW9uOiAnV2VsY29tZSBjaXRpemVuLCBpZGVudGlmeSByZXF1ZXN0ZWQgc2NoZW1lIG9yIGRvY3VtZW50IHNlcnZpY2UsIGFuZCB2ZXJpZnkgYmFzaWMgZWxpZ2liaWxpdHkuJyxcbiAgICB0b29sc1VzZWQ6IFsnRGFzaGJvYXJkJywgJzUwKyBHb3Z0IFBvcnRhbHMgSHViJywgJ0FJIFNjaGVtZSBBc3Npc3RhbnQnXSxcbiAgICBjaGVja2xpc3Q6IFtcbiAgICAgICdBc2sgZm9yIEFhZGhhYXIgTnVtYmVyIC8gUmVnaXN0ZXJlZCBNb2JpbGUgTnVtYmVyJyxcbiAgICAgICdWZXJpZnkgYWN0aXZlIE9UUCBvbiBtb2JpbGUgZm9yIEFhZGhhYXIvUEFOIGJhc2VkIHBvcnRhbHMnLFxuICAgICAgJ0luZm9ybSBjdXN0b21lciBvZiBvZmZpY2lhbCBHb3Z0IHBvcnRhbCBmZWUgKyBjeWJlciBjYWZlIHNlcnZpY2UgY2hhcmdlcyB1cGZyb250JyxcbiAgICAgICdSZWNvcmQgY3VzdG9tZXIgbmFtZSBhbmQgcGhvbmUgaW4gQ3VzdG9tZXIgQ1JNJ1xuICAgIF0sXG4gICAgdGlwczogJ0FhZGhhYXIgbWVpbiBtb2JpbGUgbnVtYmVyIGxpbmtlZCBob25hIHphcm9vcmkgaGFpIFBNLUtJU0FOLCBMYWRraSBCYWhpbiwgYXVyIE1haGFkYnQgc2NoZW1lcyBrZSBsaXllLidcbiAgfSxcbiAge1xuICAgIGlkOiAnc3RlcC0yJyxcbiAgICBzdGVwTnVtYmVyOiAyLFxuICAgIHRpdGxlOiAnUG9ydGFsIFN1Ym1pc3Npb24gJiBBcHBsaWNhdGlvbiBGaWxpbmcnLFxuICAgIGRlc2NyaXB0aW9uOiAnTmF2aWdhdGUgdG8gdGhlIG9mZmljaWFsIENlbnRyYWwgb3IgU3RhdGUgcG9ydGFsLCBlbnRlciB2ZXJpZmllZCBkZXRhaWxzLCBhbmQgc3VibWl0IGFwcGxpY2F0aW9uLicsXG4gICAgdG9vbHNVc2VkOiBbJzUwKyBHb3Z0IFBvcnRhbHMgRGlyZWN0b3J5JywgJ1BERiB0byBIRCBKUEcgQ29udmVydGVyJ10sXG4gICAgY2hlY2tsaXN0OiBbXG4gICAgICAnT3BlbiBvZmZpY2lhbCBwb3J0YWwgdmlhIERpcmVjdCBQb3J0YWwgSHViIChBYXBsZSBTYXJrYXIsIE1haGFkYnQsIFNhcmF0aGksIGV0Yy4pJyxcbiAgICAgICdGaWxsIGNhbmRpZGF0ZSBuYW1lIG1hdGNoaW5nIGV4YWN0bHkgd2l0aCBBYWRoYWFyIGNhcmQnLFxuICAgICAgJ0lmIHBvcnRhbCByZXF1aXJlcyBKUEcgdW5kZXIgMTAwS0IsIHVzZSBQREYgdG8gSlBHIHRvb2wgdG8gY29tcHJlc3MgZG9jdW1lbnRzJyxcbiAgICAgICdTYXZlIGZpbmFsIHN1Ym1pc3Npb24gUERGIC8gQWNrbm93bGVkZ2VtZW50IHNsaXAnXG4gICAgXSxcbiAgICB0aXBzOiAnQWNrbm93bGVkZ2VtZW50IFJlY2VpcHQgVG9rZW4gTnVtYmVyIGhhbWVzaGEgZG93bmxvYWQga2Fya2UgQ3VzdG9tZXIgQ1JNIG1laW4gbm90ZSBrYXJlaW4uJ1xuICB9LFxuICB7XG4gICAgaWQ6ICdzdGVwLTMnLFxuICAgIHN0ZXBOdW1iZXI6IDMsXG4gICAgdGl0bGU6ICdTdHVkaW8gUGhvdG8gJiBQVkMgQ2FyZCBQcm9jZXNzaW5nJyxcbiAgICBkZXNjcmlwdGlvbjogJ0Zvcm1hdCBwaG90b3MgZm9yIG9mZmljaWFsIGV4YW0gc3BlY2lmaWNhdGlvbnMgb3IgcHJlcGFyZSBkdWFsIENSLTgwIFBWQyBjYXJkcy4nLFxuICAgIHRvb2xzVXNlZDogWydQYXNzcG9ydCBQaG90byBTdHVkaW8gUHJvJywgJ1BWQyBTbWFydCBDYXJkIE1ha2VyJ10sXG4gICAgY2hlY2tsaXN0OiBbXG4gICAgICAnUGFzc3BvcnQgUGhvdG86IENob29zZSA0w5c2IExhbmRzY2FwZSAoOCBDb3BpZXMgQCAzMDAgRFBJKSBvciBBNCBMYW5kc2NhcGUnLFxuICAgICAgJ0JhY2tncm91bmQ6IFVzZSBNYWdpYyBXYW5kIG9yIFBlbiBUb29sIHRvIGNoYW5nZSBiYWNrZ3JvdW5kIHRvIE9mZmljaWFsIFdoaXRlIG9yIFN0dWRpbyBCbHVlJyxcbiAgICAgICdBdXRvIEJlYXV0eTogQXBwbHkgQUkgRmFjZSBTbW9vdGhpbmcgdG8gcmVtb3ZlIGNhbWVyYSBub2lzZSBhbmQgYnJpZ2h0ZW4gZmFjaWFsIGZlYXR1cmVzJyxcbiAgICAgICdFeGFtIFN0cmlwOiBBZGQgQ2FuZGlkYXRlIE5hbWUgJiBEYXRlIHN0YW1wIGlmIGFwcGx5aW5nIGZvciBTU0MgR0QsIFBvbGljZSBCaGFydGksIG9yIFJhaWx3YXknLFxuICAgICAgJ1BWQyBDYXJkOiBVcGxvYWQgRnJvbnQgJiBCYWNrIHNpZGUsIGFsaWduIHRvIENSLTgwIDg1LjbDlzU0bW0gdGVtcGxhdGUgd2l0aCBjZW50ZXIgY3V0IGxpbmUnXG4gICAgXSxcbiAgICB0aXBzOiAnUFZDIENhcmQgcHJpbnQga2FydGUgd2FxdCBwcmludGVyIHByb3BlcnRpZXMgbWVpbiBcIkhpZ2ggUXVhbGl0eSBHbG9zc3kgUGhvdG8gUGFwZXJcIiBzZWxlY3Qga2FyZWluLidcbiAgfSxcbiAge1xuICAgIGlkOiAnc3RlcC00JyxcbiAgICBzdGVwTnVtYmVyOiA0LFxuICAgIHRpdGxlOiAnUHJpbnRpbmcgJiBRdWFsaXR5IExhbWluYXRpb24nLFxuICAgIGRlc2NyaXB0aW9uOiAnRXhlY3V0ZSBoaWdoLXJlc29sdXRpb24gcGh5c2ljYWwgcHJpbnRpbmcgb24gY29ubmVjdGVkIEVwc29uLCBDYW5vbiwgb3IgSFAgcHJpbnRlcnMuJyxcbiAgICB0b29sc1VzZWQ6IFsnRGlyZWN0IEluLUFwcCBQcmludCBFbmdpbmUgKEN0cmwgKyBQKSddLFxuICAgIGNoZWNrbGlzdDogW1xuICAgICAgJ0xvYWQgNMOXNiBpbmNoICgxMMOXMTUgY20pIEdsb3NzeSBQaG90byBQYXBlciBpbiBwcmludGVyIHRyYXknLFxuICAgICAgJ1ByZXNzIFwi8J+WqO+4jyBEaXJlY3QgUHJpbnQgU2hlZXQgKEN0cmwgKyBQKVwiIGRpcmVjdGx5IGluc2lkZSB0aGUgYXBwJyxcbiAgICAgICdJbnNwZWN0IHByaW50ZWQgY29sb3JzLCBjcm9wIG1hcmtzLCBhbmQgY3V0IGFsb25nIHByZS1hbGlnbmVkIGd1aWRlIGxpbmUnLFxuICAgICAgJ0ZvciBQVkMgQ2FyZHM6IFBhc3MgY2FyZCB0aHJvdWdoIHRoZXJtYWwgbGFtaW5hdG9yIGZvciB3YXRlcnByb29mIGZpbmlzaCdcbiAgICBdLFxuICAgIHRpcHM6ICdJbi1hcHAgZGlyZWN0IHByaW50IHplcm8gcG9wdXAgYmxvY2tlciBrZSBzYWF0aCBzZWVkaGEgY29ubmVjdGVkIHByaW50ZXIgcGFyIDMwMCBEUEkgam9iIGJoZWp0YSBoYWkuJ1xuICB9LFxuICB7XG4gICAgaWQ6ICdzdGVwLTUnLFxuICAgIHN0ZXBOdW1iZXI6IDUsXG4gICAgdGl0bGU6ICdQT1MgQmlsbGluZyAmIFRoZXJtYWwgUmVjZWlwdCcsXG4gICAgZGVzY3JpcHRpb246ICdHZW5lcmF0ZSBpdGVtaXplZCB0YXggaW52b2ljZSBvciA1OG1tLzgwbW0gdGhlcm1hbCBzbGlwIHdpdGggVVBJIGR5bmFtaWMgUVIgY29kZS4nLFxuICAgIHRvb2xzVXNlZDogWydGYXN0IEJpbGxpbmcgRGVzayBQT1MnXSxcbiAgICBjaGVja2xpc3Q6IFtcbiAgICAgICdTZWxlY3Qgc2VydmljZSBwYWNrYWdlIChlLmcuIFBWQyBDYXJkIOKCuTcwLCBQYXNzcG9ydCBQaG90byA4LWNvcGllcyDigrk1MCwgT25saW5lIEZvcm0g4oK5MTAwKScsXG4gICAgICAnRGlzcGxheSBkeW5hbWljIFVQSSBRUiBjb2RlIG9uIHNjcmVlbiBmb3IgaW5zdGFudCBjdXN0b21lciBwYXltZW50JyxcbiAgICAgICdQcmludCA1OG1tIHRoZXJtYWwgcmVjZWlwdCBvciBBNCBvZmZpY2lhbCB0YXggaW52b2ljZSBmb3IgY3VzdG9tZXIgcmVjb3JkcycsXG4gICAgICAnVXBkYXRlIHBheW1lbnQgc3RhdHVzIGFzIFwiUGFpZFwiIGluIGxlZGdlcidcbiAgICBdLFxuICAgIHRpcHM6ICdUaGVybWFsIHJlY2VpcHQgcGFyIHNob3Aga2EgYXV0aG9yaXplZCBzaWduYXR1cmUgYXVyIG5vbi1yZWZ1bmRhYmxlIHBvcnRhbCB0ZXJtcyBhdXRvbWF0aWMgYWF0ZSBoYWluLidcbiAgfSxcbiAge1xuICAgIGlkOiAnc3RlcC02JyxcbiAgICBzdGVwTnVtYmVyOiA2LFxuICAgIHRpdGxlOiAnQ3VzdG9tZXIgSGFuZG92ZXIgJiBEZWxpdmVyeSBUcmFja2luZycsXG4gICAgZGVzY3JpcHRpb246ICdIYW5kIG92ZXIgcHJpbnRlZCBjb3BpZXMsIHNlbmQgV2hhdHNBcHAgYWNrbm93bGVkZ2VtZW50LCBhbmQgY2xvc2Ugam9iIHRpY2tldC4nLFxuICAgIHRvb2xzVXNlZDogWydDdXN0b21lciBDUk0gJiBKb2IgVHJhY2tlciddLFxuICAgIGNoZWNrbGlzdDogW1xuICAgICAgJ0hhbmQgb3ZlciBsYW1pbmF0ZWQgY2FyZHMsIHBhc3Nwb3J0IHBob3RvcyBpbiBzbGVldmUsIGFuZCBwb3J0YWwgYWNrbm93bGVkZ2VtZW50JyxcbiAgICAgICdTZW5kIFdoYXRzQXBwIGNvbmZpcm1hdGlvbiB3aXRoIHN0YXR1cyB1cGRhdGUnLFxuICAgICAgJ01hcmsgam9iIGFzIFwiRGVsaXZlcmVkXCIgaW4gQ1JNIFRyYWNrZXInLFxuICAgICAgJ0RhaWx5IHJlY29uY2lsaWF0aW9uOiBDaGVjayB0b3RhbCBjYXNoICsgVVBJIGNvbGxlY3Rpb25zIGluIEJpbGxpbmcgRGVzayBTdW1tYXJ5J1xuICAgIF0sXG4gICAgdGlwczogJ0RpbiBrZSBlbmQgcGFyIERhaWx5IExlZGdlciBTdW1tYXJ5IHNlIGNhc2ggY291bnRlciBiYWxhbmNlIG1hdGNoIGthcmVpbi4nXG4gIH1cbl07XG5cbmV4cG9ydCBjb25zdCBXb3JrZmxvd0d1aWRlVmlldzogUmVhY3QuRkMgPSAoKSA9PiB7XG4gIGNvbnN0IFtjb21wbGV0ZWRTdGVwcywgc2V0Q29tcGxldGVkU3RlcHNdID0gdXNlU3RhdGU8UmVjb3JkPHN0cmluZywgYm9vbGVhbj4+KHt9KTtcblxuICBjb25zdCB0b2dnbGVTdGVwID0gKHN0ZXBJZDogc3RyaW5nKSA9PiB7XG4gICAgc2V0Q29tcGxldGVkU3RlcHMocHJldiA9PiAoe1xuICAgICAgLi4ucHJldixcbiAgICAgIFtzdGVwSWRdOiAhcHJldltzdGVwSWRdXG4gICAgfSkpO1xuICB9O1xuXG4gIGNvbnN0IGNvbXBsZXRlZENvdW50ID0gT2JqZWN0LnZhbHVlcyhjb21wbGV0ZWRTdGVwcykuZmlsdGVyKEJvb2xlYW4pLmxlbmd0aDtcbiAgY29uc3QgcHJvZ3Jlc3NQZXJjZW50ID0gTWF0aC5yb3VuZCgoY29tcGxldGVkQ291bnQgLyBXT1JLRkxPV19TVEVQUy5sZW5ndGgpICogMTAwKTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XG4gICAgICB7LyogSGVhZGVyICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcC01IHJvdW5kZWQtMnhsIHNoYWRvdy1tZCBmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IHNtOml0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTRcIj5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWV4dHJhYm9sZCB0ZXh0LXdoaXRlXCI+Q3liZXIgQ2FmZSBTdGFuZGFyZCBPcGVyYXRpbmcgUHJvY2VkdXJlIChTT1ApPC9oMT5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJnLWJsdWUtNTAwLzIwIHRleHQtYmx1ZS0zMDAgYm9yZGVyIGJvcmRlci1ibHVlLTUwMC8zMCB0ZXh0LXhzIHB4LTIuNSBweS0wLjUgcm91bmRlZC1mdWxsIGZvbnQtbW9ubyBmb250LWJvbGRcIj5cbiAgICAgICAgICAgICAgdjk4LjAgTWFzdGVyIFdvcmtmbG93XG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMCBtdC0xXCI+XG4gICAgICAgICAgICBFbmQtdG8tRW5kIEN5YmVyIENhZmUgV29ya3N0YXRpb24gRmxvdyDigKIgQ2l0aXplbiBJbnRha2UgdG8gMzAwIERQSSBQcmludGluZyAmIFBPUyBTZXR0bGVtZW50XG4gICAgICAgICAgPC9wPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogUHJvZ3Jlc3MgQmFyICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBwLTMgcm91bmRlZC14bCBtaW4tdy1bMjAwcHhdIHRleHQteHMgc3BhY2UteS0xLjVcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciB0ZXh0LXNsYXRlLTMwMCBmb250LWJvbGRcIj5cbiAgICAgICAgICAgIDxzcGFuPkRhaWx5IEpvYiBDaGVja2xpc3Q6PC9zcGFuPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ibHVlLTQwMCBmb250LW1vbm9cIj57Y29tcGxldGVkQ291bnR9IC8ge1dPUktGTE9XX1NURVBTLmxlbmd0aH0gQ29tcGxldGVkPC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTgwMCBoLTIgcm91bmRlZC1mdWxsIG92ZXJmbG93LWhpZGRlblwiPlxuICAgICAgICAgICAgPGRpdiBcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JhZGllbnQtdG8tciBmcm9tLWJsdWUtNjAwIHRvLWluZGlnby01MDAgaC1mdWxsIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMFwiXG4gICAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiBgJHtwcm9ncmVzc1BlcmNlbnR9JWAgfX1cbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBTdGVwIGJ5IHN0ZXAgY2FyZHMgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTRcIj5cbiAgICAgICAge1dPUktGTE9XX1NURVBTLm1hcCgoc3RlcCkgPT4ge1xuICAgICAgICAgIGNvbnN0IGlzRG9uZSA9ICEhY29tcGxldGVkU3RlcHNbc3RlcC5pZF07XG4gICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgIDxkaXYgXG4gICAgICAgICAgICAgIGtleT17c3RlcC5pZH1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYm9yZGVyIHJvdW5kZWQtMnhsIHAtNSB0cmFuc2l0aW9uLWFsbCBzaGFkb3ctbWQgZmxleCBmbGV4LWNvbCBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteS00ICR7XG4gICAgICAgICAgICAgICAgaXNEb25lIFxuICAgICAgICAgICAgICAgICAgPyAnYmctc2xhdGUtOTAwLzQwIGJvcmRlci1lbWVyYWxkLTUwMC80MCcgXG4gICAgICAgICAgICAgICAgICA6ICdiZy1zbGF0ZS05MDAgYm9yZGVyLXNsYXRlLTgwMCBob3Zlcjpib3JkZXItc2xhdGUtNzAwJ1xuICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMi41XCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YHctNyBoLTcgcm91bmRlZC14bCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBmb250LWV4dHJhYm9sZCB0ZXh0LXhzIGZvbnQtbW9ubyBzaGFkb3ctc20gJHtcbiAgICAgICAgICAgICAgICAgICAgICBpc0RvbmUgXG4gICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1lbWVyYWxkLTUwMCB0ZXh0LXNsYXRlLTk1MCBmb250LWJvbGQnIFxuICAgICAgICAgICAgICAgICAgICAgICAgOiAnYmctYmx1ZS02MDAgdGV4dC13aGl0ZSdcbiAgICAgICAgICAgICAgICAgICAgfWB9PlxuICAgICAgICAgICAgICAgICAgICAgIHtzdGVwLnN0ZXBOdW1iZXJ9XG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtZXh0cmFib2xkIHRleHQtd2hpdGUgdGV4dC1zbVwiPntzdGVwLnRpdGxlfTwvaDM+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB0b2dnbGVTdGVwKHN0ZXAuaWQpfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHRleHQteHMgZm9udC1ib2xkIHB4LTIuNSBweS0xIHJvdW5kZWQtbGcgYm9yZGVyIHRyYW5zaXRpb24tYWxsICR7XG4gICAgICAgICAgICAgICAgICAgICAgaXNEb25lXG4gICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1lbWVyYWxkLTUwMC8yMCB0ZXh0LWVtZXJhbGQtMzAwIGJvcmRlci1lbWVyYWxkLTUwMC8zMCdcbiAgICAgICAgICAgICAgICAgICAgICAgIDogJ2JnLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTQwMCBib3JkZXItc2xhdGUtNzAwIGhvdmVyOnRleHQtd2hpdGUnXG4gICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICB7aXNEb25lID8gPENoZWNrQ2lyY2xlMiBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtZW1lcmFsZC00MDBcIiAvPiA6IDxDaXJjbGUgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+fVxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj57aXNEb25lID8gJ0NvbXBsZXRlZCcgOiAnTWFyayBEb25lJ308L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS0zMDAgbGVhZGluZy1yZWxheGVkXCI+XG4gICAgICAgICAgICAgICAgICB7c3RlcC5kZXNjcmlwdGlvbn1cbiAgICAgICAgICAgICAgICA8L3A+XG5cbiAgICAgICAgICAgICAgICB7LyogVG9vbHMgdXNlZCB0YWdzICovfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBmbGV4LXdyYXAgcHQtMVwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS01MDAgZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlRvb2xzOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIHtzdGVwLnRvb2xzVXNlZC5tYXAoKHRvb2wpID0+IChcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gXG4gICAgICAgICAgICAgICAgICAgICAga2V5PXt0b29sfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGJnLXNsYXRlLTk1MCB0ZXh0LWJsdWUtMzAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHB4LTIgcHktMC41IHJvdW5kZWQgZm9udC1tb25vIGZvbnQtbWVkaXVtXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIHt0b29sfVxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIHsvKiBDaGVja2xpc3QgKi99XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwdC0yIGJvcmRlci10IGJvcmRlci1zbGF0ZS04MDAvODAgc3BhY2UteS0xLjVcIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTMwMCBibG9ja1wiPk9wZXJhdG9yIEFjdGlvbiBJdGVtczo8L3NwYW4+XG4gICAgICAgICAgICAgICAgICB7c3RlcC5jaGVja2xpc3QubWFwKChpdGVtLCBpZHgpID0+IChcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e2lkeH0gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBnYXAtMiB0ZXh0LXhzIHRleHQtc2xhdGUtNDAwIGxlYWRpbmctc251Z1wiPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtYmx1ZS01MDAgbXQtMC41XCI+4oCiPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPntpdGVtfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgey8qIE9wZXJhdG9yIFBybyBUaXAgKi99XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zIHJvdW5kZWQteGwgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHRleHQtWzExcHhdIHRleHQtYW1iZXItMzAwLzkwIGZsZXggaXRlbXMtc3RhcnQgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICA8U3BhcmtsZXMgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1hbWJlci00MDAgZmxleC1zaHJpbmstMCBtdC0wLjVcIiAvPlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8YiBjbGFzc05hbWU9XCJ0ZXh0LXdoaXRlXCI+UHJvIFRpcDogPC9iPntzdGVwLnRpcHN9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKTtcbiAgICAgICAgfSl9XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG4iXX0=