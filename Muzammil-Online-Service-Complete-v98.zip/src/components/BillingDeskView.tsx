const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"];const QRCode = __vite__cjsImport2_qrcode;const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=090625a0";
import { Receipt, Printer, Send, Search, Trash2, FileSpreadsheet } from "/node_modules/.vite/deps/lucide-react.js?v=090625a0";
import __vite__cjsImport2_qrcode from "/node_modules/.vite/deps/qrcode.js?v=090625a0";
import { COMMON_SHOP_SERVICES } from "/src/data/portalData.ts";
import { printHtmlDocument } from "/src/utils/printer.ts";
var _jsxFileName = "/app/applet/src/components/BillingDeskView.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=090625a0";
export const BillingDeskView = ({ bills, settings, onAddBill, onDeleteBill }) => {
	// New Bill Form State
	const [customerName, setCustomerName] = useState("");
	const [customerMobile, setCustomerMobile] = useState("");
	const [selectedService, setSelectedService] = useState(COMMON_SHOP_SERVICES[0].name);
	const [category, setCategory] = useState(COMMON_SHOP_SERVICES[0].category);
	const [govtFee, setGovtFee] = useState(COMMON_SHOP_SERVICES[0].govtFee);
	const [serviceFee, setServiceFee] = useState(COMMON_SHOP_SERVICES[0].serviceFee);
	const [paymentMode, setPaymentMode] = useState("Cash");
	const [paymentStatus, setPaymentStatus] = useState("Paid");
	const [notes, setNotes] = useState("");
	// Generated QR Code Data URL
	const [qrDataUrl, setQrDataUrl] = useState("");
	// Filter & Search
	const [searchTerm, setSearchTerm] = useState("");
	const [dateFilter, setDateFilter] = useState("");
	// Active bill for preview
	const [activePreviewBill, setActivePreviewBill] = useState(null);
	const totalAmount = (Number(govtFee) || 0) + (Number(serviceFee) || 0);
	// Auto-generate invoice number
	const nextInvoiceNo = `MOS-${new Date().getFullYear()}-${String(bills.length + 101).padStart(4, "0")}`;
	// When selected service changes, populate defaults
	const handleServiceSelect = (serviceName) => {
		setSelectedService(serviceName);
		const found = COMMON_SHOP_SERVICES.find((s) => s.name === serviceName);
		if (found) {
			setCategory(found.category);
			setGovtFee(found.govtFee);
			setServiceFee(found.serviceFee);
		}
	};
	// Generate UPI QR Code whenever total or UPI ID changes
	useEffect(() => {
		const upiString = `upi://pay?pa=${settings.upiId}&pn=${encodeURIComponent(settings.shopName)}&am=${totalAmount}&cu=INR&tn=${encodeURIComponent(nextInvoiceNo)}`;
		QRCode.toDataURL(upiString, {
			width: 180,
			margin: 1
		}).then((url) => setQrDataUrl(url)).catch(() => setQrDataUrl(""));
	}, [
		totalAmount,
		settings.upiId,
		settings.shopName,
		nextInvoiceNo
	]);
	// Handle Form Submission
	const handleCreateBill = (e) => {
		e.preventDefault();
		if (!customerName.trim()) {
			alert("Please enter Customer Name");
			return;
		}
		const newBill = {
			id: `bill-${Date.now()}`,
			invoiceNo: nextInvoiceNo,
			customerName: customerName.trim(),
			customerMobile: customerMobile.trim() || "N/A",
			serviceName: selectedService,
			category,
			govtFee: Number(govtFee) || 0,
			serviceFee: Number(serviceFee) || 0,
			total: totalAmount,
			paymentMode,
			status: paymentStatus,
			createdAt: new Date().toLocaleString("en-IN", {
				dateStyle: "medium",
				timeStyle: "short"
			}),
			notes: notes.trim()
		};
		onAddBill(newBill);
		setActivePreviewBill(newBill);
		// Reset customer name & mobile for next transaction
		setCustomerName("");
		setCustomerMobile("");
		setNotes("");
	};
	// Direct Thermal POS Print (58mm or 80mm format)
	const handlePrintThermal = (billToPrint) => {
		const is80 = settings.thermalWidth === "80mm";
		const paperWidth = is80 ? "76mm" : "56mm";
		const pageStyle = `
      @page {
        size: ${paperWidth} auto;
        margin: 0;
      }
      body {
        font-family: 'Courier New', Courier, monospace;
        width: ${paperWidth};
        margin: 0 auto;
        padding: 6px;
        font-size: 12px;
        color: #000;
        line-height: 1.3;
      }
      .center { text-align: center; }
      .right { text-align: right; }
      .bold { font-weight: bold; }
      .divider { border-top: 1px dashed #000; margin: 6px 0; }
      .header { font-size: 15px; font-weight: bold; }
      .qr { text-align: center; margin: 8px 0; }
      .qr img { width: 120px; height: 120px; }
      table { width: 100%; border-collapse: collapse; font-size: 12px; }
      td { padding: 2px 0; }
    `;
		const htmlBody = `
      <div class="center">
        <div class="header">${settings.shopName}</div>
        <div>${settings.tagline}</div>
        <div>${settings.address}</div>
        <div>Mob: ${settings.phone}</div>
      </div>
      <div class="divider"></div>
      <div><b>Invoice:</b> ${billToPrint.invoiceNo}</div>
      <div><b>Date:</b> ${billToPrint.createdAt}</div>
      <div><b>Customer:</b> ${billToPrint.customerName}</div>
      <div><b>Phone:</b> ${billToPrint.customerMobile}</div>
      <div class="divider"></div>
      <table>
        <tr><td class="bold">Service:</td><td class="right">${billToPrint.serviceName}</td></tr>
        ${billToPrint.govtFee > 0 ? `<tr><td>Govt Fee:</td><td class="right">₹${billToPrint.govtFee}</td></tr>` : ""}
        <tr><td>Service Charge:</td><td class="right">₹${billToPrint.serviceFee}</td></tr>
        <tr style="border-top:1px solid #000; font-weight:bold;">
          <td style="font-size:14px;">TOTAL:</td>
          <td class="right" style="font-size:14px;">₹${billToPrint.total}</td>
        </tr>
      </table>
      <div class="divider"></div>
      <div><b>Payment:</b> ${billToPrint.paymentMode} (${billToPrint.status})</div>
      ${settings.upiId ? `
        <div class="qr">
          <div>Scan UPI to Pay:</div>
          <img src="${qrDataUrl}" />
          <div style="font-size:10px;">${settings.upiId}</div>
        </div>
      ` : ""}
      <div class="center" style="font-size:11px; margin-top:8px;">
        <div>*** Thank You Visit Again ***</div>
        <div>Computerized Online Service Receipt</div>
      </div>
    `;
		printHtmlDocument(htmlBody, `Receipt_${billToPrint.invoiceNo}`, pageStyle);
	};
	// Direct A4 Official Invoice Print
	const handlePrintA4 = (billToPrint) => {
		const pageStyle = `
      @page { size: A4; margin: 15mm; }
      body { font-family: sans-serif; margin: 0; padding: 20px; color: #1e293b; font-size: 14px; }
      .header-table { width: 100%; border-bottom: 2px solid #2563eb; padding-bottom: 15px; margin-bottom: 20px; }
      .shop-title { font-size: 24px; font-weight: 800; color: #1e40af; }
      .info-box { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 12px; margin-bottom: 20px; }
      table.items { width: 100%; border-collapse: collapse; margin-top: 15px; }
      table.items th { background: #2563eb; color: #fff; text-align: left; padding: 10px; font-size: 13px; }
      table.items td { padding: 10px; border-bottom: 1px solid #e2e8f0; }
      .total-row { font-size: 16px; font-weight: bold; background: #eff6ff; }
      .footer { margin-top: 40px; display: flex; justify-content: space-between; align-items: flex-end; }
      .sign { border-top: 1px solid #94a3b8; width: 180px; text-align: center; padding-top: 5px; font-size: 12px; }
    `;
		const htmlBody = `
          <table class="header-table">
            <tr>
              <td>
                <div class="shop-title">${settings.shopName}</div>
                <div>${settings.tagline}</div>
                <div>${settings.address}</div>
                <div>Phone / WhatsApp: ${settings.phone}</div>
                ${settings.gstNo ? `<div>GSTIN: ${settings.gstNo}</div>` : ""}
              </td>
              <td style="text-align:right;">
                <h2 style="margin:0; color:#1e40af;">SERVICE INVOICE</h2>
                <div style="font-family:monospace; font-size:16px; font-weight:bold;">${billToPrint.invoiceNo}</div>
                <div style="margin-top:4px;">Date: ${billToPrint.createdAt}</div>
              </td>
            </tr>
          </table>

          <div class="info-box">
            <table style="width:100%;">
              <tr>
                <td><b>Billed To:</b> ${billToPrint.customerName}</td>
                <td style="text-align:right;"><b>Mobile:</b> ${billToPrint.customerMobile}</td>
              </tr>
            </table>
          </div>

          <table class="items">
            <thead>
              <tr>
                <th>Sr.</th>
                <th>Service Description</th>
                <th>Category</th>
                <th style="text-align:right;">Govt Fee</th>
                <th style="text-align:right;">Service Charge</th>
                <th style="text-align:right;">Total (₹)</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>1</td>
                <td><b>${billToPrint.serviceName}</b></td>
                <td>${billToPrint.category}</td>
                <td style="text-align:right;">₹${billToPrint.govtFee}</td>
                <td style="text-align:right;">₹${billToPrint.serviceFee}</td>
                <td style="text-align:right; font-weight:bold;">₹${billToPrint.total}</td>
              </tr>
              <tr class="total-row">
                <td colspan="5" style="text-align:right;">GRAND TOTAL:</td>
                <td style="text-align:right; color:#1e40af;">₹${billToPrint.total}.00</td>
              </tr>
            </tbody>
          </table>

          <div style="margin-top:15px; font-size:12px; color:#64748b;">
            Payment Mode: <b>${billToPrint.paymentMode}</b> | Status: <b>${billToPrint.status}</b>
          </div>

          <div class="footer">
            <div style="font-size:11px; color:#64748b;">
              This is a computer generated invoice.<br>Terms: Fees once paid for government portal submissions are non-refundable.
            </div>
            <div class="sign">
              Authorized Signatory<br><b>${settings.shopName}</b>
            </div>
          </div>
        </body>
      </html>
    `;
		printHtmlDocument(htmlBody, `Invoice_${billToPrint.invoiceNo}`, pageStyle);
	};
	// Export ledger to CSV
	const handleExportCSV = () => {
		let csv = "Invoice No,Customer Name,Mobile,Service,Govt Fee,Service Fee,Total,Payment Mode,Status,Date\n";
		bills.forEach((b) => {
			csv += `"${b.invoiceNo}","${b.customerName}","${b.customerMobile}","${b.serviceName}",${b.govtFee},${b.serviceFee},${b.total},"${b.paymentMode}","${b.status}","${b.createdAt}"\n`;
		});
		const blob = new Blob([csv], { type: "text/csv" });
		const url = URL.createObjectURL(blob);
		const a = document.createElement("a");
		a.href = url;
		a.download = `Muzammil_Bills_Ledger_${new Date().toISOString().slice(0, 10)}.csv`;
		a.click();
		URL.revokeObjectURL(url);
	};
	// Filter bills
	const filteredBills = bills.filter((b) => {
		const matchesSearch = b.customerName.toLowerCase().includes(searchTerm.toLowerCase()) || b.customerMobile.includes(searchTerm) || b.invoiceNo.toLowerCase().includes(searchTerm.toLowerCase()) || b.serviceName.toLowerCase().includes(searchTerm.toLowerCase());
		const matchesDate = !dateFilter || b.createdAt.includes(dateFilter);
		return matchesSearch && matchesDate;
	});
	const activeDisplayBill = activePreviewBill || (bills.length > 0 ? bills[0] : null);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900 border border-slate-800 p-4 rounded-2xl shadow-md",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ _jsxDEV("h1", {
						className: "text-xl font-extrabold text-white",
						children: "Billing Desk & POS Station"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 310,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-xs px-2 py-0.5 rounded-full font-mono font-bold",
						children: [settings.thermalWidth, " POS / A4"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 311,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 309,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "text-xs text-slate-400 mt-0.5",
					children: "Quick customer billing, dynamic UPI QR payments, 58mm/80mm thermal receipt printing & WhatsApp notification"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 315,
					columnNumber: 11
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 308,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2",
					children: /* @__PURE__ */ _jsxDEV("button", {
						onClick: handleExportCSV,
						className: "flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white font-bold text-xs px-3 py-2 rounded-xl border border-slate-700 transition-all",
						title: "Export Bills Ledger to Excel CSV",
						children: [/* @__PURE__ */ _jsxDEV(FileSpreadsheet, { className: "w-4 h-4 text-emerald-400" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 326,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Export CSV" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 327,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 321,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 320,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 307,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "grid grid-cols-1 lg:grid-cols-12 gap-5 items-start",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "lg:col-span-7 space-y-4",
					children: /* @__PURE__ */ _jsxDEV("form", {
						onSubmit: handleCreateBill,
						className: "bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-md space-y-4",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center justify-between border-b border-slate-800 pb-3",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-2",
									children: [/* @__PURE__ */ _jsxDEV(Receipt, { className: "w-4 h-4 text-emerald-400" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 339,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Create New Customer Receipt" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 340,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 338,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs font-mono font-bold text-blue-400 bg-blue-500/10 px-2 py-0.5 rounded border border-blue-500/20",
									children: ["Next: ", nextInvoiceNo]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 342,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 337,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs",
								children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "font-semibold text-slate-300 block mb-1",
									children: "Customer Full Name *"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 350,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									required: true,
									placeholder: "e.g. Shaikh Sameer",
									value: customerName,
									onChange: (e) => setCustomerName(e.target.value),
									className: "w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 text-sm font-medium"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 351,
									columnNumber: 17
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 349,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "font-semibold text-slate-300 block mb-1",
									children: "Customer Mobile (WhatsApp) *"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 362,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "tel",
									placeholder: "10 digit mobile (e.g. 9561460313)",
									value: customerMobile,
									onChange: (e) => setCustomerMobile(e.target.value),
									className: "w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 text-sm font-mono"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 363,
									columnNumber: 17
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 361,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 348,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "text-xs space-y-1",
								children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "font-semibold text-slate-300 block",
									children: "Select Service / Application *"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 375,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("select", {
									value: selectedService,
									onChange: (e) => handleServiceSelect(e.target.value),
									className: "w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2.5 text-white focus:outline-none focus:border-emerald-500 text-sm font-medium",
									children: COMMON_SHOP_SERVICES.map((s) => /* @__PURE__ */ _jsxDEV("option", {
										value: s.name,
										children: [
											s.name,
											" (Govt: ₹",
											s.govtFee,
											" + Fee: ₹",
											s.serviceFee,
											" = ₹",
											s.govtFee + s.serviceFee,
											")"
										]
									}, s.name, true, {
										fileName: _jsxFileName,
										lineNumber: 382,
										columnNumber: 19
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 376,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 374,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-3 gap-3 text-xs bg-slate-950/60 p-3 rounded-xl border border-slate-800",
								children: [
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "text-slate-400 block mb-1",
										children: "Govt Portal Fee (₹)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 392,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "number",
										min: "0",
										value: govtFee,
										onChange: (e) => setGovtFee(Number(e.target.value)),
										className: "w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white font-mono text-sm"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 393,
										columnNumber: 17
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 391,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "text-slate-400 block mb-1",
										children: "Shop Service Fee (₹)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 403,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "number",
										min: "0",
										value: serviceFee,
										onChange: (e) => setServiceFee(Number(e.target.value)),
										className: "w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white font-mono text-sm"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 404,
										columnNumber: 17
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 402,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "text-emerald-400 font-bold block mb-1",
										children: "Total Bill Amount"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 414,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "h-8 rounded-lg bg-emerald-950/40 border border-emerald-500/40 flex items-center px-3 font-mono font-black text-emerald-400 text-base",
										children: ["₹", totalAmount]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 415,
										columnNumber: 17
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 413,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 390,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs",
								children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "font-semibold text-slate-300 block mb-1",
									children: "Payment Method"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 424,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-3 gap-1.5",
									children: [
										"Cash",
										"UPI / QR",
										"Pending"
									].map((mode) => /* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => setPaymentMode(mode),
										className: `py-1.5 px-2 rounded-lg font-bold border transition-all ${paymentMode === mode ? "bg-blue-600 text-white border-blue-500 shadow-sm" : "bg-slate-950 text-slate-400 border-slate-800 hover:bg-slate-800"}`,
										children: mode
									}, mode, false, {
										fileName: _jsxFileName,
										lineNumber: 427,
										columnNumber: 21
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 425,
									columnNumber: 17
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 423,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "font-semibold text-slate-300 block mb-1",
									children: "Payment Status"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 444,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-2 gap-1.5",
									children: ["Paid", "Due"].map((st) => /* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => setPaymentStatus(st === "Due" ? "Due" : "Paid"),
										className: `py-1.5 px-2 rounded-lg font-bold border transition-all ${paymentStatus === st ? st === "Paid" ? "bg-emerald-600 text-white border-emerald-500" : "bg-rose-600 text-white border-rose-500" : "bg-slate-950 text-slate-400 border-slate-800 hover:bg-slate-800"}`,
										children: st
									}, st, false, {
										fileName: _jsxFileName,
										lineNumber: 447,
										columnNumber: 21
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 445,
									columnNumber: 17
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 443,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 422,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "text-xs",
								children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "text-slate-400 block mb-1",
									children: "Service Remarks / Ack Token (Optional)"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 468,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									placeholder: "e.g. Ack token 88124, 2 copies printed",
									value: notes,
									onChange: (e) => setNotes(e.target.value),
									className: "w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-1.5 text-white placeholder-slate-500 text-xs"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 469,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 467,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								type: "submit",
								className: "w-full flex items-center justify-center gap-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-extrabold text-sm py-3 rounded-xl shadow-lg shadow-emerald-600/30 transition-all hover:scale-[1.01] active:scale-[0.99]",
								children: [/* @__PURE__ */ _jsxDEV(Receipt, { className: "w-4 h-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 483,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: [
									"Generate Receipt & Save (₹",
									totalAmount,
									")"
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 484,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 479,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 336,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 335,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "lg:col-span-5 space-y-3",
					children: /* @__PURE__ */ _jsxDEV("div", {
						className: "bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-xl",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center justify-between mb-3 text-xs",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "font-bold text-white flex items-center gap-1.5",
									children: [/* @__PURE__ */ _jsxDEV(Printer, { className: "w-3.5 h-3.5 text-blue-400" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 494,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Live POS Thermal Slip Preview" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 495,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 493,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "text-[11px] font-mono text-slate-400 bg-slate-800 px-2 py-0.5 rounded",
									children: [settings.thermalWidth, " Monospace"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 497,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 492,
								columnNumber: 13
							}, this),
							activeDisplayBill ? /* @__PURE__ */ _jsxDEV("div", {
								className: "bg-white text-slate-950 p-5 rounded-xl shadow-2xl font-mono text-xs select-text border border-slate-300 mx-auto max-w-[340px] leading-relaxed",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "text-center space-y-0.5 border-b border-dashed border-slate-400 pb-3",
										children: [
											/* @__PURE__ */ _jsxDEV("div", {
												className: "font-black text-sm uppercase tracking-tight",
												children: settings.shopName
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 507,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "text-[11px] text-slate-600",
												children: settings.tagline
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 508,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "text-[10px] text-slate-600",
												children: settings.address
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 509,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "text-[11px] font-bold",
												children: ["Mob: ", settings.phone]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 510,
												columnNumber: 19
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 506,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "py-2.5 border-b border-dashed border-slate-400 space-y-0.5 text-[11px]",
										children: [
											/* @__PURE__ */ _jsxDEV("div", {
												className: "flex justify-between",
												children: [/* @__PURE__ */ _jsxDEV("span", { children: "Invoice:" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 516,
													columnNumber: 21
												}, this), /* @__PURE__ */ _jsxDEV("span", {
													className: "font-bold",
													children: activeDisplayBill.invoiceNo
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 517,
													columnNumber: 21
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 515,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "flex justify-between",
												children: [/* @__PURE__ */ _jsxDEV("span", { children: "Date:" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 520,
													columnNumber: 21
												}, this), /* @__PURE__ */ _jsxDEV("span", { children: activeDisplayBill.createdAt }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 521,
													columnNumber: 21
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 519,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "flex justify-between",
												children: [/* @__PURE__ */ _jsxDEV("span", { children: "Customer:" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 524,
													columnNumber: 21
												}, this), /* @__PURE__ */ _jsxDEV("span", {
													className: "font-bold",
													children: activeDisplayBill.customerName
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 525,
													columnNumber: 21
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 523,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "flex justify-between",
												children: [/* @__PURE__ */ _jsxDEV("span", { children: "Phone:" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 528,
													columnNumber: 21
												}, this), /* @__PURE__ */ _jsxDEV("span", { children: activeDisplayBill.customerMobile }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 529,
													columnNumber: 21
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 527,
												columnNumber: 19
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 514,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "py-2.5 border-b border-dashed border-slate-400 space-y-1 text-xs",
										children: [
											/* @__PURE__ */ _jsxDEV("div", {
												className: "font-bold",
												children: activeDisplayBill.serviceName
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 535,
												columnNumber: 19
											}, this),
											activeDisplayBill.govtFee > 0 && /* @__PURE__ */ _jsxDEV("div", {
												className: "flex justify-between text-[11px] text-slate-700",
												children: [/* @__PURE__ */ _jsxDEV("span", { children: "Govt Portal Fee:" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 538,
													columnNumber: 23
												}, this), /* @__PURE__ */ _jsxDEV("span", { children: ["₹", activeDisplayBill.govtFee] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 539,
													columnNumber: 23
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 537,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "flex justify-between text-[11px] text-slate-700",
												children: [/* @__PURE__ */ _jsxDEV("span", { children: "Service Charge:" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 543,
													columnNumber: 21
												}, this), /* @__PURE__ */ _jsxDEV("span", { children: ["₹", activeDisplayBill.serviceFee] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 544,
													columnNumber: 21
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 542,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "flex justify-between font-black text-sm pt-1 border-t border-slate-900 mt-1",
												children: [/* @__PURE__ */ _jsxDEV("span", { children: "NET TOTAL:" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 547,
													columnNumber: 21
												}, this), /* @__PURE__ */ _jsxDEV("span", { children: [
													"₹",
													activeDisplayBill.total,
													".00"
												] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 548,
													columnNumber: 21
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 546,
												columnNumber: 19
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 534,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "pt-2 text-center space-y-2",
										children: [
											/* @__PURE__ */ _jsxDEV("div", {
												className: "text-[11px] font-semibold",
												children: [
													"Payment Mode: ",
													/* @__PURE__ */ _jsxDEV("b", { children: activeDisplayBill.paymentMode }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 555,
														columnNumber: 35
													}, this),
													" (",
													activeDisplayBill.status,
													")"
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 554,
												columnNumber: 19
											}, this),
											settings.upiId && /* @__PURE__ */ _jsxDEV("div", {
												className: "flex flex-col items-center justify-center p-2 bg-slate-50 rounded-lg border border-slate-200",
												children: [
													/* @__PURE__ */ _jsxDEV("span", {
														className: "text-[10px] text-slate-500 mb-1",
														children: "Scan QR via GPay / PhonePe / Paytm:"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 560,
														columnNumber: 23
													}, this),
													qrDataUrl && /* @__PURE__ */ _jsxDEV("img", {
														src: qrDataUrl,
														alt: "UPI QR",
														className: "w-28 h-28"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 561,
														columnNumber: 37
													}, this),
													/* @__PURE__ */ _jsxDEV("span", {
														className: "text-[10px] font-bold font-mono text-slate-700 mt-1",
														children: settings.upiId
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 562,
														columnNumber: 23
													}, this)
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 559,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "text-[10px] text-slate-500 pt-1",
												children: [
													"*** Thank You Visit Again ***",
													/* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 567,
														columnNumber: 50
													}, this),
													"Muzammil Online Service Digital Hub"
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 566,
												columnNumber: 19
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 553,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 504,
								columnNumber: 15
							}, this) : /* @__PURE__ */ _jsxDEV("div", {
								className: "p-8 text-center text-slate-500 text-xs",
								children: "No bill selected. Create a bill on the left to see live preview."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 573,
								columnNumber: 15
							}, this),
							activeDisplayBill && /* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-3 gap-2 mt-4 pt-3 border-t border-slate-800",
								children: [
									/* @__PURE__ */ _jsxDEV("button", {
										onClick: () => handlePrintThermal(activeDisplayBill),
										className: "flex items-center justify-center gap-1.5 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs py-2 rounded-xl shadow-md transition-colors",
										title: "Print on 58mm/80mm Thermal Printer",
										children: [/* @__PURE__ */ _jsxDEV(Printer, { className: "w-3.5 h-3.5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 586,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Thermal" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 587,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 581,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										onClick: () => handlePrintA4(activeDisplayBill),
										className: "flex items-center justify-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white font-bold text-xs py-2 rounded-xl border border-slate-700 transition-colors",
										title: "Print Official A4 Tax Invoice",
										children: [/* @__PURE__ */ _jsxDEV(Printer, { className: "w-3.5 h-3.5 text-purple-400" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 595,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: "A4 Invoice" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 596,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 590,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("a", {
										href: `https://wa.me/91${activeDisplayBill.customerMobile}?text=Hello%20${encodeURIComponent(activeDisplayBill.customerName)},%20your%20receipt%20for%20${encodeURIComponent(activeDisplayBill.serviceName)}%20at%20${encodeURIComponent(settings.shopName)}%20is%20ready.%20Total:%20Rs.${activeDisplayBill.total}.%20Invoice:%20${activeDisplayBill.invoiceNo}`,
										target: "_blank",
										rel: "noopener noreferrer",
										className: "flex items-center justify-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs py-2 rounded-xl shadow-md transition-colors",
										title: "Send Receipt via WhatsApp",
										children: [/* @__PURE__ */ _jsxDEV(Send, { className: "w-3.5 h-3.5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 606,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: "WhatsApp" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 607,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 599,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 580,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 491,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 490,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 333,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-md space-y-4",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3",
					children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
						className: "font-bold text-base text-white",
						children: "Billing History & Sales Ledger"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 619,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "text-xs text-slate-400",
						children: [
							"Total ",
							bills.length,
							" bills recorded in local database"
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 620,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 618,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-2",
						children: /* @__PURE__ */ _jsxDEV("div", {
							className: "relative",
							children: [/* @__PURE__ */ _jsxDEV(Search, { className: "w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 625,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								placeholder: "Filter by customer, phone, invoice...",
								value: searchTerm,
								onChange: (e) => setSearchTerm(e.target.value),
								className: "bg-slate-950 border border-slate-700 rounded-xl pl-8 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 w-56"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 626,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 624,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 623,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 617,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "overflow-x-auto",
					children: /* @__PURE__ */ _jsxDEV("table", {
						className: "w-full text-left text-xs",
						children: [/* @__PURE__ */ _jsxDEV("thead", {
							className: "bg-slate-950 text-slate-400 border-b border-slate-800 font-mono",
							children: /* @__PURE__ */ _jsxDEV("tr", { children: [
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-2.5 px-3",
									children: "Invoice"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 641,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-2.5 px-3",
									children: "Date & Time"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 642,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-2.5 px-3",
									children: "Customer"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 643,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-2.5 px-3",
									children: "Mobile"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 644,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-2.5 px-3",
									children: "Service"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 645,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-2.5 px-3 text-right",
									children: "Govt"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 646,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-2.5 px-3 text-right",
									children: "Fee"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 647,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-2.5 px-3 text-right",
									children: "Total"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 648,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-2.5 px-3 text-center",
									children: "Status"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 649,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-2.5 px-3 text-right",
									children: "Actions"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 650,
									columnNumber: 17
								}, this)
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 640,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 639,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("tbody", {
							className: "divide-y divide-slate-800/60",
							children: filteredBills.map((b) => /* @__PURE__ */ _jsxDEV("tr", {
								onClick: () => setActivePreviewBill(b),
								className: `cursor-pointer transition-colors ${activePreviewBill?.id === b.id ? "bg-blue-950/30" : "hover:bg-slate-800/40"}`,
								children: [
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-3 px-3 font-mono font-bold text-blue-400",
										children: b.invoiceNo
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 662,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-3 px-3 text-slate-400 font-mono text-[11px]",
										children: b.createdAt
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 663,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-3 px-3 font-semibold text-white",
										children: b.customerName
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 664,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-3 px-3 font-mono text-slate-400",
										children: b.customerMobile
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 665,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-3 px-3 text-slate-300 max-w-[200px] truncate",
										children: b.serviceName
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 666,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-3 px-3 text-right font-mono text-slate-400",
										children: ["₹", b.govtFee]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 667,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-3 px-3 text-right font-mono text-slate-400",
										children: ["₹", b.serviceFee]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 668,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-3 px-3 text-right font-mono font-bold text-emerald-400",
										children: ["₹", b.total]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 669,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-3 px-3 text-center",
										children: /* @__PURE__ */ _jsxDEV("span", {
											className: `px-2 py-0.5 rounded text-[10px] font-bold ${b.status === "Paid" ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30" : "bg-amber-500/20 text-amber-300 border border-amber-500/30"}`,
											children: b.status
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 671,
											columnNumber: 21
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 670,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-3 px-3 text-right space-x-1 whitespace-nowrap",
										children: [/* @__PURE__ */ _jsxDEV("button", {
											onClick: (e) => {
												e.stopPropagation();
												handlePrintThermal(b);
											},
											title: "Print Thermal Slip",
											className: "p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors",
											children: /* @__PURE__ */ _jsxDEV(Printer, { className: "w-3.5 h-3.5" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 685,
												columnNumber: 23
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 680,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("button", {
											onClick: (e) => {
												e.stopPropagation();
												onDeleteBill(b.id);
											},
											title: "Delete Bill",
											className: "p-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 transition-colors",
											children: /* @__PURE__ */ _jsxDEV(Trash2, { className: "w-3.5 h-3.5" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 692,
												columnNumber: 23
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 687,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 679,
										columnNumber: 19
									}, this)
								]
							}, b.id, true, {
								fileName: _jsxFileName,
								lineNumber: 655,
								columnNumber: 17
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 653,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 638,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 637,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 616,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 305,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsaUJBQXlCO0FBQ25ELFNBQ0UsU0FDQSxTQUNBLE1BRUEsUUFDQSxRQUtBLHVCQUlLO0FBQ1AsT0FBTyxZQUFZO0FBRW5CLFNBQVMsNEJBQTRCO0FBQ3JDLFNBQVMseUJBQXlCOzs7QUFTbEMsT0FBTyxNQUFNLG1CQUFtRCxFQUM5RCxPQUNBLFVBQ0EsV0FDQSxtQkFDSTs7Q0FFSixNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBUyxFQUFFO0NBQ25ELE1BQU0sQ0FBQyxnQkFBZ0IscUJBQXFCLFNBQVMsRUFBRTtDQUN2RCxNQUFNLENBQUMsaUJBQWlCLHNCQUFzQixTQUFTLHFCQUFxQixFQUFFLENBQUMsSUFBSTtDQUNuRixNQUFNLENBQUMsVUFBVSxlQUFlLFNBQVMscUJBQXFCLEVBQUUsQ0FBQyxRQUFRO0NBQ3pFLE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBaUIscUJBQXFCLEVBQUUsQ0FBQyxPQUFPO0NBQzlFLE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUFpQixxQkFBcUIsRUFBRSxDQUFDLFVBQVU7Q0FDdkYsTUFBTSxDQUFDLGFBQWEsa0JBQWtCLFNBQW1ELE1BQU07Q0FDL0YsTUFBTSxDQUFDLGVBQWUsb0JBQW9CLFNBQXFDLE1BQU07Q0FDckYsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLEVBQUU7O0NBR3JDLE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFpQixFQUFFOztDQUdyRCxNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBUyxFQUFFO0NBQy9DLE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUFTLEVBQUU7O0NBRy9DLE1BQU0sQ0FBQyxtQkFBbUIsd0JBQXdCLFNBQTBCLElBQUk7Q0FFaEYsTUFBTSxlQUFlLE9BQU8sT0FBTyxLQUFLLE1BQU0sT0FBTyxVQUFVLEtBQUs7O0NBR3BFLE1BQU0sZ0JBQWdCLE9BQU8sSUFBSSxLQUFLLENBQUMsQ0FBQyxZQUFZLEVBQUUsR0FBRyxPQUFPLE1BQU0sU0FBUyxHQUFHLENBQUMsQ0FBQyxTQUFTLEdBQUcsR0FBRzs7Q0FHbkcsTUFBTSx1QkFBdUIsZ0JBQXdCO0VBQ25ELG1CQUFtQixXQUFXO0VBQzlCLE1BQU0sUUFBUSxxQkFBcUIsTUFBSyxNQUFLLEVBQUUsU0FBUyxXQUFXO0VBQ25FLElBQUksT0FBTztHQUNULFlBQVksTUFBTSxRQUFRO0dBQzFCLFdBQVcsTUFBTSxPQUFPO0dBQ3hCLGNBQWMsTUFBTSxVQUFVO0VBQ2hDO0NBQ0Y7O0NBR0EsZ0JBQWdCO0VBQ2QsTUFBTSxZQUFZLGdCQUFnQixTQUFTLE1BQU0sTUFBTSxtQkFBbUIsU0FBUyxRQUFRLEVBQUUsTUFBTSxZQUFZLGFBQWEsbUJBQW1CLGFBQWE7RUFDNUosT0FBTyxVQUFVLFdBQVc7R0FBRSxPQUFPO0dBQUssUUFBUTtFQUFFLENBQUMsQ0FBQyxDQUNuRCxNQUFLLFFBQU8sYUFBYSxHQUFHLENBQUMsQ0FBQyxDQUM5QixZQUFZLGFBQWEsRUFBRSxDQUFDO0NBQ2pDLEdBQUc7RUFBQztFQUFhLFNBQVM7RUFBTyxTQUFTO0VBQVU7Q0FBYSxDQUFDOztDQUdsRSxNQUFNLG9CQUFvQixNQUF1QjtFQUMvQyxFQUFFLGVBQWU7RUFDakIsSUFBSSxDQUFDLGFBQWEsS0FBSyxHQUFHO0dBQ3hCLE1BQU0sNEJBQTRCO0dBQ2xDO0VBQ0Y7RUFFQSxNQUFNLFVBQW9CO0dBQ3hCLElBQUksUUFBUSxLQUFLLElBQUk7R0FDckIsV0FBVztHQUNYLGNBQWMsYUFBYSxLQUFLO0dBQ2hDLGdCQUFnQixlQUFlLEtBQUssS0FBSztHQUN6QyxhQUFhO0dBQ0g7R0FDVixTQUFTLE9BQU8sT0FBTyxLQUFLO0dBQzVCLFlBQVksT0FBTyxVQUFVLEtBQUs7R0FDbEMsT0FBTztHQUNNO0dBQ2IsUUFBUTtHQUNSLFdBQVcsSUFBSSxLQUFLLENBQUMsQ0FBQyxlQUFlLFNBQVM7SUFDNUMsV0FBVztJQUNYLFdBQVc7R0FDYixDQUFDO0dBQ0QsT0FBTyxNQUFNLEtBQUs7RUFDcEI7RUFFQSxVQUFVLE9BQU87RUFDakIscUJBQXFCLE9BQU87O0VBRzVCLGdCQUFnQixFQUFFO0VBQ2xCLGtCQUFrQixFQUFFO0VBQ3BCLFNBQVMsRUFBRTtDQUNiOztDQUdBLE1BQU0sc0JBQXNCLGdCQUEwQjtFQUNwRCxNQUFNLE9BQU8sU0FBUyxpQkFBaUI7RUFDdkMsTUFBTSxhQUFhLE9BQU8sU0FBUztFQUVuQyxNQUFNLFlBQVk7O2dCQUVOLFdBQVc7Ozs7O2lCQUtWLFdBQVc7Ozs7Ozs7Ozs7Ozs7Ozs7O0VBa0J4QixNQUFNLFdBQVc7OzhCQUVTLFNBQVMsU0FBUztlQUNqQyxTQUFTLFFBQVE7ZUFDakIsU0FBUyxRQUFRO29CQUNaLFNBQVMsTUFBTTs7OzZCQUdOLFlBQVksVUFBVTswQkFDekIsWUFBWSxVQUFVOzhCQUNsQixZQUFZLGFBQWE7MkJBQzVCLFlBQVksZUFBZTs7OzhEQUdRLFlBQVksWUFBWTtVQUM1RSxZQUFZLFVBQVUsSUFBSSw0Q0FBNEMsWUFBWSxRQUFRLGNBQWMsR0FBRzt5REFDNUQsWUFBWSxXQUFXOzs7dURBR3pCLFlBQVksTUFBTTs7Ozs2QkFJNUMsWUFBWSxZQUFZLElBQUksWUFBWSxPQUFPO1FBQ3BFLFNBQVMsUUFBUTs7O3NCQUdILFVBQVU7eUNBQ1MsU0FBUyxNQUFNOztVQUU5QyxHQUFHOzs7Ozs7RUFPVCxrQkFBa0IsVUFBVSxXQUFXLFlBQVksYUFBYSxTQUFTO0NBQzNFOztDQUdBLE1BQU0saUJBQWlCLGdCQUEwQjtFQUMvQyxNQUFNLFlBQVk7Ozs7Ozs7Ozs7Ozs7RUFjbEIsTUFBTSxXQUFXOzs7OzBDQUlxQixTQUFTLFNBQVM7dUJBQ3JDLFNBQVMsUUFBUTt1QkFDakIsU0FBUyxRQUFRO3lDQUNDLFNBQVMsTUFBTTtrQkFDdEMsU0FBUyxRQUFRLGVBQWUsU0FBUyxNQUFNLFVBQVUsR0FBRzs7Ozt3RkFJVSxZQUFZLFVBQVU7cURBQ3pELFlBQVksVUFBVTs7Ozs7Ozs7d0NBUW5DLFlBQVksYUFBYTsrREFDRixZQUFZLGVBQWU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7eUJBbUJqRSxZQUFZLFlBQVk7c0JBQzNCLFlBQVksU0FBUztpREFDTSxZQUFZLFFBQVE7aURBQ3BCLFlBQVksV0FBVzttRUFDTCxZQUFZLE1BQU07Ozs7Z0VBSXJCLFlBQVksTUFBTTs7Ozs7OytCQU1uRCxZQUFZLFlBQVksb0JBQW9CLFlBQVksT0FBTzs7Ozs7Ozs7MkNBUW5ELFNBQVMsU0FBUzs7Ozs7O0VBT3pELGtCQUFrQixVQUFVLFdBQVcsWUFBWSxhQUFhLFNBQVM7Q0FDM0U7O0NBR0EsTUFBTSx3QkFBd0I7RUFDNUIsSUFBSSxNQUFNO0VBQ1YsTUFBTSxTQUFRLE1BQUs7R0FDakIsT0FBTyxJQUFJLEVBQUUsVUFBVSxLQUFLLEVBQUUsYUFBYSxLQUFLLEVBQUUsZUFBZSxLQUFLLEVBQUUsWUFBWSxJQUFJLEVBQUUsUUFBUSxHQUFHLEVBQUUsV0FBVyxHQUFHLEVBQUUsTUFBTSxJQUFJLEVBQUUsWUFBWSxLQUFLLEVBQUUsT0FBTyxLQUFLLEVBQUUsVUFBVTtFQUNoTCxDQUFDO0VBQ0QsTUFBTSxPQUFPLElBQUksS0FBSyxDQUFDLEdBQUcsR0FBRyxFQUFFLE1BQU0sV0FBVyxDQUFDO0VBQ2pELE1BQU0sTUFBTSxJQUFJLGdCQUFnQixJQUFJO0VBQ3BDLE1BQU0sSUFBSSxTQUFTLGNBQWMsR0FBRztFQUNwQyxFQUFFLE9BQU87RUFDVCxFQUFFLFdBQVcseUJBQXlCLElBQUksS0FBSyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsTUFBTSxHQUFHLEVBQUUsRUFBRTtFQUM1RSxFQUFFLE1BQU07RUFDUixJQUFJLGdCQUFnQixHQUFHO0NBQ3pCOztDQUdBLE1BQU0sZ0JBQWdCLE1BQU0sUUFBTyxNQUFLO0VBQ3RDLE1BQU0sZ0JBQ0osRUFBRSxhQUFhLFlBQVksQ0FBQyxDQUFDLFNBQVMsV0FBVyxZQUFZLENBQUMsS0FDOUQsRUFBRSxlQUFlLFNBQVMsVUFBVSxLQUNwQyxFQUFFLFVBQVUsWUFBWSxDQUFDLENBQUMsU0FBUyxXQUFXLFlBQVksQ0FBQyxLQUMzRCxFQUFFLFlBQVksWUFBWSxDQUFDLENBQUMsU0FBUyxXQUFXLFlBQVksQ0FBQztFQUMvRCxNQUFNLGNBQWMsQ0FBQyxjQUFjLEVBQUUsVUFBVSxTQUFTLFVBQVU7RUFDbEUsT0FBTyxpQkFBaUI7Q0FDMUIsQ0FBQztDQUVELE1BQU0sb0JBQW9CLHNCQUFzQixNQUFNLFNBQVMsSUFBSSxNQUFNLEtBQUs7Q0FFOUUsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmO0dBRUUsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQW9DO0tBQThCOzs7O2VBQ2hGLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUFoQixDQUNHLFNBQVMsY0FBYSxXQUNuQjs7Ozs7YUFDSDs7Ozs7Y0FDTCx3QkFBQyxLQUFEO0tBQUcsV0FBVTtlQUFnQztJQUUxQzs7OztZQUNBOzs7O2NBRUwsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFDYix3QkFBQyxVQUFEO01BQ0UsU0FBUztNQUNULFdBQVU7TUFDVixPQUFNO2dCQUhSLENBS0Usd0JBQUMsaUJBQUQsRUFBaUIsV0FBVSwyQkFBNEI7Ozs7Z0JBQ3ZELHdCQUFDLFFBQUQsWUFBTSxhQUFnQjs7OztjQUNoQjs7Ozs7O0lBQ0w7Ozs7WUFDRjs7Ozs7O0dBR0wsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUVFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ2Isd0JBQUMsUUFBRDtNQUFNLFVBQVU7TUFBa0IsV0FBVTtnQkFBNUM7T0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFoQixDQUNFLHdCQUFDLFNBQUQsRUFBUyxXQUFVLDJCQUE0Qjs7OzttQkFDL0Msd0JBQUMsUUFBRCxZQUFNLDhCQUFpQzs7OztpQkFDbkM7Ozs7O2tCQUNOLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFoQixDQUF5SCxVQUNoSCxhQUNIOzs7OztnQkFDSDs7Ozs7O09BR0wsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtTQUFPLFdBQVU7bUJBQTBDO1FBQTJCOzs7O2tCQUN0Rix3QkFBQyxTQUFEO1NBQ0UsTUFBSztTQUNMO1NBQ0EsYUFBWTtTQUNaLE9BQU87U0FDUCxXQUFXLE1BQU0sZ0JBQWdCLEVBQUUsT0FBTyxLQUFLO1NBQy9DLFdBQVU7UUFDWDs7OztnQkFDRTs7OztrQkFFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtTQUFPLFdBQVU7bUJBQTBDO1FBQW1DOzs7O2tCQUM5Rix3QkFBQyxTQUFEO1NBQ0UsTUFBSztTQUNMLGFBQVk7U0FDWixPQUFPO1NBQ1AsV0FBVyxNQUFNLGtCQUFrQixFQUFFLE9BQU8sS0FBSztTQUNqRCxXQUFVO1FBQ1g7Ozs7Z0JBQ0U7Ozs7Z0JBQ0Y7Ozs7OztPQUdMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsU0FBRDtTQUFPLFdBQVU7bUJBQXFDO1FBQXFDOzs7O2tCQUMzRix3QkFBQyxVQUFEO1NBQ0UsT0FBTztTQUNQLFdBQVcsTUFBTSxvQkFBb0IsRUFBRSxPQUFPLEtBQUs7U0FDbkQsV0FBVTttQkFFVCxxQkFBcUIsS0FBSyxNQUN6Qix3QkFBQyxVQUFEO1VBQXFCLE9BQU8sRUFBRTtvQkFBOUI7V0FDRyxFQUFFO1dBQUs7V0FBVSxFQUFFO1dBQVE7V0FBVSxFQUFFO1dBQVc7V0FBSyxFQUFFLFVBQVUsRUFBRTtXQUFXO1VBQzNFO1lBRkssRUFBRTs7OztnQkFFUCxDQUNUO1FBQ0s7Ozs7Z0JBQ0w7Ozs7OztPQUdMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7VUFBTyxXQUFVO29CQUE0QjtTQUEwQjs7OzttQkFDdkUsd0JBQUMsU0FBRDtVQUNFLE1BQUs7VUFDTCxLQUFJO1VBQ0osT0FBTztVQUNQLFdBQVcsTUFBTSxXQUFXLE9BQU8sRUFBRSxPQUFPLEtBQUssQ0FBQztVQUNsRCxXQUFVO1NBQ1g7Ozs7aUJBQ0U7Ozs7O1NBRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7VUFBTyxXQUFVO29CQUE0QjtTQUEyQjs7OzttQkFDeEUsd0JBQUMsU0FBRDtVQUNFLE1BQUs7VUFDTCxLQUFJO1VBQ0osT0FBTztVQUNQLFdBQVcsTUFBTSxjQUFjLE9BQU8sRUFBRSxPQUFPLEtBQUssQ0FBQztVQUNyRCxXQUFVO1NBQ1g7Ozs7aUJBQ0U7Ozs7O1NBRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7VUFBTyxXQUFVO29CQUF3QztTQUF3Qjs7OzttQkFDakYsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FBc0osS0FDbEosV0FDQzs7Ozs7aUJBQ0Y7Ozs7O1FBQ0Y7Ozs7OztPQUdMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7U0FBTyxXQUFVO21CQUEwQztRQUFxQjs7OztrQkFDaEYsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQ1g7VUFBQztVQUFRO1VBQVk7U0FBUyxDQUFDLENBQVcsS0FBSyxTQUMvQyx3QkFBQyxVQUFEO1VBQ0UsTUFBSztVQUVMLGVBQWUsZUFBZSxJQUFJO1VBQ2xDLFdBQVcsMERBQ1QsZ0JBQWdCLE9BQ1oscURBQ0E7b0JBR0w7U0FDSyxHQVREOzs7O2dCQVNDLENBQ1Q7UUFDRTs7OztnQkFDRjs7OztrQkFFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtTQUFPLFdBQVU7bUJBQTBDO1FBQXFCOzs7O2tCQUNoRix3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFDWCxDQUFDLFFBQVEsS0FBSyxDQUFDLENBQVcsS0FBSyxPQUMvQix3QkFBQyxVQUFEO1VBQ0UsTUFBSztVQUVMLGVBQWUsaUJBQWlCLE9BQU8sUUFBUSxRQUFRLE1BQU07VUFDN0QsV0FBVywwREFDVCxrQkFBa0IsS0FDZCxPQUFPLFNBQ0wsaURBQ0EsMkNBQ0Y7b0JBR0w7U0FDSyxHQVhEOzs7O2dCQVdDLENBQ1Q7UUFDRTs7OztnQkFDRjs7OztnQkFDRjs7Ozs7O09BR0wsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxTQUFEO1NBQU8sV0FBVTttQkFBNEI7UUFBNkM7Ozs7a0JBQzFGLHdCQUFDLFNBQUQ7U0FDRSxNQUFLO1NBQ0wsYUFBWTtTQUNaLE9BQU87U0FDUCxXQUFXLE1BQU0sU0FBUyxFQUFFLE9BQU8sS0FBSztTQUN4QyxXQUFVO1FBQ1g7Ozs7Z0JBQ0U7Ozs7OztPQUdMLHdCQUFDLFVBQUQ7UUFDRSxNQUFLO1FBQ0wsV0FBVTtrQkFGWixDQUlFLHdCQUFDLFNBQUQsRUFBUyxXQUFVLFVBQVc7Ozs7a0JBQzlCLHdCQUFDLFFBQUQ7U0FBTTtTQUEyQjtTQUFZO1FBQU87Ozs7Z0JBQzlDOzs7Ozs7TUFDSjs7Ozs7O0lBQ0g7Ozs7Y0FHTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNiLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBaEIsQ0FDRSx3QkFBQyxTQUFELEVBQVMsV0FBVSw0QkFBNkI7Ozs7bUJBQ2hELHdCQUFDLFFBQUQsWUFBTSxnQ0FBbUM7Ozs7aUJBQ3JDOzs7OztrQkFDTix3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBaEIsQ0FDRyxTQUFTLGNBQWEsWUFDbkI7Ozs7O2dCQUNIOzs7Ozs7T0FHSixvQkFDQyx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUVFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmO1dBQ0Usd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQStDLFNBQVM7V0FBYzs7Ozs7V0FDckYsd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQThCLFNBQVM7V0FBYTs7Ozs7V0FDbkUsd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQThCLFNBQVM7V0FBYTs7Ozs7V0FDbkUsd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQWYsQ0FBdUMsU0FBTSxTQUFTLEtBQVc7Ozs7OztVQUM5RDs7Ozs7O1NBR0wsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWY7V0FDRSx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZixDQUNFLHdCQUFDLFFBQUQsWUFBTSxXQUFjOzs7O3NCQUNwQix3QkFBQyxRQUFEO2FBQU0sV0FBVTt1QkFBYSxrQkFBa0I7WUFBZ0I7Ozs7b0JBQzVEOzs7Ozs7V0FDTCx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZixDQUNFLHdCQUFDLFFBQUQsWUFBTSxRQUFXOzs7O3NCQUNqQix3QkFBQyxRQUFELFlBQU8sa0JBQWtCLFVBQWdCOzs7O29CQUN0Qzs7Ozs7O1dBQ0wsd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQWYsQ0FDRSx3QkFBQyxRQUFELFlBQU0sWUFBZTs7OztzQkFDckIsd0JBQUMsUUFBRDthQUFNLFdBQVU7dUJBQWEsa0JBQWtCO1lBQW1COzs7O29CQUMvRDs7Ozs7O1dBQ0wsd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQWYsQ0FDRSx3QkFBQyxRQUFELFlBQU0sU0FBWTs7OztzQkFDbEIsd0JBQUMsUUFBRCxZQUFPLGtCQUFrQixlQUFxQjs7OztvQkFDM0M7Ozs7OztVQUNGOzs7Ozs7U0FHTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZjtXQUNFLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUFhLGtCQUFrQjtXQUFpQjs7Ozs7V0FDOUQsa0JBQWtCLFVBQVUsS0FDM0Isd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQWYsQ0FDRSx3QkFBQyxRQUFELFlBQU0sbUJBQXNCOzs7O3NCQUM1Qix3QkFBQyxRQUFELGFBQU0sS0FBRSxrQkFBa0IsT0FBYzs7OztvQkFDckM7Ozs7OztXQUVQLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUFmLENBQ0Usd0JBQUMsUUFBRCxZQUFNLGtCQUFxQjs7OztzQkFDM0Isd0JBQUMsUUFBRCxhQUFNLEtBQUUsa0JBQWtCLFVBQWlCOzs7O29CQUN4Qzs7Ozs7O1dBQ0wsd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQWYsQ0FDRSx3QkFBQyxRQUFELFlBQU0sYUFBZ0I7Ozs7c0JBQ3RCLHdCQUFDLFFBQUQ7YUFBTTthQUFFLGtCQUFrQjthQUFNO1lBQVM7Ozs7b0JBQ3RDOzs7Ozs7VUFDRjs7Ozs7O1NBR0wsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWY7V0FDRSx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZjthQUEyQzthQUMzQix3QkFBQyxLQUFELFlBQUksa0JBQWtCLFlBQWU7Ozs7O2FBQUM7YUFBRyxrQkFBa0I7YUFBTztZQUM3RTs7Ozs7O1dBRUosU0FBUyxTQUNSLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUFmO2FBQ0Usd0JBQUMsUUFBRDtjQUFNLFdBQVU7d0JBQWtDO2FBQXlDOzs7OzthQUMxRixhQUFhLHdCQUFDLE9BQUQ7Y0FBSyxLQUFLO2NBQVcsS0FBSTtjQUFTLFdBQVU7YUFBYTs7Ozs7YUFDdkUsd0JBQUMsUUFBRDtjQUFNLFdBQVU7d0JBQXVELFNBQVM7YUFBWTs7Ozs7WUFDekY7Ozs7OztXQUdQLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUFmO2FBQWlEO2FBQ2xCLHdCQUFDLE1BQUQsQ0FBSzs7Ozs7YUFBQztZQUVoQzs7Ozs7O1VBQ0Y7Ozs7OztRQUNGOzs7OztrQkFFTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBeUM7T0FFbkQ7Ozs7O09BSU4scUJBQ0Msd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxVQUFEO1VBQ0UsZUFBZSxtQkFBbUIsaUJBQWlCO1VBQ25ELFdBQVU7VUFDVixPQUFNO29CQUhSLENBS0Usd0JBQUMsU0FBRCxFQUFTLFdBQVUsY0FBZTs7OztvQkFDbEMsd0JBQUMsUUFBRCxZQUFNLFVBQWE7Ozs7a0JBQ2I7Ozs7OztTQUVSLHdCQUFDLFVBQUQ7VUFDRSxlQUFlLGNBQWMsaUJBQWlCO1VBQzlDLFdBQVU7VUFDVixPQUFNO29CQUhSLENBS0Usd0JBQUMsU0FBRCxFQUFTLFdBQVUsOEJBQStCOzs7O29CQUNsRCx3QkFBQyxRQUFELFlBQU0sYUFBZ0I7Ozs7a0JBQ2hCOzs7Ozs7U0FFUix3QkFBQyxLQUFEO1VBQ0UsTUFBTSxtQkFBbUIsa0JBQWtCLGVBQWUsZ0JBQWdCLG1CQUFtQixrQkFBa0IsWUFBWSxFQUFFLDZCQUE2QixtQkFBbUIsa0JBQWtCLFdBQVcsRUFBRSxVQUFVLG1CQUFtQixTQUFTLFFBQVEsRUFBRSwrQkFBK0Isa0JBQWtCLE1BQU0saUJBQWlCLGtCQUFrQjtVQUN0VixRQUFPO1VBQ1AsS0FBSTtVQUNKLFdBQVU7VUFDVixPQUFNO29CQUxSLENBT0Usd0JBQUMsTUFBRCxFQUFNLFdBQVUsY0FBZTs7OztvQkFDL0Isd0JBQUMsUUFBRCxZQUFNLFdBQWM7Ozs7a0JBQ25COzs7Ozs7UUFDQTs7Ozs7O01BRUo7Ozs7OztJQUNGOzs7O1lBQ0Y7Ozs7OztHQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUFpQztLQUFrQzs7OztlQUNqRix3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBYjtPQUFzQztPQUFPLE1BQU07T0FBTztNQUFvQzs7Ozs7YUFDM0Y7Ozs7ZUFFTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFDYix3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFFBQUQsRUFBUSxXQUFVLHdFQUF5RTs7OztpQkFDM0Ysd0JBQUMsU0FBRDtRQUNFLE1BQUs7UUFDTCxhQUFZO1FBQ1osT0FBTztRQUNQLFdBQVcsTUFBTSxjQUFjLEVBQUUsT0FBTyxLQUFLO1FBQzdDLFdBQVU7T0FDWDs7OztlQUNFOzs7Ozs7S0FDRjs7OzthQUNGOzs7OztjQUVMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ2Isd0JBQUMsU0FBRDtNQUFPLFdBQVU7Z0JBQWpCLENBQ0Usd0JBQUMsU0FBRDtPQUFPLFdBQVU7aUJBQ2Ysd0JBQUMsTUFBRDtRQUNFLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUFjO1FBQVc7Ozs7O1FBQ3ZDLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUFjO1FBQWU7Ozs7O1FBQzNDLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUFjO1FBQVk7Ozs7O1FBQ3hDLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUFjO1FBQVU7Ozs7O1FBQ3RDLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUFjO1FBQVc7Ozs7O1FBQ3ZDLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUF5QjtRQUFROzs7OztRQUMvQyx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBeUI7UUFBTzs7Ozs7UUFDOUMsd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQXlCO1FBQVM7Ozs7O1FBQ2hELHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUEwQjtRQUFVOzs7OztRQUNsRCx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBeUI7UUFBVzs7Ozs7T0FDaEQ7Ozs7O01BQ0M7Ozs7Z0JBQ1Asd0JBQUMsU0FBRDtPQUFPLFdBQVU7aUJBQ2QsY0FBYyxLQUFLLE1BQ2xCLHdCQUFDLE1BQUQ7UUFFRSxlQUFlLHFCQUFxQixDQUFDO1FBQ3JDLFdBQVcsb0NBQ1QsbUJBQW1CLE9BQU8sRUFBRSxLQUFLLG1CQUFtQjtrQkFKeEQ7U0FPRSx3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFBK0MsRUFBRTtTQUFjOzs7OztTQUM3RSx3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFBa0QsRUFBRTtTQUFjOzs7OztTQUNoRix3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFBc0MsRUFBRTtTQUFpQjs7Ozs7U0FDdkUsd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQXNDLEVBQUU7U0FBbUI7Ozs7O1NBQ3pFLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUFtRCxFQUFFO1NBQWdCOzs7OztTQUNuRix3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFBZCxDQUE4RCxLQUFFLEVBQUUsT0FBWTs7Ozs7O1NBQzlFLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUFkLENBQThELEtBQUUsRUFBRSxVQUFlOzs7Ozs7U0FDakYsd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQWQsQ0FBMEUsS0FBRSxFQUFFLEtBQVU7Ozs7OztTQUN4Rix3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFDWix3QkFBQyxRQUFEO1dBQU0sV0FBVyw2Q0FDZixFQUFFLFdBQVcsU0FDVCxvRUFDQTtxQkFFSCxFQUFFO1VBQ0M7Ozs7O1NBQ0o7Ozs7O1NBQ0osd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQWQsQ0FDRSx3QkFBQyxVQUFEO1dBQ0UsVUFBVSxNQUFNO1lBQUUsRUFBRSxnQkFBZ0I7WUFBRyxtQkFBbUIsQ0FBQztXQUFHO1dBQzlELE9BQU07V0FDTixXQUFVO3FCQUVWLHdCQUFDLFNBQUQsRUFBUyxXQUFVLGNBQWU7Ozs7O1VBQzVCOzs7O29CQUNSLHdCQUFDLFVBQUQ7V0FDRSxVQUFVLE1BQU07WUFBRSxFQUFFLGdCQUFnQjtZQUFHLGFBQWEsRUFBRSxFQUFFO1dBQUc7V0FDM0QsT0FBTTtXQUNOLFdBQVU7cUJBRVYsd0JBQUMsUUFBRCxFQUFRLFdBQVUsY0FBZTs7Ozs7VUFDM0I7Ozs7a0JBQ047Ozs7OztRQUNGO1VBdkNHLEVBQUU7Ozs7Y0F1Q0wsQ0FDTDtNQUNJOzs7O2NBQ0Y7Ozs7OztJQUNKOzs7O1lBQ0Y7Ozs7OztFQUNGOzs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJCaWxsaW5nRGVza1ZpZXcudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0LCB1c2VSZWYgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBcbiAgUmVjZWlwdCwgXG4gIFByaW50ZXIsIFxuICBTZW5kLCBcbiAgUGx1cywgXG4gIFNlYXJjaCwgXG4gIFRyYXNoMiwgXG4gIFFyQ29kZSwgXG4gIEluZGlhblJ1cGVlLCBcbiAgQ2hlY2tDaXJjbGUsIFxuICBDbG9jaywgXG4gIEZpbGVTcHJlYWRzaGVldCwgXG4gIEhlbHBDaXJjbGUsXG4gIENyZWRpdENhcmQsXG4gIFNtYXJ0cGhvbmVcbn0gZnJvbSAnbHVjaWRlLXJlYWN0JztcbmltcG9ydCBRUkNvZGUgZnJvbSAncXJjb2RlJztcbmltcG9ydCB7IEJpbGxJdGVtLCBTaG9wU2V0dGluZ3MgfSBmcm9tICcuLi90eXBlcyc7XG5pbXBvcnQgeyBDT01NT05fU0hPUF9TRVJWSUNFUyB9IGZyb20gJy4uL2RhdGEvcG9ydGFsRGF0YSc7XG5pbXBvcnQgeyBwcmludEh0bWxEb2N1bWVudCB9IGZyb20gJy4uL3V0aWxzL3ByaW50ZXInO1xuXG5pbnRlcmZhY2UgQmlsbGluZ0Rlc2tWaWV3UHJvcHMge1xuICBiaWxsczogQmlsbEl0ZW1bXTtcbiAgc2V0dGluZ3M6IFNob3BTZXR0aW5ncztcbiAgb25BZGRCaWxsOiAoYmlsbDogQmlsbEl0ZW0pID0+IHZvaWQ7XG4gIG9uRGVsZXRlQmlsbDogKGlkOiBzdHJpbmcpID0+IHZvaWQ7XG59XG5cbmV4cG9ydCBjb25zdCBCaWxsaW5nRGVza1ZpZXc6IFJlYWN0LkZDPEJpbGxpbmdEZXNrVmlld1Byb3BzPiA9ICh7XG4gIGJpbGxzLFxuICBzZXR0aW5ncyxcbiAgb25BZGRCaWxsLFxuICBvbkRlbGV0ZUJpbGxcbn0pID0+IHtcbiAgLy8gTmV3IEJpbGwgRm9ybSBTdGF0ZVxuICBjb25zdCBbY3VzdG9tZXJOYW1lLCBzZXRDdXN0b21lck5hbWVdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbY3VzdG9tZXJNb2JpbGUsIHNldEN1c3RvbWVyTW9iaWxlXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW3NlbGVjdGVkU2VydmljZSwgc2V0U2VsZWN0ZWRTZXJ2aWNlXSA9IHVzZVN0YXRlKENPTU1PTl9TSE9QX1NFUlZJQ0VTWzBdLm5hbWUpO1xuICBjb25zdCBbY2F0ZWdvcnksIHNldENhdGVnb3J5XSA9IHVzZVN0YXRlKENPTU1PTl9TSE9QX1NFUlZJQ0VTWzBdLmNhdGVnb3J5KTtcbiAgY29uc3QgW2dvdnRGZWUsIHNldEdvdnRGZWVdID0gdXNlU3RhdGU8bnVtYmVyPihDT01NT05fU0hPUF9TRVJWSUNFU1swXS5nb3Z0RmVlKTtcbiAgY29uc3QgW3NlcnZpY2VGZWUsIHNldFNlcnZpY2VGZWVdID0gdXNlU3RhdGU8bnVtYmVyPihDT01NT05fU0hPUF9TRVJWSUNFU1swXS5zZXJ2aWNlRmVlKTtcbiAgY29uc3QgW3BheW1lbnRNb2RlLCBzZXRQYXltZW50TW9kZV0gPSB1c2VTdGF0ZTwnQ2FzaCcgfCAnVVBJIC8gUVInIHwgJ0NhcmQnIHwgJ1BlbmRpbmcnPignQ2FzaCcpO1xuICBjb25zdCBbcGF5bWVudFN0YXR1cywgc2V0UGF5bWVudFN0YXR1c10gPSB1c2VTdGF0ZTwnUGFpZCcgfCAnUGVuZGluZycgfCAnRHVlJz4oJ1BhaWQnKTtcbiAgY29uc3QgW25vdGVzLCBzZXROb3Rlc10gPSB1c2VTdGF0ZSgnJyk7XG5cbiAgLy8gR2VuZXJhdGVkIFFSIENvZGUgRGF0YSBVUkxcbiAgY29uc3QgW3FyRGF0YVVybCwgc2V0UXJEYXRhVXJsXSA9IHVzZVN0YXRlPHN0cmluZz4oJycpO1xuXG4gIC8vIEZpbHRlciAmIFNlYXJjaFxuICBjb25zdCBbc2VhcmNoVGVybSwgc2V0U2VhcmNoVGVybV0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtkYXRlRmlsdGVyLCBzZXREYXRlRmlsdGVyXSA9IHVzZVN0YXRlKCcnKTtcblxuICAvLyBBY3RpdmUgYmlsbCBmb3IgcHJldmlld1xuICBjb25zdCBbYWN0aXZlUHJldmlld0JpbGwsIHNldEFjdGl2ZVByZXZpZXdCaWxsXSA9IHVzZVN0YXRlPEJpbGxJdGVtIHwgbnVsbD4obnVsbCk7XG5cbiAgY29uc3QgdG90YWxBbW91bnQgPSAoTnVtYmVyKGdvdnRGZWUpIHx8IDApICsgKE51bWJlcihzZXJ2aWNlRmVlKSB8fCAwKTtcblxuICAvLyBBdXRvLWdlbmVyYXRlIGludm9pY2UgbnVtYmVyXG4gIGNvbnN0IG5leHRJbnZvaWNlTm8gPSBgTU9TLSR7bmV3IERhdGUoKS5nZXRGdWxsWWVhcigpfS0ke1N0cmluZyhiaWxscy5sZW5ndGggKyAxMDEpLnBhZFN0YXJ0KDQsICcwJyl9YDtcblxuICAvLyBXaGVuIHNlbGVjdGVkIHNlcnZpY2UgY2hhbmdlcywgcG9wdWxhdGUgZGVmYXVsdHNcbiAgY29uc3QgaGFuZGxlU2VydmljZVNlbGVjdCA9IChzZXJ2aWNlTmFtZTogc3RyaW5nKSA9PiB7XG4gICAgc2V0U2VsZWN0ZWRTZXJ2aWNlKHNlcnZpY2VOYW1lKTtcbiAgICBjb25zdCBmb3VuZCA9IENPTU1PTl9TSE9QX1NFUlZJQ0VTLmZpbmQocyA9PiBzLm5hbWUgPT09IHNlcnZpY2VOYW1lKTtcbiAgICBpZiAoZm91bmQpIHtcbiAgICAgIHNldENhdGVnb3J5KGZvdW5kLmNhdGVnb3J5KTtcbiAgICAgIHNldEdvdnRGZWUoZm91bmQuZ292dEZlZSk7XG4gICAgICBzZXRTZXJ2aWNlRmVlKGZvdW5kLnNlcnZpY2VGZWUpO1xuICAgIH1cbiAgfTtcblxuICAvLyBHZW5lcmF0ZSBVUEkgUVIgQ29kZSB3aGVuZXZlciB0b3RhbCBvciBVUEkgSUQgY2hhbmdlc1xuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IHVwaVN0cmluZyA9IGB1cGk6Ly9wYXk/cGE9JHtzZXR0aW5ncy51cGlJZH0mcG49JHtlbmNvZGVVUklDb21wb25lbnQoc2V0dGluZ3Muc2hvcE5hbWUpfSZhbT0ke3RvdGFsQW1vdW50fSZjdT1JTlImdG49JHtlbmNvZGVVUklDb21wb25lbnQobmV4dEludm9pY2VObyl9YDtcbiAgICBRUkNvZGUudG9EYXRhVVJMKHVwaVN0cmluZywgeyB3aWR0aDogMTgwLCBtYXJnaW46IDEgfSlcbiAgICAgIC50aGVuKHVybCA9PiBzZXRRckRhdGFVcmwodXJsKSlcbiAgICAgIC5jYXRjaCgoKSA9PiBzZXRRckRhdGFVcmwoJycpKTtcbiAgfSwgW3RvdGFsQW1vdW50LCBzZXR0aW5ncy51cGlJZCwgc2V0dGluZ3Muc2hvcE5hbWUsIG5leHRJbnZvaWNlTm9dKTtcblxuICAvLyBIYW5kbGUgRm9ybSBTdWJtaXNzaW9uXG4gIGNvbnN0IGhhbmRsZUNyZWF0ZUJpbGwgPSAoZTogUmVhY3QuRm9ybUV2ZW50KSA9PiB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgIGlmICghY3VzdG9tZXJOYW1lLnRyaW0oKSkge1xuICAgICAgYWxlcnQoJ1BsZWFzZSBlbnRlciBDdXN0b21lciBOYW1lJyk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgY29uc3QgbmV3QmlsbDogQmlsbEl0ZW0gPSB7XG4gICAgICBpZDogYGJpbGwtJHtEYXRlLm5vdygpfWAsXG4gICAgICBpbnZvaWNlTm86IG5leHRJbnZvaWNlTm8sXG4gICAgICBjdXN0b21lck5hbWU6IGN1c3RvbWVyTmFtZS50cmltKCksXG4gICAgICBjdXN0b21lck1vYmlsZTogY3VzdG9tZXJNb2JpbGUudHJpbSgpIHx8ICdOL0EnLFxuICAgICAgc2VydmljZU5hbWU6IHNlbGVjdGVkU2VydmljZSxcbiAgICAgIGNhdGVnb3J5OiBjYXRlZ29yeSxcbiAgICAgIGdvdnRGZWU6IE51bWJlcihnb3Z0RmVlKSB8fCAwLFxuICAgICAgc2VydmljZUZlZTogTnVtYmVyKHNlcnZpY2VGZWUpIHx8IDAsXG4gICAgICB0b3RhbDogdG90YWxBbW91bnQsXG4gICAgICBwYXltZW50TW9kZTogcGF5bWVudE1vZGUsXG4gICAgICBzdGF0dXM6IHBheW1lbnRTdGF0dXMsXG4gICAgICBjcmVhdGVkQXQ6IG5ldyBEYXRlKCkudG9Mb2NhbGVTdHJpbmcoJ2VuLUlOJywge1xuICAgICAgICBkYXRlU3R5bGU6ICdtZWRpdW0nLFxuICAgICAgICB0aW1lU3R5bGU6ICdzaG9ydCdcbiAgICAgIH0pLFxuICAgICAgbm90ZXM6IG5vdGVzLnRyaW0oKVxuICAgIH07XG5cbiAgICBvbkFkZEJpbGwobmV3QmlsbCk7XG4gICAgc2V0QWN0aXZlUHJldmlld0JpbGwobmV3QmlsbCk7XG5cbiAgICAvLyBSZXNldCBjdXN0b21lciBuYW1lICYgbW9iaWxlIGZvciBuZXh0IHRyYW5zYWN0aW9uXG4gICAgc2V0Q3VzdG9tZXJOYW1lKCcnKTtcbiAgICBzZXRDdXN0b21lck1vYmlsZSgnJyk7XG4gICAgc2V0Tm90ZXMoJycpO1xuICB9O1xuXG4gIC8vIERpcmVjdCBUaGVybWFsIFBPUyBQcmludCAoNThtbSBvciA4MG1tIGZvcm1hdClcbiAgY29uc3QgaGFuZGxlUHJpbnRUaGVybWFsID0gKGJpbGxUb1ByaW50OiBCaWxsSXRlbSkgPT4ge1xuICAgIGNvbnN0IGlzODAgPSBzZXR0aW5ncy50aGVybWFsV2lkdGggPT09ICc4MG1tJztcbiAgICBjb25zdCBwYXBlcldpZHRoID0gaXM4MCA/ICc3Nm1tJyA6ICc1Nm1tJztcblxuICAgIGNvbnN0IHBhZ2VTdHlsZSA9IGBcbiAgICAgIEBwYWdlIHtcbiAgICAgICAgc2l6ZTogJHtwYXBlcldpZHRofSBhdXRvO1xuICAgICAgICBtYXJnaW46IDA7XG4gICAgICB9XG4gICAgICBib2R5IHtcbiAgICAgICAgZm9udC1mYW1pbHk6ICdDb3VyaWVyIE5ldycsIENvdXJpZXIsIG1vbm9zcGFjZTtcbiAgICAgICAgd2lkdGg6ICR7cGFwZXJXaWR0aH07XG4gICAgICAgIG1hcmdpbjogMCBhdXRvO1xuICAgICAgICBwYWRkaW5nOiA2cHg7XG4gICAgICAgIGZvbnQtc2l6ZTogMTJweDtcbiAgICAgICAgY29sb3I6ICMwMDA7XG4gICAgICAgIGxpbmUtaGVpZ2h0OiAxLjM7XG4gICAgICB9XG4gICAgICAuY2VudGVyIHsgdGV4dC1hbGlnbjogY2VudGVyOyB9XG4gICAgICAucmlnaHQgeyB0ZXh0LWFsaWduOiByaWdodDsgfVxuICAgICAgLmJvbGQgeyBmb250LXdlaWdodDogYm9sZDsgfVxuICAgICAgLmRpdmlkZXIgeyBib3JkZXItdG9wOiAxcHggZGFzaGVkICMwMDA7IG1hcmdpbjogNnB4IDA7IH1cbiAgICAgIC5oZWFkZXIgeyBmb250LXNpemU6IDE1cHg7IGZvbnQtd2VpZ2h0OiBib2xkOyB9XG4gICAgICAucXIgeyB0ZXh0LWFsaWduOiBjZW50ZXI7IG1hcmdpbjogOHB4IDA7IH1cbiAgICAgIC5xciBpbWcgeyB3aWR0aDogMTIwcHg7IGhlaWdodDogMTIwcHg7IH1cbiAgICAgIHRhYmxlIHsgd2lkdGg6IDEwMCU7IGJvcmRlci1jb2xsYXBzZTogY29sbGFwc2U7IGZvbnQtc2l6ZTogMTJweDsgfVxuICAgICAgdGQgeyBwYWRkaW5nOiAycHggMDsgfVxuICAgIGA7XG5cbiAgICBjb25zdCBodG1sQm9keSA9IGBcbiAgICAgIDxkaXYgY2xhc3M9XCJjZW50ZXJcIj5cbiAgICAgICAgPGRpdiBjbGFzcz1cImhlYWRlclwiPiR7c2V0dGluZ3Muc2hvcE5hbWV9PC9kaXY+XG4gICAgICAgIDxkaXY+JHtzZXR0aW5ncy50YWdsaW5lfTwvZGl2PlxuICAgICAgICA8ZGl2PiR7c2V0dGluZ3MuYWRkcmVzc308L2Rpdj5cbiAgICAgICAgPGRpdj5Nb2I6ICR7c2V0dGluZ3MucGhvbmV9PC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxkaXYgY2xhc3M9XCJkaXZpZGVyXCI+PC9kaXY+XG4gICAgICA8ZGl2PjxiPkludm9pY2U6PC9iPiAke2JpbGxUb1ByaW50Lmludm9pY2VOb308L2Rpdj5cbiAgICAgIDxkaXY+PGI+RGF0ZTo8L2I+ICR7YmlsbFRvUHJpbnQuY3JlYXRlZEF0fTwvZGl2PlxuICAgICAgPGRpdj48Yj5DdXN0b21lcjo8L2I+ICR7YmlsbFRvUHJpbnQuY3VzdG9tZXJOYW1lfTwvZGl2PlxuICAgICAgPGRpdj48Yj5QaG9uZTo8L2I+ICR7YmlsbFRvUHJpbnQuY3VzdG9tZXJNb2JpbGV9PC9kaXY+XG4gICAgICA8ZGl2IGNsYXNzPVwiZGl2aWRlclwiPjwvZGl2PlxuICAgICAgPHRhYmxlPlxuICAgICAgICA8dHI+PHRkIGNsYXNzPVwiYm9sZFwiPlNlcnZpY2U6PC90ZD48dGQgY2xhc3M9XCJyaWdodFwiPiR7YmlsbFRvUHJpbnQuc2VydmljZU5hbWV9PC90ZD48L3RyPlxuICAgICAgICAke2JpbGxUb1ByaW50LmdvdnRGZWUgPiAwID8gYDx0cj48dGQ+R292dCBGZWU6PC90ZD48dGQgY2xhc3M9XCJyaWdodFwiPuKCuSR7YmlsbFRvUHJpbnQuZ292dEZlZX08L3RkPjwvdHI+YCA6ICcnfVxuICAgICAgICA8dHI+PHRkPlNlcnZpY2UgQ2hhcmdlOjwvdGQ+PHRkIGNsYXNzPVwicmlnaHRcIj7igrkke2JpbGxUb1ByaW50LnNlcnZpY2VGZWV9PC90ZD48L3RyPlxuICAgICAgICA8dHIgc3R5bGU9XCJib3JkZXItdG9wOjFweCBzb2xpZCAjMDAwOyBmb250LXdlaWdodDpib2xkO1wiPlxuICAgICAgICAgIDx0ZCBzdHlsZT1cImZvbnQtc2l6ZToxNHB4O1wiPlRPVEFMOjwvdGQ+XG4gICAgICAgICAgPHRkIGNsYXNzPVwicmlnaHRcIiBzdHlsZT1cImZvbnQtc2l6ZToxNHB4O1wiPuKCuSR7YmlsbFRvUHJpbnQudG90YWx9PC90ZD5cbiAgICAgICAgPC90cj5cbiAgICAgIDwvdGFibGU+XG4gICAgICA8ZGl2IGNsYXNzPVwiZGl2aWRlclwiPjwvZGl2PlxuICAgICAgPGRpdj48Yj5QYXltZW50OjwvYj4gJHtiaWxsVG9QcmludC5wYXltZW50TW9kZX0gKCR7YmlsbFRvUHJpbnQuc3RhdHVzfSk8L2Rpdj5cbiAgICAgICR7c2V0dGluZ3MudXBpSWQgPyBgXG4gICAgICAgIDxkaXYgY2xhc3M9XCJxclwiPlxuICAgICAgICAgIDxkaXY+U2NhbiBVUEkgdG8gUGF5OjwvZGl2PlxuICAgICAgICAgIDxpbWcgc3JjPVwiJHtxckRhdGFVcmx9XCIgLz5cbiAgICAgICAgICA8ZGl2IHN0eWxlPVwiZm9udC1zaXplOjEwcHg7XCI+JHtzZXR0aW5ncy51cGlJZH08L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICBgIDogJyd9XG4gICAgICA8ZGl2IGNsYXNzPVwiY2VudGVyXCIgc3R5bGU9XCJmb250LXNpemU6MTFweDsgbWFyZ2luLXRvcDo4cHg7XCI+XG4gICAgICAgIDxkaXY+KioqIFRoYW5rIFlvdSBWaXNpdCBBZ2FpbiAqKio8L2Rpdj5cbiAgICAgICAgPGRpdj5Db21wdXRlcml6ZWQgT25saW5lIFNlcnZpY2UgUmVjZWlwdDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgYDtcblxuICAgIHByaW50SHRtbERvY3VtZW50KGh0bWxCb2R5LCBgUmVjZWlwdF8ke2JpbGxUb1ByaW50Lmludm9pY2VOb31gLCBwYWdlU3R5bGUpO1xuICB9O1xuXG4gIC8vIERpcmVjdCBBNCBPZmZpY2lhbCBJbnZvaWNlIFByaW50XG4gIGNvbnN0IGhhbmRsZVByaW50QTQgPSAoYmlsbFRvUHJpbnQ6IEJpbGxJdGVtKSA9PiB7XG4gICAgY29uc3QgcGFnZVN0eWxlID0gYFxuICAgICAgQHBhZ2UgeyBzaXplOiBBNDsgbWFyZ2luOiAxNW1tOyB9XG4gICAgICBib2R5IHsgZm9udC1mYW1pbHk6IHNhbnMtc2VyaWY7IG1hcmdpbjogMDsgcGFkZGluZzogMjBweDsgY29sb3I6ICMxZTI5M2I7IGZvbnQtc2l6ZTogMTRweDsgfVxuICAgICAgLmhlYWRlci10YWJsZSB7IHdpZHRoOiAxMDAlOyBib3JkZXItYm90dG9tOiAycHggc29saWQgIzI1NjNlYjsgcGFkZGluZy1ib3R0b206IDE1cHg7IG1hcmdpbi1ib3R0b206IDIwcHg7IH1cbiAgICAgIC5zaG9wLXRpdGxlIHsgZm9udC1zaXplOiAyNHB4OyBmb250LXdlaWdodDogODAwOyBjb2xvcjogIzFlNDBhZjsgfVxuICAgICAgLmluZm8tYm94IHsgYmFja2dyb3VuZDogI2Y4ZmFmYzsgYm9yZGVyOiAxcHggc29saWQgI2UyZThmMDsgYm9yZGVyLXJhZGl1czogOHB4OyBwYWRkaW5nOiAxMnB4OyBtYXJnaW4tYm90dG9tOiAyMHB4OyB9XG4gICAgICB0YWJsZS5pdGVtcyB7IHdpZHRoOiAxMDAlOyBib3JkZXItY29sbGFwc2U6IGNvbGxhcHNlOyBtYXJnaW4tdG9wOiAxNXB4OyB9XG4gICAgICB0YWJsZS5pdGVtcyB0aCB7IGJhY2tncm91bmQ6ICMyNTYzZWI7IGNvbG9yOiAjZmZmOyB0ZXh0LWFsaWduOiBsZWZ0OyBwYWRkaW5nOiAxMHB4OyBmb250LXNpemU6IDEzcHg7IH1cbiAgICAgIHRhYmxlLml0ZW1zIHRkIHsgcGFkZGluZzogMTBweDsgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNlMmU4ZjA7IH1cbiAgICAgIC50b3RhbC1yb3cgeyBmb250LXNpemU6IDE2cHg7IGZvbnQtd2VpZ2h0OiBib2xkOyBiYWNrZ3JvdW5kOiAjZWZmNmZmOyB9XG4gICAgICAuZm9vdGVyIHsgbWFyZ2luLXRvcDogNDBweDsgZGlzcGxheTogZmxleDsganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuOyBhbGlnbi1pdGVtczogZmxleC1lbmQ7IH1cbiAgICAgIC5zaWduIHsgYm9yZGVyLXRvcDogMXB4IHNvbGlkICM5NGEzYjg7IHdpZHRoOiAxODBweDsgdGV4dC1hbGlnbjogY2VudGVyOyBwYWRkaW5nLXRvcDogNXB4OyBmb250LXNpemU6IDEycHg7IH1cbiAgICBgO1xuXG4gICAgY29uc3QgaHRtbEJvZHkgPSBgXG4gICAgICAgICAgPHRhYmxlIGNsYXNzPVwiaGVhZGVyLXRhYmxlXCI+XG4gICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgIDx0ZD5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwic2hvcC10aXRsZVwiPiR7c2V0dGluZ3Muc2hvcE5hbWV9PC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdj4ke3NldHRpbmdzLnRhZ2xpbmV9PC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdj4ke3NldHRpbmdzLmFkZHJlc3N9PC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdj5QaG9uZSAvIFdoYXRzQXBwOiAke3NldHRpbmdzLnBob25lfTwvZGl2PlxuICAgICAgICAgICAgICAgICR7c2V0dGluZ3MuZ3N0Tm8gPyBgPGRpdj5HU1RJTjogJHtzZXR0aW5ncy5nc3ROb308L2Rpdj5gIDogJyd9XG4gICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgIDx0ZCBzdHlsZT1cInRleHQtYWxpZ246cmlnaHQ7XCI+XG4gICAgICAgICAgICAgICAgPGgyIHN0eWxlPVwibWFyZ2luOjA7IGNvbG9yOiMxZTQwYWY7XCI+U0VSVklDRSBJTlZPSUNFPC9oMj5cbiAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPVwiZm9udC1mYW1pbHk6bW9ub3NwYWNlOyBmb250LXNpemU6MTZweDsgZm9udC13ZWlnaHQ6Ym9sZDtcIj4ke2JpbGxUb1ByaW50Lmludm9pY2VOb308L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPVwibWFyZ2luLXRvcDo0cHg7XCI+RGF0ZTogJHtiaWxsVG9QcmludC5jcmVhdGVkQXR9PC9kaXY+XG4gICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICA8L3RyPlxuICAgICAgICAgIDwvdGFibGU+XG5cbiAgICAgICAgICA8ZGl2IGNsYXNzPVwiaW5mby1ib3hcIj5cbiAgICAgICAgICAgIDx0YWJsZSBzdHlsZT1cIndpZHRoOjEwMCU7XCI+XG4gICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICA8dGQ+PGI+QmlsbGVkIFRvOjwvYj4gJHtiaWxsVG9QcmludC5jdXN0b21lck5hbWV9PC90ZD5cbiAgICAgICAgICAgICAgICA8dGQgc3R5bGU9XCJ0ZXh0LWFsaWduOnJpZ2h0O1wiPjxiPk1vYmlsZTo8L2I+ICR7YmlsbFRvUHJpbnQuY3VzdG9tZXJNb2JpbGV9PC90ZD5cbiAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgIDwvdGFibGU+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8dGFibGUgY2xhc3M9XCJpdGVtc1wiPlxuICAgICAgICAgICAgPHRoZWFkPlxuICAgICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgICAgPHRoPlNyLjwvdGg+XG4gICAgICAgICAgICAgICAgPHRoPlNlcnZpY2UgRGVzY3JpcHRpb248L3RoPlxuICAgICAgICAgICAgICAgIDx0aD5DYXRlZ29yeTwvdGg+XG4gICAgICAgICAgICAgICAgPHRoIHN0eWxlPVwidGV4dC1hbGlnbjpyaWdodDtcIj5Hb3Z0IEZlZTwvdGg+XG4gICAgICAgICAgICAgICAgPHRoIHN0eWxlPVwidGV4dC1hbGlnbjpyaWdodDtcIj5TZXJ2aWNlIENoYXJnZTwvdGg+XG4gICAgICAgICAgICAgICAgPHRoIHN0eWxlPVwidGV4dC1hbGlnbjpyaWdodDtcIj5Ub3RhbCAo4oK5KTwvdGg+XG4gICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICA8L3RoZWFkPlxuICAgICAgICAgICAgPHRib2R5PlxuICAgICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgICAgPHRkPjE8L3RkPlxuICAgICAgICAgICAgICAgIDx0ZD48Yj4ke2JpbGxUb1ByaW50LnNlcnZpY2VOYW1lfTwvYj48L3RkPlxuICAgICAgICAgICAgICAgIDx0ZD4ke2JpbGxUb1ByaW50LmNhdGVnb3J5fTwvdGQ+XG4gICAgICAgICAgICAgICAgPHRkIHN0eWxlPVwidGV4dC1hbGlnbjpyaWdodDtcIj7igrkke2JpbGxUb1ByaW50LmdvdnRGZWV9PC90ZD5cbiAgICAgICAgICAgICAgICA8dGQgc3R5bGU9XCJ0ZXh0LWFsaWduOnJpZ2h0O1wiPuKCuSR7YmlsbFRvUHJpbnQuc2VydmljZUZlZX08L3RkPlxuICAgICAgICAgICAgICAgIDx0ZCBzdHlsZT1cInRleHQtYWxpZ246cmlnaHQ7IGZvbnQtd2VpZ2h0OmJvbGQ7XCI+4oK5JHtiaWxsVG9QcmludC50b3RhbH08L3RkPlxuICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICA8dHIgY2xhc3M9XCJ0b3RhbC1yb3dcIj5cbiAgICAgICAgICAgICAgICA8dGQgY29sc3Bhbj1cIjVcIiBzdHlsZT1cInRleHQtYWxpZ246cmlnaHQ7XCI+R1JBTkQgVE9UQUw6PC90ZD5cbiAgICAgICAgICAgICAgICA8dGQgc3R5bGU9XCJ0ZXh0LWFsaWduOnJpZ2h0OyBjb2xvcjojMWU0MGFmO1wiPuKCuSR7YmlsbFRvUHJpbnQudG90YWx9LjAwPC90ZD5cbiAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgIDwvdGJvZHk+XG4gICAgICAgICAgPC90YWJsZT5cblxuICAgICAgICAgIDxkaXYgc3R5bGU9XCJtYXJnaW4tdG9wOjE1cHg7IGZvbnQtc2l6ZToxMnB4OyBjb2xvcjojNjQ3NDhiO1wiPlxuICAgICAgICAgICAgUGF5bWVudCBNb2RlOiA8Yj4ke2JpbGxUb1ByaW50LnBheW1lbnRNb2RlfTwvYj4gfCBTdGF0dXM6IDxiPiR7YmlsbFRvUHJpbnQuc3RhdHVzfTwvYj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxkaXYgY2xhc3M9XCJmb290ZXJcIj5cbiAgICAgICAgICAgIDxkaXYgc3R5bGU9XCJmb250LXNpemU6MTFweDsgY29sb3I6IzY0NzQ4YjtcIj5cbiAgICAgICAgICAgICAgVGhpcyBpcyBhIGNvbXB1dGVyIGdlbmVyYXRlZCBpbnZvaWNlLjxicj5UZXJtczogRmVlcyBvbmNlIHBhaWQgZm9yIGdvdmVybm1lbnQgcG9ydGFsIHN1Ym1pc3Npb25zIGFyZSBub24tcmVmdW5kYWJsZS5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cInNpZ25cIj5cbiAgICAgICAgICAgICAgQXV0aG9yaXplZCBTaWduYXRvcnk8YnI+PGI+JHtzZXR0aW5ncy5zaG9wTmFtZX08L2I+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9ib2R5PlxuICAgICAgPC9odG1sPlxuICAgIGA7XG5cbiAgICBwcmludEh0bWxEb2N1bWVudChodG1sQm9keSwgYEludm9pY2VfJHtiaWxsVG9QcmludC5pbnZvaWNlTm99YCwgcGFnZVN0eWxlKTtcbiAgfTtcblxuICAvLyBFeHBvcnQgbGVkZ2VyIHRvIENTVlxuICBjb25zdCBoYW5kbGVFeHBvcnRDU1YgPSAoKSA9PiB7XG4gICAgbGV0IGNzdiA9ICdJbnZvaWNlIE5vLEN1c3RvbWVyIE5hbWUsTW9iaWxlLFNlcnZpY2UsR292dCBGZWUsU2VydmljZSBGZWUsVG90YWwsUGF5bWVudCBNb2RlLFN0YXR1cyxEYXRlXFxuJztcbiAgICBiaWxscy5mb3JFYWNoKGIgPT4ge1xuICAgICAgY3N2ICs9IGBcIiR7Yi5pbnZvaWNlTm99XCIsXCIke2IuY3VzdG9tZXJOYW1lfVwiLFwiJHtiLmN1c3RvbWVyTW9iaWxlfVwiLFwiJHtiLnNlcnZpY2VOYW1lfVwiLCR7Yi5nb3Z0RmVlfSwke2Iuc2VydmljZUZlZX0sJHtiLnRvdGFsfSxcIiR7Yi5wYXltZW50TW9kZX1cIixcIiR7Yi5zdGF0dXN9XCIsXCIke2IuY3JlYXRlZEF0fVwiXFxuYDtcbiAgICB9KTtcbiAgICBjb25zdCBibG9iID0gbmV3IEJsb2IoW2Nzdl0sIHsgdHlwZTogJ3RleHQvY3N2JyB9KTtcbiAgICBjb25zdCB1cmwgPSBVUkwuY3JlYXRlT2JqZWN0VVJMKGJsb2IpO1xuICAgIGNvbnN0IGEgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdhJyk7XG4gICAgYS5ocmVmID0gdXJsO1xuICAgIGEuZG93bmxvYWQgPSBgTXV6YW1taWxfQmlsbHNfTGVkZ2VyXyR7bmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNsaWNlKDAsIDEwKX0uY3N2YDtcbiAgICBhLmNsaWNrKCk7XG4gICAgVVJMLnJldm9rZU9iamVjdFVSTCh1cmwpO1xuICB9O1xuXG4gIC8vIEZpbHRlciBiaWxsc1xuICBjb25zdCBmaWx0ZXJlZEJpbGxzID0gYmlsbHMuZmlsdGVyKGIgPT4ge1xuICAgIGNvbnN0IG1hdGNoZXNTZWFyY2ggPSBcbiAgICAgIGIuY3VzdG9tZXJOYW1lLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoc2VhcmNoVGVybS50b0xvd2VyQ2FzZSgpKSB8fFxuICAgICAgYi5jdXN0b21lck1vYmlsZS5pbmNsdWRlcyhzZWFyY2hUZXJtKSB8fFxuICAgICAgYi5pbnZvaWNlTm8udG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhzZWFyY2hUZXJtLnRvTG93ZXJDYXNlKCkpIHx8XG4gICAgICBiLnNlcnZpY2VOYW1lLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoc2VhcmNoVGVybS50b0xvd2VyQ2FzZSgpKTtcbiAgICBjb25zdCBtYXRjaGVzRGF0ZSA9ICFkYXRlRmlsdGVyIHx8IGIuY3JlYXRlZEF0LmluY2x1ZGVzKGRhdGVGaWx0ZXIpO1xuICAgIHJldHVybiBtYXRjaGVzU2VhcmNoICYmIG1hdGNoZXNEYXRlO1xuICB9KTtcblxuICBjb25zdCBhY3RpdmVEaXNwbGF5QmlsbCA9IGFjdGl2ZVByZXZpZXdCaWxsIHx8IChiaWxscy5sZW5ndGggPiAwID8gYmlsbHNbMF0gOiBudWxsKTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS01XCI+XG4gICAgICB7LyogSGVhZGVyIGJhciAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBzbTppdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBwLTQgcm91bmRlZC0yeGwgc2hhZG93LW1kXCI+XG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1leHRyYWJvbGQgdGV4dC13aGl0ZVwiPkJpbGxpbmcgRGVzayAmIFBPUyBTdGF0aW9uPC9oMT5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJnLWVtZXJhbGQtNTAwLzIwIHRleHQtZW1lcmFsZC00MDAgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTUwMC8zMCB0ZXh0LXhzIHB4LTIgcHktMC41IHJvdW5kZWQtZnVsbCBmb250LW1vbm8gZm9udC1ib2xkXCI+XG4gICAgICAgICAgICAgIHtzZXR0aW5ncy50aGVybWFsV2lkdGh9IFBPUyAvIEE0XG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMCBtdC0wLjVcIj5cbiAgICAgICAgICAgIFF1aWNrIGN1c3RvbWVyIGJpbGxpbmcsIGR5bmFtaWMgVVBJIFFSIHBheW1lbnRzLCA1OG1tLzgwbW0gdGhlcm1hbCByZWNlaXB0IHByaW50aW5nICYgV2hhdHNBcHAgbm90aWZpY2F0aW9uXG4gICAgICAgICAgPC9wPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17aGFuZGxlRXhwb3J0Q1NWfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBiZy1zbGF0ZS04MDAgaG92ZXI6Ymctc2xhdGUtNzAwIHRleHQtc2xhdGUtMjAwIGhvdmVyOnRleHQtd2hpdGUgZm9udC1ib2xkIHRleHQteHMgcHgtMyBweS0yIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgdHJhbnNpdGlvbi1hbGxcIlxuICAgICAgICAgICAgdGl0bGU9XCJFeHBvcnQgQmlsbHMgTGVkZ2VyIHRvIEV4Y2VsIENTVlwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPEZpbGVTcHJlYWRzaGVldCBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtZW1lcmFsZC00MDBcIiAvPlxuICAgICAgICAgICAgPHNwYW4+RXhwb3J0IENTVjwvc3Bhbj5cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIE1haW4gRHVhbCBQYW5lOiBMZWZ0ID0gTmV3IEJpbGwgRm9ybSwgUmlnaHQgPSBMaXZlIFBPUyBSZWNlaXB0IFByZXZpZXcgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbGc6Z3JpZC1jb2xzLTEyIGdhcC01IGl0ZW1zLXN0YXJ0XCI+XG4gICAgICAgIHsvKiBMZWZ0IFNpZGU6IEZhc3QgUE9TIEVudHJ5IEZvcm0gKDcgY29scykgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibGc6Y29sLXNwYW4tNyBzcGFjZS15LTRcIj5cbiAgICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlQ3JlYXRlQmlsbH0gY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwLzkwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtMnhsIHAtNSBzaGFkb3ctbWQgc3BhY2UteS00XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBib3JkZXItYiBib3JkZXItc2xhdGUtODAwIHBiLTNcIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS0yMDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgPFJlY2VpcHQgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWVtZXJhbGQtNDAwXCIgLz5cbiAgICAgICAgICAgICAgICA8c3Bhbj5DcmVhdGUgTmV3IEN1c3RvbWVyIFJlY2VpcHQ8L3NwYW4+XG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1vbm8gZm9udC1ib2xkIHRleHQtYmx1ZS00MDAgYmctYmx1ZS01MDAvMTAgcHgtMiBweS0wLjUgcm91bmRlZCBib3JkZXIgYm9yZGVyLWJsdWUtNTAwLzIwXCI+XG4gICAgICAgICAgICAgICAgTmV4dDoge25leHRJbnZvaWNlTm99XG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogQ3VzdG9tZXIgTmFtZSAmIE1vYmlsZSAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMiBnYXAtMyB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS0zMDAgYmxvY2sgbWItMVwiPkN1c3RvbWVyIEZ1bGwgTmFtZSAqPC9sYWJlbD5cbiAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImUuZy4gU2hhaWtoIFNhbWVlclwiXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17Y3VzdG9tZXJOYW1lfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRDdXN0b21lck5hbWUoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLXhsIHB4LTMgcHktMiB0ZXh0LXdoaXRlIHBsYWNlaG9sZGVyLXNsYXRlLTUwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLWVtZXJhbGQtNTAwIHRleHQtc20gZm9udC1tZWRpdW1cIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS0zMDAgYmxvY2sgbWItMVwiPkN1c3RvbWVyIE1vYmlsZSAoV2hhdHNBcHApICo8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRlbFwiXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIjEwIGRpZ2l0IG1vYmlsZSAoZS5nLiA5NTYxNDYwMzEzKVwiXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17Y3VzdG9tZXJNb2JpbGV9XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEN1c3RvbWVyTW9iaWxlKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCBweC0zIHB5LTIgdGV4dC13aGl0ZSBwbGFjZWhvbGRlci1zbGF0ZS01MDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1lbWVyYWxkLTUwMCB0ZXh0LXNtIGZvbnQtbW9ub1wiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIFNlcnZpY2UgUHJlc2V0IERyb3Bkb3duICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHNwYWNlLXktMVwiPlxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTMwMCBibG9ja1wiPlNlbGVjdCBTZXJ2aWNlIC8gQXBwbGljYXRpb24gKjwvbGFiZWw+XG4gICAgICAgICAgICAgIDxzZWxlY3RcbiAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRTZXJ2aWNlfVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlU2VydmljZVNlbGVjdChlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLXhsIHB4LTMgcHktMi41IHRleHQtd2hpdGUgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1lbWVyYWxkLTUwMCB0ZXh0LXNtIGZvbnQtbWVkaXVtXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIHtDT01NT05fU0hPUF9TRVJWSUNFUy5tYXAoKHMpID0+IChcbiAgICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXtzLm5hbWV9IHZhbHVlPXtzLm5hbWV9PlxuICAgICAgICAgICAgICAgICAgICB7cy5uYW1lfSAoR292dDog4oK5e3MuZ292dEZlZX0gKyBGZWU6IOKCuXtzLnNlcnZpY2VGZWV9ID0g4oK5e3MuZ292dEZlZSArIHMuc2VydmljZUZlZX0pXG4gICAgICAgICAgICAgICAgICA8L29wdGlvbj5cbiAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIEZlZSBCcmVha2Rvd24gKEdvdnQgRmVlIHZzIFNlcnZpY2UgQ2hhcmdlKSAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMyBnYXAtMyB0ZXh0LXhzIGJnLXNsYXRlLTk1MC82MCBwLTMgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBibG9jayBtYi0xXCI+R292dCBQb3J0YWwgRmVlICjigrkpPC9sYWJlbD5cbiAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxuICAgICAgICAgICAgICAgICAgbWluPVwiMFwiXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17Z292dEZlZX1cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0R292dEZlZShOdW1iZXIoZS50YXJnZXQudmFsdWUpKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC1sZyBweC0yLjUgcHktMS41IHRleHQtd2hpdGUgZm9udC1tb25vIHRleHQtc21cIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIGJsb2NrIG1iLTFcIj5TaG9wIFNlcnZpY2UgRmVlICjigrkpPC9sYWJlbD5cbiAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxuICAgICAgICAgICAgICAgICAgbWluPVwiMFwiXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17c2VydmljZUZlZX1cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2VydmljZUZlZShOdW1iZXIoZS50YXJnZXQudmFsdWUpKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC1sZyBweC0yLjUgcHktMS41IHRleHQtd2hpdGUgZm9udC1tb25vIHRleHQtc21cIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtZW1lcmFsZC00MDAgZm9udC1ib2xkIGJsb2NrIG1iLTFcIj5Ub3RhbCBCaWxsIEFtb3VudDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoLTggcm91bmRlZC1sZyBiZy1lbWVyYWxkLTk1MC80MCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtNTAwLzQwIGZsZXggaXRlbXMtY2VudGVyIHB4LTMgZm9udC1tb25vIGZvbnQtYmxhY2sgdGV4dC1lbWVyYWxkLTQwMCB0ZXh0LWJhc2VcIj5cbiAgICAgICAgICAgICAgICAgIOKCuXt0b3RhbEFtb3VudH1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIFBheW1lbnQgTW9kZSAmIFN0YXR1cyAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMiBnYXAtMyB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS0zMDAgYmxvY2sgbWItMVwiPlBheW1lbnQgTWV0aG9kPC9sYWJlbD5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTMgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgICAgeyhbJ0Nhc2gnLCAnVVBJIC8gUVInLCAnUGVuZGluZyddIGFzIGNvbnN0KS5tYXAoKG1vZGUpID0+IChcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgIGtleT17bW9kZX1cbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRQYXltZW50TW9kZShtb2RlKX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweS0xLjUgcHgtMiByb3VuZGVkLWxnIGZvbnQtYm9sZCBib3JkZXIgdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHBheW1lbnRNb2RlID09PSBtb2RlXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLWJsdWUtNjAwIHRleHQtd2hpdGUgYm9yZGVyLWJsdWUtNTAwIHNoYWRvdy1zbSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnYmctc2xhdGUtOTUwIHRleHQtc2xhdGUtNDAwIGJvcmRlci1zbGF0ZS04MDAgaG92ZXI6Ymctc2xhdGUtODAwJ1xuICAgICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAge21vZGV9XG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS0zMDAgYmxvY2sgbWItMVwiPlBheW1lbnQgU3RhdHVzPC9sYWJlbD5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgICAgeyhbJ1BhaWQnLCAnRHVlJ10gYXMgY29uc3QpLm1hcCgoc3QpID0+IChcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgIGtleT17c3R9XG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0UGF5bWVudFN0YXR1cyhzdCA9PT0gJ0R1ZScgPyAnRHVlJyA6ICdQYWlkJyl9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHktMS41IHB4LTIgcm91bmRlZC1sZyBmb250LWJvbGQgYm9yZGVyIHRyYW5zaXRpb24tYWxsICR7XG4gICAgICAgICAgICAgICAgICAgICAgICBwYXltZW50U3RhdHVzID09PSBzdFxuICAgICAgICAgICAgICAgICAgICAgICAgICA/IHN0ID09PSAnUGFpZCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1lbWVyYWxkLTYwMCB0ZXh0LXdoaXRlIGJvcmRlci1lbWVyYWxkLTUwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA6ICdiZy1yb3NlLTYwMCB0ZXh0LXdoaXRlIGJvcmRlci1yb3NlLTUwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnYmctc2xhdGUtOTUwIHRleHQtc2xhdGUtNDAwIGJvcmRlci1zbGF0ZS04MDAgaG92ZXI6Ymctc2xhdGUtODAwJ1xuICAgICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAge3N0fVxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogTm90ZXMgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHNcIj5cbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIGJsb2NrIG1iLTFcIj5TZXJ2aWNlIFJlbWFya3MgLyBBY2sgVG9rZW4gKE9wdGlvbmFsKTwvbGFiZWw+XG4gICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImUuZy4gQWNrIHRva2VuIDg4MTI0LCAyIGNvcGllcyBwcmludGVkXCJcbiAgICAgICAgICAgICAgICB2YWx1ZT17bm90ZXN9XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXROb3RlcyhlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLXhsIHB4LTMgcHktMS41IHRleHQtd2hpdGUgcGxhY2Vob2xkZXItc2xhdGUtNTAwIHRleHQteHNcIlxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBTdWJtaXQgJiBHZW5lcmF0ZSBCdXR0b24gKi99XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgYmctZ3JhZGllbnQtdG8tciBmcm9tLWVtZXJhbGQtNjAwIHRvLXRlYWwtNjAwIGhvdmVyOmZyb20tZW1lcmFsZC01MDAgaG92ZXI6dG8tdGVhbC01MDAgdGV4dC13aGl0ZSBmb250LWV4dHJhYm9sZCB0ZXh0LXNtIHB5LTMgcm91bmRlZC14bCBzaGFkb3ctbGcgc2hhZG93LWVtZXJhbGQtNjAwLzMwIHRyYW5zaXRpb24tYWxsIGhvdmVyOnNjYWxlLVsxLjAxXSBhY3RpdmU6c2NhbGUtWzAuOTldXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPFJlY2VpcHQgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgIDxzcGFuPkdlbmVyYXRlIFJlY2VpcHQgJiBTYXZlICjigrl7dG90YWxBbW91bnR9KTwvc3Bhbj5cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvZm9ybT5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIFJpZ2h0IFNpZGU6IExpdmUgVGhlcm1hbCBQT1MgUmVjZWlwdCBQcmV2aWV3ICg1IGNvbHMpICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxnOmNvbC1zcGFuLTUgc3BhY2UteS0zXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0yeGwgcC00IHNoYWRvdy14bFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItMyB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXdoaXRlIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgICA8UHJpbnRlciBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LWJsdWUtNDAwXCIgLz5cbiAgICAgICAgICAgICAgICA8c3Bhbj5MaXZlIFBPUyBUaGVybWFsIFNsaXAgUHJldmlldzwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LW1vbm8gdGV4dC1zbGF0ZS00MDAgYmctc2xhdGUtODAwIHB4LTIgcHktMC41IHJvdW5kZWRcIj5cbiAgICAgICAgICAgICAgICB7c2V0dGluZ3MudGhlcm1hbFdpZHRofSBNb25vc3BhY2VcbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBXaGl0ZSBUaGVybWFsIFJlY2VpcHQgU2xpcCBCb3ggKi99XG4gICAgICAgICAgICB7YWN0aXZlRGlzcGxheUJpbGwgPyAoXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgdGV4dC1zbGF0ZS05NTAgcC01IHJvdW5kZWQteGwgc2hhZG93LTJ4bCBmb250LW1vbm8gdGV4dC14cyBzZWxlY3QtdGV4dCBib3JkZXIgYm9yZGVyLXNsYXRlLTMwMCBteC1hdXRvIG1heC13LVszNDBweF0gbGVhZGluZy1yZWxheGVkXCI+XG4gICAgICAgICAgICAgICAgey8qIFNob3AgSGVhZGVyICovfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgc3BhY2UteS0wLjUgYm9yZGVyLWIgYm9yZGVyLWRhc2hlZCBib3JkZXItc2xhdGUtNDAwIHBiLTNcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9udC1ibGFjayB0ZXh0LXNtIHVwcGVyY2FzZSB0cmFja2luZy10aWdodFwiPntzZXR0aW5ncy5zaG9wTmFtZX08L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS02MDBcIj57c2V0dGluZ3MudGFnbGluZX08L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS02MDBcIj57c2V0dGluZ3MuYWRkcmVzc308L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1ib2xkXCI+TW9iOiB7c2V0dGluZ3MucGhvbmV9PC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICB7LyogQmlsbCBNZXRhZGF0YSAqL31cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTIuNSBib3JkZXItYiBib3JkZXItZGFzaGVkIGJvcmRlci1zbGF0ZS00MDAgc3BhY2UteS0wLjUgdGV4dC1bMTFweF1cIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+SW52b2ljZTo8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZFwiPnthY3RpdmVEaXNwbGF5QmlsbC5pbnZvaWNlTm99PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPkRhdGU6PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj57YWN0aXZlRGlzcGxheUJpbGwuY3JlYXRlZEF0fTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj5DdXN0b21lcjo8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZFwiPnthY3RpdmVEaXNwbGF5QmlsbC5jdXN0b21lck5hbWV9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPlBob25lOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+e2FjdGl2ZURpc3BsYXlCaWxsLmN1c3RvbWVyTW9iaWxlfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgey8qIEl0ZW1zICYgRmVlcyAqL31cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTIuNSBib3JkZXItYiBib3JkZXItZGFzaGVkIGJvcmRlci1zbGF0ZS00MDAgc3BhY2UteS0xIHRleHQteHNcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9udC1ib2xkXCI+e2FjdGl2ZURpc3BsYXlCaWxsLnNlcnZpY2VOYW1lfTwvZGl2PlxuICAgICAgICAgICAgICAgICAge2FjdGl2ZURpc3BsYXlCaWxsLmdvdnRGZWUgPiAwICYmIChcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiB0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTcwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPkdvdnQgUG9ydGFsIEZlZTo8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+4oK5e2FjdGl2ZURpc3BsYXlCaWxsLmdvdnRGZWV9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIHRleHQtWzExcHhdIHRleHQtc2xhdGUtNzAwXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPlNlcnZpY2UgQ2hhcmdlOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+4oK5e2FjdGl2ZURpc3BsYXlCaWxsLnNlcnZpY2VGZWV9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGZvbnQtYmxhY2sgdGV4dC1zbSBwdC0xIGJvcmRlci10IGJvcmRlci1zbGF0ZS05MDAgbXQtMVwiPlxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj5ORVQgVE9UQUw6PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj7igrl7YWN0aXZlRGlzcGxheUJpbGwudG90YWx9LjAwPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICB7LyogUGF5bWVudCAmIFFSICovfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHQtMiB0ZXh0LWNlbnRlciBzcGFjZS15LTJcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZFwiPlxuICAgICAgICAgICAgICAgICAgICBQYXltZW50IE1vZGU6IDxiPnthY3RpdmVEaXNwbGF5QmlsbC5wYXltZW50TW9kZX08L2I+ICh7YWN0aXZlRGlzcGxheUJpbGwuc3RhdHVzfSlcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICB7c2V0dGluZ3MudXBpSWQgJiYgKFxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtMiBiZy1zbGF0ZS01MCByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItc2xhdGUtMjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS01MDAgbWItMVwiPlNjYW4gUVIgdmlhIEdQYXkgLyBQaG9uZVBlIC8gUGF5dG06PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIHtxckRhdGFVcmwgJiYgPGltZyBzcmM9e3FyRGF0YVVybH0gYWx0PVwiVVBJIFFSXCIgY2xhc3NOYW1lPVwidy0yOCBoLTI4XCIgLz59XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1ib2xkIGZvbnQtbW9ubyB0ZXh0LXNsYXRlLTcwMCBtdC0xXCI+e3NldHRpbmdzLnVwaUlkfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNTAwIHB0LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgKioqIFRoYW5rIFlvdSBWaXNpdCBBZ2FpbiAqKio8YnIgLz5cbiAgICAgICAgICAgICAgICAgICAgTXV6YW1taWwgT25saW5lIFNlcnZpY2UgRGlnaXRhbCBIdWJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC04IHRleHQtY2VudGVyIHRleHQtc2xhdGUtNTAwIHRleHQteHNcIj5cbiAgICAgICAgICAgICAgICBObyBiaWxsIHNlbGVjdGVkLiBDcmVhdGUgYSBiaWxsIG9uIHRoZSBsZWZ0IHRvIHNlZSBsaXZlIHByZXZpZXcuXG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgey8qIFNsaXAgQWN0aW9uIEJ1dHRvbnMgKi99XG4gICAgICAgICAgICB7YWN0aXZlRGlzcGxheUJpbGwgJiYgKFxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTMgZ2FwLTIgbXQtNCBwdC0zIGJvcmRlci10IGJvcmRlci1zbGF0ZS04MDBcIj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVQcmludFRoZXJtYWwoYWN0aXZlRGlzcGxheUJpbGwpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTEuNSBiZy1ibHVlLTYwMCBob3ZlcjpiZy1ibHVlLTUwMCB0ZXh0LXdoaXRlIGZvbnQtYm9sZCB0ZXh0LXhzIHB5LTIgcm91bmRlZC14bCBzaGFkb3ctbWQgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgICAgICAgICAgdGl0bGU9XCJQcmludCBvbiA1OG1tLzgwbW0gVGhlcm1hbCBQcmludGVyXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8UHJpbnRlciBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XG4gICAgICAgICAgICAgICAgICA8c3Bhbj5UaGVybWFsPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlUHJpbnRBNChhY3RpdmVEaXNwbGF5QmlsbCl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMS41IGJnLXNsYXRlLTgwMCBob3ZlcjpiZy1zbGF0ZS03MDAgdGV4dC1zbGF0ZS0yMDAgaG92ZXI6dGV4dC13aGl0ZSBmb250LWJvbGQgdGV4dC14cyBweS0yIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgICAgICAgICAgdGl0bGU9XCJQcmludCBPZmZpY2lhbCBBNCBUYXggSW52b2ljZVwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPFByaW50ZXIgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1wdXJwbGUtNDAwXCIgLz5cbiAgICAgICAgICAgICAgICAgIDxzcGFuPkE0IEludm9pY2U8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgICAgICA8YVxuICAgICAgICAgICAgICAgICAgaHJlZj17YGh0dHBzOi8vd2EubWUvOTEke2FjdGl2ZURpc3BsYXlCaWxsLmN1c3RvbWVyTW9iaWxlfT90ZXh0PUhlbGxvJTIwJHtlbmNvZGVVUklDb21wb25lbnQoYWN0aXZlRGlzcGxheUJpbGwuY3VzdG9tZXJOYW1lKX0sJTIweW91ciUyMHJlY2VpcHQlMjBmb3IlMjAke2VuY29kZVVSSUNvbXBvbmVudChhY3RpdmVEaXNwbGF5QmlsbC5zZXJ2aWNlTmFtZSl9JTIwYXQlMjAke2VuY29kZVVSSUNvbXBvbmVudChzZXR0aW5ncy5zaG9wTmFtZSl9JTIwaXMlMjByZWFkeS4lMjBUb3RhbDolMjBScy4ke2FjdGl2ZURpc3BsYXlCaWxsLnRvdGFsfS4lMjBJbnZvaWNlOiUyMCR7YWN0aXZlRGlzcGxheUJpbGwuaW52b2ljZU5vfWB9XG4gICAgICAgICAgICAgICAgICB0YXJnZXQ9XCJfYmxhbmtcIlxuICAgICAgICAgICAgICAgICAgcmVsPVwibm9vcGVuZXIgbm9yZWZlcnJlclwiXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMS41IGJnLWVtZXJhbGQtNjAwIGhvdmVyOmJnLWVtZXJhbGQtNTAwIHRleHQtd2hpdGUgZm9udC1ib2xkIHRleHQteHMgcHktMiByb3VuZGVkLXhsIHNoYWRvdy1tZCB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICAgICAgICB0aXRsZT1cIlNlbmQgUmVjZWlwdCB2aWEgV2hhdHNBcHBcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxTZW5kIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cbiAgICAgICAgICAgICAgICAgIDxzcGFuPldoYXRzQXBwPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvYT5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogQm90dG9tIFNlY3Rpb246IEZ1bGwgQmlsbGluZyBMZWRnZXIgJiBTYWxlcyBIaXN0b3J5IFRhYmxlICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0yeGwgcC01IHNoYWRvdy1tZCBzcGFjZS15LTRcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IHNtOml0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTNcIj5cbiAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LWJhc2UgdGV4dC13aGl0ZVwiPkJpbGxpbmcgSGlzdG9yeSAmIFNhbGVzIExlZGdlcjwvaDM+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwXCI+VG90YWwge2JpbGxzLmxlbmd0aH0gYmlsbHMgcmVjb3JkZWQgaW4gbG9jYWwgZGF0YWJhc2U8L3A+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlXCI+XG4gICAgICAgICAgICAgIDxTZWFyY2ggY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1zbGF0ZS00MDAgYWJzb2x1dGUgbGVmdC0yLjUgdG9wLTEvMiAtdHJhbnNsYXRlLXktMS8yXCIgLz5cbiAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRmlsdGVyIGJ5IGN1c3RvbWVyLCBwaG9uZSwgaW52b2ljZS4uLlwiXG4gICAgICAgICAgICAgICAgdmFsdWU9e3NlYXJjaFRlcm19XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTZWFyY2hUZXJtKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCBwbC04IHByLTMgcHktMS41IHRleHQteHMgdGV4dC13aGl0ZSBwbGFjZWhvbGRlci1zbGF0ZS01MDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LTU2XCJcbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm92ZXJmbG93LXgtYXV0b1wiPlxuICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJ3LWZ1bGwgdGV4dC1sZWZ0IHRleHQteHNcIj5cbiAgICAgICAgICAgIDx0aGVhZCBjbGFzc05hbWU9XCJiZy1zbGF0ZS05NTAgdGV4dC1zbGF0ZS00MDAgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMCBmb250LW1vbm9cIj5cbiAgICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0yLjUgcHgtM1wiPkludm9pY2U8L3RoPlxuICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0yLjUgcHgtM1wiPkRhdGUgJiBUaW1lPC90aD5cbiAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMi41IHB4LTNcIj5DdXN0b21lcjwvdGg+XG4gICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTIuNSBweC0zXCI+TW9iaWxlPC90aD5cbiAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMi41IHB4LTNcIj5TZXJ2aWNlPC90aD5cbiAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMi41IHB4LTMgdGV4dC1yaWdodFwiPkdvdnQ8L3RoPlxuICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0yLjUgcHgtMyB0ZXh0LXJpZ2h0XCI+RmVlPC90aD5cbiAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMi41IHB4LTMgdGV4dC1yaWdodFwiPlRvdGFsPC90aD5cbiAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMi41IHB4LTMgdGV4dC1jZW50ZXJcIj5TdGF0dXM8L3RoPlxuICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0yLjUgcHgtMyB0ZXh0LXJpZ2h0XCI+QWN0aW9uczwvdGg+XG4gICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICA8L3RoZWFkPlxuICAgICAgICAgICAgPHRib2R5IGNsYXNzTmFtZT1cImRpdmlkZS15IGRpdmlkZS1zbGF0ZS04MDAvNjBcIj5cbiAgICAgICAgICAgICAge2ZpbHRlcmVkQmlsbHMubWFwKChiKSA9PiAoXG4gICAgICAgICAgICAgICAgPHRyIFxuICAgICAgICAgICAgICAgICAga2V5PXtiLmlkfSBcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZVByZXZpZXdCaWxsKGIpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgY3Vyc29yLXBvaW50ZXIgdHJhbnNpdGlvbi1jb2xvcnMgJHtcbiAgICAgICAgICAgICAgICAgICAgYWN0aXZlUHJldmlld0JpbGw/LmlkID09PSBiLmlkID8gJ2JnLWJsdWUtOTUwLzMwJyA6ICdob3ZlcjpiZy1zbGF0ZS04MDAvNDAnXG4gICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMyBweC0zIGZvbnQtbW9ubyBmb250LWJvbGQgdGV4dC1ibHVlLTQwMFwiPntiLmludm9pY2VOb308L3RkPlxuICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMgcHgtMyB0ZXh0LXNsYXRlLTQwMCBmb250LW1vbm8gdGV4dC1bMTFweF1cIj57Yi5jcmVhdGVkQXR9PC90ZD5cbiAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zIHB4LTMgZm9udC1zZW1pYm9sZCB0ZXh0LXdoaXRlXCI+e2IuY3VzdG9tZXJOYW1lfTwvdGQ+XG4gICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMyBweC0zIGZvbnQtbW9ubyB0ZXh0LXNsYXRlLTQwMFwiPntiLmN1c3RvbWVyTW9iaWxlfTwvdGQ+XG4gICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMyBweC0zIHRleHQtc2xhdGUtMzAwIG1heC13LVsyMDBweF0gdHJ1bmNhdGVcIj57Yi5zZXJ2aWNlTmFtZX08L3RkPlxuICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMgcHgtMyB0ZXh0LXJpZ2h0IGZvbnQtbW9ubyB0ZXh0LXNsYXRlLTQwMFwiPuKCuXtiLmdvdnRGZWV9PC90ZD5cbiAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zIHB4LTMgdGV4dC1yaWdodCBmb250LW1vbm8gdGV4dC1zbGF0ZS00MDBcIj7igrl7Yi5zZXJ2aWNlRmVlfTwvdGQ+XG4gICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMyBweC0zIHRleHQtcmlnaHQgZm9udC1tb25vIGZvbnQtYm9sZCB0ZXh0LWVtZXJhbGQtNDAwXCI+4oK5e2IudG90YWx9PC90ZD5cbiAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zIHB4LTMgdGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgcHgtMiBweS0wLjUgcm91bmRlZCB0ZXh0LVsxMHB4XSBmb250LWJvbGQgJHtcbiAgICAgICAgICAgICAgICAgICAgICBiLnN0YXR1cyA9PT0gJ1BhaWQnIFxuICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctZW1lcmFsZC01MDAvMjAgdGV4dC1lbWVyYWxkLTMwMCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtNTAwLzMwJyBcbiAgICAgICAgICAgICAgICAgICAgICAgIDogJ2JnLWFtYmVyLTUwMC8yMCB0ZXh0LWFtYmVyLTMwMCBib3JkZXIgYm9yZGVyLWFtYmVyLTUwMC8zMCdcbiAgICAgICAgICAgICAgICAgICAgfWB9PlxuICAgICAgICAgICAgICAgICAgICAgIHtiLnN0YXR1c31cbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zIHB4LTMgdGV4dC1yaWdodCBzcGFjZS14LTEgd2hpdGVzcGFjZS1ub3dyYXBcIj5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eyhlKSA9PiB7IGUuc3RvcFByb3BhZ2F0aW9uKCk7IGhhbmRsZVByaW50VGhlcm1hbChiKTsgfX1cbiAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIlByaW50IFRoZXJtYWwgU2xpcFwiXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xLjUgcm91bmRlZC1sZyBiZy1zbGF0ZS04MDAgaG92ZXI6Ymctc2xhdGUtNzAwIHRleHQtc2xhdGUtMjAwIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIDxQcmludGVyIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoZSkgPT4geyBlLnN0b3BQcm9wYWdhdGlvbigpOyBvbkRlbGV0ZUJpbGwoYi5pZCk7IH19XG4gICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJEZWxldGUgQmlsbFwiXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xLjUgcm91bmRlZC1sZyBiZy1yb3NlLTUwMC8xMCBob3ZlcjpiZy1yb3NlLTUwMC8yMCB0ZXh0LXJvc2UtNDAwIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIDxUcmFzaDIgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICA8L3Rib2R5PlxuICAgICAgICAgIDwvdGFibGU+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59O1xuIl19