<!doctype html>
<html lang="en">
  <head>
    <script type="module" src="/@vite/client"></script>

    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="manifest" href="/manifest.json" />
    <meta name="theme-color" content="#0f172a" />
    <meta name="mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
    <meta name="apple-mobile-web-app-title" content="Muzammil PC" />
    <link rel="apple-touch-icon" href="/pwa-192x192.png" />
    <link rel="icon" type="image/png" href="/muzammil_app_icon.png" />
    <title>Muzammil Online Service - PC Desktop Suite</title>
    <meta name="description" content="Professional PC Desktop workstation for Muzammil Online Service. All-in-one portal for citizen government schemes, PVC ID card maker (300 DPI), passport photo studio, PDF/JPG converter, billing desk with thermal receipts, customer CRM, and AI service assistant." />
    <meta property="og:title" content="Muzammil Online Service - PC Desktop Suite" />
    <meta property="og:description" content="Professional PC Desktop workstation for Muzammil Online Service. All-in-one portal for citizen government schemes, PVC ID card maker (300 DPI), passport photo studio, PDF/JPG converter, billing desk with thermal receipts, customer CRM, and AI service assistant." />
    <meta property="og:type" content="website" />
    <meta name="twitter:card" content="summary_large_image" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800;900&family=JetBrains+Mono:wght@400;500;600&display=swap" rel="stylesheet">
  <script src="/_aistudio-iframe.js?v=2c34bde1"></script></head>
  <body class="bg-slate-900 text-slate-100 antialiased selection:bg-blue-600 selection:text-white">
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
    <script>
      if ('serviceWorker' in navigator) {
        window.addEventListener('load', () => {
          navigator.serviceWorker.register('/sw.js').catch(() => {});
        });
      }
    </script>
  </body>
</html>

