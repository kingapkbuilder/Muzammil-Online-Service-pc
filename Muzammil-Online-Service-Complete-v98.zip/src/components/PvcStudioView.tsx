const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useRef = __vite__cjsImport0_react["useRef"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=090625a0";
import { Upload, Printer, Download, RotateCw, Check, ArrowUpDown, Sun, Contrast, HelpCircle } from "/node_modules/.vite/deps/lucide-react.js?v=090625a0";
import { jsPDF } from "/node_modules/.vite/deps/jspdf.js?v=090625a0";
import { addDownloadRecord } from "/src/utils/storage.ts";
import { printImageSheet } from "/src/utils/printer.ts";
var _jsxFileName = "/app/applet/src/components/PvcStudioView.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=090625a0";
export const PvcStudioView = () => {
	// Canvas references
	const canvasRef = useRef(null);
	// Card images (Data URLs or Image objects)
	const [card1Src, setCard1Src] = useState(null);
	const [card2Src, setCard2Src] = useState(null);
	// Active editing card: 'card1' | 'card2'
	const [activeCard, setActiveCard] = useState("card1");
	// Adjustments per card
	const [card1Config, setCard1Config] = useState({
		x: 0,
		y: 0,
		scale: 1,
		rotation: 0
	});
	const [card2Config, setCard2Config] = useState({
		x: 0,
		y: 0,
		scale: 1,
		rotation: 0
	});
	// Global card adjustments
	const [brightness, setBrightness] = useState(0);
	const [contrast, setContrast] = useState(0);
	const [showCutMarks, setShowCutMarks] = useState(true);
	const [roundedCorners, setRoundedCorners] = useState(true);
	const [borderStroke, setBorderStroke] = useState(true);
	const [isProcessing, setIsProcessing] = useState(false);
	const [printAlert, setPrintAlert] = useState(null);
	// Dragging state on canvas
	const [isDragging, setIsDragging] = useState(false);
	const [dragCard, setDragCard] = useState(null);
	const [dragStart, setDragStart] = useState({
		x: 0,
		y: 0
	});
	// 300 DPI constants for 4x6 inch paper:
	// 4 inches = 1200 px, 6 inches = 1800 px
	const CANVAS_WIDTH = 1200;
	const CANVAS_HEIGHT = 1800;
	// CR-80 card dimensions in mm: 85.6mm x 53.98mm (~3.37in x 2.125in)
	// At 300 DPI:
	// Width: 3.37 * 300 ≈ 1011 px
	// Height: 2.125 * 300 ≈ 638 px
	const CARD_WIDTH = 1010;
	const CARD_HEIGHT = 638;
	// Position on 4x6 sheet (two cards stacked vertically or centered)
	// Top Card Center: X = 600, Y = 460
	// Bottom Card Center: X = 600, Y = 1340
	const CARD1_DEFAULT_Y = 460;
	const CARD2_DEFAULT_Y = 1340;
	const CARD_CENTER_X = 600;
	// Pre-load images for canvas drawing
	const card1ImgRef = useRef(null);
	const card2ImgRef = useRef(null);
	// Load card 1 image
	useEffect(() => {
		if (card1Src) {
			const img = new Image();
			img.crossOrigin = "anonymous";
			img.onload = () => {
				card1ImgRef.current = img;
				renderCanvas();
			};
			img.src = card1Src;
		} else {
			card1ImgRef.current = null;
			renderCanvas();
		}
	}, [card1Src]);
	// Load card 2 image
	useEffect(() => {
		if (card2Src) {
			const img = new Image();
			img.crossOrigin = "anonymous";
			img.onload = () => {
				card2ImgRef.current = img;
				renderCanvas();
			};
			img.src = card2Src;
		} else {
			card2ImgRef.current = null;
			renderCanvas();
		}
	}, [card2Src]);
	// Global Keyboard shortcuts listener (Ctrl+P, Ctrl+S, Ctrl+J)
	useEffect(() => {
		const handleGlobalPrint = () => handleDirectPrint();
		const handleGlobalPdf = () => handleDownloadPDF();
		const handleGlobalJpg = () => handleDownloadJPG();
		window.addEventListener("app-direct-print", handleGlobalPrint);
		window.addEventListener("app-direct-pdf", handleGlobalPdf);
		window.addEventListener("app-direct-jpg", handleGlobalJpg);
		return () => {
			window.removeEventListener("app-direct-print", handleGlobalPrint);
			window.removeEventListener("app-direct-pdf", handleGlobalPdf);
			window.removeEventListener("app-direct-jpg", handleGlobalJpg);
		};
	});
	// Re-render canvas whenever configs change
	useEffect(() => {
		renderCanvas();
	}, [
		card1Config,
		card2Config,
		brightness,
		contrast,
		showCutMarks,
		roundedCorners,
		borderStroke
	]);
	// Main Render Function to Canvas @ 300 DPI
	const renderCanvas = () => {
		const canvas = canvasRef.current;
		if (!canvas) return;
		const ctx = canvas.getContext("2d");
		if (!ctx) return;
		// Clear background to pure white (for photo paper print)
		ctx.fillStyle = "#ffffff";
		ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
		// Filter string
		const filterStr = `brightness(${100 + brightness}%) contrast(${100 + contrast}%)`;
		// 1. Draw Card 1 (Top / Front)
		drawSingleCard(ctx, card1ImgRef.current, CARD_CENTER_X + card1Config.x, CARD1_DEFAULT_Y + card1Config.y, card1Config.scale, card1Config.rotation, "Card 1 (Front)", filterStr);
		// 2. Draw Card 2 (Bottom / Back)
		drawSingleCard(ctx, card2ImgRef.current, CARD_CENTER_X + card2Config.x, CARD2_DEFAULT_Y + card2Config.y, card2Config.scale, card2Config.rotation, "Card 2 (Back)", filterStr);
		// 3. Draw Cut Guide Line between cards
		if (showCutMarks) {
			ctx.save();
			ctx.strokeStyle = "#94a3b8";
			ctx.lineWidth = 2;
			ctx.setLineDash([8, 8]);
			// Horizontal center cut mark
			const midY = (CARD1_DEFAULT_Y + CARD_HEIGHT / 2 + CARD2_DEFAULT_Y - CARD_HEIGHT / 2) / 2;
			ctx.beginPath();
			ctx.moveTo(40, midY);
			ctx.lineTo(CANVAS_WIDTH - 40, midY);
			ctx.stroke();
			// Scissor indicator text
			ctx.setLineDash([]);
			ctx.fillStyle = "#64748b";
			ctx.font = "bold 20px sans-serif";
			ctx.textAlign = "center";
			ctx.fillText("✂ Cut Here (Fold / Separate)", CANVAS_WIDTH / 2, midY - 12);
			// Sheet boundary crop corners
			drawCropMarks(ctx, 40, 40);
			drawCropMarks(ctx, CANVAS_WIDTH - 40, 40);
			drawCropMarks(ctx, 40, CANVAS_HEIGHT - 40);
			drawCropMarks(ctx, CANVAS_WIDTH - 40, CANVAS_HEIGHT - 40);
			ctx.restore();
		}
	};
	const drawCropMarks = (ctx, x, y) => {
		ctx.strokeStyle = "#cbd5e1";
		ctx.lineWidth = 2;
		ctx.beginPath();
		ctx.moveTo(x - 20, y);
		ctx.lineTo(x + 20, y);
		ctx.moveTo(x, y - 20);
		ctx.lineTo(x, y + 20);
		ctx.stroke();
	};
	const drawSingleCard = (ctx, img, centerX, centerY, scale, rotation, placeholderLabel, filter) => {
		const w = CARD_WIDTH;
		const h = CARD_HEIGHT;
		const left = centerX - w / 2;
		const top = centerY - h / 2;
		ctx.save();
		// Rounded rectangle path for CR-80 card (standard ~3mm / 36px radius @ 300DPI)
		const radius = roundedCorners ? 36 : 0;
		ctx.beginPath();
		ctx.roundRect(left, top, w, h, radius);
		if (img) {
			ctx.save();
			// Clip image to card boundary
			ctx.clip();
			// Apply brightness & contrast filters
			ctx.filter = filter;
			// Transform for position, scale & rotation
			ctx.translate(centerX, centerY);
			ctx.rotate(rotation * Math.PI / 180);
			ctx.scale(scale, scale);
			// Draw image centered
			ctx.drawImage(img, -w / 2, -h / 2, w, h);
			ctx.restore();
		} else {
			// Empty placeholder slot
			ctx.fillStyle = "#f8fafc";
			ctx.fill();
			ctx.strokeStyle = "#cbd5e1";
			ctx.lineWidth = 4;
			ctx.setLineDash([12, 8]);
			ctx.stroke();
			// Placeholder text
			ctx.fillStyle = "#64748b";
			ctx.font = "bold 36px sans-serif";
			ctx.textAlign = "center";
			ctx.fillText(placeholderLabel, centerX, centerY - 20);
			ctx.font = "24px sans-serif";
			ctx.fillStyle = "#94a3b8";
			ctx.fillText("Drop image or PDF to place here", centerX, centerY + 30);
			ctx.fillText("CR-80 Standard: 85.6 mm × 54.0 mm", centerX, centerY + 70);
		}
		// Border line around card
		if (borderStroke) {
			ctx.beginPath();
			ctx.roundRect(left, top, w, h, radius);
			ctx.strokeStyle = "#1e293b";
			ctx.lineWidth = 2;
			ctx.setLineDash([]);
			ctx.stroke();
		}
		ctx.restore();
	};
	// Upload handler for Card 1 or Card 2
	const handleFileUpload = (e, target) => {
		const file = e.target.files?.[0];
		if (!file) return;
		const reader = new FileReader();
		reader.onload = (event) => {
			const result = event.target?.result;
			if (target === "card1") {
				setCard1Src(result);
				setActiveCard("card1");
			} else {
				setCard2Src(result);
				setActiveCard("card2");
			}
		};
		reader.readAsDataURL(file);
		e.target.value = "";
	};
	// Swap Front & Back cards
	const handleSwapCards = () => {
		const tempSrc = card1Src;
		setCard1Src(card2Src);
		setCard2Src(tempSrc);
		const tempCfg = { ...card1Config };
		setCard1Config({ ...card2Config });
		setCard2Config(tempCfg);
	};
	// Scale adjustment
	const handleScaleChange = (val) => {
		if (activeCard === "card1") {
			setCard1Config((prev) => ({
				...prev,
				scale: val
			}));
		} else {
			setCard2Config((prev) => ({
				...prev,
				scale: val
			}));
		}
	};
	// Nudge adjustment
	const handleNudge = (dx, dy) => {
		if (activeCard === "card1") {
			setCard1Config((prev) => ({
				...prev,
				x: prev.x + dx,
				y: prev.y + dy
			}));
		} else {
			setCard2Config((prev) => ({
				...prev,
				x: prev.x + dx,
				y: prev.y + dy
			}));
		}
	};
	// Rotate 90 degrees
	const handleRotate = () => {
		if (activeCard === "card1") {
			setCard1Config((prev) => ({
				...prev,
				rotation: (prev.rotation + 90) % 360
			}));
		} else {
			setCard2Config((prev) => ({
				...prev,
				rotation: (prev.rotation + 90) % 360
			}));
		}
	};
	// Reset controls
	const handleReset = () => {
		setCard1Config({
			x: 0,
			y: 0,
			scale: 1,
			rotation: 0
		});
		setCard2Config({
			x: 0,
			y: 0,
			scale: 1,
			rotation: 0
		});
		setBrightness(0);
		setContrast(0);
	};
	// Download High-Res 300 DPI JPG
	const handleDownloadJPG = () => {
		const canvas = canvasRef.current;
		if (!canvas) return;
		setIsProcessing(true);
		try {
			const dataUrl = canvas.toDataURL("image/jpeg", .98);
			const a = document.createElement("a");
			a.href = dataUrl;
			const fileName = `PVC_Card_4x6_300DPI_${Date.now()}.jpg`;
			a.download = fileName;
			a.click();
			addDownloadRecord({
				id: `pvc-jpg-${Date.now()}`,
				title: fileName,
				type: "PVC Card JPG",
				size: "1200×1800 px (300 DPI)",
				timestamp: new Date().toLocaleTimeString("en-IN")
			});
		} catch (e) {
			console.error(e);
		} finally {
			setIsProcessing(false);
		}
	};
	// Download 300 DPI PDF (Exact 4x6 inch paper size)
	const handleDownloadPDF = () => {
		const canvas = canvasRef.current;
		if (!canvas) return;
		setIsProcessing(true);
		try {
			const dataUrl = canvas.toDataURL("image/jpeg", .98);
			// 4x6 inches in PDF points: 4 * 72 = 288, 6 * 72 = 432
			const pdf = new jsPDF({
				orientation: "portrait",
				unit: "in",
				format: [4, 6]
			});
			pdf.addImage(dataUrl, "JPEG", 0, 0, 4, 6);
			const fileName = `PVC_Card_Printable_4x6_${Date.now()}.pdf`;
			pdf.save(fileName);
			addDownloadRecord({
				id: `pvc-pdf-${Date.now()}`,
				title: fileName,
				type: "PVC Card PDF",
				size: "4×6 inch (300 DPI)",
				timestamp: new Date().toLocaleTimeString("en-IN")
			});
		} catch (e) {
			console.error(e);
		} finally {
			setIsProcessing(false);
		}
	};
	// Direct Browser Print (Formatted for 4x6 photo paper)
	const handleDirectPrint = () => {
		const canvas = canvasRef.current;
		if (!canvas) return;
		try {
			const dataUrl = canvas.toDataURL("image/jpeg", 1);
			printImageSheet(dataUrl, {
				paperFormat: "4x6_portrait",
				title: "PVC_Card_4x6_Print"
			});
			setPrintAlert("🖨️ PVC Card print command sent to printer! (4×6 Photo Paper • CR-80 High Definition)");
			setTimeout(() => setPrintAlert(null), 4e3);
		} catch (e) {
			console.error(e);
			window.print();
		}
	};
	// Interactive Drag on Canvas
	const handleMouseDown = (e) => {
		const canvas = canvasRef.current;
		if (!canvas) return;
		const rect = canvas.getBoundingClientRect();
		const scaleX = CANVAS_WIDTH / rect.width;
		const scaleY = CANVAS_HEIGHT / rect.height;
		const mouseX = (e.clientX - rect.left) * scaleX;
		const mouseY = (e.clientY - rect.top) * scaleY;
		// Check if clicked in top card (Card 1)
		if (mouseY < CANVAS_HEIGHT / 2) {
			setDragCard("card1");
			setActiveCard("card1");
			setIsDragging(true);
			setDragStart({
				x: mouseX - card1Config.x,
				y: mouseY - card1Config.y
			});
		} else {
			setDragCard("card2");
			setActiveCard("card2");
			setIsDragging(true);
			setDragStart({
				x: mouseX - card2Config.x,
				y: mouseY - card2Config.y
			});
		}
	};
	const handleMouseMove = (e) => {
		if (!isDragging || !dragCard) return;
		const canvas = canvasRef.current;
		if (!canvas) return;
		const rect = canvas.getBoundingClientRect();
		const scaleX = CANVAS_WIDTH / rect.width;
		const scaleY = CANVAS_HEIGHT / rect.height;
		const mouseX = (e.clientX - rect.left) * scaleX;
		const mouseY = (e.clientY - rect.top) * scaleY;
		if (dragCard === "card1") {
			setCard1Config((prev) => ({
				...prev,
				x: Math.round(mouseX - dragStart.x),
				y: Math.round(mouseY - dragStart.y)
			}));
		} else {
			setCard2Config((prev) => ({
				...prev,
				x: Math.round(mouseX - dragStart.x),
				y: Math.round(mouseY - dragStart.y)
			}));
		}
	};
	const handleMouseUp = () => {
		setIsDragging(false);
		setDragCard(null);
	};
	const currentConfig = activeCard === "card1" ? card1Config : card2Config;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900 border border-slate-800 p-4 rounded-2xl shadow-md",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ _jsxDEV("h1", {
						className: "text-xl font-extrabold text-white",
						children: "PVC Smart Card Studio (CR-80)"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 503,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "bg-blue-500/20 text-blue-400 border border-blue-500/30 text-xs px-2 py-0.5 rounded-full font-mono font-bold",
						children: "300 DPI High-Definition"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 504,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 502,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "text-xs text-slate-400 mt-0.5",
					children: "Standard 4×6 inch sheet with 2 cards (Front & Back) • Standard CR-80 85.6 mm × 54.0 mm"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 508,
					columnNumber: 11
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 501,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2 flex-wrap",
					children: [
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: handleDirectPrint,
							className: "flex items-center gap-2 bg-gradient-to-r from-blue-600 via-indigo-600 to-blue-500 hover:from-blue-500 hover:to-indigo-500 text-white font-extrabold text-xs px-4 py-2.5 rounded-xl shadow-lg shadow-blue-600/30 transition-all hover:scale-105 active:scale-95 border border-blue-400/30",
							title: "Direct Print to Epson / Canon (Ctrl + P)",
							children: [/* @__PURE__ */ _jsxDEV(Printer, { className: "w-4 h-4 text-white" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 520,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "🖨️ Direct Print PVC Card" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 521,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 515,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: handleDownloadPDF,
							disabled: isProcessing,
							className: "flex items-center gap-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs px-3.5 py-2.5 rounded-xl shadow-lg shadow-indigo-600/30 transition-all hover:scale-105 disabled:opacity-50",
							title: "Download Printable 300 DPI PDF",
							children: [/* @__PURE__ */ _jsxDEV(Download, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 530,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "📄 PDF (4×6)" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 531,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 524,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: handleDownloadJPG,
							disabled: isProcessing,
							className: "flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white font-bold text-xs px-3 py-2.5 rounded-xl border border-slate-700 transition-all",
							title: "Download High-Res 1200x1800 JPG",
							children: [/* @__PURE__ */ _jsxDEV(Download, { className: "w-3.5 h-3.5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 540,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "🖼️ HD JPG" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 541,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 534,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 514,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 500,
				columnNumber: 7
			}, this),
			printAlert && /* @__PURE__ */ _jsxDEV("div", {
				className: "p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs flex items-center gap-2 animate-in fade-in",
				children: [/* @__PURE__ */ _jsxDEV(Check, { className: "w-4 h-4 text-emerald-400 flex-shrink-0" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 549,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("span", { children: printAlert }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 550,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 548,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "grid grid-cols-1 lg:grid-cols-12 gap-5 items-start",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "lg:col-span-5 space-y-4",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-md space-y-3",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs font-bold text-slate-300 uppercase tracking-wider",
									children: "Card Slots & Images"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 561,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									onClick: handleSwapCards,
									className: "text-xs font-semibold text-blue-400 hover:text-blue-300 flex items-center gap-1",
									title: "Swap Front and Back Cards",
									children: [/* @__PURE__ */ _jsxDEV(ArrowUpDown, { className: "w-3.5 h-3.5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 567,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Swap Front/Back" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 568,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 562,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 560,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: `p-3 rounded-xl border transition-all ${activeCard === "card1" ? "bg-blue-950/30 border-blue-500/50 shadow-sm" : "bg-slate-950/40 border-slate-800 hover:border-slate-700"}`,
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center justify-between mb-2",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ _jsxDEV("span", { className: "w-2 h-2 rounded-full bg-blue-500" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 580,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "text-xs font-bold text-white",
											children: "Card 1 (Front Side)"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 581,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 579,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-1.5",
										children: [/* @__PURE__ */ _jsxDEV("button", {
											onClick: () => setCard1Config((prev) => ({
												...prev,
												rotation: (prev.rotation + 90) % 360
											})),
											className: "text-[11px] px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 flex items-center gap-1",
											title: "Rotate Card 1",
											children: [/* @__PURE__ */ _jsxDEV(RotateCw, { className: "w-3 h-3 text-amber-400" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 589,
												columnNumber: 21
											}, this), /* @__PURE__ */ _jsxDEV("span", { children: [card1Config.rotation, "°"] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 590,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 584,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("button", {
											onClick: () => setCard1Config({
												x: 0,
												y: 0,
												scale: 1,
												rotation: 0
											}),
											className: "text-[11px] px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white",
											title: "Reset Position",
											children: "Reset"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 592,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 583,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 578,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "flex-1 flex items-center justify-center gap-2 py-2 px-3 bg-slate-800 hover:bg-slate-750 text-slate-200 text-xs font-semibold rounded-lg cursor-pointer border border-slate-700 transition-colors",
										children: [
											/* @__PURE__ */ _jsxDEV(Upload, { className: "w-3.5 h-3.5 text-blue-400" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 604,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("span", { children: card1Src ? "Change Front Photo/PDF" : "Upload Card 1 (Front)" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 605,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("input", {
												type: "file",
												accept: "image/*,.pdf",
												onChange: (e) => handleFileUpload(e, "card1"),
												className: "hidden"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 606,
												columnNumber: 19
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 603,
										columnNumber: 17
									}, this), card1Src && /* @__PURE__ */ _jsxDEV("button", {
										onClick: () => setCard1Src(null),
										className: "p-2 text-rose-400 hover:bg-rose-500/10 rounded-lg text-xs",
										title: "Remove Card 1",
										children: "✕"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 609,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 602,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 573,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: `p-3 rounded-xl border transition-all ${activeCard === "card2" ? "bg-blue-950/30 border-blue-500/50 shadow-sm" : "bg-slate-950/40 border-slate-800 hover:border-slate-700"}`,
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center justify-between mb-2",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ _jsxDEV("span", { className: "w-2 h-2 rounded-full bg-purple-500" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 628,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "text-xs font-bold text-white",
											children: "Card 2 (Back Side)"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 629,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 627,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-1.5",
										children: [/* @__PURE__ */ _jsxDEV("button", {
											onClick: () => setCard2Config((prev) => ({
												...prev,
												rotation: (prev.rotation + 90) % 360
											})),
											className: "text-[11px] px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 flex items-center gap-1",
											title: "Rotate Card 2",
											children: [/* @__PURE__ */ _jsxDEV(RotateCw, { className: "w-3 h-3 text-amber-400" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 637,
												columnNumber: 21
											}, this), /* @__PURE__ */ _jsxDEV("span", { children: [card2Config.rotation, "°"] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 638,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 632,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("button", {
											onClick: () => setCard2Config({
												x: 0,
												y: 0,
												scale: 1,
												rotation: 0
											}),
											className: "text-[11px] px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white",
											title: "Reset Position",
											children: "Reset"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 640,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 631,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 626,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "flex-1 flex items-center justify-center gap-2 py-2 px-3 bg-slate-800 hover:bg-slate-750 text-slate-200 text-xs font-semibold rounded-lg cursor-pointer border border-slate-700 transition-colors",
										children: [
											/* @__PURE__ */ _jsxDEV(Upload, { className: "w-3.5 h-3.5 text-purple-400" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 652,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("span", { children: card2Src ? "Change Back Photo/PDF" : "Upload Card 2 (Back)" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 653,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("input", {
												type: "file",
												accept: "image/*,.pdf",
												onChange: (e) => handleFileUpload(e, "card2"),
												className: "hidden"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 654,
												columnNumber: 19
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 651,
										columnNumber: 17
									}, this), card2Src && /* @__PURE__ */ _jsxDEV("button", {
										onClick: () => setCard2Src(null),
										className: "p-2 text-rose-400 hover:bg-rose-500/10 rounded-lg text-xs",
										title: "Remove Card 2",
										children: "✕"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 657,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 650,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 621,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 559,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-md space-y-3",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "text-xs font-bold text-slate-300 uppercase tracking-wider block",
							children: "Image Enhancement & Layout Guides"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 671,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-3 text-xs",
							children: [
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex justify-between text-slate-400 mb-1",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "flex items-center gap-1.5",
										children: [/* @__PURE__ */ _jsxDEV(Sun, { className: "w-3.5 h-3.5 text-amber-400" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 678,
											columnNumber: 63
										}, this), " Brightness"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 678,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "font-mono text-slate-200",
										children: brightness > 0 ? `+${brightness}` : brightness
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 679,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 677,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "range",
									min: "-30",
									max: "30",
									value: brightness,
									onChange: (e) => setBrightness(parseInt(e.target.value)),
									className: "w-full accent-amber-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 681,
									columnNumber: 17
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 676,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex justify-between text-slate-400 mb-1",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "flex items-center gap-1.5",
										children: [/* @__PURE__ */ _jsxDEV(Contrast, { className: "w-3.5 h-3.5 text-sky-400" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 693,
											columnNumber: 63
										}, this), " Contrast"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 693,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "font-mono text-slate-200",
										children: contrast > 0 ? `+${contrast}` : contrast
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 694,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 692,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "range",
									min: "-30",
									max: "30",
									value: contrast,
									onChange: (e) => setContrast(parseInt(e.target.value)),
									className: "w-full accent-sky-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 696,
									columnNumber: 17
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 691,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "pt-2 border-t border-slate-800 grid grid-cols-2 gap-2",
									children: [
										/* @__PURE__ */ _jsxDEV("label", {
											className: "flex items-center gap-2 cursor-pointer text-slate-300",
											children: [/* @__PURE__ */ _jsxDEV("input", {
												type: "checkbox",
												checked: showCutMarks,
												onChange: (e) => setShowCutMarks(e.target.checked),
												className: "rounded accent-blue-600"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 708,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("span", { children: "✂ Center Cut Line" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 714,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 707,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("label", {
											className: "flex items-center gap-2 cursor-pointer text-slate-300",
											children: [/* @__PURE__ */ _jsxDEV("input", {
												type: "checkbox",
												checked: roundedCorners,
												onChange: (e) => setRoundedCorners(e.target.checked),
												className: "rounded accent-blue-600"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 718,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Rounded CR80 Corner" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 724,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 717,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("label", {
											className: "flex items-center gap-2 cursor-pointer text-slate-300",
											children: [/* @__PURE__ */ _jsxDEV("input", {
												type: "checkbox",
												checked: borderStroke,
												onChange: (e) => setBorderStroke(e.target.checked),
												className: "rounded accent-blue-600"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 728,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Card Outline Border" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 734,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 727,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 706,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 675,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 670,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 557,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "lg:col-span-7 space-y-3",
					children: /* @__PURE__ */ _jsxDEV("div", {
						className: "bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-xl",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center justify-between mb-3 text-xs flex-wrap gap-2",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "font-bold text-white",
										children: "Interactive 4×6 Live Sheet"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 746,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-[11px] text-slate-400 font-mono",
										children: "(1200 × 1800 px @ 300 DPI)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 747,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 745,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									onClick: handleDirectPrint,
									className: "flex items-center gap-1.5 bg-blue-600 hover:bg-blue-500 text-white font-extrabold text-xs px-3.5 py-1.5 rounded-lg shadow-md transition-all hover:scale-105 active:scale-95",
									title: "Print PVC Card Sheet directly to connected printer",
									children: [/* @__PURE__ */ _jsxDEV(Printer, { className: "w-3.5 h-3.5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 756,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "🖨️ Print PVC Card Now" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 757,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 751,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 744,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "relative flex justify-center bg-slate-950 p-4 rounded-xl border border-slate-800/80 overflow-hidden shadow-inner",
								children: [/* @__PURE__ */ _jsxDEV("canvas", {
									ref: canvasRef,
									width: CANVAS_WIDTH,
									height: CANVAS_HEIGHT,
									onMouseDown: handleMouseDown,
									onMouseMove: handleMouseMove,
									onMouseUp: handleMouseUp,
									onMouseLeave: handleMouseUp,
									className: "w-full max-w-[460px] h-auto bg-white rounded-lg shadow-2xl cursor-move border border-slate-700",
									style: { aspectRatio: "4/6" }
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 763,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "absolute top-6 left-6 bg-slate-900/90 text-blue-400 border border-blue-500/30 px-2 py-1 rounded text-[10px] font-mono font-bold pointer-events-none",
									children: "CR-80: 85.6 mm × 54 mm"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 776,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 762,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center justify-between pt-2 border-t border-slate-800 text-xs flex-wrap gap-2",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-slate-400",
									children: "✂️ 300 DPI Pre-Aligned Center Cut Mark"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 783,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ _jsxDEV("button", {
										onClick: handleDirectPrint,
										className: "flex items-center gap-1 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs px-3 py-1.5 rounded-lg transition-colors",
										children: [/* @__PURE__ */ _jsxDEV(Printer, { className: "w-3.5 h-3.5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 789,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Print Sheet (Ctrl + P)" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 790,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 785,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("button", {
										onClick: handleDownloadPDF,
										className: "flex items-center gap-1 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs px-3 py-1.5 rounded-lg border border-slate-700 transition-colors",
										children: [/* @__PURE__ */ _jsxDEV(Download, { className: "w-3.5 h-3.5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 796,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: "PDF" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 797,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 792,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 784,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 782,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "mt-3 p-3 rounded-xl bg-slate-950 border border-slate-800/80 text-xs text-slate-300 leading-relaxed flex items-start gap-2.5",
								children: [/* @__PURE__ */ _jsxDEV(HelpCircle, { className: "w-4 h-4 text-blue-400 flex-shrink-0 mt-0.5" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 804,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", { children: [
									/* @__PURE__ */ _jsxDEV("b", {
										className: "text-white",
										children: "Printer Setup Tip:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 806,
										columnNumber: 17
									}, this),
									" Set your printer paper to ",
									/* @__PURE__ */ _jsxDEV("b", { children: "4×6 in (10×15 cm) Photo Paper Glossy" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 806,
										columnNumber: 92
									}, this),
									". In printer properties, select ",
									/* @__PURE__ */ _jsxDEV("b", { children: "High Quality" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 806,
										columnNumber: 167
									}, this),
									" and ",
									/* @__PURE__ */ _jsxDEV("b", { children: "Fit to Printable Area / 100%" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 806,
										columnNumber: 191
									}, this),
									" for exact card dimensions!"
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 805,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 803,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 743,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 742,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 555,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 498,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsUUFBUSxpQkFBaUI7QUFDbkQsU0FDRSxRQUNBLFNBQ0EsVUFDQSxVQU1BLE9BR0EsYUFDQSxLQUNBLFVBQ0Esa0JBRUs7QUFDUCxTQUFTLGFBQWE7QUFDdEIsU0FBUyx5QkFBeUI7QUFDbEMsU0FBUyx1QkFBdUI7OztBQUVoQyxPQUFPLE1BQU0sc0JBQWdDOztDQUUzQyxNQUFNLFlBQVksT0FBaUMsSUFBSTs7Q0FHdkQsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUF3QixJQUFJO0NBQzVELE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBd0IsSUFBSTs7Q0FHNUQsTUFBTSxDQUFDLFlBQVksaUJBQWlCLFNBQTRCLE9BQU87O0NBR3ZFLE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFTO0VBQzdDLEdBQUc7RUFDSCxHQUFHO0VBQ0gsT0FBTztFQUNQLFVBQVU7Q0FDWixDQUFDO0NBRUQsTUFBTSxDQUFDLGFBQWEsa0JBQWtCLFNBQVM7RUFDN0MsR0FBRztFQUNILEdBQUc7RUFDSCxPQUFPO0VBQ1AsVUFBVTtDQUNaLENBQUM7O0NBR0QsTUFBTSxDQUFDLFlBQVksaUJBQWlCLFNBQWlCLENBQUM7Q0FDdEQsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFpQixDQUFDO0NBQ2xELE1BQU0sQ0FBQyxjQUFjLG1CQUFtQixTQUFrQixJQUFJO0NBQzlELE1BQU0sQ0FBQyxnQkFBZ0IscUJBQXFCLFNBQWtCLElBQUk7Q0FDbEUsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQWtCLElBQUk7Q0FDOUQsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQWtCLEtBQUs7Q0FDL0QsTUFBTSxDQUFDLFlBQVksaUJBQWlCLFNBQXdCLElBQUk7O0NBR2hFLE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUFrQixLQUFLO0NBQzNELE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBbUMsSUFBSTtDQUN2RSxNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBbUM7RUFBRSxHQUFHO0VBQUcsR0FBRztDQUFFLENBQUM7OztDQUluRixNQUFNLGVBQWU7Q0FDckIsTUFBTSxnQkFBZ0I7Ozs7O0NBTXRCLE1BQU0sYUFBYTtDQUNuQixNQUFNLGNBQWM7Ozs7Q0FLcEIsTUFBTSxrQkFBa0I7Q0FDeEIsTUFBTSxrQkFBa0I7Q0FDeEIsTUFBTSxnQkFBZ0I7O0NBR3RCLE1BQU0sY0FBYyxPQUFnQyxJQUFJO0NBQ3hELE1BQU0sY0FBYyxPQUFnQyxJQUFJOztDQUd4RCxnQkFBZ0I7RUFDZCxJQUFJLFVBQVU7R0FDWixNQUFNLE1BQU0sSUFBSSxNQUFNO0dBQ3RCLElBQUksY0FBYztHQUNsQixJQUFJLGVBQWU7SUFDakIsWUFBWSxVQUFVO0lBQ3RCLGFBQWE7R0FDZjtHQUNBLElBQUksTUFBTTtFQUNaLE9BQU87R0FDTCxZQUFZLFVBQVU7R0FDdEIsYUFBYTtFQUNmO0NBQ0YsR0FBRyxDQUFDLFFBQVEsQ0FBQzs7Q0FHYixnQkFBZ0I7RUFDZCxJQUFJLFVBQVU7R0FDWixNQUFNLE1BQU0sSUFBSSxNQUFNO0dBQ3RCLElBQUksY0FBYztHQUNsQixJQUFJLGVBQWU7SUFDakIsWUFBWSxVQUFVO0lBQ3RCLGFBQWE7R0FDZjtHQUNBLElBQUksTUFBTTtFQUNaLE9BQU87R0FDTCxZQUFZLFVBQVU7R0FDdEIsYUFBYTtFQUNmO0NBQ0YsR0FBRyxDQUFDLFFBQVEsQ0FBQzs7Q0FHYixnQkFBZ0I7RUFDZCxNQUFNLDBCQUEwQixrQkFBa0I7RUFDbEQsTUFBTSx3QkFBd0Isa0JBQWtCO0VBQ2hELE1BQU0sd0JBQXdCLGtCQUFrQjtFQUVoRCxPQUFPLGlCQUFpQixvQkFBb0IsaUJBQWlCO0VBQzdELE9BQU8saUJBQWlCLGtCQUFrQixlQUFlO0VBQ3pELE9BQU8saUJBQWlCLGtCQUFrQixlQUFlO0VBRXpELGFBQWE7R0FDWCxPQUFPLG9CQUFvQixvQkFBb0IsaUJBQWlCO0dBQ2hFLE9BQU8sb0JBQW9CLGtCQUFrQixlQUFlO0dBQzVELE9BQU8sb0JBQW9CLGtCQUFrQixlQUFlO0VBQzlEO0NBQ0YsQ0FBQzs7Q0FHRCxnQkFBZ0I7RUFDZCxhQUFhO0NBQ2YsR0FBRztFQUFDO0VBQWE7RUFBYTtFQUFZO0VBQVU7RUFBYztFQUFnQjtDQUFZLENBQUM7O0NBRy9GLE1BQU0scUJBQXFCO0VBQ3pCLE1BQU0sU0FBUyxVQUFVO0VBQ3pCLElBQUksQ0FBQyxRQUFRO0VBQ2IsTUFBTSxNQUFNLE9BQU8sV0FBVyxJQUFJO0VBQ2xDLElBQUksQ0FBQyxLQUFLOztFQUdWLElBQUksWUFBWTtFQUNoQixJQUFJLFNBQVMsR0FBRyxHQUFHLGNBQWMsYUFBYTs7RUFHOUMsTUFBTSxZQUFZLGNBQWMsTUFBTSxXQUFXLGNBQWMsTUFBTSxTQUFTOztFQUc5RSxlQUNFLEtBQ0EsWUFBWSxTQUNaLGdCQUFnQixZQUFZLEdBQzVCLGtCQUFrQixZQUFZLEdBQzlCLFlBQVksT0FDWixZQUFZLFVBQ1osa0JBQ0EsU0FDRjs7RUFHQSxlQUNFLEtBQ0EsWUFBWSxTQUNaLGdCQUFnQixZQUFZLEdBQzVCLGtCQUFrQixZQUFZLEdBQzlCLFlBQVksT0FDWixZQUFZLFVBQ1osaUJBQ0EsU0FDRjs7RUFHQSxJQUFJLGNBQWM7R0FDaEIsSUFBSSxLQUFLO0dBQ1QsSUFBSSxjQUFjO0dBQ2xCLElBQUksWUFBWTtHQUNoQixJQUFJLFlBQVksQ0FBQyxHQUFHLENBQUMsQ0FBQzs7R0FHdEIsTUFBTSxRQUFRLGtCQUFrQixjQUFjLElBQUksa0JBQWtCLGNBQWMsS0FBSztHQUN2RixJQUFJLFVBQVU7R0FDZCxJQUFJLE9BQU8sSUFBSSxJQUFJO0dBQ25CLElBQUksT0FBTyxlQUFlLElBQUksSUFBSTtHQUNsQyxJQUFJLE9BQU87O0dBR1gsSUFBSSxZQUFZLENBQUMsQ0FBQztHQUNsQixJQUFJLFlBQVk7R0FDaEIsSUFBSSxPQUFPO0dBQ1gsSUFBSSxZQUFZO0dBQ2hCLElBQUksU0FBUyxnQ0FBZ0MsZUFBZSxHQUFHLE9BQU8sRUFBRTs7R0FHeEUsY0FBYyxLQUFLLElBQUksRUFBRTtHQUN6QixjQUFjLEtBQUssZUFBZSxJQUFJLEVBQUU7R0FDeEMsY0FBYyxLQUFLLElBQUksZ0JBQWdCLEVBQUU7R0FDekMsY0FBYyxLQUFLLGVBQWUsSUFBSSxnQkFBZ0IsRUFBRTtHQUV4RCxJQUFJLFFBQVE7RUFDZDtDQUNGO0NBRUEsTUFBTSxpQkFBaUIsS0FBK0IsR0FBVyxNQUFjO0VBQzdFLElBQUksY0FBYztFQUNsQixJQUFJLFlBQVk7RUFDaEIsSUFBSSxVQUFVO0VBQ2QsSUFBSSxPQUFPLElBQUksSUFBSSxDQUFDO0VBQ3BCLElBQUksT0FBTyxJQUFJLElBQUksQ0FBQztFQUNwQixJQUFJLE9BQU8sR0FBRyxJQUFJLEVBQUU7RUFDcEIsSUFBSSxPQUFPLEdBQUcsSUFBSSxFQUFFO0VBQ3BCLElBQUksT0FBTztDQUNiO0NBRUEsTUFBTSxrQkFDSixLQUNBLEtBQ0EsU0FDQSxTQUNBLE9BQ0EsVUFDQSxrQkFDQSxXQUNHO0VBQ0gsTUFBTSxJQUFJO0VBQ1YsTUFBTSxJQUFJO0VBQ1YsTUFBTSxPQUFPLFVBQVUsSUFBSTtFQUMzQixNQUFNLE1BQU0sVUFBVSxJQUFJO0VBRTFCLElBQUksS0FBSzs7RUFHVCxNQUFNLFNBQVMsaUJBQWlCLEtBQUs7RUFDckMsSUFBSSxVQUFVO0VBQ2QsSUFBSSxVQUFVLE1BQU0sS0FBSyxHQUFHLEdBQUcsTUFBTTtFQUVyQyxJQUFJLEtBQUs7R0FDUCxJQUFJLEtBQUs7O0dBRVQsSUFBSSxLQUFLOztHQUdULElBQUksU0FBUzs7R0FHYixJQUFJLFVBQVUsU0FBUyxPQUFPO0dBQzlCLElBQUksT0FBUSxXQUFXLEtBQUssS0FBTSxHQUFHO0dBQ3JDLElBQUksTUFBTSxPQUFPLEtBQUs7O0dBR3RCLElBQUksVUFBVSxLQUFLLENBQUMsSUFBSSxHQUFHLENBQUMsSUFBSSxHQUFHLEdBQUcsQ0FBQztHQUN2QyxJQUFJLFFBQVE7RUFDZCxPQUFPOztHQUVMLElBQUksWUFBWTtHQUNoQixJQUFJLEtBQUs7R0FFVCxJQUFJLGNBQWM7R0FDbEIsSUFBSSxZQUFZO0dBQ2hCLElBQUksWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDO0dBQ3ZCLElBQUksT0FBTzs7R0FHWCxJQUFJLFlBQVk7R0FDaEIsSUFBSSxPQUFPO0dBQ1gsSUFBSSxZQUFZO0dBQ2hCLElBQUksU0FBUyxrQkFBa0IsU0FBUyxVQUFVLEVBQUU7R0FDcEQsSUFBSSxPQUFPO0dBQ1gsSUFBSSxZQUFZO0dBQ2hCLElBQUksU0FBUyxtQ0FBbUMsU0FBUyxVQUFVLEVBQUU7R0FDckUsSUFBSSxTQUFTLHFDQUFxQyxTQUFTLFVBQVUsRUFBRTtFQUN6RTs7RUFHQSxJQUFJLGNBQWM7R0FDaEIsSUFBSSxVQUFVO0dBQ2QsSUFBSSxVQUFVLE1BQU0sS0FBSyxHQUFHLEdBQUcsTUFBTTtHQUNyQyxJQUFJLGNBQWM7R0FDbEIsSUFBSSxZQUFZO0dBQ2hCLElBQUksWUFBWSxDQUFDLENBQUM7R0FDbEIsSUFBSSxPQUFPO0VBQ2I7RUFFQSxJQUFJLFFBQVE7Q0FDZDs7Q0FHQSxNQUFNLG9CQUFvQixHQUF3QyxXQUE4QjtFQUM5RixNQUFNLE9BQU8sRUFBRSxPQUFPLFFBQVE7RUFDOUIsSUFBSSxDQUFDLE1BQU07RUFFWCxNQUFNLFNBQVMsSUFBSSxXQUFXO0VBQzlCLE9BQU8sVUFBVSxVQUFVO0dBQ3pCLE1BQU0sU0FBUyxNQUFNLFFBQVE7R0FDN0IsSUFBSSxXQUFXLFNBQVM7SUFDdEIsWUFBWSxNQUFNO0lBQ2xCLGNBQWMsT0FBTztHQUN2QixPQUFPO0lBQ0wsWUFBWSxNQUFNO0lBQ2xCLGNBQWMsT0FBTztHQUN2QjtFQUNGO0VBQ0EsT0FBTyxjQUFjLElBQUk7RUFDekIsRUFBRSxPQUFPLFFBQVE7Q0FDbkI7O0NBR0EsTUFBTSx3QkFBd0I7RUFDNUIsTUFBTSxVQUFVO0VBQ2hCLFlBQVksUUFBUTtFQUNwQixZQUFZLE9BQU87RUFFbkIsTUFBTSxVQUFVLEVBQUUsR0FBRyxZQUFZO0VBQ2pDLGVBQWUsRUFBRSxHQUFHLFlBQVksQ0FBQztFQUNqQyxlQUFlLE9BQU87Q0FDeEI7O0NBR0EsTUFBTSxxQkFBcUIsUUFBZ0I7RUFDekMsSUFBSSxlQUFlLFNBQVM7R0FDMUIsZ0JBQWUsVUFBUztJQUFFLEdBQUc7SUFBTSxPQUFPO0dBQUksRUFBRTtFQUNsRCxPQUFPO0dBQ0wsZ0JBQWUsVUFBUztJQUFFLEdBQUc7SUFBTSxPQUFPO0dBQUksRUFBRTtFQUNsRDtDQUNGOztDQUdBLE1BQU0sZUFBZSxJQUFZLE9BQWU7RUFDOUMsSUFBSSxlQUFlLFNBQVM7R0FDMUIsZ0JBQWUsVUFBUztJQUFFLEdBQUc7SUFBTSxHQUFHLEtBQUssSUFBSTtJQUFJLEdBQUcsS0FBSyxJQUFJO0dBQUcsRUFBRTtFQUN0RSxPQUFPO0dBQ0wsZ0JBQWUsVUFBUztJQUFFLEdBQUc7SUFBTSxHQUFHLEtBQUssSUFBSTtJQUFJLEdBQUcsS0FBSyxJQUFJO0dBQUcsRUFBRTtFQUN0RTtDQUNGOztDQUdBLE1BQU0scUJBQXFCO0VBQ3pCLElBQUksZUFBZSxTQUFTO0dBQzFCLGdCQUFlLFVBQVM7SUFBRSxHQUFHO0lBQU0sV0FBVyxLQUFLLFdBQVcsTUFBTTtHQUFJLEVBQUU7RUFDNUUsT0FBTztHQUNMLGdCQUFlLFVBQVM7SUFBRSxHQUFHO0lBQU0sV0FBVyxLQUFLLFdBQVcsTUFBTTtHQUFJLEVBQUU7RUFDNUU7Q0FDRjs7Q0FHQSxNQUFNLG9CQUFvQjtFQUN4QixlQUFlO0dBQUUsR0FBRztHQUFHLEdBQUc7R0FBRyxPQUFPO0dBQUssVUFBVTtFQUFFLENBQUM7RUFDdEQsZUFBZTtHQUFFLEdBQUc7R0FBRyxHQUFHO0dBQUcsT0FBTztHQUFLLFVBQVU7RUFBRSxDQUFDO0VBQ3RELGNBQWMsQ0FBQztFQUNmLFlBQVksQ0FBQztDQUNmOztDQUdBLE1BQU0sMEJBQTBCO0VBQzlCLE1BQU0sU0FBUyxVQUFVO0VBQ3pCLElBQUksQ0FBQyxRQUFRO0VBQ2IsZ0JBQWdCLElBQUk7RUFFcEIsSUFBSTtHQUNGLE1BQU0sVUFBVSxPQUFPLFVBQVUsY0FBYyxHQUFJO0dBQ25ELE1BQU0sSUFBSSxTQUFTLGNBQWMsR0FBRztHQUNwQyxFQUFFLE9BQU87R0FDVCxNQUFNLFdBQVcsdUJBQXVCLEtBQUssSUFBSSxFQUFFO0dBQ25ELEVBQUUsV0FBVztHQUNiLEVBQUUsTUFBTTtHQUVSLGtCQUFrQjtJQUNoQixJQUFJLFdBQVcsS0FBSyxJQUFJO0lBQ3hCLE9BQU87SUFDUCxNQUFNO0lBQ04sTUFBTTtJQUNOLFdBQVcsSUFBSSxLQUFLLENBQUMsQ0FBQyxtQkFBbUIsT0FBTztHQUNsRCxDQUFDO0VBQ0gsU0FBUyxHQUFHO0dBQ1YsUUFBUSxNQUFNLENBQUM7RUFDakIsVUFBVTtHQUNSLGdCQUFnQixLQUFLO0VBQ3ZCO0NBQ0Y7O0NBR0EsTUFBTSwwQkFBMEI7RUFDOUIsTUFBTSxTQUFTLFVBQVU7RUFDekIsSUFBSSxDQUFDLFFBQVE7RUFDYixnQkFBZ0IsSUFBSTtFQUVwQixJQUFJO0dBQ0YsTUFBTSxVQUFVLE9BQU8sVUFBVSxjQUFjLEdBQUk7O0dBRW5ELE1BQU0sTUFBTSxJQUFJLE1BQU07SUFDcEIsYUFBYTtJQUNiLE1BQU07SUFDTixRQUFRLENBQUMsR0FBRyxDQUFDO0dBQ2YsQ0FBQztHQUVELElBQUksU0FBUyxTQUFTLFFBQVEsR0FBRyxHQUFHLEdBQUcsQ0FBQztHQUN4QyxNQUFNLFdBQVcsMEJBQTBCLEtBQUssSUFBSSxFQUFFO0dBQ3RELElBQUksS0FBSyxRQUFRO0dBRWpCLGtCQUFrQjtJQUNoQixJQUFJLFdBQVcsS0FBSyxJQUFJO0lBQ3hCLE9BQU87SUFDUCxNQUFNO0lBQ04sTUFBTTtJQUNOLFdBQVcsSUFBSSxLQUFLLENBQUMsQ0FBQyxtQkFBbUIsT0FBTztHQUNsRCxDQUFDO0VBQ0gsU0FBUyxHQUFHO0dBQ1YsUUFBUSxNQUFNLENBQUM7RUFDakIsVUFBVTtHQUNSLGdCQUFnQixLQUFLO0VBQ3ZCO0NBQ0Y7O0NBR0EsTUFBTSwwQkFBMEI7RUFDOUIsTUFBTSxTQUFTLFVBQVU7RUFDekIsSUFBSSxDQUFDLFFBQVE7RUFDYixJQUFJO0dBQ0YsTUFBTSxVQUFVLE9BQU8sVUFBVSxjQUFjLENBQUc7R0FDbEQsZ0JBQWdCLFNBQVM7SUFDdkIsYUFBYTtJQUNiLE9BQU87R0FDVCxDQUFDO0dBQ0QsY0FBYyx1RkFBdUY7R0FDckcsaUJBQWlCLGNBQWMsSUFBSSxHQUFHLEdBQUk7RUFDNUMsU0FBUyxHQUFHO0dBQ1YsUUFBUSxNQUFNLENBQUM7R0FDZixPQUFPLE1BQU07RUFDZjtDQUNGOztDQUdBLE1BQU0sbUJBQW1CLE1BQTJDO0VBQ2xFLE1BQU0sU0FBUyxVQUFVO0VBQ3pCLElBQUksQ0FBQyxRQUFRO0VBQ2IsTUFBTSxPQUFPLE9BQU8sc0JBQXNCO0VBQzFDLE1BQU0sU0FBUyxlQUFlLEtBQUs7RUFDbkMsTUFBTSxTQUFTLGdCQUFnQixLQUFLO0VBRXBDLE1BQU0sVUFBVSxFQUFFLFVBQVUsS0FBSyxRQUFRO0VBQ3pDLE1BQU0sVUFBVSxFQUFFLFVBQVUsS0FBSyxPQUFPOztFQUd4QyxJQUFJLFNBQVMsZ0JBQWdCLEdBQUc7R0FDOUIsWUFBWSxPQUFPO0dBQ25CLGNBQWMsT0FBTztHQUNyQixjQUFjLElBQUk7R0FDbEIsYUFBYTtJQUFFLEdBQUcsU0FBUyxZQUFZO0lBQUcsR0FBRyxTQUFTLFlBQVk7R0FBRSxDQUFDO0VBQ3ZFLE9BQU87R0FDTCxZQUFZLE9BQU87R0FDbkIsY0FBYyxPQUFPO0dBQ3JCLGNBQWMsSUFBSTtHQUNsQixhQUFhO0lBQUUsR0FBRyxTQUFTLFlBQVk7SUFBRyxHQUFHLFNBQVMsWUFBWTtHQUFFLENBQUM7RUFDdkU7Q0FDRjtDQUVBLE1BQU0sbUJBQW1CLE1BQTJDO0VBQ2xFLElBQUksQ0FBQyxjQUFjLENBQUMsVUFBVTtFQUM5QixNQUFNLFNBQVMsVUFBVTtFQUN6QixJQUFJLENBQUMsUUFBUTtFQUNiLE1BQU0sT0FBTyxPQUFPLHNCQUFzQjtFQUMxQyxNQUFNLFNBQVMsZUFBZSxLQUFLO0VBQ25DLE1BQU0sU0FBUyxnQkFBZ0IsS0FBSztFQUVwQyxNQUFNLFVBQVUsRUFBRSxVQUFVLEtBQUssUUFBUTtFQUN6QyxNQUFNLFVBQVUsRUFBRSxVQUFVLEtBQUssT0FBTztFQUV4QyxJQUFJLGFBQWEsU0FBUztHQUN4QixnQkFBZSxVQUFTO0lBQ3RCLEdBQUc7SUFDSCxHQUFHLEtBQUssTUFBTSxTQUFTLFVBQVUsQ0FBQztJQUNsQyxHQUFHLEtBQUssTUFBTSxTQUFTLFVBQVUsQ0FBQztHQUNwQyxFQUFFO0VBQ0osT0FBTztHQUNMLGdCQUFlLFVBQVM7SUFDdEIsR0FBRztJQUNILEdBQUcsS0FBSyxNQUFNLFNBQVMsVUFBVSxDQUFDO0lBQ2xDLEdBQUcsS0FBSyxNQUFNLFNBQVMsVUFBVSxDQUFDO0dBQ3BDLEVBQUU7RUFDSjtDQUNGO0NBRUEsTUFBTSxzQkFBc0I7RUFDMUIsY0FBYyxLQUFLO0VBQ25CLFlBQVksSUFBSTtDQUNsQjtDQUVBLE1BQU0sZ0JBQWdCLGVBQWUsVUFBVSxjQUFjO0NBRTdELE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUVFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUFvQztLQUFpQzs7OztlQUNuRix3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFBOEc7S0FFeEg7Ozs7YUFDSDs7Ozs7Y0FDTCx3QkFBQyxLQUFEO0tBQUcsV0FBVTtlQUFnQztJQUUxQzs7OztZQUNBOzs7O2NBR0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNFLHdCQUFDLFVBQUQ7T0FDRSxTQUFTO09BQ1QsV0FBVTtPQUNWLE9BQU07aUJBSFIsQ0FLRSx3QkFBQyxTQUFELEVBQVMsV0FBVSxxQkFBc0I7Ozs7aUJBQ3pDLHdCQUFDLFFBQUQsWUFBTSw0QkFBK0I7Ozs7ZUFDL0I7Ozs7OztNQUVSLHdCQUFDLFVBQUQ7T0FDRSxTQUFTO09BQ1QsVUFBVTtPQUNWLFdBQVU7T0FDVixPQUFNO2lCQUpSLENBTUUsd0JBQUMsVUFBRCxFQUFVLFdBQVUsVUFBVzs7OztpQkFDL0Isd0JBQUMsUUFBRCxZQUFNLGVBQWtCOzs7O2VBQ2xCOzs7Ozs7TUFFUix3QkFBQyxVQUFEO09BQ0UsU0FBUztPQUNULFVBQVU7T0FDVixXQUFVO09BQ1YsT0FBTTtpQkFKUixDQU1FLHdCQUFDLFVBQUQsRUFBVSxXQUFVLGNBQWU7Ozs7aUJBQ25DLHdCQUFDLFFBQUQsWUFBTSxhQUFnQjs7OztlQUNoQjs7Ozs7O0tBQ0w7Ozs7O1lBQ0Y7Ozs7OztHQUdKLGNBQ0Msd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQsRUFBTyxXQUFVLHlDQUEwQzs7OztjQUMzRCx3QkFBQyxRQUFELFlBQU8sV0FBaUI7Ozs7WUFDckI7Ozs7OztHQUlQLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FFRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBRUUsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUE0RDtRQUF5Qjs7OztrQkFDckcsd0JBQUMsVUFBRDtTQUNFLFNBQVM7U0FDVCxXQUFVO1NBQ1YsT0FBTTttQkFIUixDQUtFLHdCQUFDLGFBQUQsRUFBYSxXQUFVLGNBQWU7Ozs7bUJBQ3RDLHdCQUFDLFFBQUQsWUFBTSxrQkFBcUI7Ozs7aUJBQ3JCOzs7OztnQkFDTDs7Ozs7O09BR0wsd0JBQUMsT0FBRDtRQUFLLFdBQVcsd0NBQ2QsZUFBZSxVQUNYLGdEQUNBO2tCQUhOLENBS0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLFFBQUQsRUFBTSxXQUFVLG1DQUF5Qzs7OztvQkFDekQsd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQStCO1VBQXlCOzs7O2tCQUNyRTs7Ozs7bUJBQ0wsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxVQUFEO1dBQ0UsZUFBZSxnQkFBZSxVQUFTO1lBQUUsR0FBRztZQUFNLFdBQVcsS0FBSyxXQUFXLE1BQU07V0FBSSxFQUFFO1dBQ3pGLFdBQVU7V0FDVixPQUFNO3FCQUhSLENBS0Usd0JBQUMsVUFBRCxFQUFVLFdBQVUseUJBQTBCOzs7O3FCQUM5Qyx3QkFBQyxRQUFELGFBQU8sWUFBWSxVQUFTLEdBQU87Ozs7bUJBQzdCOzs7OztvQkFDUix3QkFBQyxVQUFEO1dBQ0UsZUFBZSxlQUFlO1lBQUUsR0FBRztZQUFHLEdBQUc7WUFBRyxPQUFPO1lBQUssVUFBVTtXQUFFLENBQUM7V0FDckUsV0FBVTtXQUNWLE9BQU07cUJBQ1A7VUFFTzs7OztrQkFDTDs7Ozs7aUJBQ0Y7Ozs7O2tCQUVMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsU0FBRDtVQUFPLFdBQVU7b0JBQWpCO1dBQ0Usd0JBQUMsUUFBRCxFQUFRLFdBQVUsNEJBQTZCOzs7OztXQUMvQyx3QkFBQyxRQUFELFlBQU8sV0FBVywyQkFBMkIsd0JBQThCOzs7OztXQUMzRSx3QkFBQyxTQUFEO1lBQU8sTUFBSztZQUFPLFFBQU87WUFBZSxXQUFXLE1BQU0saUJBQWlCLEdBQUcsT0FBTztZQUFHLFdBQVU7V0FBVTs7Ozs7VUFDdkc7Ozs7O21CQUNOLFlBQ0Msd0JBQUMsVUFBRDtVQUNFLGVBQWUsWUFBWSxJQUFJO1VBQy9CLFdBQVU7VUFDVixPQUFNO29CQUNQO1NBRU87Ozs7aUJBRVA7Ozs7O2dCQUNGOzs7Ozs7T0FHTCx3QkFBQyxPQUFEO1FBQUssV0FBVyx3Q0FDZCxlQUFlLFVBQ1gsZ0RBQ0E7a0JBSE4sQ0FLRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsUUFBRCxFQUFNLFdBQVUscUNBQTJDOzs7O29CQUMzRCx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBK0I7VUFBd0I7Ozs7a0JBQ3BFOzs7OzttQkFDTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLFVBQUQ7V0FDRSxlQUFlLGdCQUFlLFVBQVM7WUFBRSxHQUFHO1lBQU0sV0FBVyxLQUFLLFdBQVcsTUFBTTtXQUFJLEVBQUU7V0FDekYsV0FBVTtXQUNWLE9BQU07cUJBSFIsQ0FLRSx3QkFBQyxVQUFELEVBQVUsV0FBVSx5QkFBMEI7Ozs7cUJBQzlDLHdCQUFDLFFBQUQsYUFBTyxZQUFZLFVBQVMsR0FBTzs7OzttQkFDN0I7Ozs7O29CQUNSLHdCQUFDLFVBQUQ7V0FDRSxlQUFlLGVBQWU7WUFBRSxHQUFHO1lBQUcsR0FBRztZQUFHLE9BQU87WUFBSyxVQUFVO1dBQUUsQ0FBQztXQUNyRSxXQUFVO1dBQ1YsT0FBTTtxQkFDUDtVQUVPOzs7O2tCQUNMOzs7OztpQkFDRjs7Ozs7a0JBRUwsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxTQUFEO1VBQU8sV0FBVTtvQkFBakI7V0FDRSx3QkFBQyxRQUFELEVBQVEsV0FBVSw4QkFBK0I7Ozs7O1dBQ2pELHdCQUFDLFFBQUQsWUFBTyxXQUFXLDBCQUEwQix1QkFBNkI7Ozs7O1dBQ3pFLHdCQUFDLFNBQUQ7WUFBTyxNQUFLO1lBQU8sUUFBTztZQUFlLFdBQVcsTUFBTSxpQkFBaUIsR0FBRyxPQUFPO1lBQUcsV0FBVTtXQUFVOzs7OztVQUN2Rzs7Ozs7bUJBQ04sWUFDQyx3QkFBQyxVQUFEO1VBQ0UsZUFBZSxZQUFZLElBQUk7VUFDL0IsV0FBVTtVQUNWLE9BQU07b0JBQ1A7U0FFTzs7OztpQkFFUDs7Ozs7Z0JBQ0Y7Ozs7OztNQUNGOzs7OztlQUdMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQWtFO01BRTVFOzs7O2dCQUVOLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQWhCLENBQTRDLHdCQUFDLEtBQUQsRUFBSyxXQUFVLDZCQUE4Qjs7OztvQkFBQyxhQUFpQjs7Ozs7bUJBQzNHLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUE0QixhQUFhLElBQUksSUFBSSxlQUFlO1NBQWlCOzs7O2lCQUM5Rjs7Ozs7a0JBQ0wsd0JBQUMsU0FBRDtTQUNFLE1BQUs7U0FDTCxLQUFJO1NBQ0osS0FBSTtTQUNKLE9BQU87U0FDUCxXQUFXLE1BQU0sY0FBYyxTQUFTLEVBQUUsT0FBTyxLQUFLLENBQUM7U0FDdkQsV0FBVTtRQUNYOzs7O2dCQUNFOzs7OztRQUVMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFoQixDQUE0Qyx3QkFBQyxVQUFELEVBQVUsV0FBVSwyQkFBNEI7Ozs7b0JBQUMsV0FBZTs7Ozs7bUJBQzVHLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUE0QixXQUFXLElBQUksSUFBSSxhQUFhO1NBQWU7Ozs7aUJBQ3hGOzs7OztrQkFDTCx3QkFBQyxTQUFEO1NBQ0UsTUFBSztTQUNMLEtBQUk7U0FDSixLQUFJO1NBQ0osT0FBTztTQUNQLFdBQVcsTUFBTSxZQUFZLFNBQVMsRUFBRSxPQUFPLEtBQUssQ0FBQztTQUNyRCxXQUFVO1FBQ1g7Ozs7Z0JBQ0U7Ozs7O1FBRUwsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWY7VUFDRSx3QkFBQyxTQUFEO1dBQU8sV0FBVTtxQkFBakIsQ0FDRSx3QkFBQyxTQUFEO1lBQ0UsTUFBSztZQUNMLFNBQVM7WUFDVCxXQUFXLE1BQU0sZ0JBQWdCLEVBQUUsT0FBTyxPQUFPO1lBQ2pELFdBQVU7V0FDWDs7OztxQkFDRCx3QkFBQyxRQUFELFlBQU0sb0JBQXVCOzs7O21CQUN4Qjs7Ozs7O1VBRVAsd0JBQUMsU0FBRDtXQUFPLFdBQVU7cUJBQWpCLENBQ0Usd0JBQUMsU0FBRDtZQUNFLE1BQUs7WUFDTCxTQUFTO1lBQ1QsV0FBVyxNQUFNLGtCQUFrQixFQUFFLE9BQU8sT0FBTztZQUNuRCxXQUFVO1dBQ1g7Ozs7cUJBQ0Qsd0JBQUMsUUFBRCxZQUFNLHNCQUF5Qjs7OzttQkFDMUI7Ozs7OztVQUVQLHdCQUFDLFNBQUQ7V0FBTyxXQUFVO3FCQUFqQixDQUNFLHdCQUFDLFNBQUQ7WUFDRSxNQUFLO1lBQ0wsU0FBUztZQUNULFdBQVcsTUFBTSxnQkFBZ0IsRUFBRSxPQUFPLE9BQU87WUFDakQsV0FBVTtXQUNYOzs7O3FCQUNELHdCQUFDLFFBQUQsWUFBTSxzQkFBeUI7Ozs7bUJBQzFCOzs7Ozs7U0FDSjs7Ozs7O09BQ0Y7Ozs7O2NBQ0Y7Ozs7O2FBQ0Y7Ozs7O2NBR0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFDYix3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBdUI7U0FBZ0M7Ozs7bUJBQ3ZFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUF1QztTQUFnQzs7OztpQkFDcEY7Ozs7O2tCQUdMLHdCQUFDLFVBQUQ7U0FDRSxTQUFTO1NBQ1QsV0FBVTtTQUNWLE9BQU07bUJBSFIsQ0FLRSx3QkFBQyxTQUFELEVBQVMsV0FBVSxjQUFlOzs7O21CQUNsQyx3QkFBQyxRQUFELFlBQU0seUJBQTRCOzs7O2lCQUM1Qjs7Ozs7Z0JBQ0w7Ozs7OztPQUdMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsVUFBRDtTQUNFLEtBQUs7U0FDTCxPQUFPO1NBQ1AsUUFBUTtTQUNSLGFBQWE7U0FDYixhQUFhO1NBQ2IsV0FBVztTQUNYLGNBQWM7U0FDZCxXQUFVO1NBQ1YsT0FBTyxFQUFFLGFBQWEsTUFBTTtRQUM3Qjs7OztrQkFHRCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBc0o7UUFFaEs7Ozs7Z0JBQ0Y7Ozs7OztPQUdMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQWlCO1FBQTRDOzs7O2tCQUM3RSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLFVBQUQ7VUFDRSxTQUFTO1VBQ1QsV0FBVTtvQkFGWixDQUlFLHdCQUFDLFNBQUQsRUFBUyxXQUFVLGNBQWU7Ozs7b0JBQ2xDLHdCQUFDLFFBQUQsWUFBTSx5QkFBNEI7Ozs7a0JBQzVCOzs7OzttQkFDUix3QkFBQyxVQUFEO1VBQ0UsU0FBUztVQUNULFdBQVU7b0JBRlosQ0FJRSx3QkFBQyxVQUFELEVBQVUsV0FBVSxjQUFlOzs7O29CQUNuQyx3QkFBQyxRQUFELFlBQU0sTUFBUzs7OztrQkFDVDs7Ozs7aUJBQ0w7Ozs7O2dCQUNGOzs7Ozs7T0FHTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLFlBQUQsRUFBWSxXQUFVLDZDQUE4Qzs7OztrQkFDcEUsd0JBQUMsT0FBRDtTQUNFLHdCQUFDLEtBQUQ7VUFBRyxXQUFVO29CQUFhO1NBQXFCOzs7OztTQUFDO1NBQTJCLHdCQUFDLEtBQUQsWUFBRyx1Q0FBdUM7Ozs7O1NBQUM7U0FBZ0Msd0JBQUMsS0FBRCxZQUFHLGVBQWU7Ozs7O1NBQUM7U0FBSyx3QkFBQyxLQUFELFlBQUcsK0JBQStCOzs7OztTQUFDO1FBQzlNOzs7O2dCQUNGOzs7Ozs7TUFDRjs7Ozs7O0lBQ0Y7Ozs7WUFDRjs7Ozs7O0VBQ0Y7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlB2Y1N0dWRpb1ZpZXcudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlUmVmLCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBcbiAgVXBsb2FkLCBcbiAgUHJpbnRlciwgXG4gIERvd25sb2FkLCBcbiAgUm90YXRlQ3csIFxuICBab29tSW4sIFxuICBab29tT3V0LCBcbiAgTW92ZSwgXG4gIFNwYXJrbGVzLCBcbiAgUmVmcmVzaEN3LCBcbiAgQ2hlY2ssIFxuICBTY2lzc29ycywgXG4gIExheWVycywgXG4gIEFycm93VXBEb3duLCBcbiAgU3VuLCBcbiAgQ29udHJhc3QsIFxuICBIZWxwQ2lyY2xlLFxuICBGaWxlVGV4dFxufSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuaW1wb3J0IHsganNQREYgfSBmcm9tICdqc3BkZic7XG5pbXBvcnQgeyBhZGREb3dubG9hZFJlY29yZCB9IGZyb20gJy4uL3V0aWxzL3N0b3JhZ2UnO1xuaW1wb3J0IHsgcHJpbnRJbWFnZVNoZWV0IH0gZnJvbSAnLi4vdXRpbHMvcHJpbnRlcic7XG5cbmV4cG9ydCBjb25zdCBQdmNTdHVkaW9WaWV3OiBSZWFjdC5GQyA9ICgpID0+IHtcbiAgLy8gQ2FudmFzIHJlZmVyZW5jZXNcbiAgY29uc3QgY2FudmFzUmVmID0gdXNlUmVmPEhUTUxDYW52YXNFbGVtZW50IHwgbnVsbD4obnVsbCk7XG5cbiAgLy8gQ2FyZCBpbWFnZXMgKERhdGEgVVJMcyBvciBJbWFnZSBvYmplY3RzKVxuICBjb25zdCBbY2FyZDFTcmMsIHNldENhcmQxU3JjXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbY2FyZDJTcmMsIHNldENhcmQyU3JjXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuXG4gIC8vIEFjdGl2ZSBlZGl0aW5nIGNhcmQ6ICdjYXJkMScgfCAnY2FyZDInXG4gIGNvbnN0IFthY3RpdmVDYXJkLCBzZXRBY3RpdmVDYXJkXSA9IHVzZVN0YXRlPCdjYXJkMScgfCAnY2FyZDInPignY2FyZDEnKTtcblxuICAvLyBBZGp1c3RtZW50cyBwZXIgY2FyZFxuICBjb25zdCBbY2FyZDFDb25maWcsIHNldENhcmQxQ29uZmlnXSA9IHVzZVN0YXRlKHtcbiAgICB4OiAwLFxuICAgIHk6IDAsXG4gICAgc2NhbGU6IDEuMCxcbiAgICByb3RhdGlvbjogMFxuICB9KTtcblxuICBjb25zdCBbY2FyZDJDb25maWcsIHNldENhcmQyQ29uZmlnXSA9IHVzZVN0YXRlKHtcbiAgICB4OiAwLFxuICAgIHk6IDAsXG4gICAgc2NhbGU6IDEuMCxcbiAgICByb3RhdGlvbjogMFxuICB9KTtcblxuICAvLyBHbG9iYWwgY2FyZCBhZGp1c3RtZW50c1xuICBjb25zdCBbYnJpZ2h0bmVzcywgc2V0QnJpZ2h0bmVzc10gPSB1c2VTdGF0ZTxudW1iZXI+KDApO1xuICBjb25zdCBbY29udHJhc3QsIHNldENvbnRyYXN0XSA9IHVzZVN0YXRlPG51bWJlcj4oMCk7XG4gIGNvbnN0IFtzaG93Q3V0TWFya3MsIHNldFNob3dDdXRNYXJrc10gPSB1c2VTdGF0ZTxib29sZWFuPih0cnVlKTtcbiAgY29uc3QgW3JvdW5kZWRDb3JuZXJzLCBzZXRSb3VuZGVkQ29ybmVyc10gPSB1c2VTdGF0ZTxib29sZWFuPih0cnVlKTtcbiAgY29uc3QgW2JvcmRlclN0cm9rZSwgc2V0Qm9yZGVyU3Ryb2tlXSA9IHVzZVN0YXRlPGJvb2xlYW4+KHRydWUpO1xuICBjb25zdCBbaXNQcm9jZXNzaW5nLCBzZXRJc1Byb2Nlc3NpbmddID0gdXNlU3RhdGU8Ym9vbGVhbj4oZmFsc2UpO1xuICBjb25zdCBbcHJpbnRBbGVydCwgc2V0UHJpbnRBbGVydF0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcblxuICAvLyBEcmFnZ2luZyBzdGF0ZSBvbiBjYW52YXNcbiAgY29uc3QgW2lzRHJhZ2dpbmcsIHNldElzRHJhZ2dpbmddID0gdXNlU3RhdGU8Ym9vbGVhbj4oZmFsc2UpO1xuICBjb25zdCBbZHJhZ0NhcmQsIHNldERyYWdDYXJkXSA9IHVzZVN0YXRlPCdjYXJkMScgfCAnY2FyZDInIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IFtkcmFnU3RhcnQsIHNldERyYWdTdGFydF0gPSB1c2VTdGF0ZTx7IHg6IG51bWJlcjsgeTogbnVtYmVyIH0+KHsgeDogMCwgeTogMCB9KTtcblxuICAvLyAzMDAgRFBJIGNvbnN0YW50cyBmb3IgNHg2IGluY2ggcGFwZXI6XG4gIC8vIDQgaW5jaGVzID0gMTIwMCBweCwgNiBpbmNoZXMgPSAxODAwIHB4XG4gIGNvbnN0IENBTlZBU19XSURUSCA9IDEyMDA7XG4gIGNvbnN0IENBTlZBU19IRUlHSFQgPSAxODAwO1xuXG4gIC8vIENSLTgwIGNhcmQgZGltZW5zaW9ucyBpbiBtbTogODUuNm1tIHggNTMuOThtbSAofjMuMzdpbiB4IDIuMTI1aW4pXG4gIC8vIEF0IDMwMCBEUEk6XG4gIC8vIFdpZHRoOiAzLjM3ICogMzAwIOKJiCAxMDExIHB4XG4gIC8vIEhlaWdodDogMi4xMjUgKiAzMDAg4omIIDYzOCBweFxuICBjb25zdCBDQVJEX1dJRFRIID0gMTAxMDtcbiAgY29uc3QgQ0FSRF9IRUlHSFQgPSA2Mzg7XG5cbiAgLy8gUG9zaXRpb24gb24gNHg2IHNoZWV0ICh0d28gY2FyZHMgc3RhY2tlZCB2ZXJ0aWNhbGx5IG9yIGNlbnRlcmVkKVxuICAvLyBUb3AgQ2FyZCBDZW50ZXI6IFggPSA2MDAsIFkgPSA0NjBcbiAgLy8gQm90dG9tIENhcmQgQ2VudGVyOiBYID0gNjAwLCBZID0gMTM0MFxuICBjb25zdCBDQVJEMV9ERUZBVUxUX1kgPSA0NjA7XG4gIGNvbnN0IENBUkQyX0RFRkFVTFRfWSA9IDEzNDA7XG4gIGNvbnN0IENBUkRfQ0VOVEVSX1ggPSA2MDA7XG5cbiAgLy8gUHJlLWxvYWQgaW1hZ2VzIGZvciBjYW52YXMgZHJhd2luZ1xuICBjb25zdCBjYXJkMUltZ1JlZiA9IHVzZVJlZjxIVE1MSW1hZ2VFbGVtZW50IHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IGNhcmQySW1nUmVmID0gdXNlUmVmPEhUTUxJbWFnZUVsZW1lbnQgfCBudWxsPihudWxsKTtcblxuICAvLyBMb2FkIGNhcmQgMSBpbWFnZVxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChjYXJkMVNyYykge1xuICAgICAgY29uc3QgaW1nID0gbmV3IEltYWdlKCk7XG4gICAgICBpbWcuY3Jvc3NPcmlnaW4gPSAnYW5vbnltb3VzJztcbiAgICAgIGltZy5vbmxvYWQgPSAoKSA9PiB7XG4gICAgICAgIGNhcmQxSW1nUmVmLmN1cnJlbnQgPSBpbWc7XG4gICAgICAgIHJlbmRlckNhbnZhcygpO1xuICAgICAgfTtcbiAgICAgIGltZy5zcmMgPSBjYXJkMVNyYztcbiAgICB9IGVsc2Uge1xuICAgICAgY2FyZDFJbWdSZWYuY3VycmVudCA9IG51bGw7XG4gICAgICByZW5kZXJDYW52YXMoKTtcbiAgICB9XG4gIH0sIFtjYXJkMVNyY10pO1xuXG4gIC8vIExvYWQgY2FyZCAyIGltYWdlXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKGNhcmQyU3JjKSB7XG4gICAgICBjb25zdCBpbWcgPSBuZXcgSW1hZ2UoKTtcbiAgICAgIGltZy5jcm9zc09yaWdpbiA9ICdhbm9ueW1vdXMnO1xuICAgICAgaW1nLm9ubG9hZCA9ICgpID0+IHtcbiAgICAgICAgY2FyZDJJbWdSZWYuY3VycmVudCA9IGltZztcbiAgICAgICAgcmVuZGVyQ2FudmFzKCk7XG4gICAgICB9O1xuICAgICAgaW1nLnNyYyA9IGNhcmQyU3JjO1xuICAgIH0gZWxzZSB7XG4gICAgICBjYXJkMkltZ1JlZi5jdXJyZW50ID0gbnVsbDtcbiAgICAgIHJlbmRlckNhbnZhcygpO1xuICAgIH1cbiAgfSwgW2NhcmQyU3JjXSk7XG5cbiAgLy8gR2xvYmFsIEtleWJvYXJkIHNob3J0Y3V0cyBsaXN0ZW5lciAoQ3RybCtQLCBDdHJsK1MsIEN0cmwrSilcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCBoYW5kbGVHbG9iYWxQcmludCA9ICgpID0+IGhhbmRsZURpcmVjdFByaW50KCk7XG4gICAgY29uc3QgaGFuZGxlR2xvYmFsUGRmID0gKCkgPT4gaGFuZGxlRG93bmxvYWRQREYoKTtcbiAgICBjb25zdCBoYW5kbGVHbG9iYWxKcGcgPSAoKSA9PiBoYW5kbGVEb3dubG9hZEpQRygpO1xuXG4gICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ2FwcC1kaXJlY3QtcHJpbnQnLCBoYW5kbGVHbG9iYWxQcmludCk7XG4gICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ2FwcC1kaXJlY3QtcGRmJywgaGFuZGxlR2xvYmFsUGRmKTtcbiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcignYXBwLWRpcmVjdC1qcGcnLCBoYW5kbGVHbG9iYWxKcGcpO1xuXG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKCdhcHAtZGlyZWN0LXByaW50JywgaGFuZGxlR2xvYmFsUHJpbnQpO1xuICAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ2FwcC1kaXJlY3QtcGRmJywgaGFuZGxlR2xvYmFsUGRmKTtcbiAgICAgIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKCdhcHAtZGlyZWN0LWpwZycsIGhhbmRsZUdsb2JhbEpwZyk7XG4gICAgfTtcbiAgfSk7XG5cbiAgLy8gUmUtcmVuZGVyIGNhbnZhcyB3aGVuZXZlciBjb25maWdzIGNoYW5nZVxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIHJlbmRlckNhbnZhcygpO1xuICB9LCBbY2FyZDFDb25maWcsIGNhcmQyQ29uZmlnLCBicmlnaHRuZXNzLCBjb250cmFzdCwgc2hvd0N1dE1hcmtzLCByb3VuZGVkQ29ybmVycywgYm9yZGVyU3Ryb2tlXSk7XG5cbiAgLy8gTWFpbiBSZW5kZXIgRnVuY3Rpb24gdG8gQ2FudmFzIEAgMzAwIERQSVxuICBjb25zdCByZW5kZXJDYW52YXMgPSAoKSA9PiB7XG4gICAgY29uc3QgY2FudmFzID0gY2FudmFzUmVmLmN1cnJlbnQ7XG4gICAgaWYgKCFjYW52YXMpIHJldHVybjtcbiAgICBjb25zdCBjdHggPSBjYW52YXMuZ2V0Q29udGV4dCgnMmQnKTtcbiAgICBpZiAoIWN0eCkgcmV0dXJuO1xuXG4gICAgLy8gQ2xlYXIgYmFja2dyb3VuZCB0byBwdXJlIHdoaXRlIChmb3IgcGhvdG8gcGFwZXIgcHJpbnQpXG4gICAgY3R4LmZpbGxTdHlsZSA9ICcjZmZmZmZmJztcbiAgICBjdHguZmlsbFJlY3QoMCwgMCwgQ0FOVkFTX1dJRFRILCBDQU5WQVNfSEVJR0hUKTtcblxuICAgIC8vIEZpbHRlciBzdHJpbmdcbiAgICBjb25zdCBmaWx0ZXJTdHIgPSBgYnJpZ2h0bmVzcygkezEwMCArIGJyaWdodG5lc3N9JSkgY29udHJhc3QoJHsxMDAgKyBjb250cmFzdH0lKWA7XG5cbiAgICAvLyAxLiBEcmF3IENhcmQgMSAoVG9wIC8gRnJvbnQpXG4gICAgZHJhd1NpbmdsZUNhcmQoXG4gICAgICBjdHgsXG4gICAgICBjYXJkMUltZ1JlZi5jdXJyZW50LFxuICAgICAgQ0FSRF9DRU5URVJfWCArIGNhcmQxQ29uZmlnLngsXG4gICAgICBDQVJEMV9ERUZBVUxUX1kgKyBjYXJkMUNvbmZpZy55LFxuICAgICAgY2FyZDFDb25maWcuc2NhbGUsXG4gICAgICBjYXJkMUNvbmZpZy5yb3RhdGlvbixcbiAgICAgICdDYXJkIDEgKEZyb250KScsXG4gICAgICBmaWx0ZXJTdHJcbiAgICApO1xuXG4gICAgLy8gMi4gRHJhdyBDYXJkIDIgKEJvdHRvbSAvIEJhY2spXG4gICAgZHJhd1NpbmdsZUNhcmQoXG4gICAgICBjdHgsXG4gICAgICBjYXJkMkltZ1JlZi5jdXJyZW50LFxuICAgICAgQ0FSRF9DRU5URVJfWCArIGNhcmQyQ29uZmlnLngsXG4gICAgICBDQVJEMl9ERUZBVUxUX1kgKyBjYXJkMkNvbmZpZy55LFxuICAgICAgY2FyZDJDb25maWcuc2NhbGUsXG4gICAgICBjYXJkMkNvbmZpZy5yb3RhdGlvbixcbiAgICAgICdDYXJkIDIgKEJhY2spJyxcbiAgICAgIGZpbHRlclN0clxuICAgICk7XG5cbiAgICAvLyAzLiBEcmF3IEN1dCBHdWlkZSBMaW5lIGJldHdlZW4gY2FyZHNcbiAgICBpZiAoc2hvd0N1dE1hcmtzKSB7XG4gICAgICBjdHguc2F2ZSgpO1xuICAgICAgY3R4LnN0cm9rZVN0eWxlID0gJyM5NGEzYjgnO1xuICAgICAgY3R4LmxpbmVXaWR0aCA9IDI7XG4gICAgICBjdHguc2V0TGluZURhc2goWzgsIDhdKTtcblxuICAgICAgLy8gSG9yaXpvbnRhbCBjZW50ZXIgY3V0IG1hcmtcbiAgICAgIGNvbnN0IG1pZFkgPSAoQ0FSRDFfREVGQVVMVF9ZICsgQ0FSRF9IRUlHSFQgLyAyICsgQ0FSRDJfREVGQVVMVF9ZIC0gQ0FSRF9IRUlHSFQgLyAyKSAvIDI7XG4gICAgICBjdHguYmVnaW5QYXRoKCk7XG4gICAgICBjdHgubW92ZVRvKDQwLCBtaWRZKTtcbiAgICAgIGN0eC5saW5lVG8oQ0FOVkFTX1dJRFRIIC0gNDAsIG1pZFkpO1xuICAgICAgY3R4LnN0cm9rZSgpO1xuXG4gICAgICAvLyBTY2lzc29yIGluZGljYXRvciB0ZXh0XG4gICAgICBjdHguc2V0TGluZURhc2goW10pO1xuICAgICAgY3R4LmZpbGxTdHlsZSA9ICcjNjQ3NDhiJztcbiAgICAgIGN0eC5mb250ID0gJ2JvbGQgMjBweCBzYW5zLXNlcmlmJztcbiAgICAgIGN0eC50ZXh0QWxpZ24gPSAnY2VudGVyJztcbiAgICAgIGN0eC5maWxsVGV4dCgn4pyCIEN1dCBIZXJlIChGb2xkIC8gU2VwYXJhdGUpJywgQ0FOVkFTX1dJRFRIIC8gMiwgbWlkWSAtIDEyKTtcblxuICAgICAgLy8gU2hlZXQgYm91bmRhcnkgY3JvcCBjb3JuZXJzXG4gICAgICBkcmF3Q3JvcE1hcmtzKGN0eCwgNDAsIDQwKTtcbiAgICAgIGRyYXdDcm9wTWFya3MoY3R4LCBDQU5WQVNfV0lEVEggLSA0MCwgNDApO1xuICAgICAgZHJhd0Nyb3BNYXJrcyhjdHgsIDQwLCBDQU5WQVNfSEVJR0hUIC0gNDApO1xuICAgICAgZHJhd0Nyb3BNYXJrcyhjdHgsIENBTlZBU19XSURUSCAtIDQwLCBDQU5WQVNfSEVJR0hUIC0gNDApO1xuXG4gICAgICBjdHgucmVzdG9yZSgpO1xuICAgIH1cbiAgfTtcblxuICBjb25zdCBkcmF3Q3JvcE1hcmtzID0gKGN0eDogQ2FudmFzUmVuZGVyaW5nQ29udGV4dDJELCB4OiBudW1iZXIsIHk6IG51bWJlcikgPT4ge1xuICAgIGN0eC5zdHJva2VTdHlsZSA9ICcjY2JkNWUxJztcbiAgICBjdHgubGluZVdpZHRoID0gMjtcbiAgICBjdHguYmVnaW5QYXRoKCk7XG4gICAgY3R4Lm1vdmVUbyh4IC0gMjAsIHkpO1xuICAgIGN0eC5saW5lVG8oeCArIDIwLCB5KTtcbiAgICBjdHgubW92ZVRvKHgsIHkgLSAyMCk7XG4gICAgY3R4LmxpbmVUbyh4LCB5ICsgMjApO1xuICAgIGN0eC5zdHJva2UoKTtcbiAgfTtcblxuICBjb25zdCBkcmF3U2luZ2xlQ2FyZCA9IChcbiAgICBjdHg6IENhbnZhc1JlbmRlcmluZ0NvbnRleHQyRCxcbiAgICBpbWc6IEhUTUxJbWFnZUVsZW1lbnQgfCBudWxsLFxuICAgIGNlbnRlclg6IG51bWJlcixcbiAgICBjZW50ZXJZOiBudW1iZXIsXG4gICAgc2NhbGU6IG51bWJlcixcbiAgICByb3RhdGlvbjogbnVtYmVyLFxuICAgIHBsYWNlaG9sZGVyTGFiZWw6IHN0cmluZyxcbiAgICBmaWx0ZXI6IHN0cmluZ1xuICApID0+IHtcbiAgICBjb25zdCB3ID0gQ0FSRF9XSURUSDtcbiAgICBjb25zdCBoID0gQ0FSRF9IRUlHSFQ7XG4gICAgY29uc3QgbGVmdCA9IGNlbnRlclggLSB3IC8gMjtcbiAgICBjb25zdCB0b3AgPSBjZW50ZXJZIC0gaCAvIDI7XG5cbiAgICBjdHguc2F2ZSgpO1xuXG4gICAgLy8gUm91bmRlZCByZWN0YW5nbGUgcGF0aCBmb3IgQ1ItODAgY2FyZCAoc3RhbmRhcmQgfjNtbSAvIDM2cHggcmFkaXVzIEAgMzAwRFBJKVxuICAgIGNvbnN0IHJhZGl1cyA9IHJvdW5kZWRDb3JuZXJzID8gMzYgOiAwO1xuICAgIGN0eC5iZWdpblBhdGgoKTtcbiAgICBjdHgucm91bmRSZWN0KGxlZnQsIHRvcCwgdywgaCwgcmFkaXVzKTtcblxuICAgIGlmIChpbWcpIHtcbiAgICAgIGN0eC5zYXZlKCk7XG4gICAgICAvLyBDbGlwIGltYWdlIHRvIGNhcmQgYm91bmRhcnlcbiAgICAgIGN0eC5jbGlwKCk7XG5cbiAgICAgIC8vIEFwcGx5IGJyaWdodG5lc3MgJiBjb250cmFzdCBmaWx0ZXJzXG4gICAgICBjdHguZmlsdGVyID0gZmlsdGVyO1xuXG4gICAgICAvLyBUcmFuc2Zvcm0gZm9yIHBvc2l0aW9uLCBzY2FsZSAmIHJvdGF0aW9uXG4gICAgICBjdHgudHJhbnNsYXRlKGNlbnRlclgsIGNlbnRlclkpO1xuICAgICAgY3R4LnJvdGF0ZSgocm90YXRpb24gKiBNYXRoLlBJKSAvIDE4MCk7XG4gICAgICBjdHguc2NhbGUoc2NhbGUsIHNjYWxlKTtcblxuICAgICAgLy8gRHJhdyBpbWFnZSBjZW50ZXJlZFxuICAgICAgY3R4LmRyYXdJbWFnZShpbWcsIC13IC8gMiwgLWggLyAyLCB3LCBoKTtcbiAgICAgIGN0eC5yZXN0b3JlKCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIC8vIEVtcHR5IHBsYWNlaG9sZGVyIHNsb3RcbiAgICAgIGN0eC5maWxsU3R5bGUgPSAnI2Y4ZmFmYyc7XG4gICAgICBjdHguZmlsbCgpO1xuXG4gICAgICBjdHguc3Ryb2tlU3R5bGUgPSAnI2NiZDVlMSc7XG4gICAgICBjdHgubGluZVdpZHRoID0gNDtcbiAgICAgIGN0eC5zZXRMaW5lRGFzaChbMTIsIDhdKTtcbiAgICAgIGN0eC5zdHJva2UoKTtcblxuICAgICAgLy8gUGxhY2Vob2xkZXIgdGV4dFxuICAgICAgY3R4LmZpbGxTdHlsZSA9ICcjNjQ3NDhiJztcbiAgICAgIGN0eC5mb250ID0gJ2JvbGQgMzZweCBzYW5zLXNlcmlmJztcbiAgICAgIGN0eC50ZXh0QWxpZ24gPSAnY2VudGVyJztcbiAgICAgIGN0eC5maWxsVGV4dChwbGFjZWhvbGRlckxhYmVsLCBjZW50ZXJYLCBjZW50ZXJZIC0gMjApO1xuICAgICAgY3R4LmZvbnQgPSAnMjRweCBzYW5zLXNlcmlmJztcbiAgICAgIGN0eC5maWxsU3R5bGUgPSAnIzk0YTNiOCc7XG4gICAgICBjdHguZmlsbFRleHQoJ0Ryb3AgaW1hZ2Ugb3IgUERGIHRvIHBsYWNlIGhlcmUnLCBjZW50ZXJYLCBjZW50ZXJZICsgMzApO1xuICAgICAgY3R4LmZpbGxUZXh0KCdDUi04MCBTdGFuZGFyZDogODUuNiBtbSDDlyA1NC4wIG1tJywgY2VudGVyWCwgY2VudGVyWSArIDcwKTtcbiAgICB9XG5cbiAgICAvLyBCb3JkZXIgbGluZSBhcm91bmQgY2FyZFxuICAgIGlmIChib3JkZXJTdHJva2UpIHtcbiAgICAgIGN0eC5iZWdpblBhdGgoKTtcbiAgICAgIGN0eC5yb3VuZFJlY3QobGVmdCwgdG9wLCB3LCBoLCByYWRpdXMpO1xuICAgICAgY3R4LnN0cm9rZVN0eWxlID0gJyMxZTI5M2InO1xuICAgICAgY3R4LmxpbmVXaWR0aCA9IDI7XG4gICAgICBjdHguc2V0TGluZURhc2goW10pO1xuICAgICAgY3R4LnN0cm9rZSgpO1xuICAgIH1cblxuICAgIGN0eC5yZXN0b3JlKCk7XG4gIH07XG5cbiAgLy8gVXBsb2FkIGhhbmRsZXIgZm9yIENhcmQgMSBvciBDYXJkIDJcbiAgY29uc3QgaGFuZGxlRmlsZVVwbG9hZCA9IChlOiBSZWFjdC5DaGFuZ2VFdmVudDxIVE1MSW5wdXRFbGVtZW50PiwgdGFyZ2V0OiAnY2FyZDEnIHwgJ2NhcmQyJykgPT4ge1xuICAgIGNvbnN0IGZpbGUgPSBlLnRhcmdldC5maWxlcz8uWzBdO1xuICAgIGlmICghZmlsZSkgcmV0dXJuO1xuXG4gICAgY29uc3QgcmVhZGVyID0gbmV3IEZpbGVSZWFkZXIoKTtcbiAgICByZWFkZXIub25sb2FkID0gKGV2ZW50KSA9PiB7XG4gICAgICBjb25zdCByZXN1bHQgPSBldmVudC50YXJnZXQ/LnJlc3VsdCBhcyBzdHJpbmc7XG4gICAgICBpZiAodGFyZ2V0ID09PSAnY2FyZDEnKSB7XG4gICAgICAgIHNldENhcmQxU3JjKHJlc3VsdCk7XG4gICAgICAgIHNldEFjdGl2ZUNhcmQoJ2NhcmQxJyk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBzZXRDYXJkMlNyYyhyZXN1bHQpO1xuICAgICAgICBzZXRBY3RpdmVDYXJkKCdjYXJkMicpO1xuICAgICAgfVxuICAgIH07XG4gICAgcmVhZGVyLnJlYWRBc0RhdGFVUkwoZmlsZSk7XG4gICAgZS50YXJnZXQudmFsdWUgPSAnJztcbiAgfTtcblxuICAvLyBTd2FwIEZyb250ICYgQmFjayBjYXJkc1xuICBjb25zdCBoYW5kbGVTd2FwQ2FyZHMgPSAoKSA9PiB7XG4gICAgY29uc3QgdGVtcFNyYyA9IGNhcmQxU3JjO1xuICAgIHNldENhcmQxU3JjKGNhcmQyU3JjKTtcbiAgICBzZXRDYXJkMlNyYyh0ZW1wU3JjKTtcblxuICAgIGNvbnN0IHRlbXBDZmcgPSB7IC4uLmNhcmQxQ29uZmlnIH07XG4gICAgc2V0Q2FyZDFDb25maWcoeyAuLi5jYXJkMkNvbmZpZyB9KTtcbiAgICBzZXRDYXJkMkNvbmZpZyh0ZW1wQ2ZnKTtcbiAgfTtcblxuICAvLyBTY2FsZSBhZGp1c3RtZW50XG4gIGNvbnN0IGhhbmRsZVNjYWxlQ2hhbmdlID0gKHZhbDogbnVtYmVyKSA9PiB7XG4gICAgaWYgKGFjdGl2ZUNhcmQgPT09ICdjYXJkMScpIHtcbiAgICAgIHNldENhcmQxQ29uZmlnKHByZXYgPT4gKHsgLi4ucHJldiwgc2NhbGU6IHZhbCB9KSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHNldENhcmQyQ29uZmlnKHByZXYgPT4gKHsgLi4ucHJldiwgc2NhbGU6IHZhbCB9KSk7XG4gICAgfVxuICB9O1xuXG4gIC8vIE51ZGdlIGFkanVzdG1lbnRcbiAgY29uc3QgaGFuZGxlTnVkZ2UgPSAoZHg6IG51bWJlciwgZHk6IG51bWJlcikgPT4ge1xuICAgIGlmIChhY3RpdmVDYXJkID09PSAnY2FyZDEnKSB7XG4gICAgICBzZXRDYXJkMUNvbmZpZyhwcmV2ID0+ICh7IC4uLnByZXYsIHg6IHByZXYueCArIGR4LCB5OiBwcmV2LnkgKyBkeSB9KSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHNldENhcmQyQ29uZmlnKHByZXYgPT4gKHsgLi4ucHJldiwgeDogcHJldi54ICsgZHgsIHk6IHByZXYueSArIGR5IH0pKTtcbiAgICB9XG4gIH07XG5cbiAgLy8gUm90YXRlIDkwIGRlZ3JlZXNcbiAgY29uc3QgaGFuZGxlUm90YXRlID0gKCkgPT4ge1xuICAgIGlmIChhY3RpdmVDYXJkID09PSAnY2FyZDEnKSB7XG4gICAgICBzZXRDYXJkMUNvbmZpZyhwcmV2ID0+ICh7IC4uLnByZXYsIHJvdGF0aW9uOiAocHJldi5yb3RhdGlvbiArIDkwKSAlIDM2MCB9KSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHNldENhcmQyQ29uZmlnKHByZXYgPT4gKHsgLi4ucHJldiwgcm90YXRpb246IChwcmV2LnJvdGF0aW9uICsgOTApICUgMzYwIH0pKTtcbiAgICB9XG4gIH07XG5cbiAgLy8gUmVzZXQgY29udHJvbHNcbiAgY29uc3QgaGFuZGxlUmVzZXQgPSAoKSA9PiB7XG4gICAgc2V0Q2FyZDFDb25maWcoeyB4OiAwLCB5OiAwLCBzY2FsZTogMS4wLCByb3RhdGlvbjogMCB9KTtcbiAgICBzZXRDYXJkMkNvbmZpZyh7IHg6IDAsIHk6IDAsIHNjYWxlOiAxLjAsIHJvdGF0aW9uOiAwIH0pO1xuICAgIHNldEJyaWdodG5lc3MoMCk7XG4gICAgc2V0Q29udHJhc3QoMCk7XG4gIH07XG5cbiAgLy8gRG93bmxvYWQgSGlnaC1SZXMgMzAwIERQSSBKUEdcbiAgY29uc3QgaGFuZGxlRG93bmxvYWRKUEcgPSAoKSA9PiB7XG4gICAgY29uc3QgY2FudmFzID0gY2FudmFzUmVmLmN1cnJlbnQ7XG4gICAgaWYgKCFjYW52YXMpIHJldHVybjtcbiAgICBzZXRJc1Byb2Nlc3NpbmcodHJ1ZSk7XG5cbiAgICB0cnkge1xuICAgICAgY29uc3QgZGF0YVVybCA9IGNhbnZhcy50b0RhdGFVUkwoJ2ltYWdlL2pwZWcnLCAwLjk4KTtcbiAgICAgIGNvbnN0IGEgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdhJyk7XG4gICAgICBhLmhyZWYgPSBkYXRhVXJsO1xuICAgICAgY29uc3QgZmlsZU5hbWUgPSBgUFZDX0NhcmRfNHg2XzMwMERQSV8ke0RhdGUubm93KCl9LmpwZ2A7XG4gICAgICBhLmRvd25sb2FkID0gZmlsZU5hbWU7XG4gICAgICBhLmNsaWNrKCk7XG5cbiAgICAgIGFkZERvd25sb2FkUmVjb3JkKHtcbiAgICAgICAgaWQ6IGBwdmMtanBnLSR7RGF0ZS5ub3coKX1gLFxuICAgICAgICB0aXRsZTogZmlsZU5hbWUsXG4gICAgICAgIHR5cGU6ICdQVkMgQ2FyZCBKUEcnLFxuICAgICAgICBzaXplOiAnMTIwMMOXMTgwMCBweCAoMzAwIERQSSknLFxuICAgICAgICB0aW1lc3RhbXA6IG5ldyBEYXRlKCkudG9Mb2NhbGVUaW1lU3RyaW5nKCdlbi1JTicpXG4gICAgICB9KTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBjb25zb2xlLmVycm9yKGUpO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRJc1Byb2Nlc3NpbmcoZmFsc2UpO1xuICAgIH1cbiAgfTtcblxuICAvLyBEb3dubG9hZCAzMDAgRFBJIFBERiAoRXhhY3QgNHg2IGluY2ggcGFwZXIgc2l6ZSlcbiAgY29uc3QgaGFuZGxlRG93bmxvYWRQREYgPSAoKSA9PiB7XG4gICAgY29uc3QgY2FudmFzID0gY2FudmFzUmVmLmN1cnJlbnQ7XG4gICAgaWYgKCFjYW52YXMpIHJldHVybjtcbiAgICBzZXRJc1Byb2Nlc3NpbmcodHJ1ZSk7XG5cbiAgICB0cnkge1xuICAgICAgY29uc3QgZGF0YVVybCA9IGNhbnZhcy50b0RhdGFVUkwoJ2ltYWdlL2pwZWcnLCAwLjk4KTtcbiAgICAgIC8vIDR4NiBpbmNoZXMgaW4gUERGIHBvaW50czogNCAqIDcyID0gMjg4LCA2ICogNzIgPSA0MzJcbiAgICAgIGNvbnN0IHBkZiA9IG5ldyBqc1BERih7XG4gICAgICAgIG9yaWVudGF0aW9uOiAncG9ydHJhaXQnLFxuICAgICAgICB1bml0OiAnaW4nLFxuICAgICAgICBmb3JtYXQ6IFs0LCA2XVxuICAgICAgfSk7XG5cbiAgICAgIHBkZi5hZGRJbWFnZShkYXRhVXJsLCAnSlBFRycsIDAsIDAsIDQsIDYpO1xuICAgICAgY29uc3QgZmlsZU5hbWUgPSBgUFZDX0NhcmRfUHJpbnRhYmxlXzR4Nl8ke0RhdGUubm93KCl9LnBkZmA7XG4gICAgICBwZGYuc2F2ZShmaWxlTmFtZSk7XG5cbiAgICAgIGFkZERvd25sb2FkUmVjb3JkKHtcbiAgICAgICAgaWQ6IGBwdmMtcGRmLSR7RGF0ZS5ub3coKX1gLFxuICAgICAgICB0aXRsZTogZmlsZU5hbWUsXG4gICAgICAgIHR5cGU6ICdQVkMgQ2FyZCBQREYnLFxuICAgICAgICBzaXplOiAnNMOXNiBpbmNoICgzMDAgRFBJKScsXG4gICAgICAgIHRpbWVzdGFtcDogbmV3IERhdGUoKS50b0xvY2FsZVRpbWVTdHJpbmcoJ2VuLUlOJylcbiAgICAgIH0pO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoZSk7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldElzUHJvY2Vzc2luZyhmYWxzZSk7XG4gICAgfVxuICB9O1xuXG4gIC8vIERpcmVjdCBCcm93c2VyIFByaW50IChGb3JtYXR0ZWQgZm9yIDR4NiBwaG90byBwYXBlcilcbiAgY29uc3QgaGFuZGxlRGlyZWN0UHJpbnQgPSAoKSA9PiB7XG4gICAgY29uc3QgY2FudmFzID0gY2FudmFzUmVmLmN1cnJlbnQ7XG4gICAgaWYgKCFjYW52YXMpIHJldHVybjtcbiAgICB0cnkge1xuICAgICAgY29uc3QgZGF0YVVybCA9IGNhbnZhcy50b0RhdGFVUkwoJ2ltYWdlL2pwZWcnLCAxLjApO1xuICAgICAgcHJpbnRJbWFnZVNoZWV0KGRhdGFVcmwsIHtcbiAgICAgICAgcGFwZXJGb3JtYXQ6ICc0eDZfcG9ydHJhaXQnLFxuICAgICAgICB0aXRsZTogJ1BWQ19DYXJkXzR4Nl9QcmludCdcbiAgICAgIH0pO1xuICAgICAgc2V0UHJpbnRBbGVydCgn8J+WqO+4jyBQVkMgQ2FyZCBwcmludCBjb21tYW5kIHNlbnQgdG8gcHJpbnRlciEgKDTDlzYgUGhvdG8gUGFwZXIg4oCiIENSLTgwIEhpZ2ggRGVmaW5pdGlvbiknKTtcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0UHJpbnRBbGVydChudWxsKSwgNDAwMCk7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgY29uc29sZS5lcnJvcihlKTtcbiAgICAgIHdpbmRvdy5wcmludCgpO1xuICAgIH1cbiAgfTtcblxuICAvLyBJbnRlcmFjdGl2ZSBEcmFnIG9uIENhbnZhc1xuICBjb25zdCBoYW5kbGVNb3VzZURvd24gPSAoZTogUmVhY3QuTW91c2VFdmVudDxIVE1MQ2FudmFzRWxlbWVudD4pID0+IHtcbiAgICBjb25zdCBjYW52YXMgPSBjYW52YXNSZWYuY3VycmVudDtcbiAgICBpZiAoIWNhbnZhcykgcmV0dXJuO1xuICAgIGNvbnN0IHJlY3QgPSBjYW52YXMuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gICAgY29uc3Qgc2NhbGVYID0gQ0FOVkFTX1dJRFRIIC8gcmVjdC53aWR0aDtcbiAgICBjb25zdCBzY2FsZVkgPSBDQU5WQVNfSEVJR0hUIC8gcmVjdC5oZWlnaHQ7XG5cbiAgICBjb25zdCBtb3VzZVggPSAoZS5jbGllbnRYIC0gcmVjdC5sZWZ0KSAqIHNjYWxlWDtcbiAgICBjb25zdCBtb3VzZVkgPSAoZS5jbGllbnRZIC0gcmVjdC50b3ApICogc2NhbGVZO1xuXG4gICAgLy8gQ2hlY2sgaWYgY2xpY2tlZCBpbiB0b3AgY2FyZCAoQ2FyZCAxKVxuICAgIGlmIChtb3VzZVkgPCBDQU5WQVNfSEVJR0hUIC8gMikge1xuICAgICAgc2V0RHJhZ0NhcmQoJ2NhcmQxJyk7XG4gICAgICBzZXRBY3RpdmVDYXJkKCdjYXJkMScpO1xuICAgICAgc2V0SXNEcmFnZ2luZyh0cnVlKTtcbiAgICAgIHNldERyYWdTdGFydCh7IHg6IG1vdXNlWCAtIGNhcmQxQ29uZmlnLngsIHk6IG1vdXNlWSAtIGNhcmQxQ29uZmlnLnkgfSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHNldERyYWdDYXJkKCdjYXJkMicpO1xuICAgICAgc2V0QWN0aXZlQ2FyZCgnY2FyZDInKTtcbiAgICAgIHNldElzRHJhZ2dpbmcodHJ1ZSk7XG4gICAgICBzZXREcmFnU3RhcnQoeyB4OiBtb3VzZVggLSBjYXJkMkNvbmZpZy54LCB5OiBtb3VzZVkgLSBjYXJkMkNvbmZpZy55IH0pO1xuICAgIH1cbiAgfTtcblxuICBjb25zdCBoYW5kbGVNb3VzZU1vdmUgPSAoZTogUmVhY3QuTW91c2VFdmVudDxIVE1MQ2FudmFzRWxlbWVudD4pID0+IHtcbiAgICBpZiAoIWlzRHJhZ2dpbmcgfHwgIWRyYWdDYXJkKSByZXR1cm47XG4gICAgY29uc3QgY2FudmFzID0gY2FudmFzUmVmLmN1cnJlbnQ7XG4gICAgaWYgKCFjYW52YXMpIHJldHVybjtcbiAgICBjb25zdCByZWN0ID0gY2FudmFzLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuICAgIGNvbnN0IHNjYWxlWCA9IENBTlZBU19XSURUSCAvIHJlY3Qud2lkdGg7XG4gICAgY29uc3Qgc2NhbGVZID0gQ0FOVkFTX0hFSUdIVCAvIHJlY3QuaGVpZ2h0O1xuXG4gICAgY29uc3QgbW91c2VYID0gKGUuY2xpZW50WCAtIHJlY3QubGVmdCkgKiBzY2FsZVg7XG4gICAgY29uc3QgbW91c2VZID0gKGUuY2xpZW50WSAtIHJlY3QudG9wKSAqIHNjYWxlWTtcblxuICAgIGlmIChkcmFnQ2FyZCA9PT0gJ2NhcmQxJykge1xuICAgICAgc2V0Q2FyZDFDb25maWcocHJldiA9PiAoe1xuICAgICAgICAuLi5wcmV2LFxuICAgICAgICB4OiBNYXRoLnJvdW5kKG1vdXNlWCAtIGRyYWdTdGFydC54KSxcbiAgICAgICAgeTogTWF0aC5yb3VuZChtb3VzZVkgLSBkcmFnU3RhcnQueSlcbiAgICAgIH0pKTtcbiAgICB9IGVsc2Uge1xuICAgICAgc2V0Q2FyZDJDb25maWcocHJldiA9PiAoe1xuICAgICAgICAuLi5wcmV2LFxuICAgICAgICB4OiBNYXRoLnJvdW5kKG1vdXNlWCAtIGRyYWdTdGFydC54KSxcbiAgICAgICAgeTogTWF0aC5yb3VuZChtb3VzZVkgLSBkcmFnU3RhcnQueSlcbiAgICAgIH0pKTtcbiAgICB9XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlTW91c2VVcCA9ICgpID0+IHtcbiAgICBzZXRJc0RyYWdnaW5nKGZhbHNlKTtcbiAgICBzZXREcmFnQ2FyZChudWxsKTtcbiAgfTtcblxuICBjb25zdCBjdXJyZW50Q29uZmlnID0gYWN0aXZlQ2FyZCA9PT0gJ2NhcmQxJyA/IGNhcmQxQ29uZmlnIDogY2FyZDJDb25maWc7XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxuICAgICAgey8qIEhlYWRlciBiYXIgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgc206ZmxleC1yb3cgc206aXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMyBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcC00IHJvdW5kZWQtMnhsIHNoYWRvdy1tZFwiPlxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtZXh0cmFib2xkIHRleHQtd2hpdGVcIj5QVkMgU21hcnQgQ2FyZCBTdHVkaW8gKENSLTgwKTwvaDE+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJiZy1ibHVlLTUwMC8yMCB0ZXh0LWJsdWUtNDAwIGJvcmRlciBib3JkZXItYmx1ZS01MDAvMzAgdGV4dC14cyBweC0yIHB5LTAuNSByb3VuZGVkLWZ1bGwgZm9udC1tb25vIGZvbnQtYm9sZFwiPlxuICAgICAgICAgICAgICAzMDAgRFBJIEhpZ2gtRGVmaW5pdGlvblxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS00MDAgbXQtMC41XCI+XG4gICAgICAgICAgICBTdGFuZGFyZCA0w5c2IGluY2ggc2hlZXQgd2l0aCAyIGNhcmRzIChGcm9udCAmIEJhY2spIOKAoiBTdGFuZGFyZCBDUi04MCA4NS42IG1tIMOXIDU0LjAgbW1cbiAgICAgICAgICA8L3A+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBQcmltYXJ5IEV4cG9ydCBBY3Rpb25zIGZvciBQQyAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBmbGV4LXdyYXBcIj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVEaXJlY3RQcmludH1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGJnLWdyYWRpZW50LXRvLXIgZnJvbS1ibHVlLTYwMCB2aWEtaW5kaWdvLTYwMCB0by1ibHVlLTUwMCBob3Zlcjpmcm9tLWJsdWUtNTAwIGhvdmVyOnRvLWluZGlnby01MDAgdGV4dC13aGl0ZSBmb250LWV4dHJhYm9sZCB0ZXh0LXhzIHB4LTQgcHktMi41IHJvdW5kZWQteGwgc2hhZG93LWxnIHNoYWRvdy1ibHVlLTYwMC8zMCB0cmFuc2l0aW9uLWFsbCBob3ZlcjpzY2FsZS0xMDUgYWN0aXZlOnNjYWxlLTk1IGJvcmRlciBib3JkZXItYmx1ZS00MDAvMzBcIlxuICAgICAgICAgICAgdGl0bGU9XCJEaXJlY3QgUHJpbnQgdG8gRXBzb24gLyBDYW5vbiAoQ3RybCArIFApXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8UHJpbnRlciBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtd2hpdGVcIiAvPlxuICAgICAgICAgICAgPHNwYW4+8J+WqO+4jyBEaXJlY3QgUHJpbnQgUFZDIENhcmQ8L3NwYW4+XG4gICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVEb3dubG9hZFBERn1cbiAgICAgICAgICAgIGRpc2FibGVkPXtpc1Byb2Nlc3Npbmd9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IGJnLWluZGlnby02MDAgaG92ZXI6YmctaW5kaWdvLTUwMCB0ZXh0LXdoaXRlIGZvbnQtYm9sZCB0ZXh0LXhzIHB4LTMuNSBweS0yLjUgcm91bmRlZC14bCBzaGFkb3ctbGcgc2hhZG93LWluZGlnby02MDAvMzAgdHJhbnNpdGlvbi1hbGwgaG92ZXI6c2NhbGUtMTA1IGRpc2FibGVkOm9wYWNpdHktNTBcIlxuICAgICAgICAgICAgdGl0bGU9XCJEb3dubG9hZCBQcmludGFibGUgMzAwIERQSSBQREZcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxEb3dubG9hZCBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgIDxzcGFuPvCfk4QgUERGICg0w5c2KTwvc3Bhbj5cbiAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZURvd25sb2FkSlBHfVxuICAgICAgICAgICAgZGlzYWJsZWQ9e2lzUHJvY2Vzc2luZ31cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgYmctc2xhdGUtODAwIGhvdmVyOmJnLXNsYXRlLTcwMCB0ZXh0LXNsYXRlLTIwMCBob3Zlcjp0ZXh0LXdoaXRlIGZvbnQtYm9sZCB0ZXh0LXhzIHB4LTMgcHktMi41IHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgdHJhbnNpdGlvbi1hbGxcIlxuICAgICAgICAgICAgdGl0bGU9XCJEb3dubG9hZCBIaWdoLVJlcyAxMjAweDE4MDAgSlBHXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8RG93bmxvYWQgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICAgICAgPHNwYW4+8J+WvO+4jyBIRCBKUEc8L3NwYW4+XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBQcmludCBOb3RpZmljYXRpb24gQmFubmVyICovfVxuICAgICAge3ByaW50QWxlcnQgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMyByb3VuZGVkLXhsIGJnLWVtZXJhbGQtNTAwLzEwIGJvcmRlciBib3JkZXItZW1lcmFsZC01MDAvMzAgdGV4dC1lbWVyYWxkLTQwMCB0ZXh0LXhzIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGFuaW1hdGUtaW4gZmFkZS1pblwiPlxuICAgICAgICAgIDxDaGVjayBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtZW1lcmFsZC00MDAgZmxleC1zaHJpbmstMFwiIC8+XG4gICAgICAgICAgPHNwYW4+e3ByaW50QWxlcnR9PC9zcGFuPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIHsvKiBNYWluIER1YWwtUGFuZSBQQyBXb3Jrc3BhY2UgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbGc6Z3JpZC1jb2xzLTEyIGdhcC01IGl0ZW1zLXN0YXJ0XCI+XG4gICAgICAgIHsvKiBMZWZ0IFNpZGU6IENvbnRyb2xzICYgVXBsb2FkcyAoNSBjb2x1bW5zKSAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJsZzpjb2wtc3Bhbi01IHNwYWNlLXktNFwiPlxuICAgICAgICAgIHsvKiBDYXJkIFNsb3RzIChDYXJkIDEgJiBDYXJkIDIpICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwLzkwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtMnhsIHAtNCBzaGFkb3ctbWQgc3BhY2UteS0zXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTMwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5DYXJkIFNsb3RzICYgSW1hZ2VzPC9zcGFuPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlU3dhcENhcmRzfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWJsdWUtNDAwIGhvdmVyOnRleHQtYmx1ZS0zMDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIlxuICAgICAgICAgICAgICAgIHRpdGxlPVwiU3dhcCBGcm9udCBhbmQgQmFjayBDYXJkc1wiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8QXJyb3dVcERvd24gY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICAgICAgICAgIDxzcGFuPlN3YXAgRnJvbnQvQmFjazwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIENhcmQgMSBTbG90ICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2BwLTMgcm91bmRlZC14bCBib3JkZXIgdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgICAgICAgYWN0aXZlQ2FyZCA9PT0gJ2NhcmQxJyBcbiAgICAgICAgICAgICAgICA/ICdiZy1ibHVlLTk1MC8zMCBib3JkZXItYmx1ZS01MDAvNTAgc2hhZG93LXNtJyBcbiAgICAgICAgICAgICAgICA6ICdiZy1zbGF0ZS05NTAvNDAgYm9yZGVyLXNsYXRlLTgwMCBob3Zlcjpib3JkZXItc2xhdGUtNzAwJ1xuICAgICAgICAgICAgfWB9PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi0yXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy0yIGgtMiByb3VuZGVkLWZ1bGwgYmctYmx1ZS01MDBcIj48L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXdoaXRlXCI+Q2FyZCAxIChGcm9udCBTaWRlKTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0Q2FyZDFDb25maWcocHJldiA9PiAoeyAuLi5wcmV2LCByb3RhdGlvbjogKHByZXYucm90YXRpb24gKyA5MCkgJSAzNjAgfSkpfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBweC0yIHB5LTAuNSByb3VuZGVkIGJnLXNsYXRlLTgwMCBob3ZlcjpiZy1zbGF0ZS03MDAgdGV4dC1zbGF0ZS0yMDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIlxuICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIlJvdGF0ZSBDYXJkIDFcIlxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8Um90YXRlQ3cgY2xhc3NOYW1lPVwidy0zIGgtMyB0ZXh0LWFtYmVyLTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPntjYXJkMUNvbmZpZy5yb3RhdGlvbn3CsDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRDYXJkMUNvbmZpZyh7IHg6IDAsIHk6IDAsIHNjYWxlOiAxLjAsIHJvdGF0aW9uOiAwIH0pfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBweC0yIHB5LTAuNSByb3VuZGVkIGJnLXNsYXRlLTgwMCBob3ZlcjpiZy1zbGF0ZS03MDAgdGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC13aGl0ZVwiXG4gICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiUmVzZXQgUG9zaXRpb25cIlxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICBSZXNldFxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZmxleC0xIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIHB5LTIgcHgtMyBiZy1zbGF0ZS04MDAgaG92ZXI6Ymctc2xhdGUtNzUwIHRleHQtc2xhdGUtMjAwIHRleHQteHMgZm9udC1zZW1pYm9sZCByb3VuZGVkLWxnIGN1cnNvci1wb2ludGVyIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHRyYW5zaXRpb24tY29sb3JzXCI+XG4gICAgICAgICAgICAgICAgICA8VXBsb2FkIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtYmx1ZS00MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgPHNwYW4+e2NhcmQxU3JjID8gJ0NoYW5nZSBGcm9udCBQaG90by9QREYnIDogJ1VwbG9hZCBDYXJkIDEgKEZyb250KSd9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJmaWxlXCIgYWNjZXB0PVwiaW1hZ2UvKiwucGRmXCIgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVGaWxlVXBsb2FkKGUsICdjYXJkMScpfSBjbGFzc05hbWU9XCJoaWRkZW5cIiAvPlxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAge2NhcmQxU3JjICYmIChcbiAgICAgICAgICAgICAgICAgIDxidXR0b24gXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldENhcmQxU3JjKG51bGwpfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTIgdGV4dC1yb3NlLTQwMCBob3ZlcjpiZy1yb3NlLTUwMC8xMCByb3VuZGVkLWxnIHRleHQteHNcIlxuICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIlJlbW92ZSBDYXJkIDFcIlxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICDinJVcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBDYXJkIDIgU2xvdCAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgcC0zIHJvdW5kZWQteGwgYm9yZGVyIHRyYW5zaXRpb24tYWxsICR7XG4gICAgICAgICAgICAgIGFjdGl2ZUNhcmQgPT09ICdjYXJkMicgXG4gICAgICAgICAgICAgICAgPyAnYmctYmx1ZS05NTAvMzAgYm9yZGVyLWJsdWUtNTAwLzUwIHNoYWRvdy1zbScgXG4gICAgICAgICAgICAgICAgOiAnYmctc2xhdGUtOTUwLzQwIGJvcmRlci1zbGF0ZS04MDAgaG92ZXI6Ym9yZGVyLXNsYXRlLTcwMCdcbiAgICAgICAgICAgIH1gfT5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItMlwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctMiBoLTIgcm91bmRlZC1mdWxsIGJnLXB1cnBsZS01MDBcIj48L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXdoaXRlXCI+Q2FyZCAyIChCYWNrIFNpZGUpPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRDYXJkMkNvbmZpZyhwcmV2ID0+ICh7IC4uLnByZXYsIHJvdGF0aW9uOiAocHJldi5yb3RhdGlvbiArIDkwKSAlIDM2MCB9KSl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHB4LTIgcHktMC41IHJvdW5kZWQgYmctc2xhdGUtODAwIGhvdmVyOmJnLXNsYXRlLTcwMCB0ZXh0LXNsYXRlLTIwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiXG4gICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiUm90YXRlIENhcmQgMlwiXG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIDxSb3RhdGVDdyBjbGFzc05hbWU9XCJ3LTMgaC0zIHRleHQtYW1iZXItNDAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+e2NhcmQyQ29uZmlnLnJvdGF0aW9ufcKwPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldENhcmQyQ29uZmlnKHsgeDogMCwgeTogMCwgc2NhbGU6IDEuMCwgcm90YXRpb246IDAgfSl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHB4LTIgcHktMC41IHJvdW5kZWQgYmctc2xhdGUtODAwIGhvdmVyOmJnLXNsYXRlLTcwMCB0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXdoaXRlXCJcbiAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJSZXNldCBQb3NpdGlvblwiXG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIFJlc2V0XG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmbGV4LTEgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgcHktMiBweC0zIGJnLXNsYXRlLTgwMCBob3ZlcjpiZy1zbGF0ZS03NTAgdGV4dC1zbGF0ZS0yMDAgdGV4dC14cyBmb250LXNlbWlib2xkIHJvdW5kZWQtbGcgY3Vyc29yLXBvaW50ZXIgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgdHJhbnNpdGlvbi1jb2xvcnNcIj5cbiAgICAgICAgICAgICAgICAgIDxVcGxvYWQgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1wdXJwbGUtNDAwXCIgLz5cbiAgICAgICAgICAgICAgICAgIDxzcGFuPntjYXJkMlNyYyA/ICdDaGFuZ2UgQmFjayBQaG90by9QREYnIDogJ1VwbG9hZCBDYXJkIDIgKEJhY2spJ308L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cImZpbGVcIiBhY2NlcHQ9XCJpbWFnZS8qLC5wZGZcIiBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUZpbGVVcGxvYWQoZSwgJ2NhcmQyJyl9IGNsYXNzTmFtZT1cImhpZGRlblwiIC8+XG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICB7Y2FyZDJTcmMgJiYgKFxuICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0Q2FyZDJTcmMobnVsbCl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMiB0ZXh0LXJvc2UtNDAwIGhvdmVyOmJnLXJvc2UtNTAwLzEwIHJvdW5kZWQtbGcgdGV4dC14c1wiXG4gICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiUmVtb3ZlIENhcmQgMlwiXG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIOKclVxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBDb2xvciAmIFByaW50IFF1YWxpdHkgRW5oYW5jZW1lbnRzICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwLzkwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtMnhsIHAtNCBzaGFkb3ctbWQgc3BhY2UteS0zXCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTMwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgYmxvY2tcIj5cbiAgICAgICAgICAgICAgSW1hZ2UgRW5oYW5jZW1lbnQgJiBMYXlvdXQgR3VpZGVzXG4gICAgICAgICAgICA8L3NwYW4+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zIHRleHQteHNcIj5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIHRleHQtc2xhdGUtNDAwIG1iLTFcIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj48U3VuIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtYW1iZXItNDAwXCIgLz4gQnJpZ2h0bmVzczwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ubyB0ZXh0LXNsYXRlLTIwMFwiPnticmlnaHRuZXNzID4gMCA/IGArJHticmlnaHRuZXNzfWAgOiBicmlnaHRuZXNzfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJyYW5nZVwiXG4gICAgICAgICAgICAgICAgICBtaW49XCItMzBcIlxuICAgICAgICAgICAgICAgICAgbWF4PVwiMzBcIlxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2JyaWdodG5lc3N9XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEJyaWdodG5lc3MocGFyc2VJbnQoZS50YXJnZXQudmFsdWUpKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBhY2NlbnQtYW1iZXItNTAwIGgtMS41IGJnLXNsYXRlLTgwMCByb3VuZGVkLWxnIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gdGV4dC1zbGF0ZS00MDAgbWItMVwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPjxDb250cmFzdCBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LXNreS00MDBcIiAvPiBDb250cmFzdDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ubyB0ZXh0LXNsYXRlLTIwMFwiPntjb250cmFzdCA+IDAgPyBgKyR7Y29udHJhc3R9YCA6IGNvbnRyYXN0fTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJyYW5nZVwiXG4gICAgICAgICAgICAgICAgICBtaW49XCItMzBcIlxuICAgICAgICAgICAgICAgICAgbWF4PVwiMzBcIlxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2NvbnRyYXN0fVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRDb250cmFzdChwYXJzZUludChlLnRhcmdldC52YWx1ZSkpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGFjY2VudC1za3ktNTAwIGgtMS41IGJnLXNsYXRlLTgwMCByb3VuZGVkLWxnIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTIgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTgwMCBncmlkIGdyaWQtY29scy0yIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGN1cnNvci1wb2ludGVyIHRleHQtc2xhdGUtMzAwXCI+XG4gICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17c2hvd0N1dE1hcmtzfVxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNob3dDdXRNYXJrcyhlLnRhcmdldC5jaGVja2VkKX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZCBhY2NlbnQtYmx1ZS02MDBcIlxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIDxzcGFuPuKcgiBDZW50ZXIgQ3V0IExpbmU8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cblxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBjdXJzb3ItcG9pbnRlciB0ZXh0LXNsYXRlLTMwMFwiPlxuICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXG4gICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3JvdW5kZWRDb3JuZXJzfVxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFJvdW5kZWRDb3JuZXJzKGUudGFyZ2V0LmNoZWNrZWQpfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkIGFjY2VudC1ibHVlLTYwMFwiXG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgPHNwYW4+Um91bmRlZCBDUjgwIENvcm5lcjwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxuXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGN1cnNvci1wb2ludGVyIHRleHQtc2xhdGUtMzAwXCI+XG4gICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17Ym9yZGVyU3Ryb2tlfVxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEJvcmRlclN0cm9rZShlLnRhcmdldC5jaGVja2VkKX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZCBhY2NlbnQtYmx1ZS02MDBcIlxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIDxzcGFuPkNhcmQgT3V0bGluZSBCb3JkZXI8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIFJpZ2h0IFNpZGU6IExpdmUgSW50ZXJhY3RpdmUgMzAwIERQSSBDYW52YXMgUHJldmlldyAoNyBjb2x1bW5zKSAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJsZzpjb2wtc3Bhbi03IHNwYWNlLXktM1wiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtMnhsIHAtNCBzaGFkb3cteGxcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTMgdGV4dC14cyBmbGV4LXdyYXAgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXdoaXRlXCI+SW50ZXJhY3RpdmUgNMOXNiBMaXZlIFNoZWV0PC9zcGFuPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNDAwIGZvbnQtbW9ub1wiPigxMjAwIMOXIDE4MDAgcHggQCAzMDAgRFBJKTwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIFxuICAgICAgICAgICAgICB7LyogRGlyZWN0IFByaW50IEJ1dHRvbiBhYm92ZSBDYW52YXMgKi99XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVEaXJlY3RQcmludH1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IGJnLWJsdWUtNjAwIGhvdmVyOmJnLWJsdWUtNTAwIHRleHQtd2hpdGUgZm9udC1leHRyYWJvbGQgdGV4dC14cyBweC0zLjUgcHktMS41IHJvdW5kZWQtbGcgc2hhZG93LW1kIHRyYW5zaXRpb24tYWxsIGhvdmVyOnNjYWxlLTEwNSBhY3RpdmU6c2NhbGUtOTVcIlxuICAgICAgICAgICAgICAgIHRpdGxlPVwiUHJpbnQgUFZDIENhcmQgU2hlZXQgZGlyZWN0bHkgdG8gY29ubmVjdGVkIHByaW50ZXJcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPFByaW50ZXIgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICAgICAgICAgIDxzcGFuPvCflqjvuI8gUHJpbnQgUFZDIENhcmQgTm93PC9zcGFuPlxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogQ2FudmFzIENvbnRhaW5lciB3aXRoIFJ1bGVycyAmIFNoYWRvdyAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgZmxleCBqdXN0aWZ5LWNlbnRlciBiZy1zbGF0ZS05NTAgcC00IHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAvODAgb3ZlcmZsb3ctaGlkZGVuIHNoYWRvdy1pbm5lclwiPlxuICAgICAgICAgICAgICA8Y2FudmFzXG4gICAgICAgICAgICAgICAgcmVmPXtjYW52YXNSZWZ9XG4gICAgICAgICAgICAgICAgd2lkdGg9e0NBTlZBU19XSURUSH1cbiAgICAgICAgICAgICAgICBoZWlnaHQ9e0NBTlZBU19IRUlHSFR9XG4gICAgICAgICAgICAgICAgb25Nb3VzZURvd249e2hhbmRsZU1vdXNlRG93bn1cbiAgICAgICAgICAgICAgICBvbk1vdXNlTW92ZT17aGFuZGxlTW91c2VNb3ZlfVxuICAgICAgICAgICAgICAgIG9uTW91c2VVcD17aGFuZGxlTW91c2VVcH1cbiAgICAgICAgICAgICAgICBvbk1vdXNlTGVhdmU9e2hhbmRsZU1vdXNlVXB9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIG1heC13LVs0NjBweF0gaC1hdXRvIGJnLXdoaXRlIHJvdW5kZWQtbGcgc2hhZG93LTJ4bCBjdXJzb3ItbW92ZSBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMFwiXG4gICAgICAgICAgICAgICAgc3R5bGU9e3sgYXNwZWN0UmF0aW86ICc0LzYnIH19XG4gICAgICAgICAgICAgIC8+XG5cbiAgICAgICAgICAgICAgey8qIFJ1bGVycyAvIERpbWVuc2lvbiBiYWRnZSAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtNiBsZWZ0LTYgYmctc2xhdGUtOTAwLzkwIHRleHQtYmx1ZS00MDAgYm9yZGVyIGJvcmRlci1ibHVlLTUwMC8zMCBweC0yIHB5LTEgcm91bmRlZCB0ZXh0LVsxMHB4XSBmb250LW1vbm8gZm9udC1ib2xkIHBvaW50ZXItZXZlbnRzLW5vbmVcIj5cbiAgICAgICAgICAgICAgICBDUi04MDogODUuNiBtbSDDlyA1NCBtbVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogUXVpY2sgQWN0aW9uIEZvb3RlciBCYXIgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBwdC0yIGJvcmRlci10IGJvcmRlci1zbGF0ZS04MDAgdGV4dC14cyBmbGV4LXdyYXAgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDBcIj7inILvuI8gMzAwIERQSSBQcmUtQWxpZ25lZCBDZW50ZXIgQ3V0IE1hcms8L3NwYW4+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVEaXJlY3RQcmludH1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xIGJnLWJsdWUtNjAwIGhvdmVyOmJnLWJsdWUtNTAwIHRleHQtd2hpdGUgZm9udC1ib2xkIHRleHQteHMgcHgtMyBweS0xLjUgcm91bmRlZC1sZyB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPFByaW50ZXIgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICAgICAgICAgICAgPHNwYW4+UHJpbnQgU2hlZXQgKEN0cmwgKyBQKTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVEb3dubG9hZFBERn1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xIGJnLXNsYXRlLTgwMCBob3ZlcjpiZy1zbGF0ZS03MDAgdGV4dC1zbGF0ZS0yMDAgZm9udC1ib2xkIHRleHQteHMgcHgtMyBweS0xLjUgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPERvd25sb2FkIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cbiAgICAgICAgICAgICAgICAgIDxzcGFuPlBERjwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIEN5YmVyIENhZmUgT3BlcmF0b3IgUHJpbnQgVGlwcyAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMyBwLTMgcm91bmRlZC14bCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAvODAgdGV4dC14cyB0ZXh0LXNsYXRlLTMwMCBsZWFkaW5nLXJlbGF4ZWQgZmxleCBpdGVtcy1zdGFydCBnYXAtMi41XCI+XG4gICAgICAgICAgICAgIDxIZWxwQ2lyY2xlIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1ibHVlLTQwMCBmbGV4LXNocmluay0wIG10LTAuNVwiIC8+XG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGIgY2xhc3NOYW1lPVwidGV4dC13aGl0ZVwiPlByaW50ZXIgU2V0dXAgVGlwOjwvYj4gU2V0IHlvdXIgcHJpbnRlciBwYXBlciB0byA8Yj40w5c2IGluICgxMMOXMTUgY20pIFBob3RvIFBhcGVyIEdsb3NzeTwvYj4uIEluIHByaW50ZXIgcHJvcGVydGllcywgc2VsZWN0IDxiPkhpZ2ggUXVhbGl0eTwvYj4gYW5kIDxiPkZpdCB0byBQcmludGFibGUgQXJlYSAvIDEwMCU8L2I+IGZvciBleGFjdCBjYXJkIGRpbWVuc2lvbnMhXG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59O1xuIl19