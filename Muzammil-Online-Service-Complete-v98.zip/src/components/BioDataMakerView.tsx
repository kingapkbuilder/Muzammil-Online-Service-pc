const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useRef = __vite__cjsImport0_react["useRef"];const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=090625a0";
import { FileText, Printer, Download, Upload, Save, Trash2, Briefcase, Heart, Sparkles } from "/node_modules/.vite/deps/lucide-react.js?v=090625a0";
import { jsPDF } from "/node_modules/.vite/deps/jspdf.js?v=090625a0";
import { addDownloadRecord } from "/src/utils/storage.ts";
import { printHtmlDocument } from "/src/utils/printer.ts";
var _jsxFileName = "/app/applet/src/components/BioDataMakerView.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=090625a0";
export const BioDataMakerView = () => {
	const [formData, setFormData] = useState({
		template: "biodata_hindi",
		fullName: "Shaikh Sameer",
		dob: "15 August 1998",
		mobile: "9561460313",
		email: "sameer.shaikh@gmail.com",
		education: "B.Com Graduate (Pune University)",
		job: "Digital Service Specialist & Accounts",
		income: "₹ 3,50,000 / Year",
		address: "Naya Munshi Shaban Nagar, Main Road, Maharashtra",
		familyDetails: "Father: Businessman\nMother: Homemaker\nBrothers: 1 Elder Brother (Married)\nSisters: 1 Younger Sister",
		customDetails: "Height: 5 Ft 8 In\nBlood Group: B+ve\nHobbies: Reading, Technology, Sports",
		photo: null
	});
	const previewRef = useRef(null);
	const handleInputChange = (field, value) => {
		setFormData((prev) => ({
			...prev,
			[field]: value
		}));
	};
	const handlePhotoUpload = (e) => {
		const file = e.target.files?.[0];
		if (!file) return;
		const reader = new FileReader();
		reader.onload = (event) => {
			setFormData((prev) => ({
				...prev,
				photo: event.target?.result
			}));
		};
		reader.readAsDataURL(file);
		e.target.value = "";
	};
	const handleSaveDraft = () => {
		localStorage.setItem("mos_pc_biodata_draft", JSON.stringify(formData));
		alert("BioData / CV draft saved to local storage.");
	};
	const handleLoadDraft = () => {
		const raw = localStorage.getItem("mos_pc_biodata_draft");
		if (raw) {
			setFormData(JSON.parse(raw));
		} else {
			alert("No saved draft found.");
		}
	};
	const handleClear = () => {
		if (confirm("Clear all form fields?")) {
			setFormData({
				template: "biodata_hindi",
				fullName: "",
				dob: "",
				mobile: "",
				email: "",
				education: "",
				job: "",
				income: "",
				address: "",
				familyDetails: "",
				customDetails: "",
				photo: null
			});
		}
	};
	// Direct Print
	const handlePrint = () => {
		const printArea = previewRef.current;
		if (!printArea) return;
		const pageStyle = `
      @page { size: A4; margin: 10mm; }
      body { font-family: 'Plus Jakarta Sans', system-ui, sans-serif; margin: 0; padding: 0; background: #fff; color: #000; }
      .print-container { width: 100%; max-width: 800px; margin: 0 auto; }
      table { width: 100%; border-collapse: collapse; }
      td { padding: 6px 4px; vertical-align: top; }
    `;
		const htmlBody = `
      <div class="print-container">
        ${printArea.innerHTML}
      </div>
    `;
		printHtmlDocument(htmlBody, `${formData.fullName || "BioData"}_Print`, pageStyle);
	};
	// Download PDF
	const handleDownloadPDF = () => {
		const pdf = new jsPDF({
			orientation: "portrait",
			unit: "mm",
			format: "a4"
		});
		// Simple high quality PDF generation from details
		pdf.setFont("helvetica", "bold");
		pdf.setFontSize(22);
		pdf.setTextColor(30, 58, 138);
		const titleText = formData.template.includes("biodata") ? "BIODATA" : "CURRICULUM VITAE";
		pdf.text(titleText, 105, 20, { align: "center" });
		pdf.setFontSize(16);
		pdf.setTextColor(15, 23, 42);
		pdf.text(formData.fullName || "Candidate Name", 105, 30, { align: "center" });
		pdf.setFontSize(10);
		pdf.setTextColor(100, 116, 139);
		pdf.text(`Phone: ${formData.mobile} | Email: ${formData.email}`, 105, 36, { align: "center" });
		pdf.setDrawColor(37, 99, 235);
		pdf.setLineWidth(.5);
		pdf.line(20, 42, 190, 42);
		let y = 52;
		const addSection = (heading, content) => {
			if (!content.trim()) return;
			pdf.setFont("helvetica", "bold");
			pdf.setFontSize(12);
			pdf.setTextColor(30, 58, 138);
			pdf.text(heading, 20, y);
			y += 6;
			pdf.setFont("helvetica", "normal");
			pdf.setFontSize(10);
			pdf.setTextColor(30, 41, 59);
			const lines = pdf.splitTextToSize(content, 170);
			lines.forEach((line) => {
				pdf.text(line, 20, y);
				y += 5.5;
			});
			y += 4;
		};
		addSection("Personal Details", `Date of Birth: ${formData.dob}\nAddress: ${formData.address}`);
		addSection("Education & Qualifications", formData.education);
		addSection("Occupation & Income", `Occupation: ${formData.job}\nAnnual Income: ${formData.income}`);
		addSection("Family Background", formData.familyDetails);
		addSection("Additional Details", formData.customDetails);
		const fileName = `${formData.fullName.replace(/\s+/g, "_") || "BioData"}_A4.pdf`;
		pdf.save(fileName);
		addDownloadRecord({
			id: `biodata-pdf-${Date.now()}`,
			title: fileName,
			type: "BioData PDF",
			size: "A4 Document",
			timestamp: new Date().toLocaleTimeString("en-IN")
		});
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "space-y-4",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900 border border-slate-800 p-4 rounded-2xl shadow-md",
			children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center gap-2",
				children: [/* @__PURE__ */ _jsxDEV("h1", {
					className: "text-xl font-extrabold text-white",
					children: "CV & BioData Maker Studio"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 186,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("span", {
					className: "bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 text-xs px-2 py-0.5 rounded-full font-mono font-bold",
					children: "Standard A4 Format"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 187,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 185,
				columnNumber: 11
			}, this), /* @__PURE__ */ _jsxDEV("p", {
				className: "text-xs text-slate-400 mt-0.5",
				children: "Create professional job resumes and marriage biodatas in Hindi, English, and Islamic layouts with instant A4 live preview"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 191,
				columnNumber: 11
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 184,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center gap-2",
				children: [
					/* @__PURE__ */ _jsxDEV("button", {
						onClick: handlePrint,
						className: "flex items-center gap-1.5 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs px-3.5 py-2 rounded-xl shadow-lg shadow-blue-600/30 transition-all hover:scale-105",
						children: [/* @__PURE__ */ _jsxDEV(Printer, { className: "w-4 h-4" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 201,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "🖨️ Direct Print" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 202,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 197,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						onClick: handleDownloadPDF,
						className: "flex items-center gap-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs px-3.5 py-2 rounded-xl shadow-lg shadow-indigo-600/30 transition-all hover:scale-105",
						children: [/* @__PURE__ */ _jsxDEV(Download, { className: "w-4 h-4" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 209,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "📄 Download PDF" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 210,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 205,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						onClick: handleSaveDraft,
						className: "p-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl border border-slate-700 text-xs font-semibold",
						title: "Save Draft",
						children: /* @__PURE__ */ _jsxDEV(Save, { className: "w-4 h-4" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 218,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 213,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 196,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 183,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "grid grid-cols-1 lg:grid-cols-12 gap-5 items-start",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "lg:col-span-5 space-y-4",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-md space-y-3",
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "text-xs font-bold text-slate-300 uppercase tracking-wider block",
						children: "Document Template"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 229,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "grid grid-cols-2 gap-2 text-xs",
						children: [
							{
								id: "biodata_hindi",
								label: "Marriage BioData (Hindi)",
								icon: Heart
							},
							{
								id: "biodata_english",
								label: "Marriage BioData (Eng)",
								icon: Heart
							},
							{
								id: "biodata_islamic",
								label: "Islamic BioData",
								icon: Sparkles
							},
							{
								id: "cv_modern",
								label: "Professional Job Resume",
								icon: Briefcase
							}
						].map((tmpl) => {
							const Icon = tmpl.icon;
							return /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => handleInputChange("template", tmpl.id),
								className: `p-2.5 rounded-xl border font-bold flex items-center gap-2 text-left transition-all ${formData.template === tmpl.id ? "bg-indigo-600 text-white border-indigo-500 shadow-md" : "bg-slate-950 text-slate-300 border-slate-800 hover:bg-slate-800"}`,
								children: [/* @__PURE__ */ _jsxDEV(Icon, { className: "w-4 h-4 flex-shrink-0" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 249,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "text-[11px] leading-tight",
									children: tmpl.label
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 250,
									columnNumber: 21
								}, this)]
							}, tmpl.id, true, {
								fileName: _jsxFileName,
								lineNumber: 240,
								columnNumber: 19
							}, this);
						})
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 231,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 228,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-md space-y-3 text-xs",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between border-b border-slate-800 pb-2",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs font-bold text-slate-300 uppercase tracking-wider",
								children: "Candidate Particulars"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 260,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: handleClear,
								className: "text-rose-400 hover:text-rose-300 text-[11px]",
								children: "Clear Form"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 261,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 259,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
							className: "text-slate-400 block mb-1",
							children: "Full Name *"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 267,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("input", {
							type: "text",
							value: formData.fullName,
							onChange: (e) => handleInputChange("fullName", e.target.value),
							placeholder: "Full Name",
							className: "w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-1.5 text-white font-semibold text-sm"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 268,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 266,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "grid grid-cols-2 gap-3",
							children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "text-slate-400 block mb-1",
								children: "Date of Birth"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 279,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								value: formData.dob,
								onChange: (e) => handleInputChange("dob", e.target.value),
								placeholder: "DD/MM/YYYY",
								className: "w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-1.5 text-white font-mono"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 280,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 278,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "text-slate-400 block mb-1",
								children: "Mobile / WhatsApp"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 289,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								value: formData.mobile,
								onChange: (e) => handleInputChange("mobile", e.target.value),
								placeholder: "Mobile number",
								className: "w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-1.5 text-white font-mono"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 290,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 288,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 277,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
							className: "text-slate-400 block mb-1",
							children: "Email Address"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 301,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("input", {
							type: "email",
							value: formData.email,
							onChange: (e) => handleInputChange("email", e.target.value),
							placeholder: "email@example.com",
							className: "w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-1.5 text-white"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 302,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 300,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
							className: "text-slate-400 block mb-1",
							children: "Education / Degrees"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 312,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("input", {
							type: "text",
							value: formData.education,
							onChange: (e) => handleInputChange("education", e.target.value),
							placeholder: "e.g. B.Com, MBA, ITI, 12th Pass",
							className: "w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-1.5 text-white"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 313,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 311,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "grid grid-cols-2 gap-3",
							children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "text-slate-400 block mb-1",
								children: "Job / Occupation"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 324,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								value: formData.job,
								onChange: (e) => handleInputChange("job", e.target.value),
								placeholder: "e.g. Govt Employee, Business",
								className: "w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-1.5 text-white"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 325,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 323,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "text-slate-400 block mb-1",
								children: "Annual Income"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 334,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								value: formData.income,
								onChange: (e) => handleInputChange("income", e.target.value),
								placeholder: "e.g. ₹ 4,00,000 / Year",
								className: "w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-1.5 text-white font-mono"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 335,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 333,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 322,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
							className: "text-slate-400 block mb-1",
							children: "Residential Address"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 346,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("input", {
							type: "text",
							value: formData.address,
							onChange: (e) => handleInputChange("address", e.target.value),
							placeholder: "Full residential address",
							className: "w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-1.5 text-white"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 347,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 345,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
							className: "text-slate-400 block mb-1",
							children: "Family Details"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 357,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("textarea", {
							rows: 3,
							value: formData.familyDetails,
							onChange: (e) => handleInputChange("familyDetails", e.target.value),
							placeholder: "Father name, mother, brothers, sisters...",
							className: "w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white resize-none"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 358,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 356,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
							className: "text-slate-400 block mb-1",
							children: "Additional Information (Height, Gotra, Cast, Skills)"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 368,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("textarea", {
							rows: 2,
							value: formData.customDetails,
							onChange: (e) => handleInputChange("customDetails", e.target.value),
							placeholder: "Height, blood group, hobbies, computer skills...",
							className: "w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white resize-none"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 369,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 367,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
							className: "text-slate-400 block mb-1",
							children: "Candidate Photograph"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 380,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "flex-1 flex items-center justify-center gap-2 py-2 px-3 bg-slate-800 hover:bg-slate-750 text-slate-200 text-xs font-semibold rounded-lg cursor-pointer border border-slate-700",
								children: [
									/* @__PURE__ */ _jsxDEV(Upload, { className: "w-3.5 h-3.5 text-indigo-400" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 383,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("span", { children: formData.photo ? "Change Photo" : "Upload Candidate Photo" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 384,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("input", {
										type: "file",
										accept: "image/*",
										onChange: handlePhotoUpload,
										className: "hidden"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 385,
										columnNumber: 19
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 382,
								columnNumber: 17
							}, this), formData.photo && /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setFormData((prev) => ({
									...prev,
									photo: null
								})),
								className: "p-2 text-rose-400 hover:bg-rose-500/10 rounded-lg",
								children: /* @__PURE__ */ _jsxDEV(Trash2, { className: "w-4 h-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 392,
									columnNumber: 21
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 388,
								columnNumber: 19
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 381,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 379,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 258,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 226,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "lg:col-span-7 space-y-3",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-xl",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center justify-between mb-3 text-xs",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "font-bold text-white flex items-center gap-1.5",
							children: [/* @__PURE__ */ _jsxDEV(FileText, { className: "w-3.5 h-3.5 text-indigo-400" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 405,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Live A4 Document Page Preview" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 406,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 404,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "text-slate-400 font-mono",
							children: "210mm × 297mm (Standard A4)"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 408,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 403,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "bg-slate-950 p-4 rounded-xl border border-slate-800/80 overflow-auto flex justify-center shadow-inner",
						children: /* @__PURE__ */ _jsxDEV("div", {
							ref: previewRef,
							className: "w-full max-w-[500px] bg-white text-slate-900 p-8 shadow-2xl rounded-sm border border-slate-300 font-sans text-xs leading-relaxed select-text",
							style: { minHeight: "680px" },
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "text-center pb-4 border-b-2 border-indigo-700 mb-5 relative",
									children: [
										formData.template === "biodata_islamic" && /* @__PURE__ */ _jsxDEV("div", {
											className: "text-base font-bold text-emerald-800 mb-1 font-serif",
											children: "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 421,
											columnNumber: 21
										}, this),
										formData.template === "biodata_hindi" && /* @__PURE__ */ _jsxDEV("div", {
											className: "text-sm font-bold text-rose-800 mb-1",
											children: "॥ श्री गणेशाय नमः ॥"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 426,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("h2", {
											className: "text-2xl font-black tracking-wider text-indigo-950 uppercase",
											children: formData.template.includes("biodata") ? "BIO DATA" : "CURRICULUM VITAE"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 431,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "text-lg font-bold text-indigo-800 mt-1",
											children: formData.fullName
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 434,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "text-[11px] text-slate-600 mt-0.5",
											children: [
												"Phone: ",
												formData.mobile,
												" ",
												formData.email ? `• Email: ${formData.email}` : ""
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 435,
											columnNumber: 19
										}, this),
										formData.photo && /* @__PURE__ */ _jsxDEV("div", {
											className: "absolute right-0 top-0 w-24 h-32 border-2 border-slate-300 rounded p-1 bg-white shadow-sm",
											children: /* @__PURE__ */ _jsxDEV("img", {
												src: formData.photo,
												alt: "Photo",
												className: "w-full h-full object-cover"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 441,
												columnNumber: 23
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 440,
											columnNumber: 21
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 419,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-4",
									children: [
										/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h4", {
											className: "font-bold text-indigo-900 uppercase text-[11px] tracking-wider border-b border-indigo-100 pb-1 mb-2",
											children: "Personal Details"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 449,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("table", {
											className: "w-full text-xs",
											children: /* @__PURE__ */ _jsxDEV("tbody", { children: [
												/* @__PURE__ */ _jsxDEV("tr", { children: [/* @__PURE__ */ _jsxDEV("td", {
													className: "w-36 font-semibold text-slate-600 py-1",
													children: "Full Name:"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 454,
													columnNumber: 29
												}, this), /* @__PURE__ */ _jsxDEV("td", {
													className: "font-bold text-slate-900",
													children: formData.fullName
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 454,
													columnNumber: 99
												}, this)] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 454,
													columnNumber: 25
												}, this),
												/* @__PURE__ */ _jsxDEV("tr", { children: [/* @__PURE__ */ _jsxDEV("td", {
													className: "font-semibold text-slate-600 py-1",
													children: "Date of Birth:"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 455,
													columnNumber: 29
												}, this), /* @__PURE__ */ _jsxDEV("td", { children: formData.dob }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 455,
													columnNumber: 98
												}, this)] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 455,
													columnNumber: 25
												}, this),
												/* @__PURE__ */ _jsxDEV("tr", { children: [/* @__PURE__ */ _jsxDEV("td", {
													className: "font-semibold text-slate-600 py-1",
													children: "Education:"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 456,
													columnNumber: 29
												}, this), /* @__PURE__ */ _jsxDEV("td", {
													className: "font-semibold text-slate-800",
													children: formData.education
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 456,
													columnNumber: 94
												}, this)] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 456,
													columnNumber: 25
												}, this),
												/* @__PURE__ */ _jsxDEV("tr", { children: [/* @__PURE__ */ _jsxDEV("td", {
													className: "font-semibold text-slate-600 py-1",
													children: "Occupation:"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 457,
													columnNumber: 29
												}, this), /* @__PURE__ */ _jsxDEV("td", { children: formData.job }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 457,
													columnNumber: 95
												}, this)] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 457,
													columnNumber: 25
												}, this),
												/* @__PURE__ */ _jsxDEV("tr", { children: [/* @__PURE__ */ _jsxDEV("td", {
													className: "font-semibold text-slate-600 py-1",
													children: "Annual Income:"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 458,
													columnNumber: 29
												}, this), /* @__PURE__ */ _jsxDEV("td", { children: formData.income }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 458,
													columnNumber: 98
												}, this)] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 458,
													columnNumber: 25
												}, this),
												/* @__PURE__ */ _jsxDEV("tr", { children: [/* @__PURE__ */ _jsxDEV("td", {
													className: "font-semibold text-slate-600 py-1",
													children: "Address:"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 459,
													columnNumber: 29
												}, this), /* @__PURE__ */ _jsxDEV("td", { children: formData.address }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 459,
													columnNumber: 92
												}, this)] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 459,
													columnNumber: 25
												}, this)
											] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 453,
												columnNumber: 23
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 452,
											columnNumber: 21
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 448,
											columnNumber: 19
										}, this),
										formData.familyDetails && /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h4", {
											className: "font-bold text-indigo-900 uppercase text-[11px] tracking-wider border-b border-indigo-100 pb-1 mb-2",
											children: "Family Details"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 466,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "whitespace-pre-line text-slate-700 pl-1",
											children: formData.familyDetails
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 469,
											columnNumber: 23
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 465,
											columnNumber: 21
										}, this),
										formData.customDetails && /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h4", {
											className: "font-bold text-indigo-900 uppercase text-[11px] tracking-wider border-b border-indigo-100 pb-1 mb-2",
											children: "Other Particulars"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 477,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "whitespace-pre-line text-slate-700 pl-1",
											children: formData.customDetails
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 480,
											columnNumber: 23
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 476,
											columnNumber: 21
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 447,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "mt-12 pt-6 flex justify-between items-end border-t border-slate-200 text-[11px] text-slate-500",
									children: [/* @__PURE__ */ _jsxDEV("div", { children: ["Date: ", new Date().toLocaleDateString("en-IN")] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 489,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "text-right",
										children: [/* @__PURE__ */ _jsxDEV("div", { className: "h-8" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 491,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "border-t border-slate-400 w-32 text-center pt-1 font-semibold text-slate-800",
											children: "Signature"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 492,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 490,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 488,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 413,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 412,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 402,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 401,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 224,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 181,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsY0FBYztBQUN4QyxTQUNFLFVBQ0EsU0FDQSxVQUNBLFFBQ0EsTUFFQSxRQUVBLFdBRUEsT0FJQSxnQkFDSztBQUNQLFNBQVMsYUFBYTtBQUV0QixTQUFTLHlCQUF5QjtBQUNsQyxTQUFTLHlCQUF5Qjs7O0FBRWxDLE9BQU8sTUFBTSx5QkFBbUM7Q0FDOUMsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFzQjtFQUNwRCxVQUFVO0VBQ1YsVUFBVTtFQUNWLEtBQUs7RUFDTCxRQUFRO0VBQ1IsT0FBTztFQUNQLFdBQVc7RUFDWCxLQUFLO0VBQ0wsUUFBUTtFQUNSLFNBQVM7RUFDVCxlQUFlO0VBQ2YsZUFBZTtFQUNmLE9BQU87Q0FDVCxDQUFDO0NBRUQsTUFBTSxhQUFhLE9BQThCLElBQUk7Q0FFckQsTUFBTSxxQkFBcUIsT0FBMEIsVUFBa0I7RUFDckUsYUFBWSxVQUFTO0dBQUUsR0FBRztJQUFPLFFBQVE7RUFBTSxFQUFFO0NBQ25EO0NBRUEsTUFBTSxxQkFBcUIsTUFBMkM7RUFDcEUsTUFBTSxPQUFPLEVBQUUsT0FBTyxRQUFRO0VBQzlCLElBQUksQ0FBQyxNQUFNO0VBQ1gsTUFBTSxTQUFTLElBQUksV0FBVztFQUM5QixPQUFPLFVBQVUsVUFBVTtHQUN6QixhQUFZLFVBQVM7SUFBRSxHQUFHO0lBQU0sT0FBTyxNQUFNLFFBQVE7R0FBaUIsRUFBRTtFQUMxRTtFQUNBLE9BQU8sY0FBYyxJQUFJO0VBQ3pCLEVBQUUsT0FBTyxRQUFRO0NBQ25CO0NBRUEsTUFBTSx3QkFBd0I7RUFDNUIsYUFBYSxRQUFRLHdCQUF3QixLQUFLLFVBQVUsUUFBUSxDQUFDO0VBQ3JFLE1BQU0sNENBQTRDO0NBQ3BEO0NBRUEsTUFBTSx3QkFBd0I7RUFDNUIsTUFBTSxNQUFNLGFBQWEsUUFBUSxzQkFBc0I7RUFDdkQsSUFBSSxLQUFLO0dBQ1AsWUFBWSxLQUFLLE1BQU0sR0FBRyxDQUFDO0VBQzdCLE9BQU87R0FDTCxNQUFNLHVCQUF1QjtFQUMvQjtDQUNGO0NBRUEsTUFBTSxvQkFBb0I7RUFDeEIsSUFBSSxRQUFRLHdCQUF3QixHQUFHO0dBQ3JDLFlBQVk7SUFDVixVQUFVO0lBQ1YsVUFBVTtJQUNWLEtBQUs7SUFDTCxRQUFRO0lBQ1IsT0FBTztJQUNQLFdBQVc7SUFDWCxLQUFLO0lBQ0wsUUFBUTtJQUNSLFNBQVM7SUFDVCxlQUFlO0lBQ2YsZUFBZTtJQUNmLE9BQU87R0FDVCxDQUFDO0VBQ0g7Q0FDRjs7Q0FHQSxNQUFNLG9CQUFvQjtFQUN4QixNQUFNLFlBQVksV0FBVztFQUM3QixJQUFJLENBQUMsV0FBVztFQUVoQixNQUFNLFlBQVk7Ozs7Ozs7RUFRbEIsTUFBTSxXQUFXOztVQUVYLFVBQVUsVUFBVTs7O0VBSTFCLGtCQUFrQixVQUFVLEdBQUcsU0FBUyxZQUFZLFVBQVUsU0FBUyxTQUFTO0NBQ2xGOztDQUdBLE1BQU0sMEJBQTBCO0VBQzlCLE1BQU0sTUFBTSxJQUFJLE1BQU07R0FDcEIsYUFBYTtHQUNiLE1BQU07R0FDTixRQUFRO0VBQ1YsQ0FBQzs7RUFHRCxJQUFJLFFBQVEsYUFBYSxNQUFNO0VBQy9CLElBQUksWUFBWSxFQUFFO0VBQ2xCLElBQUksYUFBYSxJQUFJLElBQUksR0FBRztFQUU1QixNQUFNLFlBQVksU0FBUyxTQUFTLFNBQVMsU0FBUyxJQUFJLFlBQVk7RUFDdEUsSUFBSSxLQUFLLFdBQVcsS0FBSyxJQUFJLEVBQUUsT0FBTyxTQUFTLENBQUM7RUFFaEQsSUFBSSxZQUFZLEVBQUU7RUFDbEIsSUFBSSxhQUFhLElBQUksSUFBSSxFQUFFO0VBQzNCLElBQUksS0FBSyxTQUFTLFlBQVksa0JBQWtCLEtBQUssSUFBSSxFQUFFLE9BQU8sU0FBUyxDQUFDO0VBRTVFLElBQUksWUFBWSxFQUFFO0VBQ2xCLElBQUksYUFBYSxLQUFLLEtBQUssR0FBRztFQUM5QixJQUFJLEtBQUssVUFBVSxTQUFTLE9BQU8sWUFBWSxTQUFTLFNBQVMsS0FBSyxJQUFJLEVBQUUsT0FBTyxTQUFTLENBQUM7RUFFN0YsSUFBSSxhQUFhLElBQUksSUFBSSxHQUFHO0VBQzVCLElBQUksYUFBYSxFQUFHO0VBQ3BCLElBQUksS0FBSyxJQUFJLElBQUksS0FBSyxFQUFFO0VBRXhCLElBQUksSUFBSTtFQUVSLE1BQU0sY0FBYyxTQUFpQixZQUFvQjtHQUN2RCxJQUFJLENBQUMsUUFBUSxLQUFLLEdBQUc7R0FDckIsSUFBSSxRQUFRLGFBQWEsTUFBTTtHQUMvQixJQUFJLFlBQVksRUFBRTtHQUNsQixJQUFJLGFBQWEsSUFBSSxJQUFJLEdBQUc7R0FDNUIsSUFBSSxLQUFLLFNBQVMsSUFBSSxDQUFDO0dBQ3ZCLEtBQUs7R0FFTCxJQUFJLFFBQVEsYUFBYSxRQUFRO0dBQ2pDLElBQUksWUFBWSxFQUFFO0dBQ2xCLElBQUksYUFBYSxJQUFJLElBQUksRUFBRTtHQUUzQixNQUFNLFFBQVEsSUFBSSxnQkFBZ0IsU0FBUyxHQUFHO0dBQzlDLE1BQU0sU0FBUyxTQUFpQjtJQUM5QixJQUFJLEtBQUssTUFBTSxJQUFJLENBQUM7SUFDcEIsS0FBSztHQUNQLENBQUM7R0FDRCxLQUFLO0VBQ1A7RUFFQSxXQUFXLG9CQUFvQixrQkFBa0IsU0FBUyxJQUFJLGFBQWEsU0FBUyxTQUFTO0VBQzdGLFdBQVcsOEJBQThCLFNBQVMsU0FBUztFQUMzRCxXQUFXLHVCQUF1QixlQUFlLFNBQVMsSUFBSSxtQkFBbUIsU0FBUyxRQUFRO0VBQ2xHLFdBQVcscUJBQXFCLFNBQVMsYUFBYTtFQUN0RCxXQUFXLHNCQUFzQixTQUFTLGFBQWE7RUFFdkQsTUFBTSxXQUFXLEdBQUcsU0FBUyxTQUFTLFFBQVEsUUFBUSxHQUFHLEtBQUssVUFBVTtFQUN4RSxJQUFJLEtBQUssUUFBUTtFQUVqQixrQkFBa0I7R0FDaEIsSUFBSSxlQUFlLEtBQUssSUFBSTtHQUM1QixPQUFPO0dBQ1AsTUFBTTtHQUNOLE1BQU07R0FDTixXQUFXLElBQUksS0FBSyxDQUFDLENBQUMsbUJBQW1CLE9BQU87RUFDbEQsQ0FBQztDQUNIO0NBRUEsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmLENBRUUsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsTUFBRDtLQUFJLFdBQVU7ZUFBb0M7SUFBNkI7Ozs7Y0FDL0Usd0JBQUMsUUFBRDtLQUFNLFdBQVU7ZUFBb0g7SUFFOUg7Ozs7WUFDSDs7Ozs7YUFDTCx3QkFBQyxLQUFEO0lBQUcsV0FBVTtjQUFnQztHQUUxQzs7OztXQUNBOzs7O2FBRUwsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUNFLHdCQUFDLFVBQUQ7TUFDRSxTQUFTO01BQ1QsV0FBVTtnQkFGWixDQUlFLHdCQUFDLFNBQUQsRUFBUyxXQUFVLFVBQVc7Ozs7Z0JBQzlCLHdCQUFDLFFBQUQsWUFBTSxtQkFBc0I7Ozs7Y0FDdEI7Ozs7OztLQUVSLHdCQUFDLFVBQUQ7TUFDRSxTQUFTO01BQ1QsV0FBVTtnQkFGWixDQUlFLHdCQUFDLFVBQUQsRUFBVSxXQUFVLFVBQVc7Ozs7Z0JBQy9CLHdCQUFDLFFBQUQsWUFBTSxrQkFBcUI7Ozs7Y0FDckI7Ozs7OztLQUVSLHdCQUFDLFVBQUQ7TUFDRSxTQUFTO01BQ1QsV0FBVTtNQUNWLE9BQU07Z0JBRU4sd0JBQUMsTUFBRCxFQUFNLFdBQVUsVUFBVzs7Ozs7S0FDckI7Ozs7O0lBQ0w7Ozs7O1dBQ0Y7Ozs7O1lBR0wsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZixDQUVFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FFRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQWtFO0tBQXVCOzs7O2VBRXpHLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNaO09BQ0M7UUFBRSxJQUFJO1FBQWlCLE9BQU87UUFBNEIsTUFBTTtPQUFNO09BQ3RFO1FBQUUsSUFBSTtRQUFtQixPQUFPO1FBQTBCLE1BQU07T0FBTTtPQUN0RTtRQUFFLElBQUk7UUFBbUIsT0FBTztRQUFtQixNQUFNO09BQVM7T0FDbEU7UUFBRSxJQUFJO1FBQWEsT0FBTztRQUEyQixNQUFNO09BQVU7TUFDdkUsQ0FBQyxDQUFDLEtBQUssU0FBUztPQUNkLE1BQU0sT0FBTyxLQUFLO09BQ2xCLE9BQ0Usd0JBQUMsVUFBRDtRQUVFLGVBQWUsa0JBQWtCLFlBQVksS0FBSyxFQUFFO1FBQ3BELFdBQVcsc0ZBQ1QsU0FBUyxhQUFhLEtBQUssS0FDdkIseURBQ0E7a0JBTlIsQ0FTRSx3QkFBQyxNQUFELEVBQU0sV0FBVSx3QkFBeUI7Ozs7a0JBQ3pDLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUE2QixLQUFLO1FBQVk7Ozs7Z0JBQ3hEO1VBVkQsS0FBSzs7OztjQVVKO01BRVosQ0FBQztLQUNFOzs7O2FBQ0Y7Ozs7O2NBR0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQTREO09BQTJCOzs7O2lCQUN2Ryx3QkFBQyxVQUFEO1FBQVEsU0FBUztRQUFhLFdBQVU7a0JBQWdEO09BRWhGOzs7O2VBQ0w7Ozs7OztNQUVMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO09BQU8sV0FBVTtpQkFBNEI7TUFBa0I7Ozs7Z0JBQy9ELHdCQUFDLFNBQUQ7T0FDRSxNQUFLO09BQ0wsT0FBTyxTQUFTO09BQ2hCLFdBQVcsTUFBTSxrQkFBa0IsWUFBWSxFQUFFLE9BQU8sS0FBSztPQUM3RCxhQUFZO09BQ1osV0FBVTtNQUNYOzs7O2NBQ0U7Ozs7O01BRUwsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQTRCO09BQW9COzs7O2lCQUNqRSx3QkFBQyxTQUFEO1FBQ0UsTUFBSztRQUNMLE9BQU8sU0FBUztRQUNoQixXQUFXLE1BQU0sa0JBQWtCLE9BQU8sRUFBRSxPQUFPLEtBQUs7UUFDeEQsYUFBWTtRQUNaLFdBQVU7T0FDWDs7OztlQUNFOzs7O2lCQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1FBQU8sV0FBVTtrQkFBNEI7T0FBd0I7Ozs7aUJBQ3JFLHdCQUFDLFNBQUQ7UUFDRSxNQUFLO1FBQ0wsT0FBTyxTQUFTO1FBQ2hCLFdBQVcsTUFBTSxrQkFBa0IsVUFBVSxFQUFFLE9BQU8sS0FBSztRQUMzRCxhQUFZO1FBQ1osV0FBVTtPQUNYOzs7O2VBQ0U7Ozs7ZUFDRjs7Ozs7O01BRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7T0FBTyxXQUFVO2lCQUE0QjtNQUFvQjs7OztnQkFDakUsd0JBQUMsU0FBRDtPQUNFLE1BQUs7T0FDTCxPQUFPLFNBQVM7T0FDaEIsV0FBVyxNQUFNLGtCQUFrQixTQUFTLEVBQUUsT0FBTyxLQUFLO09BQzFELGFBQVk7T0FDWixXQUFVO01BQ1g7Ozs7Y0FDRTs7Ozs7TUFFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtPQUFPLFdBQVU7aUJBQTRCO01BQTBCOzs7O2dCQUN2RSx3QkFBQyxTQUFEO09BQ0UsTUFBSztPQUNMLE9BQU8sU0FBUztPQUNoQixXQUFXLE1BQU0sa0JBQWtCLGFBQWEsRUFBRSxPQUFPLEtBQUs7T0FDOUQsYUFBWTtPQUNaLFdBQVU7TUFDWDs7OztjQUNFOzs7OztNQUVMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7UUFBTyxXQUFVO2tCQUE0QjtPQUF1Qjs7OztpQkFDcEUsd0JBQUMsU0FBRDtRQUNFLE1BQUs7UUFDTCxPQUFPLFNBQVM7UUFDaEIsV0FBVyxNQUFNLGtCQUFrQixPQUFPLEVBQUUsT0FBTyxLQUFLO1FBQ3hELGFBQVk7UUFDWixXQUFVO09BQ1g7Ozs7ZUFDRTs7OztpQkFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQTRCO09BQW9COzs7O2lCQUNqRSx3QkFBQyxTQUFEO1FBQ0UsTUFBSztRQUNMLE9BQU8sU0FBUztRQUNoQixXQUFXLE1BQU0sa0JBQWtCLFVBQVUsRUFBRSxPQUFPLEtBQUs7UUFDM0QsYUFBWTtRQUNaLFdBQVU7T0FDWDs7OztlQUNFOzs7O2VBQ0Y7Ozs7OztNQUVMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO09BQU8sV0FBVTtpQkFBNEI7TUFBMEI7Ozs7Z0JBQ3ZFLHdCQUFDLFNBQUQ7T0FDRSxNQUFLO09BQ0wsT0FBTyxTQUFTO09BQ2hCLFdBQVcsTUFBTSxrQkFBa0IsV0FBVyxFQUFFLE9BQU8sS0FBSztPQUM1RCxhQUFZO09BQ1osV0FBVTtNQUNYOzs7O2NBQ0U7Ozs7O01BRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7T0FBTyxXQUFVO2lCQUE0QjtNQUFxQjs7OztnQkFDbEUsd0JBQUMsWUFBRDtPQUNFLE1BQU07T0FDTixPQUFPLFNBQVM7T0FDaEIsV0FBVyxNQUFNLGtCQUFrQixpQkFBaUIsRUFBRSxPQUFPLEtBQUs7T0FDbEUsYUFBWTtPQUNaLFdBQVU7TUFDWDs7OztjQUNFOzs7OztNQUVMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO09BQU8sV0FBVTtpQkFBNEI7TUFBMkQ7Ozs7Z0JBQ3hHLHdCQUFDLFlBQUQ7T0FDRSxNQUFNO09BQ04sT0FBTyxTQUFTO09BQ2hCLFdBQVcsTUFBTSxrQkFBa0IsaUJBQWlCLEVBQUUsT0FBTyxLQUFLO09BQ2xFLGFBQVk7T0FDWixXQUFVO01BQ1g7Ozs7Y0FDRTs7Ozs7TUFHTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtPQUFPLFdBQVU7aUJBQTRCO01BQTJCOzs7O2dCQUN4RSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFNBQUQ7UUFBTyxXQUFVO2tCQUFqQjtTQUNFLHdCQUFDLFFBQUQsRUFBUSxXQUFVLDhCQUErQjs7Ozs7U0FDakQsd0JBQUMsUUFBRCxZQUFPLFNBQVMsUUFBUSxpQkFBaUIseUJBQStCOzs7OztTQUN4RSx3QkFBQyxTQUFEO1VBQU8sTUFBSztVQUFPLFFBQU87VUFBVSxVQUFVO1VBQW1CLFdBQVU7U0FBVTs7Ozs7UUFDaEY7Ozs7O2lCQUNOLFNBQVMsU0FDUix3QkFBQyxVQUFEO1FBQ0UsZUFBZSxhQUFZLFVBQVM7U0FBRSxHQUFHO1NBQU0sT0FBTztRQUFLLEVBQUU7UUFDN0QsV0FBVTtrQkFFVix3QkFBQyxRQUFELEVBQVEsV0FBVSxVQUFXOzs7OztPQUN2Qjs7OztlQUVQOzs7OztjQUNGOzs7OztLQUNGOzs7OztZQUNGOzs7OzthQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ2Isd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQWhCLENBQ0Usd0JBQUMsVUFBRCxFQUFVLFdBQVUsOEJBQStCOzs7O2lCQUNuRCx3QkFBQyxRQUFELFlBQU0sZ0NBQW1DOzs7O2VBQ3JDOzs7OztnQkFDTix3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBMkI7TUFBaUM7Ozs7Y0FDekU7Ozs7O2VBR0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ2Isd0JBQUMsT0FBRDtPQUNFLEtBQUs7T0FDTCxXQUFVO09BQ1YsT0FBTyxFQUFFLFdBQVcsUUFBUTtpQkFIOUI7UUFNRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZjtVQUNHLFNBQVMsYUFBYSxxQkFDckIsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQXVEO1VBRWpFOzs7OztVQUVOLFNBQVMsYUFBYSxtQkFDckIsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQXVDO1VBRWpEOzs7OztVQUdQLHdCQUFDLE1BQUQ7V0FBSSxXQUFVO3FCQUNYLFNBQVMsU0FBUyxTQUFTLFNBQVMsSUFBSSxhQUFhO1VBQ3BEOzs7OztVQUNKLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUEwQyxTQUFTO1VBQWM7Ozs7O1VBQ2hGLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmO1lBQW1EO1lBQ3pDLFNBQVM7WUFBTztZQUFFLFNBQVMsUUFBUSxZQUFZLFNBQVMsVUFBVTtXQUN2RTs7Ozs7O1VBRUosU0FBUyxTQUNSLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUNiLHdCQUFDLE9BQUQ7WUFBSyxLQUFLLFNBQVM7WUFBTyxLQUFJO1lBQVEsV0FBVTtXQUE4Qjs7Ozs7VUFDM0U7Ozs7O1NBRUo7Ozs7OztRQUdMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmO1VBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7V0FBSSxXQUFVO3FCQUFzRztVQUVoSDs7OztvQkFDSix3QkFBQyxTQUFEO1dBQU8sV0FBVTtxQkFDZix3QkFBQyxTQUFEO1lBQ0Usd0JBQUMsTUFBRCxhQUFJLHdCQUFDLE1BQUQ7YUFBSSxXQUFVO3VCQUF5QztZQUFjOzs7O3NCQUFDLHdCQUFDLE1BQUQ7YUFBSSxXQUFVO3VCQUE0QixTQUFTO1lBQWE7Ozs7b0JBQUs7Ozs7O1lBQy9JLHdCQUFDLE1BQUQsYUFBSSx3QkFBQyxNQUFEO2FBQUksV0FBVTt1QkFBb0M7WUFBa0I7Ozs7c0JBQUMsd0JBQUMsTUFBRCxZQUFLLFNBQVMsSUFBUTs7OztvQkFBSzs7Ozs7WUFDcEcsd0JBQUMsTUFBRCxhQUFJLHdCQUFDLE1BQUQ7YUFBSSxXQUFVO3VCQUFvQztZQUFjOzs7O3NCQUFDLHdCQUFDLE1BQUQ7YUFBSSxXQUFVO3VCQUFnQyxTQUFTO1lBQWM7Ozs7b0JBQUs7Ozs7O1lBQy9JLHdCQUFDLE1BQUQsYUFBSSx3QkFBQyxNQUFEO2FBQUksV0FBVTt1QkFBb0M7WUFBZTs7OztzQkFBQyx3QkFBQyxNQUFELFlBQUssU0FBUyxJQUFROzs7O29CQUFLOzs7OztZQUNqRyx3QkFBQyxNQUFELGFBQUksd0JBQUMsTUFBRDthQUFJLFdBQVU7dUJBQW9DO1lBQWtCOzs7O3NCQUFDLHdCQUFDLE1BQUQsWUFBSyxTQUFTLE9BQVc7Ozs7b0JBQUs7Ozs7O1lBQ3ZHLHdCQUFDLE1BQUQsYUFBSSx3QkFBQyxNQUFEO2FBQUksV0FBVTt1QkFBb0M7WUFBWTs7OztzQkFBQyx3QkFBQyxNQUFELFlBQUssU0FBUyxRQUFZOzs7O29CQUFLOzs7OztXQUM3Rjs7Ozs7VUFDRjs7OztrQkFDSjs7Ozs7VUFFSixTQUFTLGlCQUNSLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO1dBQUksV0FBVTtxQkFBc0c7VUFFaEg7Ozs7b0JBQ0osd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQ1osU0FBUztVQUNQOzs7O2tCQUNGOzs7OztVQUdOLFNBQVMsaUJBQ1Isd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7V0FBSSxXQUFVO3FCQUFzRztVQUVoSDs7OztvQkFDSix3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFDWixTQUFTO1VBQ1A7Ozs7a0JBQ0Y7Ozs7O1NBRUo7Ozs7OztRQUdMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUFLLFVBQU8sSUFBSSxLQUFLLENBQUMsQ0FBQyxtQkFBbUIsT0FBTyxDQUFPOzs7O21CQUN4RCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLE9BQUQsRUFBSyxXQUFVLE1BQVc7Ozs7b0JBQzFCLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUErRTtVQUV6Rjs7OztrQkFDRjs7Ozs7aUJBQ0Y7Ozs7OztPQUNGOzs7Ozs7S0FDRjs7OzthQUNGOzs7Ozs7R0FDRjs7OztXQUNGOzs7OztVQUNGOzs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJCaW9EYXRhTWFrZXJWaWV3LnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUsIHVzZVJlZiB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IFxuICBGaWxlVGV4dCwgXG4gIFByaW50ZXIsIFxuICBEb3dubG9hZCwgXG4gIFVwbG9hZCwgXG4gIFNhdmUsIFxuICBGb2xkZXJPcGVuLCBcbiAgVHJhc2gyLCBcbiAgVXNlciwgXG4gIEJyaWVmY2FzZSwgXG4gIEdyYWR1YXRpb25DYXAsIFxuICBIZWFydCwgXG4gIE1haWwsIFxuICBQaG9uZSwgXG4gIE1hcFBpbixcbiAgU3BhcmtsZXNcbn0gZnJvbSAnbHVjaWRlLXJlYWN0JztcbmltcG9ydCB7IGpzUERGIH0gZnJvbSAnanNwZGYnO1xuaW1wb3J0IHsgQmlvRGF0YUZvcm0gfSBmcm9tICcuLi90eXBlcyc7XG5pbXBvcnQgeyBhZGREb3dubG9hZFJlY29yZCB9IGZyb20gJy4uL3V0aWxzL3N0b3JhZ2UnO1xuaW1wb3J0IHsgcHJpbnRIdG1sRG9jdW1lbnQgfSBmcm9tICcuLi91dGlscy9wcmludGVyJztcblxuZXhwb3J0IGNvbnN0IEJpb0RhdGFNYWtlclZpZXc6IFJlYWN0LkZDID0gKCkgPT4ge1xuICBjb25zdCBbZm9ybURhdGEsIHNldEZvcm1EYXRhXSA9IHVzZVN0YXRlPEJpb0RhdGFGb3JtPih7XG4gICAgdGVtcGxhdGU6ICdiaW9kYXRhX2hpbmRpJyxcbiAgICBmdWxsTmFtZTogJ1NoYWlraCBTYW1lZXInLFxuICAgIGRvYjogJzE1IEF1Z3VzdCAxOTk4JyxcbiAgICBtb2JpbGU6ICc5NTYxNDYwMzEzJyxcbiAgICBlbWFpbDogJ3NhbWVlci5zaGFpa2hAZ21haWwuY29tJyxcbiAgICBlZHVjYXRpb246ICdCLkNvbSBHcmFkdWF0ZSAoUHVuZSBVbml2ZXJzaXR5KScsXG4gICAgam9iOiAnRGlnaXRhbCBTZXJ2aWNlIFNwZWNpYWxpc3QgJiBBY2NvdW50cycsXG4gICAgaW5jb21lOiAn4oK5IDMsNTAsMDAwIC8gWWVhcicsXG4gICAgYWRkcmVzczogJ05heWEgTXVuc2hpIFNoYWJhbiBOYWdhciwgTWFpbiBSb2FkLCBNYWhhcmFzaHRyYScsXG4gICAgZmFtaWx5RGV0YWlsczogJ0ZhdGhlcjogQnVzaW5lc3NtYW5cXG5Nb3RoZXI6IEhvbWVtYWtlclxcbkJyb3RoZXJzOiAxIEVsZGVyIEJyb3RoZXIgKE1hcnJpZWQpXFxuU2lzdGVyczogMSBZb3VuZ2VyIFNpc3RlcicsXG4gICAgY3VzdG9tRGV0YWlsczogJ0hlaWdodDogNSBGdCA4IEluXFxuQmxvb2QgR3JvdXA6IEIrdmVcXG5Ib2JiaWVzOiBSZWFkaW5nLCBUZWNobm9sb2d5LCBTcG9ydHMnLFxuICAgIHBob3RvOiBudWxsXG4gIH0pO1xuXG4gIGNvbnN0IHByZXZpZXdSZWYgPSB1c2VSZWY8SFRNTERpdkVsZW1lbnQgfCBudWxsPihudWxsKTtcblxuICBjb25zdCBoYW5kbGVJbnB1dENoYW5nZSA9IChmaWVsZDoga2V5b2YgQmlvRGF0YUZvcm0sIHZhbHVlOiBzdHJpbmcpID0+IHtcbiAgICBzZXRGb3JtRGF0YShwcmV2ID0+ICh7IC4uLnByZXYsIFtmaWVsZF06IHZhbHVlIH0pKTtcbiAgfTtcblxuICBjb25zdCBoYW5kbGVQaG90b1VwbG9hZCA9IChlOiBSZWFjdC5DaGFuZ2VFdmVudDxIVE1MSW5wdXRFbGVtZW50PikgPT4ge1xuICAgIGNvbnN0IGZpbGUgPSBlLnRhcmdldC5maWxlcz8uWzBdO1xuICAgIGlmICghZmlsZSkgcmV0dXJuO1xuICAgIGNvbnN0IHJlYWRlciA9IG5ldyBGaWxlUmVhZGVyKCk7XG4gICAgcmVhZGVyLm9ubG9hZCA9IChldmVudCkgPT4ge1xuICAgICAgc2V0Rm9ybURhdGEocHJldiA9PiAoeyAuLi5wcmV2LCBwaG90bzogZXZlbnQudGFyZ2V0Py5yZXN1bHQgYXMgc3RyaW5nIH0pKTtcbiAgICB9O1xuICAgIHJlYWRlci5yZWFkQXNEYXRhVVJMKGZpbGUpO1xuICAgIGUudGFyZ2V0LnZhbHVlID0gJyc7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlU2F2ZURyYWZ0ID0gKCkgPT4ge1xuICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKCdtb3NfcGNfYmlvZGF0YV9kcmFmdCcsIEpTT04uc3RyaW5naWZ5KGZvcm1EYXRhKSk7XG4gICAgYWxlcnQoJ0Jpb0RhdGEgLyBDViBkcmFmdCBzYXZlZCB0byBsb2NhbCBzdG9yYWdlLicpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZUxvYWREcmFmdCA9ICgpID0+IHtcbiAgICBjb25zdCByYXcgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbSgnbW9zX3BjX2Jpb2RhdGFfZHJhZnQnKTtcbiAgICBpZiAocmF3KSB7XG4gICAgICBzZXRGb3JtRGF0YShKU09OLnBhcnNlKHJhdykpO1xuICAgIH0gZWxzZSB7XG4gICAgICBhbGVydCgnTm8gc2F2ZWQgZHJhZnQgZm91bmQuJyk7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IGhhbmRsZUNsZWFyID0gKCkgPT4ge1xuICAgIGlmIChjb25maXJtKCdDbGVhciBhbGwgZm9ybSBmaWVsZHM/JykpIHtcbiAgICAgIHNldEZvcm1EYXRhKHtcbiAgICAgICAgdGVtcGxhdGU6ICdiaW9kYXRhX2hpbmRpJyxcbiAgICAgICAgZnVsbE5hbWU6ICcnLFxuICAgICAgICBkb2I6ICcnLFxuICAgICAgICBtb2JpbGU6ICcnLFxuICAgICAgICBlbWFpbDogJycsXG4gICAgICAgIGVkdWNhdGlvbjogJycsXG4gICAgICAgIGpvYjogJycsXG4gICAgICAgIGluY29tZTogJycsXG4gICAgICAgIGFkZHJlc3M6ICcnLFxuICAgICAgICBmYW1pbHlEZXRhaWxzOiAnJyxcbiAgICAgICAgY3VzdG9tRGV0YWlsczogJycsXG4gICAgICAgIHBob3RvOiBudWxsXG4gICAgICB9KTtcbiAgICB9XG4gIH07XG5cbiAgLy8gRGlyZWN0IFByaW50XG4gIGNvbnN0IGhhbmRsZVByaW50ID0gKCkgPT4ge1xuICAgIGNvbnN0IHByaW50QXJlYSA9IHByZXZpZXdSZWYuY3VycmVudDtcbiAgICBpZiAoIXByaW50QXJlYSkgcmV0dXJuO1xuXG4gICAgY29uc3QgcGFnZVN0eWxlID0gYFxuICAgICAgQHBhZ2UgeyBzaXplOiBBNDsgbWFyZ2luOiAxMG1tOyB9XG4gICAgICBib2R5IHsgZm9udC1mYW1pbHk6ICdQbHVzIEpha2FydGEgU2FucycsIHN5c3RlbS11aSwgc2Fucy1zZXJpZjsgbWFyZ2luOiAwOyBwYWRkaW5nOiAwOyBiYWNrZ3JvdW5kOiAjZmZmOyBjb2xvcjogIzAwMDsgfVxuICAgICAgLnByaW50LWNvbnRhaW5lciB7IHdpZHRoOiAxMDAlOyBtYXgtd2lkdGg6IDgwMHB4OyBtYXJnaW46IDAgYXV0bzsgfVxuICAgICAgdGFibGUgeyB3aWR0aDogMTAwJTsgYm9yZGVyLWNvbGxhcHNlOiBjb2xsYXBzZTsgfVxuICAgICAgdGQgeyBwYWRkaW5nOiA2cHggNHB4OyB2ZXJ0aWNhbC1hbGlnbjogdG9wOyB9XG4gICAgYDtcblxuICAgIGNvbnN0IGh0bWxCb2R5ID0gYFxuICAgICAgPGRpdiBjbGFzcz1cInByaW50LWNvbnRhaW5lclwiPlxuICAgICAgICAke3ByaW50QXJlYS5pbm5lckhUTUx9XG4gICAgICA8L2Rpdj5cbiAgICBgO1xuXG4gICAgcHJpbnRIdG1sRG9jdW1lbnQoaHRtbEJvZHksIGAke2Zvcm1EYXRhLmZ1bGxOYW1lIHx8ICdCaW9EYXRhJ31fUHJpbnRgLCBwYWdlU3R5bGUpO1xuICB9O1xuXG4gIC8vIERvd25sb2FkIFBERlxuICBjb25zdCBoYW5kbGVEb3dubG9hZFBERiA9ICgpID0+IHtcbiAgICBjb25zdCBwZGYgPSBuZXcganNQREYoe1xuICAgICAgb3JpZW50YXRpb246ICdwb3J0cmFpdCcsXG4gICAgICB1bml0OiAnbW0nLFxuICAgICAgZm9ybWF0OiAnYTQnXG4gICAgfSk7XG5cbiAgICAvLyBTaW1wbGUgaGlnaCBxdWFsaXR5IFBERiBnZW5lcmF0aW9uIGZyb20gZGV0YWlsc1xuICAgIHBkZi5zZXRGb250KCdoZWx2ZXRpY2EnLCAnYm9sZCcpO1xuICAgIHBkZi5zZXRGb250U2l6ZSgyMik7XG4gICAgcGRmLnNldFRleHRDb2xvcigzMCwgNTgsIDEzOCk7XG5cbiAgICBjb25zdCB0aXRsZVRleHQgPSBmb3JtRGF0YS50ZW1wbGF0ZS5pbmNsdWRlcygnYmlvZGF0YScpID8gJ0JJT0RBVEEnIDogJ0NVUlJJQ1VMVU0gVklUQUUnO1xuICAgIHBkZi50ZXh0KHRpdGxlVGV4dCwgMTA1LCAyMCwgeyBhbGlnbjogJ2NlbnRlcicgfSk7XG5cbiAgICBwZGYuc2V0Rm9udFNpemUoMTYpO1xuICAgIHBkZi5zZXRUZXh0Q29sb3IoMTUsIDIzLCA0Mik7XG4gICAgcGRmLnRleHQoZm9ybURhdGEuZnVsbE5hbWUgfHwgJ0NhbmRpZGF0ZSBOYW1lJywgMTA1LCAzMCwgeyBhbGlnbjogJ2NlbnRlcicgfSk7XG5cbiAgICBwZGYuc2V0Rm9udFNpemUoMTApO1xuICAgIHBkZi5zZXRUZXh0Q29sb3IoMTAwLCAxMTYsIDEzOSk7XG4gICAgcGRmLnRleHQoYFBob25lOiAke2Zvcm1EYXRhLm1vYmlsZX0gfCBFbWFpbDogJHtmb3JtRGF0YS5lbWFpbH1gLCAxMDUsIDM2LCB7IGFsaWduOiAnY2VudGVyJyB9KTtcblxuICAgIHBkZi5zZXREcmF3Q29sb3IoMzcsIDk5LCAyMzUpO1xuICAgIHBkZi5zZXRMaW5lV2lkdGgoMC41KTtcbiAgICBwZGYubGluZSgyMCwgNDIsIDE5MCwgNDIpO1xuXG4gICAgbGV0IHkgPSA1MjtcblxuICAgIGNvbnN0IGFkZFNlY3Rpb24gPSAoaGVhZGluZzogc3RyaW5nLCBjb250ZW50OiBzdHJpbmcpID0+IHtcbiAgICAgIGlmICghY29udGVudC50cmltKCkpIHJldHVybjtcbiAgICAgIHBkZi5zZXRGb250KCdoZWx2ZXRpY2EnLCAnYm9sZCcpO1xuICAgICAgcGRmLnNldEZvbnRTaXplKDEyKTtcbiAgICAgIHBkZi5zZXRUZXh0Q29sb3IoMzAsIDU4LCAxMzgpO1xuICAgICAgcGRmLnRleHQoaGVhZGluZywgMjAsIHkpO1xuICAgICAgeSArPSA2O1xuXG4gICAgICBwZGYuc2V0Rm9udCgnaGVsdmV0aWNhJywgJ25vcm1hbCcpO1xuICAgICAgcGRmLnNldEZvbnRTaXplKDEwKTtcbiAgICAgIHBkZi5zZXRUZXh0Q29sb3IoMzAsIDQxLCA1OSk7XG5cbiAgICAgIGNvbnN0IGxpbmVzID0gcGRmLnNwbGl0VGV4dFRvU2l6ZShjb250ZW50LCAxNzApO1xuICAgICAgbGluZXMuZm9yRWFjaCgobGluZTogc3RyaW5nKSA9PiB7XG4gICAgICAgIHBkZi50ZXh0KGxpbmUsIDIwLCB5KTtcbiAgICAgICAgeSArPSA1LjU7XG4gICAgICB9KTtcbiAgICAgIHkgKz0gNDtcbiAgICB9O1xuXG4gICAgYWRkU2VjdGlvbignUGVyc29uYWwgRGV0YWlscycsIGBEYXRlIG9mIEJpcnRoOiAke2Zvcm1EYXRhLmRvYn1cXG5BZGRyZXNzOiAke2Zvcm1EYXRhLmFkZHJlc3N9YCk7XG4gICAgYWRkU2VjdGlvbignRWR1Y2F0aW9uICYgUXVhbGlmaWNhdGlvbnMnLCBmb3JtRGF0YS5lZHVjYXRpb24pO1xuICAgIGFkZFNlY3Rpb24oJ09jY3VwYXRpb24gJiBJbmNvbWUnLCBgT2NjdXBhdGlvbjogJHtmb3JtRGF0YS5qb2J9XFxuQW5udWFsIEluY29tZTogJHtmb3JtRGF0YS5pbmNvbWV9YCk7XG4gICAgYWRkU2VjdGlvbignRmFtaWx5IEJhY2tncm91bmQnLCBmb3JtRGF0YS5mYW1pbHlEZXRhaWxzKTtcbiAgICBhZGRTZWN0aW9uKCdBZGRpdGlvbmFsIERldGFpbHMnLCBmb3JtRGF0YS5jdXN0b21EZXRhaWxzKTtcblxuICAgIGNvbnN0IGZpbGVOYW1lID0gYCR7Zm9ybURhdGEuZnVsbE5hbWUucmVwbGFjZSgvXFxzKy9nLCAnXycpIHx8ICdCaW9EYXRhJ31fQTQucGRmYDtcbiAgICBwZGYuc2F2ZShmaWxlTmFtZSk7XG5cbiAgICBhZGREb3dubG9hZFJlY29yZCh7XG4gICAgICBpZDogYGJpb2RhdGEtcGRmLSR7RGF0ZS5ub3coKX1gLFxuICAgICAgdGl0bGU6IGZpbGVOYW1lLFxuICAgICAgdHlwZTogJ0Jpb0RhdGEgUERGJyxcbiAgICAgIHNpemU6ICdBNCBEb2N1bWVudCcsXG4gICAgICB0aW1lc3RhbXA6IG5ldyBEYXRlKCkudG9Mb2NhbGVUaW1lU3RyaW5nKCdlbi1JTicpXG4gICAgfSk7XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxuICAgICAgey8qIEhlYWRlciBiYXIgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgc206ZmxleC1yb3cgc206aXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMyBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcC00IHJvdW5kZWQtMnhsIHNoYWRvdy1tZFwiPlxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtZXh0cmFib2xkIHRleHQtd2hpdGVcIj5DViAmIEJpb0RhdGEgTWFrZXIgU3R1ZGlvPC9oMT5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJnLWluZGlnby01MDAvMjAgdGV4dC1pbmRpZ28tMzAwIGJvcmRlciBib3JkZXItaW5kaWdvLTUwMC8zMCB0ZXh0LXhzIHB4LTIgcHktMC41IHJvdW5kZWQtZnVsbCBmb250LW1vbm8gZm9udC1ib2xkXCI+XG4gICAgICAgICAgICAgIFN0YW5kYXJkIEE0IEZvcm1hdFxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS00MDAgbXQtMC41XCI+XG4gICAgICAgICAgICBDcmVhdGUgcHJvZmVzc2lvbmFsIGpvYiByZXN1bWVzIGFuZCBtYXJyaWFnZSBiaW9kYXRhcyBpbiBIaW5kaSwgRW5nbGlzaCwgYW5kIElzbGFtaWMgbGF5b3V0cyB3aXRoIGluc3RhbnQgQTQgbGl2ZSBwcmV2aWV3XG4gICAgICAgICAgPC9wPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17aGFuZGxlUHJpbnR9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IGJnLWJsdWUtNjAwIGhvdmVyOmJnLWJsdWUtNTAwIHRleHQtd2hpdGUgZm9udC1ib2xkIHRleHQteHMgcHgtMy41IHB5LTIgcm91bmRlZC14bCBzaGFkb3ctbGcgc2hhZG93LWJsdWUtNjAwLzMwIHRyYW5zaXRpb24tYWxsIGhvdmVyOnNjYWxlLTEwNVwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPFByaW50ZXIgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICA8c3Bhbj7wn5ao77iPIERpcmVjdCBQcmludDwvc3Bhbj5cbiAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZURvd25sb2FkUERGfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBiZy1pbmRpZ28tNjAwIGhvdmVyOmJnLWluZGlnby01MDAgdGV4dC13aGl0ZSBmb250LWJvbGQgdGV4dC14cyBweC0zLjUgcHktMiByb3VuZGVkLXhsIHNoYWRvdy1sZyBzaGFkb3ctaW5kaWdvLTYwMC8zMCB0cmFuc2l0aW9uLWFsbCBob3ZlcjpzY2FsZS0xMDVcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxEb3dubG9hZCBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgIDxzcGFuPvCfk4QgRG93bmxvYWQgUERGPC9zcGFuPlxuICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17aGFuZGxlU2F2ZURyYWZ0fVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0yIGJnLXNsYXRlLTgwMCBob3ZlcjpiZy1zbGF0ZS03MDAgdGV4dC1zbGF0ZS0yMDAgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGRcIlxuICAgICAgICAgICAgdGl0bGU9XCJTYXZlIERyYWZ0XCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8U2F2ZSBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIE1haW4gRHVhbCBQYW5lOiBGb3JtIEVkaXRvciBvbiBMZWZ0LCBMaXZlIEE0IERvY3VtZW50IG9uIFJpZ2h0ICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIGxnOmdyaWQtY29scy0xMiBnYXAtNSBpdGVtcy1zdGFydFwiPlxuICAgICAgICB7LyogTGVmdCBTaWRlOiBGb3JtIEVkaXRvciAoNSBjb2xzKSAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJsZzpjb2wtc3Bhbi01IHNwYWNlLXktNFwiPlxuICAgICAgICAgIHsvKiBUZW1wbGF0ZSBTZWxlY3RvciAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMC85MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTJ4bCBwLTQgc2hhZG93LW1kIHNwYWNlLXktM1wiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS0zMDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIGJsb2NrXCI+RG9jdW1lbnQgVGVtcGxhdGU8L3NwYW4+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtMiB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgIHtbXG4gICAgICAgICAgICAgICAgeyBpZDogJ2Jpb2RhdGFfaGluZGknLCBsYWJlbDogJ01hcnJpYWdlIEJpb0RhdGEgKEhpbmRpKScsIGljb246IEhlYXJ0IH0sXG4gICAgICAgICAgICAgICAgeyBpZDogJ2Jpb2RhdGFfZW5nbGlzaCcsIGxhYmVsOiAnTWFycmlhZ2UgQmlvRGF0YSAoRW5nKScsIGljb246IEhlYXJ0IH0sXG4gICAgICAgICAgICAgICAgeyBpZDogJ2Jpb2RhdGFfaXNsYW1pYycsIGxhYmVsOiAnSXNsYW1pYyBCaW9EYXRhJywgaWNvbjogU3BhcmtsZXMgfSxcbiAgICAgICAgICAgICAgICB7IGlkOiAnY3ZfbW9kZXJuJywgbGFiZWw6ICdQcm9mZXNzaW9uYWwgSm9iIFJlc3VtZScsIGljb246IEJyaWVmY2FzZSB9XG4gICAgICAgICAgICAgIF0ubWFwKCh0bXBsKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgSWNvbiA9IHRtcGwuaWNvbjtcbiAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICBrZXk9e3RtcGwuaWR9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZUlucHV0Q2hhbmdlKCd0ZW1wbGF0ZScsIHRtcGwuaWQpfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BwLTIuNSByb3VuZGVkLXhsIGJvcmRlciBmb250LWJvbGQgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC1sZWZ0IHRyYW5zaXRpb24tYWxsICR7XG4gICAgICAgICAgICAgICAgICAgICAgZm9ybURhdGEudGVtcGxhdGUgPT09IHRtcGwuaWRcbiAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLWluZGlnby02MDAgdGV4dC13aGl0ZSBib3JkZXItaW5kaWdvLTUwMCBzaGFkb3ctbWQnXG4gICAgICAgICAgICAgICAgICAgICAgICA6ICdiZy1zbGF0ZS05NTAgdGV4dC1zbGF0ZS0zMDAgYm9yZGVyLXNsYXRlLTgwMCBob3ZlcjpiZy1zbGF0ZS04MDAnXG4gICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8SWNvbiBjbGFzc05hbWU9XCJ3LTQgaC00IGZsZXgtc2hyaW5rLTBcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBsZWFkaW5nLXRpZ2h0XCI+e3RtcGwubGFiZWx9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBGb3JtIEZpZWxkcyAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMC85MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTJ4bCBwLTQgc2hhZG93LW1kIHNwYWNlLXktMyB0ZXh0LXhzXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBib3JkZXItYiBib3JkZXItc2xhdGUtODAwIHBiLTJcIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS0zMDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+Q2FuZGlkYXRlIFBhcnRpY3VsYXJzPC9zcGFuPlxuICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9e2hhbmRsZUNsZWFyfSBjbGFzc05hbWU9XCJ0ZXh0LXJvc2UtNDAwIGhvdmVyOnRleHQtcm9zZS0zMDAgdGV4dC1bMTFweF1cIj5cbiAgICAgICAgICAgICAgICBDbGVhciBGb3JtXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBibG9jayBtYi0xXCI+RnVsbCBOYW1lICo8L2xhYmVsPlxuICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmZ1bGxOYW1lfVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlSW5wdXRDaGFuZ2UoJ2Z1bGxOYW1lJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRnVsbCBOYW1lXCJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQteGwgcHgtMyBweS0xLjUgdGV4dC13aGl0ZSBmb250LXNlbWlib2xkIHRleHQtc21cIlxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtM1wiPlxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBibG9jayBtYi0xXCI+RGF0ZSBvZiBCaXJ0aDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuZG9ifVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVJbnB1dENoYW5nZSgnZG9iJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJERC9NTS9ZWVlZXCJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCBweC0zIHB5LTEuNSB0ZXh0LXdoaXRlIGZvbnQtbW9ub1wiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIGJsb2NrIG1iLTFcIj5Nb2JpbGUgLyBXaGF0c0FwcDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEubW9iaWxlfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVJbnB1dENoYW5nZSgnbW9iaWxlJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJNb2JpbGUgbnVtYmVyXCJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCBweC0zIHB5LTEuNSB0ZXh0LXdoaXRlIGZvbnQtbW9ub1wiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIGJsb2NrIG1iLTFcIj5FbWFpbCBBZGRyZXNzPC9sYWJlbD5cbiAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgdHlwZT1cImVtYWlsXCJcbiAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuZW1haWx9XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVJbnB1dENoYW5nZSgnZW1haWwnLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJlbWFpbEBleGFtcGxlLmNvbVwiXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLXhsIHB4LTMgcHktMS41IHRleHQtd2hpdGVcIlxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBibG9jayBtYi0xXCI+RWR1Y2F0aW9uIC8gRGVncmVlczwvbGFiZWw+XG4gICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuZWR1Y2F0aW9ufVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlSW5wdXRDaGFuZ2UoJ2VkdWNhdGlvbicsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImUuZy4gQi5Db20sIE1CQSwgSVRJLCAxMnRoIFBhc3NcIlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCBweC0zIHB5LTEuNSB0ZXh0LXdoaXRlXCJcbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgYmxvY2sgbWItMVwiPkpvYiAvIE9jY3VwYXRpb248L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmpvYn1cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlSW5wdXRDaGFuZ2UoJ2pvYicsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiZS5nLiBHb3Z0IEVtcGxveWVlLCBCdXNpbmVzc1wiXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQteGwgcHgtMyBweS0xLjUgdGV4dC13aGl0ZVwiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIGJsb2NrIG1iLTFcIj5Bbm51YWwgSW5jb21lPC9sYWJlbD5cbiAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5pbmNvbWV9XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUlucHV0Q2hhbmdlKCdpbmNvbWUnLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImUuZy4g4oK5IDQsMDAsMDAwIC8gWWVhclwiXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQteGwgcHgtMyBweS0xLjUgdGV4dC13aGl0ZSBmb250LW1vbm9cIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBibG9jayBtYi0xXCI+UmVzaWRlbnRpYWwgQWRkcmVzczwvbGFiZWw+XG4gICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuYWRkcmVzc31cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUlucHV0Q2hhbmdlKCdhZGRyZXNzJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRnVsbCByZXNpZGVudGlhbCBhZGRyZXNzXCJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQteGwgcHgtMyBweS0xLjUgdGV4dC13aGl0ZVwiXG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIGJsb2NrIG1iLTFcIj5GYW1pbHkgRGV0YWlsczwvbGFiZWw+XG4gICAgICAgICAgICAgIDx0ZXh0YXJlYVxuICAgICAgICAgICAgICAgIHJvd3M9ezN9XG4gICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmZhbWlseURldGFpbHN9XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVJbnB1dENoYW5nZSgnZmFtaWx5RGV0YWlscycsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkZhdGhlciBuYW1lLCBtb3RoZXIsIGJyb3RoZXJzLCBzaXN0ZXJzLi4uXCJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQteGwgcC0yLjUgdGV4dC13aGl0ZSByZXNpemUtbm9uZVwiXG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIGJsb2NrIG1iLTFcIj5BZGRpdGlvbmFsIEluZm9ybWF0aW9uIChIZWlnaHQsIEdvdHJhLCBDYXN0LCBTa2lsbHMpPC9sYWJlbD5cbiAgICAgICAgICAgICAgPHRleHRhcmVhXG4gICAgICAgICAgICAgICAgcm93cz17Mn1cbiAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuY3VzdG9tRGV0YWlsc31cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUlucHV0Q2hhbmdlKCdjdXN0b21EZXRhaWxzJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiSGVpZ2h0LCBibG9vZCBncm91cCwgaG9iYmllcywgY29tcHV0ZXIgc2tpbGxzLi4uXCJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQteGwgcC0yLjUgdGV4dC13aGl0ZSByZXNpemUtbm9uZVwiXG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIFBob3RvIHVwbG9hZCAqL31cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBibG9jayBtYi0xXCI+Q2FuZGlkYXRlIFBob3RvZ3JhcGg8L2xhYmVsPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZsZXgtMSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiBweS0yIHB4LTMgYmctc2xhdGUtODAwIGhvdmVyOmJnLXNsYXRlLTc1MCB0ZXh0LXNsYXRlLTIwMCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgcm91bmRlZC1sZyBjdXJzb3ItcG9pbnRlciBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMFwiPlxuICAgICAgICAgICAgICAgICAgPFVwbG9hZCBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LWluZGlnby00MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgPHNwYW4+e2Zvcm1EYXRhLnBob3RvID8gJ0NoYW5nZSBQaG90bycgOiAnVXBsb2FkIENhbmRpZGF0ZSBQaG90byd9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJmaWxlXCIgYWNjZXB0PVwiaW1hZ2UvKlwiIG9uQ2hhbmdlPXtoYW5kbGVQaG90b1VwbG9hZH0gY2xhc3NOYW1lPVwiaGlkZGVuXCIgLz5cbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgIHtmb3JtRGF0YS5waG90byAmJiAoXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEZvcm1EYXRhKHByZXYgPT4gKHsgLi4ucHJldiwgcGhvdG86IG51bGwgfSkpfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTIgdGV4dC1yb3NlLTQwMCBob3ZlcjpiZy1yb3NlLTUwMC8xMCByb3VuZGVkLWxnXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPFRyYXNoMiBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBSaWdodCBTaWRlOiBMaXZlIEE0IERvY3VtZW50IFByZXZpZXcgKDcgY29scykgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibGc6Y29sLXNwYW4tNyBzcGFjZS15LTNcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTJ4bCBwLTQgc2hhZG93LXhsXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi0zIHRleHQteHNcIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtd2hpdGUgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgIDxGaWxlVGV4dCBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LWluZGlnby00MDBcIiAvPlxuICAgICAgICAgICAgICAgIDxzcGFuPkxpdmUgQTQgRG9jdW1lbnQgUGFnZSBQcmV2aWV3PC9zcGFuPlxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIGZvbnQtbW9ub1wiPjIxMG1tIMOXIDI5N21tIChTdGFuZGFyZCBBNCk8L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIEE0IFBhcGVyIEJveCBDb250YWluZXIgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTk1MCBwLTQgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMC84MCBvdmVyZmxvdy1hdXRvIGZsZXgganVzdGlmeS1jZW50ZXIgc2hhZG93LWlubmVyXCI+XG4gICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICByZWY9e3ByZXZpZXdSZWZ9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIG1heC13LVs1MDBweF0gYmctd2hpdGUgdGV4dC1zbGF0ZS05MDAgcC04IHNoYWRvdy0yeGwgcm91bmRlZC1zbSBib3JkZXIgYm9yZGVyLXNsYXRlLTMwMCBmb250LXNhbnMgdGV4dC14cyBsZWFkaW5nLXJlbGF4ZWQgc2VsZWN0LXRleHRcIlxuICAgICAgICAgICAgICAgIHN0eWxlPXt7IG1pbkhlaWdodDogJzY4MHB4JyB9fVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgey8qIEhlYWRlciBEZWNvcmF0aW9uICovfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgcGItNCBib3JkZXItYi0yIGJvcmRlci1pbmRpZ28tNzAwIG1iLTUgcmVsYXRpdmVcIj5cbiAgICAgICAgICAgICAgICAgIHtmb3JtRGF0YS50ZW1wbGF0ZSA9PT0gJ2Jpb2RhdGFfaXNsYW1pYycgJiYgKFxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LWJvbGQgdGV4dC1lbWVyYWxkLTgwMCBtYi0xIGZvbnQtc2VyaWZcIj5cbiAgICAgICAgICAgICAgICAgICAgICDYqNmQ2LPZktmF2ZAg2KfZhNmE2Y7ZkdmH2ZAg2KfZhNix2Y7Zkdit2ZLZhdmO2bDZhtmQINin2YTYsdmO2ZHYrdmQ2YrZhdmQXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgIHtmb3JtRGF0YS50ZW1wbGF0ZSA9PT0gJ2Jpb2RhdGFfaGluZGknICYmIChcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LXJvc2UtODAwIG1iLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICDgpaUg4KS24KWN4KSw4KWAIOCkl+Cko+Clh+CktuCkvuCkryDgpKjgpK7gpIMg4KWlXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYmxhY2sgdHJhY2tpbmctd2lkZXIgdGV4dC1pbmRpZ28tOTUwIHVwcGVyY2FzZVwiPlxuICAgICAgICAgICAgICAgICAgICB7Zm9ybURhdGEudGVtcGxhdGUuaW5jbHVkZXMoJ2Jpb2RhdGEnKSA/ICdCSU8gREFUQScgOiAnQ1VSUklDVUxVTSBWSVRBRSd9XG4gICAgICAgICAgICAgICAgICA8L2gyPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LWluZGlnby04MDAgbXQtMVwiPntmb3JtRGF0YS5mdWxsTmFtZX08L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS02MDAgbXQtMC41XCI+XG4gICAgICAgICAgICAgICAgICAgIFBob25lOiB7Zm9ybURhdGEubW9iaWxlfSB7Zm9ybURhdGEuZW1haWwgPyBg4oCiIEVtYWlsOiAke2Zvcm1EYXRhLmVtYWlsfWAgOiAnJ31cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICB7Zm9ybURhdGEucGhvdG8gJiYgKFxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIHJpZ2h0LTAgdG9wLTAgdy0yNCBoLTMyIGJvcmRlci0yIGJvcmRlci1zbGF0ZS0zMDAgcm91bmRlZCBwLTEgYmctd2hpdGUgc2hhZG93LXNtXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGltZyBzcmM9e2Zvcm1EYXRhLnBob3RvfSBhbHQ9XCJQaG90b1wiIGNsYXNzTmFtZT1cInctZnVsbCBoLWZ1bGwgb2JqZWN0LWNvdmVyXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgey8qIENvbnRlbnQgU2VjdGlvbnMgVGFibGUgKi99XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1pbmRpZ28tOTAwIHVwcGVyY2FzZSB0ZXh0LVsxMXB4XSB0cmFja2luZy13aWRlciBib3JkZXItYiBib3JkZXItaW5kaWdvLTEwMCBwYi0xIG1iLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICBQZXJzb25hbCBEZXRhaWxzXG4gICAgICAgICAgICAgICAgICAgIDwvaDQ+XG4gICAgICAgICAgICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJ3LWZ1bGwgdGV4dC14c1wiPlxuICAgICAgICAgICAgICAgICAgICAgIDx0Ym9keT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0cj48dGQgY2xhc3NOYW1lPVwidy0zNiBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNjAwIHB5LTFcIj5GdWxsIE5hbWU6PC90ZD48dGQgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwXCI+e2Zvcm1EYXRhLmZ1bGxOYW1lfTwvdGQ+PC90cj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0cj48dGQgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTYwMCBweS0xXCI+RGF0ZSBvZiBCaXJ0aDo8L3RkPjx0ZD57Zm9ybURhdGEuZG9ifTwvdGQ+PC90cj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0cj48dGQgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTYwMCBweS0xXCI+RWR1Y2F0aW9uOjwvdGQ+PHRkIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS04MDBcIj57Zm9ybURhdGEuZWR1Y2F0aW9ufTwvdGQ+PC90cj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0cj48dGQgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTYwMCBweS0xXCI+T2NjdXBhdGlvbjo8L3RkPjx0ZD57Zm9ybURhdGEuam9ifTwvdGQ+PC90cj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0cj48dGQgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTYwMCBweS0xXCI+QW5udWFsIEluY29tZTo8L3RkPjx0ZD57Zm9ybURhdGEuaW5jb21lfTwvdGQ+PC90cj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0cj48dGQgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTYwMCBweS0xXCI+QWRkcmVzczo8L3RkPjx0ZD57Zm9ybURhdGEuYWRkcmVzc308L3RkPjwvdHI+XG4gICAgICAgICAgICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICAgICAgICAgICAgPC90YWJsZT5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICB7Zm9ybURhdGEuZmFtaWx5RGV0YWlscyAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LWluZGlnby05MDAgdXBwZXJjYXNlIHRleHQtWzExcHhdIHRyYWNraW5nLXdpZGVyIGJvcmRlci1iIGJvcmRlci1pbmRpZ28tMTAwIHBiLTEgbWItMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgRmFtaWx5IERldGFpbHNcbiAgICAgICAgICAgICAgICAgICAgICA8L2g0PlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwid2hpdGVzcGFjZS1wcmUtbGluZSB0ZXh0LXNsYXRlLTcwMCBwbC0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7Zm9ybURhdGEuZmFtaWx5RGV0YWlsc31cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgICB7Zm9ybURhdGEuY3VzdG9tRGV0YWlscyAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LWluZGlnby05MDAgdXBwZXJjYXNlIHRleHQtWzExcHhdIHRyYWNraW5nLXdpZGVyIGJvcmRlci1iIGJvcmRlci1pbmRpZ28tMTAwIHBiLTEgbWItMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgT3RoZXIgUGFydGljdWxhcnNcbiAgICAgICAgICAgICAgICAgICAgICA8L2g0PlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwid2hpdGVzcGFjZS1wcmUtbGluZSB0ZXh0LXNsYXRlLTcwMCBwbC0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7Zm9ybURhdGEuY3VzdG9tRGV0YWlsc31cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgey8qIEZvb3RlciBTaWduYXR1cmUgKi99XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0xMiBwdC02IGZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWVuZCBib3JkZXItdCBib3JkZXItc2xhdGUtMjAwIHRleHQtWzExcHhdIHRleHQtc2xhdGUtNTAwXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2PkRhdGU6IHtuZXcgRGF0ZSgpLnRvTG9jYWxlRGF0ZVN0cmluZygnZW4tSU4nKX08L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1yaWdodFwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtOFwiPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci10IGJvcmRlci1zbGF0ZS00MDAgdy0zMiB0ZXh0LWNlbnRlciBwdC0xIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS04MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICBTaWduYXR1cmVcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG4iXX0=