const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=090625a0";
import { Search, Plus, Send, Trash2 } from "/node_modules/.vite/deps/lucide-react.js?v=090625a0";
var _jsxFileName = "/app/applet/src/components/CustomerCrmView.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=090625a0";
export const CustomerCrmView = ({ customers, settings, onAddCustomer, onUpdateStatus, onDeleteCustomer }) => {
	const [searchTerm, setSearchTerm] = useState("");
	const [statusFilter, setStatusFilter] = useState("all");
	const [showAddModal, setShowAddModal] = useState(false);
	// New customer form state
	const [name, setName] = useState("");
	const [mobile, setMobile] = useState("");
	const [serviceType, setServiceType] = useState("Majhi Ladki Bahin Yojana");
	const [ackToken, setAckToken] = useState("");
	const [amount, setAmount] = useState(100);
	const [notes, setNotes] = useState("");
	const handleAddSubmit = (e) => {
		e.preventDefault();
		if (!name.trim()) return;
		const newRec = {
			id: `cust-${Date.now()}`,
			name: name.trim(),
			mobile: mobile.trim() || "N/A",
			serviceType: serviceType.trim(),
			ackToken: ackToken.trim() || `TOK-${Math.floor(1e4 + Math.random() * 9e4)}`,
			status: "Pending",
			date: new Date().toISOString().slice(0, 10),
			amount: Number(amount) || 0,
			notes: notes.trim()
		};
		onAddCustomer(newRec);
		setShowAddModal(false);
		setName("");
		setMobile("");
		setAckToken("");
		setNotes("");
	};
	const filtered = customers.filter((c) => {
		const matchesSearch = c.name.toLowerCase().includes(searchTerm.toLowerCase()) || c.mobile.includes(searchTerm) || c.serviceType.toLowerCase().includes(searchTerm.toLowerCase()) || c.ackToken.toLowerCase().includes(searchTerm.toLowerCase());
		const matchesStatus = statusFilter === "all" || c.status.toLowerCase() === statusFilter.toLowerCase();
		return matchesSearch && matchesStatus;
	});
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900 border border-slate-800 p-4 rounded-2xl shadow-md",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ _jsxDEV("h1", {
						className: "text-xl font-extrabold text-white",
						children: "Customer CRM & Job Tracker"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 84,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "bg-blue-500/20 text-blue-400 border border-blue-500/30 text-xs px-2 py-0.5 rounded-full font-mono font-bold",
						children: [customers.length, " Records"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 85,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 83,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "text-xs text-slate-400 mt-0.5",
					children: "Track customer applications, biometric verification status, delivery alerts & WhatsApp updates"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 89,
					columnNumber: 11
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 82,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2",
					children: /* @__PURE__ */ _jsxDEV("button", {
						onClick: () => setShowAddModal(true),
						className: "flex items-center gap-1.5 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs px-3.5 py-2 rounded-xl shadow-lg shadow-blue-600/30 transition-all hover:scale-105",
						children: [/* @__PURE__ */ _jsxDEV(Plus, { className: "w-4 h-4" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 99,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "+ Add Customer Job" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 100,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 95,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 94,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 81,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900/80 border border-slate-800 p-3 rounded-xl",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-1.5 overflow-x-auto text-xs",
					children: [
						"all",
						"Pending",
						"Processing",
						"Ready",
						"Delivered"
					].map((st) => /* @__PURE__ */ _jsxDEV("button", {
						onClick: () => setStatusFilter(st),
						className: `px-3 py-1.5 rounded-lg font-bold transition-all ${statusFilter === st ? "bg-blue-600 text-white shadow-sm" : "bg-slate-950 text-slate-400 hover:text-white border border-slate-800"}`,
						children: st === "all" ? "All Jobs" : st
					}, st, false, {
						fileName: _jsxFileName,
						lineNumber: 110,
						columnNumber: 13
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 108,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "relative",
					children: [/* @__PURE__ */ _jsxDEV(Search, { className: "w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 126,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("input", {
						type: "text",
						placeholder: "Search by name, phone, token...",
						value: searchTerm,
						onChange: (e) => setSearchTerm(e.target.value),
						className: "bg-slate-950 border border-slate-700 rounded-xl pl-8 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 w-full sm:w-64"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 127,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 125,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 106,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-md",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "overflow-x-auto",
					children: /* @__PURE__ */ _jsxDEV("table", {
						className: "w-full text-left text-xs",
						children: [/* @__PURE__ */ _jsxDEV("thead", {
							className: "bg-slate-950 text-slate-400 border-b border-slate-800 font-mono",
							children: /* @__PURE__ */ _jsxDEV("tr", { children: [
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-3 px-4",
									children: "Token / Ack"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 143,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-3 px-4",
									children: "Customer Name"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 144,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-3 px-4",
									children: "Mobile"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 145,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-3 px-4",
									children: "Service Applied"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 146,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-3 px-4",
									children: "Date"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 147,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-3 px-4",
									children: "Status"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 148,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-3 px-4 text-right",
									children: "Fee"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 149,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-3 px-4 text-right",
									children: "Actions"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 150,
									columnNumber: 17
								}, this)
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 142,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 141,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("tbody", {
							className: "divide-y divide-slate-800/60",
							children: filtered.map((c) => /* @__PURE__ */ _jsxDEV("tr", {
								className: "hover:bg-slate-800/40 transition-colors",
								children: [
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-3.5 px-4 font-mono font-bold text-blue-400",
										children: c.ackToken
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 156,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-3.5 px-4",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "font-bold text-white",
											children: c.name
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 158,
											columnNumber: 21
										}, this), c.notes && /* @__PURE__ */ _jsxDEV("div", {
											className: "text-[11px] text-slate-400 line-clamp-1",
											children: c.notes
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 159,
											columnNumber: 33
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 157,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-3.5 px-4 font-mono text-slate-300",
										children: c.mobile
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 161,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-3.5 px-4 font-medium text-slate-200",
										children: c.serviceType
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 162,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-3.5 px-4 font-mono text-slate-400 text-[11px]",
										children: c.date
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 163,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-3.5 px-4",
										children: /* @__PURE__ */ _jsxDEV("select", {
											value: c.status,
											onChange: (e) => onUpdateStatus(c.id, e.target.value),
											className: `text-[11px] font-bold px-2 py-1 rounded-lg border focus:outline-none cursor-pointer ${c.status === "Ready" ? "bg-emerald-500/20 text-emerald-300 border-emerald-500/40" : c.status === "Delivered" ? "bg-blue-500/20 text-blue-300 border-blue-500/40" : c.status === "Processing" ? "bg-amber-500/20 text-amber-300 border-amber-500/40" : "bg-rose-500/20 text-rose-300 border-rose-500/40"}`,
											children: [
												/* @__PURE__ */ _jsxDEV("option", {
													value: "Pending",
													className: "bg-slate-900 text-rose-300",
													children: "Pending"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 178,
													columnNumber: 23
												}, this),
												/* @__PURE__ */ _jsxDEV("option", {
													value: "Processing",
													className: "bg-slate-900 text-amber-300",
													children: "Processing"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 179,
													columnNumber: 23
												}, this),
												/* @__PURE__ */ _jsxDEV("option", {
													value: "Ready",
													className: "bg-slate-900 text-emerald-300",
													children: "Ready"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 180,
													columnNumber: 23
												}, this),
												/* @__PURE__ */ _jsxDEV("option", {
													value: "Delivered",
													className: "bg-slate-900 text-blue-300",
													children: "Delivered"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 181,
													columnNumber: 23
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 165,
											columnNumber: 21
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 164,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-3.5 px-4 text-right font-mono font-bold text-emerald-400",
										children: ["₹", c.amount]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 184,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-3.5 px-4 text-right space-x-1 whitespace-nowrap",
										children: [/* @__PURE__ */ _jsxDEV("a", {
											href: `https://wa.me/91${c.mobile}?text=Namaskar%20${encodeURIComponent(c.name)},%20your%20${encodeURIComponent(c.serviceType)}%20application%20(Token:%20${c.ackToken})%20status%20is:%20${c.status}.%20Regards,%20${encodeURIComponent(settings.shopName)}.`,
											target: "_blank",
											rel: "noopener noreferrer",
											title: "WhatsApp Status Alert",
											className: "p-1.5 rounded-lg bg-emerald-600/20 hover:bg-emerald-600/40 text-emerald-400 inline-block transition-colors",
											children: /* @__PURE__ */ _jsxDEV(Send, { className: "w-3.5 h-3.5" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 193,
												columnNumber: 23
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 186,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("button", {
											onClick: () => onDeleteCustomer(c.id),
											title: "Delete Customer Record",
											className: "p-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 transition-colors",
											children: /* @__PURE__ */ _jsxDEV(Trash2, { className: "w-3.5 h-3.5" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 200,
												columnNumber: 23
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 195,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 185,
										columnNumber: 19
									}, this)
								]
							}, c.id, true, {
								fileName: _jsxFileName,
								lineNumber: 155,
								columnNumber: 17
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 153,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 140,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 139,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 138,
				columnNumber: 7
			}, this),
			showAddModal && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed inset-0 bg-black/75 z-50 flex items-center justify-center p-4",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-5 shadow-2xl space-y-4",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center justify-between border-b border-slate-800 pb-3",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "font-bold text-white text-base",
							children: "New Customer Application Job"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 215,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setShowAddModal(false),
							className: "text-slate-400 hover:text-white",
							children: "✕"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 216,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 214,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("form", {
						onSubmit: handleAddSubmit,
						className: "space-y-3 text-xs",
						children: [
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "text-slate-300 font-semibold block mb-1",
								children: "Customer Full Name *"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 221,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								required: true,
								placeholder: "e.g. Shaikh Sameer",
								value: name,
								onChange: (e) => setName(e.target.value),
								className: "w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 222,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 220,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "text-slate-300 font-semibold block mb-1",
								children: "Mobile / WhatsApp *"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 233,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "tel",
								placeholder: "10 digit number",
								value: mobile,
								onChange: (e) => setMobile(e.target.value),
								className: "w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 234,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 232,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "text-slate-300 font-semibold block mb-1",
								children: "Service Type"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 244,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								value: serviceType,
								onChange: (e) => setServiceType(e.target.value),
								placeholder: "e.g. Majhi Ladki Bahin Yojana, PAN Card",
								className: "w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 245,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 243,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-2 gap-3",
								children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "text-slate-300 font-semibold block mb-1",
									children: "Ack / Token No."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 256,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									value: ackToken,
									onChange: (e) => setAckToken(e.target.value),
									placeholder: "Auto-generated if blank",
									className: "w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 257,
									columnNumber: 19
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 255,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "text-slate-300 font-semibold block mb-1",
									children: "Amount (₹)"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 266,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "number",
									value: amount,
									onChange: (e) => setAmount(Number(e.target.value)),
									className: "w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 267,
									columnNumber: 19
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 265,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 254,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "text-slate-300 font-semibold block mb-1",
								children: "Job Remarks / Details"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 277,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								value: notes,
								onChange: (e) => setNotes(e.target.value),
								placeholder: "e.g. Aadhaar seeding pending in Bank of Maharashtra",
								className: "w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 278,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 276,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "pt-2 flex items-center gap-2",
								children: [/* @__PURE__ */ _jsxDEV("button", {
									type: "submit",
									className: "flex-1 bg-blue-600 hover:bg-blue-500 text-white font-bold py-2.5 rounded-xl transition-colors",
									children: "Save Customer Job"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 288,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => setShowAddModal(false),
									className: "px-4 py-2.5 bg-slate-800 text-slate-300 rounded-xl hover:bg-slate-750",
									children: "Cancel"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 294,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 287,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 219,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 213,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 212,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 79,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxTQUVFLFFBQ0EsTUFDQSxNQUlBLGNBSUs7OztBQVdQLE9BQU8sTUFBTSxtQkFBbUQsRUFDOUQsV0FDQSxVQUNBLGVBQ0EsZ0JBQ0EsdUJBQ0k7Q0FDSixNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBUyxFQUFFO0NBQy9DLE1BQU0sQ0FBQyxjQUFjLG1CQUFtQixTQUFpQixLQUFLO0NBQzlELE1BQU0sQ0FBQyxjQUFjLG1CQUFtQixTQUFTLEtBQUs7O0NBR3RELE1BQU0sQ0FBQyxNQUFNLFdBQVcsU0FBUyxFQUFFO0NBQ25DLE1BQU0sQ0FBQyxRQUFRLGFBQWEsU0FBUyxFQUFFO0NBQ3ZDLE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFTLDBCQUEwQjtDQUN6RSxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQVMsRUFBRTtDQUMzQyxNQUFNLENBQUMsUUFBUSxhQUFhLFNBQWlCLEdBQUc7Q0FDaEQsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLEVBQUU7Q0FFckMsTUFBTSxtQkFBbUIsTUFBdUI7RUFDOUMsRUFBRSxlQUFlO0VBQ2pCLElBQUksQ0FBQyxLQUFLLEtBQUssR0FBRztFQUVsQixNQUFNLFNBQXlCO0dBQzdCLElBQUksUUFBUSxLQUFLLElBQUk7R0FDckIsTUFBTSxLQUFLLEtBQUs7R0FDaEIsUUFBUSxPQUFPLEtBQUssS0FBSztHQUN6QixhQUFhLFlBQVksS0FBSztHQUM5QixVQUFVLFNBQVMsS0FBSyxLQUFLLE9BQU8sS0FBSyxNQUFNLE1BQVEsS0FBSyxPQUFPLElBQUksR0FBSztHQUM1RSxRQUFRO0dBQ1IsTUFBTSxJQUFJLEtBQUssQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLE1BQU0sR0FBRyxFQUFFO0dBQzFDLFFBQVEsT0FBTyxNQUFNLEtBQUs7R0FDMUIsT0FBTyxNQUFNLEtBQUs7RUFDcEI7RUFFQSxjQUFjLE1BQU07RUFDcEIsZ0JBQWdCLEtBQUs7RUFDckIsUUFBUSxFQUFFO0VBQ1YsVUFBVSxFQUFFO0VBQ1osWUFBWSxFQUFFO0VBQ2QsU0FBUyxFQUFFO0NBQ2I7Q0FFQSxNQUFNLFdBQVcsVUFBVSxRQUFPLE1BQUs7RUFDckMsTUFBTSxnQkFDSixFQUFFLEtBQUssWUFBWSxDQUFDLENBQUMsU0FBUyxXQUFXLFlBQVksQ0FBQyxLQUN0RCxFQUFFLE9BQU8sU0FBUyxVQUFVLEtBQzVCLEVBQUUsWUFBWSxZQUFZLENBQUMsQ0FBQyxTQUFTLFdBQVcsWUFBWSxDQUFDLEtBQzdELEVBQUUsU0FBUyxZQUFZLENBQUMsQ0FBQyxTQUFTLFdBQVcsWUFBWSxDQUFDO0VBQzVELE1BQU0sZ0JBQWdCLGlCQUFpQixTQUFTLEVBQUUsT0FBTyxZQUFZLE1BQU0sYUFBYSxZQUFZO0VBQ3BHLE9BQU8saUJBQWlCO0NBQzFCLENBQUM7Q0FFRCxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FFRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBb0M7S0FBOEI7Ozs7ZUFDaEYsd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQWhCLENBQ0csVUFBVSxRQUFPLFVBQ2Q7Ozs7O2FBQ0g7Ozs7O2NBQ0wsd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFBZ0M7SUFFMUM7Ozs7WUFDQTs7OztjQUVMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ2Isd0JBQUMsVUFBRDtNQUNFLGVBQWUsZ0JBQWdCLElBQUk7TUFDbkMsV0FBVTtnQkFGWixDQUlFLHdCQUFDLE1BQUQsRUFBTSxXQUFVLFVBQVc7Ozs7Z0JBQzNCLHdCQUFDLFFBQUQsWUFBTSxxQkFBd0I7Ozs7Y0FDeEI7Ozs7OztJQUNMOzs7O1lBQ0Y7Ozs7OztHQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FFRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNaO01BQUM7TUFBTztNQUFXO01BQWM7TUFBUztLQUFXLENBQUMsQ0FBQyxLQUFLLE9BQzNELHdCQUFDLFVBQUQ7TUFFRSxlQUFlLGdCQUFnQixFQUFFO01BQ2pDLFdBQVcsbURBQ1QsaUJBQWlCLEtBQ2IscUNBQ0E7Z0JBR0wsT0FBTyxRQUFRLGFBQWE7S0FDdkIsR0FURDs7OztZQVNDLENBQ1Q7SUFDRTs7OztjQUdMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxRQUFELEVBQVEsV0FBVSxzRUFBdUU7Ozs7ZUFDekYsd0JBQUMsU0FBRDtNQUNFLE1BQUs7TUFDTCxhQUFZO01BQ1osT0FBTztNQUNQLFdBQVcsTUFBTSxjQUFjLEVBQUUsT0FBTyxLQUFLO01BQzdDLFdBQVU7S0FDWDs7OzthQUNFOzs7OztZQUNGOzs7Ozs7R0FHTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNiLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ2Isd0JBQUMsU0FBRDtNQUFPLFdBQVU7Z0JBQWpCLENBQ0Usd0JBQUMsU0FBRDtPQUFPLFdBQVU7aUJBQ2Ysd0JBQUMsTUFBRDtRQUNFLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUFZO1FBQWU7Ozs7O1FBQ3pDLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUFZO1FBQWlCOzs7OztRQUMzQyx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBWTtRQUFVOzs7OztRQUNwQyx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBWTtRQUFtQjs7Ozs7UUFDN0Msd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQVk7UUFBUTs7Ozs7UUFDbEMsd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQVk7UUFBVTs7Ozs7UUFDcEMsd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQXVCO1FBQU87Ozs7O1FBQzVDLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUF1QjtRQUFXOzs7OztPQUM5Qzs7Ozs7TUFDQzs7OztnQkFDUCx3QkFBQyxTQUFEO09BQU8sV0FBVTtpQkFDZCxTQUFTLEtBQUssTUFDYix3QkFBQyxNQUFEO1FBQWUsV0FBVTtrQkFBekI7U0FDRSx3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFBaUQsRUFBRTtTQUFhOzs7OztTQUM5RSx3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFBZCxDQUNFLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUF3QixFQUFFO1VBQVU7Ozs7b0JBQ2xELEVBQUUsU0FBUyx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBMkMsRUFBRTtVQUFXOzs7O2tCQUNqRjs7Ozs7O1NBQ0osd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQXdDLEVBQUU7U0FBVzs7Ozs7U0FDbkUsd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQTBDLEVBQUU7U0FBZ0I7Ozs7O1NBQzFFLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUFvRCxFQUFFO1NBQVM7Ozs7O1NBQzdFLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUNaLHdCQUFDLFVBQUQ7V0FDRSxPQUFPLEVBQUU7V0FDVCxXQUFXLE1BQU0sZUFBZSxFQUFFLElBQUksRUFBRSxPQUFPLEtBQVk7V0FDM0QsV0FBVyx1RkFDVCxFQUFFLFdBQVcsVUFDVCw2REFDQSxFQUFFLFdBQVcsY0FDYixvREFDQSxFQUFFLFdBQVcsZUFDYix1REFDQTtxQkFWUjtZQWFFLHdCQUFDLFVBQUQ7YUFBUSxPQUFNO2FBQVUsV0FBVTt1QkFBNkI7WUFBZTs7Ozs7WUFDOUUsd0JBQUMsVUFBRDthQUFRLE9BQU07YUFBYSxXQUFVO3VCQUE4QjtZQUFrQjs7Ozs7WUFDckYsd0JBQUMsVUFBRDthQUFRLE9BQU07YUFBUSxXQUFVO3VCQUFnQztZQUFhOzs7OztZQUM3RSx3QkFBQyxVQUFEO2FBQVEsT0FBTTthQUFZLFdBQVU7dUJBQTZCO1lBQWlCOzs7OztXQUM1RTs7Ozs7O1NBQ047Ozs7O1NBQ0osd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQWQsQ0FBNEUsS0FBRSxFQUFFLE1BQVc7Ozs7OztTQUMzRix3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFBZCxDQUNFLHdCQUFDLEtBQUQ7V0FDRSxNQUFNLG1CQUFtQixFQUFFLE9BQU8sbUJBQW1CLG1CQUFtQixFQUFFLElBQUksRUFBRSxhQUFhLG1CQUFtQixFQUFFLFdBQVcsRUFBRSw2QkFBNkIsRUFBRSxTQUFTLHFCQUFxQixFQUFFLE9BQU8saUJBQWlCLG1CQUFtQixTQUFTLFFBQVEsRUFBRTtXQUM1UCxRQUFPO1dBQ1AsS0FBSTtXQUNKLE9BQU07V0FDTixXQUFVO3FCQUVWLHdCQUFDLE1BQUQsRUFBTSxXQUFVLGNBQWU7Ozs7O1VBQzlCOzs7O29CQUNILHdCQUFDLFVBQUQ7V0FDRSxlQUFlLGlCQUFpQixFQUFFLEVBQUU7V0FDcEMsT0FBTTtXQUNOLFdBQVU7cUJBRVYsd0JBQUMsUUFBRCxFQUFRLFdBQVUsY0FBZTs7Ozs7VUFDM0I7Ozs7a0JBQ047Ozs7OztRQUNGO1VBaERLLEVBQUU7Ozs7Y0FnRFAsQ0FDTDtNQUNJOzs7O2NBQ0Y7Ozs7OztJQUNKOzs7OztHQUNGOzs7OztHQUdKLGdCQUNDLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ2Isd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQWlDO01BQWtDOzs7O2dCQUNuRix3QkFBQyxVQUFEO09BQVEsZUFBZSxnQkFBZ0IsS0FBSztPQUFHLFdBQVU7aUJBQWtDO01BQVM7Ozs7Y0FDakc7Ozs7O2VBRUwsd0JBQUMsUUFBRDtNQUFNLFVBQVU7TUFBaUIsV0FBVTtnQkFBM0M7T0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQTBDO09BQTJCOzs7O2lCQUN0Rix3QkFBQyxTQUFEO1FBQ0UsTUFBSztRQUNMO1FBQ0EsYUFBWTtRQUNaLE9BQU87UUFDUCxXQUFXLE1BQU0sUUFBUSxFQUFFLE9BQU8sS0FBSztRQUN2QyxXQUFVO09BQ1g7Ozs7ZUFDRTs7Ozs7T0FFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQTBDO09BQTBCOzs7O2lCQUNyRix3QkFBQyxTQUFEO1FBQ0UsTUFBSztRQUNMLGFBQVk7UUFDWixPQUFPO1FBQ1AsV0FBVyxNQUFNLFVBQVUsRUFBRSxPQUFPLEtBQUs7UUFDekMsV0FBVTtPQUNYOzs7O2VBQ0U7Ozs7O09BRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7UUFBTyxXQUFVO2tCQUEwQztPQUFtQjs7OztpQkFDOUUsd0JBQUMsU0FBRDtRQUNFLE1BQUs7UUFDTCxPQUFPO1FBQ1AsV0FBVyxNQUFNLGVBQWUsRUFBRSxPQUFPLEtBQUs7UUFDOUMsYUFBWTtRQUNaLFdBQVU7T0FDWDs7OztlQUNFOzs7OztPQUVMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7U0FBTyxXQUFVO21CQUEwQztRQUFzQjs7OztrQkFDakYsd0JBQUMsU0FBRDtTQUNFLE1BQUs7U0FDTCxPQUFPO1NBQ1AsV0FBVyxNQUFNLFlBQVksRUFBRSxPQUFPLEtBQUs7U0FDM0MsYUFBWTtTQUNaLFdBQVU7UUFDWDs7OztnQkFDRTs7OztrQkFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtTQUFPLFdBQVU7bUJBQTBDO1FBQWlCOzs7O2tCQUM1RSx3QkFBQyxTQUFEO1NBQ0UsTUFBSztTQUNMLE9BQU87U0FDUCxXQUFXLE1BQU0sVUFBVSxPQUFPLEVBQUUsT0FBTyxLQUFLLENBQUM7U0FDakQsV0FBVTtRQUNYOzs7O2dCQUNFOzs7O2dCQUNGOzs7Ozs7T0FFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQTBDO09BQTRCOzs7O2lCQUN2Rix3QkFBQyxTQUFEO1FBQ0UsTUFBSztRQUNMLE9BQU87UUFDUCxXQUFXLE1BQU0sU0FBUyxFQUFFLE9BQU8sS0FBSztRQUN4QyxhQUFZO1FBQ1osV0FBVTtPQUNYOzs7O2VBQ0U7Ozs7O09BRUwsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxVQUFEO1NBQ0UsTUFBSztTQUNMLFdBQVU7bUJBQ1g7UUFFTzs7OztrQkFDUix3QkFBQyxVQUFEO1NBQ0UsTUFBSztTQUNMLGVBQWUsZ0JBQWdCLEtBQUs7U0FDcEMsV0FBVTttQkFDWDtRQUVPOzs7O2dCQUNMOzs7Ozs7TUFDRDs7Ozs7YUFDSDs7Ozs7O0dBQ0Y7Ozs7O0VBRUo7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkN1c3RvbWVyQ3JtVmlldy50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgXG4gIFVzZXJzLCBcbiAgU2VhcmNoLCBcbiAgUGx1cywgXG4gIFNlbmQsIFxuICBDaGVja0NpcmNsZTIsIFxuICBDbG9jaywgXG4gIEFsZXJ0Q2lyY2xlLCBcbiAgVHJhc2gyLCBcbiAgRmlsZVNwcmVhZHNoZWV0LFxuICBFZGl0LFxuICBQaG9uZVxufSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuaW1wb3J0IHsgQ3VzdG9tZXJSZWNvcmQsIFNob3BTZXR0aW5ncyB9IGZyb20gJy4uL3R5cGVzJztcblxuaW50ZXJmYWNlIEN1c3RvbWVyQ3JtVmlld1Byb3BzIHtcbiAgY3VzdG9tZXJzOiBDdXN0b21lclJlY29yZFtdO1xuICBzZXR0aW5nczogU2hvcFNldHRpbmdzO1xuICBvbkFkZEN1c3RvbWVyOiAoY3VzdG9tZXI6IEN1c3RvbWVyUmVjb3JkKSA9PiB2b2lkO1xuICBvblVwZGF0ZVN0YXR1czogKGlkOiBzdHJpbmcsIG5ld1N0YXR1czogQ3VzdG9tZXJSZWNvcmRbJ3N0YXR1cyddKSA9PiB2b2lkO1xuICBvbkRlbGV0ZUN1c3RvbWVyOiAoaWQ6IHN0cmluZykgPT4gdm9pZDtcbn1cblxuZXhwb3J0IGNvbnN0IEN1c3RvbWVyQ3JtVmlldzogUmVhY3QuRkM8Q3VzdG9tZXJDcm1WaWV3UHJvcHM+ID0gKHtcbiAgY3VzdG9tZXJzLFxuICBzZXR0aW5ncyxcbiAgb25BZGRDdXN0b21lcixcbiAgb25VcGRhdGVTdGF0dXMsXG4gIG9uRGVsZXRlQ3VzdG9tZXJcbn0pID0+IHtcbiAgY29uc3QgW3NlYXJjaFRlcm0sIHNldFNlYXJjaFRlcm1dID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbc3RhdHVzRmlsdGVyLCBzZXRTdGF0dXNGaWx0ZXJdID0gdXNlU3RhdGU8c3RyaW5nPignYWxsJyk7XG4gIGNvbnN0IFtzaG93QWRkTW9kYWwsIHNldFNob3dBZGRNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XG5cbiAgLy8gTmV3IGN1c3RvbWVyIGZvcm0gc3RhdGVcbiAgY29uc3QgW25hbWUsIHNldE5hbWVdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbbW9iaWxlLCBzZXRNb2JpbGVdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbc2VydmljZVR5cGUsIHNldFNlcnZpY2VUeXBlXSA9IHVzZVN0YXRlKCdNYWpoaSBMYWRraSBCYWhpbiBZb2phbmEnKTtcbiAgY29uc3QgW2Fja1Rva2VuLCBzZXRBY2tUb2tlbl0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFthbW91bnQsIHNldEFtb3VudF0gPSB1c2VTdGF0ZTxudW1iZXI+KDEwMCk7XG4gIGNvbnN0IFtub3Rlcywgc2V0Tm90ZXNdID0gdXNlU3RhdGUoJycpO1xuXG4gIGNvbnN0IGhhbmRsZUFkZFN1Ym1pdCA9IChlOiBSZWFjdC5Gb3JtRXZlbnQpID0+IHtcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgaWYgKCFuYW1lLnRyaW0oKSkgcmV0dXJuO1xuXG4gICAgY29uc3QgbmV3UmVjOiBDdXN0b21lclJlY29yZCA9IHtcbiAgICAgIGlkOiBgY3VzdC0ke0RhdGUubm93KCl9YCxcbiAgICAgIG5hbWU6IG5hbWUudHJpbSgpLFxuICAgICAgbW9iaWxlOiBtb2JpbGUudHJpbSgpIHx8ICdOL0EnLFxuICAgICAgc2VydmljZVR5cGU6IHNlcnZpY2VUeXBlLnRyaW0oKSxcbiAgICAgIGFja1Rva2VuOiBhY2tUb2tlbi50cmltKCkgfHwgYFRPSy0ke01hdGguZmxvb3IoMTAwMDAgKyBNYXRoLnJhbmRvbSgpICogOTAwMDApfWAsXG4gICAgICBzdGF0dXM6ICdQZW5kaW5nJyxcbiAgICAgIGRhdGU6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zbGljZSgwLCAxMCksXG4gICAgICBhbW91bnQ6IE51bWJlcihhbW91bnQpIHx8IDAsXG4gICAgICBub3Rlczogbm90ZXMudHJpbSgpXG4gICAgfTtcblxuICAgIG9uQWRkQ3VzdG9tZXIobmV3UmVjKTtcbiAgICBzZXRTaG93QWRkTW9kYWwoZmFsc2UpO1xuICAgIHNldE5hbWUoJycpO1xuICAgIHNldE1vYmlsZSgnJyk7XG4gICAgc2V0QWNrVG9rZW4oJycpO1xuICAgIHNldE5vdGVzKCcnKTtcbiAgfTtcblxuICBjb25zdCBmaWx0ZXJlZCA9IGN1c3RvbWVycy5maWx0ZXIoYyA9PiB7XG4gICAgY29uc3QgbWF0Y2hlc1NlYXJjaCA9IFxuICAgICAgYy5uYW1lLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoc2VhcmNoVGVybS50b0xvd2VyQ2FzZSgpKSB8fFxuICAgICAgYy5tb2JpbGUuaW5jbHVkZXMoc2VhcmNoVGVybSkgfHxcbiAgICAgIGMuc2VydmljZVR5cGUudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhzZWFyY2hUZXJtLnRvTG93ZXJDYXNlKCkpIHx8XG4gICAgICBjLmFja1Rva2VuLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoc2VhcmNoVGVybS50b0xvd2VyQ2FzZSgpKTtcbiAgICBjb25zdCBtYXRjaGVzU3RhdHVzID0gc3RhdHVzRmlsdGVyID09PSAnYWxsJyB8fCBjLnN0YXR1cy50b0xvd2VyQ2FzZSgpID09PSBzdGF0dXNGaWx0ZXIudG9Mb3dlckNhc2UoKTtcbiAgICByZXR1cm4gbWF0Y2hlc1NlYXJjaCAmJiBtYXRjaGVzU3RhdHVzO1xuICB9KTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XG4gICAgICB7LyogSGVhZGVyIGJhciAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBzbTppdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBwLTQgcm91bmRlZC0yeGwgc2hhZG93LW1kXCI+XG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1leHRyYWJvbGQgdGV4dC13aGl0ZVwiPkN1c3RvbWVyIENSTSAmIEpvYiBUcmFja2VyPC9oMT5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJnLWJsdWUtNTAwLzIwIHRleHQtYmx1ZS00MDAgYm9yZGVyIGJvcmRlci1ibHVlLTUwMC8zMCB0ZXh0LXhzIHB4LTIgcHktMC41IHJvdW5kZWQtZnVsbCBmb250LW1vbm8gZm9udC1ib2xkXCI+XG4gICAgICAgICAgICAgIHtjdXN0b21lcnMubGVuZ3RofSBSZWNvcmRzXG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMCBtdC0wLjVcIj5cbiAgICAgICAgICAgIFRyYWNrIGN1c3RvbWVyIGFwcGxpY2F0aW9ucywgYmlvbWV0cmljIHZlcmlmaWNhdGlvbiBzdGF0dXMsIGRlbGl2ZXJ5IGFsZXJ0cyAmIFdoYXRzQXBwIHVwZGF0ZXNcbiAgICAgICAgICA8L3A+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93QWRkTW9kYWwodHJ1ZSl9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IGJnLWJsdWUtNjAwIGhvdmVyOmJnLWJsdWUtNTAwIHRleHQtd2hpdGUgZm9udC1ib2xkIHRleHQteHMgcHgtMy41IHB5LTIgcm91bmRlZC14bCBzaGFkb3ctbGcgc2hhZG93LWJsdWUtNjAwLzMwIHRyYW5zaXRpb24tYWxsIGhvdmVyOnNjYWxlLTEwNVwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPFBsdXMgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICA8c3Bhbj4rIEFkZCBDdXN0b21lciBKb2I8L3NwYW4+XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBGaWx0ZXJzICYgU2VhcmNoIFJvdyAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBzbTppdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zIGJnLXNsYXRlLTkwMC84MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBwLTMgcm91bmRlZC14bFwiPlxuICAgICAgICB7LyogU3RhdHVzIENoaXBzICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgb3ZlcmZsb3cteC1hdXRvIHRleHQteHNcIj5cbiAgICAgICAgICB7WydhbGwnLCAnUGVuZGluZycsICdQcm9jZXNzaW5nJywgJ1JlYWR5JywgJ0RlbGl2ZXJlZCddLm1hcCgoc3QpID0+IChcbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAga2V5PXtzdH1cbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U3RhdHVzRmlsdGVyKHN0KX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtMyBweS0xLjUgcm91bmRlZC1sZyBmb250LWJvbGQgdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgICAgICAgICBzdGF0dXNGaWx0ZXIgPT09IHN0XG4gICAgICAgICAgICAgICAgICA/ICdiZy1ibHVlLTYwMCB0ZXh0LXdoaXRlIHNoYWRvdy1zbSdcbiAgICAgICAgICAgICAgICAgIDogJ2JnLXNsYXRlLTk1MCB0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXdoaXRlIGJvcmRlciBib3JkZXItc2xhdGUtODAwJ1xuICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAge3N0ID09PSAnYWxsJyA/ICdBbGwgSm9icycgOiBzdH1cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICkpfVxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogU2VhcmNoICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlXCI+XG4gICAgICAgICAgPFNlYXJjaCBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LXNsYXRlLTQwMCBhYnNvbHV0ZSBsZWZ0LTMgdG9wLTEvMiAtdHJhbnNsYXRlLXktMS8yXCIgLz5cbiAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VhcmNoIGJ5IG5hbWUsIHBob25lLCB0b2tlbi4uLlwiXG4gICAgICAgICAgICB2YWx1ZT17c2VhcmNoVGVybX1cbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2VhcmNoVGVybShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCBwbC04IHByLTMgcHktMS41IHRleHQteHMgdGV4dC13aGl0ZSBwbGFjZWhvbGRlci1zbGF0ZS01MDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgc206dy02NFwiXG4gICAgICAgICAgLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIEN1c3RvbWVycyBUYWJsZSAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtMnhsIG92ZXJmbG93LWhpZGRlbiBzaGFkb3ctbWRcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvdmVyZmxvdy14LWF1dG9cIj5cbiAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQtbGVmdCB0ZXh0LXhzXCI+XG4gICAgICAgICAgICA8dGhlYWQgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTUwIHRleHQtc2xhdGUtNDAwIGJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDAgZm9udC1tb25vXCI+XG4gICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMyBweC00XCI+VG9rZW4gLyBBY2s8L3RoPlxuICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zIHB4LTRcIj5DdXN0b21lciBOYW1lPC90aD5cbiAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMyBweC00XCI+TW9iaWxlPC90aD5cbiAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMyBweC00XCI+U2VydmljZSBBcHBsaWVkPC90aD5cbiAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMyBweC00XCI+RGF0ZTwvdGg+XG4gICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTMgcHgtNFwiPlN0YXR1czwvdGg+XG4gICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTMgcHgtNCB0ZXh0LXJpZ2h0XCI+RmVlPC90aD5cbiAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMyBweC00IHRleHQtcmlnaHRcIj5BY3Rpb25zPC90aD5cbiAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgIDwvdGhlYWQ+XG4gICAgICAgICAgICA8dGJvZHkgY2xhc3NOYW1lPVwiZGl2aWRlLXkgZGl2aWRlLXNsYXRlLTgwMC82MFwiPlxuICAgICAgICAgICAgICB7ZmlsdGVyZWQubWFwKChjKSA9PiAoXG4gICAgICAgICAgICAgICAgPHRyIGtleT17Yy5pZH0gY2xhc3NOYW1lPVwiaG92ZXI6Ymctc2xhdGUtODAwLzQwIHRyYW5zaXRpb24tY29sb3JzXCI+XG4gICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMy41IHB4LTQgZm9udC1tb25vIGZvbnQtYm9sZCB0ZXh0LWJsdWUtNDAwXCI+e2MuYWNrVG9rZW59PC90ZD5cbiAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zLjUgcHgtNFwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXdoaXRlXCI+e2MubmFtZX08L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAge2Mubm90ZXMgJiYgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTQwMCBsaW5lLWNsYW1wLTFcIj57Yy5ub3Rlc308L2Rpdj59XG4gICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMuNSBweC00IGZvbnQtbW9ubyB0ZXh0LXNsYXRlLTMwMFwiPntjLm1vYmlsZX08L3RkPlxuICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMuNSBweC00IGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtMjAwXCI+e2Muc2VydmljZVR5cGV9PC90ZD5cbiAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zLjUgcHgtNCBmb250LW1vbm8gdGV4dC1zbGF0ZS00MDAgdGV4dC1bMTFweF1cIj57Yy5kYXRlfTwvdGQ+XG4gICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMy41IHB4LTRcIj5cbiAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtjLnN0YXR1c31cbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IG9uVXBkYXRlU3RhdHVzKGMuaWQsIGUudGFyZ2V0LnZhbHVlIGFzIGFueSl9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdGV4dC1bMTFweF0gZm9udC1ib2xkIHB4LTIgcHktMSByb3VuZGVkLWxnIGJvcmRlciBmb2N1czpvdXRsaW5lLW5vbmUgY3Vyc29yLXBvaW50ZXIgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGMuc3RhdHVzID09PSAnUmVhZHknXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLWVtZXJhbGQtNTAwLzIwIHRleHQtZW1lcmFsZC0zMDAgYm9yZGVyLWVtZXJhbGQtNTAwLzQwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICA6IGMuc3RhdHVzID09PSAnRGVsaXZlcmVkJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1ibHVlLTUwMC8yMCB0ZXh0LWJsdWUtMzAwIGJvcmRlci1ibHVlLTUwMC80MCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgOiBjLnN0YXR1cyA9PT0gJ1Byb2Nlc3NpbmcnXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLWFtYmVyLTUwMC8yMCB0ZXh0LWFtYmVyLTMwMCBib3JkZXItYW1iZXItNTAwLzQwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICA6ICdiZy1yb3NlLTUwMC8yMCB0ZXh0LXJvc2UtMzAwIGJvcmRlci1yb3NlLTUwMC80MCdcbiAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJQZW5kaW5nXCIgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwIHRleHQtcm9zZS0zMDBcIj5QZW5kaW5nPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlByb2Nlc3NpbmdcIiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAgdGV4dC1hbWJlci0zMDBcIj5Qcm9jZXNzaW5nPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlJlYWR5XCIgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwIHRleHQtZW1lcmFsZC0zMDBcIj5SZWFkeTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJEZWxpdmVyZWRcIiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAgdGV4dC1ibHVlLTMwMFwiPkRlbGl2ZXJlZDwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMy41IHB4LTQgdGV4dC1yaWdodCBmb250LW1vbm8gZm9udC1ib2xkIHRleHQtZW1lcmFsZC00MDBcIj7igrl7Yy5hbW91bnR9PC90ZD5cbiAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zLjUgcHgtNCB0ZXh0LXJpZ2h0IHNwYWNlLXgtMSB3aGl0ZXNwYWNlLW5vd3JhcFwiPlxuICAgICAgICAgICAgICAgICAgICA8YVxuICAgICAgICAgICAgICAgICAgICAgIGhyZWY9e2BodHRwczovL3dhLm1lLzkxJHtjLm1vYmlsZX0/dGV4dD1OYW1hc2thciUyMCR7ZW5jb2RlVVJJQ29tcG9uZW50KGMubmFtZSl9LCUyMHlvdXIlMjAke2VuY29kZVVSSUNvbXBvbmVudChjLnNlcnZpY2VUeXBlKX0lMjBhcHBsaWNhdGlvbiUyMChUb2tlbjolMjAke2MuYWNrVG9rZW59KSUyMHN0YXR1cyUyMGlzOiUyMCR7Yy5zdGF0dXN9LiUyMFJlZ2FyZHMsJTIwJHtlbmNvZGVVUklDb21wb25lbnQoc2V0dGluZ3Muc2hvcE5hbWUpfS5gfVxuICAgICAgICAgICAgICAgICAgICAgIHRhcmdldD1cIl9ibGFua1wiXG4gICAgICAgICAgICAgICAgICAgICAgcmVsPVwibm9vcGVuZXIgbm9yZWZlcnJlclwiXG4gICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJXaGF0c0FwcCBTdGF0dXMgQWxlcnRcIlxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMS41IHJvdW5kZWQtbGcgYmctZW1lcmFsZC02MDAvMjAgaG92ZXI6YmctZW1lcmFsZC02MDAvNDAgdGV4dC1lbWVyYWxkLTQwMCBpbmxpbmUtYmxvY2sgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgPFNlbmQgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8L2E+XG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvbkRlbGV0ZUN1c3RvbWVyKGMuaWQpfVxuICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiRGVsZXRlIEN1c3RvbWVyIFJlY29yZFwiXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xLjUgcm91bmRlZC1sZyBiZy1yb3NlLTUwMC8xMCBob3ZlcjpiZy1yb3NlLTUwMC8yMCB0ZXh0LXJvc2UtNDAwIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIDxUcmFzaDIgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICA8L3Rib2R5PlxuICAgICAgICAgIDwvdGFibGU+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBBZGQgQ3VzdG9tZXIgTW9kYWwgKi99XG4gICAgICB7c2hvd0FkZE1vZGFsICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIGJnLWJsYWNrLzc1IHotNTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC00XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0yeGwgbWF4LXctbWQgdy1mdWxsIHAtNSBzaGFkb3ctMnhsIHNwYWNlLXktNFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMCBwYi0zXCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXdoaXRlIHRleHQtYmFzZVwiPk5ldyBDdXN0b21lciBBcHBsaWNhdGlvbiBKb2I8L3NwYW4+XG4gICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gc2V0U2hvd0FkZE1vZGFsKGZhbHNlKX0gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC13aGl0ZVwiPuKclTwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVBZGRTdWJtaXR9IGNsYXNzTmFtZT1cInNwYWNlLXktMyB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtMzAwIGZvbnQtc2VtaWJvbGQgYmxvY2sgbWItMVwiPkN1c3RvbWVyIEZ1bGwgTmFtZSAqPC9sYWJlbD5cbiAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImUuZy4gU2hhaWtoIFNhbWVlclwiXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17bmFtZX1cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0TmFtZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQteGwgcHgtMyBweS0yIHRleHQtd2hpdGVcIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtMzAwIGZvbnQtc2VtaWJvbGQgYmxvY2sgbWItMVwiPk1vYmlsZSAvIFdoYXRzQXBwICo8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRlbFwiXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIjEwIGRpZ2l0IG51bWJlclwiXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17bW9iaWxlfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRNb2JpbGUoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLXhsIHB4LTMgcHktMiB0ZXh0LXdoaXRlIGZvbnQtbW9ub1wiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS0zMDAgZm9udC1zZW1pYm9sZCBibG9jayBtYi0xXCI+U2VydmljZSBUeXBlPC9sYWJlbD5cbiAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZXJ2aWNlVHlwZX1cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2VydmljZVR5cGUoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJlLmcuIE1hamhpIExhZGtpIEJhaGluIFlvamFuYSwgUEFOIENhcmRcIlxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLXhsIHB4LTMgcHktMiB0ZXh0LXdoaXRlXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtMzAwIGZvbnQtc2VtaWJvbGQgYmxvY2sgbWItMVwiPkFjayAvIFRva2VuIE5vLjwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17YWNrVG9rZW59XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0QWNrVG9rZW4oZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkF1dG8tZ2VuZXJhdGVkIGlmIGJsYW5rXCJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLXhsIHB4LTMgcHktMiB0ZXh0LXdoaXRlIGZvbnQtbW9ub1wiXG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS0zMDAgZm9udC1zZW1pYm9sZCBibG9jayBtYi0xXCI+QW1vdW50ICjigrkpPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Ftb3VudH1cbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRBbW91bnQoTnVtYmVyKGUudGFyZ2V0LnZhbHVlKSl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCBweC0zIHB5LTIgdGV4dC13aGl0ZSBmb250LW1vbm9cIlxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS0zMDAgZm9udC1zZW1pYm9sZCBibG9jayBtYi0xXCI+Sm9iIFJlbWFya3MgLyBEZXRhaWxzPC9sYWJlbD5cbiAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtub3Rlc31cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Tm90ZXMoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJlLmcuIEFhZGhhYXIgc2VlZGluZyBwZW5kaW5nIGluIEJhbmsgb2YgTWFoYXJhc2h0cmFcIlxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLXhsIHB4LTMgcHktMiB0ZXh0LXdoaXRlXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTIgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXgtMSBiZy1ibHVlLTYwMCBob3ZlcjpiZy1ibHVlLTUwMCB0ZXh0LXdoaXRlIGZvbnQtYm9sZCBweS0yLjUgcm91bmRlZC14bCB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgU2F2ZSBDdXN0b21lciBKb2JcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dBZGRNb2RhbChmYWxzZSl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIuNSBiZy1zbGF0ZS04MDAgdGV4dC1zbGF0ZS0zMDAgcm91bmRlZC14bCBob3ZlcjpiZy1zbGF0ZS03NTBcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIENhbmNlbFxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZm9ybT5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuICAgIDwvZGl2PlxuICApO1xufTtcbiJdfQ==