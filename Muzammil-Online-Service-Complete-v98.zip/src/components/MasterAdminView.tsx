const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=090625a0";
import { ShieldCheck, Lock, Unlock, Smartphone, Laptop, RotateCcw, UserPlus, Trash2, Download, CheckCircle2, Clock, Key, Archive, RefreshCw, Cpu, Monitor, ClipboardList, Sparkles, Circle } from "/node_modules/.vite/deps/lucide-react.js?v=090625a0";
import { getRegisteredOperators, resetOperatorPcBinding, resetOperatorMobileBinding, resetOperatorAllBindings, toggleOperatorLock, addNewOperator, deleteOperator, getSecurityAuditLogs, getHardwareDeviceId, getHardwareDeviceName, isMobileDevice } from "/src/utils/deviceSecurity.ts";
import { generateProjectZip, triggerDownloadZip } from "/src/utils/projectZip.ts";
var _jsxFileName = "/app/applet/src/components/MasterAdminView.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=090625a0";
const MASTER_WORKFLOW_STEPS = [
	{
		stepNumber: 1,
		title: "Customer Intake & Service Identification",
		description: "Welcome citizen, verify Aadhaar linked mobile, check document prerequisites, and quote transparent rates.",
		toolsUsed: [
			"Dashboard",
			"50+ Govt Portals Hub",
			"AI Assistant"
		],
		checklist: [
			"Check customer Aadhaar & active mobile OTP availability",
			"Inform customer of official portal charges + service fee",
			"Record customer name & WhatsApp number in CRM",
			"Issue physical or digital queue token"
		],
		tips: "Aadhaar mein active mobile number hona PM-KISAN, Ladki Bahin, aur Mahadbt schemes ke liye anivarya hai."
	},
	{
		stepNumber: 2,
		title: "Official Portal Filing & Document Submission",
		description: "Log into central/state portal (Aaple Sarkar, Sarathi, Mahadbt), complete form entry, and submit.",
		toolsUsed: ["50+ Govt Portals Directory", "PDF to HD JPG Converter"],
		checklist: [
			"Enter applicant details matching Aadhaar letter by letter",
			"If portal requires JPG under 100KB, use PDF to JPG tool to compress documents",
			"Verify uploaded certificate previews before final submission",
			"Download and save official acknowledgement PDF"
		],
		tips: "Acknowledgement Receipt Token Number hamesha download karke Customer CRM mein note karein."
	},
	{
		stepNumber: 3,
		title: "Studio Photo & PVC Smart Card Processing",
		description: "Produce high-precision CR-80 PVC cards or 35x45mm passport photo sheets.",
		toolsUsed: ["PVC Smart Card Maker", "Passport Photo Studio Pro"],
		checklist: [
			"Passport Photo: Select 4×6 Landscape (8 Copies @ 300 DPI) or A4 Landscape",
			"Background: Use Connected Magic Wand or Pen Tool to cut out person and set White/Studio Blue BG",
			"Auto Beauty: Apply AI Face Smoothing to brighten skin tones and reduce camera shadows",
			"Exam Strip: Add Candidate Name & Date stamp for SSC GD, Police Bharti, or Railway forms",
			"PVC Card: Align Front & Back cards to standard CR-80 (85.6×54mm) with center cut guide line"
		],
		tips: "PVC Card print karte waqt printer properties mein \"High Quality Glossy Photo Paper\" select karein."
	},
	{
		stepNumber: 4,
		title: "300 DPI Physical Printing & Thermal Lamination",
		description: "Execute in-app borderless printing on photo paper, cut cards, and laminate.",
		toolsUsed: ["In-App Direct Print Engine (Ctrl + P)"],
		checklist: [
			"Load 4×6 inch (10×15 cm) Glossy Photo Paper into printer",
			"Press \"🖨️ Direct Print Sheet (Ctrl + P)\" directly inside studio",
			"Cut along pre-aligned guide marks",
			"For PVC Smart Cards: Pass through thermal laminator for durable waterproof finish"
		],
		tips: "In-app direct print zero popup blocker ke saath seedha connected printer par 300 DPI job bhejta hai."
	},
	{
		stepNumber: 5,
		title: "POS Billing & Thermal Receipt Generation",
		description: "Generate itemized tax invoice or 58mm/80mm thermal slip with dynamic UPI QR code.",
		toolsUsed: ["Fast Billing Desk POS"],
		checklist: [
			"Select service package (e.g. PVC Card ₹70, Passport Photo 8-copies ₹50, Online Form ₹100)",
			"Display dynamic UPI QR code on screen for instant customer payment",
			"Print 58mm thermal receipt or A4 official tax invoice for customer records",
			"Update payment status as \"Paid\" in ledger"
		],
		tips: "Thermal receipt par shop ka authorized signature aur non-refundable portal terms automatic aate hain."
	},
	{
		stepNumber: 6,
		title: "Customer Handover & Daily Cash Reconciliation",
		description: "Hand over laminated cards, passport photos in sleeve, and portal acknowledgement.",
		toolsUsed: ["Customer CRM & Job Tracker"],
		checklist: [
			"Hand over laminated cards, passport photos in sleeve, and portal acknowledgement",
			"Send WhatsApp confirmation with status update",
			"Mark job as \"Delivered\" in CRM Tracker",
			"Daily reconciliation: Check total cash + UPI collections in Billing Desk Summary"
		],
		tips: "Din ke end par Daily Ledger Summary se cash counter balance match karein."
	}
];
export const MasterAdminView = ({ settings, onUpdateSettings, onNavigateToWorkflow }) => {
	const [operators, setOperators] = useState([]);
	const [auditLogs, setAuditLogs] = useState([]);
	const [activeSubTab, setActiveSubTab] = useState("operators");
	// New Operator Modal State
	const [showAddModal, setShowAddModal] = useState(false);
	const [newUsername, setNewUsername] = useState("");
	const [newPassword, setNewPassword] = useState("");
	const [newDisplayName, setNewDisplayName] = useState("");
	const [newPhone, setNewPhone] = useState("");
	const [addError, setAddError] = useState("");
	// Project ZIP Export State
	const [isExportingZip, setIsExportingZip] = useState(false);
	const [zipProgress, setZipProgress] = useState({
		percent: 0,
		file: ""
	});
	// Notifications
	const [alertMessage, setAlertMessage] = useState(null);
	// Shop Settings Form
	const [shopForm, setShopForm] = useState(settings);
	// Workflow Checklist state inside Master Admin
	const [completedSteps, setCompletedSteps] = useState({});
	const currentDeviceId = getHardwareDeviceId();
	const currentDeviceName = getHardwareDeviceName();
	const currentIsMobile = isMobileDevice();
	const loadData = () => {
		setOperators(getRegisteredOperators());
		setAuditLogs(getSecurityAuditLogs());
	};
	useEffect(() => {
		loadData();
	}, []);
	// Handle Reset PC Binding
	const handleResetPc = (operatorId, username) => {
		if (window.confirm(`Reset PC Device Binding for "${username}"? Operator can now log in on a new PC/Laptop.`)) {
			resetOperatorPcBinding(operatorId);
			loadData();
			setAlertMessage(`✅ PC device binding cleared for ${username}. Operator can bind a new PC.`);
			setTimeout(() => setAlertMessage(null), 4e3);
		}
	};
	// Handle Reset Mobile Binding
	const handleResetMobile = (operatorId, username) => {
		if (window.confirm(`Reset Mobile Device Binding for "${username}"? Operator can now log in on a new Smartphone.`)) {
			resetOperatorMobileBinding(operatorId);
			loadData();
			setAlertMessage(`✅ Mobile device binding cleared for ${username}. Operator can bind a new phone.`);
			setTimeout(() => setAlertMessage(null), 4e3);
		}
	};
	// Handle Reset All Devices (PC + Mobile)
	const handleResetAllDevices = (operatorId, username) => {
		if (window.confirm(`Reset BOTH PC & Mobile bindings for "${username}"?`)) {
			resetOperatorAllBindings(operatorId);
			loadData();
			setAlertMessage(`✅ All device bindings (PC & Mobile) cleared for ${username}.`);
			setTimeout(() => setAlertMessage(null), 4e3);
		}
	};
	// Handle Toggle Lock
	const handleToggleLock = (operatorId, username) => {
		toggleOperatorLock(operatorId);
		loadData();
		setAlertMessage(`Lock status updated for ${username}`);
		setTimeout(() => setAlertMessage(null), 3e3);
	};
	// Handle Delete Operator
	const handleDeleteOperator = (operatorId, username) => {
		if (window.confirm(`Permanently delete operator account "${username}"?`)) {
			deleteOperator(operatorId);
			loadData();
			setAlertMessage(`Operator ${username} deleted`);
			setTimeout(() => setAlertMessage(null), 3e3);
		}
	};
	// Handle Add Operator
	const handleCreateOperator = (e) => {
		e.preventDefault();
		setAddError("");
		if (!newUsername.trim() || !newPassword.trim() || !newDisplayName.trim()) {
			setAddError("Please fill all required fields");
			return;
		}
		const success = addNewOperator({
			username: newUsername.trim().toLowerCase(),
			password: newPassword.trim(),
			displayName: newDisplayName.trim(),
			role: "operator",
			phone: newPhone.trim() || "9561460313"
		});
		if (success) {
			setShowAddModal(false);
			setNewUsername("");
			setNewPassword("");
			setNewDisplayName("");
			setNewPhone("");
			loadData();
			setAlertMessage("✅ New Operator ID created! Permitted on 1 Authorized PC + 1 Authorized Mobile.");
			setTimeout(() => setAlertMessage(null), 4e3);
		} else {
			setAddError("Username already exists. Please choose another username.");
		}
	};
	// Handle Download Project ZIP
	const handleDownloadZip = async () => {
		setIsExportingZip(true);
		setZipProgress({
			percent: 10,
			file: "Gathering project source files..."
		});
		try {
			const zipBlob = await generateProjectZip((percent, file) => {
				setZipProgress({
					percent,
					file
				});
			});
			triggerDownloadZip(zipBlob, `Muzammil-Online-Service-Complete-v98.zip`);
			setAlertMessage("📦 Complete original project source code (.ZIP) downloaded successfully!");
			setTimeout(() => setAlertMessage(null), 4e3);
		} catch (e) {
			console.error(e);
			window.location.href = "/api/download-zip";
		} finally {
			setIsExportingZip(false);
		}
	};
	// Handle Save Shop Settings
	const handleSaveSettings = (e) => {
		e.preventDefault();
		onUpdateSettings(shopForm);
		setAlertMessage("✅ Shop details and configuration saved!");
		setTimeout(() => setAlertMessage(null), 3e3);
	};
	const completedWorkflowCount = Object.values(completedSteps).filter(Boolean).length;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-md flex flex-col sm:flex-row sm:items-center justify-between gap-4",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2 flex-wrap",
					children: [/* @__PURE__ */ _jsxDEV("h1", {
						className: "text-xl font-extrabold text-white flex items-center gap-2",
						children: [/* @__PURE__ */ _jsxDEV(ShieldCheck, { className: "w-6 h-6 text-blue-400" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 303,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Master Admin Control Panel" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 304,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 302,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs px-2.5 py-0.5 rounded-full font-mono font-bold flex items-center gap-1.5",
						children: [/* @__PURE__ */ _jsxDEV(Monitor, { className: "w-3.5 h-3.5 text-blue-400" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 307,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "1 PC + 1 Mobile per Operator ID" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 308,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 306,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 301,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "text-xs text-slate-400 mt-1",
					children: "Same ID works across Shop PC & Operator Mobile • Project .ZIP Source Export • Cyber Cafe Workflow & SOP"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 311,
					columnNumber: 11
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 300,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2 flex-wrap",
					children: /* @__PURE__ */ _jsxDEV("button", {
						onClick: handleDownloadZip,
						disabled: isExportingZip,
						className: "flex items-center gap-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-extrabold text-xs px-4 py-2.5 rounded-xl shadow-lg shadow-emerald-600/20 transition-all hover:scale-105 disabled:opacity-50",
						title: "Download full project source code archive (.zip)",
						children: [/* @__PURE__ */ _jsxDEV(Archive, { className: "w-4 h-4" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 324,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: isExportingZip ? "Packing ZIP..." : "📦 Download Project .ZIP" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 325,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 318,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 317,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 299,
				columnNumber: 7
			}, this),
			alertMessage && /* @__PURE__ */ _jsxDEV("div", {
				className: "p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs flex items-center justify-between animate-in fade-in",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ _jsxDEV(CheckCircle2, { className: "w-4 h-4 text-emerald-400 flex-shrink-0" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 334,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: alertMessage }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 335,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 333,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					onClick: () => setAlertMessage(null),
					className: "text-emerald-400 hover:text-white",
					children: "✕"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 337,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 332,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center gap-1.5 bg-slate-900 border border-slate-800 p-1.5 rounded-xl text-xs font-bold overflow-x-auto",
				children: [
					/* @__PURE__ */ _jsxDEV("button", {
						onClick: () => setActiveSubTab("operators"),
						className: `flex items-center gap-1.5 px-4 py-2 rounded-lg transition-all ${activeSubTab === "operators" ? "bg-blue-600 text-white shadow" : "text-slate-400 hover:text-white"}`,
						children: [/* @__PURE__ */ _jsxDEV(Monitor, { className: "w-3.5 h-3.5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 351,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: [
							"Operator IDs (PC & Mobile Locks) (",
							operators.length,
							")"
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 352,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 343,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						onClick: () => setActiveSubTab("workflow"),
						className: `flex items-center gap-1.5 px-4 py-2 rounded-lg transition-all ${activeSubTab === "workflow" ? "bg-blue-600 text-white shadow" : "text-slate-400 hover:text-white"}`,
						children: [/* @__PURE__ */ _jsxDEV(ClipboardList, { className: "w-3.5 h-3.5 text-amber-400" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 363,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Cyber Cafe Workflow & SOP" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 364,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 355,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						onClick: () => setActiveSubTab("zip_download"),
						className: `flex items-center gap-1.5 px-4 py-2 rounded-lg transition-all ${activeSubTab === "zip_download" ? "bg-blue-600 text-white shadow" : "text-slate-400 hover:text-white"}`,
						children: [/* @__PURE__ */ _jsxDEV(Archive, { className: "w-3.5 h-3.5 text-emerald-400" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 375,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Project (.ZIP) Export" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 376,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 367,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						onClick: () => setActiveSubTab("logs"),
						className: `flex items-center gap-1.5 px-4 py-2 rounded-lg transition-all ${activeSubTab === "logs" ? "bg-blue-600 text-white shadow" : "text-slate-400 hover:text-white"}`,
						children: [/* @__PURE__ */ _jsxDEV(Clock, { className: "w-3.5 h-3.5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 387,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Security & Device Logs" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 388,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 379,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						onClick: () => setActiveSubTab("settings"),
						className: `flex items-center gap-1.5 px-4 py-2 rounded-lg transition-all ${activeSubTab === "settings" ? "bg-blue-600 text-white shadow" : "text-slate-400 hover:text-white"}`,
						children: [/* @__PURE__ */ _jsxDEV(Key, { className: "w-3.5 h-3.5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 399,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Shop Configuration" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 400,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 391,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 342,
				columnNumber: 7
			}, this),
			activeSubTab === "operators" && /* @__PURE__ */ _jsxDEV("div", {
				className: "bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800",
						children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
							className: "text-base font-extrabold text-white flex items-center gap-2",
							children: [/* @__PURE__ */ _jsxDEV("span", { children: "Authorized Operators (PC + Mobile Binding)" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 410,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20 font-mono",
								children: "1 PC + 1 Mobile Per ID"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 411,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 409,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-slate-400 mt-0.5",
							children: [
								"Each operator ID can work on ",
								/* @__PURE__ */ _jsxDEV("b", { children: "1 authorized PC" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 416,
									columnNumber: 46
								}, this),
								" AND ",
								/* @__PURE__ */ _jsxDEV("b", { children: "1 authorized Mobile" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 416,
									columnNumber: 73
								}, this),
								" at the same time. Third-party devices are blocked automatically."
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 415,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 408,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setShowAddModal(true),
							className: "flex items-center gap-1.5 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs px-3.5 py-2 rounded-xl shadow transition-all self-start sm:self-auto",
							children: [/* @__PURE__ */ _jsxDEV(UserPlus, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 424,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Register New Operator ID" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 425,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 420,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 407,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "p-3.5 rounded-xl bg-slate-950 border border-slate-800 text-xs flex items-center justify-between flex-wrap gap-2 text-slate-300",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2",
							children: [
								/* @__PURE__ */ _jsxDEV(Cpu, { className: "w-4 h-4 text-blue-400" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 432,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("span", { children: [
									"Your Current Machine (",
									currentIsMobile ? "📱 Mobile" : "💻 PC",
									"):"
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 433,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("code", {
									className: "text-white font-mono font-bold bg-slate-900 px-2 py-0.5 rounded border border-slate-700",
									children: currentDeviceId
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 434,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 431,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "text-slate-400 font-mono text-[11px]",
							children: currentDeviceName
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 438,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 430,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "overflow-x-auto",
						children: /* @__PURE__ */ _jsxDEV("table", {
							className: "w-full text-left text-xs",
							children: [/* @__PURE__ */ _jsxDEV("thead", { children: /* @__PURE__ */ _jsxDEV("tr", {
								className: "border-b border-slate-800 text-slate-400 uppercase tracking-wider font-semibold",
								children: [
									/* @__PURE__ */ _jsxDEV("th", {
										className: "py-3 px-3",
										children: "Operator / Username"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 446,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("th", {
										className: "py-3 px-3",
										children: "Role"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 447,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("th", {
										className: "py-3 px-3",
										children: "Authorized PC (1 Max)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 448,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("th", {
										className: "py-3 px-3",
										children: "Authorized Mobile (1 Max)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 449,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("th", {
										className: "py-3 px-3",
										children: "Status"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 450,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("th", {
										className: "py-3 px-3 text-right",
										children: "Device Actions"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 451,
										columnNumber: 19
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 445,
								columnNumber: 17
							}, this) }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 444,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("tbody", {
								className: "divide-y divide-slate-800/60",
								children: operators.map((op) => /* @__PURE__ */ _jsxDEV("tr", {
									className: "hover:bg-slate-950/40 transition-colors",
									children: [
										/* @__PURE__ */ _jsxDEV("td", {
											className: "py-3 px-3",
											children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "font-bold text-white text-sm",
												children: op.displayName
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 459,
												columnNumber: 23
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "text-slate-400 font-mono text-[11px]",
												children: [
													"@",
													op.username,
													" • ",
													op.phone
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 460,
												columnNumber: 23
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 458,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("td", {
											className: "py-3 px-3",
											children: /* @__PURE__ */ _jsxDEV("span", {
												className: `px-2 py-0.5 rounded text-[10px] font-bold uppercase font-mono ${op.role === "admin" ? "bg-purple-500/20 text-purple-300 border border-purple-500/30" : "bg-blue-500/20 text-blue-300 border border-blue-500/30"}`,
												children: op.role === "admin" ? "Master Admin" : "Operator"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 465,
												columnNumber: 23
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 464,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("td", {
											className: "py-3 px-3",
											children: op.boundPcDeviceId ? /* @__PURE__ */ _jsxDEV("div", {
												className: "space-y-0.5",
												children: [
													/* @__PURE__ */ _jsxDEV("div", {
														className: "flex items-center gap-1.5 font-bold text-blue-400",
														children: [/* @__PURE__ */ _jsxDEV(Laptop, { className: "w-3.5 h-3.5 text-blue-400" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 479,
															columnNumber: 29
														}, this), /* @__PURE__ */ _jsxDEV("span", {
															className: "font-mono text-[11px]",
															children: op.boundPcDeviceId
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 480,
															columnNumber: 29
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 478,
														columnNumber: 27
													}, this),
													/* @__PURE__ */ _jsxDEV("div", {
														className: "text-[10px] text-slate-400 truncate max-w-[160px]",
														children: op.boundPcDeviceName || "PC Workstation"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 482,
														columnNumber: 27
													}, this),
													/* @__PURE__ */ _jsxDEV("button", {
														onClick: () => handleResetPc(op.id, op.username),
														className: "text-[10px] text-amber-400 hover:underline flex items-center gap-0.5 font-bold pt-0.5",
														children: [/* @__PURE__ */ _jsxDEV(RotateCcw, { className: "w-2.5 h-2.5" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 487,
															columnNumber: 29
														}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Reset PC Binding" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 488,
															columnNumber: 29
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 483,
														columnNumber: 27
													}, this)
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 477,
												columnNumber: 25
											}, this) : /* @__PURE__ */ _jsxDEV("span", {
												className: "text-[10px] text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20 font-medium",
												children: "Unbound PC (Pending)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 492,
												columnNumber: 25
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 475,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("td", {
											className: "py-3 px-3",
											children: op.boundMobileDeviceId ? /* @__PURE__ */ _jsxDEV("div", {
												className: "space-y-0.5",
												children: [
													/* @__PURE__ */ _jsxDEV("div", {
														className: "flex items-center gap-1.5 font-bold text-purple-400",
														children: [/* @__PURE__ */ _jsxDEV(Smartphone, { className: "w-3.5 h-3.5 text-purple-400" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 503,
															columnNumber: 29
														}, this), /* @__PURE__ */ _jsxDEV("span", {
															className: "font-mono text-[11px]",
															children: op.boundMobileDeviceId
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 504,
															columnNumber: 29
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 502,
														columnNumber: 27
													}, this),
													/* @__PURE__ */ _jsxDEV("div", {
														className: "text-[10px] text-slate-400 truncate max-w-[160px]",
														children: op.boundMobileDeviceName || "Smartphone"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 506,
														columnNumber: 27
													}, this),
													/* @__PURE__ */ _jsxDEV("button", {
														onClick: () => handleResetMobile(op.id, op.username),
														className: "text-[10px] text-amber-400 hover:underline flex items-center gap-0.5 font-bold pt-0.5",
														children: [/* @__PURE__ */ _jsxDEV(RotateCcw, { className: "w-2.5 h-2.5" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 511,
															columnNumber: 29
														}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Reset Mobile Binding" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 512,
															columnNumber: 29
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 507,
														columnNumber: 27
													}, this)
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 501,
												columnNumber: 25
											}, this) : /* @__PURE__ */ _jsxDEV("span", {
												className: "text-[10px] text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20 font-medium",
												children: "Unbound Mobile (Pending)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 516,
												columnNumber: 25
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 499,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("td", {
											className: "py-3 px-3",
											children: op.isLocked ? /* @__PURE__ */ _jsxDEV("span", {
												className: "px-2 py-0.5 rounded bg-rose-500/20 text-rose-300 border border-rose-500/30 font-bold text-[10px] uppercase",
												children: "Suspended"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 525,
												columnNumber: 25
											}, this) : /* @__PURE__ */ _jsxDEV("span", {
												className: "px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold text-[10px] uppercase flex items-center gap-1 w-fit",
												children: [/* @__PURE__ */ _jsxDEV("span", { className: "w-1.5 h-1.5 rounded-full bg-emerald-400" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 530,
													columnNumber: 27
												}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Active" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 531,
													columnNumber: 27
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 529,
												columnNumber: 25
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 523,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("td", {
											className: "py-3 px-3 text-right",
											children: /* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center justify-end gap-1.5 flex-wrap",
												children: [
													(op.boundPcDeviceId || op.boundMobileDeviceId) && /* @__PURE__ */ _jsxDEV("button", {
														onClick: () => handleResetAllDevices(op.id, op.username),
														className: "px-2 py-1 rounded-lg bg-amber-500/10 text-amber-300 border border-amber-500/30 hover:bg-amber-500/20 font-bold text-[10px] transition-colors",
														title: "Reset both PC and Mobile bindings",
														children: "Reset All"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 541,
														columnNumber: 27
													}, this),
													op.role !== "admin" && /* @__PURE__ */ _jsxDEV("button", {
														onClick: () => handleToggleLock(op.id, op.username),
														className: `p-1.5 rounded-lg border text-xs ${op.isLocked ? "bg-emerald-500/10 text-emerald-300 border-emerald-500/30 hover:bg-emerald-500/20" : "bg-slate-800 text-slate-400 border-slate-700 hover:text-white"}`,
														title: op.isLocked ? "Unlock Operator" : "Suspend Operator",
														children: op.isLocked ? /* @__PURE__ */ _jsxDEV(Unlock, { className: "w-3.5 h-3.5" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 561,
															columnNumber: 44
														}, this) : /* @__PURE__ */ _jsxDEV(Lock, { className: "w-3.5 h-3.5" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 561,
															columnNumber: 81
														}, this)
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 552,
														columnNumber: 27
													}, this),
													op.role !== "admin" && /* @__PURE__ */ _jsxDEV("button", {
														onClick: () => handleDeleteOperator(op.id, op.username),
														className: "p-1.5 rounded-lg bg-rose-500/10 text-rose-400 border border-rose-500/20 hover:bg-rose-500/20 text-xs",
														title: "Delete Operator",
														children: /* @__PURE__ */ _jsxDEV(Trash2, { className: "w-3.5 h-3.5" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 572,
															columnNumber: 29
														}, this)
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 567,
														columnNumber: 27
													}, this)
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 538,
												columnNumber: 23
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 537,
											columnNumber: 21
										}, this)
									]
								}, op.id, true, {
									fileName: _jsxFileName,
									lineNumber: 456,
									columnNumber: 19
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 454,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 443,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 442,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 406,
				columnNumber: 9
			}, this),
			activeSubTab === "workflow" && /* @__PURE__ */ _jsxDEV("div", {
				className: "bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800",
					children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
						className: "text-base font-extrabold text-white flex items-center gap-2",
						children: [
							/* @__PURE__ */ _jsxDEV(ClipboardList, { className: "w-5 h-5 text-amber-400" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 591,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("span", { children: "Cyber Cafe Standard Operating Procedure (SOP)" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 592,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20 font-mono",
								children: "Master Workflow"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 593,
								columnNumber: 17
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 590,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "text-xs text-slate-400 mt-0.5",
						children: "Standardized 6-stage operational protocol for all CSC & Cyber Cafe services"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 597,
						columnNumber: 15
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 589,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "bg-slate-950 px-3 py-1.5 rounded-xl border border-slate-800 text-xs font-mono text-slate-300",
						children: ["Checklist: ", /* @__PURE__ */ _jsxDEV("strong", {
							className: "text-emerald-400",
							children: [
								completedWorkflowCount,
								" / ",
								MASTER_WORKFLOW_STEPS.length,
								" Completed"
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 603,
							columnNumber: 26
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 602,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 588,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "grid grid-cols-1 md:grid-cols-2 gap-4",
					children: MASTER_WORKFLOW_STEPS.map((step) => {
						const isDone = !!completedSteps[step.stepNumber];
						return /* @__PURE__ */ _jsxDEV("div", {
							className: `p-4 rounded-xl border transition-all space-y-3 ${isDone ? "bg-slate-950/60 border-emerald-500/40" : "bg-slate-950 border-slate-800 hover:border-slate-700"}`,
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: `w-6 h-6 rounded-lg flex items-center justify-center font-bold text-xs font-mono ${isDone ? "bg-emerald-500 text-slate-950" : "bg-blue-600 text-white"}`,
											children: step.stepNumber
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 622,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("h3", {
											className: "font-extrabold text-white text-xs",
											children: step.title
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 627,
											columnNumber: 23
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 621,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("button", {
										onClick: () => setCompletedSteps((prev) => ({
											...prev,
											[step.stepNumber]: !prev[step.stepNumber]
										})),
										className: `flex items-center gap-1 text-[11px] font-bold px-2 py-0.5 rounded-md border ${isDone ? "bg-emerald-500/20 text-emerald-300 border-emerald-500/30" : "bg-slate-900 text-slate-400 border-slate-700"}`,
										children: [isDone ? /* @__PURE__ */ _jsxDEV(CheckCircle2, { className: "w-3.5 h-3.5 text-emerald-400" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 638,
											columnNumber: 33
										}, this) : /* @__PURE__ */ _jsxDEV(Circle, { className: "w-3.5 h-3.5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 638,
											columnNumber: 93
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: isDone ? "Done" : "Mark" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 639,
											columnNumber: 23
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 630,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 620,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-[11px] text-slate-300 leading-snug",
									children: step.description
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 643,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-1 pt-1 border-t border-slate-800/80",
									children: step.checklist.map((item, idx) => /* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-start gap-1.5 text-[11px] text-slate-400",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "text-blue-500",
											children: "•"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 648,
											columnNumber: 25
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: item }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 649,
											columnNumber: 25
										}, this)]
									}, idx, true, {
										fileName: _jsxFileName,
										lineNumber: 647,
										columnNumber: 23
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 645,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "p-2 rounded-lg bg-slate-900 text-[10px] text-amber-300/90 flex items-start gap-1.5",
									children: [/* @__PURE__ */ _jsxDEV(Sparkles, { className: "w-3 h-3 text-amber-400 flex-shrink-0 mt-0.5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 655,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: [
										/* @__PURE__ */ _jsxDEV("b", { children: "Operator Note:" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 656,
											columnNumber: 27
										}, this),
										" ",
										step.tips
									] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 656,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 654,
									columnNumber: 19
								}, this)
							]
						}, step.stepNumber, true, {
							fileName: _jsxFileName,
							lineNumber: 612,
							columnNumber: 17
						}, this);
					})
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 608,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 587,
				columnNumber: 9
			}, this),
			activeSubTab === "zip_download" && /* @__PURE__ */ _jsxDEV("div", {
				className: "bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-6",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-start gap-4",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "w-14 h-14 rounded-2xl bg-gradient-to-tr from-emerald-600/20 to-teal-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400 flex-shrink-0 shadow-inner",
							children: /* @__PURE__ */ _jsxDEV(Archive, { className: "w-7 h-7" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 670,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 669,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-1",
							children: [/* @__PURE__ */ _jsxDEV("h2", {
								className: "text-lg font-extrabold text-white",
								children: "Download Complete Original Project Source (.ZIP)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 673,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-slate-300 leading-relaxed",
								children: "Download the complete, standalone offline codebase of Muzammil Online Service suite containing all components, server, styles, package configuration, and assets."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 674,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 672,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 668,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "text-xs font-bold text-white block",
							children: "Archive Package Contents:"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 681,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2 text-xs text-slate-400",
							children: [
								/* @__PURE__ */ _jsxDEV("div", { children: "• PVC Smart Card Studio (CR-80)" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 683,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: "• Passport Photo Studio Pro" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 684,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: "• Fast POS Billing Desk & Receipts" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 685,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: "• Customer CRM & Ledger" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 686,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: "• BioData & CV Maker Engine" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 687,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: "• 50+ Govt Citizen Portals Hub" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 688,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: "• Dual Device Locking (PC + Mobile)" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 689,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: "• Server.ts Express & Gemini Proxy" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 690,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: "• Complete Offline PWA Manifest" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 691,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 682,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 680,
						columnNumber: 11
					}, this),
					isExportingZip && /* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-2 p-4 rounded-xl bg-slate-950 border border-emerald-500/30 animate-pulse",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex justify-between text-xs text-emerald-400 font-bold",
							children: [/* @__PURE__ */ _jsxDEV("span", { children: ["Packing ZIP Archive: ", zipProgress.file] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 699,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: [zipProgress.percent, "%"] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 700,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 698,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "w-full bg-slate-800 h-2 rounded-full overflow-hidden",
							children: /* @__PURE__ */ _jsxDEV("div", {
								className: "bg-emerald-500 h-full transition-all duration-200",
								style: { width: `${zipProgress.percent}%` }
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 703,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 702,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 697,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-3 flex-wrap",
						children: [/* @__PURE__ */ _jsxDEV("button", {
							onClick: handleDownloadZip,
							disabled: isExportingZip,
							className: "flex items-center gap-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-extrabold text-sm px-6 py-3 rounded-xl shadow-lg shadow-emerald-600/30 transition-all hover:scale-105 disabled:opacity-50",
							children: [/* @__PURE__ */ _jsxDEV(Download, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 717,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: isExportingZip ? "Compressing Project..." : "Download Project .ZIP Archive" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 718,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 712,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("a", {
							href: "/api/download-zip",
							download: "Muzammil-Online-Service-Complete-Source.zip",
							className: "text-xs text-blue-400 hover:underline flex items-center gap-1 font-semibold",
							children: /* @__PURE__ */ _jsxDEV("span", { children: "Direct Server Download Link" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 726,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 721,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 711,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 667,
				columnNumber: 9
			}, this),
			activeSubTab === "logs" && /* @__PURE__ */ _jsxDEV("div", {
				className: "bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center justify-between pb-3 border-b border-slate-800",
					children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
						className: "text-base font-extrabold text-white",
						children: "Real-Time Security & Device Audit Log"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 737,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "text-xs text-slate-400",
						children: "Record of all authorized PC & Mobile logins, device locks, and blocked access attempts"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 738,
						columnNumber: 15
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 736,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: loadData,
						className: "flex items-center gap-1 px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white text-xs font-semibold",
						children: [/* @__PURE__ */ _jsxDEV(RefreshCw, { className: "w-3.5 h-3.5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 744,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Refresh Logs" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 745,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 740,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 735,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "overflow-x-auto max-h-96",
					children: /* @__PURE__ */ _jsxDEV("table", {
						className: "w-full text-left text-xs",
						children: [/* @__PURE__ */ _jsxDEV("thead", {
							className: "sticky top-0 bg-slate-900 border-b border-slate-800 text-slate-400",
							children: /* @__PURE__ */ _jsxDEV("tr", { children: [
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-2.5 px-3",
									children: "Timestamp"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 753,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-2.5 px-3",
									children: "Action"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 754,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-2.5 px-3",
									children: "Operator"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 755,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-2.5 px-3",
									children: "Type"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 756,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-2.5 px-3",
									children: "Device ID"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 757,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-2.5 px-3",
									children: "Details"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 758,
									columnNumber: 19
								}, this)
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 752,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 751,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("tbody", {
							className: "divide-y divide-slate-800/60 font-mono text-[11px]",
							children: auditLogs.length > 0 ? auditLogs.map((log) => /* @__PURE__ */ _jsxDEV("tr", {
								className: "hover:bg-slate-950/40",
								children: [
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-2.5 px-3 text-slate-400",
										children: log.timestamp
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 765,
										columnNumber: 23
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-2.5 px-3",
										children: /* @__PURE__ */ _jsxDEV("span", {
											className: `px-2 py-0.5 rounded text-[10px] font-bold ${log.action === "LOGIN_SUCCESS" ? "bg-emerald-500/20 text-emerald-400" : log.action === "DEVICE_BLOCKED" ? "bg-rose-500/20 text-rose-400" : log.action === "DEVICE_BOUND" ? "bg-blue-500/20 text-blue-400" : "bg-amber-500/20 text-amber-400"}`,
											children: log.action
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 767,
											columnNumber: 25
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 766,
										columnNumber: 23
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-2.5 px-3 text-white font-bold",
										children: ["@", log.username]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 779,
										columnNumber: 23
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-2.5 px-3 text-slate-400",
										children: log.deviceType === "mobile" ? "📱 Mobile" : "💻 PC"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 780,
										columnNumber: 23
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-2.5 px-3 text-slate-300",
										children: log.deviceId
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 781,
										columnNumber: 23
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-2.5 px-3 text-slate-400 max-w-xs truncate font-sans",
										children: log.details
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 782,
										columnNumber: 23
									}, this)
								]
							}, log.id, true, {
								fileName: _jsxFileName,
								lineNumber: 764,
								columnNumber: 21
							}, this)) : /* @__PURE__ */ _jsxDEV("tr", { children: /* @__PURE__ */ _jsxDEV("td", {
								colSpan: 6,
								className: "py-6 text-center text-slate-500",
								children: "No security audit logs recorded yet."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 787,
								columnNumber: 21
							}, this) }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 786,
								columnNumber: 19
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 761,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 750,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 749,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 734,
				columnNumber: 9
			}, this),
			activeSubTab === "settings" && /* @__PURE__ */ _jsxDEV("div", {
				className: "bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl max-w-2xl space-y-4",
				children: [/* @__PURE__ */ _jsxDEV("h2", {
					className: "text-base font-extrabold text-white",
					children: "Cyber Cafe & CSC Configuration"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 801,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("form", {
					onSubmit: handleSaveSettings,
					className: "space-y-4 text-xs",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "grid grid-cols-1 sm:grid-cols-2 gap-3",
						children: [
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "text-slate-400 block mb-1",
								children: "Shop / Center Name"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 805,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								value: shopForm.shopName,
								onChange: (e) => setShopForm({
									...shopForm,
									shopName: e.target.value
								}),
								className: "w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white font-bold"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 806,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 804,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "text-slate-400 block mb-1",
								children: "Owner Name"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 815,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								value: shopForm.ownerName,
								onChange: (e) => setShopForm({
									...shopForm,
									ownerName: e.target.value
								}),
								className: "w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white font-bold"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 816,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 814,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "text-slate-400 block mb-1",
								children: "WhatsApp / Contact Phone"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 825,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								value: shopForm.phone,
								onChange: (e) => setShopForm({
									...shopForm,
									phone: e.target.value
								}),
								className: "w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white font-bold"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 826,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 824,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "text-slate-400 block mb-1",
								children: "UPI ID for POS QR Code"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 835,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								value: shopForm.upiId,
								onChange: (e) => setShopForm({
									...shopForm,
									upiId: e.target.value
								}),
								className: "w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white font-bold"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 836,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 834,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "sm:col-span-2",
								children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "text-slate-400 block mb-1",
									children: "Address (Printed on receipts & invoices)"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 845,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									value: shopForm.address,
									onChange: (e) => setShopForm({
										...shopForm,
										address: e.target.value
									}),
									className: "w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 846,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 844,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 803,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						type: "submit",
						className: "px-5 py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl shadow transition-all",
						children: "Save Shop Settings"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 855,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 802,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 800,
				columnNumber: 9
			}, this),
			showAddModal && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-slate-900 border border-slate-800 rounded-3xl max-w-md w-full p-6 shadow-2xl space-y-4 animate-in fade-in zoom-in-95",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between pb-2 border-b border-slate-800",
							children: [/* @__PURE__ */ _jsxDEV("h3", {
								className: "font-extrabold text-white text-base flex items-center gap-2",
								children: [/* @__PURE__ */ _jsxDEV(UserPlus, { className: "w-5 h-5 text-blue-400" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 871,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Register New Operator ID" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 872,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 870,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setShowAddModal(false),
								className: "text-slate-400 hover:text-white",
								children: "✕"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 874,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 869,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-slate-300",
							children: [
								"This new operator ID will bind to ",
								/* @__PURE__ */ _jsxDEV("b", { children: "1 Authorized PC" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 878,
									columnNumber: 49
								}, this),
								" + ",
								/* @__PURE__ */ _jsxDEV("b", { children: "1 Authorized Mobile" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 878,
									columnNumber: 74
								}, this),
								" upon their first login from each device."
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 877,
							columnNumber: 13
						}, this),
						addError && /* @__PURE__ */ _jsxDEV("div", {
							className: "p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs",
							children: addError
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 882,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("form", {
							onSubmit: handleCreateOperator,
							className: "space-y-3 text-xs",
							children: [
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "text-slate-400 block mb-1",
									children: "Operator Full Name"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 889,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									required: true,
									placeholder: "e.g. Shaikh Sameer",
									value: newDisplayName,
									onChange: (e) => setNewDisplayName(e.target.value),
									className: "w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white font-bold"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 890,
									columnNumber: 17
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 888,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "text-slate-400 block mb-1",
									children: "Username (Login ID)"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 901,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									required: true,
									placeholder: "e.g. operator3",
									value: newUsername,
									onChange: (e) => setNewUsername(e.target.value),
									className: "w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white font-mono font-bold"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 902,
									columnNumber: 17
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 900,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "text-slate-400 block mb-1",
									children: "Password"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 913,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "password",
									required: true,
									placeholder: "Create secure password",
									value: newPassword,
									onChange: (e) => setNewPassword(e.target.value),
									className: "w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 914,
									columnNumber: 17
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 912,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "text-slate-400 block mb-1",
									children: "Phone Number"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 925,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "tel",
									placeholder: "Mobile number",
									value: newPhone,
									onChange: (e) => setNewPhone(e.target.value),
									className: "w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 926,
									columnNumber: 17
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 924,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "pt-2 flex items-center justify-end gap-2",
									children: [/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => setShowAddModal(false),
										className: "px-4 py-2 bg-slate-800 text-slate-300 font-bold rounded-xl",
										children: "Cancel"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 936,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("button", {
										type: "submit",
										className: "px-5 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl shadow",
										children: "Register Operator"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 943,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 935,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 887,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 868,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 867,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 297,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsaUJBQWlCO0FBQzNDLFNBQ0UsYUFDQSxNQUNBLFFBQ0EsWUFDQSxRQUNBLFdBQ0EsVUFDQSxRQUNBLFVBQ0EsY0FFQSxPQUNBLEtBSUEsU0FDQSxXQUNBLEtBQ0EsU0FDQSxlQUNBLFVBQ0EsY0FFSztBQUVQLFNBQ0Usd0JBQ0Esd0JBQ0EsNEJBQ0EsMEJBQ0Esb0JBQ0EsZ0JBQ0EsZ0JBQ0Esc0JBRUEscUJBQ0EsdUJBQ0Esc0JBQ0s7QUFDUCxTQUFTLG9CQUFvQiwwQkFBMEI7OztBQWlCdkQsTUFBTSx3QkFBd0M7Q0FDNUM7RUFDRSxZQUFZO0VBQ1osT0FBTztFQUNQLGFBQWE7RUFDYixXQUFXO0dBQUM7R0FBYTtHQUF3QjtFQUFjO0VBQy9ELFdBQVc7R0FDVDtHQUNBO0dBQ0E7R0FDQTtFQUNGO0VBQ0EsTUFBTTtDQUNSO0NBQ0E7RUFDRSxZQUFZO0VBQ1osT0FBTztFQUNQLGFBQWE7RUFDYixXQUFXLENBQUMsOEJBQThCLHlCQUF5QjtFQUNuRSxXQUFXO0dBQ1Q7R0FDQTtHQUNBO0dBQ0E7RUFDRjtFQUNBLE1BQU07Q0FDUjtDQUNBO0VBQ0UsWUFBWTtFQUNaLE9BQU87RUFDUCxhQUFhO0VBQ2IsV0FBVyxDQUFDLHdCQUF3QiwyQkFBMkI7RUFDL0QsV0FBVztHQUNUO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7RUFDRjtFQUNBLE1BQU07Q0FDUjtDQUNBO0VBQ0UsWUFBWTtFQUNaLE9BQU87RUFDUCxhQUFhO0VBQ2IsV0FBVyxDQUFDLHVDQUF1QztFQUNuRCxXQUFXO0dBQ1Q7R0FDQTtHQUNBO0dBQ0E7RUFDRjtFQUNBLE1BQU07Q0FDUjtDQUNBO0VBQ0UsWUFBWTtFQUNaLE9BQU87RUFDUCxhQUFhO0VBQ2IsV0FBVyxDQUFDLHVCQUF1QjtFQUNuQyxXQUFXO0dBQ1Q7R0FDQTtHQUNBO0dBQ0E7RUFDRjtFQUNBLE1BQU07Q0FDUjtDQUNBO0VBQ0UsWUFBWTtFQUNaLE9BQU87RUFDUCxhQUFhO0VBQ2IsV0FBVyxDQUFDLDRCQUE0QjtFQUN4QyxXQUFXO0dBQ1Q7R0FDQTtHQUNBO0dBQ0E7RUFDRjtFQUNBLE1BQU07Q0FDUjtBQUNGO0FBRUEsT0FBTyxNQUFNLG1CQUFtRCxFQUM5RCxVQUNBLGtCQUNBLDJCQUNJO0NBQ0osTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQTRCLENBQUMsQ0FBQztDQUNoRSxNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBNkIsQ0FBQyxDQUFDO0NBQ2pFLE1BQU0sQ0FBQyxjQUFjLG1CQUFtQixTQUEwRSxXQUFXOztDQUc3SCxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBa0IsS0FBSztDQUMvRCxNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBaUIsRUFBRTtDQUN6RCxNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBaUIsRUFBRTtDQUN6RCxNQUFNLENBQUMsZ0JBQWdCLHFCQUFxQixTQUFpQixFQUFFO0NBQy9ELE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBaUIsRUFBRTtDQUNuRCxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQWlCLEVBQUU7O0NBR25ELE1BQU0sQ0FBQyxnQkFBZ0IscUJBQXFCLFNBQWtCLEtBQUs7Q0FDbkUsTUFBTSxDQUFDLGFBQWEsa0JBQWtCLFNBQTRDO0VBQUUsU0FBUztFQUFHLE1BQU07Q0FBRyxDQUFDOztDQUcxRyxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBd0IsSUFBSTs7Q0FHcEUsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUF1QixRQUFROztDQUcvRCxNQUFNLENBQUMsZ0JBQWdCLHFCQUFxQixTQUFrQyxDQUFDLENBQUM7Q0FFaEYsTUFBTSxrQkFBa0Isb0JBQW9CO0NBQzVDLE1BQU0sb0JBQW9CLHNCQUFzQjtDQUNoRCxNQUFNLGtCQUFrQixlQUFlO0NBRXZDLE1BQU0saUJBQWlCO0VBQ3JCLGFBQWEsdUJBQXVCLENBQUM7RUFDckMsYUFBYSxxQkFBcUIsQ0FBQztDQUNyQztDQUVBLGdCQUFnQjtFQUNkLFNBQVM7Q0FDWCxHQUFHLENBQUMsQ0FBQzs7Q0FHTCxNQUFNLGlCQUFpQixZQUFvQixhQUFxQjtFQUM5RCxJQUFJLE9BQU8sUUFBUSxnQ0FBZ0MsU0FBUywrQ0FBK0MsR0FBRztHQUM1Ryx1QkFBdUIsVUFBVTtHQUNqQyxTQUFTO0dBQ1QsZ0JBQWdCLG1DQUFtQyxTQUFTLDhCQUE4QjtHQUMxRixpQkFBaUIsZ0JBQWdCLElBQUksR0FBRyxHQUFJO0VBQzlDO0NBQ0Y7O0NBR0EsTUFBTSxxQkFBcUIsWUFBb0IsYUFBcUI7RUFDbEUsSUFBSSxPQUFPLFFBQVEsb0NBQW9DLFNBQVMsZ0RBQWdELEdBQUc7R0FDakgsMkJBQTJCLFVBQVU7R0FDckMsU0FBUztHQUNULGdCQUFnQix1Q0FBdUMsU0FBUyxpQ0FBaUM7R0FDakcsaUJBQWlCLGdCQUFnQixJQUFJLEdBQUcsR0FBSTtFQUM5QztDQUNGOztDQUdBLE1BQU0seUJBQXlCLFlBQW9CLGFBQXFCO0VBQ3RFLElBQUksT0FBTyxRQUFRLHdDQUF3QyxTQUFTLEdBQUcsR0FBRztHQUN4RSx5QkFBeUIsVUFBVTtHQUNuQyxTQUFTO0dBQ1QsZ0JBQWdCLG1EQUFtRCxTQUFTLEVBQUU7R0FDOUUsaUJBQWlCLGdCQUFnQixJQUFJLEdBQUcsR0FBSTtFQUM5QztDQUNGOztDQUdBLE1BQU0sb0JBQW9CLFlBQW9CLGFBQXFCO0VBQ2pFLG1CQUFtQixVQUFVO0VBQzdCLFNBQVM7RUFDVCxnQkFBZ0IsMkJBQTJCLFVBQVU7RUFDckQsaUJBQWlCLGdCQUFnQixJQUFJLEdBQUcsR0FBSTtDQUM5Qzs7Q0FHQSxNQUFNLHdCQUF3QixZQUFvQixhQUFxQjtFQUNyRSxJQUFJLE9BQU8sUUFBUSx3Q0FBd0MsU0FBUyxHQUFHLEdBQUc7R0FDeEUsZUFBZSxVQUFVO0dBQ3pCLFNBQVM7R0FDVCxnQkFBZ0IsWUFBWSxTQUFTLFNBQVM7R0FDOUMsaUJBQWlCLGdCQUFnQixJQUFJLEdBQUcsR0FBSTtFQUM5QztDQUNGOztDQUdBLE1BQU0sd0JBQXdCLE1BQXVCO0VBQ25ELEVBQUUsZUFBZTtFQUNqQixZQUFZLEVBQUU7RUFFZCxJQUFJLENBQUMsWUFBWSxLQUFLLEtBQUssQ0FBQyxZQUFZLEtBQUssS0FBSyxDQUFDLGVBQWUsS0FBSyxHQUFHO0dBQ3hFLFlBQVksaUNBQWlDO0dBQzdDO0VBQ0Y7RUFFQSxNQUFNLFVBQVUsZUFBZTtHQUM3QixVQUFVLFlBQVksS0FBSyxDQUFDLENBQUMsWUFBWTtHQUN6QyxVQUFVLFlBQVksS0FBSztHQUMzQixhQUFhLGVBQWUsS0FBSztHQUNqQyxNQUFNO0dBQ04sT0FBTyxTQUFTLEtBQUssS0FBSztFQUM1QixDQUFDO0VBRUQsSUFBSSxTQUFTO0dBQ1gsZ0JBQWdCLEtBQUs7R0FDckIsZUFBZSxFQUFFO0dBQ2pCLGVBQWUsRUFBRTtHQUNqQixrQkFBa0IsRUFBRTtHQUNwQixZQUFZLEVBQUU7R0FDZCxTQUFTO0dBQ1QsZ0JBQWdCLGdGQUFnRjtHQUNoRyxpQkFBaUIsZ0JBQWdCLElBQUksR0FBRyxHQUFJO0VBQzlDLE9BQU87R0FDTCxZQUFZLDBEQUEwRDtFQUN4RTtDQUNGOztDQUdBLE1BQU0sb0JBQW9CLFlBQVk7RUFDcEMsa0JBQWtCLElBQUk7RUFDdEIsZUFBZTtHQUFFLFNBQVM7R0FBSSxNQUFNO0VBQW9DLENBQUM7RUFFekUsSUFBSTtHQUNGLE1BQU0sVUFBVSxNQUFNLG9CQUFvQixTQUFTLFNBQVM7SUFDMUQsZUFBZTtLQUFFO0tBQVM7SUFBSyxDQUFDO0dBQ2xDLENBQUM7R0FFRCxtQkFBbUIsU0FBUywwQ0FBMEM7R0FDdEUsZ0JBQWdCLDBFQUEwRTtHQUMxRixpQkFBaUIsZ0JBQWdCLElBQUksR0FBRyxHQUFJO0VBQzlDLFNBQVMsR0FBRztHQUNWLFFBQVEsTUFBTSxDQUFDO0dBQ2YsT0FBTyxTQUFTLE9BQU87RUFDekIsVUFBVTtHQUNSLGtCQUFrQixLQUFLO0VBQ3pCO0NBQ0Y7O0NBR0EsTUFBTSxzQkFBc0IsTUFBdUI7RUFDakQsRUFBRSxlQUFlO0VBQ2pCLGlCQUFpQixRQUFRO0VBQ3pCLGdCQUFnQix5Q0FBeUM7RUFDekQsaUJBQWlCLGdCQUFnQixJQUFJLEdBQUcsR0FBSTtDQUM5QztDQUVBLE1BQU0seUJBQXlCLE9BQU8sT0FBTyxjQUFjLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDO0NBRTdFLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUVFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUFkLENBQ0Usd0JBQUMsYUFBRCxFQUFhLFdBQVUsd0JBQXlCOzs7O2dCQUNoRCx3QkFBQyxRQUFELFlBQU0sNkJBQWdDOzs7O2NBQ3BDOzs7OztlQUNKLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUFoQixDQUNFLHdCQUFDLFNBQUQsRUFBUyxXQUFVLDRCQUE2Qjs7OztnQkFDaEQsd0JBQUMsUUFBRCxZQUFNLGtDQUFxQzs7OztjQUN2Qzs7Ozs7YUFDSDs7Ozs7Y0FDTCx3QkFBQyxLQUFEO0tBQUcsV0FBVTtlQUE4QjtJQUV4Qzs7OztZQUNBOzs7O2NBR0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFDYix3QkFBQyxVQUFEO01BQ0UsU0FBUztNQUNULFVBQVU7TUFDVixXQUFVO01BQ1YsT0FBTTtnQkFKUixDQU1FLHdCQUFDLFNBQUQsRUFBUyxXQUFVLFVBQVc7Ozs7Z0JBQzlCLHdCQUFDLFFBQUQsWUFBTyxpQkFBaUIsbUJBQW1CLDJCQUFpQzs7OztjQUN0RTs7Ozs7O0lBQ0w7Ozs7WUFDRjs7Ozs7O0dBR0osZ0JBQ0Msd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxjQUFELEVBQWMsV0FBVSx5Q0FBMEM7Ozs7ZUFDbEUsd0JBQUMsUUFBRCxZQUFPLGFBQW1COzs7O2FBQ3ZCOzs7OztjQUNMLHdCQUFDLFVBQUQ7S0FBUSxlQUFlLGdCQUFnQixJQUFJO0tBQUcsV0FBVTtlQUFvQztJQUFTOzs7O1lBQ2xHOzs7Ozs7R0FJUCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmO0tBQ0Usd0JBQUMsVUFBRDtNQUNFLGVBQWUsZ0JBQWdCLFdBQVc7TUFDMUMsV0FBVyxpRUFDVCxpQkFBaUIsY0FDYixrQ0FDQTtnQkFMUixDQVFFLHdCQUFDLFNBQUQsRUFBUyxXQUFVLGNBQWU7Ozs7Z0JBQ2xDLHdCQUFDLFFBQUQ7T0FBTTtPQUFtQyxVQUFVO09BQU87TUFBTzs7OztjQUMzRDs7Ozs7O0tBRVIsd0JBQUMsVUFBRDtNQUNFLGVBQWUsZ0JBQWdCLFVBQVU7TUFDekMsV0FBVyxpRUFDVCxpQkFBaUIsYUFDYixrQ0FDQTtnQkFMUixDQVFFLHdCQUFDLGVBQUQsRUFBZSxXQUFVLDZCQUE4Qjs7OztnQkFDdkQsd0JBQUMsUUFBRCxZQUFNLDRCQUErQjs7OztjQUMvQjs7Ozs7O0tBRVIsd0JBQUMsVUFBRDtNQUNFLGVBQWUsZ0JBQWdCLGNBQWM7TUFDN0MsV0FBVyxpRUFDVCxpQkFBaUIsaUJBQ2Isa0NBQ0E7Z0JBTFIsQ0FRRSx3QkFBQyxTQUFELEVBQVMsV0FBVSwrQkFBZ0M7Ozs7Z0JBQ25ELHdCQUFDLFFBQUQsWUFBTSx3QkFBMkI7Ozs7Y0FDM0I7Ozs7OztLQUVSLHdCQUFDLFVBQUQ7TUFDRSxlQUFlLGdCQUFnQixNQUFNO01BQ3JDLFdBQVcsaUVBQ1QsaUJBQWlCLFNBQ2Isa0NBQ0E7Z0JBTFIsQ0FRRSx3QkFBQyxPQUFELEVBQU8sV0FBVSxjQUFlOzs7O2dCQUNoQyx3QkFBQyxRQUFELFlBQU0seUJBQTRCOzs7O2NBQzVCOzs7Ozs7S0FFUix3QkFBQyxVQUFEO01BQ0UsZUFBZSxnQkFBZ0IsVUFBVTtNQUN6QyxXQUFXLGlFQUNULGlCQUFpQixhQUNiLGtDQUNBO2dCQUxSLENBUUUsd0JBQUMsS0FBRCxFQUFLLFdBQVUsY0FBZTs7OztnQkFDOUIsd0JBQUMsUUFBRCxZQUFNLHFCQUF3Qjs7OztjQUN4Qjs7Ozs7O0lBQ0w7Ozs7OztHQUdKLGlCQUFpQixlQUNoQix3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmO0tBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQWQsQ0FDRSx3QkFBQyxRQUFELFlBQU0sNkNBQWdEOzs7O2lCQUN0RCx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBd0c7T0FFbEg7Ozs7ZUFDSjs7Ozs7Z0JBQ0osd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQWI7UUFBNkM7UUFDZCx3QkFBQyxLQUFELFlBQUcsa0JBQWtCOzs7OztRQUFDO1FBQUssd0JBQUMsS0FBRCxZQUFHLHNCQUFzQjs7Ozs7UUFBQztPQUNqRjs7Ozs7Y0FDQTs7OztnQkFFTCx3QkFBQyxVQUFEO09BQ0UsZUFBZSxnQkFBZ0IsSUFBSTtPQUNuQyxXQUFVO2lCQUZaLENBSUUsd0JBQUMsVUFBRCxFQUFVLFdBQVUsVUFBVzs7OztpQkFDL0Isd0JBQUMsUUFBRCxZQUFNLDJCQUE4Qjs7OztlQUM5Qjs7Ozs7Y0FDTDs7Ozs7O0tBR0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNFLHdCQUFDLEtBQUQsRUFBSyxXQUFVLHdCQUF5Qjs7Ozs7UUFDeEMsd0JBQUMsUUFBRDtTQUFNO1NBQXVCLGtCQUFrQixjQUFjO1NBQVE7UUFBUTs7Ozs7UUFDN0Usd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQ2I7UUFDRzs7Ozs7T0FDSDs7Ozs7Z0JBQ0wsd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQXdDO01BQXdCOzs7O2NBQzdFOzs7Ozs7S0FHTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFDYix3QkFBQyxTQUFEO09BQU8sV0FBVTtpQkFBakIsQ0FDRSx3QkFBQyxTQUFELFlBQ0Usd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQWQ7U0FDRSx3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFBWTtTQUF1Qjs7Ozs7U0FDakQsd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQVk7U0FBUTs7Ozs7U0FDbEMsd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQVk7U0FBeUI7Ozs7O1NBQ25ELHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUFZO1NBQTZCOzs7OztTQUN2RCx3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFBWTtTQUFVOzs7OztTQUNwQyx3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFBdUI7U0FBa0I7Ozs7O1FBQ3JEOzs7OztnQkFDQzs7OztpQkFDUCx3QkFBQyxTQUFEO1FBQU8sV0FBVTtrQkFDZCxVQUFVLEtBQUssT0FDZCx3QkFBQyxNQUFEO1NBQWdCLFdBQVU7bUJBQTFCO1VBRUUsd0JBQUMsTUFBRDtXQUFJLFdBQVU7cUJBQWQsQ0FDRSx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZ0MsR0FBRztXQUFpQjs7OztxQkFDbkUsd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQWY7YUFBc0Q7YUFBRSxHQUFHO2FBQVM7YUFBSSxHQUFHO1lBQVc7Ozs7O21CQUNwRjs7Ozs7O1VBR0osd0JBQUMsTUFBRDtXQUFJLFdBQVU7cUJBQ1osd0JBQUMsUUFBRDtZQUFNLFdBQVcsaUVBQ2YsR0FBRyxTQUFTLFVBQ1IsaUVBQ0E7c0JBRUgsR0FBRyxTQUFTLFVBQVUsaUJBQWlCO1dBQ3BDOzs7OztVQUNKOzs7OztVQUdKLHdCQUFDLE1BQUQ7V0FBSSxXQUFVO3FCQUNYLEdBQUcsa0JBQ0Ysd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQWY7YUFDRSx3QkFBQyxPQUFEO2NBQUssV0FBVTt3QkFBZixDQUNFLHdCQUFDLFFBQUQsRUFBUSxXQUFVLDRCQUE2Qjs7Ozt3QkFDL0Msd0JBQUMsUUFBRDtlQUFNLFdBQVU7eUJBQXlCLEdBQUc7Y0FBc0I7Ozs7c0JBQy9EOzs7Ozs7YUFDTCx3QkFBQyxPQUFEO2NBQUssV0FBVTt3QkFBcUQsR0FBRyxxQkFBcUI7YUFBc0I7Ozs7O2FBQ2xILHdCQUFDLFVBQUQ7Y0FDRSxlQUFlLGNBQWMsR0FBRyxJQUFJLEdBQUcsUUFBUTtjQUMvQyxXQUFVO3dCQUZaLENBSUUsd0JBQUMsV0FBRCxFQUFXLFdBQVUsY0FBZTs7Ozt3QkFDcEMsd0JBQUMsUUFBRCxZQUFNLG1CQUFzQjs7OztzQkFDdEI7Ozs7OztZQUNMOzs7OztzQkFFTCx3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBd0c7V0FFbEg7Ozs7O1VBRU47Ozs7O1VBR0osd0JBQUMsTUFBRDtXQUFJLFdBQVU7cUJBQ1gsR0FBRyxzQkFDRix3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZjthQUNFLHdCQUFDLE9BQUQ7Y0FBSyxXQUFVO3dCQUFmLENBQ0Usd0JBQUMsWUFBRCxFQUFZLFdBQVUsOEJBQStCOzs7O3dCQUNyRCx3QkFBQyxRQUFEO2VBQU0sV0FBVTt5QkFBeUIsR0FBRztjQUEwQjs7OztzQkFDbkU7Ozs7OzthQUNMLHdCQUFDLE9BQUQ7Y0FBSyxXQUFVO3dCQUFxRCxHQUFHLHlCQUF5QjthQUFrQjs7Ozs7YUFDbEgsd0JBQUMsVUFBRDtjQUNFLGVBQWUsa0JBQWtCLEdBQUcsSUFBSSxHQUFHLFFBQVE7Y0FDbkQsV0FBVTt3QkFGWixDQUlFLHdCQUFDLFdBQUQsRUFBVyxXQUFVLGNBQWU7Ozs7d0JBQ3BDLHdCQUFDLFFBQUQsWUFBTSx1QkFBMEI7Ozs7c0JBQzFCOzs7Ozs7WUFDTDs7Ozs7c0JBRUwsd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQXdHO1dBRWxIOzs7OztVQUVOOzs7OztVQUdKLHdCQUFDLE1BQUQ7V0FBSSxXQUFVO3FCQUNYLEdBQUcsV0FDRix3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBNkc7V0FFdkg7Ozs7c0JBRU4sd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQWhCLENBQ0Usd0JBQUMsUUFBRCxFQUFNLFdBQVUsMENBQWdEOzs7O3NCQUNoRSx3QkFBQyxRQUFELFlBQU0sU0FBWTs7OztvQkFDZDs7Ozs7O1VBRU47Ozs7O1VBR0osd0JBQUMsTUFBRDtXQUFJLFdBQVU7cUJBQ1osd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQWY7Y0FFSSxHQUFHLG1CQUFtQixHQUFHLHdCQUN6Qix3QkFBQyxVQUFEO2NBQ0UsZUFBZSxzQkFBc0IsR0FBRyxJQUFJLEdBQUcsUUFBUTtjQUN2RCxXQUFVO2NBQ1YsT0FBTTt3QkFDUDthQUVPOzs7OzthQUlULEdBQUcsU0FBUyxXQUNYLHdCQUFDLFVBQUQ7Y0FDRSxlQUFlLGlCQUFpQixHQUFHLElBQUksR0FBRyxRQUFRO2NBQ2xELFdBQVcsbUNBQ1QsR0FBRyxXQUNDLHFGQUNBO2NBRU4sT0FBTyxHQUFHLFdBQVcsb0JBQW9CO3dCQUV4QyxHQUFHLFdBQVcsd0JBQUMsUUFBRCxFQUFRLFdBQVUsY0FBZTs7Ozt5QkFBSSx3QkFBQyxNQUFELEVBQU0sV0FBVSxjQUFlOzs7OzthQUM3RTs7Ozs7YUFJVCxHQUFHLFNBQVMsV0FDWCx3QkFBQyxVQUFEO2NBQ0UsZUFBZSxxQkFBcUIsR0FBRyxJQUFJLEdBQUcsUUFBUTtjQUN0RCxXQUFVO2NBQ1YsT0FBTTt3QkFFTix3QkFBQyxRQUFELEVBQVEsV0FBVSxjQUFlOzs7OzthQUMzQjs7Ozs7WUFFUDs7Ozs7O1VBQ0g7Ozs7O1NBQ0Y7V0F6SEssR0FBRzs7OztlQXlIUixDQUNMO09BQ0k7Ozs7ZUFDRjs7Ozs7O0tBQ0o7Ozs7O0lBQ0Y7Ozs7OztHQUlOLGlCQUFpQixjQUNoQix3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBZDtPQUNFLHdCQUFDLGVBQUQsRUFBZSxXQUFVLHlCQUEwQjs7Ozs7T0FDbkQsd0JBQUMsUUFBRCxZQUFNLGdEQUFtRDs7Ozs7T0FDekQsd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQWtHO09BRTVHOzs7OztNQUNKOzs7OztlQUNKLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUFnQztLQUUxQzs7OzthQUNBOzs7O2VBRUwsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FBOEcsZUFDakcsd0JBQUMsVUFBRDtPQUFRLFdBQVU7aUJBQWxCO1FBQXNDO1FBQXVCO1FBQUksc0JBQXNCO1FBQU87T0FBa0I7Ozs7O2NBQ3hIOzs7OzthQUNGOzs7OztjQUdMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ1osc0JBQXNCLEtBQUssU0FBUztNQUNuQyxNQUFNLFNBQVMsQ0FBQyxDQUFDLGVBQWUsS0FBSztNQUNyQyxPQUNFLHdCQUFDLE9BQUQ7T0FFRSxXQUFXLGtEQUNULFNBQ0ksMENBQ0E7aUJBTFI7UUFRRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsUUFBRDtXQUFNLFdBQVcsbUZBQ2YsU0FBUyxrQ0FBa0M7cUJBRTFDLEtBQUs7VUFDRjs7OztvQkFDTix3QkFBQyxNQUFEO1dBQUksV0FBVTtxQkFBcUMsS0FBSztVQUFVOzs7O2tCQUMvRDs7Ozs7bUJBRUwsd0JBQUMsVUFBRDtVQUNFLGVBQWUsbUJBQWtCLFVBQVM7V0FBRSxHQUFHO1lBQU8sS0FBSyxhQUFhLENBQUMsS0FBSyxLQUFLO1VBQVksRUFBRTtVQUNqRyxXQUFXLCtFQUNULFNBQ0ksNkRBQ0E7b0JBTFIsQ0FRRyxTQUFTLHdCQUFDLGNBQUQsRUFBYyxXQUFVLCtCQUFnQzs7OztxQkFBSSx3QkFBQyxRQUFELEVBQVEsV0FBVSxjQUFlOzs7O29CQUN2Ryx3QkFBQyxRQUFELFlBQU8sU0FBUyxTQUFTLE9BQWE7Ozs7a0JBQ2hDOzs7OztpQkFDTDs7Ozs7O1FBRUwsd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQTJDLEtBQUs7UUFBZTs7Ozs7UUFFNUUsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQ1osS0FBSyxVQUFVLEtBQUssTUFBTSxRQUN6Qix3QkFBQyxPQUFEO1VBQWUsV0FBVTtvQkFBekIsQ0FDRSx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBZ0I7VUFBTzs7OztvQkFDdkMsd0JBQUMsUUFBRCxZQUFPLEtBQVc7Ozs7a0JBQ2Y7WUFISzs7OztnQkFHTCxDQUNOO1FBQ0U7Ozs7O1FBRUwsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxVQUFELEVBQVUsV0FBVSw4Q0FBK0M7Ozs7bUJBQ25FLHdCQUFDLFFBQUQ7VUFBTSx3QkFBQyxLQUFELFlBQUcsaUJBQWlCOzs7OztVQUFDO1VBQUUsS0FBSztTQUFXOzs7O2lCQUMxQzs7Ozs7O09BQ0Y7U0E3Q0UsS0FBSzs7OzthQTZDUDtLQUVULENBQUM7SUFDRTs7OztZQUNGOzs7Ozs7R0FJTixpQkFBaUIsa0JBQ2hCLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNiLHdCQUFDLFNBQUQsRUFBUyxXQUFVLFVBQVc7Ozs7O01BQzNCOzs7O2dCQUNMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQW9DO09BQW9EOzs7O2lCQUN0Ryx3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBeUM7T0FFbkQ7Ozs7ZUFDQTs7Ozs7Y0FDRjs7Ozs7O0tBRUwsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBcUM7TUFBK0I7Ozs7Z0JBQ3BGLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsT0FBRCxZQUFLLGtDQUFvQzs7Ozs7UUFDekMsd0JBQUMsT0FBRCxZQUFLLDhCQUFnQzs7Ozs7UUFDckMsd0JBQUMsT0FBRCxZQUFLLHFDQUF1Qzs7Ozs7UUFDNUMsd0JBQUMsT0FBRCxZQUFLLDBCQUE0Qjs7Ozs7UUFDakMsd0JBQUMsT0FBRCxZQUFLLDhCQUFnQzs7Ozs7UUFDckMsd0JBQUMsT0FBRCxZQUFLLGlDQUFtQzs7Ozs7UUFDeEMsd0JBQUMsT0FBRCxZQUFLLHNDQUF3Qzs7Ozs7UUFDN0Msd0JBQUMsT0FBRCxZQUFLLHFDQUF1Qzs7Ozs7UUFDNUMsd0JBQUMsT0FBRCxZQUFLLGtDQUFvQzs7Ozs7T0FDdEM7Ozs7O2NBQ0Y7Ozs7OztLQUdKLGtCQUNDLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxRQUFELGFBQU0seUJBQXNCLFlBQVksSUFBVzs7OztpQkFDbkQsd0JBQUMsUUFBRCxhQUFPLFlBQVksU0FBUSxHQUFPOzs7O2VBQy9COzs7OztnQkFDTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDYix3QkFBQyxPQUFEO1FBQ0UsV0FBVTtRQUNWLE9BQU8sRUFBRSxPQUFPLEdBQUcsWUFBWSxRQUFRLEdBQUc7T0FDM0M7Ozs7O01BQ0U7Ozs7Y0FDRjs7Ozs7O0tBR1Asd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxVQUFEO09BQ0UsU0FBUztPQUNULFVBQVU7T0FDVixXQUFVO2lCQUhaLENBS0Usd0JBQUMsVUFBRCxFQUFVLFdBQVUsVUFBVzs7OztpQkFDL0Isd0JBQUMsUUFBRCxZQUFPLGlCQUFpQiwyQkFBMkIsZ0NBQXNDOzs7O2VBQ25GOzs7OztnQkFFUix3QkFBQyxLQUFEO09BQ0UsTUFBSztPQUNMLFVBQVM7T0FDVCxXQUFVO2lCQUVWLHdCQUFDLFFBQUQsWUFBTSw4QkFBaUM7Ozs7O01BQ3RDOzs7O2NBQ0E7Ozs7OztJQUNGOzs7Ozs7R0FJTixpQkFBaUIsVUFDaEIsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQXNDO0tBQXlDOzs7O2VBQzdGLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUF5QjtLQUF5Rjs7OzthQUM1SDs7OztlQUNMLHdCQUFDLFVBQUQ7TUFDRSxTQUFTO01BQ1QsV0FBVTtnQkFGWixDQUlFLHdCQUFDLFdBQUQsRUFBVyxXQUFVLGNBQWU7Ozs7Z0JBQ3BDLHdCQUFDLFFBQUQsWUFBTSxlQUFrQjs7OztjQUNsQjs7Ozs7YUFDTDs7Ozs7Y0FFTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNiLHdCQUFDLFNBQUQ7TUFBTyxXQUFVO2dCQUFqQixDQUNFLHdCQUFDLFNBQUQ7T0FBTyxXQUFVO2lCQUNmLHdCQUFDLE1BQUQ7UUFDRSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBYztRQUFhOzs7OztRQUN6Qyx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBYztRQUFVOzs7OztRQUN0Qyx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBYztRQUFZOzs7OztRQUN4Qyx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBYztRQUFROzs7OztRQUNwQyx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBYztRQUFhOzs7OztRQUN6Qyx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBYztRQUFXOzs7OztPQUNyQzs7Ozs7TUFDQzs7OztnQkFDUCx3QkFBQyxTQUFEO09BQU8sV0FBVTtpQkFDZCxVQUFVLFNBQVMsSUFDbEIsVUFBVSxLQUFLLFFBQ2Isd0JBQUMsTUFBRDtRQUFpQixXQUFVO2tCQUEzQjtTQUNFLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUE4QixJQUFJO1NBQWM7Ozs7O1NBQzlELHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUNaLHdCQUFDLFFBQUQ7V0FBTSxXQUFXLDZDQUNmLElBQUksV0FBVyxrQkFDWCx1Q0FDQSxJQUFJLFdBQVcsbUJBQ2YsaUNBQ0EsSUFBSSxXQUFXLGlCQUNmLGlDQUNBO3FCQUVILElBQUk7VUFDRDs7Ozs7U0FDSjs7Ozs7U0FDSix3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFBZCxDQUFpRCxLQUFFLElBQUksUUFBYTs7Ozs7O1NBQ3BFLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUE4QixJQUFJLGVBQWUsV0FBVyxjQUFjO1NBQVk7Ozs7O1NBQ3BHLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUE4QixJQUFJO1NBQWE7Ozs7O1NBQzdELHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUEwRCxJQUFJO1NBQVk7Ozs7O1FBQ3RGO1VBbkJLLElBQUk7Ozs7Y0FtQlQsQ0FDTCxJQUVELHdCQUFDLE1BQUQsWUFDRSx3QkFBQyxNQUFEO1FBQUksU0FBUztRQUFHLFdBQVU7a0JBQWtDO09BRXhEOzs7O2dCQUNGOzs7OztNQUVEOzs7O2NBQ0Y7Ozs7OztJQUNKOzs7O1lBQ0Y7Ozs7OztHQUlOLGlCQUFpQixjQUNoQix3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsTUFBRDtLQUFJLFdBQVU7ZUFBc0M7SUFBa0M7Ozs7Y0FDdEYsd0JBQUMsUUFBRDtLQUFNLFVBQVU7S0FBb0IsV0FBVTtlQUE5QyxDQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7UUFBTyxXQUFVO2tCQUE0QjtPQUF5Qjs7OztpQkFDdEUsd0JBQUMsU0FBRDtRQUNFLE1BQUs7UUFDTCxPQUFPLFNBQVM7UUFDaEIsV0FBVyxNQUFNLFlBQVk7U0FBRSxHQUFHO1NBQVUsVUFBVSxFQUFFLE9BQU87UUFBTSxDQUFDO1FBQ3RFLFdBQVU7T0FDWDs7OztlQUNFOzs7OztPQUVMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1FBQU8sV0FBVTtrQkFBNEI7T0FBaUI7Ozs7aUJBQzlELHdCQUFDLFNBQUQ7UUFDRSxNQUFLO1FBQ0wsT0FBTyxTQUFTO1FBQ2hCLFdBQVcsTUFBTSxZQUFZO1NBQUUsR0FBRztTQUFVLFdBQVcsRUFBRSxPQUFPO1FBQU0sQ0FBQztRQUN2RSxXQUFVO09BQ1g7Ozs7ZUFDRTs7Ozs7T0FFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQTRCO09BQStCOzs7O2lCQUM1RSx3QkFBQyxTQUFEO1FBQ0UsTUFBSztRQUNMLE9BQU8sU0FBUztRQUNoQixXQUFXLE1BQU0sWUFBWTtTQUFFLEdBQUc7U0FBVSxPQUFPLEVBQUUsT0FBTztRQUFNLENBQUM7UUFDbkUsV0FBVTtPQUNYOzs7O2VBQ0U7Ozs7O09BRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7UUFBTyxXQUFVO2tCQUE0QjtPQUE2Qjs7OztpQkFDMUUsd0JBQUMsU0FBRDtRQUNFLE1BQUs7UUFDTCxPQUFPLFNBQVM7UUFDaEIsV0FBVyxNQUFNLFlBQVk7U0FBRSxHQUFHO1NBQVUsT0FBTyxFQUFFLE9BQU87UUFBTSxDQUFDO1FBQ25FLFdBQVU7T0FDWDs7OztlQUNFOzs7OztPQUVMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsU0FBRDtTQUFPLFdBQVU7bUJBQTRCO1FBQStDOzs7O2tCQUM1Rix3QkFBQyxTQUFEO1NBQ0UsTUFBSztTQUNMLE9BQU8sU0FBUztTQUNoQixXQUFXLE1BQU0sWUFBWTtVQUFFLEdBQUc7VUFBVSxTQUFTLEVBQUUsT0FBTztTQUFNLENBQUM7U0FDckUsV0FBVTtRQUNYOzs7O2dCQUNFOzs7Ozs7TUFDRjs7Ozs7ZUFFTCx3QkFBQyxVQUFEO01BQ0UsTUFBSztNQUNMLFdBQVU7Z0JBQ1g7S0FFTzs7OzthQUNKOzs7OztZQUNIOzs7Ozs7R0FJTixnQkFDQyx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNiLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUFkLENBQ0Usd0JBQUMsVUFBRCxFQUFVLFdBQVUsd0JBQXlCOzs7O2tCQUM3Qyx3QkFBQyxRQUFELFlBQU0sMkJBQThCOzs7O2dCQUNsQzs7Ozs7aUJBQ0osd0JBQUMsVUFBRDtRQUFRLGVBQWUsZ0JBQWdCLEtBQUs7UUFBRyxXQUFVO2tCQUFrQztPQUFTOzs7O2VBQ2pHOzs7Ozs7TUFFTCx3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBYjtRQUFzQztRQUNGLHdCQUFDLEtBQUQsWUFBRyxrQkFBa0I7Ozs7O1FBQUM7UUFBRyx3QkFBQyxLQUFELFlBQUcsc0JBQXNCOzs7OztRQUFDO09BQ3BGOzs7Ozs7TUFFRixZQUNDLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNaO01BQ0U7Ozs7O01BR1Asd0JBQUMsUUFBRDtPQUFNLFVBQVU7T0FBc0IsV0FBVTtpQkFBaEQ7UUFDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtTQUFPLFdBQVU7bUJBQTRCO1FBQXlCOzs7O2tCQUN0RSx3QkFBQyxTQUFEO1NBQ0UsTUFBSztTQUNMO1NBQ0EsYUFBWTtTQUNaLE9BQU87U0FDUCxXQUFXLE1BQU0sa0JBQWtCLEVBQUUsT0FBTyxLQUFLO1NBQ2pELFdBQVU7UUFDWDs7OztnQkFDRTs7Ozs7UUFFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtTQUFPLFdBQVU7bUJBQTRCO1FBQTBCOzs7O2tCQUN2RSx3QkFBQyxTQUFEO1NBQ0UsTUFBSztTQUNMO1NBQ0EsYUFBWTtTQUNaLE9BQU87U0FDUCxXQUFXLE1BQU0sZUFBZSxFQUFFLE9BQU8sS0FBSztTQUM5QyxXQUFVO1FBQ1g7Ozs7Z0JBQ0U7Ozs7O1FBRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7U0FBTyxXQUFVO21CQUE0QjtRQUFlOzs7O2tCQUM1RCx3QkFBQyxTQUFEO1NBQ0UsTUFBSztTQUNMO1NBQ0EsYUFBWTtTQUNaLE9BQU87U0FDUCxXQUFXLE1BQU0sZUFBZSxFQUFFLE9BQU8sS0FBSztTQUM5QyxXQUFVO1FBQ1g7Ozs7Z0JBQ0U7Ozs7O1FBRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7U0FBTyxXQUFVO21CQUE0QjtRQUFtQjs7OztrQkFDaEUsd0JBQUMsU0FBRDtTQUNFLE1BQUs7U0FDTCxhQUFZO1NBQ1osT0FBTztTQUNQLFdBQVcsTUFBTSxZQUFZLEVBQUUsT0FBTyxLQUFLO1NBQzNDLFdBQVU7UUFDWDs7OztnQkFDRTs7Ozs7UUFFTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLFVBQUQ7VUFDRSxNQUFLO1VBQ0wsZUFBZSxnQkFBZ0IsS0FBSztVQUNwQyxXQUFVO29CQUNYO1NBRU87Ozs7bUJBQ1Isd0JBQUMsVUFBRDtVQUNFLE1BQUs7VUFDTCxXQUFVO29CQUNYO1NBRU87Ozs7aUJBQ0w7Ozs7OztPQUNEOzs7Ozs7S0FDSDs7Ozs7O0dBQ0Y7Ozs7O0VBRUo7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIk1hc3RlckFkbWluVmlldy50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBcbiAgU2hpZWxkQ2hlY2ssIFxuICBMb2NrLCBcbiAgVW5sb2NrLCBcbiAgU21hcnRwaG9uZSwgXG4gIExhcHRvcCwgXG4gIFJvdGF0ZUNjdywgXG4gIFVzZXJQbHVzLCBcbiAgVHJhc2gyLCBcbiAgRG93bmxvYWQsIFxuICBDaGVja0NpcmNsZTIsIFxuICBBbGVydENpcmNsZSwgXG4gIENsb2NrLCBcbiAgS2V5LCBcbiAgRmlsZUNvZGUsIFxuICBMYXllcnMsIFxuICBDaGVjaywgXG4gIEFyY2hpdmUsXG4gIFJlZnJlc2hDdyxcbiAgQ3B1LFxuICBNb25pdG9yLFxuICBDbGlwYm9hcmRMaXN0LFxuICBTcGFya2xlcyxcbiAgQ2lyY2xlLFxuICBIZWxwQ2lyY2xlXG59IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5pbXBvcnQgeyBPcGVyYXRvckFjY291bnQsIFNob3BTZXR0aW5ncyB9IGZyb20gJy4uL3R5cGVzJztcbmltcG9ydCB7IFxuICBnZXRSZWdpc3RlcmVkT3BlcmF0b3JzLCBcbiAgcmVzZXRPcGVyYXRvclBjQmluZGluZyxcbiAgcmVzZXRPcGVyYXRvck1vYmlsZUJpbmRpbmcsXG4gIHJlc2V0T3BlcmF0b3JBbGxCaW5kaW5ncyxcbiAgdG9nZ2xlT3BlcmF0b3JMb2NrLCBcbiAgYWRkTmV3T3BlcmF0b3IsIFxuICBkZWxldGVPcGVyYXRvcixcbiAgZ2V0U2VjdXJpdHlBdWRpdExvZ3MsXG4gIFNlY3VyaXR5QXVkaXRMb2csXG4gIGdldEhhcmR3YXJlRGV2aWNlSWQsXG4gIGdldEhhcmR3YXJlRGV2aWNlTmFtZSxcbiAgaXNNb2JpbGVEZXZpY2Vcbn0gZnJvbSAnLi4vdXRpbHMvZGV2aWNlU2VjdXJpdHknO1xuaW1wb3J0IHsgZ2VuZXJhdGVQcm9qZWN0WmlwLCB0cmlnZ2VyRG93bmxvYWRaaXAgfSBmcm9tICcuLi91dGlscy9wcm9qZWN0WmlwJztcblxuaW50ZXJmYWNlIE1hc3RlckFkbWluVmlld1Byb3BzIHtcbiAgc2V0dGluZ3M6IFNob3BTZXR0aW5ncztcbiAgb25VcGRhdGVTZXR0aW5nczogKHNldHRpbmdzOiBTaG9wU2V0dGluZ3MpID0+IHZvaWQ7XG4gIG9uTmF2aWdhdGVUb1dvcmtmbG93PzogKCkgPT4gdm9pZDtcbn1cblxuaW50ZXJmYWNlIFdvcmtmbG93U3RlcCB7XG4gIHN0ZXBOdW1iZXI6IG51bWJlcjtcbiAgdGl0bGU6IHN0cmluZztcbiAgZGVzY3JpcHRpb246IHN0cmluZztcbiAgdG9vbHNVc2VkOiBzdHJpbmdbXTtcbiAgY2hlY2tsaXN0OiBzdHJpbmdbXTtcbiAgdGlwczogc3RyaW5nO1xufVxuXG5jb25zdCBNQVNURVJfV09SS0ZMT1dfU1RFUFM6IFdvcmtmbG93U3RlcFtdID0gW1xuICB7XG4gICAgc3RlcE51bWJlcjogMSxcbiAgICB0aXRsZTogJ0N1c3RvbWVyIEludGFrZSAmIFNlcnZpY2UgSWRlbnRpZmljYXRpb24nLFxuICAgIGRlc2NyaXB0aW9uOiAnV2VsY29tZSBjaXRpemVuLCB2ZXJpZnkgQWFkaGFhciBsaW5rZWQgbW9iaWxlLCBjaGVjayBkb2N1bWVudCBwcmVyZXF1aXNpdGVzLCBhbmQgcXVvdGUgdHJhbnNwYXJlbnQgcmF0ZXMuJyxcbiAgICB0b29sc1VzZWQ6IFsnRGFzaGJvYXJkJywgJzUwKyBHb3Z0IFBvcnRhbHMgSHViJywgJ0FJIEFzc2lzdGFudCddLFxuICAgIGNoZWNrbGlzdDogW1xuICAgICAgJ0NoZWNrIGN1c3RvbWVyIEFhZGhhYXIgJiBhY3RpdmUgbW9iaWxlIE9UUCBhdmFpbGFiaWxpdHknLFxuICAgICAgJ0luZm9ybSBjdXN0b21lciBvZiBvZmZpY2lhbCBwb3J0YWwgY2hhcmdlcyArIHNlcnZpY2UgZmVlJyxcbiAgICAgICdSZWNvcmQgY3VzdG9tZXIgbmFtZSAmIFdoYXRzQXBwIG51bWJlciBpbiBDUk0nLFxuICAgICAgJ0lzc3VlIHBoeXNpY2FsIG9yIGRpZ2l0YWwgcXVldWUgdG9rZW4nXG4gICAgXSxcbiAgICB0aXBzOiAnQWFkaGFhciBtZWluIGFjdGl2ZSBtb2JpbGUgbnVtYmVyIGhvbmEgUE0tS0lTQU4sIExhZGtpIEJhaGluLCBhdXIgTWFoYWRidCBzY2hlbWVzIGtlIGxpeWUgYW5pdmFyeWEgaGFpLidcbiAgfSxcbiAge1xuICAgIHN0ZXBOdW1iZXI6IDIsXG4gICAgdGl0bGU6ICdPZmZpY2lhbCBQb3J0YWwgRmlsaW5nICYgRG9jdW1lbnQgU3VibWlzc2lvbicsXG4gICAgZGVzY3JpcHRpb246ICdMb2cgaW50byBjZW50cmFsL3N0YXRlIHBvcnRhbCAoQWFwbGUgU2Fya2FyLCBTYXJhdGhpLCBNYWhhZGJ0KSwgY29tcGxldGUgZm9ybSBlbnRyeSwgYW5kIHN1Ym1pdC4nLFxuICAgIHRvb2xzVXNlZDogWyc1MCsgR292dCBQb3J0YWxzIERpcmVjdG9yeScsICdQREYgdG8gSEQgSlBHIENvbnZlcnRlciddLFxuICAgIGNoZWNrbGlzdDogW1xuICAgICAgJ0VudGVyIGFwcGxpY2FudCBkZXRhaWxzIG1hdGNoaW5nIEFhZGhhYXIgbGV0dGVyIGJ5IGxldHRlcicsXG4gICAgICAnSWYgcG9ydGFsIHJlcXVpcmVzIEpQRyB1bmRlciAxMDBLQiwgdXNlIFBERiB0byBKUEcgdG9vbCB0byBjb21wcmVzcyBkb2N1bWVudHMnLFxuICAgICAgJ1ZlcmlmeSB1cGxvYWRlZCBjZXJ0aWZpY2F0ZSBwcmV2aWV3cyBiZWZvcmUgZmluYWwgc3VibWlzc2lvbicsXG4gICAgICAnRG93bmxvYWQgYW5kIHNhdmUgb2ZmaWNpYWwgYWNrbm93bGVkZ2VtZW50IFBERidcbiAgICBdLFxuICAgIHRpcHM6ICdBY2tub3dsZWRnZW1lbnQgUmVjZWlwdCBUb2tlbiBOdW1iZXIgaGFtZXNoYSBkb3dubG9hZCBrYXJrZSBDdXN0b21lciBDUk0gbWVpbiBub3RlIGthcmVpbi4nXG4gIH0sXG4gIHtcbiAgICBzdGVwTnVtYmVyOiAzLFxuICAgIHRpdGxlOiAnU3R1ZGlvIFBob3RvICYgUFZDIFNtYXJ0IENhcmQgUHJvY2Vzc2luZycsXG4gICAgZGVzY3JpcHRpb246ICdQcm9kdWNlIGhpZ2gtcHJlY2lzaW9uIENSLTgwIFBWQyBjYXJkcyBvciAzNXg0NW1tIHBhc3Nwb3J0IHBob3RvIHNoZWV0cy4nLFxuICAgIHRvb2xzVXNlZDogWydQVkMgU21hcnQgQ2FyZCBNYWtlcicsICdQYXNzcG9ydCBQaG90byBTdHVkaW8gUHJvJ10sXG4gICAgY2hlY2tsaXN0OiBbXG4gICAgICAnUGFzc3BvcnQgUGhvdG86IFNlbGVjdCA0w5c2IExhbmRzY2FwZSAoOCBDb3BpZXMgQCAzMDAgRFBJKSBvciBBNCBMYW5kc2NhcGUnLFxuICAgICAgJ0JhY2tncm91bmQ6IFVzZSBDb25uZWN0ZWQgTWFnaWMgV2FuZCBvciBQZW4gVG9vbCB0byBjdXQgb3V0IHBlcnNvbiBhbmQgc2V0IFdoaXRlL1N0dWRpbyBCbHVlIEJHJyxcbiAgICAgICdBdXRvIEJlYXV0eTogQXBwbHkgQUkgRmFjZSBTbW9vdGhpbmcgdG8gYnJpZ2h0ZW4gc2tpbiB0b25lcyBhbmQgcmVkdWNlIGNhbWVyYSBzaGFkb3dzJyxcbiAgICAgICdFeGFtIFN0cmlwOiBBZGQgQ2FuZGlkYXRlIE5hbWUgJiBEYXRlIHN0YW1wIGZvciBTU0MgR0QsIFBvbGljZSBCaGFydGksIG9yIFJhaWx3YXkgZm9ybXMnLFxuICAgICAgJ1BWQyBDYXJkOiBBbGlnbiBGcm9udCAmIEJhY2sgY2FyZHMgdG8gc3RhbmRhcmQgQ1ItODAgKDg1LjbDlzU0bW0pIHdpdGggY2VudGVyIGN1dCBndWlkZSBsaW5lJ1xuICAgIF0sXG4gICAgdGlwczogJ1BWQyBDYXJkIHByaW50IGthcnRlIHdhcXQgcHJpbnRlciBwcm9wZXJ0aWVzIG1laW4gXCJIaWdoIFF1YWxpdHkgR2xvc3N5IFBob3RvIFBhcGVyXCIgc2VsZWN0IGthcmVpbi4nXG4gIH0sXG4gIHtcbiAgICBzdGVwTnVtYmVyOiA0LFxuICAgIHRpdGxlOiAnMzAwIERQSSBQaHlzaWNhbCBQcmludGluZyAmIFRoZXJtYWwgTGFtaW5hdGlvbicsXG4gICAgZGVzY3JpcHRpb246ICdFeGVjdXRlIGluLWFwcCBib3JkZXJsZXNzIHByaW50aW5nIG9uIHBob3RvIHBhcGVyLCBjdXQgY2FyZHMsIGFuZCBsYW1pbmF0ZS4nLFxuICAgIHRvb2xzVXNlZDogWydJbi1BcHAgRGlyZWN0IFByaW50IEVuZ2luZSAoQ3RybCArIFApJ10sXG4gICAgY2hlY2tsaXN0OiBbXG4gICAgICAnTG9hZCA0w5c2IGluY2ggKDEww5cxNSBjbSkgR2xvc3N5IFBob3RvIFBhcGVyIGludG8gcHJpbnRlcicsXG4gICAgICAnUHJlc3MgXCLwn5ao77iPIERpcmVjdCBQcmludCBTaGVldCAoQ3RybCArIFApXCIgZGlyZWN0bHkgaW5zaWRlIHN0dWRpbycsXG4gICAgICAnQ3V0IGFsb25nIHByZS1hbGlnbmVkIGd1aWRlIG1hcmtzJyxcbiAgICAgICdGb3IgUFZDIFNtYXJ0IENhcmRzOiBQYXNzIHRocm91Z2ggdGhlcm1hbCBsYW1pbmF0b3IgZm9yIGR1cmFibGUgd2F0ZXJwcm9vZiBmaW5pc2gnXG4gICAgXSxcbiAgICB0aXBzOiAnSW4tYXBwIGRpcmVjdCBwcmludCB6ZXJvIHBvcHVwIGJsb2NrZXIga2Ugc2FhdGggc2VlZGhhIGNvbm5lY3RlZCBwcmludGVyIHBhciAzMDAgRFBJIGpvYiBiaGVqdGEgaGFpLidcbiAgfSxcbiAge1xuICAgIHN0ZXBOdW1iZXI6IDUsXG4gICAgdGl0bGU6ICdQT1MgQmlsbGluZyAmIFRoZXJtYWwgUmVjZWlwdCBHZW5lcmF0aW9uJyxcbiAgICBkZXNjcmlwdGlvbjogJ0dlbmVyYXRlIGl0ZW1pemVkIHRheCBpbnZvaWNlIG9yIDU4bW0vODBtbSB0aGVybWFsIHNsaXAgd2l0aCBkeW5hbWljIFVQSSBRUiBjb2RlLicsXG4gICAgdG9vbHNVc2VkOiBbJ0Zhc3QgQmlsbGluZyBEZXNrIFBPUyddLFxuICAgIGNoZWNrbGlzdDogW1xuICAgICAgJ1NlbGVjdCBzZXJ2aWNlIHBhY2thZ2UgKGUuZy4gUFZDIENhcmQg4oK5NzAsIFBhc3Nwb3J0IFBob3RvIDgtY29waWVzIOKCuTUwLCBPbmxpbmUgRm9ybSDigrkxMDApJyxcbiAgICAgICdEaXNwbGF5IGR5bmFtaWMgVVBJIFFSIGNvZGUgb24gc2NyZWVuIGZvciBpbnN0YW50IGN1c3RvbWVyIHBheW1lbnQnLFxuICAgICAgJ1ByaW50IDU4bW0gdGhlcm1hbCByZWNlaXB0IG9yIEE0IG9mZmljaWFsIHRheCBpbnZvaWNlIGZvciBjdXN0b21lciByZWNvcmRzJyxcbiAgICAgICdVcGRhdGUgcGF5bWVudCBzdGF0dXMgYXMgXCJQYWlkXCIgaW4gbGVkZ2VyJ1xuICAgIF0sXG4gICAgdGlwczogJ1RoZXJtYWwgcmVjZWlwdCBwYXIgc2hvcCBrYSBhdXRob3JpemVkIHNpZ25hdHVyZSBhdXIgbm9uLXJlZnVuZGFibGUgcG9ydGFsIHRlcm1zIGF1dG9tYXRpYyBhYXRlIGhhaW4uJ1xuICB9LFxuICB7XG4gICAgc3RlcE51bWJlcjogNixcbiAgICB0aXRsZTogJ0N1c3RvbWVyIEhhbmRvdmVyICYgRGFpbHkgQ2FzaCBSZWNvbmNpbGlhdGlvbicsXG4gICAgZGVzY3JpcHRpb246ICdIYW5kIG92ZXIgbGFtaW5hdGVkIGNhcmRzLCBwYXNzcG9ydCBwaG90b3MgaW4gc2xlZXZlLCBhbmQgcG9ydGFsIGFja25vd2xlZGdlbWVudC4nLFxuICAgIHRvb2xzVXNlZDogWydDdXN0b21lciBDUk0gJiBKb2IgVHJhY2tlciddLFxuICAgIGNoZWNrbGlzdDogW1xuICAgICAgJ0hhbmQgb3ZlciBsYW1pbmF0ZWQgY2FyZHMsIHBhc3Nwb3J0IHBob3RvcyBpbiBzbGVldmUsIGFuZCBwb3J0YWwgYWNrbm93bGVkZ2VtZW50JyxcbiAgICAgICdTZW5kIFdoYXRzQXBwIGNvbmZpcm1hdGlvbiB3aXRoIHN0YXR1cyB1cGRhdGUnLFxuICAgICAgJ01hcmsgam9iIGFzIFwiRGVsaXZlcmVkXCIgaW4gQ1JNIFRyYWNrZXInLFxuICAgICAgJ0RhaWx5IHJlY29uY2lsaWF0aW9uOiBDaGVjayB0b3RhbCBjYXNoICsgVVBJIGNvbGxlY3Rpb25zIGluIEJpbGxpbmcgRGVzayBTdW1tYXJ5J1xuICAgIF0sXG4gICAgdGlwczogJ0RpbiBrZSBlbmQgcGFyIERhaWx5IExlZGdlciBTdW1tYXJ5IHNlIGNhc2ggY291bnRlciBiYWxhbmNlIG1hdGNoIGthcmVpbi4nXG4gIH1cbl07XG5cbmV4cG9ydCBjb25zdCBNYXN0ZXJBZG1pblZpZXc6IFJlYWN0LkZDPE1hc3RlckFkbWluVmlld1Byb3BzPiA9ICh7XG4gIHNldHRpbmdzLFxuICBvblVwZGF0ZVNldHRpbmdzLFxuICBvbk5hdmlnYXRlVG9Xb3JrZmxvd1xufSkgPT4ge1xuICBjb25zdCBbb3BlcmF0b3JzLCBzZXRPcGVyYXRvcnNdID0gdXNlU3RhdGU8T3BlcmF0b3JBY2NvdW50W10+KFtdKTtcbiAgY29uc3QgW2F1ZGl0TG9ncywgc2V0QXVkaXRMb2dzXSA9IHVzZVN0YXRlPFNlY3VyaXR5QXVkaXRMb2dbXT4oW10pO1xuICBjb25zdCBbYWN0aXZlU3ViVGFiLCBzZXRBY3RpdmVTdWJUYWJdID0gdXNlU3RhdGU8J29wZXJhdG9ycycgfCAnd29ya2Zsb3cnIHwgJ3ppcF9kb3dubG9hZCcgfCAnbG9ncycgfCAnc2V0dGluZ3MnPignb3BlcmF0b3JzJyk7XG5cbiAgLy8gTmV3IE9wZXJhdG9yIE1vZGFsIFN0YXRlXG4gIGNvbnN0IFtzaG93QWRkTW9kYWwsIHNldFNob3dBZGRNb2RhbF0gPSB1c2VTdGF0ZTxib29sZWFuPihmYWxzZSk7XG4gIGNvbnN0IFtuZXdVc2VybmFtZSwgc2V0TmV3VXNlcm5hbWVdID0gdXNlU3RhdGU8c3RyaW5nPignJyk7XG4gIGNvbnN0IFtuZXdQYXNzd29yZCwgc2V0TmV3UGFzc3dvcmRdID0gdXNlU3RhdGU8c3RyaW5nPignJyk7XG4gIGNvbnN0IFtuZXdEaXNwbGF5TmFtZSwgc2V0TmV3RGlzcGxheU5hbWVdID0gdXNlU3RhdGU8c3RyaW5nPignJyk7XG4gIGNvbnN0IFtuZXdQaG9uZSwgc2V0TmV3UGhvbmVdID0gdXNlU3RhdGU8c3RyaW5nPignJyk7XG4gIGNvbnN0IFthZGRFcnJvciwgc2V0QWRkRXJyb3JdID0gdXNlU3RhdGU8c3RyaW5nPignJyk7XG5cbiAgLy8gUHJvamVjdCBaSVAgRXhwb3J0IFN0YXRlXG4gIGNvbnN0IFtpc0V4cG9ydGluZ1ppcCwgc2V0SXNFeHBvcnRpbmdaaXBdID0gdXNlU3RhdGU8Ym9vbGVhbj4oZmFsc2UpO1xuICBjb25zdCBbemlwUHJvZ3Jlc3MsIHNldFppcFByb2dyZXNzXSA9IHVzZVN0YXRlPHsgcGVyY2VudDogbnVtYmVyOyBmaWxlOiBzdHJpbmcgfT4oeyBwZXJjZW50OiAwLCBmaWxlOiAnJyB9KTtcblxuICAvLyBOb3RpZmljYXRpb25zXG4gIGNvbnN0IFthbGVydE1lc3NhZ2UsIHNldEFsZXJ0TWVzc2FnZV0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcblxuICAvLyBTaG9wIFNldHRpbmdzIEZvcm1cbiAgY29uc3QgW3Nob3BGb3JtLCBzZXRTaG9wRm9ybV0gPSB1c2VTdGF0ZTxTaG9wU2V0dGluZ3M+KHNldHRpbmdzKTtcblxuICAvLyBXb3JrZmxvdyBDaGVja2xpc3Qgc3RhdGUgaW5zaWRlIE1hc3RlciBBZG1pblxuICBjb25zdCBbY29tcGxldGVkU3RlcHMsIHNldENvbXBsZXRlZFN0ZXBzXSA9IHVzZVN0YXRlPFJlY29yZDxudW1iZXIsIGJvb2xlYW4+Pih7fSk7XG5cbiAgY29uc3QgY3VycmVudERldmljZUlkID0gZ2V0SGFyZHdhcmVEZXZpY2VJZCgpO1xuICBjb25zdCBjdXJyZW50RGV2aWNlTmFtZSA9IGdldEhhcmR3YXJlRGV2aWNlTmFtZSgpO1xuICBjb25zdCBjdXJyZW50SXNNb2JpbGUgPSBpc01vYmlsZURldmljZSgpO1xuXG4gIGNvbnN0IGxvYWREYXRhID0gKCkgPT4ge1xuICAgIHNldE9wZXJhdG9ycyhnZXRSZWdpc3RlcmVkT3BlcmF0b3JzKCkpO1xuICAgIHNldEF1ZGl0TG9ncyhnZXRTZWN1cml0eUF1ZGl0TG9ncygpKTtcbiAgfTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGxvYWREYXRhKCk7XG4gIH0sIFtdKTtcblxuICAvLyBIYW5kbGUgUmVzZXQgUEMgQmluZGluZ1xuICBjb25zdCBoYW5kbGVSZXNldFBjID0gKG9wZXJhdG9ySWQ6IHN0cmluZywgdXNlcm5hbWU6IHN0cmluZykgPT4ge1xuICAgIGlmICh3aW5kb3cuY29uZmlybShgUmVzZXQgUEMgRGV2aWNlIEJpbmRpbmcgZm9yIFwiJHt1c2VybmFtZX1cIj8gT3BlcmF0b3IgY2FuIG5vdyBsb2cgaW4gb24gYSBuZXcgUEMvTGFwdG9wLmApKSB7XG4gICAgICByZXNldE9wZXJhdG9yUGNCaW5kaW5nKG9wZXJhdG9ySWQpO1xuICAgICAgbG9hZERhdGEoKTtcbiAgICAgIHNldEFsZXJ0TWVzc2FnZShg4pyFIFBDIGRldmljZSBiaW5kaW5nIGNsZWFyZWQgZm9yICR7dXNlcm5hbWV9LiBPcGVyYXRvciBjYW4gYmluZCBhIG5ldyBQQy5gKTtcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0QWxlcnRNZXNzYWdlKG51bGwpLCA0MDAwKTtcbiAgICB9XG4gIH07XG5cbiAgLy8gSGFuZGxlIFJlc2V0IE1vYmlsZSBCaW5kaW5nXG4gIGNvbnN0IGhhbmRsZVJlc2V0TW9iaWxlID0gKG9wZXJhdG9ySWQ6IHN0cmluZywgdXNlcm5hbWU6IHN0cmluZykgPT4ge1xuICAgIGlmICh3aW5kb3cuY29uZmlybShgUmVzZXQgTW9iaWxlIERldmljZSBCaW5kaW5nIGZvciBcIiR7dXNlcm5hbWV9XCI/IE9wZXJhdG9yIGNhbiBub3cgbG9nIGluIG9uIGEgbmV3IFNtYXJ0cGhvbmUuYCkpIHtcbiAgICAgIHJlc2V0T3BlcmF0b3JNb2JpbGVCaW5kaW5nKG9wZXJhdG9ySWQpO1xuICAgICAgbG9hZERhdGEoKTtcbiAgICAgIHNldEFsZXJ0TWVzc2FnZShg4pyFIE1vYmlsZSBkZXZpY2UgYmluZGluZyBjbGVhcmVkIGZvciAke3VzZXJuYW1lfS4gT3BlcmF0b3IgY2FuIGJpbmQgYSBuZXcgcGhvbmUuYCk7XG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHNldEFsZXJ0TWVzc2FnZShudWxsKSwgNDAwMCk7XG4gICAgfVxuICB9O1xuXG4gIC8vIEhhbmRsZSBSZXNldCBBbGwgRGV2aWNlcyAoUEMgKyBNb2JpbGUpXG4gIGNvbnN0IGhhbmRsZVJlc2V0QWxsRGV2aWNlcyA9IChvcGVyYXRvcklkOiBzdHJpbmcsIHVzZXJuYW1lOiBzdHJpbmcpID0+IHtcbiAgICBpZiAod2luZG93LmNvbmZpcm0oYFJlc2V0IEJPVEggUEMgJiBNb2JpbGUgYmluZGluZ3MgZm9yIFwiJHt1c2VybmFtZX1cIj9gKSkge1xuICAgICAgcmVzZXRPcGVyYXRvckFsbEJpbmRpbmdzKG9wZXJhdG9ySWQpO1xuICAgICAgbG9hZERhdGEoKTtcbiAgICAgIHNldEFsZXJ0TWVzc2FnZShg4pyFIEFsbCBkZXZpY2UgYmluZGluZ3MgKFBDICYgTW9iaWxlKSBjbGVhcmVkIGZvciAke3VzZXJuYW1lfS5gKTtcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0QWxlcnRNZXNzYWdlKG51bGwpLCA0MDAwKTtcbiAgICB9XG4gIH07XG5cbiAgLy8gSGFuZGxlIFRvZ2dsZSBMb2NrXG4gIGNvbnN0IGhhbmRsZVRvZ2dsZUxvY2sgPSAob3BlcmF0b3JJZDogc3RyaW5nLCB1c2VybmFtZTogc3RyaW5nKSA9PiB7XG4gICAgdG9nZ2xlT3BlcmF0b3JMb2NrKG9wZXJhdG9ySWQpO1xuICAgIGxvYWREYXRhKCk7XG4gICAgc2V0QWxlcnRNZXNzYWdlKGBMb2NrIHN0YXR1cyB1cGRhdGVkIGZvciAke3VzZXJuYW1lfWApO1xuICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0QWxlcnRNZXNzYWdlKG51bGwpLCAzMDAwKTtcbiAgfTtcblxuICAvLyBIYW5kbGUgRGVsZXRlIE9wZXJhdG9yXG4gIGNvbnN0IGhhbmRsZURlbGV0ZU9wZXJhdG9yID0gKG9wZXJhdG9ySWQ6IHN0cmluZywgdXNlcm5hbWU6IHN0cmluZykgPT4ge1xuICAgIGlmICh3aW5kb3cuY29uZmlybShgUGVybWFuZW50bHkgZGVsZXRlIG9wZXJhdG9yIGFjY291bnQgXCIke3VzZXJuYW1lfVwiP2ApKSB7XG4gICAgICBkZWxldGVPcGVyYXRvcihvcGVyYXRvcklkKTtcbiAgICAgIGxvYWREYXRhKCk7XG4gICAgICBzZXRBbGVydE1lc3NhZ2UoYE9wZXJhdG9yICR7dXNlcm5hbWV9IGRlbGV0ZWRgKTtcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0QWxlcnRNZXNzYWdlKG51bGwpLCAzMDAwKTtcbiAgICB9XG4gIH07XG5cbiAgLy8gSGFuZGxlIEFkZCBPcGVyYXRvclxuICBjb25zdCBoYW5kbGVDcmVhdGVPcGVyYXRvciA9IChlOiBSZWFjdC5Gb3JtRXZlbnQpID0+IHtcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgc2V0QWRkRXJyb3IoJycpO1xuXG4gICAgaWYgKCFuZXdVc2VybmFtZS50cmltKCkgfHwgIW5ld1Bhc3N3b3JkLnRyaW0oKSB8fCAhbmV3RGlzcGxheU5hbWUudHJpbSgpKSB7XG4gICAgICBzZXRBZGRFcnJvcignUGxlYXNlIGZpbGwgYWxsIHJlcXVpcmVkIGZpZWxkcycpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGNvbnN0IHN1Y2Nlc3MgPSBhZGROZXdPcGVyYXRvcih7XG4gICAgICB1c2VybmFtZTogbmV3VXNlcm5hbWUudHJpbSgpLnRvTG93ZXJDYXNlKCksXG4gICAgICBwYXNzd29yZDogbmV3UGFzc3dvcmQudHJpbSgpLFxuICAgICAgZGlzcGxheU5hbWU6IG5ld0Rpc3BsYXlOYW1lLnRyaW0oKSxcbiAgICAgIHJvbGU6ICdvcGVyYXRvcicsXG4gICAgICBwaG9uZTogbmV3UGhvbmUudHJpbSgpIHx8ICc5NTYxNDYwMzEzJ1xuICAgIH0pO1xuXG4gICAgaWYgKHN1Y2Nlc3MpIHtcbiAgICAgIHNldFNob3dBZGRNb2RhbChmYWxzZSk7XG4gICAgICBzZXROZXdVc2VybmFtZSgnJyk7XG4gICAgICBzZXROZXdQYXNzd29yZCgnJyk7XG4gICAgICBzZXROZXdEaXNwbGF5TmFtZSgnJyk7XG4gICAgICBzZXROZXdQaG9uZSgnJyk7XG4gICAgICBsb2FkRGF0YSgpO1xuICAgICAgc2V0QWxlcnRNZXNzYWdlKCfinIUgTmV3IE9wZXJhdG9yIElEIGNyZWF0ZWQhIFBlcm1pdHRlZCBvbiAxIEF1dGhvcml6ZWQgUEMgKyAxIEF1dGhvcml6ZWQgTW9iaWxlLicpO1xuICAgICAgc2V0VGltZW91dCgoKSA9PiBzZXRBbGVydE1lc3NhZ2UobnVsbCksIDQwMDApO1xuICAgIH0gZWxzZSB7XG4gICAgICBzZXRBZGRFcnJvcignVXNlcm5hbWUgYWxyZWFkeSBleGlzdHMuIFBsZWFzZSBjaG9vc2UgYW5vdGhlciB1c2VybmFtZS4nKTtcbiAgICB9XG4gIH07XG5cbiAgLy8gSGFuZGxlIERvd25sb2FkIFByb2plY3QgWklQXG4gIGNvbnN0IGhhbmRsZURvd25sb2FkWmlwID0gYXN5bmMgKCkgPT4ge1xuICAgIHNldElzRXhwb3J0aW5nWmlwKHRydWUpO1xuICAgIHNldFppcFByb2dyZXNzKHsgcGVyY2VudDogMTAsIGZpbGU6ICdHYXRoZXJpbmcgcHJvamVjdCBzb3VyY2UgZmlsZXMuLi4nIH0pO1xuXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHppcEJsb2IgPSBhd2FpdCBnZW5lcmF0ZVByb2plY3RaaXAoKHBlcmNlbnQsIGZpbGUpID0+IHtcbiAgICAgICAgc2V0WmlwUHJvZ3Jlc3MoeyBwZXJjZW50LCBmaWxlIH0pO1xuICAgICAgfSk7XG5cbiAgICAgIHRyaWdnZXJEb3dubG9hZFppcCh6aXBCbG9iLCBgTXV6YW1taWwtT25saW5lLVNlcnZpY2UtQ29tcGxldGUtdjk4LnppcGApO1xuICAgICAgc2V0QWxlcnRNZXNzYWdlKCfwn5OmIENvbXBsZXRlIG9yaWdpbmFsIHByb2plY3Qgc291cmNlIGNvZGUgKC5aSVApIGRvd25sb2FkZWQgc3VjY2Vzc2Z1bGx5IScpO1xuICAgICAgc2V0VGltZW91dCgoKSA9PiBzZXRBbGVydE1lc3NhZ2UobnVsbCksIDQwMDApO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoZSk7XG4gICAgICB3aW5kb3cubG9jYXRpb24uaHJlZiA9ICcvYXBpL2Rvd25sb2FkLXppcCc7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldElzRXhwb3J0aW5nWmlwKGZhbHNlKTtcbiAgICB9XG4gIH07XG5cbiAgLy8gSGFuZGxlIFNhdmUgU2hvcCBTZXR0aW5nc1xuICBjb25zdCBoYW5kbGVTYXZlU2V0dGluZ3MgPSAoZTogUmVhY3QuRm9ybUV2ZW50KSA9PiB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgIG9uVXBkYXRlU2V0dGluZ3Moc2hvcEZvcm0pO1xuICAgIHNldEFsZXJ0TWVzc2FnZSgn4pyFIFNob3AgZGV0YWlscyBhbmQgY29uZmlndXJhdGlvbiBzYXZlZCEnKTtcbiAgICBzZXRUaW1lb3V0KCgpID0+IHNldEFsZXJ0TWVzc2FnZShudWxsKSwgMzAwMCk7XG4gIH07XG5cbiAgY29uc3QgY29tcGxldGVkV29ya2Zsb3dDb3VudCA9IE9iamVjdC52YWx1ZXMoY29tcGxldGVkU3RlcHMpLmZpbHRlcihCb29sZWFuKS5sZW5ndGg7XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxuICAgICAgey8qIFRvcCBCYW5uZXIgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBwLTUgcm91bmRlZC0yeGwgc2hhZG93LW1kIGZsZXggZmxleC1jb2wgc206ZmxleC1yb3cgc206aXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtNFwiPlxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgZmxleC13cmFwXCI+XG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWV4dHJhYm9sZCB0ZXh0LXdoaXRlIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgIDxTaGllbGRDaGVjayBjbGFzc05hbWU9XCJ3LTYgaC02IHRleHQtYmx1ZS00MDBcIiAvPlxuICAgICAgICAgICAgICA8c3Bhbj5NYXN0ZXIgQWRtaW4gQ29udHJvbCBQYW5lbDwvc3Bhbj5cbiAgICAgICAgICAgIDwvaDE+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJiZy1lbWVyYWxkLTUwMC8yMCB0ZXh0LWVtZXJhbGQtMzAwIGJvcmRlciBib3JkZXItZW1lcmFsZC01MDAvMzAgdGV4dC14cyBweC0yLjUgcHktMC41IHJvdW5kZWQtZnVsbCBmb250LW1vbm8gZm9udC1ib2xkIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgPE1vbml0b3IgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1ibHVlLTQwMFwiIC8+XG4gICAgICAgICAgICAgIDxzcGFuPjEgUEMgKyAxIE1vYmlsZSBwZXIgT3BlcmF0b3IgSUQ8L3NwYW4+XG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMCBtdC0xXCI+XG4gICAgICAgICAgICBTYW1lIElEIHdvcmtzIGFjcm9zcyBTaG9wIFBDICYgT3BlcmF0b3IgTW9iaWxlIOKAoiBQcm9qZWN0IC5aSVAgU291cmNlIEV4cG9ydCDigKIgQ3liZXIgQ2FmZSBXb3JrZmxvdyAmIFNPUFxuICAgICAgICAgIDwvcD5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIEFjdGlvbiBCdXR0b25zICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGZsZXgtd3JhcFwiPlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZURvd25sb2FkWmlwfVxuICAgICAgICAgICAgZGlzYWJsZWQ9e2lzRXhwb3J0aW5nWmlwfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgYmctZ3JhZGllbnQtdG8tciBmcm9tLWVtZXJhbGQtNjAwIHRvLXRlYWwtNjAwIGhvdmVyOmZyb20tZW1lcmFsZC01MDAgaG92ZXI6dG8tdGVhbC01MDAgdGV4dC13aGl0ZSBmb250LWV4dHJhYm9sZCB0ZXh0LXhzIHB4LTQgcHktMi41IHJvdW5kZWQteGwgc2hhZG93LWxnIHNoYWRvdy1lbWVyYWxkLTYwMC8yMCB0cmFuc2l0aW9uLWFsbCBob3ZlcjpzY2FsZS0xMDUgZGlzYWJsZWQ6b3BhY2l0eS01MFwiXG4gICAgICAgICAgICB0aXRsZT1cIkRvd25sb2FkIGZ1bGwgcHJvamVjdCBzb3VyY2UgY29kZSBhcmNoaXZlICguemlwKVwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPEFyY2hpdmUgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICA8c3Bhbj57aXNFeHBvcnRpbmdaaXAgPyAnUGFja2luZyBaSVAuLi4nIDogJ/Cfk6YgRG93bmxvYWQgUHJvamVjdCAuWklQJ308L3NwYW4+XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBOb3RpZmljYXRpb25zICovfVxuICAgICAge2FsZXJ0TWVzc2FnZSAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zLjUgcm91bmRlZC14bCBiZy1lbWVyYWxkLTUwMC8xMCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtNTAwLzMwIHRleHQtZW1lcmFsZC00MDAgdGV4dC14cyBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gYW5pbWF0ZS1pbiBmYWRlLWluXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgPENoZWNrQ2lyY2xlMiBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtZW1lcmFsZC00MDAgZmxleC1zaHJpbmstMFwiIC8+XG4gICAgICAgICAgICA8c3Bhbj57YWxlcnRNZXNzYWdlfTwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IHNldEFsZXJ0TWVzc2FnZShudWxsKX0gY2xhc3NOYW1lPVwidGV4dC1lbWVyYWxkLTQwMCBob3Zlcjp0ZXh0LXdoaXRlXCI+4pyVPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgey8qIFN1Yi1OYXZpZ2F0aW9uIFRhYnM6IE9wZXJhdG9ycywgV29ya2Zsb3cgU09QLCBQcm9qZWN0IFpJUCwgTG9ncywgU2V0dGluZ3MgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHAtMS41IHJvdW5kZWQteGwgdGV4dC14cyBmb250LWJvbGQgb3ZlcmZsb3cteC1hdXRvXCI+XG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVTdWJUYWIoJ29wZXJhdG9ycycpfVxuICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtNCBweS0yIHJvdW5kZWQtbGcgdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgICAgIGFjdGl2ZVN1YlRhYiA9PT0gJ29wZXJhdG9ycydcbiAgICAgICAgICAgICAgPyAnYmctYmx1ZS02MDAgdGV4dC13aGl0ZSBzaGFkb3cnXG4gICAgICAgICAgICAgIDogJ3RleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtd2hpdGUnXG4gICAgICAgICAgfWB9XG4gICAgICAgID5cbiAgICAgICAgICA8TW9uaXRvciBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XG4gICAgICAgICAgPHNwYW4+T3BlcmF0b3IgSURzIChQQyAmIE1vYmlsZSBMb2NrcykgKHtvcGVyYXRvcnMubGVuZ3RofSk8L3NwYW4+XG4gICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVTdWJUYWIoJ3dvcmtmbG93Jyl9XG4gICAgICAgICAgY2xhc3NOYW1lPXtgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC00IHB5LTIgcm91bmRlZC1sZyB0cmFuc2l0aW9uLWFsbCAke1xuICAgICAgICAgICAgYWN0aXZlU3ViVGFiID09PSAnd29ya2Zsb3cnXG4gICAgICAgICAgICAgID8gJ2JnLWJsdWUtNjAwIHRleHQtd2hpdGUgc2hhZG93J1xuICAgICAgICAgICAgICA6ICd0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXdoaXRlJ1xuICAgICAgICAgIH1gfVxuICAgICAgICA+XG4gICAgICAgICAgPENsaXBib2FyZExpc3QgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1hbWJlci00MDBcIiAvPlxuICAgICAgICAgIDxzcGFuPkN5YmVyIENhZmUgV29ya2Zsb3cgJiBTT1A8L3NwYW4+XG4gICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVTdWJUYWIoJ3ppcF9kb3dubG9hZCcpfVxuICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtNCBweS0yIHJvdW5kZWQtbGcgdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgICAgIGFjdGl2ZVN1YlRhYiA9PT0gJ3ppcF9kb3dubG9hZCdcbiAgICAgICAgICAgICAgPyAnYmctYmx1ZS02MDAgdGV4dC13aGl0ZSBzaGFkb3cnXG4gICAgICAgICAgICAgIDogJ3RleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtd2hpdGUnXG4gICAgICAgICAgfWB9XG4gICAgICAgID5cbiAgICAgICAgICA8QXJjaGl2ZSBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LWVtZXJhbGQtNDAwXCIgLz5cbiAgICAgICAgICA8c3Bhbj5Qcm9qZWN0ICguWklQKSBFeHBvcnQ8L3NwYW4+XG4gICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVTdWJUYWIoJ2xvZ3MnKX1cbiAgICAgICAgICBjbGFzc05hbWU9e2BmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTQgcHktMiByb3VuZGVkLWxnIHRyYW5zaXRpb24tYWxsICR7XG4gICAgICAgICAgICBhY3RpdmVTdWJUYWIgPT09ICdsb2dzJ1xuICAgICAgICAgICAgICA/ICdiZy1ibHVlLTYwMCB0ZXh0LXdoaXRlIHNoYWRvdydcbiAgICAgICAgICAgICAgOiAndGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC13aGl0ZSdcbiAgICAgICAgICB9YH1cbiAgICAgICAgPlxuICAgICAgICAgIDxDbG9jayBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XG4gICAgICAgICAgPHNwYW4+U2VjdXJpdHkgJiBEZXZpY2UgTG9nczwvc3Bhbj5cbiAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZVN1YlRhYignc2V0dGluZ3MnKX1cbiAgICAgICAgICBjbGFzc05hbWU9e2BmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTQgcHktMiByb3VuZGVkLWxnIHRyYW5zaXRpb24tYWxsICR7XG4gICAgICAgICAgICBhY3RpdmVTdWJUYWIgPT09ICdzZXR0aW5ncydcbiAgICAgICAgICAgICAgPyAnYmctYmx1ZS02MDAgdGV4dC13aGl0ZSBzaGFkb3cnXG4gICAgICAgICAgICAgIDogJ3RleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtd2hpdGUnXG4gICAgICAgICAgfWB9XG4gICAgICAgID5cbiAgICAgICAgICA8S2V5IGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cbiAgICAgICAgICA8c3Bhbj5TaG9wIENvbmZpZ3VyYXRpb248L3NwYW4+XG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBUQUIgMTogT1BFUkFUT1IgSURTICYgRFVBTC1ERVZJQ0UgKFBDICsgTU9CSUxFKSBUQUJMRSAqL31cbiAgICAgIHthY3RpdmVTdWJUYWIgPT09ICdvcGVyYXRvcnMnICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0yeGwgcC01IHNoYWRvdy14bCBzcGFjZS15LTRcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgc206ZmxleC1yb3cgc206aXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMyBwYi0zIGJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDBcIj5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1leHRyYWJvbGQgdGV4dC13aGl0ZSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgIDxzcGFuPkF1dGhvcml6ZWQgT3BlcmF0b3JzIChQQyArIE1vYmlsZSBCaW5kaW5nKTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZW1lcmFsZC00MDAgYmctZW1lcmFsZC01MDAvMTAgcHgtMiBweS0wLjUgcm91bmRlZCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtNTAwLzIwIGZvbnQtbW9ub1wiPlxuICAgICAgICAgICAgICAgICAgMSBQQyArIDEgTW9iaWxlIFBlciBJRFxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9oMj5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMCBtdC0wLjVcIj5cbiAgICAgICAgICAgICAgICBFYWNoIG9wZXJhdG9yIElEIGNhbiB3b3JrIG9uIDxiPjEgYXV0aG9yaXplZCBQQzwvYj4gQU5EIDxiPjEgYXV0aG9yaXplZCBNb2JpbGU8L2I+IGF0IHRoZSBzYW1lIHRpbWUuIFRoaXJkLXBhcnR5IGRldmljZXMgYXJlIGJsb2NrZWQgYXV0b21hdGljYWxseS5cbiAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd0FkZE1vZGFsKHRydWUpfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IGJnLWJsdWUtNjAwIGhvdmVyOmJnLWJsdWUtNTAwIHRleHQtd2hpdGUgZm9udC1ib2xkIHRleHQteHMgcHgtMy41IHB5LTIgcm91bmRlZC14bCBzaGFkb3cgdHJhbnNpdGlvbi1hbGwgc2VsZi1zdGFydCBzbTpzZWxmLWF1dG9cIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8VXNlclBsdXMgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgIDxzcGFuPlJlZ2lzdGVyIE5ldyBPcGVyYXRvciBJRDwvc3Bhbj5cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIEN1cnJlbnQgRGV2aWNlIENhbGxvdXQgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMuNSByb3VuZGVkLXhsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCB0ZXh0LXhzIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBmbGV4LXdyYXAgZ2FwLTIgdGV4dC1zbGF0ZS0zMDBcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgPENwdSBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtYmx1ZS00MDBcIiAvPlxuICAgICAgICAgICAgICA8c3Bhbj5Zb3VyIEN1cnJlbnQgTWFjaGluZSAoe2N1cnJlbnRJc01vYmlsZSA/ICfwn5OxIE1vYmlsZScgOiAn8J+SuyBQQyd9KTo8L3NwYW4+XG4gICAgICAgICAgICAgIDxjb2RlIGNsYXNzTmFtZT1cInRleHQtd2hpdGUgZm9udC1tb25vIGZvbnQtYm9sZCBiZy1zbGF0ZS05MDAgcHgtMiBweS0wLjUgcm91bmRlZCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMFwiPlxuICAgICAgICAgICAgICAgIHtjdXJyZW50RGV2aWNlSWR9XG4gICAgICAgICAgICAgIDwvY29kZT5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgZm9udC1tb25vIHRleHQtWzExcHhdXCI+e2N1cnJlbnREZXZpY2VOYW1lfTwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBPcGVyYXRvcnMgVGFibGUgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvdmVyZmxvdy14LWF1dG9cIj5cbiAgICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJ3LWZ1bGwgdGV4dC1sZWZ0IHRleHQteHNcIj5cbiAgICAgICAgICAgICAgPHRoZWFkPlxuICAgICAgICAgICAgICAgIDx0ciBjbGFzc05hbWU9XCJib3JkZXItYiBib3JkZXItc2xhdGUtODAwIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBmb250LXNlbWlib2xkXCI+XG4gICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMyBweC0zXCI+T3BlcmF0b3IgLyBVc2VybmFtZTwvdGg+XG4gICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMyBweC0zXCI+Um9sZTwvdGg+XG4gICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMyBweC0zXCI+QXV0aG9yaXplZCBQQyAoMSBNYXgpPC90aD5cbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zIHB4LTNcIj5BdXRob3JpemVkIE1vYmlsZSAoMSBNYXgpPC90aD5cbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zIHB4LTNcIj5TdGF0dXM8L3RoPlxuICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTMgcHgtMyB0ZXh0LXJpZ2h0XCI+RGV2aWNlIEFjdGlvbnM8L3RoPlxuICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgIDwvdGhlYWQ+XG4gICAgICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJkaXZpZGUteSBkaXZpZGUtc2xhdGUtODAwLzYwXCI+XG4gICAgICAgICAgICAgICAge29wZXJhdG9ycy5tYXAoKG9wKSA9PiAoXG4gICAgICAgICAgICAgICAgICA8dHIga2V5PXtvcC5pZH0gY2xhc3NOYW1lPVwiaG92ZXI6Ymctc2xhdGUtOTUwLzQwIHRyYW5zaXRpb24tY29sb3JzXCI+XG4gICAgICAgICAgICAgICAgICAgIHsvKiBPcGVyYXRvciBOYW1lICovfVxuICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMyBweC0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC13aGl0ZSB0ZXh0LXNtXCI+e29wLmRpc3BsYXlOYW1lfTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgZm9udC1tb25vIHRleHQtWzExcHhdXCI+QHtvcC51c2VybmFtZX0g4oCiIHtvcC5waG9uZX08L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC90ZD5cblxuICAgICAgICAgICAgICAgICAgICB7LyogUm9sZSAqL31cbiAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMgcHgtM1wiPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YHB4LTIgcHktMC41IHJvdW5kZWQgdGV4dC1bMTBweF0gZm9udC1ib2xkIHVwcGVyY2FzZSBmb250LW1vbm8gJHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG9wLnJvbGUgPT09ICdhZG1pbidcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctcHVycGxlLTUwMC8yMCB0ZXh0LXB1cnBsZS0zMDAgYm9yZGVyIGJvcmRlci1wdXJwbGUtNTAwLzMwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICA6ICdiZy1ibHVlLTUwMC8yMCB0ZXh0LWJsdWUtMzAwIGJvcmRlciBib3JkZXItYmx1ZS01MDAvMzAnXG4gICAgICAgICAgICAgICAgICAgICAgfWB9PlxuICAgICAgICAgICAgICAgICAgICAgICAge29wLnJvbGUgPT09ICdhZG1pbicgPyAnTWFzdGVyIEFkbWluJyA6ICdPcGVyYXRvcid9XG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L3RkPlxuXG4gICAgICAgICAgICAgICAgICAgIHsvKiBBdXRob3JpemVkIFBDICovfVxuICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMyBweC0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAge29wLmJvdW5kUGNEZXZpY2VJZCA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0wLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IGZvbnQtYm9sZCB0ZXh0LWJsdWUtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPExhcHRvcCBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LWJsdWUtNDAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1vbm8gdGV4dC1bMTFweF1cIj57b3AuYm91bmRQY0RldmljZUlkfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS00MDAgdHJ1bmNhdGUgbWF4LXctWzE2MHB4XVwiPntvcC5ib3VuZFBjRGV2aWNlTmFtZSB8fCAnUEMgV29ya3N0YXRpb24nfTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlUmVzZXRQYyhvcC5pZCwgb3AudXNlcm5hbWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtYW1iZXItNDAwIGhvdmVyOnVuZGVybGluZSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMC41IGZvbnQtYm9sZCBwdC0wLjVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFJvdGF0ZUNjdyBjbGFzc05hbWU9XCJ3LTIuNSBoLTIuNVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+UmVzZXQgUEMgQmluZGluZzwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1hbWJlci00MDAgYmctYW1iZXItNTAwLzEwIHB4LTIgcHktMC41IHJvdW5kZWQgYm9yZGVyIGJvcmRlci1hbWJlci01MDAvMjAgZm9udC1tZWRpdW1cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgVW5ib3VuZCBQQyAoUGVuZGluZylcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICA8L3RkPlxuXG4gICAgICAgICAgICAgICAgICAgIHsvKiBBdXRob3JpemVkIE1vYmlsZSAqL31cbiAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMgcHgtM1wiPlxuICAgICAgICAgICAgICAgICAgICAgIHtvcC5ib3VuZE1vYmlsZURldmljZUlkID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTAuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgZm9udC1ib2xkIHRleHQtcHVycGxlLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTbWFydHBob25lIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtcHVycGxlLTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vIHRleHQtWzExcHhdXCI+e29wLmJvdW5kTW9iaWxlRGV2aWNlSWR9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTQwMCB0cnVuY2F0ZSBtYXgtdy1bMTYwcHhdXCI+e29wLmJvdW5kTW9iaWxlRGV2aWNlTmFtZSB8fCAnU21hcnRwaG9uZSd9PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVSZXNldE1vYmlsZShvcC5pZCwgb3AudXNlcm5hbWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtYW1iZXItNDAwIGhvdmVyOnVuZGVybGluZSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMC41IGZvbnQtYm9sZCBwdC0wLjVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFJvdGF0ZUNjdyBjbGFzc05hbWU9XCJ3LTIuNSBoLTIuNVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+UmVzZXQgTW9iaWxlIEJpbmRpbmc8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtYW1iZXItNDAwIGJnLWFtYmVyLTUwMC8xMCBweC0yIHB5LTAuNSByb3VuZGVkIGJvcmRlciBib3JkZXItYW1iZXItNTAwLzIwIGZvbnQtbWVkaXVtXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIFVuYm91bmQgTW9iaWxlIChQZW5kaW5nKVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgIDwvdGQ+XG5cbiAgICAgICAgICAgICAgICAgICAgey8qIEFjY291bnQgU3RhdHVzICovfVxuICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMyBweC0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAge29wLmlzTG9ja2VkID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicHgtMiBweS0wLjUgcm91bmRlZCBiZy1yb3NlLTUwMC8yMCB0ZXh0LXJvc2UtMzAwIGJvcmRlciBib3JkZXItcm9zZS01MDAvMzAgZm9udC1ib2xkIHRleHQtWzEwcHhdIHVwcGVyY2FzZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICBTdXNwZW5kZWRcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicHgtMiBweS0wLjUgcm91bmRlZCBiZy1lbWVyYWxkLTUwMC8yMCB0ZXh0LWVtZXJhbGQtMzAwIGJvcmRlciBib3JkZXItZW1lcmFsZC01MDAvMzAgZm9udC1ib2xkIHRleHQtWzEwcHhdIHVwcGVyY2FzZSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSB3LWZpdFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3LTEuNSBoLTEuNSByb3VuZGVkLWZ1bGwgYmctZW1lcmFsZC00MDBcIj48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPkFjdGl2ZTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICA8L3RkPlxuXG4gICAgICAgICAgICAgICAgICAgIHsvKiBBY3Rpb24gYnV0dG9ucyAqL31cbiAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMgcHgtMyB0ZXh0LXJpZ2h0XCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWVuZCBnYXAtMS41IGZsZXgtd3JhcFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIFJlc2V0IEFsbCBEZXZpY2VzIEJ1dHRvbiAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgIHsob3AuYm91bmRQY0RldmljZUlkIHx8IG9wLmJvdW5kTW9iaWxlRGV2aWNlSWQpICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVJlc2V0QWxsRGV2aWNlcyhvcC5pZCwgb3AudXNlcm5hbWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTIgcHktMSByb3VuZGVkLWxnIGJnLWFtYmVyLTUwMC8xMCB0ZXh0LWFtYmVyLTMwMCBib3JkZXIgYm9yZGVyLWFtYmVyLTUwMC8zMCBob3ZlcjpiZy1hbWJlci01MDAvMjAgZm9udC1ib2xkIHRleHQtWzEwcHhdIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIlJlc2V0IGJvdGggUEMgYW5kIE1vYmlsZSBiaW5kaW5nc1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBSZXNldCBBbGxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICB7LyogTG9jayAvIFVubG9jayAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgIHtvcC5yb2xlICE9PSAnYWRtaW4nICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVRvZ2dsZUxvY2sob3AuaWQsIG9wLnVzZXJuYW1lKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BwLTEuNSByb3VuZGVkLWxnIGJvcmRlciB0ZXh0LXhzICR7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcC5pc0xvY2tlZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1lbWVyYWxkLTUwMC8xMCB0ZXh0LWVtZXJhbGQtMzAwIGJvcmRlci1lbWVyYWxkLTUwMC8zMCBob3ZlcjpiZy1lbWVyYWxkLTUwMC8yMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnYmctc2xhdGUtODAwIHRleHQtc2xhdGUtNDAwIGJvcmRlci1zbGF0ZS03MDAgaG92ZXI6dGV4dC13aGl0ZSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT17b3AuaXNMb2NrZWQgPyAnVW5sb2NrIE9wZXJhdG9yJyA6ICdTdXNwZW5kIE9wZXJhdG9yJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtvcC5pc0xvY2tlZCA/IDxVbmxvY2sgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPiA6IDxMb2NrIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz59XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIERlbGV0ZSBPcGVyYXRvciAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgIHtvcC5yb2xlICE9PSAnYWRtaW4nICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZURlbGV0ZU9wZXJhdG9yKG9wLmlkLCBvcC51c2VybmFtZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xLjUgcm91bmRlZC1sZyBiZy1yb3NlLTUwMC8xMCB0ZXh0LXJvc2UtNDAwIGJvcmRlciBib3JkZXItcm9zZS01MDAvMjAgaG92ZXI6Ymctcm9zZS01MDAvMjAgdGV4dC14c1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJEZWxldGUgT3BlcmF0b3JcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFRyYXNoMiBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgIDwvdGJvZHk+XG4gICAgICAgICAgICA8L3RhYmxlPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIHsvKiBUQUIgMjogQ1lCRVIgQ0FGRSBXT1JLRkxPVyAmIFNPUCAoRU1CRURERUQgSU4gTUFTVEVSIEFETUlOKSAqL31cbiAgICAgIHthY3RpdmVTdWJUYWIgPT09ICd3b3JrZmxvdycgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTJ4bCBwLTUgc2hhZG93LXhsIHNwYWNlLXktNFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBzbTppdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zIHBiLTMgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LWV4dHJhYm9sZCB0ZXh0LXdoaXRlIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgPENsaXBib2FyZExpc3QgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LWFtYmVyLTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgPHNwYW4+Q3liZXIgQ2FmZSBTdGFuZGFyZCBPcGVyYXRpbmcgUHJvY2VkdXJlIChTT1ApPC9zcGFuPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1hbWJlci00MDAgYmctYW1iZXItNTAwLzEwIHB4LTIgcHktMC41IHJvdW5kZWQgYm9yZGVyIGJvcmRlci1hbWJlci01MDAvMjAgZm9udC1tb25vXCI+XG4gICAgICAgICAgICAgICAgICBNYXN0ZXIgV29ya2Zsb3dcbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIDwvaDI+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS00MDAgbXQtMC41XCI+XG4gICAgICAgICAgICAgICAgU3RhbmRhcmRpemVkIDYtc3RhZ2Ugb3BlcmF0aW9uYWwgcHJvdG9jb2wgZm9yIGFsbCBDU0MgJiBDeWJlciBDYWZlIHNlcnZpY2VzXG4gICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTk1MCBweC0zIHB5LTEuNSByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHRleHQteHMgZm9udC1tb25vIHRleHQtc2xhdGUtMzAwXCI+XG4gICAgICAgICAgICAgIENoZWNrbGlzdDogPHN0cm9uZyBjbGFzc05hbWU9XCJ0ZXh0LWVtZXJhbGQtNDAwXCI+e2NvbXBsZXRlZFdvcmtmbG93Q291bnR9IC8ge01BU1RFUl9XT1JLRkxPV19TVEVQUy5sZW5ndGh9IENvbXBsZXRlZDwvc3Ryb25nPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogV29ya2Zsb3cgU3RlcHMgR3JpZCAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTRcIj5cbiAgICAgICAgICAgIHtNQVNURVJfV09SS0ZMT1dfU1RFUFMubWFwKChzdGVwKSA9PiB7XG4gICAgICAgICAgICAgIGNvbnN0IGlzRG9uZSA9ICEhY29tcGxldGVkU3RlcHNbc3RlcC5zdGVwTnVtYmVyXTtcbiAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICBrZXk9e3N0ZXAuc3RlcE51bWJlcn1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHAtNCByb3VuZGVkLXhsIGJvcmRlciB0cmFuc2l0aW9uLWFsbCBzcGFjZS15LTMgJHtcbiAgICAgICAgICAgICAgICAgICAgaXNEb25lIFxuICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLXNsYXRlLTk1MC82MCBib3JkZXItZW1lcmFsZC01MDAvNDAnIFxuICAgICAgICAgICAgICAgICAgICAgIDogJ2JnLXNsYXRlLTk1MCBib3JkZXItc2xhdGUtODAwIGhvdmVyOmJvcmRlci1zbGF0ZS03MDAnXG4gICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgdy02IGgtNiByb3VuZGVkLWxnIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGZvbnQtYm9sZCB0ZXh0LXhzIGZvbnQtbW9ubyAke1xuICAgICAgICAgICAgICAgICAgICAgICAgaXNEb25lID8gJ2JnLWVtZXJhbGQtNTAwIHRleHQtc2xhdGUtOTUwJyA6ICdiZy1ibHVlLTYwMCB0ZXh0LXdoaXRlJ1xuICAgICAgICAgICAgICAgICAgICAgIH1gfT5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtzdGVwLnN0ZXBOdW1iZXJ9XG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LWV4dHJhYm9sZCB0ZXh0LXdoaXRlIHRleHQteHNcIj57c3RlcC50aXRsZX08L2gzPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0Q29tcGxldGVkU3RlcHMocHJldiA9PiAoeyAuLi5wcmV2LCBbc3RlcC5zdGVwTnVtYmVyXTogIXByZXZbc3RlcC5zdGVwTnVtYmVyXSB9KSl9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgdGV4dC1bMTFweF0gZm9udC1ib2xkIHB4LTIgcHktMC41IHJvdW5kZWQtbWQgYm9yZGVyICR7XG4gICAgICAgICAgICAgICAgICAgICAgICBpc0RvbmUgXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLWVtZXJhbGQtNTAwLzIwIHRleHQtZW1lcmFsZC0zMDAgYm9yZGVyLWVtZXJhbGQtNTAwLzMwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICA6ICdiZy1zbGF0ZS05MDAgdGV4dC1zbGF0ZS00MDAgYm9yZGVyLXNsYXRlLTcwMCdcbiAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIHtpc0RvbmUgPyA8Q2hlY2tDaXJjbGUyIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtZW1lcmFsZC00MDBcIiAvPiA6IDxDaXJjbGUgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPn1cbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57aXNEb25lID8gJ0RvbmUnIDogJ01hcmsnfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS0zMDAgbGVhZGluZy1zbnVnXCI+e3N0ZXAuZGVzY3JpcHRpb259PC9wPlxuXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMSBwdC0xIGJvcmRlci10IGJvcmRlci1zbGF0ZS04MDAvODBcIj5cbiAgICAgICAgICAgICAgICAgICAge3N0ZXAuY2hlY2tsaXN0Lm1hcCgoaXRlbSwgaWR4KSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e2lkeH0gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBnYXAtMS41IHRleHQtWzExcHhdIHRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNTAwXCI+4oCiPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e2l0ZW19PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMiByb3VuZGVkLWxnIGJnLXNsYXRlLTkwMCB0ZXh0LVsxMHB4XSB0ZXh0LWFtYmVyLTMwMC85MCBmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgPFNwYXJrbGVzIGNsYXNzTmFtZT1cInctMyBoLTMgdGV4dC1hbWJlci00MDAgZmxleC1zaHJpbmstMCBtdC0wLjVcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj48Yj5PcGVyYXRvciBOb3RlOjwvYj4ge3N0ZXAudGlwc308L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIH0pfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIHsvKiBUQUIgMzogT1JJR0lOQUwgUFJPSkVDVCAoLlpJUCkgRE9XTkxPQUQgQ0FSRCAqL31cbiAgICAgIHthY3RpdmVTdWJUYWIgPT09ICd6aXBfZG93bmxvYWQnICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0yeGwgcC02IHNoYWRvdy14bCBzcGFjZS15LTZcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQgZ2FwLTRcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xNCBoLTE0IHJvdW5kZWQtMnhsIGJnLWdyYWRpZW50LXRvLXRyIGZyb20tZW1lcmFsZC02MDAvMjAgdG8tdGVhbC01MDAvMjAgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTUwMC8zMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0ZXh0LWVtZXJhbGQtNDAwIGZsZXgtc2hyaW5rLTAgc2hhZG93LWlubmVyXCI+XG4gICAgICAgICAgICAgIDxBcmNoaXZlIGNsYXNzTmFtZT1cInctNyBoLTdcIiAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMVwiPlxuICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWV4dHJhYm9sZCB0ZXh0LXdoaXRlXCI+RG93bmxvYWQgQ29tcGxldGUgT3JpZ2luYWwgUHJvamVjdCBTb3VyY2UgKC5aSVApPC9oMj5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTMwMCBsZWFkaW5nLXJlbGF4ZWRcIj5cbiAgICAgICAgICAgICAgICBEb3dubG9hZCB0aGUgY29tcGxldGUsIHN0YW5kYWxvbmUgb2ZmbGluZSBjb2RlYmFzZSBvZiBNdXphbW1pbCBPbmxpbmUgU2VydmljZSBzdWl0ZSBjb250YWluaW5nIGFsbCBjb21wb25lbnRzLCBzZXJ2ZXIsIHN0eWxlcywgcGFja2FnZSBjb25maWd1cmF0aW9uLCBhbmQgYXNzZXRzLlxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IHJvdW5kZWQteGwgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHNwYWNlLXktM1wiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC13aGl0ZSBibG9ja1wiPkFyY2hpdmUgUGFja2FnZSBDb250ZW50czo8L3NwYW4+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTIgbWQ6Z3JpZC1jb2xzLTMgZ2FwLTIgdGV4dC14cyB0ZXh0LXNsYXRlLTQwMFwiPlxuICAgICAgICAgICAgICA8ZGl2PuKAoiBQVkMgU21hcnQgQ2FyZCBTdHVkaW8gKENSLTgwKTwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2PuKAoiBQYXNzcG9ydCBQaG90byBTdHVkaW8gUHJvPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXY+4oCiIEZhc3QgUE9TIEJpbGxpbmcgRGVzayAmIFJlY2VpcHRzPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXY+4oCiIEN1c3RvbWVyIENSTSAmIExlZGdlcjwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2PuKAoiBCaW9EYXRhICYgQ1YgTWFrZXIgRW5naW5lPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXY+4oCiIDUwKyBHb3Z0IENpdGl6ZW4gUG9ydGFscyBIdWI8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdj7igKIgRHVhbCBEZXZpY2UgTG9ja2luZyAoUEMgKyBNb2JpbGUpPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXY+4oCiIFNlcnZlci50cyBFeHByZXNzICYgR2VtaW5pIFByb3h5PC9kaXY+XG4gICAgICAgICAgICAgIDxkaXY+4oCiIENvbXBsZXRlIE9mZmxpbmUgUFdBIE1hbmlmZXN0PC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBEb3dubG9hZCBQcm9ncmVzcyBCYXIgKi99XG4gICAgICAgICAge2lzRXhwb3J0aW5nWmlwICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yIHAtNCByb3VuZGVkLXhsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtNTAwLzMwIGFuaW1hdGUtcHVsc2VcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiB0ZXh0LXhzIHRleHQtZW1lcmFsZC00MDAgZm9udC1ib2xkXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4+UGFja2luZyBaSVAgQXJjaGl2ZToge3ppcFByb2dyZXNzLmZpbGV9PC9zcGFuPlxuICAgICAgICAgICAgICAgIDxzcGFuPnt6aXBQcm9ncmVzcy5wZXJjZW50fSU8L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS04MDAgaC0yIHJvdW5kZWQtZnVsbCBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgICAgICAgICAgICA8ZGl2IFxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZW1lcmFsZC01MDAgaC1mdWxsIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTIwMFwiIFxuICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IGAke3ppcFByb2dyZXNzLnBlcmNlbnR9JWAgfX1cbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIGZsZXgtd3JhcFwiPlxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVEb3dubG9hZFppcH1cbiAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzRXhwb3J0aW5nWmlwfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBiZy1ncmFkaWVudC10by1yIGZyb20tZW1lcmFsZC02MDAgdG8tdGVhbC02MDAgaG92ZXI6ZnJvbS1lbWVyYWxkLTUwMCBob3Zlcjp0by10ZWFsLTUwMCB0ZXh0LXdoaXRlIGZvbnQtZXh0cmFib2xkIHRleHQtc20gcHgtNiBweS0zIHJvdW5kZWQteGwgc2hhZG93LWxnIHNoYWRvdy1lbWVyYWxkLTYwMC8zMCB0cmFuc2l0aW9uLWFsbCBob3ZlcjpzY2FsZS0xMDUgZGlzYWJsZWQ6b3BhY2l0eS01MFwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxEb3dubG9hZCBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgICAgPHNwYW4+e2lzRXhwb3J0aW5nWmlwID8gJ0NvbXByZXNzaW5nIFByb2plY3QuLi4nIDogJ0Rvd25sb2FkIFByb2plY3QgLlpJUCBBcmNoaXZlJ308L3NwYW4+XG4gICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgPGFcbiAgICAgICAgICAgICAgaHJlZj1cIi9hcGkvZG93bmxvYWQtemlwXCJcbiAgICAgICAgICAgICAgZG93bmxvYWQ9XCJNdXphbW1pbC1PbmxpbmUtU2VydmljZS1Db21wbGV0ZS1Tb3VyY2UuemlwXCJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWJsdWUtNDAwIGhvdmVyOnVuZGVybGluZSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSBmb250LXNlbWlib2xkXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPHNwYW4+RGlyZWN0IFNlcnZlciBEb3dubG9hZCBMaW5rPC9zcGFuPlxuICAgICAgICAgICAgPC9hPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIHsvKiBUQUIgNDogU0VDVVJJVFkgQVVESVQgJiBBQ0NFU1MgTE9HUyAqL31cbiAgICAgIHthY3RpdmVTdWJUYWIgPT09ICdsb2dzJyAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtMnhsIHAtNSBzaGFkb3cteGwgc3BhY2UteS00XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcGItMyBib3JkZXItYiBib3JkZXItc2xhdGUtODAwXCI+XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtZXh0cmFib2xkIHRleHQtd2hpdGVcIj5SZWFsLVRpbWUgU2VjdXJpdHkgJiBEZXZpY2UgQXVkaXQgTG9nPC9oMj5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMFwiPlJlY29yZCBvZiBhbGwgYXV0aG9yaXplZCBQQyAmIE1vYmlsZSBsb2dpbnMsIGRldmljZSBsb2NrcywgYW5kIGJsb2NrZWQgYWNjZXNzIGF0dGVtcHRzPC9wPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIG9uQ2xpY2s9e2xvYWREYXRhfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSBweC0zIHB5LTEuNSByb3VuZGVkLWxnIGJnLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTMwMCBob3Zlcjp0ZXh0LXdoaXRlIHRleHQteHMgZm9udC1zZW1pYm9sZFwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxSZWZyZXNoQ3cgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICAgICAgICA8c3Bhbj5SZWZyZXNoIExvZ3M8L3NwYW4+XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwib3ZlcmZsb3cteC1hdXRvIG1heC1oLTk2XCI+XG4gICAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQtbGVmdCB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgIDx0aGVhZCBjbGFzc05hbWU9XCJzdGlja3kgdG9wLTAgYmctc2xhdGUtOTAwIGJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDAgdGV4dC1zbGF0ZS00MDBcIj5cbiAgICAgICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMi41IHB4LTNcIj5UaW1lc3RhbXA8L3RoPlxuICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTIuNSBweC0zXCI+QWN0aW9uPC90aD5cbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0yLjUgcHgtM1wiPk9wZXJhdG9yPC90aD5cbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0yLjUgcHgtM1wiPlR5cGU8L3RoPlxuICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTIuNSBweC0zXCI+RGV2aWNlIElEPC90aD5cbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0yLjUgcHgtM1wiPkRldGFpbHM8L3RoPlxuICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgIDwvdGhlYWQ+XG4gICAgICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJkaXZpZGUteSBkaXZpZGUtc2xhdGUtODAwLzYwIGZvbnQtbW9ubyB0ZXh0LVsxMXB4XVwiPlxuICAgICAgICAgICAgICAgIHthdWRpdExvZ3MubGVuZ3RoID4gMCA/IChcbiAgICAgICAgICAgICAgICAgIGF1ZGl0TG9ncy5tYXAoKGxvZykgPT4gKFxuICAgICAgICAgICAgICAgICAgICA8dHIga2V5PXtsb2cuaWR9IGNsYXNzTmFtZT1cImhvdmVyOmJnLXNsYXRlLTk1MC80MFwiPlxuICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0yLjUgcHgtMyB0ZXh0LXNsYXRlLTQwMFwiPntsb2cudGltZXN0YW1wfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTIuNSBweC0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2BweC0yIHB5LTAuNSByb3VuZGVkIHRleHQtWzEwcHhdIGZvbnQtYm9sZCAke1xuICAgICAgICAgICAgICAgICAgICAgICAgICBsb2cuYWN0aW9uID09PSAnTE9HSU5fU1VDQ0VTUycgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctZW1lcmFsZC01MDAvMjAgdGV4dC1lbWVyYWxkLTQwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IGxvZy5hY3Rpb24gPT09ICdERVZJQ0VfQkxPQ0tFRCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1yb3NlLTUwMC8yMCB0ZXh0LXJvc2UtNDAwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogbG9nLmFjdGlvbiA9PT0gJ0RFVklDRV9CT1VORCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1ibHVlLTUwMC8yMCB0ZXh0LWJsdWUtNDAwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogJ2JnLWFtYmVyLTUwMC8yMCB0ZXh0LWFtYmVyLTQwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgIH1gfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAge2xvZy5hY3Rpb259XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMi41IHB4LTMgdGV4dC13aGl0ZSBmb250LWJvbGRcIj5Ae2xvZy51c2VybmFtZX08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0yLjUgcHgtMyB0ZXh0LXNsYXRlLTQwMFwiPntsb2cuZGV2aWNlVHlwZSA9PT0gJ21vYmlsZScgPyAn8J+TsSBNb2JpbGUnIDogJ/CfkrsgUEMnfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTIuNSBweC0zIHRleHQtc2xhdGUtMzAwXCI+e2xvZy5kZXZpY2VJZH08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0yLjUgcHgtMyB0ZXh0LXNsYXRlLTQwMCBtYXgtdy14cyB0cnVuY2F0ZSBmb250LXNhbnNcIj57bG9nLmRldGFpbHN9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICkpXG4gICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICAgICAgPHRkIGNvbFNwYW49ezZ9IGNsYXNzTmFtZT1cInB5LTYgdGV4dC1jZW50ZXIgdGV4dC1zbGF0ZS01MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICBObyBzZWN1cml0eSBhdWRpdCBsb2dzIHJlY29yZGVkIHlldC5cbiAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICAgIDwvdGFibGU+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgey8qIFRBQiA1OiBTSE9QIENPTkZJR1VSQVRJT04gU0VUVElOR1MgKi99XG4gICAgICB7YWN0aXZlU3ViVGFiID09PSAnc2V0dGluZ3MnICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0yeGwgcC01IHNoYWRvdy14bCBtYXgtdy0yeGwgc3BhY2UteS00XCI+XG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LWV4dHJhYm9sZCB0ZXh0LXdoaXRlXCI+Q3liZXIgQ2FmZSAmIENTQyBDb25maWd1cmF0aW9uPC9oMj5cbiAgICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlU2F2ZVNldHRpbmdzfSBjbGFzc05hbWU9XCJzcGFjZS15LTQgdGV4dC14c1wiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0yIGdhcC0zXCI+XG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIGJsb2NrIG1iLTFcIj5TaG9wIC8gQ2VudGVyIE5hbWU8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3Nob3BGb3JtLnNob3BOYW1lfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTaG9wRm9ybSh7IC4uLnNob3BGb3JtLCBzaG9wTmFtZTogZS50YXJnZXQudmFsdWUgfSl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQteGwgcC0yLjUgdGV4dC13aGl0ZSBmb250LWJvbGRcIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIGJsb2NrIG1iLTFcIj5Pd25lciBOYW1lPC9sYWJlbD5cbiAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtzaG9wRm9ybS5vd25lck5hbWV9XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNob3BGb3JtKHsgLi4uc2hvcEZvcm0sIG93bmVyTmFtZTogZS50YXJnZXQudmFsdWUgfSl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQteGwgcC0yLjUgdGV4dC13aGl0ZSBmb250LWJvbGRcIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIGJsb2NrIG1iLTFcIj5XaGF0c0FwcCAvIENvbnRhY3QgUGhvbmU8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3Nob3BGb3JtLnBob25lfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTaG9wRm9ybSh7IC4uLnNob3BGb3JtLCBwaG9uZTogZS50YXJnZXQudmFsdWUgfSl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQteGwgcC0yLjUgdGV4dC13aGl0ZSBmb250LWJvbGRcIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIGJsb2NrIG1iLTFcIj5VUEkgSUQgZm9yIFBPUyBRUiBDb2RlPC9sYWJlbD5cbiAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtzaG9wRm9ybS51cGlJZH1cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2hvcEZvcm0oeyAuLi5zaG9wRm9ybSwgdXBpSWQ6IGUudGFyZ2V0LnZhbHVlIH0pfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLXhsIHAtMi41IHRleHQtd2hpdGUgZm9udC1ib2xkXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNtOmNvbC1zcGFuLTJcIj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgYmxvY2sgbWItMVwiPkFkZHJlc3MgKFByaW50ZWQgb24gcmVjZWlwdHMgJiBpbnZvaWNlcyk8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3Nob3BGb3JtLmFkZHJlc3N9XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNob3BGb3JtKHsgLi4uc2hvcEZvcm0sIGFkZHJlc3M6IGUudGFyZ2V0LnZhbHVlIH0pfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLXhsIHAtMi41IHRleHQtd2hpdGVcIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTUgcHktMi41IGJnLWJsdWUtNjAwIGhvdmVyOmJnLWJsdWUtNTAwIHRleHQtd2hpdGUgZm9udC1ib2xkIHJvdW5kZWQteGwgc2hhZG93IHRyYW5zaXRpb24tYWxsXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgU2F2ZSBTaG9wIFNldHRpbmdzXG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8L2Zvcm0+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgey8qIFJFR0lTVEVSIE5FVyBPUEVSQVRPUiBNT0RBTCAqL31cbiAgICAgIHtzaG93QWRkTW9kYWwgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgYmctYmxhY2svODAgYmFja2Ryb3AtYmx1ci1zbSB6LTUwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtNFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtM3hsIG1heC13LW1kIHctZnVsbCBwLTYgc2hhZG93LTJ4bCBzcGFjZS15LTQgYW5pbWF0ZS1pbiBmYWRlLWluIHpvb20taW4tOTVcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHBiLTIgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZm9udC1leHRyYWJvbGQgdGV4dC13aGl0ZSB0ZXh0LWJhc2UgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICA8VXNlclBsdXMgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LWJsdWUtNDAwXCIgLz5cbiAgICAgICAgICAgICAgICA8c3Bhbj5SZWdpc3RlciBOZXcgT3BlcmF0b3IgSUQ8L3NwYW4+XG4gICAgICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gc2V0U2hvd0FkZE1vZGFsKGZhbHNlKX0gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC13aGl0ZVwiPuKclTwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS0zMDBcIj5cbiAgICAgICAgICAgICAgVGhpcyBuZXcgb3BlcmF0b3IgSUQgd2lsbCBiaW5kIHRvIDxiPjEgQXV0aG9yaXplZCBQQzwvYj4gKyA8Yj4xIEF1dGhvcml6ZWQgTW9iaWxlPC9iPiB1cG9uIHRoZWlyIGZpcnN0IGxvZ2luIGZyb20gZWFjaCBkZXZpY2UuXG4gICAgICAgICAgICA8L3A+XG5cbiAgICAgICAgICAgIHthZGRFcnJvciAmJiAoXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zIHJvdW5kZWQteGwgYmctcm9zZS01MDAvMTAgYm9yZGVyIGJvcmRlci1yb3NlLTUwMC8zMCB0ZXh0LXJvc2UtNDAwIHRleHQteHNcIj5cbiAgICAgICAgICAgICAgICB7YWRkRXJyb3J9XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZUNyZWF0ZU9wZXJhdG9yfSBjbGFzc05hbWU9XCJzcGFjZS15LTMgdGV4dC14c1wiPlxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBibG9jayBtYi0xXCI+T3BlcmF0b3IgRnVsbCBOYW1lPC9sYWJlbD5cbiAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImUuZy4gU2hhaWtoIFNhbWVlclwiXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17bmV3RGlzcGxheU5hbWV9XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldE5ld0Rpc3BsYXlOYW1lKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCBwLTIuNSB0ZXh0LXdoaXRlIGZvbnQtYm9sZFwiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgYmxvY2sgbWItMVwiPlVzZXJuYW1lIChMb2dpbiBJRCk8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiZS5nLiBvcGVyYXRvcjNcIlxuICAgICAgICAgICAgICAgICAgdmFsdWU9e25ld1VzZXJuYW1lfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXROZXdVc2VybmFtZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQteGwgcC0yLjUgdGV4dC13aGl0ZSBmb250LW1vbm8gZm9udC1ib2xkXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBibG9jayBtYi0xXCI+UGFzc3dvcmQ8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgdHlwZT1cInBhc3N3b3JkXCJcbiAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkNyZWF0ZSBzZWN1cmUgcGFzc3dvcmRcIlxuICAgICAgICAgICAgICAgICAgdmFsdWU9e25ld1Bhc3N3b3JkfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXROZXdQYXNzd29yZChlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQteGwgcC0yLjUgdGV4dC13aGl0ZVwiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgYmxvY2sgbWItMVwiPlBob25lIE51bWJlcjwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICB0eXBlPVwidGVsXCJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiTW9iaWxlIG51bWJlclwiXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17bmV3UGhvbmV9XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldE5ld1Bob25lKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCBwLTIuNSB0ZXh0LXdoaXRlXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTIgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1lbmQgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dBZGRNb2RhbChmYWxzZSl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIgYmctc2xhdGUtODAwIHRleHQtc2xhdGUtMzAwIGZvbnQtYm9sZCByb3VuZGVkLXhsXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICBDYW5jZWxcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTUgcHktMiBiZy1ibHVlLTYwMCBob3ZlcjpiZy1ibHVlLTUwMCB0ZXh0LXdoaXRlIGZvbnQtYm9sZCByb3VuZGVkLXhsIHNoYWRvd1wiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgUmVnaXN0ZXIgT3BlcmF0b3JcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Zvcm0+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG4iXX0=