const JSZip = __vite__cjsImport0_jszip;import __vite__cjsImport0_jszip from "/node_modules/.vite/deps/jszip.js?v=090625a0";
export async function generateProjectZip(onProgress) {
	const zip = new JSZip();
	// Project information
	const readmeContent = `# Muzammil Online Service - CSC & Cyber Cafe Workstation Suite
## Version: v98.0 PC Suite (Standalone Standalone Edition)
**Owner:** Imran Khan | **Contact:** 9561460313
**Address:** Naya Munshi Shaban Nagar, Main Road, Maharashtra, India

---

### Features & Workstation Modules:
1. **Strict 1-Device Security Locking**: Each Operator ID is permanently bound to a single computer/phone.
2. **PVC Smart Card Studio**: CR-80 85.6x54mm instant dual card 300 DPI layout for 4x6 photo paper with center cut line.
3. **Passport Photo Studio Pro**:
   - 4x6 Landscape (8 Copies @ 300 DPI) & A4 Landscape sheet layout.
   - Connected Flood-Fill Magic Wand Background Cutout.
   - Vector Pen Tool with Anchor Points & Live Dual Preview.
   - AI Auto Beauty Face Effect with Skin Smoothing & Facial Radiance.
   - Official Exam Stamp (Candidate Name & Date for SSC/Police Bharti).
4. **PDF to HD JPG High-Resolution Rasterizer**: Convert PDF Aadhaar/PAN/Voter slips to 300 DPI images.
5. **Fast Thermal Billing Desk & POS**: 58mm & 80mm thermal receipt generator with QR code payment.
6. **Customer CRM & Delivery Tracker**: Token tracking, pending work alerts, WhatsApp notifications.
7. **BioData & CV Maker**: Hindi, English, and Islamic wedding biodata templates.
8. **50+ Government Portals Directory**: Direct links to all Central & Maharashtra State Citizen Portals.
9. **Cyber Cafe Daily SOP Workflow Engine**: Interactive checklist for day-to-day cyber operations.
10. **Master Admin Panel**: Device lock resets, operator management, and security audit logs.

---

### How to Run Locally:
\`\`\`bash
# 1. Install dependencies
npm install

# 2. Run development server (Port 3000)
npm run dev

# 3. Build for production
npm run build
\`\`\`
`;
	zip.file("README.md", readmeContent);
	// We can fetch files or bundle the source files that make up the client app
	const sourceFiles = [
		"/package.json",
		"/server.ts",
		"/vite.config.ts",
		"/tsconfig.json",
		"/index.html",
		"/src/main.tsx",
		"/src/App.tsx",
		"/src/index.css",
		"/src/types.ts",
		"/src/utils/storage.ts",
		"/src/utils/printer.ts",
		"/src/utils/deviceSecurity.ts",
		"/src/utils/projectZip.ts",
		"/src/components/LoginScreen.tsx",
		"/src/components/PvcStudioView.tsx",
		"/src/components/PassportStudioView.tsx",
		"/src/components/BillingDeskView.tsx",
		"/src/components/CustomerCrmView.tsx",
		"/src/components/PdfToJpgView.tsx",
		"/src/components/BioDataMakerView.tsx",
		"/src/components/PortalsDirectoryView.tsx",
		"/src/components/AiAssistantView.tsx",
		"/src/components/ShortcutsModal.tsx",
		"/src/components/AuthModal.tsx",
		"/src/components/SettingsModal.tsx",
		"/src/components/MasterAdminView.tsx",
		"/src/components/WorkflowGuideView.tsx"
	];
	let completed = 0;
	for (const filePath of sourceFiles) {
		try {
			const cleanPath = filePath.startsWith("/") ? filePath.slice(1) : filePath;
			if (onProgress) {
				onProgress(Math.round(completed / sourceFiles.length * 100), cleanPath);
			}
			const res = await fetch(filePath);
			if (res.ok) {
				const text = await res.text();
				zip.file(cleanPath, text);
			}
		} catch {}
		completed++;
	}
	if (onProgress) {
		onProgress(100, "Compressing archive...");
	}
	const content = await zip.generateAsync({
		type: "blob",
		compression: "DEFLATE",
		compressionOptions: { level: 9 }
	});
	return content;
}
export function triggerDownloadZip(blob, filename = "Muzammil-Online-Service-Complete-Source.zip") {
	const url = URL.createObjectURL(blob);
	const a = document.createElement("a");
	a.href = url;
	a.download = filename;
	document.body.appendChild(a);
	a.click();
	document.body.removeChild(a);
	setTimeout(() => URL.revokeObjectURL(url), 5e3);
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBRWxCLE9BQU8sZUFBZSxtQkFBbUIsWUFBcUU7Q0FDNUcsTUFBTSxNQUFNLElBQUksTUFBTTs7Q0FHdEIsTUFBTSxnQkFBZ0I7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBdUN0QixJQUFJLEtBQUssYUFBYSxhQUFhOztDQUduQyxNQUFNLGNBQWM7RUFDbEI7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0NBQ0Y7Q0FFQSxJQUFJLFlBQVk7Q0FDaEIsS0FBSyxNQUFNLFlBQVksYUFBYTtFQUNsQyxJQUFJO0dBQ0YsTUFBTSxZQUFZLFNBQVMsV0FBVyxHQUFHLElBQUksU0FBUyxNQUFNLENBQUMsSUFBSTtHQUNqRSxJQUFJLFlBQVk7SUFDZCxXQUFXLEtBQUssTUFBTyxZQUFZLFlBQVksU0FBVSxHQUFHLEdBQUcsU0FBUztHQUMxRTtHQUVBLE1BQU0sTUFBTSxNQUFNLE1BQU0sUUFBUTtHQUNoQyxJQUFJLElBQUksSUFBSTtJQUNWLE1BQU0sT0FBTyxNQUFNLElBQUksS0FBSztJQUM1QixJQUFJLEtBQUssV0FBVyxJQUFJO0dBQzFCO0VBQ0YsUUFBUSxDQUVSO0VBQ0E7Q0FDRjtDQUVBLElBQUksWUFBWTtFQUNkLFdBQVcsS0FBSyx3QkFBd0I7Q0FDMUM7Q0FFQSxNQUFNLFVBQVUsTUFBTSxJQUFJLGNBQWM7RUFDdEMsTUFBTTtFQUNOLGFBQWE7RUFDYixvQkFBb0IsRUFBRSxPQUFPLEVBQUU7Q0FDakMsQ0FBQztDQUVELE9BQU87QUFDVDtBQUVBLE9BQU8sU0FBUyxtQkFBbUIsTUFBWSxXQUFXLCtDQUErQztDQUN2RyxNQUFNLE1BQU0sSUFBSSxnQkFBZ0IsSUFBSTtDQUNwQyxNQUFNLElBQUksU0FBUyxjQUFjLEdBQUc7Q0FDcEMsRUFBRSxPQUFPO0NBQ1QsRUFBRSxXQUFXO0NBQ2IsU0FBUyxLQUFLLFlBQVksQ0FBQztDQUMzQixFQUFFLE1BQU07Q0FDUixTQUFTLEtBQUssWUFBWSxDQUFDO0NBQzNCLGlCQUFpQixJQUFJLGdCQUFnQixHQUFHLEdBQUcsR0FBSTtBQUNqRCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJwcm9qZWN0WmlwLnRzIl0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBKU1ppcCBmcm9tICdqc3ppcCc7XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZW5lcmF0ZVByb2plY3RaaXAob25Qcm9ncmVzcz86IChwZXJjZW50OiBudW1iZXIsIGZpbGU6IHN0cmluZykgPT4gdm9pZCk6IFByb21pc2U8QmxvYj4ge1xuICBjb25zdCB6aXAgPSBuZXcgSlNaaXAoKTtcblxuICAvLyBQcm9qZWN0IGluZm9ybWF0aW9uXG4gIGNvbnN0IHJlYWRtZUNvbnRlbnQgPSBgIyBNdXphbW1pbCBPbmxpbmUgU2VydmljZSAtIENTQyAmIEN5YmVyIENhZmUgV29ya3N0YXRpb24gU3VpdGVcbiMjIFZlcnNpb246IHY5OC4wIFBDIFN1aXRlIChTdGFuZGFsb25lIFN0YW5kYWxvbmUgRWRpdGlvbilcbioqT3duZXI6KiogSW1yYW4gS2hhbiB8ICoqQ29udGFjdDoqKiA5NTYxNDYwMzEzXG4qKkFkZHJlc3M6KiogTmF5YSBNdW5zaGkgU2hhYmFuIE5hZ2FyLCBNYWluIFJvYWQsIE1haGFyYXNodHJhLCBJbmRpYVxuXG4tLS1cblxuIyMjIEZlYXR1cmVzICYgV29ya3N0YXRpb24gTW9kdWxlczpcbjEuICoqU3RyaWN0IDEtRGV2aWNlIFNlY3VyaXR5IExvY2tpbmcqKjogRWFjaCBPcGVyYXRvciBJRCBpcyBwZXJtYW5lbnRseSBib3VuZCB0byBhIHNpbmdsZSBjb21wdXRlci9waG9uZS5cbjIuICoqUFZDIFNtYXJ0IENhcmQgU3R1ZGlvKio6IENSLTgwIDg1LjZ4NTRtbSBpbnN0YW50IGR1YWwgY2FyZCAzMDAgRFBJIGxheW91dCBmb3IgNHg2IHBob3RvIHBhcGVyIHdpdGggY2VudGVyIGN1dCBsaW5lLlxuMy4gKipQYXNzcG9ydCBQaG90byBTdHVkaW8gUHJvKio6XG4gICAtIDR4NiBMYW5kc2NhcGUgKDggQ29waWVzIEAgMzAwIERQSSkgJiBBNCBMYW5kc2NhcGUgc2hlZXQgbGF5b3V0LlxuICAgLSBDb25uZWN0ZWQgRmxvb2QtRmlsbCBNYWdpYyBXYW5kIEJhY2tncm91bmQgQ3V0b3V0LlxuICAgLSBWZWN0b3IgUGVuIFRvb2wgd2l0aCBBbmNob3IgUG9pbnRzICYgTGl2ZSBEdWFsIFByZXZpZXcuXG4gICAtIEFJIEF1dG8gQmVhdXR5IEZhY2UgRWZmZWN0IHdpdGggU2tpbiBTbW9vdGhpbmcgJiBGYWNpYWwgUmFkaWFuY2UuXG4gICAtIE9mZmljaWFsIEV4YW0gU3RhbXAgKENhbmRpZGF0ZSBOYW1lICYgRGF0ZSBmb3IgU1NDL1BvbGljZSBCaGFydGkpLlxuNC4gKipQREYgdG8gSEQgSlBHIEhpZ2gtUmVzb2x1dGlvbiBSYXN0ZXJpemVyKio6IENvbnZlcnQgUERGIEFhZGhhYXIvUEFOL1ZvdGVyIHNsaXBzIHRvIDMwMCBEUEkgaW1hZ2VzLlxuNS4gKipGYXN0IFRoZXJtYWwgQmlsbGluZyBEZXNrICYgUE9TKio6IDU4bW0gJiA4MG1tIHRoZXJtYWwgcmVjZWlwdCBnZW5lcmF0b3Igd2l0aCBRUiBjb2RlIHBheW1lbnQuXG42LiAqKkN1c3RvbWVyIENSTSAmIERlbGl2ZXJ5IFRyYWNrZXIqKjogVG9rZW4gdHJhY2tpbmcsIHBlbmRpbmcgd29yayBhbGVydHMsIFdoYXRzQXBwIG5vdGlmaWNhdGlvbnMuXG43LiAqKkJpb0RhdGEgJiBDViBNYWtlcioqOiBIaW5kaSwgRW5nbGlzaCwgYW5kIElzbGFtaWMgd2VkZGluZyBiaW9kYXRhIHRlbXBsYXRlcy5cbjguICoqNTArIEdvdmVybm1lbnQgUG9ydGFscyBEaXJlY3RvcnkqKjogRGlyZWN0IGxpbmtzIHRvIGFsbCBDZW50cmFsICYgTWFoYXJhc2h0cmEgU3RhdGUgQ2l0aXplbiBQb3J0YWxzLlxuOS4gKipDeWJlciBDYWZlIERhaWx5IFNPUCBXb3JrZmxvdyBFbmdpbmUqKjogSW50ZXJhY3RpdmUgY2hlY2tsaXN0IGZvciBkYXktdG8tZGF5IGN5YmVyIG9wZXJhdGlvbnMuXG4xMC4gKipNYXN0ZXIgQWRtaW4gUGFuZWwqKjogRGV2aWNlIGxvY2sgcmVzZXRzLCBvcGVyYXRvciBtYW5hZ2VtZW50LCBhbmQgc2VjdXJpdHkgYXVkaXQgbG9ncy5cblxuLS0tXG5cbiMjIyBIb3cgdG8gUnVuIExvY2FsbHk6XG5cXGBcXGBcXGBiYXNoXG4jIDEuIEluc3RhbGwgZGVwZW5kZW5jaWVzXG5ucG0gaW5zdGFsbFxuXG4jIDIuIFJ1biBkZXZlbG9wbWVudCBzZXJ2ZXIgKFBvcnQgMzAwMClcbm5wbSBydW4gZGV2XG5cbiMgMy4gQnVpbGQgZm9yIHByb2R1Y3Rpb25cbm5wbSBydW4gYnVpbGRcblxcYFxcYFxcYFxuYDtcblxuICB6aXAuZmlsZSgnUkVBRE1FLm1kJywgcmVhZG1lQ29udGVudCk7XG5cbiAgLy8gV2UgY2FuIGZldGNoIGZpbGVzIG9yIGJ1bmRsZSB0aGUgc291cmNlIGZpbGVzIHRoYXQgbWFrZSB1cCB0aGUgY2xpZW50IGFwcFxuICBjb25zdCBzb3VyY2VGaWxlcyA9IFtcbiAgICAnL3BhY2thZ2UuanNvbicsXG4gICAgJy9zZXJ2ZXIudHMnLFxuICAgICcvdml0ZS5jb25maWcudHMnLFxuICAgICcvdHNjb25maWcuanNvbicsXG4gICAgJy9pbmRleC5odG1sJyxcbiAgICAnL3NyYy9tYWluLnRzeCcsXG4gICAgJy9zcmMvQXBwLnRzeCcsXG4gICAgJy9zcmMvaW5kZXguY3NzJyxcbiAgICAnL3NyYy90eXBlcy50cycsXG4gICAgJy9zcmMvdXRpbHMvc3RvcmFnZS50cycsXG4gICAgJy9zcmMvdXRpbHMvcHJpbnRlci50cycsXG4gICAgJy9zcmMvdXRpbHMvZGV2aWNlU2VjdXJpdHkudHMnLFxuICAgICcvc3JjL3V0aWxzL3Byb2plY3RaaXAudHMnLFxuICAgICcvc3JjL2NvbXBvbmVudHMvTG9naW5TY3JlZW4udHN4JyxcbiAgICAnL3NyYy9jb21wb25lbnRzL1B2Y1N0dWRpb1ZpZXcudHN4JyxcbiAgICAnL3NyYy9jb21wb25lbnRzL1Bhc3Nwb3J0U3R1ZGlvVmlldy50c3gnLFxuICAgICcvc3JjL2NvbXBvbmVudHMvQmlsbGluZ0Rlc2tWaWV3LnRzeCcsXG4gICAgJy9zcmMvY29tcG9uZW50cy9DdXN0b21lckNybVZpZXcudHN4JyxcbiAgICAnL3NyYy9jb21wb25lbnRzL1BkZlRvSnBnVmlldy50c3gnLFxuICAgICcvc3JjL2NvbXBvbmVudHMvQmlvRGF0YU1ha2VyVmlldy50c3gnLFxuICAgICcvc3JjL2NvbXBvbmVudHMvUG9ydGFsc0RpcmVjdG9yeVZpZXcudHN4JyxcbiAgICAnL3NyYy9jb21wb25lbnRzL0FpQXNzaXN0YW50Vmlldy50c3gnLFxuICAgICcvc3JjL2NvbXBvbmVudHMvU2hvcnRjdXRzTW9kYWwudHN4JyxcbiAgICAnL3NyYy9jb21wb25lbnRzL0F1dGhNb2RhbC50c3gnLFxuICAgICcvc3JjL2NvbXBvbmVudHMvU2V0dGluZ3NNb2RhbC50c3gnLFxuICAgICcvc3JjL2NvbXBvbmVudHMvTWFzdGVyQWRtaW5WaWV3LnRzeCcsXG4gICAgJy9zcmMvY29tcG9uZW50cy9Xb3JrZmxvd0d1aWRlVmlldy50c3gnXG4gIF07XG5cbiAgbGV0IGNvbXBsZXRlZCA9IDA7XG4gIGZvciAoY29uc3QgZmlsZVBhdGggb2Ygc291cmNlRmlsZXMpIHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgY2xlYW5QYXRoID0gZmlsZVBhdGguc3RhcnRzV2l0aCgnLycpID8gZmlsZVBhdGguc2xpY2UoMSkgOiBmaWxlUGF0aDtcbiAgICAgIGlmIChvblByb2dyZXNzKSB7XG4gICAgICAgIG9uUHJvZ3Jlc3MoTWF0aC5yb3VuZCgoY29tcGxldGVkIC8gc291cmNlRmlsZXMubGVuZ3RoKSAqIDEwMCksIGNsZWFuUGF0aCk7XG4gICAgICB9XG4gICAgICBcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKGZpbGVQYXRoKTtcbiAgICAgIGlmIChyZXMub2spIHtcbiAgICAgICAgY29uc3QgdGV4dCA9IGF3YWl0IHJlcy50ZXh0KCk7XG4gICAgICAgIHppcC5maWxlKGNsZWFuUGF0aCwgdGV4dCk7XG4gICAgICB9XG4gICAgfSBjYXRjaCB7XG4gICAgICAvLyBDb250aW51ZSBidW5kbGluZ1xuICAgIH1cbiAgICBjb21wbGV0ZWQrKztcbiAgfVxuXG4gIGlmIChvblByb2dyZXNzKSB7XG4gICAgb25Qcm9ncmVzcygxMDAsICdDb21wcmVzc2luZyBhcmNoaXZlLi4uJyk7XG4gIH1cblxuICBjb25zdCBjb250ZW50ID0gYXdhaXQgemlwLmdlbmVyYXRlQXN5bmMoe1xuICAgIHR5cGU6ICdibG9iJyxcbiAgICBjb21wcmVzc2lvbjogJ0RFRkxBVEUnLFxuICAgIGNvbXByZXNzaW9uT3B0aW9uczogeyBsZXZlbDogOSB9XG4gIH0pO1xuXG4gIHJldHVybiBjb250ZW50O1xufVxuXG5leHBvcnQgZnVuY3Rpb24gdHJpZ2dlckRvd25sb2FkWmlwKGJsb2I6IEJsb2IsIGZpbGVuYW1lID0gJ011emFtbWlsLU9ubGluZS1TZXJ2aWNlLUNvbXBsZXRlLVNvdXJjZS56aXAnKSB7XG4gIGNvbnN0IHVybCA9IFVSTC5jcmVhdGVPYmplY3RVUkwoYmxvYik7XG4gIGNvbnN0IGEgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdhJyk7XG4gIGEuaHJlZiA9IHVybDtcbiAgYS5kb3dubG9hZCA9IGZpbGVuYW1lO1xuICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKGEpO1xuICBhLmNsaWNrKCk7XG4gIGRvY3VtZW50LmJvZHkucmVtb3ZlQ2hpbGQoYSk7XG4gIHNldFRpbWVvdXQoKCkgPT4gVVJMLnJldm9rZU9iamVjdFVSTCh1cmwpLCA1MDAwKTtcbn1cbiJdfQ==