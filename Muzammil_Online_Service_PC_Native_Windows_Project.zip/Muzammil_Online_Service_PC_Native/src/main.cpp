#define UNICODE
#define _UNICODE
#include <windows.h>
#include <shellapi.h>
#include <string>
#include <vector>
#include <fstream>

#pragma comment(lib, "user32.lib")
#pragma comment(lib, "gdi32.lib")
#pragma comment(lib, "shell32.lib")

static const wchar_t* APP = L"Muzammil Online Service";
static HWND hMain, hList, hContent, hStatus;
static HBRUSH hBg, hPanel, hCard;
static HFONT fTitle, fNav, fBody;

struct Item { const wchar_t* name; const wchar_t* desc; };
static Item items[] = {
    {L"Dashboard", L"All services at a glance"},
    {L"Passport Size Photo", L"Photo crop, print layout and save"},
    {L"PVC Card", L"4x6 inch • 8.5 x 5.5 cm • 2 cards"},
    {L"PDF to JPG", L"High quality conversion with Python engine"},
    {L"PDF Tools", L"Merge, split and print PDF files"},
    {L"CV / Bio Data", L"A4 CV and bio-data maker"},
    {L"Banner Maker", L"Create service banners and posters"},
    {L"Bill / Receipt", L"Paid and pending bill receipts"},
    {L"Government Services", L"Aadhaar • PAN • Voter • e-Shram • ABHA"},
    {L"Maharashtra Schemes", L"MahaSarathi • state services and schemes"},
    {L"Central Schemes", L"PM Kisan • PM Solar • PM Mudra • PM Awas"},
    {L"Banking Services", L"Banking and assisted service shortcuts"},
    {L"Settings", L"Printer, folders, theme and application settings"}
};

void SetFont(HWND h, HFONT f){ SendMessageW(h, WM_SETFONT, (WPARAM)f, TRUE); }
void SetText(HWND h, const std::wstring& s){ SetWindowTextW(h, s.c_str()); }
void Status(const std::wstring& s){ SetText(hStatus, s); }

void OpenFile(){
    OPENFILENAMEW ofn{}; wchar_t file[4096]{};
    ofn.lStructSize=sizeof(ofn); ofn.hwndOwner=hMain; ofn.lpstrFile=file; ofn.nMaxFile=4096;
    ofn.lpstrFilter=L"All supported files\0*.pdf;*.jpg;*.jpeg;*.png\0PDF files\0*.pdf\0Images\0*.jpg;*.jpeg;*.png\0All files\0*.*\0";
    ofn.Flags=OFN_FILEMUSTEXIST|OFN_PATHMUSTEXIST;
    if(GetOpenFileNameW(&ofn)) Status(std::wstring(L"Selected: ")+file);
}
void RunPortal(const wchar_t* url){ ShellExecuteW(hMain,L"open",url,nullptr,nullptr,SW_SHOWNORMAL); }
void PaintCard(HDC dc, RECT r, const wchar_t* title, const wchar_t* desc){
    HBRUSH old=(HBRUSH)SelectObject(dc,hCard); RoundRect(dc,r.left,r.top,r.right,r.bottom,18,18); SelectObject(dc,old);
    SetBkMode(dc,TRANSPARENT); SetTextColor(dc,RGB(235,242,255));
    RECT a{r.left+18,r.top+15,r.right-18,r.top+45}; DrawTextW(dc,title,-1,&a,DT_LEFT|DT_SINGLELINE);
    SetTextColor(dc,RGB(165,181,205)); RECT b{r.left+18,r.top+48,r.right-18,r.bottom-12}; DrawTextW(dc,desc,-1,&b,DT_WORDBREAK);
}

void RenderContent(int idx){
    InvalidateRect(hContent,nullptr,TRUE);
    if(idx==1) Status(L"Passport Size Photo: choose an image, crop and prepare print layout.");
    else if(idx==2) Status(L"PVC Card: 4x6 layout with two 8.5 x 5.5 cm cards.");
    else if(idx==3) Status(L"PDF to JPG: select a PDF to start high-quality conversion.");
    else Status(items[idx].desc);
}

LRESULT CALLBACK WndProc(HWND w, UINT m, WPARAM wp, LPARAM lp){
    switch(m){
    case WM_CREATE:{
        hBg=CreateSolidBrush(RGB(8,18,35)); hPanel=CreateSolidBrush(RGB(12,28,51)); hCard=CreateSolidBrush(RGB(19,39,67));
        fTitle=CreateFontW(30,0,0,0,FW_BOLD,FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,CLEARTYPE_QUALITY,DEFAULT_PITCH,L"Segoe UI");
        fNav=CreateFontW(16,0,0,0,FW_SEMIBOLD,FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,CLEARTYPE_QUALITY,DEFAULT_PITCH,L"Segoe UI");
        fBody=CreateFontW(14,0,0,0,FW_NORMAL,FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,CLEARTYPE_QUALITY,DEFAULT_PITCH,L"Segoe UI");
        hList=CreateWindowW(L"LISTBOX",nullptr,WS_CHILD|WS_VISIBLE|LBS_NOTIFY|WS_VSCROLL|LBS_NOINTEGRALHEIGHT,20,95,280,500,w,(HMENU)1001,GetModuleHandleW(nullptr),nullptr); SetFont(hList,fNav);
        for(auto &it:items) SendMessageW(hList,LB_ADDSTRING,0,(LPARAM)it.name);
        SendMessageW(hList,LB_SETCURSEL,0,0);
        hContent=CreateWindowW(L"STATIC",nullptr,WS_CHILD|WS_VISIBLE,325,95,900,520,w,(HMENU)1002,GetModuleHandleW(nullptr),nullptr); SetFont(hContent,fBody);
        hStatus=CreateWindowW(L"STATIC",L"Ready",WS_CHILD|WS_VISIBLE,20,640,1200,30,w,(HMENU)1003,GetModuleHandleW(nullptr),nullptr); SetFont(hStatus,fBody);
        CreateWindowW(L"BUTTON",L"Open File",WS_CHILD|WS_VISIBLE|BS_PUSHBUTTON,325,610,120,34,w,(HMENU)2001,GetModuleHandleW(nullptr),nullptr);
        CreateWindowW(L"BUTTON",L"Open Portal",WS_CHILD|WS_VISIBLE|BS_PUSHBUTTON,455,610,130,34,w,(HMENU)2002,GetModuleHandleW(nullptr),nullptr);
        SetFont(GetDlgItem(w,2001),fBody); SetFont(GetDlgItem(w,2002),fBody);
        return 0;}
    case WM_COMMAND:
        if(LOWORD(wp)==1001 && HIWORD(wp)==LBN_SELCHANGE){ int i=(int)SendMessageW(hList,LB_GETCURSEL,0,0); if(i>=0) RenderContent(i); return 0; }
        if(LOWORD(wp)==2001){ OpenFile(); return 0; }
        if(LOWORD(wp)==2002){ RunPortal(L"https://www.india.gov.in/"); return 0; }
        return 0;
    case WM_CTLCOLORSTATIC:{ HDC dc=(HDC)wp; SetBkColor(dc,RGB(8,18,35)); SetTextColor(dc,RGB(220,230,245)); return (LRESULT)hBg; }
    case WM_ERASEBKGND: return 1;
    case WM_PAINT:{ PAINTSTRUCT ps; HDC dc=BeginPaint(w,&ps); RECT rc; GetClientRect(w,&rc); FillRect(dc,&rc,hBg);
        SetBkMode(dc,TRANSPARENT); SetTextColor(dc,RGB(245,249,255)); SetFont(w,fTitle); RECT t{20,20,1000,65}; DrawTextW(dc,APP,-1,&t,DT_LEFT|DT_SINGLELINE);
        SetTextColor(dc,RGB(145,165,195)); RECT sub{22,62,1100,90}; DrawTextW(dc,L"Professional Windows desktop application",-1,&sub,DT_LEFT|DT_SINGLELINE);
        RECT cr{325,95,1225,590}; PaintCard(dc,cr,items[SendMessageW(hList,LB_GETCURSEL,0,0)].name,items[SendMessageW(hList,LB_GETCURSEL,0,0)].desc);
        EndPaint(w,&ps); return 0; }
    case WM_DESTROY: PostQuitMessage(0); return 0;
    }
    return DefWindowProcW(w,m,wp,lp);
}

int WINAPI wWinMain(HINSTANCE h, HINSTANCE, PWSTR, int n){
    WNDCLASSW wc{}; wc.lpfnWndProc=WndProc; wc.hInstance=h; wc.lpszClassName=L"MuzammilNativePC"; wc.hCursor=LoadCursor(nullptr,IDC_ARROW); wc.hbrBackground=CreateSolidBrush(RGB(8,18,35)); RegisterClassW(&wc);
    hMain=CreateWindowExW(0,wc.lpszClassName,APP,WS_OVERLAPPEDWINDOW|WS_CLIPCHILDREN,CW_USEDEFAULT,CW_USEDEFAULT,1280,730,nullptr,nullptr,h,nullptr);
    ShowWindow(hMain,n); UpdateWindow(hMain);
    MSG msg; while(GetMessageW(&msg,nullptr,0,0)){ TranslateMessage(&msg); DispatchMessageW(&msg);} return (int)msg.wParam;
}
