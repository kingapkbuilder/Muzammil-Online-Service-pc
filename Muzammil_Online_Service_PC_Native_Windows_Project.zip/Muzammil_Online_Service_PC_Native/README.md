# Muzammil Online Service — Native Windows Edition

This is a real Windows desktop application, not a browser/WebView wrapper.

## Architecture
- Native C++ Win32 desktop UI
- Python/PyMuPDF worker for high-quality PDF → JPG conversion
- Inno Setup installer for normal Windows installation/uninstallation
- GitHub Actions builds the Windows EXE and Setup EXE

## Install experience
The generated `Muzammil-Online-Service-Setup.exe` installs to Program Files, creates Desktop and Start Menu shortcuts, registers an uninstaller, and can launch the app after installation.

## Planned modules
Dashboard, Passport Size Photo, PVC Card 4x6 (8.5x5.5 cm), PDF→JPG 300 DPI, PDF tools, CV/Bio Data, Banner Maker, Bill/Receipt, Government Services, Maharashtra Schemes, Central Schemes, Banking Services, Settings.
