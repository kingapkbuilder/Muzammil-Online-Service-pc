# Mobile se Windows Setup EXE banana

1. Is ZIP ko extract karo.
2. GitHub repository kholo.
3. Is ZIP ke andar ki saari files repository ke root mein upload karo.
4. `.github/workflows/build-windows.yml` bhi upload hona chahiye.
5. GitHub -> Actions -> Build Windows Setup EXE.
6. Run workflow dabao.
7. Green check ke baad workflow ke Artifacts mein `Muzammil-Online-Service-PC-Setup` download karo.
8. Artifact ZIP ke andar Windows Setup `.exe` milega.

Build sirf NSIS Setup EXE banata hai; portable target nahi hai.
Existing source/UI/server files ko intentionally preserve kiya gaya hai.
