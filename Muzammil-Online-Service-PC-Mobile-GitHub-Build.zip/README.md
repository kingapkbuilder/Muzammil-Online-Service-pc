# Muzammil Online Service PC

Windows installer build for Muzammil Online Service & Xerox.

- Installer only (NSIS)
- No portable build
- App opens to the existing login screen
- `server.ts` is intentionally unchanged
- GitHub Actions builds `*-Setup.exe`
