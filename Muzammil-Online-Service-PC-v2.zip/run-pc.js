/**
 * MUZAMMIL ONLINE SERVICE PC - WORKSTATION V2.0
 * Standalone Node.js Runner Script
 * 
 * Usage:
 *   node run-pc.js
 */

import { spawn } from 'child_process';
import { existsSync } from 'fs';
import { createServer } from 'http';

console.log('====================================================');
console.log('  MUZAMMIL ONLINE SERVICE PC - WORKSTATION V2.0');
console.log('  Local Node.js Workstation Engine Initializing...');
console.log('====================================================');

// Check node_modules
if (!existsSync('./node_modules')) {
  console.log('[INFO] First time setup detected! Installing dependencies...');
  const install = spawn('npm', ['install', '--legacy-peer-deps'], { stdio: 'inherit', shell: true });
  install.on('close', (code) => {
    if (code === 0) {
      startApp();
    } else {
      console.error('[ERROR] Failed to install packages. Code:', code);
    }
  });
} else {
  startApp();
}

function startApp() {
  console.log('[INFO] Launching Workstation Server on port 3000...');
  
  // Launch vite dev / server
  const server = spawn('npm', ['run', 'dev'], { stdio: 'inherit', shell: true });

  // Auto-launch browser after 3 seconds
  setTimeout(() => {
    console.log('[INFO] Opening browser at http://localhost:3000');
    const startCmd = process.platform === 'win32' ? 'start' : process.platform === 'darwin' ? 'open' : 'xdg-open';
    spawn(startCmd, ['http://localhost:3000'], { shell: true });
  }, 3000);

  server.on('close', (code) => {
    console.log('[INFO] Server stopped with code:', code);
  });
}
