import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, 
  Lock, 
  Unlock, 
  Smartphone, 
  Laptop, 
  RotateCcw, 
  UserPlus, 
  Trash2, 
  Download, 
  CheckCircle2, 
  AlertCircle, 
  Clock, 
  Key, 
  FileCode, 
  Layers, 
  Check, 
  Archive,
  RefreshCw,
  Cpu,
  Monitor,
  ClipboardList,
  Sparkles,
  Circle,
  HelpCircle,
  Activity,
  Radio,
  Power,
  MessageSquare,
  Send,
  Calendar,
  AlertTriangle,
  Wifi,
  Globe,
  Copy,
  Terminal,
  ExternalLink,
  FileText
} from 'lucide-react';
import { OperatorAccount, ShopSettings, LiveOperatorSession } from '../types';
import { 
  getRegisteredOperators, 
  resetOperatorPcBinding,
  resetOperatorMobileBinding,
  resetOperatorAllBindings,
  toggleOperatorLock, 
  addNewOperator, 
  deleteOperator,
  getSecurityAuditLogs,
  SecurityAuditLog,
  getHardwareDeviceId,
  getHardwareDeviceName,
  isMobileDevice,
  renewOperatorLicense,
  calculateRemainingDays,
  getLiveOperatorSessions,
  forceDisconnectOperator,
  sendOperatorBroadcastMessage
} from '../utils/deviceSecurity';
import { generateProjectZip, triggerDownloadZip } from '../utils/projectZip';

interface MasterAdminViewProps {
  settings: ShopSettings;
  onUpdateSettings: (settings: ShopSettings) => void;
  onNavigateToWorkflow?: () => void;
}

interface WorkflowStep {
  stepNumber: number;
  title: string;
  description: string;
  toolsUsed: string[];
  checklist: string[];
  tips: string;
}

const MASTER_WORKFLOW_STEPS: WorkflowStep[] = [
  {
    stepNumber: 1,
    title: 'Customer Intake & Service Identification',
    description: 'Welcome citizen, verify Aadhaar linked mobile, check document prerequisites, and quote transparent rates.',
    toolsUsed: ['Dashboard', '50+ Govt Portals Hub', 'AI Assistant'],
    checklist: [
      'Check customer Aadhaar & active mobile OTP availability',
      'Inform customer of official portal charges + service fee',
      'Record customer name & WhatsApp number in CRM',
      'Issue physical or digital queue token'
    ],
    tips: 'Aadhaar mein active mobile number hona PM-KISAN, Ladki Bahin, aur Mahadbt schemes ke liye anivarya hai.'
  },
  {
    stepNumber: 2,
    title: 'Official Portal Filing & Document Submission',
    description: 'Log into central/state portal (Aaple Sarkar, Sarathi, Mahadbt), complete form entry, and submit.',
    toolsUsed: ['50+ Govt Portals Directory', 'PDF to HD JPG Converter'],
    checklist: [
      'Enter applicant details matching Aadhaar letter by letter',
      'If portal requires JPG under 100KB, use PDF to JPG tool to compress documents',
      'Verify uploaded certificate previews before final submission',
      'Download and save official acknowledgement PDF'
    ],
    tips: 'Acknowledgement Receipt Token Number hamesha download karke Customer CRM mein note karein.'
  },
  {
    stepNumber: 3,
    title: 'Studio Photo & PVC Smart Card Processing',
    description: 'Produce high-precision CR-80 PVC cards or 35x45mm passport photo sheets.',
    toolsUsed: ['PVC Smart Card Maker', 'Passport Photo Studio Pro'],
    checklist: [
      'Passport Photo: Select 4×6 Landscape (8 Copies @ 300 DPI) or A4 Landscape',
      'Background: Use Connected Magic Wand or Pen Tool to cut out person and set White/Studio Blue BG',
      'Auto Beauty: Apply AI Face Smoothing to brighten skin tones and reduce camera shadows',
      'Exam Strip: Add Candidate Name & Date stamp for SSC GD, Police Bharti, or Railway forms',
      'PVC Card: Align Front & Back cards to standard CR-80 (85.6×54mm) with center cut guide line'
    ],
    tips: 'PVC Card print karte waqt printer properties mein "High Quality Glossy Photo Paper" select karein.'
  },
  {
    stepNumber: 4,
    title: '300 DPI Physical Printing & Thermal Lamination',
    description: 'Execute in-app borderless printing on photo paper, cut cards, and laminate.',
    toolsUsed: ['In-App Direct Print Engine (Ctrl + P)'],
    checklist: [
      'Load 4×6 inch (10×15 cm) Glossy Photo Paper into printer',
      'Press "🖨️ Direct Print Sheet (Ctrl + P)" directly inside studio',
      'Cut along pre-aligned guide marks',
      'For PVC Smart Cards: Pass through thermal laminator for durable waterproof finish'
    ],
    tips: 'In-app direct print zero popup blocker ke saath seedha connected printer par 300 DPI job bhejta hai.'
  },
  {
    stepNumber: 5,
    title: 'POS Billing & Thermal Receipt Generation',
    description: 'Generate itemized tax invoice or 58mm/80mm thermal slip with dynamic UPI QR code.',
    toolsUsed: ['Fast Billing Desk POS'],
    checklist: [
      'Select service package (e.g. PVC Card ₹70, Passport Photo 8-copies ₹50, Online Form ₹100)',
      'Display dynamic UPI QR code on screen for instant customer payment',
      'Print 58mm thermal receipt or A4 official tax invoice for customer records',
      'Update payment status as "Paid" in ledger'
    ],
    tips: 'Thermal receipt par shop ka authorized signature aur non-refundable portal terms automatic aate hain.'
  },
  {
    stepNumber: 6,
    title: 'Customer Handover & Daily Cash Reconciliation',
    description: 'Hand over laminated cards, passport photos in sleeve, and portal acknowledgement.',
    toolsUsed: ['Customer CRM & Job Tracker'],
    checklist: [
      'Hand over laminated cards, passport photos in sleeve, and portal acknowledgement',
      'Send WhatsApp confirmation with status update',
      'Mark job as "Delivered" in CRM Tracker',
      'Daily reconciliation: Check total cash + UPI collections in Billing Desk Summary'
    ],
    tips: 'Din ke end par Daily Ledger Summary se cash counter balance match karein.'
  }
];

export const MasterAdminView: React.FC<MasterAdminViewProps> = ({
  settings,
  onUpdateSettings,
  onNavigateToWorkflow
}) => {
  const [operators, setOperators] = useState<OperatorAccount[]>([]);
  const [auditLogs, setAuditLogs] = useState<SecurityAuditLog[]>([]);
  const [activeSubTab, setActiveSubTab] = useState<'live_monitor' | 'operators' | 'workflow' | 'zip_download' | 'logs' | 'settings'>('live_monitor');

  // Live Monitoring State
  const [liveSessions, setLiveSessions] = useState<LiveOperatorSession[]>([]);
  const [isAutoRefreshing, setIsAutoRefreshing] = useState<boolean>(true);
  const [lastRefreshedAt, setLastRefreshedAt] = useState<string>('');

  // Renewal Modal State
  const [selectedOpForRenew, setSelectedOpForRenew] = useState<OperatorAccount | null>(null);
  const [renewDaysCount, setRenewDaysCount] = useState<number>(30);

  // Broadcast Alert Modal
  const [broadcastTargetUsername, setBroadcastTargetUsername] = useState<string | null>(null);
  const [broadcastMessageText, setBroadcastMessageText] = useState<string>('');

  // New Operator Modal State
  const [showAddModal, setShowAddModal] = useState<boolean>(false);
  const [newUsername, setNewUsername] = useState<string>('');
  const [newPassword, setNewPassword] = useState<string>('');
  const [newDisplayName, setNewDisplayName] = useState<string>('');
  const [newPhone, setNewPhone] = useState<string>('');
  const [addError, setAddError] = useState<string>('');

  // Project ZIP Export State
  const [isExportingZip, setIsExportingZip] = useState<boolean>(false);
  const [zipProgress, setZipProgress] = useState<{ percent: number; file: string }>({ percent: 0, file: '' });

  // 3 Files Hub - Copy feedback & Modal viewers
  const [copiedWorkflow, setCopiedWorkflow] = useState<boolean>(false);
  const [copiedPcBatch, setCopiedPcBatch] = useState<boolean>(false);
  const [copiedExeBatch, setCopiedExeBatch] = useState<boolean>(false);
  const [copiedPcNode, setCopiedPcNode] = useState<boolean>(false);
  const [expandedFileCard, setExpandedFileCard] = useState<'workflow' | 'pc_batch' | 'exe_batch' | 'pc_node' | null>(null);

  // Notifications
  const [alertMessage, setAlertMessage] = useState<string | null>(null);

  // Shop Settings Form
  const [shopForm, setShopForm] = useState<ShopSettings>(settings);

  // Workflow Checklist state inside Master Admin
  const [completedSteps, setCompletedSteps] = useState<Record<number, boolean>>({});

  const currentDeviceId = getHardwareDeviceId();
  const currentDeviceName = getHardwareDeviceName();
  const currentIsMobile = isMobileDevice();

  const loadData = () => {
    setOperators(getRegisteredOperators());
    setAuditLogs(getSecurityAuditLogs());
  };

  const refreshLiveSessions = async () => {
    try {
      const sessions = await getLiveOperatorSessions();
      setLiveSessions(sessions);
      setLastRefreshedAt(new Date().toLocaleTimeString());
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    loadData();
    refreshLiveSessions();
  }, []);

  // Real-Time 3.5s Live Polling Heartbeat
  useEffect(() => {
    if (!isAutoRefreshing) return;
    const interval = setInterval(() => {
      refreshLiveSessions();
    }, 3500);
    return () => clearInterval(interval);
  }, [isAutoRefreshing]);

  // Handle License / Access Renewal
  const handleExecuteRenewal = () => {
    if (!selectedOpForRenew) return;
    const result = renewOperatorLicense(selectedOpForRenew.id, renewDaysCount);
    if (result.success) {
      loadData();
      refreshLiveSessions();
      setAlertMessage(`✅ Access Renewed for "${selectedOpForRenew.displayName}"! Valid until ${result.newExpiry} (${result.daysLeft} days remaining)`);
      setSelectedOpForRenew(null);
      setTimeout(() => setAlertMessage(null), 5000);
    }
  };

  // Handle Force Disconnect Live Session
  const handleForceDisconnect = async (username: string, deviceId?: string) => {
    if (window.confirm(`Force terminate active session for @${username}? Operator will be immediately logged out.`)) {
      await forceDisconnectOperator(username, deviceId);
      refreshLiveSessions();
      setAlertMessage(`🚨 Session for @${username} has been forcefully terminated.`);
      setTimeout(() => setAlertMessage(null), 4000);
    }
  };

  // Handle Send In-App Broadcast Alert
  const handleSendBroadcast = async () => {
    if (!broadcastTargetUsername || !broadcastMessageText.trim()) return;
    await sendOperatorBroadcastMessage(broadcastTargetUsername, broadcastMessageText.trim());
    setAlertMessage(`📢 Alert message sent to @${broadcastTargetUsername}!`);
    setBroadcastTargetUsername(null);
    setBroadcastMessageText('');
    setTimeout(() => setAlertMessage(null), 4000);
  };

  // Handle Reset PC Binding
  const handleResetPc = (operatorId: string, username: string) => {
    if (window.confirm(`Reset PC Device Binding for "${username}"? Operator can now log in on a new PC/Laptop.`)) {
      resetOperatorPcBinding(operatorId);
      loadData();
      refreshLiveSessions();
      setAlertMessage(`✅ PC device binding cleared for ${username}. Operator can bind a new PC.`);
      setTimeout(() => setAlertMessage(null), 4000);
    }
  };

  // Handle Reset Mobile Binding
  const handleResetMobile = (operatorId: string, username: string) => {
    if (window.confirm(`Reset Mobile Device Binding for "${username}"? Operator can now log in on a new Smartphone.`)) {
      resetOperatorMobileBinding(operatorId);
      loadData();
      refreshLiveSessions();
      setAlertMessage(`✅ Mobile device binding cleared for ${username}. Operator can bind a new phone.`);
      setTimeout(() => setAlertMessage(null), 4000);
    }
  };

  // Handle Reset All Devices (PC + Mobile)
  const handleResetAllDevices = (operatorId: string, username: string) => {
    if (window.confirm(`Reset BOTH PC & Mobile bindings for "${username}"?`)) {
      resetOperatorAllBindings(operatorId);
      loadData();
      refreshLiveSessions();
      setAlertMessage(`✅ All device bindings (PC & Mobile) cleared for ${username}.`);
      setTimeout(() => setAlertMessage(null), 4000);
    }
  };

  // Handle Toggle Lock
  const handleToggleLock = (operatorId: string, username: string) => {
    toggleOperatorLock(operatorId);
    loadData();
    refreshLiveSessions();
    setAlertMessage(`Lock status updated for ${username}`);
    setTimeout(() => setAlertMessage(null), 3000);
  };

  // Handle Delete Operator
  const handleDeleteOperator = (operatorId: string, username: string) => {
    if (window.confirm(`Permanently delete operator account "${username}"?`)) {
      deleteOperator(operatorId);
      loadData();
      refreshLiveSessions();
      setAlertMessage(`Operator ${username} deleted`);
      setTimeout(() => setAlertMessage(null), 3000);
    }
  };

  // Handle Add Operator
  const handleCreateOperator = (e: React.FormEvent) => {
    e.preventDefault();
    setAddError('');

    if (!newUsername.trim() || !newPassword.trim() || !newDisplayName.trim()) {
      setAddError('Please fill all required fields');
      return;
    }

    const success = addNewOperator({
      username: newUsername.trim().toLowerCase(),
      password: newPassword.trim(),
      displayName: newDisplayName.trim(),
      role: 'operator',
      phone: newPhone.trim() || '9561460313'
    });

    if (success) {
      setShowAddModal(false);
      setNewUsername('');
      setNewPassword('');
      setNewDisplayName('');
      setNewPhone('');
      loadData();
      refreshLiveSessions();
      setAlertMessage('✅ New Operator ID created! Permitted on 1 Authorized PC + 1 Authorized Mobile.');
      setTimeout(() => setAlertMessage(null), 4000);
    } else {
      setAddError('Username already exists. Please choose another username.');
    }
  };

  // Handle Download Project ZIP
  const handleDownloadZip = async () => {
    setIsExportingZip(true);
    setZipProgress({ percent: 10, file: 'Gathering project source files...' });

    try {
      const zipBlob = await generateProjectZip((percent, file) => {
        setZipProgress({ percent, file });
      });

      triggerDownloadZip(zipBlob, `Muzammil-Online-Service-PC-v2.zip`);
      setAlertMessage('📦 Complete V2 Project Source Code (.ZIP) downloaded successfully!');
      setTimeout(() => setAlertMessage(null), 4000);
    } catch (e: any) {
      console.error(e);
      setAlertMessage('⚠️ Download error: ' + (e?.message || 'Failed to package files. Please try again.'));
      setTimeout(() => setAlertMessage(null), 5000);
    } finally {
      setIsExportingZip(false);
    }
  };

  const WORKFLOW_YAML_CODE = `name: Build Windows Desktop EXE Setup

on:
  push:
    branches: [ main, master ]
  workflow_dispatch:
  release:
    types: [ published ]

jobs:
  build-windows:
    runs-on: ubuntu-latest

    steps:
      - name: Checkout Code
        uses: actions/checkout@v4

      - name: Setup Node.js 20
        uses: actions/setup-node@v4
        with:
          node-version: 20

      - name: Extract ZIP & Prepare Workspace
        run: |
          shopt -s nullglob
          for f in *.zip; do
            echo "Auto-extracting: $f..."
            unzip -o "$f" || true
          done

          for dir in */; do
            if [ -f "\${dir}package.json" ]; then
              echo "Moving \${dir} to root..."
              cp -rf "\${dir}"* . 2>/dev/null || true
            fi
          done

      - name: Install Dependencies
        run: |
          npm install --legacy-peer-deps
          npm install --save-dev electron electron-packager --legacy-peer-deps

      - name: Build Web Application Assets
        run: |
          npm run build

      - name: Package Windows .EXE Application
        run: |
          npx electron-packager . "Muzammil Online service pc" --platform=win32 --arch=x64 --out=dist-exe --overwrite --prune=true

      - name: Compress Executable Folder to ZIP
        run: |
          cd dist-exe
          zip -r ../Muzammil-Online-Service-Windows-x64.zip "Muzammil Online service pc-win32-x64"
          cd ..

      - name: Upload Windows EXE Artifact
        uses: actions/upload-artifact@v4
        with:
          name: Muzammil-Online-Service-Windows-x64
          path: Muzammil-Online-Service-Windows-x64.zip
          retention-days: 30`;

  const PC_LAUNCHER_BAT_CODE = `@echo off
title Muzammil Online service pc
color 0b
echo ========================================================
echo   MUZAMMIL ONLINE SERVICE PC - WORKSTATION v98.0
echo   Starting Local Server and Launching App...
echo ========================================================

:: Check if node_modules exists
if not exist node_modules (
    echo [INFO] First time setup detected! Installing dependencies...
    call npm install
)

:: Launch browser in background after 3 seconds
start "" cmd /c "timeout /t 3 >nul && start http://localhost:3000"

:: Start the application
call npm run dev
pause`;

  const PC_EXE_BUILDER_BAT_CODE = `@echo off
title Muzammil Online service pc - Professional .EXE Setup Builder
color 0a

echo ========================================================
echo   MUZAMMIL ONLINE SERVICE PC - PROFESSIONAL .EXE BUILDER
echo   Building Desktop Application and Windows Installer...
echo ========================================================
echo.

where node >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Node.js is not installed!
    echo Please install Node.js from https://nodejs.org
    pause
    exit /b
)

echo [1/4] Installing necessary build packages...
call npm install
call npm install --save-dev electron electron-packager electron-builder

echo [2/4] Building high-performance production assets...
call npm run build

echo [3/4] Packaging standalone Windows Executable (.exe)...
call npx electron-packager . "Muzammil Online service pc" --platform=win32 --arch=x64 --out=dist-exe --overwrite --icon=public/favicon.ico

echo.
echo ========================================================
echo   SUCCESS! Windows Desktop Software is Ready!
echo   Folder: dist-exe\\Muzammil Online service pc-win32-x64\\
echo   Executable: "Muzammil Online service pc.exe"
echo ========================================================
echo.
explorer "dist-exe\\Muzammil Online service pc-win32-x64"
pause`;

  const PC_NODE_JS_CODE = `/**
 * MUZAMMIL ONLINE SERVICE PC - WORKSTATION V2.0
 * Standalone Node.js Runner Script
 * 
 * Usage:
 *   node run-pc.js
 */

import { spawn } from 'child_process';
import { existsSync } from 'fs';

console.log('====================================================');
console.log('  MUZAMMIL ONLINE SERVICE PC - WORKSTATION V2.0');
console.log('  Local Node.js Workstation Engine Initializing...');
console.log('====================================================');

if (!existsSync('./node_modules')) {
  console.log('[INFO] First time setup detected! Installing dependencies...');
  const install = spawn('npm', ['install', '--legacy-peer-deps'], { stdio: 'inherit', shell: true });
  install.on('close', (code) => {
    if (code === 0) startApp();
    else console.error('[ERROR] Failed to install packages. Code:', code);
  });
} else {
  startApp();
}

function startApp() {
  console.log('[INFO] Launching Workstation Server on port 3000...');
  const server = spawn('npm', ['run', 'dev'], { stdio: 'inherit', shell: true });

  setTimeout(() => {
    console.log('[INFO] Opening browser at http://localhost:3000');
    const startCmd = process.platform === 'win32' ? 'start' : process.platform === 'darwin' ? 'open' : 'xdg-open';
    spawn(startCmd, ['http://localhost:3000'], { shell: true });
  }, 3000);

  server.on('close', (code) => {
    console.log('[INFO] Server stopped with code:', code);
  });
}`;

  // Download Workflow YML
  const handleDownloadWorkflowYml = () => {
    const blob = new Blob([WORKFLOW_YAML_CODE], { type: 'text/yaml' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'build-windows-exe.yml';
    a.click();
    URL.revokeObjectURL(url);
    setAlertMessage('⚡ GitHub Actions workflow file "build-windows-exe.yml" downloaded!');
    setTimeout(() => setAlertMessage(null), 3000);
  };

  // Download PC Launcher BAT
  const handleDownloadPcLauncher = () => {
    const blob = new Blob([PC_LAUNCHER_BAT_CODE], { type: 'application/x-bat' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'START-WORKSTATION.bat';
    a.click();
    URL.revokeObjectURL(url);
    setAlertMessage('💻 PC Launcher file "START-WORKSTATION.bat" downloaded!');
    setTimeout(() => setAlertMessage(null), 3000);
  };

  // Download PC EXE Builder BAT
  const handleDownloadExeBuilder = () => {
    const blob = new Blob([PC_EXE_BUILDER_BAT_CODE], { type: 'application/x-bat' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'CREATE-EXE-SETUP.bat';
    a.click();
    URL.revokeObjectURL(url);
    setAlertMessage('🛠️ PC EXE Setup Builder file "CREATE-EXE-SETUP.bat" downloaded!');
    setTimeout(() => setAlertMessage(null), 3000);
  };

  // Copy to clipboard helpers
  const handleCopyWorkflowCode = () => {
    navigator.clipboard.writeText(WORKFLOW_YAML_CODE);
    setCopiedWorkflow(true);
    setAlertMessage('📋 GitHub Actions Workflow YAML code copied to clipboard!');
    setTimeout(() => {
      setCopiedWorkflow(false);
      setAlertMessage(null);
    }, 3000);
  };

  const handleCopyPcBatchCode = () => {
    navigator.clipboard.writeText(PC_LAUNCHER_BAT_CODE);
    setCopiedPcBatch(true);
    setAlertMessage('📋 PC 1-Click Launcher (START-WORKSTATION.bat) code copied to clipboard!');
    setTimeout(() => {
      setCopiedPcBatch(false);
      setAlertMessage(null);
    }, 3000);
  };

  const handleCopyExeBuilderCode = () => {
    navigator.clipboard.writeText(PC_EXE_BUILDER_BAT_CODE);
    setCopiedExeBatch(true);
    setAlertMessage('📋 PC EXE Setup Builder (CREATE-EXE-SETUP.bat) code copied to clipboard!');
    setTimeout(() => {
      setCopiedExeBatch(false);
      setAlertMessage(null);
    }, 3000);
  };

  const handleDownloadPcNode = () => {
    const blob = new Blob([PC_NODE_JS_CODE], { type: 'application/javascript' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'run-pc.js';
    a.click();
    URL.revokeObjectURL(url);
    setAlertMessage('🟢 Node.js Runner Script "run-pc.js" downloaded!');
    setTimeout(() => setAlertMessage(null), 3000);
  };

  const handleCopyPcNodeCode = () => {
    navigator.clipboard.writeText(PC_NODE_JS_CODE);
    setCopiedPcNode(true);
    setAlertMessage('📋 Standalone Node.js Runner script (run-pc.js) copied to clipboard!');
    setTimeout(() => {
      setCopiedPcNode(false);
      setAlertMessage(null);
    }, 3000);
  };

  // Handle Save Shop Settings
  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateSettings(shopForm);
    setAlertMessage('✅ Shop details and configuration saved!');
    setTimeout(() => setAlertMessage(null), 3000);
  };

  const completedWorkflowCount = Object.values(completedSteps).filter(Boolean).length;
  const onlineCount = liveSessions.filter(s => s.isOnline).length;

  return (
    <div className="space-y-4">
      {/* Top Banner */}
      <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-md flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 flex-wrap">
            <h1 className="text-xl font-extrabold text-white flex items-center gap-2">
              <ShieldCheck className="w-6 h-6 text-blue-400" />
              <span>Master Admin Control & Live Monitoring Hub</span>
            </h1>
            <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs px-2.5 py-0.5 rounded-full font-mono font-bold flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              <span>Live: {onlineCount} Active Online</span>
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Real-Time Operator Activity Monitor • License Renewals • Dual-Device PC & Mobile Security • Central Setup
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={handleDownloadZip}
            disabled={isExportingZip}
            className="flex items-center gap-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-extrabold text-xs px-4 py-2.5 rounded-xl shadow-lg shadow-emerald-600/20 transition-all hover:scale-105 disabled:opacity-50"
            title="Download full project source code archive (.zip)"
          >
            <Archive className="w-4 h-4" />
            <span>{isExportingZip ? 'Packing ZIP...' : '📦 Download Project .ZIP'}</span>
          </button>
        </div>
      </div>

      {/* Notifications */}
      {alertMessage && (
        <div className="p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs flex items-center justify-between animate-in fade-in">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
            <span>{alertMessage}</span>
          </div>
          <button onClick={() => setAlertMessage(null)} className="text-emerald-400 hover:text-white">✕</button>
        </div>
      )}

      {/* Sub-Navigation Tabs */}
      <div className="flex items-center gap-1.5 bg-slate-900 border border-slate-800 p-1.5 rounded-xl text-xs font-bold overflow-x-auto">
        <button
          onClick={() => setActiveSubTab('live_monitor')}
          className={`flex items-center gap-1.5 px-4 py-2 rounded-lg transition-all ${
            activeSubTab === 'live_monitor'
              ? 'bg-rose-600 text-white shadow'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Radio className="w-3.5 h-3.5 text-white animate-pulse" />
          <span>🔴 Live Operator Monitor ({onlineCount})</span>
        </button>

        <button
          onClick={() => setActiveSubTab('operators')}
          className={`flex items-center gap-1.5 px-4 py-2 rounded-lg transition-all ${
            activeSubTab === 'operators'
              ? 'bg-blue-600 text-white shadow'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Monitor className="w-3.5 h-3.5" />
          <span>Operator IDs & Locks ({operators.length})</span>
        </button>

        <button
          onClick={() => setActiveSubTab('workflow')}
          className={`flex items-center gap-1.5 px-4 py-2 rounded-lg transition-all ${
            activeSubTab === 'workflow'
              ? 'bg-blue-600 text-white shadow'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <ClipboardList className="w-3.5 h-3.5 text-amber-400" />
          <span>Cyber Cafe Workflow & SOP</span>
        </button>

        <button
          onClick={() => setActiveSubTab('zip_download')}
          className={`flex items-center gap-1.5 px-4 py-2 rounded-lg transition-all ${
            activeSubTab === 'zip_download'
              ? 'bg-blue-600 text-white shadow'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Archive className="w-3.5 h-3.5 text-emerald-400" />
          <span>3 Files Hub (GitHub ZIP • Workflow • PC Files)</span>
        </button>

        <button
          onClick={() => setActiveSubTab('logs')}
          className={`flex items-center gap-1.5 px-4 py-2 rounded-lg transition-all ${
            activeSubTab === 'logs'
              ? 'bg-blue-600 text-white shadow'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Clock className="w-3.5 h-3.5" />
          <span>Security & Device Logs</span>
        </button>

        <button
          onClick={() => setActiveSubTab('settings')}
          className={`flex items-center gap-1.5 px-4 py-2 rounded-lg transition-all ${
            activeSubTab === 'settings'
              ? 'bg-blue-600 text-white shadow'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Key className="w-3.5 h-3.5" />
          <span>Master Setup Center</span>
        </button>
      </div>

      {/* TAB 0: LIVE USER MONITORING & RENEWAL DECK */}
      {activeSubTab === 'live_monitor' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
            <div>
              <h2 className="text-base font-extrabold text-white flex items-center gap-2">
                <Radio className="w-4 h-4 text-rose-500 animate-pulse" />
                <span>Live Operator Activity & Real-Time Pulse</span>
                <span className="text-xs text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20 font-mono">
                  3.5s Live Ping
                </span>
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                See exactly which operator is working on what studio in real-time, their active PC/Mobile, and renew access.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setIsAutoRefreshing(!isAutoRefreshing)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition-colors flex items-center gap-1.5 ${
                  isAutoRefreshing 
                    ? 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30' 
                    : 'bg-slate-800 text-slate-400 border-slate-700'
                }`}
              >
                <Activity className="w-3.5 h-3.5" />
                <span>{isAutoRefreshing ? 'Auto-Update: ON' : 'Paused'}</span>
              </button>

              <button
                onClick={refreshLiveSessions}
                className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs"
                title="Refresh Live Data"
              >
                <RefreshCw className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Live Metric Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs">
            <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-1">
              <span className="text-slate-400 block text-[11px]">Active Staff Online</span>
              <div className="text-2xl font-extrabold text-white font-mono flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping"></span>
                <span>{onlineCount}</span>
              </div>
              <span className="text-[10px] text-emerald-400 font-mono">Live WebSocket Pulse</span>
            </div>

            <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-1">
              <span className="text-slate-400 block text-[11px]">PC Workstations Active</span>
              <div className="text-2xl font-extrabold text-blue-400 font-mono flex items-center gap-2">
                <Laptop className="w-5 h-5" />
                <span>{liveSessions.filter(s => s.deviceType === 'pc' && s.isOnline).length}</span>
              </div>
              <span className="text-[10px] text-slate-400">Desktop Workstations</span>
            </div>

            <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-1">
              <span className="text-slate-400 block text-[11px]">Mobile Handsets Active</span>
              <div className="text-2xl font-extrabold text-purple-400 font-mono flex items-center gap-2">
                <Smartphone className="w-5 h-5" />
                <span>{liveSessions.filter(s => s.deviceType === 'mobile' && s.isOnline).length}</span>
              </div>
              <span className="text-[10px] text-slate-400">Operator Handsets</span>
            </div>

            <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-1">
              <span className="text-slate-400 block text-[11px]">Last Pulse Update</span>
              <div className="text-sm font-bold text-white font-mono mt-1">
                {lastRefreshedAt || 'Connecting...'}
              </div>
              <span className="text-[10px] text-slate-500">Auto Heartbeat</span>
            </div>
          </div>

          {/* Live Sessions Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 uppercase tracking-wider font-semibold">
                  <th className="py-3 px-3">Live Status</th>
                  <th className="py-3 px-3">Operator Name</th>
                  <th className="py-3 px-3">Device / Machine</th>
                  <th className="py-3 px-3">Active Studio / Task</th>
                  <th className="py-3 px-3">License Validity</th>
                  <th className="py-3 px-3 text-right">Admin Control</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-sans">
                {liveSessions.map((session) => {
                  const daysLeft = calculateRemainingDays(session.validityExpiresAt);
                  const isExpiring = daysLeft < 15;

                  return (
                    <tr key={session.sessionId || `${session.username}-${session.deviceId}`} className="hover:bg-slate-950/40 transition-colors">
                      {/* Live Pulse Status */}
                      <td className="py-3 px-3">
                        <div className="flex items-center gap-2">
                          <span className={`w-2.5 h-2.5 rounded-full ${
                            session.isOnline ? 'bg-emerald-400 animate-pulse' : 'bg-slate-600'
                          }`}></span>
                          <span className={`text-[11px] font-bold ${
                            session.isOnline ? 'text-emerald-400' : 'text-slate-500'
                          }`}>
                            {session.isOnline ? 'Active Now' : `${session.lastActiveSecondsAgo || 30}s ago`}
                          </span>
                        </div>
                      </td>

                      {/* Operator Details */}
                      <td className="py-3 px-3">
                        <div className="font-extrabold text-white text-sm">{session.displayName}</div>
                        <div className="text-[11px] text-slate-400 font-mono">@{session.username} • {session.phone || '9561460313'}</div>
                      </td>

                      {/* Device & Hardware */}
                      <td className="py-3 px-3">
                        <div className="flex items-center gap-1.5 font-bold text-slate-300">
                          {session.deviceType === 'mobile' ? (
                            <Smartphone className="w-3.5 h-3.5 text-purple-400" />
                          ) : (
                            <Laptop className="w-3.5 h-3.5 text-blue-400" />
                          )}
                          <span className="font-mono text-[11px]">{session.deviceId}</span>
                        </div>
                        <div className="text-[10px] text-slate-400">{session.deviceName}</div>
                      </td>

                      {/* Current Active Studio */}
                      <td className="py-3 px-3">
                        <span className="px-2.5 py-1 rounded-lg bg-blue-500/10 text-blue-300 border border-blue-500/20 font-bold text-[11px] inline-flex items-center gap-1">
                          <Activity className="w-3 h-3 text-blue-400" />
                          <span>{session.currentTab || 'Workstation Hub'}</span>
                        </span>
                      </td>

                      {/* License Validity & Renewal */}
                      <td className="py-3 px-3">
                        {session.role === 'admin' || session.username === 'admin' ? (
                          <div className="space-y-0.5">
                            <div className="font-extrabold font-mono text-[11px] text-amber-300 flex items-center gap-1">
                              <span>👑 Lifetime Access</span>
                            </div>
                            <div className="text-[10px] text-emerald-400 font-bold">Never Expires (Permanent)</div>
                          </div>
                        ) : (
                          <div className="space-y-0.5">
                            <div className={`font-bold font-mono text-[11px] ${
                              isExpiring ? 'text-rose-400' : 'text-emerald-400'
                            }`}>
                              {daysLeft > 0 ? `${daysLeft} Days Left` : 'Expired'}
                            </div>
                            <div className="text-[10px] text-slate-500">Exp: {session.validityExpiresAt || '2026-12-31'}</div>
                          </div>
                        )}
                      </td>

                      {/* Action buttons */}
                      <td className="py-3 px-3 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {/* Renew Button */}
                          <button
                            onClick={() => {
                              const found = operators.find(o => o.username === session.username);
                              if (found) setSelectedOpForRenew(found);
                            }}
                            className="px-2.5 py-1 rounded-lg bg-emerald-500/10 text-emerald-300 border border-emerald-500/30 hover:bg-emerald-500/20 font-bold text-[10px] flex items-center gap-1 transition-colors"
                            title="Renew License Access"
                          >
                            <Calendar className="w-3 h-3" />
                            <span>Renew</span>
                          </button>

                          {/* Send Message */}
                          <button
                            onClick={() => {
                              setBroadcastTargetUsername(session.username);
                              setBroadcastMessageText('');
                            }}
                            className="p-1 rounded-lg bg-slate-800 text-slate-300 border border-slate-700 hover:text-white"
                            title="Send In-App Toast Message"
                          >
                            <MessageSquare className="w-3 h-3" />
                          </button>

                          {/* Force Disconnect */}
                          <button
                            onClick={() => handleForceDisconnect(session.username, session.deviceId)}
                            className="p-1 rounded-lg bg-rose-500/10 text-rose-400 border border-rose-500/30 hover:bg-rose-500/20"
                            title="Force Disconnect Session"
                          >
                            <Power className="w-3 h-3" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 1: OPERATOR IDS & DUAL-DEVICE (PC + MOBILE) TABLE */}
      {activeSubTab === 'operators' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
            <div>
              <h2 className="text-base font-extrabold text-white flex items-center gap-2">
                <span>Authorized Operators (PC + Mobile Binding)</span>
                <span className="text-xs text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20 font-mono">
                  1 PC + 1 Mobile Per ID
                </span>
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Each operator ID can work on <b>1 authorized PC</b> AND <b>1 authorized Mobile</b> at the same time. Third-party devices are blocked automatically.
              </p>
            </div>

            <button
              onClick={() => setShowAddModal(true)}
              className="flex items-center gap-1.5 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs px-3.5 py-2 rounded-xl shadow transition-all self-start sm:self-auto"
            >
              <UserPlus className="w-4 h-4" />
              <span>Register New Operator ID</span>
            </button>
          </div>

          {/* Current Device Callout */}
          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 text-xs flex items-center justify-between flex-wrap gap-2 text-slate-300">
            <div className="flex items-center gap-2">
              <Cpu className="w-4 h-4 text-blue-400" />
              <span>Your Current Machine ({currentIsMobile ? '📱 Mobile' : '💻 PC'}):</span>
              <code className="text-white font-mono font-bold bg-slate-900 px-2 py-0.5 rounded border border-slate-700">
                {currentDeviceId}
              </code>
            </div>
            <span className="text-slate-400 font-mono text-[11px]">{currentDeviceName}</span>
          </div>

          {/* Operators Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 uppercase tracking-wider font-semibold">
                  <th className="py-3 px-3">Operator / Username</th>
                  <th className="py-3 px-3">Role</th>
                  <th className="py-3 px-3">Authorized PC (1 Max)</th>
                  <th className="py-3 px-3">Authorized Mobile (1 Max)</th>
                  <th className="py-3 px-3">License Status</th>
                  <th className="py-3 px-3 text-right">Device & Renew Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {operators.map((op) => {
                  const daysLeft = calculateRemainingDays(op.validityExpiresAt);

                  return (
                    <tr key={op.id} className="hover:bg-slate-950/40 transition-colors">
                      {/* Operator Name */}
                      <td className="py-3 px-3">
                        <div className="font-bold text-white text-sm">{op.displayName}</div>
                        <div className="text-slate-400 font-mono text-[11px]">@{op.username} • {op.phone}</div>
                      </td>

                      {/* Role */}
                      <td className="py-3 px-3">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase font-mono ${
                          op.role === 'admin'
                            ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30'
                            : 'bg-blue-500/20 text-blue-300 border border-blue-500/30'
                        }`}>
                          {op.role === 'admin' ? 'Master Admin' : 'Operator'}
                        </span>
                      </td>

                      {/* Authorized PC */}
                      <td className="py-3 px-3">
                        {op.boundPcDeviceId ? (
                          <div className="space-y-0.5">
                            <div className="flex items-center gap-1.5 font-bold text-blue-400">
                              <Laptop className="w-3.5 h-3.5 text-blue-400" />
                              <span className="font-mono text-[11px]">{op.boundPcDeviceId}</span>
                            </div>
                            <div className="text-[10px] text-slate-400 truncate max-w-[160px]">{op.boundPcDeviceName || 'PC Workstation'}</div>
                            <button
                              onClick={() => handleResetPc(op.id, op.username)}
                              className="text-[10px] text-amber-400 hover:underline flex items-center gap-0.5 font-bold pt-0.5"
                            >
                              <RotateCcw className="w-2.5 h-2.5" />
                              <span>Reset PC Binding</span>
                            </button>
                          </div>
                        ) : (
                          <span className="text-[10px] text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20 font-medium">
                            Unbound PC (Pending)
                          </span>
                        )}
                      </td>

                      {/* Authorized Mobile */}
                      <td className="py-3 px-3">
                        {op.boundMobileDeviceId ? (
                          <div className="space-y-0.5">
                            <div className="flex items-center gap-1.5 font-bold text-purple-400">
                              <Smartphone className="w-3.5 h-3.5 text-purple-400" />
                              <span className="font-mono text-[11px]">{op.boundMobileDeviceId}</span>
                            </div>
                            <div className="text-[10px] text-slate-400 truncate max-w-[160px]">{op.boundMobileDeviceName || 'Smartphone'}</div>
                            <button
                              onClick={() => handleResetMobile(op.id, op.username)}
                              className="text-[10px] text-amber-400 hover:underline flex items-center gap-0.5 font-bold pt-0.5"
                            >
                              <RotateCcw className="w-2.5 h-2.5" />
                              <span>Reset Mobile Binding</span>
                            </button>
                          </div>
                        ) : (
                          <span className="text-[10px] text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20 font-medium">
                            Unbound Mobile (Pending)
                          </span>
                        )}
                      </td>

                      {/* License Validity */}
                      <td className="py-3 px-3">
                        {op.role === 'admin' ? (
                          <div className="space-y-0.5">
                            <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30 font-bold text-[10px] font-mono flex items-center gap-1 w-fit">
                              <span>👑 Lifetime (Never Expires)</span>
                            </span>
                            <span className="text-[10px] text-emerald-400 font-bold block">Permanent Access</span>
                          </div>
                        ) : (
                          <div className="space-y-1">
                            <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold text-[10px] font-mono flex items-center gap-1 w-fit">
                              <Calendar className="w-3 h-3 text-emerald-400" />
                              <span>{daysLeft} Days Left</span>
                            </span>
                            <button
                              onClick={() => setSelectedOpForRenew(op)}
                              className="text-[10px] text-sky-400 hover:underline font-bold block"
                            >
                              + Renew Access
                            </button>
                          </div>
                        )}
                      </td>

                      {/* Action buttons */}
                      <td className="py-3 px-3 text-right">
                        <div className="flex items-center justify-end gap-1.5 flex-wrap">
                          {/* Reset All Devices Button */}
                          {(op.boundPcDeviceId || op.boundMobileDeviceId) && (
                            <button
                              onClick={() => handleResetAllDevices(op.id, op.username)}
                              className="px-2 py-1 rounded-lg bg-amber-500/10 text-amber-300 border border-amber-500/30 hover:bg-amber-500/20 font-bold text-[10px] transition-colors"
                              title="Reset both PC and Mobile bindings"
                            >
                              Reset All
                            </button>
                          )}

                          {/* Lock / Unlock */}
                          {op.role !== 'admin' && (
                            <button
                              onClick={() => handleToggleLock(op.id, op.username)}
                              className={`p-1.5 rounded-lg border text-xs ${
                                op.isLocked
                                  ? 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30 hover:bg-emerald-500/20'
                                  : 'bg-slate-800 text-slate-400 border-slate-700 hover:text-white'
                              }`}
                              title={op.isLocked ? 'Unlock Operator' : 'Suspend Operator'}
                            >
                              {op.isLocked ? <Unlock className="w-3.5 h-3.5" /> : <Lock className="w-3.5 h-3.5" />}
                            </button>
                          )}

                          {/* Delete Operator */}
                          {op.role !== 'admin' && (
                            <button
                              onClick={() => handleDeleteOperator(op.id, op.username)}
                              className="p-1.5 rounded-lg bg-rose-500/10 text-rose-400 border border-rose-500/20 hover:bg-rose-500/20 text-xs"
                              title="Delete Operator"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 2: CYBER CAFE WORKFLOW & SOP */}
      {activeSubTab === 'workflow' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
            <div>
              <h2 className="text-base font-extrabold text-white flex items-center gap-2">
                <ClipboardList className="w-5 h-5 text-amber-400" />
                <span>Cyber Cafe Standard Operating Procedure (SOP)</span>
                <span className="text-xs text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20 font-mono">
                  Master Workflow
                </span>
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Standardized 6-stage operational protocol for all CSC & Cyber Cafe services
              </p>
            </div>

            <div className="bg-slate-950 px-3 py-1.5 rounded-xl border border-slate-800 text-xs font-mono text-slate-300">
              Checklist: <strong className="text-emerald-400">{completedWorkflowCount} / {MASTER_WORKFLOW_STEPS.length} Completed</strong>
            </div>
          </div>

          {/* Workflow Steps Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {MASTER_WORKFLOW_STEPS.map((step) => {
              const isDone = !!completedSteps[step.stepNumber];
              return (
                <div
                  key={step.stepNumber}
                  className={`p-4 rounded-xl border transition-all space-y-3 ${
                    isDone 
                      ? 'bg-slate-950/60 border-emerald-500/40' 
                      : 'bg-slate-950 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className={`w-6 h-6 rounded-lg flex items-center justify-center font-bold text-xs font-mono ${
                        isDone ? 'bg-emerald-500 text-slate-950' : 'bg-blue-600 text-white'
                      }`}>
                        {step.stepNumber}
                      </span>
                      <h3 className="font-extrabold text-white text-xs">{step.title}</h3>
                    </div>

                    <button
                      onClick={() => setCompletedSteps(prev => ({ ...prev, [step.stepNumber]: !prev[step.stepNumber] }))}
                      className={`flex items-center gap-1 text-[11px] font-bold px-2 py-0.5 rounded-md border ${
                        isDone 
                          ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                          : 'bg-slate-900 text-slate-400 border-slate-700'
                      }`}
                    >
                      {isDone ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> : <Circle className="w-3.5 h-3.5" />}
                      <span>{isDone ? 'Done' : 'Mark'}</span>
                    </button>
                  </div>

                  <p className="text-[11px] text-slate-300 leading-snug">{step.description}</p>

                  <div className="space-y-1 pt-1 border-t border-slate-800/80">
                    {step.checklist.map((item, idx) => (
                      <div key={idx} className="flex items-start gap-1.5 text-[11px] text-slate-400">
                        <span className="text-blue-500">•</span>
                        <span>{item}</span>
                      </div>
                    ))}
                  </div>

                  <div className="p-2 rounded-lg bg-slate-900 text-[10px] text-amber-300/90 flex items-start gap-1.5">
                    <Sparkles className="w-3 h-3 text-amber-400 flex-shrink-0 mt-0.5" />
                    <span><b>Operator Note:</b> {step.tips}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 3: 3 MASTER ADMIN FILES HUB (GITHUB ZIP • WORKFLOW CODE • PC FILES) */}
      {activeSubTab === 'zip_download' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-6">
          {/* Header */}
          <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 pb-4 border-b border-slate-800">
            <div className="flex items-start gap-4">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-emerald-600/20 to-teal-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400 flex-shrink-0 shadow-inner">
                <Archive className="w-7 h-7" />
              </div>
              <div className="space-y-1">
                <h2 className="text-lg font-extrabold text-white flex items-center gap-2 flex-wrap">
                  <span>3 Master Admin Download Files Hub</span>
                  <span className="text-[10px] bg-emerald-500/20 text-emerald-300 font-bold px-2 py-0.5 rounded font-mono border border-emerald-500/30">
                    GitHub & PC Ready
                  </span>
                </h2>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Yahan se aap (1) GitHub-Ready complete project .ZIP, (2) GitHub Actions workflow .YML code, aur (3) PC standalone launcher .BAT files direct 1-click mein download ya copy kar sakte hain.
                </p>
              </div>
            </div>

            <span className="text-[10px] text-slate-400 font-mono bg-slate-950 px-3 py-1.5 rounded-xl border border-slate-800 self-start">
              Workstation v98.0
            </span>
          </div>

          {/* 3 DEDICATED FILE CARDS GRID (V2 SUITE) */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            {/* FILE 1: V2 GITHUB READY PROJECT .ZIP ARCHIVE */}
            <div className="bg-slate-950 border border-emerald-500/40 rounded-2xl p-4 flex flex-col justify-between space-y-3 shadow-lg hover:border-emerald-500/70 transition-all relative overflow-hidden">
              <div className="absolute top-0 right-0 bg-emerald-500 text-slate-950 text-[9px] font-black uppercase tracking-wider px-2 py-0.5 rounded-bl-lg">
                v2.0 Latest
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-sm">
                    1
                  </span>
                  <span className="text-[10px] font-bold text-emerald-300 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                    Full Source ZIP
                  </span>
                </div>

                <h3 className="font-extrabold text-white text-sm">
                  📦 Complete Project V2 .ZIP Archive
                </h3>
                <p className="text-slate-400 text-[11px] leading-relaxed">
                  Sabhi studios (PVC Studio, Passport, Video Studio, Billing POS, CRM, 50+ Portals, Node.js Server, Electron & Workflow) ka complete v2.0 package.
                </p>

                <div className="text-[10px] text-slate-500 font-mono space-y-0.5 bg-slate-900/60 p-2.5 rounded-lg border border-slate-800">
                  <div>File: <b className="text-emerald-400">Muzammil-Online-Service-PC-v2.zip</b></div>
                  <div>Format: <b>Clean ZIP (Deflate Lv9)</b></div>
                  <div>Dest: <b>GitHub / PC Workstation</b></div>
                </div>
              </div>

              <div className="space-y-2 pt-2">
                <button
                  onClick={handleDownloadZip}
                  disabled={isExportingZip}
                  className="w-full flex items-center justify-center gap-1.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-extrabold text-xs py-2.5 rounded-xl shadow transition-all disabled:opacity-50"
                >
                  <Download className="w-4 h-4" />
                  <span>{isExportingZip ? 'Compressing ZIP...' : 'Download V2 Source .ZIP'}</span>
                </button>

                <div className="flex items-center justify-between text-[11px]">
                  <button
                    onClick={handleDownloadZip}
                    disabled={isExportingZip}
                    className="text-emerald-400 hover:text-emerald-300 hover:underline flex items-center gap-1 font-semibold"
                  >
                    <Download className="w-3 h-3" />
                    <span>Instant In-App Download</span>
                  </button>
                  <span className="text-[10px] text-emerald-400 font-mono">v2.0 Verified</span>
                </div>
              </div>
            </div>

            {/* FILE 2: GITHUB ACTIONS WORKFLOW CODE (.YML) */}
            <div className="bg-slate-950 border border-purple-500/40 rounded-2xl p-4 flex flex-col justify-between space-y-3 shadow-lg hover:border-purple-500/70 transition-all relative overflow-hidden">
              <div className="absolute top-0 right-0 bg-purple-500 text-white text-[9px] font-black uppercase tracking-wider px-2 py-0.5 rounded-bl-lg">
                Ubuntu Cloud
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="w-8 h-8 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center font-bold text-sm">
                    2
                  </span>
                  <span className="text-[10px] font-bold text-purple-300 bg-purple-500/10 px-2 py-0.5 rounded border border-purple-500/20">
                    GitHub Actions .YML
                  </span>
                </div>

                <h3 className="font-extrabold text-white text-sm">
                  ⚡ GitHub Workflow Code v2.0 (.YML)
                </h3>
                <p className="text-slate-400 text-[11px] leading-relaxed">
                  GitHub Cloud servers par bina kisi error ke automatic ZIP extract karke standalone Windows <b>.EXE</b> software banane ka automation script.
                </p>

                <div className="text-[10px] text-slate-500 font-mono space-y-0.5 bg-slate-900/60 p-2.5 rounded-lg border border-slate-800">
                  <div>File: <b className="text-purple-400">build-windows-exe.yml</b></div>
                  <div>Target: <b>.github/workflows/</b></div>
                  <div>Output: <b>Muzammil-Online-Service-Windows-x64.zip (.exe)</b></div>
                </div>
              </div>

              <div className="space-y-2 pt-2">
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={handleDownloadWorkflowYml}
                    className="flex items-center justify-center gap-1 bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs py-2 rounded-xl shadow transition-colors"
                    title="Download build-windows-exe.yml"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download .YML</span>
                  </button>

                  <button
                    onClick={handleCopyWorkflowCode}
                    className={`flex items-center justify-center gap-1 font-bold text-xs py-2 rounded-xl border transition-colors ${
                      copiedWorkflow 
                        ? 'bg-emerald-600 text-white border-emerald-400' 
                        : 'bg-slate-900 hover:bg-slate-800 text-purple-300 border-purple-500/40 hover:text-white'
                    }`}
                    title="Copy full YAML code to clipboard"
                  >
                    {copiedWorkflow ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedWorkflow ? 'Copied!' : 'Copy Code'}</span>
                  </button>
                </div>

                <div className="flex items-center justify-between text-[11px] pt-0.5">
                  <a
                    href="https://github.com/kingapkbuilder/Muzammil-Online-Service-PC-v1/actions"
                    target="_blank"
                    rel="noreferrer"
                    className="text-purple-400 hover:underline flex items-center gap-1 font-semibold"
                  >
                    <ExternalLink className="w-3 h-3" />
                    <span>Open GitHub Actions</span>
                  </a>

                  <button
                    onClick={() => setExpandedFileCard(expandedFileCard === 'workflow' ? null : 'workflow')}
                    className="text-slate-400 hover:text-purple-300 font-semibold"
                  >
                    {expandedFileCard === 'workflow' ? 'Hide Code' : 'View Code'}
                  </button>
                </div>
              </div>
            </div>

            {/* FILE 3: STANDALONE NODE.JS RUNNER & PC 1-CLICK LAUNCHERS */}
            <div className="bg-slate-950 border border-blue-500/40 rounded-2xl p-4 flex flex-col justify-between space-y-3 shadow-lg hover:border-blue-500/70 transition-all relative overflow-hidden">
              <div className="absolute top-0 right-0 bg-blue-500 text-white text-[9px] font-black uppercase tracking-wider px-2 py-0.5 rounded-bl-lg">
                PC Engine
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="w-8 h-8 rounded-xl bg-blue-500/20 text-blue-400 flex items-center justify-center font-bold text-sm">
                    3
                  </span>
                  <span className="text-[10px] font-bold text-blue-300 bg-blue-500/10 px-2 py-0.5 rounded border border-blue-500/20">
                    Node.js + Windows .BAT
                  </span>
                </div>

                <h3 className="font-extrabold text-white text-sm">
                  🟢 PC Node.js Engine & Launchers
                </h3>
                <p className="text-slate-400 text-[11px] leading-relaxed">
                  PC par bina internet local server start karne wali Node.js script (<b>run-pc.js</b>) aur 1-click desktop batch launcher.
                </p>

                <div className="text-[10px] text-slate-500 font-mono space-y-0.5 bg-slate-900/60 p-2.5 rounded-lg border border-slate-800">
                  <div>File 1: <b className="text-cyan-400">run-pc.js</b> (Node Workstation Engine)</div>
                  <div>File 2: <b className="text-blue-400">START-WORKSTATION.bat</b> (1-Click Run)</div>
                  <div>File 3: <b>CREATE-EXE-SETUP.bat</b> (Local .EXE Builder)</div>
                </div>
              </div>

              <div className="space-y-2 pt-2">
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={handleDownloadPcNode}
                    className="flex items-center justify-center gap-1 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-bold text-xs py-2 rounded-xl shadow transition-colors"
                    title="Download run-pc.js"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download .JS</span>
                  </button>

                  <button
                    onClick={handleDownloadPcLauncher}
                    className="flex items-center justify-center gap-1 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs py-2 rounded-xl shadow transition-colors"
                    title="Download START-WORKSTATION.bat"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download .BAT</span>
                  </button>
                </div>

                <div className="grid grid-cols-2 gap-2 text-[11px] pt-0.5">
                  <button
                    onClick={handleCopyPcNodeCode}
                    className={`flex items-center justify-center gap-1 py-1.5 rounded-lg border text-[11px] font-bold transition-colors ${
                      copiedPcNode
                        ? 'bg-emerald-600 text-white border-emerald-400'
                        : 'bg-slate-900 text-cyan-300 border-cyan-500/30 hover:bg-slate-800'
                    }`}
                    title="Copy run-pc.js Node.js script"
                  >
                    {copiedPcNode ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedPcNode ? 'Copied .JS!' : 'Copy Node.js'}</span>
                  </button>

                  <button
                    onClick={() => setExpandedFileCard(expandedFileCard === 'pc_node' ? null : 'pc_node')}
                    className="text-slate-400 hover:text-cyan-300 font-semibold text-center py-1.5"
                  >
                    {expandedFileCard === 'pc_node' ? 'Hide Code' : 'View Code'}
                  </button>
                </div>

                <div className="flex items-center justify-between text-[11px] pt-1 border-t border-slate-900">
                  <button
                    onClick={handleDownloadExeBuilder}
                    className="text-amber-400 hover:underline flex items-center gap-1 font-semibold text-[10px]"
                    title="Download CREATE-EXE-SETUP.bat"
                  >
                    <Download className="w-2.5 h-2.5" />
                    <span>Get .EXE Builder (.bat)</span>
                  </button>

                  <button
                    onClick={() => setExpandedFileCard(expandedFileCard === 'pc_batch' ? null : 'pc_batch')}
                    className="text-slate-400 hover:text-blue-300 font-semibold text-[10px]"
                  >
                    {expandedFileCard === 'pc_batch' ? 'Hide .BAT' : 'View .BAT Code'}
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* CODE PREVIEW MODAL / EXPANDABLE BOX */}
          {expandedFileCard && (
            <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 space-y-2 animate-in fade-in">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <span className="font-mono text-xs text-white font-bold flex items-center gap-2">
                  <Terminal className="w-4 h-4 text-emerald-400" />
                  <span>
                    {expandedFileCard === 'workflow'
                      ? '.github/workflows/build-windows-exe.yml'
                      : expandedFileCard === 'pc_node'
                      ? 'run-pc.js (Node.js Workstation Engine)'
                      : expandedFileCard === 'exe_batch'
                      ? 'CREATE-EXE-SETUP.bat'
                      : 'START-WORKSTATION.bat'}
                  </span>
                </span>
                <div className="flex items-center gap-2">
                  <button
                    onClick={
                      expandedFileCard === 'workflow'
                        ? handleCopyWorkflowCode
                        : expandedFileCard === 'pc_node'
                        ? handleCopyPcNodeCode
                        : expandedFileCard === 'exe_batch'
                        ? handleCopyExeBuilderCode
                        : handleCopyPcBatchCode
                    }
                    className="px-2.5 py-1 rounded bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white text-[11px] font-bold border border-slate-700 flex items-center gap-1"
                  >
                    <Copy className="w-3 h-3" />
                    <span>Copy Code</span>
                  </button>
                  <button
                    onClick={() => setExpandedFileCard(null)}
                    className="text-slate-400 hover:text-white text-xs px-1"
                  >
                    ✕
                  </button>
                </div>
              </div>
              <pre className="text-[11px] font-mono text-slate-300 max-h-72 overflow-y-auto p-3 bg-slate-900/90 rounded-xl leading-relaxed select-all">
                {expandedFileCard === 'workflow'
                  ? WORKFLOW_YAML_CODE
                  : expandedFileCard === 'pc_node'
                  ? PC_NODE_JS_CODE
                  : expandedFileCard === 'exe_batch'
                  ? PC_EXE_BUILDER_BAT_CODE
                  : PC_LAUNCHER_BAT_CODE}
              </pre>
            </div>
          )}

          {/* Download Progress Bar */}
          {isExportingZip && (
            <div className="space-y-2 p-4 rounded-xl bg-slate-950 border border-emerald-500/30 animate-pulse">
              <div className="flex justify-between text-xs text-emerald-400 font-bold">
                <span>Packing ZIP Archive: {zipProgress.file}</span>
                <span>{zipProgress.percent}%</span>
              </div>
              <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                <div 
                  className="bg-emerald-500 h-full transition-all duration-200" 
                  style={{ width: `${zipProgress.percent}%` }}
                />
              </div>
            </div>
          )}

          {/* STEP-BY-STEP GUIDES FOR GITHUB & PC */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            {/* Guide A: GitHub Actions Se .EXE Banana */}
            <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-3">
              <div className="flex items-center gap-2 text-purple-400 font-extrabold pb-1 border-b border-slate-800">
                <FileCode className="w-4 h-4" />
                <span>GitHub Actions Se .EXE Setup Kaise Banayein:</span>
              </div>
              <ol className="list-decimal list-inside space-y-1.5 text-slate-300 text-[11px] leading-relaxed">
                <li>GitHub par nayi repository banayein: <b>muzammil-online-service</b>.</li>
                <li>Downloaded ZIP ko extract karke saari files GitHub par upload karein.</li>
                <li>GitHub ke <b>"Actions"</b> tab mein jakar <b>"Build Windows Desktop EXE Setup"</b> chunein.</li>
                <li>Right side mein <b>"Run workflow"</b> dabayein — 2 minute mein <b>.EXE Artifact</b> tayar ho jayegi!</li>
              </ol>
            </div>

            {/* Guide B: Direct PC Par Chalana */}
            <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-3">
              <div className="flex items-center gap-2 text-blue-400 font-extrabold pb-1 border-b border-slate-800">
                <Laptop className="w-4 h-4" />
                <span>Direct PC Par Software Kaise Chalayein:</span>
              </div>
              <ol className="list-decimal list-inside space-y-1.5 text-slate-300 text-[11px] leading-relaxed">
                <li>ZIP ko computer ki kisi drive mein extract karein (e.g. <code>D:\MuzammilOnlineService</code>).</li>
                <li>Agar computer mein Node.js nahi hai, to <b>nodejs.org</b> se 1-click install karein.</li>
                <li>Folder ke andar <b>START-WORKSTATION.bat</b> par double-click karein!</li>
                <li>Chrome/Edge browser mein <b>"Install as App"</b> par click karke desktop shortcut bana lein.</li>
              </ol>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: SECURITY AUDIT & ACCESS LOGS */}
      {activeSubTab === 'logs' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div>
              <h2 className="text-base font-extrabold text-white">Real-Time Security & Device Audit Log</h2>
              <p className="text-xs text-slate-400">Record of all authorized PC & Mobile logins, device locks, and blocked access attempts</p>
            </div>
            <button
              onClick={loadData}
              className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white text-xs font-semibold"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Refresh Logs</span>
            </button>
          </div>

          <div className="overflow-x-auto max-h-96">
            <table className="w-full text-left text-xs">
              <thead className="sticky top-0 bg-slate-900 border-b border-slate-800 text-slate-400">
                <tr>
                  <th className="py-2.5 px-3">Timestamp</th>
                  <th className="py-2.5 px-3">Action</th>
                  <th className="py-2.5 px-3">Operator</th>
                  <th className="py-2.5 px-3">Type</th>
                  <th className="py-2.5 px-3">Device ID</th>
                  <th className="py-2.5 px-3">Details</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-mono text-[11px]">
                {auditLogs.length > 0 ? (
                  auditLogs.map((log) => (
                    <tr key={log.id} className="hover:bg-slate-950/40">
                      <td className="py-2.5 px-3 text-slate-400">{log.timestamp}</td>
                      <td className="py-2.5 px-3">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          log.action === 'LOGIN_SUCCESS' 
                            ? 'bg-emerald-500/20 text-emerald-400'
                            : log.action === 'DEVICE_BLOCKED'
                            ? 'bg-rose-500/20 text-rose-400'
                            : log.action === 'DEVICE_BOUND'
                            ? 'bg-blue-500/20 text-blue-400'
                            : 'bg-amber-500/20 text-amber-400'
                        }`}>
                          {log.action}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-white font-bold">@{log.username}</td>
                      <td className="py-2.5 px-3 text-slate-400">{log.deviceType === 'mobile' ? '📱 Mobile' : '💻 PC'}</td>
                      <td className="py-2.5 px-3 text-slate-300">{log.deviceId}</td>
                      <td className="py-2.5 px-3 text-slate-400 max-w-xs truncate font-sans">{log.details}</td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={6} className="py-6 text-center text-slate-500">
                      No security audit logs recorded yet.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 5: MASTER SETUP & CONTROL CENTER */}
      {activeSubTab === 'settings' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
            <div>
              <h2 className="text-base font-extrabold text-white flex items-center gap-2">
                <Key className="w-5 h-5 text-blue-400" />
                <span>Master Admin Workstation Setup & Control Center</span>
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Centralized management for Shop Details, POS Rates, Hardware Settings, and Staff Security
              </p>
            </div>

            <span className="bg-rose-500/10 text-rose-300 border border-rose-500/30 text-xs px-3 py-1 rounded-full font-bold w-fit">
              Staff & Operator Access Only
            </span>
          </div>

          {/* STRICT CUSTOMER ACCESS POLICY BANNER */}
          <div className="p-4 rounded-xl bg-gradient-to-r from-rose-950/40 to-slate-950 border border-rose-500/30 space-y-2">
            <div className="flex items-center gap-2 text-rose-400 font-extrabold text-xs">
              <AlertCircle className="w-4 h-4" />
              <span>ZERO CUSTOMER LOGIN ENFORCED (NO PUBLIC ACCESS)</span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Is system mein <b>kisi bhi anjan customer ya public user ka login ya registration poori tarah band hai</b>. 
              Sirf Master Admin ke dwara banaye gaye verified Staff Operator IDs hi login kar sakte hain. 
              Sabhi citizen/customer details sirf shop ke internal <b>Customer CRM</b> mein safe record ke taur par store hoti hain.
            </p>
          </div>

          <form onSubmit={handleSaveSettings} className="space-y-6 text-xs">
            {/* Section 1: Shop & Business Identity */}
            <div className="space-y-3">
              <h3 className="font-extrabold text-white text-xs uppercase tracking-wider flex items-center gap-2 text-blue-400">
                <span>1. Shop Identity & Official Details</span>
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                <div>
                  <label className="text-slate-400 block mb-1">Shop / Center Name</label>
                  <input
                    type="text"
                    value={shopForm.shopName}
                    onChange={(e) => setShopForm({ ...shopForm, shopName: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white font-bold"
                  />
                </div>

                <div>
                  <label className="text-slate-400 block mb-1">Owner Name</label>
                  <input
                    type="text"
                    value={shopForm.ownerName}
                    onChange={(e) => setShopForm({ ...shopForm, ownerName: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white font-bold"
                  />
                </div>

                <div>
                  <label className="text-slate-400 block mb-1">WhatsApp / Contact Phone</label>
                  <input
                    type="text"
                    value={shopForm.phone}
                    onChange={(e) => setShopForm({ ...shopForm, phone: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white font-bold"
                  />
                </div>

                <div>
                  <label className="text-slate-400 block mb-1">UPI ID for Dynamic POS QR</label>
                  <input
                    type="text"
                    value={shopForm.upiId}
                    onChange={(e) => setShopForm({ ...shopForm, upiId: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white font-bold font-mono"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="text-slate-400 block mb-1">Address (Printed on Tax Invoices & Thermal Slips)</label>
                  <input
                    type="text"
                    value={shopForm.address}
                    onChange={(e) => setShopForm({ ...shopForm, address: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white"
                  />
                </div>
              </div>
            </div>

            {/* Section 2: Default POS Rates Setup */}
            <div className="space-y-3 pt-3 border-t border-slate-800">
              <h3 className="font-extrabold text-white text-xs uppercase tracking-wider flex items-center gap-2 text-emerald-400">
                <span>2. Default POS Service Rates & Pricing (₹)</span>
              </h3>

              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
                <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                  <label className="text-slate-400 block text-[11px] mb-1">PVC Smart Card</label>
                  <div className="flex items-center gap-1 font-bold text-emerald-400">
                    <span>₹</span>
                    <input
                      type="number"
                      defaultValue={0}
                      placeholder="0"
                      className="w-full bg-slate-900 border border-slate-700 rounded p-1 text-white font-mono text-xs"
                    />
                  </div>
                </div>

                <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                  <label className="text-slate-400 block text-[11px] mb-1">Passport Photo (8x)</label>
                  <div className="flex items-center gap-1 font-bold text-emerald-400">
                    <span>₹</span>
                    <input
                      type="number"
                      defaultValue={0}
                      placeholder="0"
                      className="w-full bg-slate-900 border border-slate-700 rounded p-1 text-white font-mono text-xs"
                    />
                  </div>
                </div>

                <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                  <label className="text-slate-400 block text-[11px] mb-1">Online Scheme Form</label>
                  <div className="flex items-center gap-1 font-bold text-emerald-400">
                    <span>₹</span>
                    <input
                      type="number"
                      defaultValue={0}
                      placeholder="0"
                      className="w-full bg-slate-900 border border-slate-700 rounded p-1 text-white font-mono text-xs"
                    />
                  </div>
                </div>

                <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                  <label className="text-slate-400 block text-[11px] mb-1">Exam Form (Police)</label>
                  <div className="flex items-center gap-1 font-bold text-emerald-400">
                    <span>₹</span>
                    <input
                      type="number"
                      defaultValue={0}
                      placeholder="0"
                      className="w-full bg-slate-900 border border-slate-700 rounded p-1 text-white font-mono text-xs"
                    />
                  </div>
                </div>

                <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                  <label className="text-slate-400 block text-[11px] mb-1">BioData / CV</label>
                  <div className="flex items-center gap-1 font-bold text-emerald-400">
                    <span>₹</span>
                    <input
                      type="number"
                      defaultValue={0}
                      placeholder="0"
                      className="w-full bg-slate-900 border border-slate-700 rounded p-1 text-white font-mono text-xs"
                    />
                  </div>
                </div>

                <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                  <label className="text-slate-400 block text-[11px] mb-1">Thermal Lamination</label>
                  <div className="flex items-center gap-1 font-bold text-emerald-400">
                    <span>₹</span>
                    <input
                      type="number"
                      defaultValue={0}
                      placeholder="0"
                      className="w-full bg-slate-900 border border-slate-700 rounded p-1 text-white font-mono text-xs"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Section 3: Hardware & Printer Standards */}
            <div className="space-y-3 pt-3 border-t border-slate-800">
              <h3 className="font-extrabold text-white text-xs uppercase tracking-wider flex items-center gap-2 text-purple-400">
                <span>3. Hardware & Printing Standards</span>
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1">
                  <label className="text-slate-400 block font-bold">PVC Card Resolution</label>
                  <div className="text-white font-mono font-extrabold text-xs text-blue-400">300 DPI Ultra HD</div>
                  <p className="text-[10px] text-slate-500">Optimized for Epson L805, L850 & Canon G-Series</p>
                </div>

                <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1">
                  <label className="text-slate-400 block font-bold">Photo Studio Layout</label>
                  <div className="text-white font-mono font-extrabold text-xs text-purple-400">4×6 Inch (10×15 cm) Glossy</div>
                  <p className="text-[10px] text-slate-500">8 pre-aligned passport photos with border guide lines</p>
                </div>

                <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1">
                  <label className="text-slate-400 block font-bold">POS Receipt Printer</label>
                  <div className="text-white font-mono font-extrabold text-xs text-emerald-400">58mm / 80mm Thermal ESC/POS</div>
                  <p className="text-[10px] text-slate-500">Zero-ink thermal paper with dynamic UPI QR code</p>
                </div>
              </div>
            </div>

            {/* Save Button */}
            <div className="pt-2 flex items-center gap-3">
              <button
                type="submit"
                className="px-6 py-3 bg-blue-600 hover:bg-blue-500 text-white font-extrabold rounded-xl shadow-lg shadow-blue-600/30 transition-all hover:scale-105"
              >
                Save Master Setup Configuration
              </button>
            </div>
          </form>
        </div>
      )}

      {/* RENEW ACCESS MODAL */}
      {selectedOpForRenew && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-md w-full p-6 shadow-2xl space-y-4 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <h3 className="font-extrabold text-white text-base flex items-center gap-2">
                <Calendar className="w-5 h-5 text-emerald-400" />
                <span>Renew License & Access Validity</span>
              </h3>
              <button onClick={() => setSelectedOpForRenew(null)} className="text-slate-400 hover:text-white">✕</button>
            </div>

            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-xs space-y-1">
              <div className="text-white font-bold">{selectedOpForRenew.displayName}</div>
              <div className="text-slate-400 font-mono">@{selectedOpForRenew.username} • {selectedOpForRenew.phone}</div>
              <div className="text-emerald-400 font-bold pt-1">
                Current Remaining: {calculateRemainingDays(selectedOpForRenew.validityExpiresAt)} Days
              </div>
            </div>

            <div className="space-y-2 text-xs">
              <label className="text-slate-300 font-bold block">Select Extension Duration:</label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setRenewDaysCount(30)}
                  className={`p-3 rounded-xl border font-bold text-center transition-all ${
                    renewDaysCount === 30
                      ? 'bg-blue-600 text-white border-blue-400 shadow'
                      : 'bg-slate-950 border-slate-800 text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  <div className="text-sm">+30 Days</div>
                  <div className="text-[10px] text-slate-400">1 Month Pass</div>
                </button>

                <button
                  type="button"
                  onClick={() => setRenewDaysCount(90)}
                  className={`p-3 rounded-xl border font-bold text-center transition-all ${
                    renewDaysCount === 90
                      ? 'bg-blue-600 text-white border-blue-400 shadow'
                      : 'bg-slate-950 border-slate-800 text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  <div className="text-sm">+90 Days</div>
                  <div className="text-[10px] text-slate-400">Quarterly Pass</div>
                </button>

                <button
                  type="button"
                  onClick={() => setRenewDaysCount(365)}
                  className={`p-3 rounded-xl border font-bold text-center transition-all ${
                    renewDaysCount === 365
                      ? 'bg-blue-600 text-white border-blue-400 shadow'
                      : 'bg-slate-950 border-slate-800 text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  <div className="text-sm">+365 Days</div>
                  <div className="text-[10px] text-slate-400">Annual License</div>
                </button>

                <button
                  type="button"
                  onClick={() => setRenewDaysCount(3650)}
                  className={`p-3 rounded-xl border font-bold text-center transition-all ${
                    renewDaysCount === 3650
                      ? 'bg-emerald-600 text-white border-emerald-400 shadow'
                      : 'bg-slate-950 border-slate-800 text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  <div className="text-sm">Lifetime</div>
                  <div className="text-[10px] text-slate-400">Permanent Access</div>
                </button>
              </div>
            </div>

            <div className="pt-2 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setSelectedOpForRenew(null)}
                className="px-4 py-2 bg-slate-800 text-slate-300 font-bold rounded-xl text-xs"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleExecuteRenewal}
                className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold rounded-xl shadow text-xs flex items-center gap-1.5"
              >
                <Check className="w-4 h-4" />
                <span>Confirm & Apply Renewal</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* SEND BROADCAST MODAL */}
      {broadcastTargetUsername && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-md w-full p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <h3 className="font-extrabold text-white text-base flex items-center gap-2">
                <MessageSquare className="w-5 h-5 text-sky-400" />
                <span>Send Alert to @{broadcastTargetUsername}</span>
              </h3>
              <button onClick={() => setBroadcastTargetUsername(null)} className="text-slate-400 hover:text-white">✕</button>
            </div>

            <p className="text-xs text-slate-300">
              This message will pop up immediately on the operator's computer or mobile screen.
            </p>

            <textarea
              rows={3}
              value={broadcastMessageText}
              onChange={(e) => setBroadcastMessageText(e.target.value)}
              placeholder="e.g. Please check Ladki Bahin payment slip before handing over to customer."
              className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-white text-xs"
            />

            <div className="flex justify-end gap-2">
              <button
                onClick={() => setBroadcastTargetUsername(null)}
                className="px-4 py-2 bg-slate-800 text-slate-300 font-bold rounded-xl text-xs"
              >
                Cancel
              </button>
              <button
                onClick={handleSendBroadcast}
                className="px-5 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl shadow text-xs flex items-center gap-1.5"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Send Toast Alert</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* REGISTER NEW OPERATOR MODAL */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-md w-full p-6 shadow-2xl space-y-4 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <h3 className="font-extrabold text-white text-base flex items-center gap-2">
                <UserPlus className="w-5 h-5 text-blue-400" />
                <span>Register New Operator ID</span>
              </h3>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-white">✕</button>
            </div>

            <p className="text-xs text-slate-300">
              This new operator ID will bind to <b>1 Authorized PC</b> + <b>1 Authorized Mobile</b> upon their first login from each device.
            </p>

            {addError && (
              <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs">
                {addError}
              </div>
            )}

            <form onSubmit={handleCreateOperator} className="space-y-3 text-xs">
              <div>
                <label className="text-slate-400 block mb-1">Operator Full Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Shaikh Sameer"
                  value={newDisplayName}
                  onChange={(e) => setNewDisplayName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white font-bold"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Username (Login ID)</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. operator3"
                  value={newUsername}
                  onChange={(e) => setNewUsername(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white font-mono font-bold"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Password</label>
                <input
                  type="password"
                  required
                  placeholder="Create secure password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Phone Number</label>
                <input
                  type="tel"
                  placeholder="Mobile number"
                  value={newPhone}
                  onChange={(e) => setNewPhone(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 bg-slate-800 text-slate-300 font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl shadow"
                >
                  Register Operator
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
