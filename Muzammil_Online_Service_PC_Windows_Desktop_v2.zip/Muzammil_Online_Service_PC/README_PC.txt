MUZAMMIL ONLINE SERVICE — WINDOWS PC VERSION

This is the standalone Windows/Desktop version of the Muzammil Online Service app.

Design rule:
- Same Android app theme and feature set
- Desktop/Windows layout optimized for mouse, keyboard and wide screens
- Passport Size Photo is a primary feature
- PVC Card 4x6 (8.5 x 5.5 cm, 2 cards top/bottom)
- PDF -> JPG high quality with password detection and 300 DPI
- CV/Bio Data, Banner Maker, Bill/Receipt, Downloads, portals and schemes

Build locally:
  py -m pip install -r requirements.txt
  python main.py

Windows EXE is built by .github/workflows/windows-exe.yml using GitHub Actions.
The EXE artifact is named Muzammil-Online-Service-PC-Windows.
