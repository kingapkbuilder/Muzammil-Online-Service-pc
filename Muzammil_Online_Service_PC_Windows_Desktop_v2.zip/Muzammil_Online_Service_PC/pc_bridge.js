
(function () {
  function setup(channel) {
    var b = channel.objects.desktopBridge;
    window.AndroidDownload = {
      saveDataUrl: function (url, name) { b.saveDataUrl(url, name); },
      saveText: function (text, name, mime) { b.saveText(text, name, mime || "text/plain"); },
      savePvcPdf: function (url, name) { b.savePvcPdf(url, name); },
      shareDataUrl: function (url, name, mime) { b.shareDataUrl(url, name, mime || "application/octet-stream"); },
      sharePvcPdf: function (url, name) { b.sharePvcPdf(url, name); },
      openDownload: function (name) { b.openDownload(name); },
      shareDownload: function (name) { b.shareDownload(name); },
      listDownloads: function () { return "[]"; }
    };
    window.AndroidPDF = {
      saveReceiptPdf: function (data) { b.saveReceiptPdf(data); },
      saveReceiptJpg: function (data) { b.saveReceiptJpg(data); },
      shareReceiptPdf: function (data) { b.shareReceiptPdf(data); },
      shareReceiptJpg: function (data) { b.shareReceiptJpg(data); },
      shareReceiptPdfWhatsApp: function (data) { b.shareReceiptPdfWhatsApp(data); },
      shareReceiptJpgWhatsApp: function (data) { b.shareReceiptJpgWhatsApp(data); },
      saveBioPdf: function (data) { b.saveBioPdf(data); },
      saveBioJpg: function (data) { b.saveBioJpg(data); },
      shareBioPdf: function (data) { b.shareBioPdf(data); },
      shareBioJpg: function (data) { b.shareBioJpg(data); },
      pickPdfToJpg: function (password) { b.pickPdfToJpg(password || ""); },
      convertSelectedPdfToJpg: function (password, dpi) { b.convertSelectedPdfToJpg(password || "", Number(dpi || 300)); },
      inspectSelectedPdfToJpg: function () { b.inspectSelectedPdfToJpg(); }
    };
    window.Android = {
      printPage: function (title) { b.printPage(title || "Muzammil Online Service"); }
    };
    window.PCDesktop = true;
  }

  function boot() {
    if (window.qt && qt.webChannelTransport && window.QWebChannel) {
      new QWebChannel(qt.webChannelTransport, setup);
    }
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();
})();
