
import base64
import json
import os
import re
import shutil
import subprocess
import tempfile
import webbrowser
from pathlib import Path

import fitz  # PyMuPDF
from PySide6.QtCore import QObject, QUrl, Slot, QStandardPaths, Signal
from PySide6.QtGui import QDesktopServices, QIcon
from PySide6.QtWebChannel import QWebChannel
from PySide6.QtWebEngineCore import QWebEnginePage
from PySide6.QtWebEngineWidgets import QWebEngineView
from PySide6.QtWidgets import QApplication, QFileDialog, QMainWindow, QMessageBox


APP_NAME = "Muzammil Online Service"
BASE = Path(__file__).resolve().parent
DOWNLOADS = Path(QStandardPaths.writableLocation(QStandardPaths.DownloadLocation))

DOWNLOADS.mkdir(parents=True, exist_ok=True)


def ensure_qwebchannel():
    target = BASE / "qwebchannel.js"
    if target.exists():
        return
    try:
        import PySide6
        root = Path(PySide6.__file__).resolve().parent
        candidates = list(root.rglob("qwebchannel.js"))
        if candidates:
            shutil.copyfile(candidates[0], target)
    except Exception:
        pass


ensure_qwebchannel()


def safe_name(name: str, default="Muzammil-File") -> str:
    name = os.path.basename(name or default)
    name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", name).strip()
    return name or default


def data_url_bytes(data_url: str) -> bytes:
    if "," not in data_url:
        return b""
    meta, payload = data_url.split(",", 1)
    if ";base64" in meta:
        return base64.b64decode(payload)
    from urllib.parse import unquote_to_bytes
    return unquote_to_bytes(payload)


class DesktopBridge(QObject):
    status = Signal(str)

    def __init__(self, window):
        super().__init__()
        self.window = window
        self.selected_pdf = None
        self.selected_password = ""

    def _save_bytes(self, data: bytes, name: str) -> str:
        path = DOWNLOADS / safe_name(name)
        path.write_bytes(data)
        self.status.emit(f"Saved: {path.name}")
        return str(path)

    def _open_file(self, path: Path):
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(path)))

    def _share(self, path: Path):
        # Windows has no universal file-share API. Open the containing folder and select the file.
        try:
            subprocess.Popen(["explorer", "/select,", str(path)])
        except Exception:
            self._open_file(path.parent)

    def _print_current_to_pdf(self, filename: str, done=None):
        path = DOWNLOADS / safe_name(filename)
        page = self.window.view.page()

        def finished(p, ok):
            if done:
                done(path, ok)
            else:
                self.status.emit(f"PDF saved: {path.name}")

        try:
            page.pdfPrintingFinished.disconnect()
        except Exception:
            pass
        page.pdfPrintingFinished.connect(finished)
        page.printToPdf(str(path))

    def _print_current_to_jpg(self, filename: str):
        tmp = Path(tempfile.mkstemp(suffix=".pdf")[1])

        def finished(p, ok):
            try:
                if not ok or not tmp.exists():
                    self.status.emit("JPG conversion failed.")
                    return
                doc = fitz.open(str(tmp))
                if not doc.page_count:
                    doc.close()
                    return
                page = doc.load_page(0)
                pix = page.get_pixmap(matrix=fitz.Matrix(2.5, 2.5), alpha=False)
                out = DOWNLOADS / safe_name(filename)
                pix.save(str(out))
                doc.close()
                self.status.emit(f"JPG saved: {out.name}")
            finally:
                try:
                    tmp.unlink(missing_ok=True)
                except Exception:
                    pass

        page = self.window.view.page()
        try:
            page.pdfPrintingFinished.disconnect()
        except Exception:
            pass
        page.pdfPrintingFinished.connect(finished)
        page.printToPdf(str(tmp))

    @Slot(str, str)
    def saveDataUrl(self, url, name):
        self._save_bytes(data_url_bytes(url), name)

    @Slot(str, str, str)
    def saveText(self, text, name, mime):
        self._save_bytes(text.encode("utf-8"), name)

    @Slot(str, str)
    def savePvcPdf(self, url, name):
        data = data_url_bytes(url)
        tmp_img = Path(tempfile.mkstemp(suffix=".jpg")[1])
        tmp_img.write_bytes(data)
        out = DOWNLOADS / safe_name(name)
        doc = fitz.open()
        page = doc.new_page(width=4 * 72, height=6 * 72)
        page.insert_image(page.rect, filename=str(tmp_img))
        doc.save(str(out))
        doc.close()
        tmp_img.unlink(missing_ok=True)
        self.status.emit(f"PDF saved: {out.name}")

    @Slot(str, str, str)
    def shareDataUrl(self, url, name, mime):
        path = Path(self._save_bytes(data_url_bytes(url), name))
        self._share(path)

    @Slot(str, str)
    def sharePvcPdf(self, url, name):
        self.savePvcPdf(url, name)
        self._share(DOWNLOADS / safe_name(name))

    @Slot(str)
    def openDownload(self, name):
        p = DOWNLOADS / safe_name(name)
        if p.exists():
            self._open_file(p)

    @Slot(str)
    def shareDownload(self, name):
        p = DOWNLOADS / safe_name(name)
        if p.exists():
            self._share(p)

    @Slot(str)
    def saveBioPdf(self, data):
        self._print_current_to_pdf("Muzammil-Bio-Data.pdf")

    @Slot(str)
    def saveBioJpg(self, data):
        self._print_current_to_jpg("Muzammil-Bio-Data.jpg")

    @Slot(str)
    def shareBioPdf(self, data):
        path = DOWNLOADS / "Muzammil-Bio-Data.pdf"
        self._print_current_to_pdf("Muzammil-Bio-Data.pdf",
            lambda p, ok: self._share(p) if ok else None)

    @Slot(str)
    def shareBioJpg(self, data):
        self._print_current_to_jpg("Muzammil-Bio-Data.jpg")

    @Slot(str)
    def saveReceiptPdf(self, data):
        self._print_current_to_pdf("Muzammil-Receipt.pdf")

    @Slot(str)
    def saveReceiptJpg(self, data):
        self._print_current_to_jpg("Muzammil-Receipt.jpg")

    @Slot(str)
    def shareReceiptPdf(self, data):
        self._print_current_to_pdf("Muzammil-Receipt.pdf",
            lambda p, ok: self._share(p) if ok else None)

    @Slot(str)
    def shareReceiptJpg(self, data):
        self._print_current_to_jpg("Muzammil-Receipt.jpg")

    @Slot(str)
    def shareReceiptPdfWhatsApp(self, data):
        self._print_current_to_pdf("Muzammil-Receipt.pdf",
            lambda p, ok: webbrowser.open("https://web.whatsapp.com/") if ok else None)

    @Slot(str)
    def shareReceiptJpgWhatsApp(self, data):
        self._print_current_to_jpg("Muzammil-Receipt.jpg")

    @Slot(str)
    def printPage(self, title):
        self.window.view.page().printToPdf(
            str(DOWNLOADS / (safe_name(title or "Muzammil-Print") + ".pdf"))
        )

    @Slot(str)
    def pickPdfToJpg(self, password):
        path, _ = QFileDialog.getOpenFileName(
            self.window, "Select PDF", str(DOWNLOADS), "PDF Files (*.pdf)"
        )
        if not path:
            return
        self.selected_pdf = Path(path)
        self.selected_password = password or ""
        name = self.selected_pdf.name
        self.window.run_js(
            f"window.pdfToJpgPicked && window.pdfToJpgPicked({json.dumps(name)})"
        )
        self.inspectSelectedPdfToJpg()

    @Slot()
    def inspectSelectedPdfToJpg(self):
        if not self.selected_pdf:
            return
        try:
            doc = fitz.open(str(self.selected_pdf))
            pages = doc.page_count
            if doc.needs_pass:
                msg = f"🔐 Password-protected PDF detected • {pages} page(s) • Password field use karein."
            else:
                msg = f"✅ Normal PDF detected • {pages} page(s) • Password ki zarurat nahi."
            doc.close()
        except Exception as e:
            msg = "PDF check failed: " + str(e)
        self.window.run_js(
            f"window.pdfToJpgSecurity && window.pdfToJpgSecurity({json.dumps(msg)})"
        )

    @Slot(str, int)
    def convertSelectedPdfToJpg(self, password, dpi):
        if not self.selected_pdf:
            self.window.run_js(
                "window.pdfToJpgDone && window.pdfToJpgDone('Pehle PDF select karein.')"
            )
            return
        try:
            doc = fitz.open(str(self.selected_pdf))
            if doc.needs_pass:
                if not password:
                    raise RuntimeError("PDF password required.")
                if not doc.authenticate(password):
                    raise RuntimeError("Password galat hai. PDF unlock nahi hua.")
            scale = max(120, min(400, int(dpi))) / 72.0
            base = self.selected_pdf.stem
            for i in range(doc.page_count):
                page = doc.load_page(i)
                pix = page.get_pixmap(matrix=fitz.Matrix(scale, scale), alpha=False)
                out = DOWNLOADS / f"{base}-page-{i+1}.jpg"
                pix.save(str(out), jpg_quality=100)
            pages = doc.page_count
            doc.close()
            msg = f"✅ Conversion complete • {pages} JPG file(s) Downloads mein save ho gaye • {dpi} DPI • JPEG quality 100%"
        except Exception as e:
            msg = "Conversion failed: " + str(e)
        self.window.run_js(
            f"window.pdfToJpgDone && window.pdfToJpgDone({json.dumps(msg)})"
        )


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(APP_NAME + " — Windows PC")
        self.setMinimumSize(1100, 700)
        self.resize(1536, 960)
        icon = BASE / "muzammil_app_icon.png"
        if icon.exists():
            self.setWindowIcon(QIcon(str(icon)))

        self.view = QWebEngineView(self)
        self.setCentralWidget(self.view)

        self.bridge = DesktopBridge(self)
        self.channel = QWebChannel(self.view.page())
        self.channel.registerObject("desktopBridge", self.bridge)
        self.view.page().setWebChannel(self.channel)

        self.view.setUrl(QUrl.fromLocalFile(str(BASE / "index.html")))
        self.bridge.status.connect(self.on_status)
        self.statusBar().showMessage("Muzammil Online Service PC ready")

    def run_js(self, js):
        self.view.page().runJavaScript(js)

    def on_status(self, msg):
        self.statusBar().showMessage(msg, 6000)


if __name__ == "__main__":
    app = QApplication([])
    app.setApplicationName(APP_NAME)
    w = MainWindow()
    w.showMaximized()
    app.exec()
